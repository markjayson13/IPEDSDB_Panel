#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_IPEDSDB_ROOT="$(dirname "$ROOT")/IPEDSDB_ROOT"
export IPEDSDB_ROOT="${IPEDSDB_ROOT:-$DEFAULT_IPEDSDB_ROOT}"

usage() {
  cat <<'EOF'
Run the full IPEDS Access-database pipeline in development mode.

This wrapper is for contract authoring and diagnostics. It never produces a
release-authoritative v2 dataset.

Usage:
  bash manual_commands.sh

Environment:
  IPEDSDB_ROOT  External data root (default: sibling IPEDSDB_ROOT folder)

System dependency:
  mdb-tables, mdb-schema, mdb-export

Outputs:
  development-only panel and QA paths printed by Scripts/00_run_all.py

What this wrapper does:
  1. activates .venv if present
  2. verifies mdb-tools
  3. runs the full 2004:2023 pipeline
  4. runs cleaning and QA

Best use:
  use this to exercise the full workflow while reviewed production contracts
  remain incomplete; use --pipeline-mode release directly for a governed build
EOF
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ -f "$ROOT/.venv/bin/activate" ]]; then
  # shellcheck disable=SC1090
  source "$ROOT/.venv/bin/activate"
fi

echo "[ipedsdb-panel] repo: $ROOT"
echo "[ipedsdb-panel] data root: $IPEDSDB_ROOT"
echo "[ipedsdb-panel] starting preflight"

for bin in mdb-tables mdb-schema mdb-export; do
  if ! command -v "$bin" >/dev/null 2>&1; then
    echo "Missing required system dependency: $bin" >&2
    echo "Preflight failed. Install mdb-tools before running the pipeline." >&2
    exit 1
  fi
done

mkdir -p "$IPEDSDB_ROOT"

echo "[ipedsdb-panel] preflight passed"
echo "[ipedsdb-panel] running full pipeline for years 2004:2023"
echo "[ipedsdb-panel] this can take a while on a first run"

python3 "$ROOT/Scripts/00_run_all.py" \
  --root "$IPEDSDB_ROOT" \
  --years "2004:2023" \
  --pipeline-mode development \
  --run-cleaning \
  --run-qaqc

echo ""
echo "[ipedsdb-panel] run complete"
echo "Development outputs were written to the namespace reported above."
echo ""
echo "Recommended next checks:"
echo "  $IPEDSDB_ROOT/Checks/dictionary_qc/dictionary_qaqc_summary.csv"
echo "  the development panel-QA and acceptance paths reported above"
echo ""
echo "This run is not release eligible."
