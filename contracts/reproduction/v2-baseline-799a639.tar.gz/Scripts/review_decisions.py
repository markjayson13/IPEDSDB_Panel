"""Validation helpers for the author-countersigned B03/B04 decision ledger."""
from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime
from pathlib import Path

import pandas as pd


EXPECTED_DECISION_IDS = {
    "B03-ZERO-001",
    "B04-ALIAS-001",
    *(f"B04-GAP-{number:03d}" for number in range(1, 27)),
}
REQUIRED_COLUMNS = [
    "decision_id",
    "subsystem",
    "scope",
    "affected_year_table_column_rows",
    "question",
    "evidence_based_proposal",
    "allowed_decisions",
    "approved_role_or_grain",
    "decision",
    "justification",
    "reviewer",
    "reviewed_at",
    "source_commit",
]
ROLE_TRANSLATIONS = {
    "administrative_field": "metadata",
    "measure_candidate": "measure",
    "intentionally_excluded": "excluded",
    "dimension": "dimension",
}


class DecisionRegisterError(ValueError):
    """The reviewed ledger is incomplete, altered, or internally inconsistent."""


def _fail(message: str) -> None:
    raise DecisionRegisterError(message)


def load_countersigned_decisions(
    path: Path,
    *,
    expected_source_commits: Mapping[str, str],
) -> pd.DataFrame:
    """Load only a complete, exact, author-countersigned 28-decision ledger."""
    if not path.exists():
        _fail(f"decision register does not exist: {path}")
    decisions = pd.read_csv(path, dtype=str, keep_default_na=False).fillna("")
    missing = [column for column in REQUIRED_COLUMNS if column not in decisions.columns]
    if missing:
        _fail(f"decision register missing columns: {', '.join(missing)}")
    decisions = decisions[REQUIRED_COLUMNS].copy()
    for column in REQUIRED_COLUMNS:
        decisions[column] = decisions[column].astype(str).str.strip()

    observed_ids = decisions["decision_id"].tolist()
    if (
        len(decisions) != 28
        or len(set(observed_ids)) != 28
        or set(observed_ids) != EXPECTED_DECISION_IDS
    ):
        _fail("decision register must contain exactly the expected 28 unique decision_id values")

    expected_commit_ids = set(expected_source_commits)
    if expected_commit_ids != EXPECTED_DECISION_IDS:
        missing = sorted(EXPECTED_DECISION_IDS - expected_commit_ids)
        unexpected = sorted(expected_commit_ids - EXPECTED_DECISION_IDS)
        _fail(
            "expected source-commit map must contain exactly the 28 decision IDs; "
            f"missing={','.join(missing) or '<none>'}; "
            f"unexpected={','.join(unexpected) or '<none>'}"
        )

    for field in (
        "decision",
        "approved_role_or_grain",
        "justification",
        "reviewer",
        "reviewed_at",
        "source_commit",
    ):
        if decisions[field].eq("").any():
            bad = decisions.loc[decisions[field].eq(""), "decision_id"].tolist()
            _fail(f"decision register field {field} is blank for: {', '.join(bad)}")

    invalid_dates = decisions["reviewed_at"].map(
        lambda value: _is_invalid_iso_date(value)
    )
    if invalid_dates.any():
        bad = decisions.loc[invalid_dates, "decision_id"].tolist()
        _fail(f"decision register field reviewed_at is not an ISO date for: {', '.join(bad)}")

    wrong_commits = [
        row.decision_id
        for row in decisions.itertuples(index=False)
        if row.source_commit != expected_source_commits[row.decision_id]
    ]
    if wrong_commits:
        _fail(
            "decision register field source_commit does not match reviewed "
            "per-decision provenance for: "
            + ", ".join(wrong_commits)
        )

    invalid_decisions: list[str] = []
    for row in decisions.itertuples(index=False):
        allowed = {value.strip() for value in row.allowed_decisions.split("|") if value.strip()}
        if row.decision not in allowed:
            invalid_decisions.append(row.decision_id)
    if invalid_decisions:
        _fail(
            "decision is not listed in allowed_decisions for: "
            + ", ".join(invalid_decisions)
        )

    blocked = set(
        decisions.loc[
            decisions["decision"] == "request_more_evidence",
            "decision_id",
        ]
    )
    if blocked:
        _fail(
            "fully countersigned decision register must contain no "
            "request_more_evidence decisions; observed: "
            + ", ".join(sorted(blocked))
        )
    return decisions


def _is_invalid_iso_date(value: str) -> bool:
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        return True
    return False


def canonical_source_column_role(review_role: str) -> str:
    """Translate only author-supported review roles into runtime contract roles."""
    normalized = str(review_role or "").strip().lower()
    try:
        return ROLE_TRANSLATIONS[normalized]
    except KeyError as exc:
        raise DecisionRegisterError(
            f"review role {normalized or '<blank>'!r} is unresolved or unsupported"
        ) from exc
