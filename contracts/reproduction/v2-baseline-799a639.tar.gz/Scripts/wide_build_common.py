#!/usr/bin/env python3
"""
Shared parsing and planning helpers for the wide-panel builders.

Reads:
- v2 scalar-long schema information
- release analysis/discrete contracts
- optional dictionary-lake discovery metadata
- CLI options from wide-build callers

Writes:
- no durable artifacts directly

Focus:
- frozen release-schema planning
- CLI normalization
- development-only compatibility seeding
- reviewed discrete-family planning
"""
from __future__ import annotations

import argparse
import json
import os
import pathlib
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd
import pyarrow as pa

from access_build_utils import DEFAULT_IPEDSDB_ROOT
from panel_v2_schema import PANEL_CONTRACT_ID


NULL_LIKE_TOKENS = ("", ".", "nan", "none", "<na>", "na", "nat")
ANALYSIS_SCHEMA_FIELDS = (
    "contract_id",
    "analysis_column",
    "logical_type",
    "source_variables",
    "transformation",
    "inclusion_reason",
    "first_year",
    "last_year",
    "nullable",
    "status",
)
DISCRETE_FAMILY_FIELDS = (
    "contract_id",
    "source_file",
    "family_id",
    "component_varname",
    "component_code",
    "semantic_type",
    "active_tokens",
    "inactive_tokens",
    "missing_tokens",
    "output_column",
    "output_type",
    "multi_active_policy",
    "drop_components",
    "source_evidence",
    "review_note",
)
LOGICAL_TYPES = {
    "integer",
    "decimal",
    "float",
    "boolean",
    "categorical string",
    "free text",
    "identifier string",
}
DISCRETE_SEMANTIC_TYPES = {
    "one_hot",
    "multi_select",
    "ordinal_components",
    "not_collapsible",
    "unknown",
}
RELEASE_INCLUDED_ANALYSIS_STATUSES = {"approved", "active"}
RELEASE_EXCLUDED_ANALYSIS_STATUSES = {"excluded_all_null"}
RELEASE_ANALYSIS_STATUSES = (
    RELEASE_INCLUDED_ANALYSIS_STATUSES | RELEASE_EXCLUDED_ANALYSIS_STATUSES
)
DIRECT_TRANSFORMATIONS = {"identity", "direct", "none"}
DISCRETE_TRANSFORMATION_PREFIX = "discrete:"


class WideContractError(ValueError):
    """Raised when a release-governing wide contract is absent or unsafe."""


def _read_contract(path: str | Path, required: tuple[str, ...], label: str) -> pd.DataFrame:
    fp = Path(path)
    if not fp.is_file():
        raise WideContractError(f"{label} contract does not exist: {fp}")
    try:
        df = pd.read_csv(fp, dtype="string", keep_default_na=False, encoding="utf-8")
    except UnicodeDecodeError as exc:
        raise WideContractError(f"{label} contract is not strict UTF-8: {fp}") from exc
    missing = [name for name in required if name not in df.columns]
    if missing:
        raise WideContractError(f"{label} contract missing required columns: {missing}")
    return df.loc[:, list(required)].fillna("").copy()


def _normalize_bool(value: object, *, field: str) -> bool:
    token = str(value).strip().lower()
    if token in {"true", "1", "yes"}:
        return True
    if token in {"false", "0", "no"}:
        return False
    raise WideContractError(f"{field} must be true or false, got {value!r}")


def split_contract_values(value: object) -> tuple[str, ...]:
    """Parse a reviewed contract list without assigning semantics by regex."""
    text = str(value or "").strip()
    if not text:
        return ()
    if text.startswith("["):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise WideContractError(f"invalid JSON contract list: {text!r}") from exc
        if not isinstance(parsed, list):
            raise WideContractError(f"contract list must be an array: {text!r}")
        values = [str(item).strip() for item in parsed]
    else:
        values = [item.strip() for item in text.split("|")]
    if any(not item for item in values):
        raise WideContractError(f"contract list contains a blank member: {text!r}")
    if len(values) != len(set(values)):
        raise WideContractError(f"contract list contains duplicate members: {text!r}")
    return tuple(values)


def load_analysis_schema_contract(
    path: str | Path,
    *,
    contract_id: str = PANEL_CONTRACT_ID,
) -> pd.DataFrame:
    """Load and validate the frozen release analysis schema."""
    df = _read_contract(path, ANALYSIS_SCHEMA_FIELDS, "analysis schema")
    if df.empty:
        raise WideContractError("analysis schema contract has no approved rows")
    for col in ["contract_id", "analysis_column", "logical_type", "transformation", "inclusion_reason", "status"]:
        df[col] = df[col].astype(str).str.strip()
    df["analysis_column"] = df["analysis_column"].str.upper()
    df["logical_type"] = df["logical_type"].str.lower()
    df["status"] = df["status"].str.lower()
    df["transformation"] = df["transformation"].str.lower()
    wrong_contract = df[df["contract_id"] != contract_id]
    if not wrong_contract.empty:
        raise WideContractError("analysis schema rows do not match the active contract_id")
    if (df["analysis_column"] == "").any() or (df["transformation"] == "").any() or (df["inclusion_reason"] == "").any():
        raise WideContractError("analysis schema contains blank governed fields")
    reserved = sorted(set(df["analysis_column"]) & {"UNITID", "YEAR"})
    if reserved:
        raise WideContractError(f"analysis schema reuses reserved panel keys: {reserved}")
    dupes = df[df["analysis_column"].duplicated(keep=False)]
    if not dupes.empty:
        raise WideContractError(
            f"analysis schema has duplicate analysis_column rows: {sorted(dupes['analysis_column'].unique())}"
        )
    invalid_types = sorted(set(df["logical_type"]) - LOGICAL_TYPES)
    if invalid_types:
        raise WideContractError(f"analysis schema has unsupported logical types: {invalid_types}")
    invalid_status = sorted(set(df["status"]) - RELEASE_ANALYSIS_STATUSES)
    if invalid_status:
        raise WideContractError(f"analysis schema has non-release statuses: {invalid_status}")
    invalid_all_null_reasons = df[
        (df["status"] == "excluded_all_null")
        & (df["inclusion_reason"] != "no_observed_values")
    ]
    if not invalid_all_null_reasons.empty:
        raise WideContractError(
            "excluded_all_null analysis rows must use "
            "inclusion_reason=no_observed_values"
        )
    unsupported_transforms = sorted(
        {
            value
            for value in df["transformation"]
            if value not in DIRECT_TRANSFORMATIONS
            and not value.startswith(DISCRETE_TRANSFORMATION_PREFIX)
        }
    )
    if unsupported_transforms:
        raise WideContractError(
            f"analysis schema has unsupported transformations: {unsupported_transforms}"
        )
    malformed_discrete = sorted(
        {
            value
            for value in df["transformation"]
            if value.startswith(DISCRETE_TRANSFORMATION_PREFIX)
            and not value.removeprefix(DISCRETE_TRANSFORMATION_PREFIX).strip()
        }
    )
    if malformed_discrete:
        raise WideContractError(
            f"analysis schema has malformed discrete transformations: {malformed_discrete}"
        )
    parsed_sources: list[tuple[str, ...]] = []
    nullable: list[bool] = []
    first_years: list[int] = []
    last_years: list[int] = []
    for row in df.to_dict("records"):
        sources = split_contract_values(row["source_variables"])
        if not sources:
            raise WideContractError(f"analysis column {row['analysis_column']} has no source_variables")
        parsed_sources.append(sources)
        nullable.append(_normalize_bool(row["nullable"], field="analysis nullable"))
        try:
            first = int(str(row["first_year"]).strip())
            last = int(str(row["last_year"]).strip())
        except ValueError as exc:
            raise WideContractError(f"analysis column {row['analysis_column']} has invalid year bounds") from exc
        if first > last:
            raise WideContractError(f"analysis column {row['analysis_column']} has first_year after last_year")
        first_years.append(first)
        last_years.append(last)
    df["source_variables_parsed"] = parsed_sources
    df["nullable_bool"] = nullable
    df["first_year_int"] = first_years
    df["last_year_int"] = last_years
    df["included_bool"] = df["status"].isin(RELEASE_INCLUDED_ANALYSIS_STATUSES)
    direct_sources: dict[str, set[str]] = {}
    direct_occurrences: dict[tuple[str, str], int] = {}
    for row in df.to_dict("records"):
        if str(row["transformation"]).strip().lower() not in DIRECT_TRANSFORMATIONS:
            continue
        for source in row["source_variables_parsed"]:
            key = str(source).strip()
            if key.lower().startswith("variable_id:"):
                key = f"variable_id:{key.split(':', 1)[1]}"
            elif key.lower().startswith("varname:"):
                key = f"varname:{key.split(':', 1)[1].upper()}"
            else:
                key = f"auto:{key.upper()}"
            direct_sources.setdefault(key, set()).add(str(row["analysis_column"]))
            occurrence = (str(row["analysis_column"]), key)
            direct_occurrences[occurrence] = direct_occurrences.get(occurrence, 0) + 1
    repeated = sorted(key for key, count in direct_occurrences.items() if count > 1)
    if repeated:
        raise WideContractError(f"analysis schema repeats normalized direct source variables: {repeated}")
    ambiguous = {key: sorted(columns) for key, columns in direct_sources.items() if len(columns) > 1}
    if ambiguous:
        raise WideContractError(f"analysis schema maps direct source variables to multiple columns: {ambiguous}")
    return df


def load_discrete_family_contract(
    path: str | Path,
    *,
    contract_id: str = PANEL_CONTRACT_ID,
) -> pd.DataFrame:
    """Load reviewed component semantics; numbering patterns confer no authority."""
    df = _read_contract(path, DISCRETE_FAMILY_FIELDS, "discrete family")
    if df.empty:
        raise WideContractError("discrete family contract has no reviewed rows")
    strip_cols = list(DISCRETE_FAMILY_FIELDS)
    for col in strip_cols:
        df[col] = df[col].astype(str).str.strip()
    for col in ["source_file", "family_id", "component_varname", "output_column"]:
        df[col] = df[col].str.upper()
    df["semantic_type"] = df["semantic_type"].str.lower()
    df["output_type"] = df["output_type"].str.lower()
    df["multi_active_policy"] = df["multi_active_policy"].str.lower()
    if (df["contract_id"] != contract_id).any():
        raise WideContractError("discrete family rows do not match the active contract_id")
    required_nonblank = ["source_file", "family_id", "component_varname", "component_code", "semantic_type", "source_evidence", "review_note"]
    if any((df[col] == "").any() for col in required_nonblank):
        raise WideContractError("discrete family contract contains blank governed fields")
    invalid_semantics = sorted(set(df["semantic_type"]) - DISCRETE_SEMANTIC_TYPES)
    if invalid_semantics:
        raise WideContractError(f"discrete family contract has unsupported semantics: {invalid_semantics}")
    if (df["semantic_type"] == "unknown").any():
        raise WideContractError("discrete family contract contains unresolved unknown families")
    if ((df["output_type"] != "") & ~df["output_type"].isin(LOGICAL_TYPES)).any():
        raise WideContractError("discrete family contract has unsupported output_type values")
    df["drop_components_bool"] = [
        _normalize_bool(value, field="discrete drop_components") for value in df["drop_components"]
    ]
    if ((df["semantic_type"] == "multi_select") & df["drop_components_bool"]).any():
        raise WideContractError("multi_select components cannot be dropped")
    if ((df["semantic_type"] == "one_hot") & (df["output_column"] == "")).any():
        raise WideContractError("one_hot families require an output_column")
    if ((df["semantic_type"] == "one_hot") & ~df["multi_active_policy"].isin({"error", "allow_set"})).any():
        raise WideContractError("one_hot multi_active_policy must be error or allow_set")
    if ((df["semantic_type"] == "multi_select") & ~df["multi_active_policy"].isin({"set", "preserve"})).any():
        raise WideContractError("multi_select multi_active_policy must be set or preserve")
    dupes = df[df.duplicated(["source_file", "family_id", "component_varname"], keep=False)]
    if not dupes.empty:
        raise WideContractError("discrete family contract repeats a component within a family")
    zero_active_policies: list[str] = []
    zero_active_values: list[str] = []
    for row in df.to_dict("records"):
        semantic = str(row["semantic_type"])
        output = str(row["output_column"])
        review = str(row["review_note"]).lower()
        matches = re.findall(r"(?<![a-z0-9_])zero_active=(missing|none:[^\s;,]+)", review)
        if semantic in {"one_hot", "multi_select"} and output:
            if len(matches) != 1:
                raise WideContractError(
                    "discrete family component must declare exactly one normalized "
                    f"zero_active policy: {row['source_file']}/{row['family_id']}/{row['component_varname']}"
                )
            policy = matches[0].lower()
        else:
            if len(set(match.lower() for match in matches)) > 1:
                raise WideContractError(
                    "discrete family component contains contradictory zero_active policies: "
                    f"{row['source_file']}/{row['family_id']}/{row['component_varname']}"
                )
            policy = matches[0].lower() if matches else ""
        zero_active_policies.append(policy)
        zero_active_values.append(policy.split(":", 1)[1] if policy.startswith("none:") else "")
    df["zero_active_policy"] = zero_active_policies
    df["zero_active_value"] = zero_active_values

    for (source_file, family_id), group in df.groupby(["source_file", "family_id"], sort=False):
        for field in ["semantic_type", "output_column", "output_type", "multi_active_policy", "drop_components_bool"]:
            if group[field].nunique(dropna=False) != 1:
                raise WideContractError(f"discrete family {source_file}/{family_id} has inconsistent {field}")
        if group["component_code"].duplicated().any():
            raise WideContractError(f"discrete family {source_file}/{family_id} repeats component_code")
        semantic = str(group.iloc[0]["semantic_type"])
        output = str(group.iloc[0]["output_column"])
        if semantic in {"one_hot", "multi_select"} and output:
            policies = sorted(set(group["zero_active_policy"]))
            if len(policies) != 1:
                raise WideContractError(
                    f"discrete family {source_file}/{family_id} has contradictory zero_active policies: {policies}"
                )
    active_sets: list[tuple[str, ...]] = []
    inactive_sets: list[tuple[str, ...]] = []
    missing_sets: list[tuple[str, ...]] = []
    for row in df.to_dict("records"):
        active = tuple(token.lower() for token in split_contract_values(row["active_tokens"]))
        inactive = tuple(token.lower() for token in split_contract_values(row["inactive_tokens"]))
        missing = tuple(token.lower() for token in split_contract_values(row["missing_tokens"]))
        if set(active) & set(inactive) or set(active) & set(missing) or set(inactive) & set(missing):
            raise WideContractError(
                f"discrete component {row['source_file']}/{row['component_varname']} has overlapping token classes"
            )
        if row["semantic_type"] in {"one_hot", "multi_select"} and (not active or not inactive):
            raise WideContractError(
                f"discrete component {row['source_file']}/{row['component_varname']} requires active and inactive tokens"
            )
        active_sets.append(active)
        inactive_sets.append(inactive)
        missing_sets.append(missing)
    df["active_tokens_parsed"] = active_sets
    df["inactive_tokens_parsed"] = inactive_sets
    df["missing_tokens_parsed"] = missing_sets
    return df


def default_repo_root() -> pathlib.Path:
    return pathlib.Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))


def setup_logging(log_path: str | None) -> None:
    if not log_path:
        return
    log_file = Path(log_path)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    f = log_file.open("a", buffering=1)

    class Tee:
        def __init__(self, *streams):
            self.streams = streams

        def write(self, data):
            for s in self.streams:
                s.write(data)

        def flush(self):
            for s in self.streams:
                s.flush()

    sys.stdout = Tee(sys.stdout, f)
    sys.stderr = Tee(sys.stderr, f)


def parse_years(spec: str) -> list[int]:
    start, end = spec.split(":")
    return list(range(int(start), int(end) + 1))


def parquet_row_group_size(value: str) -> int:
    """Accept DuckDB-compatible row-group sizes without silent rounding."""
    size = int(value)
    if size < 2048 or size % 2048 != 0:
        raise argparse.ArgumentTypeError(
            "must be at least 2048 and a multiple of 2048"
        )
    return size


def pick_col(schema: pa.Schema, candidates: Iterable[str]) -> str:
    for c in candidates:
        if c in schema.names:
            return c
    raise ValueError(f"None of {candidates} found in schema. Columns: {schema.names}")


def pick_optional_col(schema: pa.Schema, candidates: Iterable[str]) -> str | None:
    for c in candidates:
        if c in schema.names:
            return c
    return None


def ensure_all_target_cols(df: pd.DataFrame, targets: list[str]) -> pd.DataFrame:
    cols = ["year", "UNITID"] + targets
    return df.reindex(columns=cols)


def coerce_types(df: pd.DataFrame, numeric_targets: set[str] | None = None) -> pd.DataFrame:
    df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int32")
    df["UNITID"] = pd.to_numeric(df["UNITID"], errors="coerce").astype("Int64")
    if numeric_targets:
        cols = [c for c in df.columns if c in numeric_targets]
        if cols:
            df[cols] = df[cols].apply(pd.to_numeric, errors="coerce")
    return df


def order_targets(targets: Iterable[str]) -> list[str]:
    target_set = set(targets)
    non_x = sorted([t for t in target_set if not t.startswith("X")])
    ordered: list[str] = []
    for base in non_x:
        ordered.append(base)
        xvar = f"X{base}"
        if xvar in target_set:
            ordered.append(xvar)
    remaining = sorted([t for t in target_set if t not in ordered])
    ordered.extend(remaining)
    return ordered


def normalize_value_tokens(series: pd.Series) -> pd.Series:
    txt = series.astype("string").str.strip()
    low = txt.str.lower()
    txt = txt.mask(low.isin(NULL_LIKE_TOKENS), pd.NA)
    return txt


def is_non_empty_value(series: pd.Series) -> pd.Series:
    normalized = normalize_value_tokens(series)
    return normalized.notna()


def parse_upper_set(spec: str | None) -> set[str]:
    if not spec:
        return set()
    return {x.strip().upper() for x in str(spec).split(",") if x.strip()}


def is_expected_disc_conflict(source_file: str, variable_family: str) -> bool:
    # Retained only for the development report schema. No source/family pair is
    # semantically safe without a reviewed discrete-family contract.
    return False


def is_dimensioned_source_file(sf: str, dim_sources: set[str], dim_prefixes: tuple[str, ...]) -> bool:
    s = str(sf or "").strip().upper()
    if not s:
        return False
    if s in dim_sources:
        return True
    return any(s.startswith(p) for p in dim_prefixes)


def find_anti_garbage_hits(targets: Iterable[str], blocked_ids: set[str]) -> list[str]:
    hits: list[str] = []
    for t in targets:
        up = str(t).upper()
        if up in blocked_ids:
            hits.append(t)
            continue
        for b in blocked_ids:
            if re.match(rf"^{re.escape(b)}($|[_0-9])", up):
                hits.append(t)
                break
    return sorted(set(hits))


def build_numeric_targets(dict_path: str | None, targets: Iterable[str]) -> set[str]:
    if not dict_path:
        return set()
    ddf = pd.read_parquet(dict_path)
    if "varname" not in ddf.columns:
        return set()
    for col in ["DataType", "format"]:
        if col not in ddf.columns:
            ddf[col] = ""
    ddf["varname"] = ddf["varname"].fillna("").astype(str).str.upper().str.strip()
    ddf["DataType"] = ddf["DataType"].fillna("").astype(str).str.lower().str.strip()
    ddf["format"] = ddf["format"].fillna("").astype(str).str.lower().str.strip()
    ddf = ddf[ddf["varname"] != ""]
    if ddf.empty:
        return set()

    numeric_markers = {"cont", "continuous", "numeric", "number", "num", "int", "integer", "float", "double", "decimal"}
    string_markers = {"disc", "discrete", "char", "string", "text", "categorical", "category"}
    target_set = {str(t).upper().strip() for t in targets}
    out: set[str] = set()

    for varname, g in ddf.groupby("varname", sort=False):
        if varname not in target_set:
            continue
        vals = set(g["DataType"].tolist() + g["format"].tolist())
        has_numeric = any(v in numeric_markers for v in vals if v)
        has_string = any(v in string_markers for v in vals if v)
        if has_numeric and not has_string:
            out.add(varname)
    return out


def load_legacy_schema_seed_manifest(path: str | None) -> pd.DataFrame:
    cols = ["column_name", "seed_reason", "dtype", "source_contract"]
    if not path:
        return pd.DataFrame(columns=cols)
    fp = Path(path)
    if not fp.exists():
        return pd.DataFrame(columns=cols)
    df = pd.read_csv(fp, dtype="string").fillna("")
    if "column_name" not in df.columns:
        raise ValueError(f"legacy schema seed manifest missing required column_name: {path}")
    for col in cols:
        if col not in df.columns:
            df[col] = ""
    df = df[cols].copy()
    df["column_name"] = df["column_name"].astype(str).str.upper().str.strip()
    df["seed_reason"] = df["seed_reason"].astype(str).str.strip()
    df["dtype"] = df["dtype"].astype(str).str.lower().str.strip()
    df["source_contract"] = df["source_contract"].astype(str).str.strip()
    df = df[df["column_name"] != ""].drop_duplicates(subset=["column_name"], keep="first").reset_index(drop=True)
    return df


def plan_legacy_schema_seeds(
    manifest_df: pd.DataFrame,
    discovered_targets: Iterable[str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    cols = ["column_name", "seed_reason", "dtype", "source_contract", "present_in_target_universe", "seeded_for_compatibility"]
    if manifest_df.empty:
        return pd.DataFrame(columns=cols), pd.DataFrame(columns=cols)
    target_set = {str(t).upper().strip() for t in discovered_targets}
    plan_df = manifest_df.copy()
    plan_df["present_in_target_universe"] = plan_df["column_name"].isin(target_set)
    plan_df["seeded_for_compatibility"] = ~plan_df["present_in_target_universe"]
    seeded_df = plan_df[plan_df["seeded_for_compatibility"]].copy()
    return plan_df, seeded_df


def build_disc_groups(dict_path: str | None) -> tuple[dict[str, tuple[str, str]], dict[str, list[str]]]:
    if not dict_path:
        return {}, {}
    ddf = pd.read_parquet(dict_path)
    ddf.columns = [c.strip() for c in ddf.columns]
    name_col = "varname" if "varname" in ddf.columns else None
    dtype_col = "DataType" if "DataType" in ddf.columns else None
    fmt_col = "format" if "format" in ddf.columns else None
    if not name_col:
        return {}, {}

    def is_disc(row) -> bool:
        dt = str(row.get(dtype_col, "") or "").strip().lower() if dtype_col else ""
        fmt = str(row.get(fmt_col, "") or "").strip().lower() if fmt_col else ""
        return dt == "disc" or fmt == "disc"

    disc_names = ddf[ddf.apply(is_disc, axis=1)][name_col].dropna().astype(str).str.upper().unique()
    var_to_group: dict[str, tuple[str, str]] = {}
    group_to_vars: dict[str, list[str]] = {}
    for v in disc_names:
        m = re.match(r"^(.*?)(\d+)$", v)
        if not m:
            continue
        base, suffix = m.group(1), m.group(2)
        if not base:
            continue
        var_to_group[v] = (base, suffix)
        group_to_vars.setdefault(base, []).append(v)
    group_to_vars = {k: sorted(vs) for k, vs in group_to_vars.items() if len(vs) >= 2}
    var_to_group = {v: grp for v, grp in var_to_group.items() if grp[0] in group_to_vars}
    return var_to_group, group_to_vars


def resolve_disc_names(
    group_to_vars: dict[str, list[str]],
    existing: set[str],
    suffix: str = "_CAT",
) -> dict[str, str]:
    mapping: dict[str, str] = {}
    taken = set(existing)
    for base in sorted(group_to_vars):
        if base not in taken:
            mapping[base] = base
            taken.add(base)
            continue
        base_suffix = f"{base}{suffix}"
        if base_suffix not in taken:
            mapping[base] = base_suffix
            taken.add(base_suffix)
            continue
        i = 1
        while True:
            cand = f"{base}{suffix}{i}"
            if cand not in taken:
                mapping[base] = cand
                taken.add(cand)
                break
            i += 1
    return mapping


@dataclass
class WideBuildRuntime:
    repo_root: pathlib.Path
    years: list[int]
    scalar_conflicts_out: str | None
    anti_garbage_out: str | None
    cast_report_out: str | None
    target_lineage_out: str | None
    column_lineage_out: str | None
    seeded_legacy_out: str | None
    dim_sources: set[str]
    dim_prefixes: tuple[str, ...]
    anti_garbage_ids: set[str]
    exclude_vars: set[str]
    legacy_analysis_schema: bool
    legacy_schema_seed_manifest: str | None


def build_arg_parser(repo_root: pathlib.Path | None = None) -> argparse.ArgumentParser:
    repo_root = repo_root or default_repo_root()
    code_root = pathlib.Path(__file__).resolve().parents[1]
    build_root = repo_root / "build"

    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(repo_root), help="External IPEDSDB_ROOT used for output namespace enforcement")
    ap.add_argument("--build-mode", choices=["release", "development"], default="release", help="Release is contract-driven and fail-closed; development enables legacy diagnostics")
    ap.add_argument("--input", required=True, help="Stitched LONG panel parquet")
    ap.add_argument("--out_dir", required=True, help="Output dir for year-partitioned wide parquet")
    ap.add_argument("--years", default="2004:2023", help='Year span, default analysis window: "2004:2023"')
    ap.add_argument("--write_single", default=None, help="Optional single wide parquet path")
    ap.add_argument("--dictionary", default=None, help="Optional dictionary_lake.parquet for disc grouping")
    ap.add_argument("--dimensioned-input", default=None, help="Stage 05 dimensioned-long parquet; required for release lane coverage")
    ap.add_argument("--source-column-coverage", default=None, help="Stage 04 source-column coverage directory/glob; required for release lane coverage")
    ap.add_argument("--lane-split", action=argparse.BooleanOptionalAction, default=False, help="Split long input into scalar lane and dimensioned lane using source_file rules")
    ap.add_argument("--scalar-long-out", default=None, help="Optional output parquet for scalar long lane")
    ap.add_argument("--dim-long-out", default=None, help="Optional output parquet for dimensioned long lane")
    ap.add_argument("--wide-analysis-out", default=None, help="Alias for --write_single when building analysis-wide output")
    ap.add_argument(
        "--raw-wide-out",
        default=None,
        help="Release-only immutable alias for the exact pre-cleaning analysis-wide panel.",
    )
    ap.add_argument("--dim-sources", default="IC_CAMPUSES,IC_PCCAMPUSES,F_FA_F,F_FA_G", help="Exact source_file names treated as dimensioned")
    ap.add_argument("--dim-prefixes", default="C_,EF,GR,GR200,SAL,S_,OM,DRV", help="Comma-separated source_file prefixes treated as dimensioned")
    ap.add_argument("--exclude-vars", default=None, help="Comma-separated varnames to exclude from analysis-wide output")
    ap.add_argument("--fail-on-scalar-conflicts", action=argparse.BooleanOptionalAction, default=True, help="Fail if scalar lane has conflicting values on canonical scalar key")
    ap.add_argument("--scalar-conflicts-max-rows", type=int, default=100000, help="Max rows to write to scalar conflicts QC file")
    ap.add_argument("--anti-garbage-ids", default="CIPCODE,LINE,FORMID,FUNCTCD,MAJORNUM", help="Dimension identifier names that must not appear as scalar wide columns")
    ap.add_argument("--drop-anti-garbage-cols", action=argparse.BooleanOptionalAction, default=True, help="Drop blocked anti-garbage identifier columns from wide targets before fail gate")
    ap.add_argument("--fail-on-anti-garbage", action=argparse.BooleanOptionalAction, default=True, help="Fail if anti-garbage blocked identifiers appear as wide columns")
    ap.add_argument("--anti-garbage-out", default=None, help="QC output CSV path for anti-garbage column hits")
    ap.add_argument("--drop-globally-null-post", action=argparse.BooleanOptionalAction, default=False, help="Development-only null-column pruning; forbidden in release mode")
    ap.add_argument("--typed-output", action=argparse.BooleanOptionalAction, default=False, help="Coerce numeric variables using dictionary metadata")
    ap.add_argument("--drop-empty-cols", action=argparse.BooleanOptionalAction, default=False, help="Drop vars that are empty across all requested years")
    ap.add_argument("--collapse-disc", action="store_true", help="Collapse discrete (disc) groups into a base var")
    ap.add_argument("--drop-disc-components", action="store_true", help="Drop component vars after collapse")
    ap.add_argument("--disc-qc-dir", default=None, help="Optional dir to write disc conflict reports")
    ap.add_argument("--disc-qc-detail-max-rows", type=int, default=250000, help="Max detail rows to write per year for disc conflict QC")
    ap.add_argument("--disc-qc-high-signal-min-rows", type=int, default=100, help="Minimum grouped conflict rows to mark a disc conflict summary row as high signal")
    ap.add_argument("--disc-exclude", default=None, help="Comma-separated base names to skip collapsing (e.g., LEVEL,ADMCON)")
    ap.add_argument("--disc-suffix", default="_CAT", help="Suffix used when base name collides with an existing variable")
    ap.add_argument("--dups-qc-dir", default=None, help="Optional dir to write duplicate key samples")
    ap.add_argument("--dups-max-rows", type=int, default=10000, help="Max rows to write for duplicate samples (0 disables)")
    ap.add_argument("--dups-qc-gzip", action="store_true", help="Write dup samples as .csv.gz")
    ap.add_argument("--qc-dir", default=None, help="Optional dir to write QC summary CSV")
    ap.add_argument("--scalar-conflicts-out", default=None, help="QC CSV path for scalar conflict keys")
    ap.add_argument("--cast-report-out", default=None, help="QC CSV path for typed-cast parse report")
    ap.add_argument("--target-lineage-out", default=None, help="QC CSV path for target-lineage audit output")
    ap.add_argument("--column-lineage-out", default=None, help="QC CSV/parquet path for final column-to-source lineage output")
    ap.add_argument("--seeded-legacy-out", default=None, help="QC CSV path for legacy compatibility columns seeded into the wide schema")
    ap.add_argument("--legacy-analysis-schema", action=argparse.BooleanOptionalAction, default=False, help="Development-only compatibility schema; never part of the canonical release")
    ap.add_argument("--legacy-schema-seed-manifest", default=str(code_root / "Artifacts" / "legacy_analysis_schema_seed.csv"), help="CSV manifest for legacy compatibility seed columns")
    ap.add_argument("--lineage-only", action="store_true", help="Stop after global target-lineage audit and skip year builds")
    ap.add_argument("--scan-batch-rows", type=int, default=200_000, help="Batch size for scanning long rows")
    ap.add_argument(
        "--wide-parquet-row-group-size",
        type=parquet_row_group_size,
        default=None,
        help=(
            "Optional DuckDB row-group size for release-wide year parts and the "
            "combined wide panel only; omitted outputs retain DuckDB defaults"
        ),
    )
    ap.add_argument("--scalar-conflict-buckets", type=int, default=16, help="Hash buckets for year-local scalar conflict detection")
    ap.add_argument("--scalar-conflict-bucket-min-year", type=int, default=2008, help="Apply bucketed scalar conflict detection from this year onward")
    ap.add_argument("--duckdb-path", default=str(build_root / "ipeds_build.duckdb"), help="Persistent DuckDB build path")
    ap.add_argument("--duckdb-temp-dir", default=str(build_root / "duckdb_tmp"), help="DuckDB temp directory for spills")
    ap.add_argument("--duckdb-memory-limit", default="8GB", help="DuckDB memory_limit setting for wide builds")
    ap.add_argument("--duckdb-threads", type=int, default=2, help="DuckDB worker threads for wide builds")
    ap.add_argument("--persist-duckdb", action=argparse.BooleanOptionalAction, default=True, help="Persist DuckDB build state to --duckdb-path")
    ap.add_argument("--profile-year", type=int, default=None, help="Optional single year to save DuckDB EXPLAIN plans for")
    ap.add_argument("--profile-dir", default=None, help="Optional directory to write focused SQL plan artifacts")
    ap.add_argument("--profile-analyze", action=argparse.BooleanOptionalAction, default=False, help="Use EXPLAIN ANALYZE instead of EXPLAIN for focused profiling")
    ap.add_argument("--analysis-schema-contract", default=str(code_root / "contracts" / "analysis_schema.csv"), help="Frozen v2 analysis schema contract")
    ap.add_argument("--discrete-family-contract", default=str(code_root / "contracts" / "discrete_families.csv"), help="Reviewed v2 discrete-family semantics")
    ap.add_argument("--value-lineage-out", default=None, help="Release value-level lineage parquet (defaults under --qc-dir)")
    ap.add_argument("--analysis-candidates-out", default=None, help="Dynamic discovery candidate report; never release authority")
    ap.add_argument("--lane-coverage-out", default=None, help="Per-variable lane and release classification report")
    ap.add_argument("--release-bundle-root", default=None, help="Managed immutable Stage 06 release bundle root")
    ap.add_argument("--release-failure-sample-rows", type=int, default=1000, help="Maximum deterministic rows stored for any release failure sample")
    ap.add_argument("--compatibility-output", default=None, help="Separate development-only output for legacy schema compatibility")
    ap.add_argument("--log-file", default=None, help="Optional log file path; defaults to a mode-isolated build log")
    return ap


def validate_development_output_namespace(args: argparse.Namespace) -> None:
    if args.build_mode != "development":
        return
    repo_root = Path(args.root).expanduser().resolve()
    canonical_roots = [
        (repo_root / "Panels" / "v2").resolve(),
        (repo_root / "Checks" / "v2").resolve(),
    ]
    output_values = {
        "--out_dir": args.out_dir,
        "--write_single": args.write_single,
        "--wide-analysis-out": args.wide_analysis_out,
        "--raw-wide-out": args.raw_wide_out,
        "--scalar-long-out": args.scalar_long_out,
        "--dim-long-out": args.dim_long_out,
        "--qc-dir": args.qc_dir,
        "--disc-qc-dir": args.disc_qc_dir,
        "--scalar-conflicts-out": args.scalar_conflicts_out,
        "--anti-garbage-out": args.anti_garbage_out,
        "--cast-report-out": args.cast_report_out,
        "--target-lineage-out": args.target_lineage_out,
        "--column-lineage-out": args.column_lineage_out,
        "--seeded-legacy-out": args.seeded_legacy_out,
        "--value-lineage-out": args.value_lineage_out,
        "--analysis-candidates-out": args.analysis_candidates_out,
        "--lane-coverage-out": args.lane_coverage_out,
        "--compatibility-output": args.compatibility_output,
        "--profile-dir": args.profile_dir,
        "--duckdb-path": args.duckdb_path,
        "--duckdb-temp-dir": args.duckdb_temp_dir,
        "--log-file": args.log_file,
        "--release-bundle-root": args.release_bundle_root,
    }
    violations: list[str] = []
    for flag, value in output_values.items():
        if not value:
            continue
        resolved = Path(value).expanduser().resolve()
        if any(resolved == root or root in resolved.parents for root in canonical_roots):
            violations.append(f"{flag}={resolved}")
    if violations:
        raise SystemExit(
            "development mode cannot write canonical Panels/v2 or Checks/v2 destinations: "
            + "; ".join(violations)
        )


def prepare_runtime(args: argparse.Namespace) -> WideBuildRuntime:
    repo_root = Path(args.root).expanduser().resolve()
    if int(args.scalar_conflict_buckets) < 1:
        raise SystemExit("--scalar-conflict-buckets must be >= 1")
    if int(args.release_failure_sample_rows) < 1:
        raise SystemExit("--release-failure-sample-rows must be >= 1")
    validate_development_output_namespace(args)
    if args.build_mode == "development":
        os.makedirs(args.out_dir, exist_ok=True)
    years = parse_years(args.years)
    if args.wide_analysis_out and not args.write_single:
        args.write_single = args.wide_analysis_out
    if args.write_single is None and args.lane_split:
        args.write_single = str(
            repo_root
            / "Panels"
            / "development"
            / "v2"
            / f"panel_wide_analysis_{years[0]}_{years[-1]}.parquet"
        )

    if args.build_mode == "development" and args.qc_dir:
        Path(args.qc_dir).mkdir(parents=True, exist_ok=True)
    if args.build_mode == "development" and args.scalar_long_out:
        Path(args.scalar_long_out).parent.mkdir(parents=True, exist_ok=True)
    if args.build_mode == "development" and args.dim_long_out:
        Path(args.dim_long_out).parent.mkdir(parents=True, exist_ok=True)
    if args.build_mode == "development" and args.disc_qc_dir:
        Path(args.disc_qc_dir).mkdir(parents=True, exist_ok=True)
    if args.build_mode == "development" and args.profile_dir:
        Path(args.profile_dir).mkdir(parents=True, exist_ok=True)

    scalar_conflicts_out = args.scalar_conflicts_out or (os.path.join(args.qc_dir, "qc_scalar_conflicts.csv") if args.qc_dir else None)
    anti_garbage_out = args.anti_garbage_out or (os.path.join(args.qc_dir, "qc_anti_garbage_failures.csv") if args.qc_dir else None)
    cast_report_out = args.cast_report_out or (os.path.join(args.qc_dir, "qc_cast_report.csv") if args.qc_dir else None)
    target_lineage_out = args.target_lineage_out or (os.path.join(args.qc_dir, "qc_target_lineage.csv") if args.qc_dir else None)
    column_lineage_out = args.column_lineage_out or (os.path.join(args.qc_dir, "qc_column_lineage.csv") if args.qc_dir else None)
    seeded_legacy_out = args.seeded_legacy_out or (os.path.join(args.qc_dir, "qc_seeded_legacy_columns.csv") if args.qc_dir else None)

    return WideBuildRuntime(
        repo_root=repo_root,
        years=years,
        scalar_conflicts_out=scalar_conflicts_out,
        anti_garbage_out=anti_garbage_out,
        cast_report_out=cast_report_out,
        target_lineage_out=target_lineage_out,
        column_lineage_out=column_lineage_out,
        seeded_legacy_out=seeded_legacy_out,
        dim_sources=parse_upper_set(args.dim_sources),
        dim_prefixes=tuple([x.strip().upper() for x in str(args.dim_prefixes).split(",") if x.strip()]),
        anti_garbage_ids=parse_upper_set(args.anti_garbage_ids),
        exclude_vars=parse_upper_set(args.exclude_vars),
        legacy_analysis_schema=bool(args.legacy_analysis_schema),
        legacy_schema_seed_manifest=args.legacy_schema_seed_manifest,
    )
