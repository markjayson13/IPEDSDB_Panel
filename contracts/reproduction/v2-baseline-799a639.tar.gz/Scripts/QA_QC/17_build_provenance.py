#!/usr/bin/env python3
"""
QA 17: write release build provenance.

Reads:
- `Checks/v2/release_manifest/release_manifest.csv`

Writes:
- `Checks/v2/release_metadata/build_provenance.json`
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import DEFAULT_IPEDSDB_ROOT, atomic_write_json, compute_file_metadata, data_layout, repo_root
from stage_provenance import ProvenanceError, resolve_run_dir, sha256_file, tool_versions, verify_run


def parse_args() -> argparse.Namespace:
    root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default=str(root), help="External IPEDSDB_ROOT")
    p.add_argument("--manifest", default=None)
    p.add_argument("--verification", default=None)
    p.add_argument("--out", default=None)
    p.add_argument("--repo-root", default=str(repo_root()))
    p.add_argument("--build-type", default="https://github.com/markjayson13/IPEDSDB_Panel/release-build/v2")
    p.add_argument("--require-clean-git", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--verify-causal-chain", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require-container-digest", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require-verified-manifest", action=argparse.BooleanOptionalAction, default=True)
    return p.parse_args()


def git_value(args: list[str], cwd: Path) -> str:
    try:
        return subprocess.check_output(["git", *args], cwd=cwd, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return ""


def subject_rows(manifest: pd.DataFrame) -> list[dict[str, object]]:
    rows = []
    for _, row in manifest.iterrows():
        if str(row.get("present", "")).strip().lower() not in {"true", "1", "yes", "y"}:
            continue
        sha = str(row.get("sha256", "")).strip()
        if not sha:
            continue
        rows.append(
            {
                "name": str(row.get("relative_path", "")).strip(),
                "digest": {"sha256": sha},
                "role": str(row.get("role", "")).strip(),
                "pathBase": str(row.get("path_base", "")).strip(),
            }
        )
    return rows


def boolish(value: object) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "y"}


def require_manifest_verification(manifest_path: Path, verification_path: Path) -> str:
    if not verification_path.is_file():
        raise SystemExit(f"Release-manifest verification does not exist: {verification_path}")
    verification = pd.read_csv(verification_path, dtype=str).fillna("")
    required = {"passed", "verified_manifest_sha256"}
    missing = required - set(verification.columns)
    if missing:
        raise SystemExit(f"Release-manifest verification missing columns: {', '.join(sorted(missing))}")
    if verification.empty or not verification["passed"].map(boolish).all():
        raise SystemExit("Release-manifest verification is empty or contains failing rows.")
    _, manifest_sha256 = compute_file_metadata(manifest_path)
    recorded = {value.strip() for value in verification["verified_manifest_sha256"] if value.strip()}
    if recorded != {manifest_sha256}:
        raise SystemExit("Release-manifest verification is not bound to the exact manifest bytes.")
    return manifest_sha256


def main() -> int:
    args = parse_args()
    root = Path(args.root).expanduser()
    repo = Path(args.repo_root).expanduser()
    layout = data_layout(root)
    manifest_path = Path(args.manifest).expanduser() if args.manifest else layout.checks / "v2" / "release_manifest" / "release_manifest.csv"
    verification_path = (
        Path(args.verification).expanduser()
        if args.verification
        else manifest_path.parent / "release_manifest_verification.csv"
    )
    out_path = Path(args.out).expanduser() if args.out else layout.checks / "v2" / "release_metadata" / "build_provenance.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    git_dirty = bool(git_value(["status", "--porcelain", "--untracked-files=all"], repo))
    if args.require_clean_git and git_dirty:
        raise SystemExit("Build provenance requires a clean Git tree.")
    manifest_sha256 = ""
    if args.require_verified_manifest:
        manifest_sha256 = require_manifest_verification(manifest_path, verification_path)
    else:
        _, manifest_sha256 = compute_file_metadata(manifest_path)
    causal_manifest: Path | None = None
    if args.verify_causal_chain:
        try:
            verify_run(
                root=root,
                repo=repo,
                require_clean=bool(args.require_clean_git),
                require_container_digest=bool(args.require_container_digest),
            )
            causal_manifest = resolve_run_dir(root) / "run_manifest.json"
        except ProvenanceError as exc:
            raise SystemExit(str(exc)) from exc

    manifest = pd.read_csv(manifest_path, dtype=str).fillna("")
    now = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    provenance = {
        "_type": "https://in-toto.io/Statement/v1",
        "predicateType": "https://slsa.dev/provenance/v1",
        "subject": subject_rows(manifest),
        "predicate": {
            "buildDefinition": {
                "buildType": args.build_type,
                "externalParameters": {
                    "root": str(root),
                    "manifest": str(manifest_path),
                    "repository": "https://github.com/markjayson13/IPEDSDB_Panel",
                    "gitCommit": git_value(["rev-parse", "HEAD"], repo),
                    "gitBranch": git_value(["branch", "--show-current"], repo),
                    "gitDirty": git_dirty,
                    "causalStageManifest": str(causal_manifest or ""),
                    "releaseManifestSha256": manifest_sha256,
                },
                "internalParameters": tool_versions(),
                "resolvedDependencies": [
                    {
                        "uri": "git+https://github.com/markjayson13/IPEDSDB_Panel",
                        "digest": {"gitCommit": git_value(["rev-parse", "HEAD"], repo)},
                    },
                    *(
                        [
                            {
                                "uri": str(causal_manifest),
                                "digest": {"sha256": sha256_file(causal_manifest)},
                            }
                        ]
                        if causal_manifest is not None
                        else []
                    ),
                ],
            },
            "runDetails": {
                "builder": {
                    "id": "local:Scripts/QA_QC/17_build_provenance.py",
                    "version": {"script": "1"},
                },
                "metadata": {
                    "invocationId": now,
                    "startedOn": now,
                    "finishedOn": now,
                },
                "byproducts": [
                    {"name": "release_manifest.csv", "uri": str(manifest_path)},
                    {"name": "release_manifest_verification.csv", "uri": str(verification_path)},
                    *(
                        [{"name": "causal_stage_run_manifest.json", "uri": str(causal_manifest)}]
                        if causal_manifest is not None
                        else []
                    ),
                ],
            },
        },
    }
    atomic_write_json(out_path, provenance)
    print(f"Wrote build provenance to {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
