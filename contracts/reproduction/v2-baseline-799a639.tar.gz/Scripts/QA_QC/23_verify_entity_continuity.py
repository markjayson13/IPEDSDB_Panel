#!/usr/bin/env python3
"""Independently verify the v2 entity-continuity bundle and its release bindings."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import numbers
import os
import platform
import re
import sys
import tomllib
import unicodedata
from pathlib import Path
from typing import Mapping

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import DEFAULT_IPEDSDB_ROOT, atomic_write_json, repo_root  # noqa: E402
from stage_provenance import (  # noqa: E402
    ProvenanceError,
    current_contract_hashes,
    git_state,
    resolve_run_dir,
    tool_versions,
    verify_run,
)


SCHEMA_VERSION = "entity-continuity-v2.1"
REQUIRED_CAUSAL_STAGES = (
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "qa00",
    "qa01",
)
BUILDER_PATH = "Scripts/QA_QC/22_build_entity_continuity_crosswalk.py"
CANONICAL_CONTINUITY_CROSSWALK = (
    "Checks/v2/entity_continuity/entity_continuity_crosswalk.csv"
)
CANONICAL_CONTINUITY_MANIFEST = (
    "Checks/v2/entity_continuity/entity_continuity_manifest.json"
)
CANONICAL_CONTINUITY_VALUE_LINEAGE = (
    "Checks/v2/entity_continuity/entity_continuity_value_lineage.parquet"
)
CANONICAL_CONTINUITY_VERIFICATION = (
    "Checks/v2/entity_continuity_verification/entity_continuity_verification.json"
)
NORMALIZED_PLACEHOLDERS = {
    "missing",
    "na",
    "none",
    "notapplicable",
    "notavailable",
    "notreported",
    "null",
    "unk",
    "unknown",
    "unavailable",
    "unreported",
}
BUNDLE_FILES = {
    "entity_continuity_crosswalk.csv",
    "entity_continuity_manifest.json",
    "entity_continuity_summary.csv",
    "entity_continuity_summary.md",
    "entity_continuity_value_lineage.parquet",
}
CROSSWALK_COLUMNS = [
    "UNITID",
    "first_year",
    "last_year",
    "years_observed_count",
    "years_observed",
    "has_internal_gap",
    "internal_gap_count",
    "internal_gap_years",
    "institution_name_change_count",
    "institution_name_history",
    "opeid_change_count",
    "opeid_history",
    "opeid_count",
    "opeid_values",
    "opeid6_count",
    "opeid6_values",
    "parent_child_change_count",
    "parent_child_history",
    "prch_review_values",
    "sector_change_count",
    "sector_history",
    "control_change_count",
    "control_history",
    "level_change_count",
    "level_history",
    "potential_predecessor_unitids",
    "potential_predecessor_evidence",
    "potential_successor_unitids",
    "potential_successor_evidence",
    "candidate_link_status",
    "join_risk_flags",
    "join_risk_level",
    "evidence_sufficiency",
    "insufficient_evidence_reasons",
    "release_eligible",
    "invalid_opeid_tokens",
    "institution_name_source_column",
    "opeid_source_columns",
    "parent_child_source_columns",
    "sector_source_column",
    "control_source_column",
    "level_source_column",
    "candidate_link_source_columns",
    "evidence_source_columns",
    "evidence_variable_ids",
    "evidence_source_files",
    "evidence_access_tables",
    "value_lineage_rows",
]
REQUIRED_CODE_HASHES = {
    BUILDER_PATH,
    "Scripts/access_build_utils.py",
    "Scripts/stage_provenance.py",
}
EVIDENCE_KEYS = {
    "institution_name",
    "full_opeid",
    "opeid6",
    "parent_child",
    "sector",
    "control",
    "level",
}
PARENT_CHILD_EXPLICIT_COLUMNS = {
    "PARENT_UNITID",
    "PARENTUNITID",
    "PARENT_UNIT_ID",
    "PARENTID",
    "PARENT_OPEID",
    "PARENTOPEID",
    "SYSTEM_ID",
    "SYSTEMID",
    "F1SYSCOD",
    "F1SYSNAM",
}
EXPECTED_CANDIDATE_RATIONALE = (
    "unique full OPEID ownership at adjacent non-overlapping UNITID spans with "
    "independent corroboration"
)
RISK_FLAG_ORDER = [
    "potential_identity_link",
    "internal_year_gap",
    "single_year_observation",
    "missing_institution_name",
    "institution_name_change",
    "multi_opeid",
    "multi_opeid6",
    "opeid_change",
    "parent_child_flag_observed",
    "parent_child_change",
    "sector_change",
    "control_change",
    "level_change",
    "invalid_opeid_evidence",
    "insufficient_evidence",
]
REQUIRED_LINEAGE_COLUMNS = {
    "contract_id",
    "UNITID",
    "year",
    "analysis_column",
    "variable_id",
    "source_varnumber",
    "varname",
    "source_row_id",
    "source_row_hash",
    "source_file",
    "access_table_name",
    "transformation_id",
    "normalized_value",
    "lineage_role",
}


def reviewed_release_layout(repo: Path) -> dict[str, object]:
    contract_path = repo / "contracts" / "panel_spec.toml"
    try:
        contract = tomllib.loads(contract_path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ValueError(f"cannot read reviewed release contract: {exc}") from exc
    release = contract.get("release", {})
    dataset = contract.get("dataset", {})
    outputs = contract.get("outputs", {})
    artifacts = contract.get("artifacts", {})
    qa = contract.get("qa", {})
    try:
        start_year = int(release["start_year"])
        end_year = int(release["end_year"])
        panel_path = str(outputs["prch_cleaned"])
        lineage_path = str(outputs["column_lineage"])
        continuity_path = str(qa["entity_continuity"])
        continuity_manifest_path = str(qa["entity_continuity_manifest"])
        continuity_value_lineage_path = str(qa["entity_continuity_value_lineage"])
        continuity_verification_path = str(qa["entity_continuity_verification"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("reviewed contract lacks continuity release scope or paths") from exc
    if start_year < 1 or end_year < start_year:
        raise ValueError("reviewed contract has an invalid release year interval")
    if release.get("default_year_spec") != f"{start_year}:{end_year}":
        raise ValueError("reviewed contract default year specification is inconsistent")
    artifact_prch = artifacts.get("prch_cleaned", {}) if isinstance(artifacts, dict) else {}
    artifact_lineage = artifacts.get("lineage", {}) if isinstance(artifacts, dict) else {}
    canonical_paths = {
        panel_path,
        str(dataset.get("canonical_output", "")),
        str(artifact_prch.get("path", "")) if isinstance(artifact_prch, dict) else "",
    }
    if canonical_paths != {panel_path}:
        raise ValueError("reviewed contract disagrees on the canonical clean panel")
    if (
        not isinstance(artifact_lineage, dict)
        or str(artifact_lineage.get("path", "")) != lineage_path
    ):
        raise ValueError("reviewed contract disagrees on canonical Stage 06 lineage")
    if continuity_path != CANONICAL_CONTINUITY_CROSSWALK:
        raise ValueError("reviewed contract has an invalid continuity QA path")
    expected_continuity_paths = {
        "crosswalk": CANONICAL_CONTINUITY_CROSSWALK,
        "manifest": CANONICAL_CONTINUITY_MANIFEST,
        "value_lineage": CANONICAL_CONTINUITY_VALUE_LINEAGE,
        "verification": CANONICAL_CONTINUITY_VERIFICATION,
    }
    observed_continuity_paths = {
        "crosswalk": continuity_path,
        "manifest": continuity_manifest_path,
        "value_lineage": continuity_value_lineage_path,
        "verification": continuity_verification_path,
    }
    if observed_continuity_paths != expected_continuity_paths:
        raise ValueError("reviewed contract has invalid continuity evidence paths")
    for relative in (panel_path, lineage_path, *observed_continuity_paths.values()):
        path = Path(relative)
        if path.is_absolute() or ".." in path.parts:
            raise ValueError("reviewed contract contains a nonportable continuity path")
    return {
        "continuity_output": Path(continuity_path).parent.as_posix(),
        "continuity_manifest": continuity_manifest_path,
        "continuity_value_lineage": continuity_value_lineage_path,
        "continuity_verification": continuity_verification_path,
        "lineage_input": lineage_path,
        "panel_input": panel_path,
        "years": list(range(start_year, end_year + 1)),
    }


def parse_args() -> argparse.Namespace:
    root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(root))
    parser.add_argument("--repo", default=None)
    parser.add_argument("--bundle", default=None)
    parser.add_argument("--panel", default=None, help="Development-only override for external fixture input")
    parser.add_argument("--value-lineage", default=None, help="Development-only lineage input override")
    parser.add_argument("--mode", choices=("development", "release"), default="release")
    parser.add_argument("--report", default=None)
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_json(value: object) -> str:
    payload = json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    output: dict[str, object] = {}
    for key, value in pairs:
        if key in output:
            raise ValueError(f"duplicate JSON key {key!r}")
        output[key] = value
    return output


def load_manifest(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=reject_duplicate_keys)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"cannot read manifest {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ValueError("continuity manifest must contain a JSON object")
    return value


def parquet_schema_hash(path: Path) -> str:
    parquet_file = pq.ParquetFile(path)
    return sha256_json(
        [
            {"name": field.name, "nullable": bool(field.nullable), "physical_type": str(field.type)}
            for field in parquet_file.schema_arrow
        ]
    )


def frame_schema_hash(columns: list[tuple[str, str]]) -> str:
    return sha256_json([{"name": name, "logical_type": kind} for name, kind in columns])


def crosswalk_schema_hash() -> str:
    schema: list[tuple[str, str]] = []
    for column in CROSSWALK_COLUMNS:
        if column in {"has_internal_gap", "release_eligible"}:
            kind = "boolean"
        elif column in {"UNITID", "first_year", "last_year", "value_lineage_rows"} or column.endswith(
            "_count"
        ):
            kind = "integer"
        else:
            kind = "string"
        schema.append((column, kind))
    return frame_schema_hash(schema)


def csv_shape(path: Path) -> tuple[int, list[str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, strict=True)
        header = next(reader, [])
        rows = sum(1 for _ in reader)
    return rows, header


def portable_tools(raw: Mapping[str, object]) -> dict[str, object]:
    raw_system = raw.get("system_tools", {})
    system: dict[str, object] = {}
    if isinstance(raw_system, dict):
        for name, binding in sorted(raw_system.items()):
            record = binding if isinstance(binding, dict) else {}
            system[str(name)] = {
                "executable": Path(str(record.get("path", ""))).name if record.get("path") else "",
                "sha256": str(record.get("sha256", "")),
                "version": str(record.get("version", "")),
            }
    return {
        "container_image_digest": str(raw.get("container_image_digest", "")),
        "implementation": str(raw.get("implementation", "")),
        "packages": dict(raw.get("packages", {})) if isinstance(raw.get("packages"), dict) else {},
        "platform": str(raw.get("platform", "")),
        "python": str(raw.get("python", "")),
        "system_tools": system,
    }


def safe_root_path(root: Path, relative: object, failures: list[str], label: str) -> Path | None:
    raw = str(relative or "")
    candidate = Path(raw)
    if not raw or candidate.is_absolute() or ".." in candidate.parts:
        failures.append(f"{label} is not a safe root-relative path: {raw!r}")
        return None
    lexical = (root / candidate).absolute()
    resolved = lexical.resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError:
        failures.append(f"{label} escapes the data root: {raw!r}")
        return None
    return lexical


def bool_series(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def canonical_scalar(value: object) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            return ""
        if value.is_integer():
            return str(int(value))
        return format(value, ".15g")
    text = str(value).strip()
    if text.lower() in {"", "<na>", "na", "nan", "nat", "none", "null"}:
        return ""
    return " ".join(text.split())


def normalize_full_opeid_with_status(value: object) -> tuple[str, str]:
    compact = re.sub(r"[\s-]+", "", canonical_scalar(value))
    if not compact:
        return "", "missing"
    if not re.fullmatch(r"[0-9]{1,8}", compact):
        return "", "invalid"
    normalized = compact.zfill(8)
    if normalized in {"00000000", "99999999"} or normalized[:6] in {"000000", "999999"}:
        return "", "sentinel"
    return normalized, "valid"


def normalize_full_opeid(value: object) -> str:
    normalized, status = normalize_full_opeid_with_status(value)
    return normalized if status == "valid" else ""


def normalize_opeid6_with_status(value: object) -> tuple[str, str]:
    compact = re.sub(r"[\s-]+", "", canonical_scalar(value))
    if not compact:
        return "", "missing"
    if not re.fullmatch(r"[0-9]{1,6}", compact):
        return "", "invalid"
    normalized = compact.zfill(6)
    if normalized in {"000000", "999999"}:
        return "", "sentinel"
    return normalized, "valid"


def normalize_name(value: object) -> str:
    text = unicodedata.normalize("NFKD", canonical_scalar(value).casefold())
    normalized = "".join(character for character in text if character.isalnum())
    if normalized in NORMALIZED_PLACEHOLDERS or set(normalized) in ({"0"}, {"9"}):
        return ""
    return normalized


def valid_relationship_token(value: object) -> bool:
    text = canonical_scalar(value)
    normalized = unicodedata.normalize("NFKD", text)
    compact = "".join(character for character in normalized if character.isalnum()).upper()
    if compact in {
        "",
        "NA",
        "NONE",
        "NULL",
        "UNK",
        "UNKNOWN",
        "MISSING",
        "NOTAPPLICABLE",
        "NOTAVAILABLE",
        "NOTREPORTED",
        "UNAVAILABLE",
        "UNREPORTED",
    }:
        return False
    if any(character.isdigit() and character not in "0123456789" for character in text):
        return False
    if set(compact) in ({"0"}, {"9"}):
        return False
    numeric_match = re.fullmatch(r"[+-]?([0-9]+)(?:\.0+)?", text)
    if numeric_match:
        if text.startswith("-"):
            return False
        digits = numeric_match.group(1)
        number = int(digits)
        return number > 0 and set(digits) != {"9"}
    return any(character != "0" for character in compact)


def normalize_relationship_identifier(column: str, value: object) -> str:
    text = canonical_scalar(value)
    upper = column.upper()
    if upper in {"PARENT_OPEID", "PARENTOPEID"}:
        return normalize_full_opeid(text)
    if upper in {"PARENT_UNITID", "PARENTUNITID", "PARENT_UNIT_ID", "PARENTID"}:
        if not re.fullmatch(r"[+-]?[0-9]+", text):
            return ""
        signed = text.lstrip("+-")
        number = int(text)
        return str(number) if number > 0 and set(signed) != {"9"} else ""
    return text if valid_relationship_token(text) else ""


def has_parent_child_evidence(row: pd.Series, columns: list[str]) -> bool:
    for column in columns:
        value = canonical_scalar(row[column])
        if not value:
            continue
        if column.upper().startswith("PRCH") or normalize_relationship_identifier(column, value):
            return True
    return False


def exact_sorted_frame(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    return frame[columns].sort_values(columns, kind="stable", na_position="first").reset_index(
        drop=True
    )


def safe_integer(
    value: object,
    *,
    label: str,
    failures: list[str],
    minimum: int | None = None,
    allow_integral_float: bool = False,
    canonical_text: bool = False,
    require_json_integer: bool = False,
) -> int | None:
    if isinstance(value, bool):
        failures.append(f"{label} is not an integer: {value!r}")
        return None
    if require_json_integer:
        if not isinstance(value, numbers.Integral):
            failures.append(f"{label} is not a JSON integer: {value!r}")
            return None
        parsed = int(value)
    elif canonical_text:
        text = str(value)
        if not re.fullmatch(r"0|[1-9][0-9]*", text):
            failures.append(f"{label} is not a canonical decimal integer: {value!r}")
            return None
        parsed = int(text)
    elif isinstance(value, numbers.Integral):
        parsed = int(value)
    elif isinstance(value, numbers.Real):
        numeric = float(value)
        if not allow_integral_float or not math.isfinite(numeric) or not numeric.is_integer():
            failures.append(f"{label} is not an integer: {value!r}")
            return None
        parsed = int(numeric)
    else:
        text = str(value).strip()
        if not re.fullmatch(r"[+-]?[0-9]+", text):
            failures.append(f"{label} is not an integer: {value!r}")
            return None
        parsed = int(text)
    if minimum is not None and parsed < minimum:
        failures.append(f"{label} is below {minimum}: {parsed}")
        return None
    return parsed


def strict_boolean(value: object, *, label: str, failures: list[str]) -> bool | None:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text == "true":
        return True
    if text == "false":
        return False
    failures.append(f"{label} is not a canonical boolean: {value!r}")
    return None


def json_list(value: object, *, label: str, failures: list[str]) -> list[object] | None:
    try:
        parsed = json.loads(str(value), object_pairs_hook=reject_duplicate_keys)
    except (json.JSONDecodeError, TypeError, ValueError):
        failures.append(f"{label} is not valid JSON")
        return None
    if not isinstance(parsed, list):
        failures.append(f"{label} is not a JSON list")
        return None
    return parsed


def split_pipe(value: object) -> list[str]:
    return [item for item in str(value).split("|") if item]


def derive_evidence_mapping(panel_columns: list[str], failures: list[str]) -> dict[str, object]:
    index: dict[str, list[str]] = {}
    for column in panel_columns:
        index.setdefault(column.upper(), []).append(column)
    collisions = {key: values for key, values in index.items() if len(values) > 1}
    if collisions:
        failures.append(f"panel has case-insensitive evidence-column collisions: {collisions}")

    def first(candidates: tuple[str, ...]) -> str:
        for candidate in candidates:
            values = index.get(candidate, [])
            if values:
                return values[0]
        return ""

    opeid_columns = sorted(
        [
            values[0]
            for candidate in ("OPEID", "OPEIDB", "OPEID6", "OPEID_6")
            if (values := index.get(candidate, []))
        ],
        key=str.upper,
    )
    parent_columns = sorted(
        [
            column
            for column in panel_columns
            if column.upper().startswith("PRCH")
            or column.upper() in PARENT_CHILD_EXPLICIT_COLUMNS
        ],
        key=str.upper,
    )
    return {
        "institution_name": first(("INSTNM", "INSTITUTION_NAME")),
        "full_opeid": [
            column for column in opeid_columns if column.upper() in {"OPEID", "OPEIDB"}
        ],
        "opeid6": [
            column for column in opeid_columns if column.upper() in {"OPEID6", "OPEID_6"}
        ],
        "parent_child": parent_columns,
        "sector": first(("SECTOR",)),
        "control": first(("CONTROL",)),
        "level": first(("ICLEVEL", "INSTLEVEL", "LEVEL")),
    }


def validate_evidence_mapping(
    raw_mapping: object,
    *,
    panel_columns: list[str],
    release: bool,
    failures: list[str],
) -> dict[str, object]:
    mapping: dict[str, object] = {
        "institution_name": "",
        "full_opeid": [],
        "opeid6": [],
        "parent_child": [],
        "sector": "",
        "control": "",
        "level": "",
    }
    if not isinstance(raw_mapping, dict):
        failures.append("manifest evidence_columns is malformed")
        return mapping
    if set(raw_mapping) != EVIDENCE_KEYS:
        failures.append("manifest evidence-column group inventory is not exact")

    for key in ("institution_name", "sector", "control", "level"):
        value = raw_mapping.get(key, "")
        if not isinstance(value, str):
            failures.append(f"manifest evidence column {key} must be a string")
            continue
        mapping[key] = value
    for key in ("full_opeid", "opeid6", "parent_child"):
        values = raw_mapping.get(key, [])
        if not isinstance(values, list) or any(
            not isinstance(value, str) or not value for value in values
        ):
            failures.append(f"manifest evidence column group {key} must be a nonblank string list")
            continue
        if len(values) != len(set(values)):
            failures.append(f"manifest evidence column group {key} contains duplicates")
        mapping[key] = list(values)

    allowed_aliases = {
        "institution_name": {"INSTNM", "INSTITUTION_NAME"},
        "full_opeid": {"OPEID", "OPEIDB"},
        "opeid6": {"OPEID6", "OPEID_6"},
        "sector": {"SECTOR"},
        "control": {"CONTROL"},
        "level": {"ICLEVEL", "INSTLEVEL", "LEVEL"},
    }
    for key, aliases in allowed_aliases.items():
        raw_values = mapping[key] if isinstance(mapping[key], list) else [mapping[key]]
        for column in (str(value) for value in raw_values if str(value)):
            if column.upper() not in aliases:
                failures.append(f"manifest maps unsupported {key} evidence column: {column}")
    for column in mapping["parent_child"] if isinstance(mapping["parent_child"], list) else []:
        if not (column.upper().startswith("PRCH") or column.upper() in PARENT_CHILD_EXPLICIT_COLUMNS):
            failures.append(f"manifest maps unsupported parent_child evidence column: {column}")

    mapped_columns: list[str] = []
    for value in mapping.values():
        if isinstance(value, list):
            mapped_columns.extend(str(item) for item in value)
        elif value:
            mapped_columns.append(str(value))
    missing = sorted(set(mapped_columns) - set(panel_columns), key=str.upper)
    if missing:
        failures.append(f"manifest evidence columns are absent from the panel: {missing}")
    if len(mapped_columns) != len(set(mapped_columns)):
        failures.append("manifest maps one panel column into multiple evidence groups")
    derived_mapping = derive_evidence_mapping(panel_columns, failures)
    if mapping != derived_mapping:
        failures.append("manifest evidence mapping differs from the panel-derived mapping")
    if release:
        missing_groups = sorted(
            key
            for key in ("institution_name", "full_opeid", "parent_child", "sector", "control", "level")
            if not derived_mapping[key]
        )
        if missing_groups:
            failures.append(f"release evidence mapping omits required groups: {missing_groups}")
    return derived_mapping


def compact_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def simple_change_count(history: list[dict[str, object]]) -> int:
    changes = 0
    previous = ""
    for entry in history:
        value = str(entry.get("value", ""))
        if previous and value and value != previous:
            changes += 1
        if value:
            previous = value
    return changes


def mapping_change_count(history: list[dict[str, object]]) -> int:
    changes = 0
    previous: dict[str, str] | None = None
    for entry in history:
        raw_values = entry.get("values", {})
        values = dict(raw_values) if isinstance(raw_values, dict) else {}
        if not values:
            continue
        if previous is not None and values != previous:
            changes += 1
        previous = values
    return changes


def semantic_history_expectations(
    group: pd.DataFrame,
    *,
    mapping: Mapping[str, object],
) -> tuple[dict[str, object], set[str]]:
    name_column = str(mapping.get("institution_name", ""))
    full_columns = [str(value) for value in mapping.get("full_opeid", [])]
    opeid6_columns = [str(value) for value in mapping.get("opeid6", [])]
    parent_columns = [str(value) for value in mapping.get("parent_child", [])]
    scalar_columns = {
        "sector": str(mapping.get("sector", "")),
        "control": str(mapping.get("control", "")),
        "level": str(mapping.get("level", "")),
    }

    name_history = (
        [
            {"year": int(row["year"]), "value": canonical_scalar(row[name_column])}
            for _, row in group.iterrows()
        ]
        if name_column
        else []
    )
    opeid_history: list[dict[str, object]] = []
    full_values: set[str] = set()
    opeid6_values: set[str] = set()
    invalid_tokens: set[str] = set()
    raw_full_values: set[str] = set()
    if full_columns or opeid6_columns:
        for _, row in group.iterrows():
            normalized_full: set[str] = set()
            normalized_opeid6: set[str] = set()
            sources: dict[str, str] = {}
            for column in full_columns:
                raw = canonical_scalar(row[column])
                normalized, status = normalize_full_opeid_with_status(raw)
                if raw:
                    sources[column] = raw
                    raw_full_values.add(raw)
                if status == "valid":
                    normalized_full.add(normalized)
                    full_values.add(normalized)
                elif status in {"invalid", "sentinel"}:
                    invalid_tokens.add(f"{column}:{raw}:{status}")
            for column in opeid6_columns:
                raw = canonical_scalar(row[column])
                normalized, status = normalize_opeid6_with_status(raw)
                if raw:
                    sources[column] = raw
                if status == "valid":
                    normalized_opeid6.add(normalized)
                    opeid6_values.add(normalized)
                elif status in {"invalid", "sentinel"}:
                    invalid_tokens.add(f"{column}:{raw}:{status}")
            opeid_history.append(
                {
                    "normalized_full_opeids": sorted(normalized_full),
                    "normalized_opeid6_values": sorted(normalized_opeid6),
                    "source_values": sources,
                    "year": int(row["year"]),
                }
            )

    opeid_changes = 0
    previous_opeids: tuple[str, ...] | None = None
    for entry in opeid_history:
        values = tuple(str(value) for value in entry["normalized_full_opeids"])
        if not values:
            continue
        if previous_opeids is not None and values != previous_opeids:
            opeid_changes += 1
        previous_opeids = values

    parent_history: list[dict[str, object]] = []
    if parent_columns:
        for _, row in group.iterrows():
            values = {
                column: canonical_scalar(row[column])
                for column in parent_columns
                if canonical_scalar(row[column])
            }
            parent_history.append({"year": int(row["year"]), "values": values})
    parent_values = {
        column: sorted(
            {
                canonical_scalar(value)
                for value in group[column]
                if canonical_scalar(value)
            }
        )
        for column in parent_columns
    }
    prch_hits = [
        f"{column}:{'|'.join(values)}"
        for column, values in parent_values.items()
        if column.upper().startswith("PRCH") and any(value not in {"0", "1"} for value in values)
    ]

    scalar_histories = {
        label: (
            [
                {"year": int(row["year"]), "value": canonical_scalar(row[column])}
                for _, row in group.iterrows()
            ]
            if column
            else []
        )
        for label, column in scalar_columns.items()
    }
    name_changes = simple_change_count(name_history)
    parent_changes = mapping_change_count(parent_history)
    scalar_changes = {
        label: simple_change_count(history) for label, history in scalar_histories.items()
    }
    expectations: dict[str, object] = {
        "institution_name_change_count": name_changes,
        "institution_name_history": compact_json(name_history),
        "opeid_change_count": opeid_changes,
        "opeid_history": compact_json(opeid_history),
        "opeid_count": len(full_values),
        "opeid_values": "|".join(sorted(full_values)),
        "opeid6_count": len(opeid6_values),
        "opeid6_values": "|".join(sorted(opeid6_values)),
        "parent_child_change_count": parent_changes,
        "parent_child_history": compact_json(parent_history),
        "prch_review_values": ";".join(prch_hits),
        "sector_change_count": scalar_changes["sector"],
        "sector_history": compact_json(scalar_histories["sector"]),
        "control_change_count": scalar_changes["control"],
        "control_history": compact_json(scalar_histories["control"]),
        "level_change_count": scalar_changes["level"],
        "level_history": compact_json(scalar_histories["level"]),
        "invalid_opeid_tokens": "|".join(sorted(invalid_tokens)),
    }
    flags: set[str] = set()
    if name_column and any(not normalize_name(entry.get("value", "")) for entry in name_history):
        flags.add("missing_institution_name")
    if name_changes:
        flags.add("institution_name_change")
    if len(full_values) > 1 or (not full_values and len(raw_full_values) > 1):
        flags.add("multi_opeid")
    if len(opeid6_values) > 1:
        flags.add("multi_opeid6")
    if opeid_changes:
        flags.add("opeid_change")
    if prch_hits:
        flags.add("parent_child_flag_observed")
    if parent_changes:
        flags.add("parent_child_change")
    for label in ("sector", "control", "level"):
        if scalar_changes[label]:
            flags.add(f"{label}_change")
    if invalid_tokens:
        flags.add("invalid_opeid_evidence")
    return expectations, flags


def verify_panel_crosswalk(
    panel: pd.DataFrame,
    crosswalk: pd.DataFrame,
    *,
    mapping: Mapping[str, object],
    requested_years: list[int],
    release: bool,
    failures: list[str],
) -> pd.DataFrame | None:
    if "UNITID" not in panel or "year" not in panel:
        failures.append("continuity input must contain exact UNITID and year columns")
        return None
    normalized = panel.copy()
    unitids = [
        safe_integer(
            value,
            label=f"panel UNITID row {index + 1}",
            failures=failures,
            minimum=1,
            allow_integral_float=True,
        )
        for index, value in enumerate(normalized["UNITID"])
    ]
    years = [
        safe_integer(
            value,
            label=f"panel year row {index + 1}",
            failures=failures,
            minimum=1,
            allow_integral_float=True,
        )
        for index, value in enumerate(normalized["year"])
    ]
    if any(value is None for value in unitids) or any(value is None for value in years):
        return None
    normalized["UNITID"] = [int(value) for value in unitids]
    normalized["year"] = [int(value) for value in years]
    if normalized.duplicated(["UNITID", "year"]).any():
        failures.append("continuity input is not unique on UNITID-year")
        return normalized

    observed_years = sorted(normalized["year"].unique().tolist())
    outside = sorted(set(observed_years) - set(requested_years))
    missing_years = sorted(set(requested_years) - set(observed_years))
    if outside:
        failures.append(f"continuity input contains years outside requested scope: {outside}")
    if release and missing_years:
        failures.append(f"release continuity input is missing requested years: {missing_years}")

    crosswalk_ids = [
        safe_integer(
            value,
            label=f"crosswalk UNITID row {index + 1}",
            failures=failures,
            minimum=1,
            canonical_text=True,
        )
        for index, value in enumerate(crosswalk["UNITID"])
    ]
    if any(value is None for value in crosswalk_ids):
        return None
    if set(int(value) for value in crosswalk_ids) != set(normalized["UNITID"]):
        failures.append("continuity crosswalk UNITID inventory differs from the input panel")

    full_columns = [str(value) for value in mapping.get("full_opeid", [])]
    parent_columns = [str(value) for value in mapping.get("parent_child", [])]
    name_column = str(mapping.get("institution_name", ""))
    scalar_columns = {
        "sector": str(mapping.get("sector", "")),
        "control": str(mapping.get("control", "")),
        "level": str(mapping.get("level", "")),
    }
    evidence_failures: dict[int, set[str]] = {
        int(unitid): set() for unitid in normalized["UNITID"].unique()
    }
    for _, panel_row in normalized.iterrows():
        unitid = int(panel_row["UNITID"])
        year = int(panel_row["year"])
        if name_column and not normalize_name(panel_row[name_column]):
            evidence_failures[unitid].add(f"missing institution name in {year}")
        valid_full = {
            normalize_full_opeid(panel_row[column])
            for column in full_columns
            if normalize_full_opeid(panel_row[column])
        }
        invalid_full = [
            column
            for column in full_columns
            if canonical_scalar(panel_row[column]) and not normalize_full_opeid(panel_row[column])
        ]
        if full_columns and len(valid_full) != 1:
            evidence_failures[unitid].add(f"missing or ambiguous full OPEID in {year}")
        if invalid_full:
            evidence_failures[unitid].add(f"invalid or sentinel full OPEID in {year}")
        if parent_columns and not has_parent_child_evidence(panel_row, parent_columns):
            evidence_failures[unitid].add(f"missing parent-child evidence in {year}")
        for label, column in scalar_columns.items():
            if column and not canonical_scalar(panel_row[column]):
                evidence_failures[unitid].add(f"missing {label} evidence in {year}")

    mapped_columns: list[str] = []
    for value in mapping.values():
        if isinstance(value, list):
            mapped_columns.extend(str(item) for item in value)
        elif value:
            mapped_columns.append(str(value))
    expected_sources = "|".join(sorted({"UNITID", "year", *mapped_columns}, key=str.upper))
    expected_fields = {
        "institution_name_source_column": name_column,
        "opeid_source_columns": "|".join(
            [*full_columns, *[str(value) for value in mapping.get("opeid6", [])]]
        ),
        "parent_child_source_columns": "|".join(parent_columns),
        "sector_source_column": scalar_columns["sector"],
        "control_source_column": scalar_columns["control"],
        "level_source_column": scalar_columns["level"],
        "evidence_source_columns": expected_sources,
    }

    crosswalk_by_unit = crosswalk.assign(_UNITID=[int(value) for value in crosswalk_ids]).set_index(
        "_UNITID", drop=False
    )
    for unitid, group in normalized.groupby("UNITID", sort=True):
        if int(unitid) not in crosswalk_by_unit.index:
            continue
        row = crosswalk_by_unit.loc[int(unitid)]
        if isinstance(row, pd.DataFrame):
            failures.append(f"continuity crosswalk repeats UNITID {unitid}")
            continue
        group = group.sort_values("year", kind="stable")
        unit_years = group["year"].tolist()
        expected_gaps = [
            year
            for year in requested_years
            if unit_years[0] < year < unit_years[-1] and year not in set(unit_years)
        ]
        numeric_expectations = {
            "first_year": unit_years[0],
            "last_year": unit_years[-1],
            "years_observed_count": len(unit_years),
            "internal_gap_count": len(expected_gaps),
        }
        for field, expected in numeric_expectations.items():
            observed = safe_integer(
                row[field],
                label=f"UNITID {unitid} {field}",
                failures=failures,
                minimum=0,
                canonical_text=True,
            )
            if observed is not None and observed != expected:
                failures.append(f"UNITID {unitid} {field} is stale")
        if str(row["years_observed"]) != "|".join(str(year) for year in unit_years):
            failures.append(f"UNITID {unitid} years_observed is stale")
        if str(row["internal_gap_years"]) != "|".join(str(year) for year in expected_gaps):
            failures.append(f"UNITID {unitid} internal_gap_years is stale")
        observed_gap = strict_boolean(
            row["has_internal_gap"],
            label=f"UNITID {unitid} has_internal_gap",
            failures=failures,
        )
        if observed_gap is not None and observed_gap != bool(expected_gaps):
            failures.append(f"UNITID {unitid} has_internal_gap is stale")
        for field, expected in expected_fields.items():
            if str(row[field]) != expected:
                failures.append(f"UNITID {unitid} {field} is stale")

        semantic_expectations, semantic_flags = semantic_history_expectations(
            group, mapping=mapping
        )
        for field, expected in semantic_expectations.items():
            if field.endswith("_count"):
                observed = safe_integer(
                    row[field],
                    label=f"UNITID {unitid} {field}",
                    failures=failures,
                    minimum=0,
                    canonical_text=True,
                )
                if observed is not None and observed != expected:
                    failures.append(f"UNITID {unitid} {field} is stale")
            elif str(row[field]) != str(expected):
                failures.append(f"UNITID {unitid} {field} is stale")

        sufficiency = str(row["evidence_sufficiency"])
        eligible = strict_boolean(
            row["release_eligible"],
            label=f"UNITID {unitid} release_eligible",
            failures=failures,
        )
        if eligible is not None and eligible != (sufficiency == "complete"):
            failures.append(f"UNITID {unitid} release eligibility contradicts evidence sufficiency")
        if sufficiency == "insufficient" and str(row["join_risk_level"]) == "standard":
            failures.append(f"UNITID {unitid} is standard risk despite insufficient evidence")
        if evidence_failures[int(unitid)]:
            if sufficiency == "complete" or eligible is True:
                failures.append(f"UNITID {unitid} claims complete evidence despite missing values")
            if release:
                failures.append(
                    f"UNITID {unitid} lacks required release evidence: "
                    + "; ".join(sorted(evidence_failures[int(unitid)]))
                )
        if expected_gaps:
            semantic_flags.add("internal_year_gap")
        if len(unit_years) == 1:
            semantic_flags.add("single_year_observation")
        has_candidates = any(
            str(row[field]) != "[]"
            for field in ("potential_predecessor_evidence", "potential_successor_evidence")
        )
        if has_candidates:
            semantic_flags.add("potential_identity_link")
        if sufficiency == "insufficient":
            semantic_flags.add("insufficient_evidence")
        ordered_flags = [flag for flag in RISK_FLAG_ORDER if flag in semantic_flags]
        if str(row["join_risk_flags"]) != "|".join(ordered_flags):
            failures.append(f"UNITID {unitid} join_risk_flags is stale")
        review_flags = semantic_flags - {"insufficient_evidence", "invalid_opeid_evidence"}
        expected_risk = (
            "high"
            if has_candidates
            else "review"
            if review_flags
            else "insufficient"
            if sufficiency == "insufficient"
            else "standard"
        )
        if str(row["join_risk_level"]) != expected_risk:
            failures.append(f"UNITID {unitid} join_risk_level is stale")
    return normalized


def verify_summaries(
    *,
    bundle: Path,
    panel: pd.DataFrame,
    crosswalk: pd.DataFrame,
    mapping: Mapping[str, object],
    requested_years: list[int],
    failures: list[str],
) -> None:
    summary_path = bundle / "entity_continuity_summary.csv"
    markdown_path = bundle / "entity_continuity_summary.md"
    if not summary_path.is_file() or not markdown_path.is_file():
        return

    numeric_columns = [
        "institution_name_change_count",
        "opeid_count",
        "opeid6_count",
        "opeid_change_count",
        "parent_child_change_count",
        "sector_change_count",
        "control_change_count",
        "level_change_count",
    ]
    numeric: dict[str, pd.Series] = {}
    for column in numeric_columns:
        values = pd.to_numeric(crosswalk[column], errors="coerce")
        if values.isna().any():
            failures.append(f"continuity crosswalk {column} is not numeric")
        numeric[column] = values.fillna(0)
    eligible = bool_series(crosswalk["release_eligible"])
    has_gap = bool_series(crosswalk["has_internal_gap"])
    optional_groups = {
        "institution_name": bool(mapping.get("institution_name")),
        "full_opeid": bool(mapping.get("full_opeid")),
        "opeid6_history_only": bool(mapping.get("opeid6")),
        "parent_child": bool(mapping.get("parent_child")),
        "sector": bool(mapping.get("sector")),
        "control": bool(mapping.get("control")),
        "level": bool(mapping.get("level")),
    }
    required_groups = {
        key: present for key, present in optional_groups.items() if key != "opeid6_history_only"
    }
    expected_rows: list[tuple[str, object]] = [
        ("unitids", len(crosswalk)),
        ("input_rows", len(panel)),
        ("requested_years", "|".join(str(year) for year in requested_years)),
        ("observed_years", "|".join(str(year) for year in sorted(panel["year"].unique()))),
        ("high_risk_unitids", int(crosswalk["join_risk_level"].eq("high").sum())),
        ("review_unitids", int(crosswalk["join_risk_level"].eq("review").sum())),
        (
            "insufficient_evidence_unitids",
            int(crosswalk["evidence_sufficiency"].eq("insufficient").sum()),
        ),
        ("release_eligible_unitids", int(eligible.sum())),
        ("standard_unitids", int(crosswalk["join_risk_level"].eq("standard").sum())),
        ("internal_gap_unitids", int(has_gap.sum())),
        (
            "institution_name_change_unitids",
            int(numeric["institution_name_change_count"].gt(0).sum()),
        ),
        ("multi_opeid_unitids", int(numeric["opeid_count"].gt(1).sum())),
        ("multi_opeid6_unitids", int(numeric["opeid6_count"].gt(1).sum())),
        ("opeid_change_unitids", int(numeric["opeid_change_count"].gt(0).sum())),
        (
            "parent_child_flag_unitids",
            int(crosswalk["prch_review_values"].astype(str).ne("").sum()),
        ),
        (
            "parent_child_change_unitids",
            int(numeric["parent_child_change_count"].gt(0).sum()),
        ),
        ("sector_change_unitids", int(numeric["sector_change_count"].gt(0).sum())),
        ("control_change_unitids", int(numeric["control_change_count"].gt(0).sum())),
        ("level_change_unitids", int(numeric["level_change_count"].gt(0).sum())),
        (
            "potential_predecessor_unitids",
            int(crosswalk["potential_predecessor_unitids"].ne("[]").sum()),
        ),
        (
            "potential_successor_unitids",
            int(crosswalk["potential_successor_unitids"].ne("[]").sum()),
        ),
        (
            "missing_optional_evidence_groups",
            "|".join(sorted(key for key, present in optional_groups.items() if not present)),
        ),
        (
            "missing_release_evidence_groups",
            "|".join(sorted(key for key, present in required_groups.items() if not present)),
        ),
    ]
    summary = pd.read_csv(summary_path, keep_default_na=False, dtype=str)
    if summary.columns.tolist() != ["metric", "value"]:
        failures.append("continuity summary columns are not exact")
        return
    observed_rows = list(summary.itertuples(index=False, name=None))
    expected_strings = [(metric, str(value)) for metric, value in expected_rows]
    if observed_rows != expected_strings:
        failures.append("continuity summary values or ordering are stale")

    lines = ["# Entity Continuity Summary", "", "| Metric | Value |", "| --- | --- |"]
    for metric, value in expected_strings:
        escaped_metric = metric.replace("|", "\\|")
        escaped_value = value.replace("|", "\\|")
        lines.append(f"| {escaped_metric} | {escaped_value} |")
    lines.extend(
        [
            "",
            (
                "Potential links are review candidates only. They are not asserted mergers, "
                "closures, or identity equivalences."
            ),
            "",
        ]
    )
    if markdown_path.read_text(encoding="utf-8") != "\n".join(lines):
        failures.append("continuity Markdown summary is stale")


def derive_expected_candidate_records(
    panel: pd.DataFrame,
    mapping: Mapping[str, object],
) -> tuple[dict[int, list[dict[str, object]]], dict[int, list[dict[str, object]]]]:
    full_columns = [str(value) for value in mapping.get("full_opeid", [])]
    name_column = str(mapping.get("institution_name", ""))
    relationship_columns = [
        str(value)
        for value in mapping.get("parent_child", [])
        if not str(value).upper().startswith("PRCH")
    ]
    spans = {
        int(unitid): (int(group["year"].min()), int(group["year"].max()))
        for unitid, group in panel.groupby("UNITID", sort=False)
    }
    predecessors: dict[int, list[dict[str, object]]] = {unitid: [] for unitid in spans}
    successors: dict[int, list[dict[str, object]]] = {unitid: [] for unitid in spans}
    if not full_columns:
        return predecessors, successors
    by_key = {
        (int(row["UNITID"]), int(row["year"])): row for _, row in panel.iterrows()
    }
    occurrences: dict[str, set[tuple[int, int]]] = {}
    row_identifiers: dict[tuple[int, int], set[str]] = {}
    row_invalid: dict[tuple[int, int], bool] = {}
    for _, row in panel.iterrows():
        key = (int(row["UNITID"]), int(row["year"]))
        row_identifiers.setdefault(key, set())
        row_invalid.setdefault(key, False)
        for column in full_columns:
            identifier, status = normalize_full_opeid_with_status(row[column])
            if status == "valid":
                occurrences.setdefault(identifier, set()).add(key)
                row_identifiers[key].add(identifier)
            elif status in {"invalid", "sentinel"}:
                row_invalid[key] = True

    for identifier, occurrence_set in sorted(occurrences.items()):
        owners_by_year: dict[int, set[int]] = {}
        for unitid, year in occurrence_set:
            owners_by_year.setdefault(year, set()).add(unitid)
        for old_unitid in sorted({unitid for unitid, _ in occurrence_set}):
            old_last = spans[old_unitid][1]
            new_first = old_last + 1
            old_owners = owners_by_year.get(old_last, set())
            new_owners = owners_by_year.get(new_first, set())
            if old_owners != {old_unitid} or len(new_owners) != 1:
                continue
            new_unitid = next(iter(new_owners))
            old_key = (old_unitid, old_last)
            new_key = (new_unitid, new_first)
            if (
                new_unitid == old_unitid
                or spans[new_unitid][0] != new_first
                or row_identifiers.get(old_key) != {identifier}
                or row_identifiers.get(new_key) != {identifier}
                or row_invalid.get(old_key, False)
                or row_invalid.get(new_key, False)
            ):
                continue
            old_row = by_key[old_key]
            new_row = by_key[new_key]
            corroboration: list[dict[str, str]] = []
            if name_column:
                old_name = normalize_name(old_row[name_column])
                new_name = normalize_name(new_row[name_column])
                if old_name and old_name == new_name:
                    corroboration.append(
                        {
                            "evidence_source_column": name_column,
                            "kind": "exact_normalized_institution_name",
                            "shared_value": old_name,
                        }
                    )
            for column in relationship_columns:
                old_value = normalize_relationship_identifier(column, old_row[column])
                new_value = normalize_relationship_identifier(column, new_row[column])
                if (
                    old_value
                    and old_value == new_value
                    and not (
                        column.upper() in {"PARENT_OPEID", "PARENTOPEID"}
                        and old_value == identifier
                    )
                ):
                    corroboration.append(
                        {
                            "evidence_source_column": column,
                            "kind": "exact_explicit_relationship_identifier",
                            "shared_value": old_value,
                        }
                    )
            if not corroboration:
                continue
            old_sources = sorted(
                [
                    column
                    for column in full_columns
                    if normalize_full_opeid(old_row[column]) == identifier
                ],
                key=str.upper,
            )
            new_sources = sorted(
                [
                    column
                    for column in full_columns
                    if normalize_full_opeid(new_row[column]) == identifier
                ],
                key=str.upper,
            )
            base = {
                "corroboration": corroboration,
                "evidence_source_columns": sorted({*old_sources, *new_sources}, key=str.upper),
                "from_full_opeid_source_columns": old_sources,
                "from_last_year": old_last,
                "rationale": EXPECTED_CANDIDATE_RATIONALE,
                "shared_normalized_full_opeid": identifier,
                "to_first_year": new_first,
                "to_full_opeid_source_columns": new_sources,
            }
            successors[old_unitid].append(
                {**base, "candidate_unitid": new_unitid, "relationship": "potential_successor"}
            )
            predecessors[new_unitid].append(
                {**base, "candidate_unitid": old_unitid, "relationship": "potential_predecessor"}
            )

    def dedupe(records: list[dict[str, object]]) -> list[dict[str, object]]:
        unique = {compact_json(record): record for record in records}
        return [unique[key] for key in sorted(unique)]

    return (
        {unitid: dedupe(records) for unitid, records in predecessors.items()},
        {unitid: dedupe(records) for unitid, records in successors.items()},
    )


def verify_insufficiency_and_risk(
    *,
    panel: pd.DataFrame,
    crosswalk: pd.DataFrame,
    mapping: Mapping[str, object],
    lineage_path: Path | None,
    output_lineage: pd.DataFrame | None,
    requested_years: list[int],
    failures: list[str],
) -> None:
    name_column = str(mapping.get("institution_name", ""))
    full_columns = [str(value) for value in mapping.get("full_opeid", [])]
    opeid6_columns = [str(value) for value in mapping.get("opeid6", [])]
    parent_columns = [str(value) for value in mapping.get("parent_child", [])]
    scalar_columns = {
        "sector": str(mapping.get("sector", "")),
        "control": str(mapping.get("control", "")),
        "level": str(mapping.get("level", "")),
    }
    mapped_columns = [
        column
        for column in [
            name_column,
            *full_columns,
            *opeid6_columns,
            *parent_columns,
            *scalar_columns.values(),
        ]
        if column
    ]
    globally_missing = {
        name
        for name, present in {
            "institution_name": bool(name_column),
            "full_opeid": bool(full_columns),
            "parent_child": bool(parent_columns),
            "sector": bool(scalar_columns["sector"]),
            "control": bool(scalar_columns["control"]),
            "level": bool(scalar_columns["level"]),
        }.items()
        if not present
    }
    reasons: dict[int, set[str]] = {
        int(unitid): {f"missing_evidence_column:{name}" for name in globally_missing}
        for unitid in panel["UNITID"].unique()
    }
    lineage_available = lineage_path is not None and lineage_path.is_file()
    lineage_lookup: dict[tuple[int, int, str], set[str]] = {}
    if lineage_available and output_lineage is not None and not output_lineage.empty:
        lineage_lookup = {
            (int(unitid), int(year), str(column).upper()): {
                canonical_scalar(value)
                for value in group["normalized_value"]
                if canonical_scalar(value)
            }
            for (unitid, year, column), group in output_lineage.groupby(
                ["UNITID", "year", "analysis_column"], sort=False
            )
        }
    if not lineage_available:
        for unit_reasons in reasons.values():
            unit_reasons.add("missing_stage06_value_lineage")

    for _, row in panel.iterrows():
        unitid = int(row["UNITID"])
        year = int(row["year"])
        if name_column and not normalize_name(row[name_column]):
            reasons[unitid].add(f"missing_institution_name:{year}")
        valid_full = {
            normalize_full_opeid(row[column])
            for column in full_columns
            if normalize_full_opeid(row[column])
        }
        if full_columns and not valid_full:
            reasons[unitid].add(f"missing_valid_full_opeid:{year}")
        if len(valid_full) > 1:
            reasons[unitid].add(f"ambiguous_full_opeid:{year}")
        if parent_columns and not has_parent_child_evidence(row, parent_columns):
            reasons[unitid].add(f"missing_parent_child_evidence:{year}")
        for label, column in scalar_columns.items():
            if column and not canonical_scalar(row[column]):
                reasons[unitid].add(f"missing_{label}_evidence:{year}")
        if any(
            normalize_full_opeid_with_status(row[column])[1] in {"invalid", "sentinel"}
            for column in full_columns
        ) or any(
            normalize_opeid6_with_status(row[column])[1] in {"invalid", "sentinel"}
            for column in opeid6_columns
        ):
            reasons[unitid].add("invalid_or_sentinel_opeid")
        if lineage_available:
            for column in mapped_columns:
                value = canonical_scalar(row[column])
                observed_values = lineage_lookup.get((unitid, year, column.upper()), set())
                if value and not observed_values:
                    reasons[unitid].add(f"missing_value_lineage:{column}:{year}")
                elif observed_values != ({value} if value else set()):
                    reasons[unitid].add(f"value_lineage_mismatch:{column}:{year}")

    predecessors, successors = derive_expected_candidate_records(panel, mapping)
    crosswalk_by_unit = crosswalk.assign(_UNITID=crosswalk["UNITID"].astype(int)).set_index(
        "_UNITID", drop=False
    )
    for unitid, group in panel.groupby("UNITID", sort=True):
        unitid = int(unitid)
        row = crosswalk_by_unit.loc[unitid]
        expected_reasons = "|".join(sorted(reasons[unitid]))
        if str(row["insufficient_evidence_reasons"]) != expected_reasons:
            failures.append(f"UNITID {unitid} insufficient_evidence_reasons is stale")
        expected_sufficiency = "insufficient" if reasons[unitid] else "complete"
        if str(row["evidence_sufficiency"]) != expected_sufficiency:
            failures.append(f"UNITID {unitid} evidence_sufficiency is stale")
        eligible = strict_boolean(
            row["release_eligible"],
            label=f"UNITID {unitid} release_eligible",
            failures=failures,
        )
        if eligible is not None and eligible != (not reasons[unitid]):
            failures.append(f"UNITID {unitid} release_eligible is stale")

        group = group.sort_values("year", kind="stable")
        _, flags = semantic_history_expectations(group, mapping=mapping)
        unit_years = group["year"].tolist()
        gaps = [
            year
            for year in requested_years
            if unit_years[0] < year < unit_years[-1] and year not in set(unit_years)
        ]
        if gaps:
            flags.add("internal_year_gap")
        if len(unit_years) == 1:
            flags.add("single_year_observation")
        has_candidates = bool(predecessors[unitid] or successors[unitid])
        if has_candidates:
            flags.add("potential_identity_link")
        if reasons[unitid]:
            flags.add("insufficient_evidence")
        expected_flags = "|".join(flag for flag in RISK_FLAG_ORDER if flag in flags)
        if str(row["join_risk_flags"]) != expected_flags:
            failures.append(f"UNITID {unitid} join_risk_flags is stale")
        review_flags = flags - {"insufficient_evidence", "invalid_opeid_evidence"}
        expected_risk = (
            "high"
            if has_candidates
            else "review"
            if review_flags
            else "insufficient"
            if reasons[unitid]
            else "standard"
        )
        if str(row["join_risk_level"]) != expected_risk:
            failures.append(f"UNITID {unitid} join_risk_level is stale")


def verify_candidate_evidence(
    crosswalk: pd.DataFrame,
    panel: pd.DataFrame,
    evidence_mapping: Mapping[str, object],
    failures: list[str],
) -> None:
    full_columns = [str(value) for value in evidence_mapping.get("full_opeid", [])]
    opeid6_columns = {str(value) for value in evidence_mapping.get("opeid6", [])}
    name_column = str(evidence_mapping.get("institution_name", ""))
    parent_columns = [str(value) for value in evidence_mapping.get("parent_child", [])]
    relationship_columns = [column for column in parent_columns if not column.upper().startswith("PRCH")]
    spans = {
        int(unitid): (int(group["year"].min()), int(group["year"].max()))
        for unitid, group in panel.groupby("UNITID", sort=False)
    }
    by_key = {
        (int(row["UNITID"]), int(row["year"])): row for _, row in panel.iterrows()
    }
    predecessor_links: set[tuple[int, int, str, int, int]] = set()
    successor_links: set[tuple[int, int, str, int, int]] = set()
    expected_predecessors, expected_successors = derive_expected_candidate_records(
        panel, evidence_mapping
    )

    for _, crosswalk_row in crosswalk.iterrows():
        current_unitid = safe_integer(
            crosswalk_row["UNITID"],
            label="candidate evidence UNITID",
            failures=failures,
            minimum=1,
            canonical_text=True,
        )
        if current_unitid is None:
            continue
        declared_sources = {
            value for value in str(crosswalk_row["candidate_link_source_columns"]).split("|") if value
        }
        if declared_sources & opeid6_columns:
            failures.append(f"UNITID {current_unitid} candidate incorrectly treats OPEID6 as stable")
        observed_sources: set[str] = set()
        declared_has_candidates = False
        for field, unitids_field, expected_relationship in (
            (
                "potential_predecessor_evidence",
                "potential_predecessor_unitids",
                "potential_predecessor",
            ),
            (
                "potential_successor_evidence",
                "potential_successor_unitids",
                "potential_successor",
            ),
        ):
            records = json_list(
                crosswalk_row[field], label=f"UNITID {current_unitid} {field}", failures=failures
            )
            declared_unitids = json_list(
                crosswalk_row[unitids_field],
                label=f"UNITID {current_unitid} {unitids_field}",
                failures=failures,
            )
            if records is None or declared_unitids is None:
                continue
            expected_records = (
                expected_predecessors.get(current_unitid, [])
                if expected_relationship == "potential_predecessor"
                else expected_successors.get(current_unitid, [])
            )
            if records != expected_records:
                failures.append(
                    f"UNITID {current_unitid} {field} differs from independently derived evidence"
                )
            parsed_declared: list[int] = []
            for index, value in enumerate(declared_unitids):
                parsed = safe_integer(
                    value,
                    label=f"UNITID {current_unitid} {unitids_field}[{index}]",
                    failures=failures,
                    minimum=1,
                    require_json_integer=True,
                )
                if parsed is not None:
                    parsed_declared.append(parsed)
            record_unitids: list[int] = []
            serialized_records: set[str] = set()
            for record in records:
                if not isinstance(record, dict):
                    failures.append(f"UNITID {current_unitid} has malformed candidate record")
                    continue
                expected_record_keys = {
                    "candidate_unitid",
                    "corroboration",
                    "evidence_source_columns",
                    "from_full_opeid_source_columns",
                    "from_last_year",
                    "rationale",
                    "relationship",
                    "shared_normalized_full_opeid",
                    "to_first_year",
                    "to_full_opeid_source_columns",
                }
                if set(record) != expected_record_keys:
                    failures.append(f"UNITID {current_unitid} candidate record keys are not exact")
                serialized = json.dumps(record, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
                if serialized in serialized_records:
                    failures.append(f"UNITID {current_unitid} repeats a candidate evidence record")
                serialized_records.add(serialized)
                source_columns = record.get("evidence_source_columns", [])
                corroboration = record.get("corroboration", [])
                identifier = str(record.get("shared_normalized_full_opeid", ""))
                old_year = safe_integer(
                    record.get("from_last_year"),
                    label=f"UNITID {current_unitid} candidate from_last_year",
                    failures=failures,
                    minimum=1,
                    require_json_integer=True,
                )
                new_year = safe_integer(
                    record.get("to_first_year"),
                    label=f"UNITID {current_unitid} candidate to_first_year",
                    failures=failures,
                    minimum=1,
                    require_json_integer=True,
                )
                candidate = safe_integer(
                    record.get("candidate_unitid"),
                    label=f"UNITID {current_unitid} candidate_unitid",
                    failures=failures,
                    minimum=1,
                    require_json_integer=True,
                )
                relationship = str(record.get("relationship", ""))
                if candidate is not None:
                    record_unitids.append(candidate)
                if relationship != expected_relationship:
                    failures.append(f"UNITID {current_unitid} candidate relationship is inconsistent")
                if (
                    not isinstance(source_columns, list)
                    or not source_columns
                    or not set(str(value) for value in source_columns).issubset(set(full_columns))
                ):
                    failures.append(f"UNITID {current_unitid} candidate lacks full-OPEID sources")
                if not isinstance(corroboration, list) or not corroboration:
                    failures.append(f"UNITID {current_unitid} candidate lacks independent corroboration")
                if (
                    normalize_full_opeid(identifier) != identifier
                    or old_year is None
                    or new_year is None
                    or candidate is None
                    or new_year != old_year + 1
                ):
                    failures.append(f"UNITID {current_unitid} candidate has invalid boundary identity")
                    continue
                old_unitid = current_unitid if relationship == "potential_successor" else candidate
                new_unitid = candidate if relationship == "potential_successor" else current_unitid
                if old_unitid == new_unitid:
                    failures.append(f"UNITID {current_unitid} candidate self-links a UNITID")
                    continue
                if spans.get(old_unitid, (None, None))[1] != old_year or spans.get(
                    new_unitid, (None, None)
                )[0] != new_year:
                    failures.append(f"UNITID {current_unitid} candidate is not at true span boundaries")
                owners_old = {
                    int(row["UNITID"])
                    for _, row in panel[panel["year"].astype(int).eq(old_year)].iterrows()
                    if any(normalize_full_opeid(row[column]) == identifier for column in full_columns)
                }
                owners_new = {
                    int(row["UNITID"])
                    for _, row in panel[panel["year"].astype(int).eq(new_year)].iterrows()
                    if any(normalize_full_opeid(row[column]) == identifier for column in full_columns)
                }
                if owners_old != {old_unitid} or owners_new != {new_unitid}:
                    failures.append(f"UNITID {current_unitid} candidate lacks one-to-one boundary ownership")
                old_row = by_key.get((old_unitid, old_year))
                new_row = by_key.get((new_unitid, new_year))
                if old_row is None or new_row is None:
                    failures.append(f"UNITID {current_unitid} candidate references absent boundary keys")
                    continue
                old_identifiers = {
                    normalize_full_opeid(old_row[column])
                    for column in full_columns
                    if normalize_full_opeid(old_row[column])
                }
                new_identifiers = {
                    normalize_full_opeid(new_row[column])
                    for column in full_columns
                    if normalize_full_opeid(new_row[column])
                }
                old_invalid = any(
                    normalize_full_opeid_with_status(old_row[column])[1]
                    in {"invalid", "sentinel"}
                    for column in full_columns
                )
                new_invalid = any(
                    normalize_full_opeid_with_status(new_row[column])[1]
                    in {"invalid", "sentinel"}
                    for column in full_columns
                )
                if (
                    old_identifiers != {identifier}
                    or new_identifiers != {identifier}
                    or old_invalid
                    or new_invalid
                ):
                    failures.append(f"UNITID {current_unitid} candidate boundary OPEID is ambiguous")
                expected_old_opeid_sources = sorted(
                    [
                        column
                        for column in full_columns
                        if normalize_full_opeid(old_row[column]) == identifier
                    ],
                    key=str.upper,
                )
                expected_new_opeid_sources = sorted(
                    [
                        column
                        for column in full_columns
                        if normalize_full_opeid(new_row[column]) == identifier
                    ],
                    key=str.upper,
                )
                expected_opeid_sources = sorted(
                    {*expected_old_opeid_sources, *expected_new_opeid_sources}, key=str.upper
                )
                if source_columns != expected_opeid_sources:
                    failures.append(f"UNITID {current_unitid} candidate OPEID sources are stale")
                if record.get("from_full_opeid_source_columns") != expected_old_opeid_sources:
                    failures.append(f"UNITID {current_unitid} candidate old-boundary OPEID sources are stale")
                if record.get("to_full_opeid_source_columns") != expected_new_opeid_sources:
                    failures.append(f"UNITID {current_unitid} candidate new-boundary OPEID sources are stale")
                expected_corroboration: list[dict[str, str]] = []
                if name_column:
                    old_name = normalize_name(old_row[name_column])
                    new_name = normalize_name(new_row[name_column])
                    if old_name and old_name == new_name:
                        expected_corroboration.append(
                            {
                                "evidence_source_column": name_column,
                                "kind": "exact_normalized_institution_name",
                                "shared_value": old_name,
                            }
                        )
                for column in relationship_columns:
                    old_value = normalize_relationship_identifier(column, old_row[column])
                    new_value = normalize_relationship_identifier(column, new_row[column])
                    if (
                        old_value
                        and old_value == new_value
                        and not (
                            column.upper() in {"PARENT_OPEID", "PARENTOPEID"}
                            and old_value == identifier
                        )
                    ):
                        expected_corroboration.append(
                            {
                                "evidence_source_column": column,
                                "kind": "exact_explicit_relationship_identifier",
                                "shared_value": old_value,
                            }
                        )
                if corroboration != expected_corroboration or not expected_corroboration:
                    failures.append(f"UNITID {current_unitid} candidate corroboration is stale")
                if any(
                    not isinstance(item, dict)
                    or set(item) != {"evidence_source_column", "kind", "shared_value"}
                    for item in corroboration if isinstance(corroboration, list)
                ):
                    failures.append(f"UNITID {current_unitid} corroboration record keys are not exact")
                if record.get("rationale") != EXPECTED_CANDIDATE_RATIONALE:
                    failures.append(f"UNITID {current_unitid} candidate rationale is stale")
                observed_sources.update(str(value) for value in source_columns)
                observed_sources.update(
                    str(item.get("evidence_source_column", ""))
                    for item in expected_corroboration
                )
                signature = (old_unitid, new_unitid, identifier, old_year, new_year)
                if relationship == "potential_successor":
                    successor_links.add(signature)
                elif relationship == "potential_predecessor":
                    predecessor_links.add(signature)
            expected_unitids = sorted(set(record_unitids))
            if parsed_declared != expected_unitids:
                failures.append(f"UNITID {current_unitid} {unitids_field} does not match its evidence")
            declared_has_candidates |= bool(records)
        expected_records = [
            *expected_predecessors.get(current_unitid, []),
            *expected_successors.get(current_unitid, []),
        ]
        expected_sources = {
            str(column)
            for record in expected_records
            for column in [
                *list(record.get("evidence_source_columns", [])),
                *[
                    item.get("evidence_source_column", "")
                    for item in record.get("corroboration", [])
                    if isinstance(item, dict)
                ],
            ]
            if column
        }
        has_candidates = bool(expected_records)
        expected_status = (
            "potential_only_unique_full_opeid_with_corroboration" if has_candidates else ""
        )
        if str(crosswalk_row["candidate_link_status"]) != expected_status:
            failures.append(f"UNITID {current_unitid} candidate_link_status is stale")
        if declared_sources != expected_sources:
            failures.append(f"UNITID {current_unitid} candidate_link_source_columns is stale")
        flags = set(split_pipe(crosswalk_row["join_risk_flags"]))
        if has_candidates and (
            "potential_identity_link" not in flags or str(crosswalk_row["join_risk_level"]) != "high"
        ):
            failures.append(f"UNITID {current_unitid} candidate is not classified high risk")
        if not has_candidates and "potential_identity_link" in flags:
            failures.append(f"UNITID {current_unitid} has a candidate risk flag without evidence")
        if declared_has_candidates != has_candidates:
            failures.append(f"UNITID {current_unitid} candidate presence is incomplete")
    if predecessor_links != successor_links:
        failures.append("candidate predecessor/successor evidence is not reciprocal")


def verify_bundle(
    *,
    root: Path,
    repo: Path,
    bundle: Path,
    mode: str,
    panel_override: Path | None = None,
    lineage_override: Path | None = None,
) -> dict[str, object]:
    root = root.expanduser().absolute()
    repo = repo.expanduser().absolute()
    bundle = bundle.expanduser().absolute()
    verifier_path = Path(__file__).resolve()
    verifier_sha_before = sha256_file(verifier_path)
    failures: list[str] = []
    release = mode == "release"
    try:
        release_layout = reviewed_release_layout(repo)
    except ValueError as exc:
        failures.append(str(exc))
        release_layout = {
            "continuity_output": "Checks/v2/entity_continuity",
            "lineage_input": "Checks/v2/wide_qc/qc_value_lineage.parquet",
            "panel_input": "",
            "years": [],
        }
    canonical_bundle = root / str(release_layout["continuity_output"])
    if release and bundle != canonical_bundle:
        failures.append("release verifier requires the canonical entity-continuity pointer")
    if not release and bundle == canonical_bundle:
        failures.append("development verification cannot bless the canonical continuity pointer")
    if release and (panel_override is not None or lineage_override is not None):
        failures.append("release verifier does not permit input or lineage overrides")
        panel_override = None
        lineage_override = None
    if release and not bundle.is_symlink():
        failures.append("release continuity bundle is not an atomic managed pointer")
    try:
        resolved_bundle = bundle.resolve(strict=True)
    except OSError as exc:
        return {"status": "fail", "failures": [f"continuity bundle cannot be resolved: {exc}"]}
    if release:
        try:
            resolved_bundle.relative_to(root.resolve())
        except ValueError:
            failures.append("release continuity bundle resolves outside IPEDSDB_ROOT")
        expected_store = (bundle.parent / f".{bundle.name}.runs").resolve()
        if resolved_bundle.parent != expected_store:
            failures.append("release continuity pointer targets an unmanaged run store")
    bundle_entries = list(resolved_bundle.iterdir())
    files = {path.name for path in bundle_entries}
    if files != BUNDLE_FILES:
        failures.append(f"bundle inventory mismatch: expected={sorted(BUNDLE_FILES)} observed={sorted(files)}")
    if any(not path.is_file() or path.is_symlink() for path in bundle_entries):
        failures.append("continuity bundle contains non-regular or symlinked members")
    manifest_path = resolved_bundle / "entity_continuity_manifest.json"
    try:
        manifest = load_manifest(manifest_path)
    except ValueError as exc:
        return {"status": "fail", "failures": [str(exc)]}
    manifest_sha_before = sha256_file(manifest_path)
    if manifest.get("schema_version") != SCHEMA_VERSION:
        failures.append("continuity manifest schema is unsupported")
    if manifest.get("builder_path") != BUILDER_PATH:
        failures.append("continuity manifest builder path is not exact")
    if manifest.get("mode") != mode:
        failures.append("continuity manifest mode does not match verifier mode")
    if manifest.get("expected_bundle_files") != sorted(BUNDLE_FILES):
        failures.append("manifest expected_bundle_files is not exact")
    if resolved_bundle.name != manifest.get("run_id"):
        failures.append("managed run directory does not match manifest run_id")
    expected_run_id = "continuity-" + sha256_json(
        {
            "builder_sha256": manifest.get("builder_sha256"),
            "input_path": manifest.get("input_path"),
            "input_sha256": manifest.get("input_sha256"),
            "input_schema_sha256": manifest.get("input_schema_sha256"),
            "lineage_path": manifest.get("lineage_input_path"),
            "lineage_sha256": manifest.get("lineage_input_sha256"),
            "runtime_bindings": manifest.get("runtime_bindings"),
            "mode": manifest.get("mode"),
            "require_complete_year_scope": manifest.get("require_complete_year_scope"),
            "requested_years": manifest.get("requested_years"),
            "schema_version": manifest.get("schema_version"),
        }
    )[:24]
    if manifest.get("run_id") != expected_run_id:
        failures.append("continuity run_id is not content-addressed to its recorded inputs and bindings")
    if manifest.get("crosswalk_columns") != CROSSWALK_COLUMNS:
        failures.append("manifest crosswalk columns are stale")
    if manifest.get("crosswalk_schema_sha256") != crosswalk_schema_hash():
        failures.append("manifest crosswalk logical schema hash is stale")

    raw_requested_years = manifest.get("requested_years", [])
    requested_years: list[int] = []
    if not isinstance(raw_requested_years, list) or not raw_requested_years:
        failures.append("manifest requested_years is malformed")
    else:
        for index, value in enumerate(raw_requested_years):
            parsed = safe_integer(
                value,
                label=f"manifest requested_years[{index}]",
                failures=failures,
                minimum=1,
                require_json_integer=True,
            )
            if parsed is not None:
                requested_years.append(parsed)
    if requested_years != sorted(set(requested_years)):
        failures.append("manifest requested_years must be sorted and unique")
    if requested_years and requested_years != list(
        range(requested_years[0], requested_years[-1] + 1)
    ):
        failures.append("manifest requested_years is not one contiguous inclusive interval")
    if release and requested_years:
        if requested_years != list(release_layout["years"]):
            failures.append("release continuity years differ from the reviewed contract")
        if manifest.get("input_path") != release_layout["panel_input"]:
            failures.append("release continuity manifest does not bind the canonical clean panel")
        if manifest.get("lineage_input_path") != release_layout["lineage_input"]:
            failures.append("release continuity manifest does not bind canonical Stage 06 lineage")
        if manifest.get("require_complete_year_scope") is not True:
            failures.append("release continuity manifest disables complete-year enforcement")

    bindings = manifest.get("runtime_bindings", {})
    if not isinstance(bindings, dict):
        bindings = {}
        failures.append("runtime_bindings is malformed")
    try:
        git = git_state(repo)
        contract_id, contract_hashes = current_contract_hashes(repo)
        current_tools = portable_tools(tool_versions())
    except ProvenanceError as exc:
        failures.append(f"cannot resolve current release bindings: {exc}")
        git, contract_id, contract_hashes, current_tools = {}, "", {}, {}
    if not isinstance(bindings.get("git_dirty"), bool):
        failures.append("continuity Git dirty binding is not boolean")
    if bindings.get("git_commit") != git.get("git_commit"):
        failures.append("continuity evidence was built at a different Git commit")
    if bool(bindings.get("git_dirty")) != bool(git.get("git_dirty")):
        failures.append("continuity evidence Git dirty binding is stale")
    if release and (bool(git.get("git_dirty")) or bool(bindings.get("git_dirty"))):
        failures.append("release continuity verification requires clean Git state")
    if bindings.get("contract_id") != contract_id or bindings.get("contract_hashes") != contract_hashes:
        failures.append("continuity evidence contract hashes are stale")
    if bindings.get("tool_versions") != current_tools:
        failures.append("continuity evidence tool/container bindings are stale")
    if release and not re.fullmatch(
        r"sha256:[0-9a-fA-F]{64}", str(current_tools.get("container_image_digest", "")).strip()
    ):
        failures.append("release continuity verification requires an immutable sha256 container digest")

    code_hashes = bindings.get("code_hashes", {})
    if not isinstance(code_hashes, dict) or set(code_hashes) != REQUIRED_CODE_HASHES:
        failures.append("continuity imported-code inventory is not exact")
    else:
        for relative, recorded_hash in code_hashes.items():
            code_path = repo / relative
            if not code_path.is_file() or sha256_file(code_path) != recorded_hash:
                failures.append(f"continuity imported code hash is stale: {relative}")
        if manifest.get("builder_sha256") != code_hashes.get(BUILDER_PATH):
            failures.append("builder hash is not bound to the imported-code inventory")

    causal_run: Path | None = None
    if release:
        try:
            verify_run(
                root=root,
                repo=repo,
                required_stages=REQUIRED_CAUSAL_STAGES,
            )
            causal_run = resolve_run_dir(root)
            causal_manifest = causal_run / "run_manifest.json"
            causal_relative = causal_manifest.relative_to(root.resolve()).as_posix()
            if bindings.get("causal_run_manifest_path") != causal_relative:
                failures.append("continuity causal run-manifest path is stale")
            if bindings.get("causal_run_manifest_sha256") != sha256_file(causal_manifest):
                failures.append("continuity causal run-manifest hash is stale")
        except (ProvenanceError, OSError, ValueError) as exc:
            failures.append(f"continuity causal provenance verification failed: {exc}")

    panel_frame: pd.DataFrame | None = None
    evidence_mapping: dict[str, object] = {
        "institution_name": "",
        "full_opeid": [],
        "opeid6": [],
        "parent_child": [],
        "sector": "",
        "control": "",
        "level": "",
    }
    panel_path = panel_override
    if panel_path is None:
        panel_path = safe_root_path(root, manifest.get("input_path"), failures, "input_path")
    if panel_path is not None and panel_path.is_file():
        panel_file = pq.ParquetFile(panel_path)
        panel_schema_columns = [str(value) for value in panel_file.schema_arrow.names]
        if sha256_file(panel_path) != manifest.get("input_sha256"):
            failures.append("continuity input hash changed")
        input_rows = safe_integer(
            manifest.get("input_row_count"),
            label="manifest input_row_count",
            failures=failures,
            minimum=0,
            require_json_integer=True,
        )
        input_columns = safe_integer(
            manifest.get("input_column_count"),
            label="manifest input_column_count",
            failures=failures,
            minimum=0,
            require_json_integer=True,
        )
        if input_rows is not None and int(panel_file.metadata.num_rows) != input_rows:
            failures.append("continuity input row count changed")
        if input_columns is not None and len(panel_schema_columns) != input_columns:
            failures.append("continuity input column count changed")
        if parquet_schema_hash(panel_path) != manifest.get("input_schema_sha256"):
            failures.append("continuity input schema changed")
        evidence_mapping = validate_evidence_mapping(
            manifest.get("evidence_columns"),
            panel_columns=panel_schema_columns,
            release=release,
            failures=failures,
        )
        mapped_columns: list[str] = []
        for value in evidence_mapping.values():
            if isinstance(value, list):
                mapped_columns.extend(str(item) for item in value)
            elif value:
                mapped_columns.append(str(value))
        required_panel_columns = ["UNITID", "year", *mapped_columns]
        if set(required_panel_columns).issubset(set(panel_schema_columns)):
            panel_frame = pd.read_parquet(
                panel_path, columns=list(dict.fromkeys(required_panel_columns))
            )
            loaded_columns = safe_integer(
                manifest.get("loaded_evidence_column_count"),
                label="manifest loaded_evidence_column_count",
                failures=failures,
                minimum=0,
                require_json_integer=True,
            )
            if loaded_columns is not None and loaded_columns != len(set(required_panel_columns)):
                failures.append("manifest loaded evidence-column count is stale")
        else:
            missing_required = sorted(set(required_panel_columns) - set(panel_schema_columns))
            failures.append(
                f"continuity input is missing exact required panel columns: {missing_required}"
            )
    else:
        failures.append("continuity input parquet is missing")

    lineage_schema_valid = False
    lineage_projection_schema: pa.Schema | None = None
    lineage_path = lineage_override
    if lineage_path is None and manifest.get("lineage_input_path"):
        lineage_path = safe_root_path(
            root, manifest.get("lineage_input_path"), failures, "lineage_input_path"
        )
    if lineage_path is not None and lineage_path.is_file():
        lineage_file = pq.ParquetFile(lineage_path)
        missing_lineage_columns = sorted(
            REQUIRED_LINEAGE_COLUMNS - set(lineage_file.schema_arrow.names)
        )
        if missing_lineage_columns:
            failures.append(
                f"Stage 06 lineage input is missing required columns: {missing_lineage_columns}"
            )
        else:
            invalid_key_types = {
                column: str(lineage_file.schema_arrow.field(column).type)
                for column in ("UNITID", "year")
                if not pa.types.is_integer(lineage_file.schema_arrow.field(column).type)
            }
            if invalid_key_types:
                failures.append(
                    f"Stage 06 lineage key fields must use integer Arrow types: {invalid_key_types}"
                )
            else:
                lineage_schema_valid = True
            lineage_projection_schema = pa.schema(
                [
                    lineage_file.schema_arrow.field(column)
                    for column in sorted(REQUIRED_LINEAGE_COLUMNS)
                ]
            )
        if sha256_file(lineage_path) != manifest.get("lineage_input_sha256"):
            failures.append("Stage 06 lineage input hash changed")
        lineage_rows = safe_integer(
            manifest.get("lineage_input_row_count"),
            label="manifest lineage_input_row_count",
            failures=failures,
            minimum=0,
            require_json_integer=True,
        )
        if lineage_rows is not None and int(lineage_file.metadata.num_rows) != lineage_rows:
            failures.append("Stage 06 lineage input row count changed")
        if parquet_schema_hash(lineage_path) != manifest.get("lineage_input_schema_sha256"):
            failures.append("Stage 06 lineage input schema changed")
    elif release:
        failures.append("release continuity verification requires Stage 06 lineage input")

    if release and causal_run is not None:
        for stage, artifact_path, recorded_sha, label in (
            ("07", panel_path, manifest.get("input_sha256"), "clean panel"),
            ("06", lineage_path, manifest.get("lineage_input_sha256"), "value lineage"),
        ):
            if artifact_path is None:
                continue
            try:
                stage_manifest = load_manifest(causal_run / f"{stage}.json")
                output_metadata = stage_manifest.get("output_metadata", {})
                record = (
                    output_metadata.get(str(artifact_path.absolute()))
                    if isinstance(output_metadata, dict)
                    else None
                )
                if not isinstance(record, dict) or record.get("sha256") != recorded_sha:
                    failures.append(f"Stage {stage} causal receipt does not bind continuity {label}")
            except ValueError as exc:
                failures.append(f"cannot verify Stage {stage} continuity binding: {exc}")

    records = manifest.get("output_artifacts", [])
    if not isinstance(records, list):
        records = []
        failures.append("output artifact records are malformed")
    expected_outputs = BUNDLE_FILES - {"entity_continuity_manifest.json"}
    record_names = {
        str(record.get("path", "")) for record in records if isinstance(record, dict)
    }
    if record_names != expected_outputs or len(records) != len(expected_outputs):
        failures.append("output artifact manifest inventory is not exact")
    for raw_record in records:
        if not isinstance(raw_record, dict):
            continue
        name = str(raw_record.get("path", ""))
        if Path(name).name != name:
            failures.append(f"unsafe output artifact path: {name!r}")
            continue
        path = resolved_bundle / name
        if not path.is_file():
            failures.append(f"missing continuity output: {name}")
            continue
        recorded_bytes = safe_integer(
            raw_record.get("bytes"),
            label=f"output artifact {name} bytes",
            failures=failures,
            minimum=0,
            require_json_integer=True,
        )
        recorded_rows = safe_integer(
            raw_record.get("row_count"),
            label=f"output artifact {name} row_count",
            failures=failures,
            minimum=0,
            require_json_integer=True,
        )
        if recorded_bytes is not None and path.stat().st_size != recorded_bytes:
            failures.append(f"continuity output byte count changed: {name}")
        if sha256_file(path) != raw_record.get("sha256"):
            failures.append(f"continuity output hash changed: {name}")
        if path.suffix == ".csv":
            rows, header = csv_shape(path)
            if recorded_rows is not None and rows != recorded_rows:
                failures.append(f"continuity output row count changed: {name}")
            expected_schema = (
                crosswalk_schema_hash()
                if name == "entity_continuity_crosswalk.csv"
                else frame_schema_hash([("metric", "string"), ("value", "string")])
            )
            if name == "entity_continuity_crosswalk.csv" and header != CROSSWALK_COLUMNS:
                failures.append("continuity crosswalk header changed")
        elif path.suffix == ".parquet":
            parquet_file = pq.ParquetFile(path)
            if recorded_rows is not None and int(parquet_file.metadata.num_rows) != recorded_rows:
                failures.append(f"continuity output row count changed: {name}")
            expected_schema = parquet_schema_hash(path)
        else:
            rows = len(path.read_text(encoding="utf-8").splitlines())
            if recorded_rows is not None and rows != recorded_rows:
                failures.append(f"continuity output line count changed: {name}")
            expected_schema = sha256_json([{"name": "markdown", "logical_type": "text"}])
        if raw_record.get("schema_sha256") != expected_schema:
            failures.append(f"continuity output schema binding changed: {name}")

    crosswalk_path = resolved_bundle / "entity_continuity_crosswalk.csv"
    lineage_output = resolved_bundle / "entity_continuity_value_lineage.parquet"
    crosswalk: pd.DataFrame | None = None
    normalized_panel: pd.DataFrame | None = None
    output_lineage: pd.DataFrame | None = None
    if crosswalk_path.is_file():
        crosswalk = pd.read_csv(crosswalk_path, keep_default_na=False, dtype=str)
        if crosswalk.columns.tolist() != CROSSWALK_COLUMNS:
            failures.append("continuity crosswalk columns are not exact")
        elif crosswalk.empty or crosswalk["UNITID"].duplicated().any():
            failures.append("continuity crosswalk must contain one row per unique UNITID")
        else:
            output_unitids = safe_integer(
                manifest.get("output_unitid_count"),
                label="manifest output_unitid_count",
                failures=failures,
                minimum=0,
                require_json_integer=True,
            )
            if output_unitids is not None and len(crosswalk) != output_unitids:
                failures.append("continuity crosswalk UNITID count is stale")
            if release and not bool_series(crosswalk["release_eligible"]).all():
                failures.append("release continuity crosswalk contains ineligible UNITIDs")
            if release and not crosswalk["evidence_sufficiency"].eq("complete").all():
                failures.append("release continuity crosswalk contains insufficient evidence")
            lineage_counts = pd.to_numeric(crosswalk["value_lineage_rows"], errors="coerce")
            if release and (lineage_counts.isna().any() or (lineage_counts <= 0).any()):
                failures.append("release continuity crosswalk has unbound or malformed evidence rows")
            if panel_frame is not None:
                normalized_panel = verify_panel_crosswalk(
                    panel_frame,
                    crosswalk,
                    mapping=evidence_mapping,
                    requested_years=requested_years,
                    release=release,
                    failures=failures,
                )
                if normalized_panel is not None and not normalized_panel.duplicated(
                    ["UNITID", "year"]
                ).any():
                    observed_years = sorted(normalized_panel["year"].unique().tolist())
                    if manifest.get("observed_years") != observed_years:
                        failures.append("manifest observed_years is stale")
                    expected_missing = sorted(set(requested_years) - set(observed_years))
                    if manifest.get("missing_requested_years") != expected_missing:
                        failures.append("manifest missing_requested_years is stale")
                    verify_candidate_evidence(
                        crosswalk, normalized_panel, evidence_mapping, failures
                    )
                    verify_summaries(
                        bundle=resolved_bundle,
                        panel=normalized_panel,
                        crosswalk=crosswalk,
                        mapping=evidence_mapping,
                        requested_years=requested_years,
                        failures=failures,
                    )
    if lineage_output.is_file():
        output_lineage_schema = pq.ParquetFile(lineage_output).schema_arrow
        if lineage_projection_schema is not None and not lineage_projection_schema.equals(
            output_lineage_schema,
            check_metadata=False,
        ):
            failures.append(
                "filtered continuity value-lineage Arrow schema differs from the Stage 06 projection"
            )
        output_lineage = pd.read_parquet(lineage_output)
        comparison_columns = sorted(REQUIRED_LINEAGE_COLUMNS)
        if output_lineage.columns.tolist() != comparison_columns:
            failures.append("filtered continuity value-lineage schema is incomplete")
        if release and output_lineage.empty:
            failures.append("release filtered continuity value lineage is empty")
        lineage_output_rows = safe_integer(
            manifest.get("lineage_output_row_count"),
            label="manifest lineage_output_row_count",
            failures=failures,
            minimum=0,
            require_json_integer=True,
        )
        if lineage_output_rows is not None and lineage_output_rows != len(output_lineage):
            failures.append("manifest filtered lineage row count is stale")
        if not output_lineage.empty and output_lineage.duplicated().any():
            failures.append("filtered continuity value lineage contains duplicate rows")
        output_keys_valid = set(output_lineage.columns) >= {"UNITID", "year"}
        if output_keys_valid:
            output_unitids = [
                safe_integer(
                    value,
                    label=f"filtered lineage UNITID row {index + 1}",
                    failures=failures,
                    minimum=1,
                    allow_integral_float=True,
                )
                for index, value in enumerate(output_lineage["UNITID"])
            ]
            output_years = [
                safe_integer(
                    value,
                    label=f"filtered lineage year row {index + 1}",
                    failures=failures,
                    minimum=1,
                    allow_integral_float=True,
                )
                for index, value in enumerate(output_lineage["year"])
            ]
            output_keys_valid = all(value is not None for value in output_unitids + output_years)
            if output_keys_valid:
                output_lineage = output_lineage.copy()
                output_lineage["UNITID"] = [int(value) for value in output_unitids]
                output_lineage["year"] = [int(value) for value in output_years]
        lineage_identity_columns = [
            "contract_id",
            "variable_id",
            "source_varnumber",
            "varname",
            "source_row_id",
            "source_row_hash",
            "source_file",
            "access_table_name",
            "transformation_id",
            "lineage_role",
        ]
        if not output_lineage.empty and any(
            output_lineage[column].map(canonical_scalar).eq("").any()
            for column in lineage_identity_columns
            if column in output_lineage
        ):
            failures.append("filtered continuity value lineage contains blank scientific identities")
        if not output_lineage.empty:
            lineage_contracts = {
                canonical_scalar(value)
                for value in output_lineage.get("contract_id", [])
                if canonical_scalar(value)
            }
            if lineage_contracts != {str(bindings.get("contract_id", ""))}:
                failures.append("filtered continuity value lineage uses a stale contract_id")
        if (
            normalized_panel is not None
            and lineage_path is not None
            and lineage_path.is_file()
            and lineage_schema_valid
            and set(output_lineage.columns) == REQUIRED_LINEAGE_COLUMNS
        ):
            evidence_columns: list[str] = []
            for value in evidence_mapping.values():
                if isinstance(value, list):
                    evidence_columns.extend(str(item) for item in value if str(item))
                elif str(value):
                    evidence_columns.append(str(value))
            evidence_columns = sorted(set(evidence_columns), key=str.upper)
            panel_evidence = normalized_panel[["UNITID", "year", *evidence_columns]].copy()
            source_lineage = pd.read_parquet(
                lineage_path,
                columns=comparison_columns,
                filters=[
                    ("analysis_column", "in", [column.upper() for column in evidence_columns]),
                    ("year", "in", requested_years),
                ],
            )
            source_unitids = [
                safe_integer(
                    value,
                    label=f"Stage 06 lineage UNITID row {index + 1}",
                    failures=failures,
                    minimum=1,
                    allow_integral_float=True,
                )
                for index, value in enumerate(source_lineage["UNITID"])
            ]
            source_years = [
                safe_integer(
                    value,
                    label=f"Stage 06 lineage year row {index + 1}",
                    failures=failures,
                    minimum=1,
                    allow_integral_float=True,
                )
                for index, value in enumerate(source_lineage["year"])
            ]
            source_keys_valid = all(value is not None for value in source_unitids + source_years)
            if source_keys_valid:
                source_lineage = source_lineage.copy()
                source_lineage["UNITID"] = [int(value) for value in source_unitids]
                source_lineage["year"] = [int(value) for value in source_years]
            else:
                source_lineage = source_lineage.iloc[0:0].copy()
            if source_lineage.duplicated().any():
                failures.append("Stage 06 continuity lineage contains exact duplicate rows")
            panel_keys = set(
                zip(panel_evidence["UNITID"].astype(int), panel_evidence["year"].astype(int))
            )
            source_keys = {
                (int(unitid), int(year))
                for unitid, year in zip(source_lineage["UNITID"], source_lineage["year"])
            }
            orphan_keys = sorted(source_keys - panel_keys)
            if orphan_keys:
                failures.append(
                    f"Stage 06 continuity lineage contains panel-orphan keys: {orphan_keys[:10]}"
                )
            expected_lineage = exact_sorted_frame(
                source_lineage, comparison_columns
            )
            observed_lineage = exact_sorted_frame(
                output_lineage, comparison_columns
            )
            if not expected_lineage.equals(observed_lineage):
                failures.append("filtered continuity value lineage is not an exact Stage 06 subset")
            lookup = {
                (int(unitid), int(year), str(column).upper()): {
                    canonical_scalar(value)
                    for value in group["normalized_value"]
                    if canonical_scalar(value)
                }
                for (unitid, year, column), group in output_lineage.groupby(
                    ["UNITID", "year", "analysis_column"], sort=False
                )
            }
            for _, row in panel_evidence.iterrows():
                for column in evidence_columns:
                    value = canonical_scalar(row[column])
                    observed_values = lookup.get(
                        (int(row["UNITID"]), int(row["year"]), column.upper()), set()
                    )
                    expected_values = {value} if value else set()
                    if observed_values != expected_values:
                        failures.append(
                            f"panel evidence cell does not exactly match Stage 06 value lineage: "
                            f"UNITID={row['UNITID']} year={row['year']} column={column}"
                        )
            if crosswalk is not None and output_keys_valid:
                lineage_by_unit = {
                    int(unitid): group
                    for unitid, group in output_lineage.groupby("UNITID", sort=False)
                }
                for _, row in crosswalk.iterrows():
                    unitid = int(row["UNITID"])
                    unit_lineage = lineage_by_unit.get(
                        unitid, pd.DataFrame(columns=output_lineage.columns)
                    )
                    expected_values = {
                        "value_lineage_rows": str(len(unit_lineage)),
                        "evidence_variable_ids": "|".join(
                            sorted(
                                {
                                    canonical_scalar(value)
                                    for value in unit_lineage.get("variable_id", [])
                                    if canonical_scalar(value)
                                }
                            )
                        ),
                        "evidence_source_files": "|".join(
                            sorted(
                                {
                                    canonical_scalar(value)
                                    for value in unit_lineage.get("source_file", [])
                                    if canonical_scalar(value)
                                }
                            )
                        ),
                        "evidence_access_tables": "|".join(
                            sorted(
                                {
                                    canonical_scalar(value)
                                    for value in unit_lineage.get("access_table_name", [])
                                    if canonical_scalar(value)
                                }
                            )
                        ),
                    }
                    for field, expected in expected_values.items():
                        if canonical_scalar(row[field]) != expected:
                            failures.append(f"UNITID {unitid} {field} is stale")

    if (
        normalized_panel is not None
        and crosswalk is not None
        and (output_lineage is None or set(output_lineage.columns) >= REQUIRED_LINEAGE_COLUMNS)
    ):
        verify_insufficiency_and_risk(
            panel=normalized_panel,
            crosswalk=crosswalk,
            mapping=evidence_mapping,
            lineage_path=lineage_path,
            output_lineage=output_lineage,
            requested_years=requested_years,
            failures=failures,
        )

    if release:
        if manifest.get("release_eligible") is not True:
            failures.append("continuity manifest is not release eligible")
        if manifest.get("complete_year_scope") is not True:
            failures.append("continuity manifest lacks complete requested-year scope")

    try:
        if bundle.resolve(strict=True) != resolved_bundle:
            failures.append("continuity bundle pointer changed during verification")
    except OSError as exc:
        failures.append(f"continuity bundle pointer became unreadable: {exc}")
    final_entries = list(resolved_bundle.iterdir()) if resolved_bundle.is_dir() else []
    if {path.name for path in final_entries} != BUNDLE_FILES or any(
        not path.is_file() or path.is_symlink() for path in final_entries
    ):
        failures.append("continuity bundle inventory changed during verification")
    if not manifest_path.is_file() or sha256_file(manifest_path) != manifest_sha_before:
        failures.append("continuity manifest changed during verification")
    if panel_path is not None and panel_path.is_file():
        if sha256_file(panel_path) != manifest.get("input_sha256"):
            failures.append("continuity input changed during verification")
    if lineage_path is not None and lineage_path.is_file():
        if sha256_file(lineage_path) != manifest.get("lineage_input_sha256"):
            failures.append("Stage 06 lineage changed during verification")
    for raw_record in records:
        if not isinstance(raw_record, dict):
            continue
        name = str(raw_record.get("path", ""))
        path = resolved_bundle / name
        if Path(name).name == name and path.is_file() and sha256_file(path) != raw_record.get("sha256"):
            failures.append(f"continuity output changed during verification: {name}")
    try:
        final_git = git_state(repo)
        final_contract_id, final_contract_hashes = current_contract_hashes(repo)
        final_tools = portable_tools(tool_versions())
        if (
            final_git != git
            or final_contract_id != contract_id
            or final_contract_hashes != contract_hashes
            or final_tools != current_tools
        ):
            failures.append("repository, contracts, or tools changed during continuity verification")
    except ProvenanceError as exc:
        failures.append(f"cannot recheck release bindings after verification: {exc}")
    if isinstance(code_hashes, dict):
        for relative in REQUIRED_CODE_HASHES:
            code_path = repo / relative
            if not code_path.is_file() or sha256_file(code_path) != code_hashes.get(relative):
                failures.append(f"continuity imported code changed during verification: {relative}")
    if release:
        try:
            verify_run(
                root=root,
                repo=repo,
                required_stages=REQUIRED_CAUSAL_STAGES,
            )
            final_causal_run = resolve_run_dir(root)
            if causal_run is None or final_causal_run != causal_run:
                failures.append("authoritative causal run pointer changed during verification")
            final_causal_manifest = final_causal_run / "run_manifest.json"
            if sha256_file(final_causal_manifest) != bindings.get("causal_run_manifest_sha256"):
                failures.append("causal run manifest changed during continuity verification")
            for stage, artifact_path, recorded_sha, label in (
                ("07", panel_path, manifest.get("input_sha256"), "clean panel"),
                ("06", lineage_path, manifest.get("lineage_input_sha256"), "value lineage"),
            ):
                if artifact_path is None:
                    continue
                stage_manifest = load_manifest(final_causal_run / f"{stage}.json")
                output_metadata = stage_manifest.get("output_metadata", {})
                record = (
                    output_metadata.get(str(artifact_path.absolute()))
                    if isinstance(output_metadata, dict)
                    else None
                )
                if not isinstance(record, dict) or record.get("sha256") != recorded_sha:
                    failures.append(
                        f"Stage {stage} causal receipt changed for continuity {label}"
                    )
        except (ProvenanceError, OSError, ValueError) as exc:
            failures.append(f"cannot reverify causal continuity bindings: {exc}")
    if sha256_file(verifier_path) != verifier_sha_before:
        failures.append("continuity verifier code changed during verification")
    return {
        "bundle_path": str(bundle.relative_to(root)) if bundle.is_relative_to(root) else bundle.name,
        "continuity_manifest_path": (
            manifest_path.relative_to(root).as_posix()
            if manifest_path.is_relative_to(root)
            else manifest_path.name
        ),
        "continuity_manifest_sha256": manifest_sha_before,
        "failures": sorted(set(failures)),
        "input_bindings": {
            "panel_path": manifest.get("input_path"),
            "panel_rows": manifest.get("input_row_count"),
            "panel_schema_sha256": manifest.get("input_schema_sha256"),
            "panel_sha256": manifest.get("input_sha256"),
            "value_lineage_path": manifest.get("lineage_input_path"),
            "value_lineage_rows": manifest.get("lineage_input_row_count"),
            "value_lineage_schema_sha256": manifest.get("lineage_input_schema_sha256"),
            "value_lineage_sha256": manifest.get("lineage_input_sha256"),
        },
        "mode": mode,
        "output_bindings": records,
        "runtime_bindings": bindings,
        "run_id": str(manifest.get("run_id", "")),
        "status": "pass" if not failures else "fail",
        "verifier_path": "Scripts/QA_QC/23_verify_entity_continuity.py",
        "verifier_sha256": verifier_sha_before,
        "verifier_runtime": {
            "implementation": platform.python_implementation(),
            "python": sys.version.split()[0],
        },
    }


def main() -> int:
    args = parse_args()
    root = Path(args.root).expanduser().resolve()
    repository = Path(args.repo).expanduser().resolve() if args.repo else repo_root().resolve()
    bundle = (
        Path(args.bundle).expanduser()
        if args.bundle
        else root / "Checks" / "v2" / "entity_continuity"
    )
    try:
        report_layout = reviewed_release_layout(repository)
        canonical_report = root / str(report_layout["continuity_verification"])
    except ValueError as exc:
        print(f"Cannot resolve canonical continuity verification report: {exc}")
        return 2
    report_path = (
        Path(args.report).expanduser()
        if args.report
        else canonical_report
    )
    report_path = report_path.absolute()
    report_destination = report_path.parent.resolve() / report_path.name
    if args.mode == "release" and report_path != canonical_report:
        print(f"Release verification requires the canonical report path: {canonical_report}")
        return 2
    if args.mode == "development" and (not args.report or report_path == canonical_report):
        print("Development verification requires an explicit noncanonical report path")
        return 2
    if args.mode == "release":
        try:
            report_destination.relative_to(root.resolve())
        except ValueError:
            print("Release verification report resolves outside IPEDSDB_ROOT")
            return 2
    protected_paths = {
        repository / relative
        for relative in [*REQUIRED_CODE_HASHES, "Scripts/QA_QC/23_verify_entity_continuity.py"]
    }
    try:
        protected_layout = reviewed_release_layout(repository)
        protected_paths.update(
            {
                root / str(protected_layout["panel_input"]),
                root / str(protected_layout["lineage_input"]),
            }
        )
    except ValueError:
        pass
    if args.panel:
        protected_paths.add(Path(args.panel).expanduser().absolute())
    if args.value_lineage:
        protected_paths.add(Path(args.value_lineage).expanduser().absolute())
    if report_destination in {path.parent.resolve() / path.name for path in protected_paths}:
        print("Verification report path overlaps a protected input or code file")
        return 2
    try:
        resolved_bundle = bundle.resolve(strict=True)
    except OSError:
        resolved_bundle = None
    if resolved_bundle is not None and report_destination.is_relative_to(resolved_bundle):
        print("Verification report path overlaps the continuity bundle")
        return 2
    if report_destination.is_relative_to(repository.resolve()):
        print("Verification report cannot be written inside the source repository")
        return 2
    try:
        result = verify_bundle(
            root=root,
            repo=repository,
            bundle=bundle,
            mode=args.mode,
            panel_override=Path(args.panel).expanduser() if args.panel else None,
            lineage_override=Path(args.value_lineage).expanduser() if args.value_lineage else None,
        )
    except Exception as exc:  # fail closed while still leaving a machine-readable report
        result = {
            "bundle_path": str(bundle),
            "continuity_manifest_sha256": "",
            "failures": [f"unhandled verification error: {type(exc).__name__}: {exc}"],
            "mode": args.mode,
            "run_id": "",
            "status": "fail",
            "verifier_path": "Scripts/QA_QC/23_verify_entity_continuity.py",
            "verifier_sha256": sha256_file(Path(__file__).resolve()),
        }
    atomic_write_json(report_path, result)
    if result["status"] != "pass":
        print("Entity continuity verification failed:")
        for failure in result["failures"]:
            print(f"- {failure}")
        return 1
    print(f"Entity continuity verification passed: {bundle}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
