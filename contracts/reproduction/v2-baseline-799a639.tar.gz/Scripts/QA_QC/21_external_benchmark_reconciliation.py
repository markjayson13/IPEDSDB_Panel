#!/usr/bin/env python3
"""QA 21: reconcile the v2 panel against independently sourced benchmarks.

Release mode is fail closed and contract driven.  It requires a nonempty,
reviewable benchmark contract, the configured coverage floor, current causal
Stage 01-through-07 plus QA 00/01 provenance, and a canonical atomically
promoted evidence bundle.  Development mode permits explicit fixture paths but
cannot publish to the canonical release location.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import sys
import tomllib
import uuid
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import pandas as pd
import pyarrow.dataset as ds

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import DEFAULT_IPEDSDB_ROOT, parse_years, repo_root
from stage_provenance import ProvenanceError, resolve_run_dir, verify_run


SCHEMA_VERSION = "external-benchmark-reconciliation-v2.0"
REQUIRED_CAUSAL_STAGES = (
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "qa00",
    "qa01",
)
CANONICAL_OUTPUT = "Checks/v2/external_benchmarks/external_benchmark_reconciliation.csv"
STRICT_COLUMNS = [
    "benchmark_id",
    "contract_id",
    "artifact",
    "year",
    "metric",
    "variable",
    "filters",
    "component_family",
    "expected_value",
    "absolute_tolerance",
    "relative_tolerance",
    "tolerance_rationale",
    "official_source",
    "source_date_or_version",
    "source_evidence_path",
    "source_evidence_sha256",
    "review_status",
    "reviewer",
    "review_date",
    "definition",
    "notes",
]
LEGACY_COLUMNS = {
    "benchmark_id",
    "year",
    "metric",
    "column",
    "expected_value",
    "tolerance_abs",
    "tolerance_rel",
    "source",
    "notes",
}
OUTPUT_COLUMNS = [
    "benchmark_id",
    "contract_id",
    "artifact",
    "year",
    "metric",
    "variable",
    "filters",
    "component_family",
    "actual_value",
    "expected_value",
    "delta",
    "absolute_tolerance",
    "relative_tolerance",
    "allowed_delta",
    "status",
    "failure_reason",
    "tolerance_rationale",
    "official_source",
    "source_date_or_version",
    "source_evidence_path",
    "source_evidence_sha256",
    "review_status",
    "reviewer",
    "review_date",
    "definition",
    "notes",
    "panel_sha256",
    "benchmark_contract_sha256",
]
SUPPORTED_METRICS = {
    "panel_rows",
    "distinct_unitid",
    "distinct_count",
    "nonnull_count",
    "sum",
    "mean",
}
SHA256_RE = re.compile(r"[0-9a-f]{64}")
YEAR_SCOPE_RE = re.compile(r"(?P<start>\d{4})(?:(?::|\.\.)(?P<end>\d{4}))?")


class BenchmarkError(RuntimeError):
    """Benchmark evidence is incomplete, malformed, stale, or failing."""


def parse_args() -> argparse.Namespace:
    root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(root), help="External IPEDSDB_ROOT")
    parser.add_argument("--repo", default=None, help="Repository containing the reviewed v2 contract")
    parser.add_argument("--years", default="2004:2023")
    parser.add_argument("--panel", default=None, help="Development-only panel override")
    parser.add_argument("--benchmarks", default=None, help="Development-only benchmark-contract override")
    parser.add_argument("--out-dir", default=None, help="Development-only output directory")
    parser.add_argument("--mode", choices=("development", "release"), default=None)
    parser.add_argument(
        "--require-benchmarks",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Legacy development switch; release mode always requires benchmarks.",
    )
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_json(value: object) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def portable_relative(value: object, *, label: str) -> str:
    text = str(value or "").strip()
    path = Path(text)
    if not text or path.is_absolute() or ".." in path.parts:
        raise BenchmarkError(f"reviewed contract has a nonportable {label} path")
    return path.as_posix()


def reviewed_layout(repo: Path) -> dict[str, object]:
    spec_path = repo / "contracts" / "panel_spec.toml"
    try:
        with spec_path.open("rb") as handle:
            contract = tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise BenchmarkError(f"cannot read reviewed panel contract: {exc}") from exc
    release = contract.get("release", {})
    outputs = contract.get("outputs", {})
    policies = contract.get("policies", {})
    qa = contract.get("qa", {})
    external = contract.get("external_validation", {})
    try:
        start = int(release["start_year"])
        end = int(release["end_year"])
        contract_id = str(contract["contract_id"]).strip()
        panel = portable_relative(outputs["prch_cleaned"], label="clean-panel")
        benchmark_contract = portable_relative(
            policies["external_benchmarks"],
            label="benchmark-contract",
        )
        output = portable_relative(qa["external_benchmarks"], label="benchmark-output")
        minimum_checks = int(external["min_benchmark_checks"])
        minimum_years = int(external["min_distinct_years"])
        minimum_families = int(external["min_component_families"])
        required_families = [str(value).strip() for value in external["required_component_families"]]
    except (KeyError, TypeError, ValueError) as exc:
        raise BenchmarkError("reviewed contract lacks external-validation scope or paths") from exc
    expected_years = list(range(start, end + 1))
    if release.get("default_year_spec") != f"{start}:{end}":
        raise BenchmarkError("reviewed contract has inconsistent release years")
    if release.get("require_external_benchmarks") is not True:
        raise BenchmarkError("reviewed contract does not require external benchmarks")
    if output != CANONICAL_OUTPUT:
        raise BenchmarkError("reviewed contract has an invalid benchmark output path")
    if minimum_checks < 1 or minimum_years < 1 or minimum_families < 1:
        raise BenchmarkError("external-validation coverage floors must be positive")
    if len(required_families) != len(set(required_families)) or not all(required_families):
        raise BenchmarkError("required external-validation component families are malformed")
    return {
        "benchmark_contract": benchmark_contract,
        "contract_id": contract_id,
        "minimum_checks": minimum_checks,
        "minimum_families": minimum_families,
        "minimum_years": minimum_years,
        "output": output,
        "panel": panel,
        "required_families": required_families,
        "years": expected_years,
    }


def validate_csv_syntax(path: Path) -> list[str]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle, strict=True)
            header = next(reader)
            for _ in reader:
                pass
    except (OSError, UnicodeError, csv.Error, StopIteration) as exc:
        raise BenchmarkError(f"cannot parse benchmark contract {path}: {exc}") from exc
    if len(header) != len(set(header)):
        raise BenchmarkError("benchmark contract contains duplicate column names")
    return header


def load_benchmarks(path: Path, *, release: bool, layout: dict[str, object]) -> pd.DataFrame:
    if not path.is_file():
        raise BenchmarkError(f"benchmark contract does not exist: {path}")
    header = validate_csv_syntax(path)
    frame = pd.read_csv(path, dtype=str, keep_default_na=False)
    if release:
        if header != STRICT_COLUMNS:
            raise BenchmarkError("release benchmark contract columns or order do not match the reviewed v2 schema")
        return frame.copy()
    if header == STRICT_COLUMNS:
        return frame.copy()
    if set(header) != LEGACY_COLUMNS:
        raise BenchmarkError("development benchmark contract has an unsupported schema")
    if frame.empty:
        return pd.DataFrame(columns=STRICT_COLUMNS)
    converted = pd.DataFrame(
        {
            "benchmark_id": frame["benchmark_id"],
            "contract_id": str(layout["contract_id"]),
            "artifact": str(layout["panel"]),
            "year": frame["year"],
            "metric": frame["metric"],
            "variable": frame["column"].where(frame["column"].str.strip() != "", "UNITID"),
            "filters": "{}",
            "component_family": "development_fixture",
            "expected_value": frame["expected_value"],
            "absolute_tolerance": frame["tolerance_abs"],
            "relative_tolerance": frame["tolerance_rel"],
            "tolerance_rationale": "development fixture",
            "official_source": frame["source"],
            "source_date_or_version": "development fixture",
            "source_evidence_path": "",
            "source_evidence_sha256": "",
            "review_status": "development",
            "reviewer": "",
            "review_date": "",
            "definition": "development fixture",
            "notes": frame["notes"],
        }
    )
    return converted[STRICT_COLUMNS]


def duplicate_key_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"duplicate filter key {key!r}")
        result[key] = value
    return result


def parse_filter_object(raw: object) -> dict[str, object]:
    text = str(raw).strip()
    if not text:
        raise BenchmarkError("filters must be explicit JSON, using {} when no filter is needed")
    try:
        value = json.loads(text, object_pairs_hook=duplicate_key_object)
    except (json.JSONDecodeError, ValueError) as exc:
        raise BenchmarkError(f"filters are not valid duplicate-free JSON: {exc}") from exc
    if not isinstance(value, dict):
        raise BenchmarkError("filters must be a JSON object")
    for key, expected in value.items():
        if not isinstance(key, str) or not key.strip():
            raise BenchmarkError("filter column names must be nonblank strings")
        values = expected if isinstance(expected, list) else [expected]
        if not values and isinstance(expected, list):
            raise BenchmarkError(f"filter {key!r} has an empty allowed-value list")
        if any(isinstance(item, (dict, list)) for item in values):
            raise BenchmarkError(f"filter {key!r} contains a nested value")
        if any(isinstance(item, float) and not math.isfinite(item) for item in values):
            raise BenchmarkError(f"filter {key!r} contains a nonfinite number")
    return value


def parse_year_scope(raw: object, *, allowed_years: list[int]) -> list[int]:
    text = str(raw).strip()
    match = YEAR_SCOPE_RE.fullmatch(text)
    if match is None:
        raise BenchmarkError(f"invalid benchmark year or range: {text!r}")
    start = int(match.group("start"))
    end = int(match.group("end") or start)
    if end < start:
        raise BenchmarkError(f"descending benchmark year range: {text!r}")
    years = list(range(start, end + 1))
    if not set(years).issubset(allowed_years):
        raise BenchmarkError(f"benchmark year range is outside release scope: {text!r}")
    return years


def finite_number(raw: object, *, label: str) -> float:
    text = str(raw).strip()
    if not text:
        raise BenchmarkError(f"{label} is blank")
    try:
        value = float(text)
    except ValueError as exc:
        raise BenchmarkError(f"{label} is not numeric") from exc
    if not math.isfinite(value):
        raise BenchmarkError(f"{label} is not finite")
    return value


def validate_official_source(value: object) -> str:
    source = str(value).strip()
    parsed = urlparse(source)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise BenchmarkError("official_source must be an external HTTP(S) source")
    if (parsed.hostname or "").lower() in {"localhost", "127.0.0.1", "::1"}:
        raise BenchmarkError("official_source cannot be a local endpoint")
    return source


def portable_evidence_path(value: object, *, benchmark_id: str) -> Path:
    raw_path = str(value).strip()
    relative = Path(raw_path)
    if (
        not raw_path
        or raw_path.startswith("~")
        or "\\" in raw_path
        or re.match(r"^[A-Za-z]:", raw_path)
        or relative.is_absolute()
        or ".." in relative.parts
        or relative.as_posix() != raw_path
    ):
        raise BenchmarkError(
            f"benchmark {benchmark_id} lacks a portable source_evidence_path"
        )
    return relative


def normalized_rows(
    frame: pd.DataFrame,
    *,
    layout: dict[str, object],
    release: bool,
) -> tuple[list[dict[str, object]], set[int], set[str], set[str]]:
    rows: list[dict[str, object]] = []
    all_years: set[int] = set()
    families: set[str] = set()
    selected_columns = {"UNITID", "year"}
    if frame["benchmark_id"].astype(str).str.strip().duplicated().any():
        raise BenchmarkError("benchmark IDs must be unique")
    for index, raw_row in frame.iterrows():
        row_number = int(index) + 2
        row = {column: str(raw_row[column]).strip() for column in STRICT_COLUMNS}
        benchmark_id = row["benchmark_id"]
        if not benchmark_id:
            raise BenchmarkError(f"benchmark row {row_number} has a blank benchmark_id")
        if row["contract_id"] != layout["contract_id"]:
            raise BenchmarkError(f"benchmark {benchmark_id} is not bound to the current contract")
        if row["artifact"] != layout["panel"]:
            raise BenchmarkError(f"benchmark {benchmark_id} targets a noncanonical artifact")
        years = parse_year_scope(row["year"], allowed_years=list(layout["years"]))
        metric = row["metric"].lower()
        if metric not in SUPPORTED_METRICS:
            raise BenchmarkError(f"benchmark {benchmark_id} uses unsupported metric {metric!r}")
        variable = row["variable"]
        if not variable:
            raise BenchmarkError(f"benchmark {benchmark_id} has a blank variable")
        filters = parse_filter_object(row["filters"])
        family = row["component_family"].lower()
        if not re.fullmatch(r"[a-z][a-z0-9_]*", family):
            raise BenchmarkError(f"benchmark {benchmark_id} has an invalid component_family")
        expected = finite_number(row["expected_value"], label=f"benchmark {benchmark_id} expected_value")
        tolerance_abs = finite_number(
            row["absolute_tolerance"],
            label=f"benchmark {benchmark_id} absolute_tolerance",
        )
        tolerance_rel = finite_number(
            row["relative_tolerance"],
            label=f"benchmark {benchmark_id} relative_tolerance",
        )
        if tolerance_abs < 0 or tolerance_rel < 0:
            raise BenchmarkError(f"benchmark {benchmark_id} tolerances must be nonnegative")
        if not row["tolerance_rationale"]:
            raise BenchmarkError(f"benchmark {benchmark_id} lacks tolerance_rationale")
        if release:
            validate_official_source(row["official_source"])
        elif not row["official_source"]:
            raise BenchmarkError(f"benchmark {benchmark_id} lacks a source")
        if not row["source_date_or_version"]:
            raise BenchmarkError(f"benchmark {benchmark_id} lacks source_date_or_version")
        if release:
            portable_evidence_path(row["source_evidence_path"], benchmark_id=benchmark_id)
            if not SHA256_RE.fullmatch(row["source_evidence_sha256"]):
                raise BenchmarkError(f"benchmark {benchmark_id} lacks a source-evidence SHA-256")
            if row["review_status"].lower() != "approved" or not row["reviewer"]:
                raise BenchmarkError(f"benchmark {benchmark_id} lacks approved independent review")
            try:
                datetime.strptime(row["review_date"], "%Y-%m-%d")
            except ValueError as exc:
                raise BenchmarkError(f"benchmark {benchmark_id} has an invalid review_date") from exc
        if not row["definition"]:
            raise BenchmarkError(f"benchmark {benchmark_id} lacks a definition")
        selected_columns.add(variable)
        selected_columns.update(filters)
        all_years.update(years)
        families.add(family)
        rows.append(
            {
                **row,
                "absolute_tolerance_number": tolerance_abs,
                "expected_number": expected,
                "filter_object": filters,
                "relative_tolerance_number": tolerance_rel,
                "scope_years": years,
            }
        )
    return rows, all_years, families, selected_columns


def verify_source_evidence(
    rows: list[dict[str, object]],
    *,
    repository: Path,
) -> None:
    for row in rows:
        benchmark_id = str(row["benchmark_id"])
        relative = portable_evidence_path(
            row["source_evidence_path"],
            benchmark_id=benchmark_id,
        )
        try:
            evidence = (repository / relative).resolve(strict=True)
        except OSError as exc:
            raise BenchmarkError(
                f"benchmark {benchmark_id} source evidence is missing"
            ) from exc
        try:
            evidence.relative_to(repository.resolve())
        except ValueError as exc:
            raise BenchmarkError(
                f"benchmark {benchmark_id} source evidence resolves outside the repository"
            ) from exc
        if not evidence.is_file():
            raise BenchmarkError(f"benchmark {benchmark_id} source evidence is not a file")
        if sha256_file(evidence) != str(row["source_evidence_sha256"]):
            raise BenchmarkError(f"benchmark {benchmark_id} source evidence hash is stale")


def enforce_release_coverage(
    rows: list[dict[str, object]],
    years: set[int],
    families: set[str],
    layout: dict[str, object],
) -> None:
    failures: list[str] = []
    if len(rows) < int(layout["minimum_checks"]):
        failures.append(f"checks={len(rows)}<{layout['minimum_checks']}")
    if len(years) < int(layout["minimum_years"]):
        failures.append(f"years={len(years)}<{layout['minimum_years']}")
    if len(families) < int(layout["minimum_families"]):
        failures.append(f"families={len(families)}<{layout['minimum_families']}")
    missing_families = sorted(set(layout["required_families"]) - families)
    if missing_families:
        failures.append("missing_families=" + ",".join(missing_families))
    if failures:
        raise BenchmarkError("external benchmark coverage floor failed: " + "; ".join(failures))


def value_mask(series: pd.Series, expected: object) -> pd.Series:
    if expected is None:
        return series.isna()
    return series.eq(expected)


def filtered_subset(panel: pd.DataFrame, row: dict[str, object]) -> pd.DataFrame:
    numeric_years = pd.to_numeric(panel["year"], errors="coerce")
    mask = numeric_years.isin(row["scope_years"])
    for column, expected in row["filter_object"].items():
        values = expected if isinstance(expected, list) else [expected]
        column_mask = pd.Series(False, index=panel.index)
        for value in values:
            column_mask |= value_mask(panel[column], value)
        mask &= column_mask
    subset = panel.loc[mask]
    if subset.empty:
        raise BenchmarkError("benchmark scope selected zero panel rows")
    return subset


def metric_value(panel: pd.DataFrame, metric: str, variable: str) -> float:
    if metric == "panel_rows":
        return float(len(panel))
    if metric == "distinct_unitid":
        return float(panel["UNITID"].nunique(dropna=True))
    if metric == "distinct_count":
        return float(panel[variable].nunique(dropna=True))
    if metric == "nonnull_count":
        return float(panel[variable].notna().sum())
    source = panel[variable]
    numeric = pd.to_numeric(source, errors="coerce")
    invalid_nonnull = source.notna() & numeric.isna()
    if invalid_nonnull.any():
        raise BenchmarkError(
            f"numeric metric encountered {int(invalid_nonnull.sum())} invalid nonnull tokens"
        )
    if metric == "sum":
        value = numeric.sum(skipna=True, min_count=1)
    elif metric == "mean":
        value = numeric.mean(skipna=True)
    else:  # pragma: no cover - normalized_rows pins the metric set.
        raise BenchmarkError(f"unsupported metric {metric!r}")
    if pd.isna(value) or not math.isfinite(float(value)):
        raise BenchmarkError("metric produced no finite value")
    return float(value)


def evaluate(
    panel: pd.DataFrame,
    rows: list[dict[str, object]],
    *,
    panel_sha: str,
    benchmark_sha: str,
) -> list[dict[str, object]]:
    results: list[dict[str, object]] = []
    for row in rows:
        failure = ""
        actual: float | str = ""
        delta: float | str = ""
        allowed: float | str = ""
        try:
            subset = filtered_subset(panel, row)
            actual = metric_value(subset, str(row["metric"]).lower(), str(row["variable"]))
            expected = float(row["expected_number"])
            delta = actual - expected
            allowed = max(
                float(row["absolute_tolerance_number"]),
                abs(expected) * float(row["relative_tolerance_number"]),
            )
            if abs(delta) > allowed:
                failure = "observed value exceeds the reviewed tolerance"
        except (BenchmarkError, KeyError, TypeError, ValueError) as exc:
            failure = str(exc)
        results.append(
            {
                "benchmark_id": row["benchmark_id"],
                "contract_id": row["contract_id"],
                "artifact": row["artifact"],
                "year": row["year"],
                "metric": row["metric"],
                "variable": row["variable"],
                "filters": row["filters"],
                "component_family": row["component_family"],
                "actual_value": actual,
                "expected_value": row["expected_value"],
                "delta": delta,
                "absolute_tolerance": row["absolute_tolerance"],
                "relative_tolerance": row["relative_tolerance"],
                "allowed_delta": allowed,
                "status": "FAIL" if failure else "PASS",
                "failure_reason": failure,
                "tolerance_rationale": row["tolerance_rationale"],
                "official_source": row["official_source"],
                "source_date_or_version": row["source_date_or_version"],
                "source_evidence_path": row["source_evidence_path"],
                "source_evidence_sha256": row["source_evidence_sha256"],
                "review_status": row["review_status"],
                "reviewer": row["reviewer"],
                "review_date": row["review_date"],
                "definition": row["definition"],
                "notes": row["notes"],
                "panel_sha256": panel_sha,
                "benchmark_contract_sha256": benchmark_sha,
            }
        )
    return results


def render_markdown(results: list[dict[str, object]], summary: dict[str, object]) -> str:
    lines = [
        "# External Benchmark Reconciliation",
        "",
        f"- status: `{summary['status']}`",
        f"- mode: `{summary['mode']}`",
        f"- benchmark checks: `{summary['benchmark_count']}`",
        f"- distinct years: `{summary['distinct_year_count']}`",
        f"- component families: `{summary['component_family_count']}`",
        "",
        "| Benchmark | Status | Year | Metric | Variable | Actual | Expected | Source |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for row in results:
        lines.append(
            "| {benchmark_id} | {status} | {year} | {metric} | {variable} | "
            "{actual_value} | {expected_value} | {official_source} |".format(**row)
        )
    lines.append("")
    return "\n".join(lines)


def write_payload(directory: Path, results: list[dict[str, object]], summary: dict[str, object]) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(results, columns=OUTPUT_COLUMNS)
    frame.to_csv(directory / "external_benchmark_reconciliation.csv", index=False)
    (directory / "external_benchmark_reconciliation.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    (directory / "external_benchmark_reconciliation.md").write_text(
        render_markdown(results, summary),
        encoding="utf-8",
    )


def publish_release_bundle(
    pointer: Path,
    results: list[dict[str, object]],
    summary: dict[str, object],
) -> Path:
    if pointer.exists() and not pointer.is_symlink():
        raise BenchmarkError(f"canonical benchmark output is not an atomic managed pointer: {pointer}")
    pointer.parent.mkdir(parents=True, exist_ok=True)
    runs = pointer.parent / f".{pointer.name}.runs"
    if runs.is_symlink():
        raise BenchmarkError(f"managed benchmark run store cannot be a symlink: {runs}")
    runs.mkdir(parents=True, exist_ok=True)
    run_id = str(summary["run_id"])
    final = runs / run_id
    staging = runs / f".{run_id}.staging-{uuid.uuid4().hex}"
    try:
        write_payload(staging, results, summary)
        if final.exists():
            expected = {
                path.name: sha256_file(path)
                for path in staging.iterdir()
                if path.is_file()
            }
            observed = {
                path.name: sha256_file(path)
                for path in final.iterdir()
                if path.is_file()
            }
            if expected != observed:
                raise BenchmarkError(f"content-addressed benchmark run already exists with drift: {run_id}")
            shutil.rmtree(staging)
        else:
            os.replace(staging, final)
        temporary_pointer = pointer.parent / f".{pointer.name}.pointer-{uuid.uuid4().hex}"
        target = os.path.relpath(final, pointer.parent)
        os.symlink(target, temporary_pointer)
        os.replace(temporary_pointer, pointer)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return final


def write_development_bundle(
    directory: Path,
    results: list[dict[str, object]],
    summary: dict[str, object],
) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    for name in (
        "external_benchmark_reconciliation.csv",
        "external_benchmark_reconciliation.json",
        "external_benchmark_reconciliation.md",
    ):
        temporary = directory / f".{name}.{uuid.uuid4().hex}.part"
        staging = directory / f".{name}.staging-{uuid.uuid4().hex}"
        staging.mkdir()
        write_payload(staging, results, summary)
        shutil.move(staging / name, temporary)
        os.replace(temporary, directory / name)
        shutil.rmtree(staging)
    return directory


def verify_stage07_binding(root: Path, panel_path: Path, panel_sha: str) -> tuple[str, str]:
    run_dir = resolve_run_dir(root)
    manifest_path = run_dir / "07.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BenchmarkError(f"cannot read Stage 07 causal receipt: {exc}") from exc
    outputs = manifest.get("output_metadata", {})
    record = outputs.get(str(panel_path.absolute())) if isinstance(outputs, dict) else None
    if not isinstance(record, dict) or record.get("sha256") != panel_sha:
        raise BenchmarkError("Stage 07 causal receipt does not bind the benchmark panel")
    run_manifest = run_dir / "run_manifest.json"
    try:
        portable_run = run_dir.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise BenchmarkError("causal run resolves outside IPEDSDB_ROOT") from exc
    return portable_run, sha256_file(run_manifest)


def main() -> int:
    args = parse_args()
    root = Path(args.root).expanduser().resolve()
    repository = Path(args.repo).expanduser().resolve() if args.repo else repo_root().resolve()
    try:
        layout = reviewed_layout(repository)
        inferred_development = any((args.panel, args.benchmarks, args.out_dir))
        mode = args.mode or ("development" if inferred_development else "release")
        release = mode == "release"
        if release and inferred_development:
            raise BenchmarkError("release mode does not permit panel, benchmark, or output overrides")
        requested_years = parse_years(args.years)
        if release and requested_years != layout["years"]:
            raise BenchmarkError("release benchmark years do not match the reviewed contract")
        panel_path = Path(args.panel).expanduser().resolve() if args.panel else root / str(layout["panel"])
        benchmark_path = (
            Path(args.benchmarks).expanduser().resolve()
            if args.benchmarks
            else repository / str(layout["benchmark_contract"])
        )
        output_dir = (
            Path(args.out_dir).expanduser().resolve()
            if args.out_dir
            else root / Path(str(layout["output"])).parent
        )
        canonical_output_dir = root / Path(str(layout["output"])).parent
        if release and output_dir != canonical_output_dir:
            raise BenchmarkError("release benchmark output is not canonical")
        if not release and output_dir == canonical_output_dir:
            raise BenchmarkError("development mode cannot publish canonical benchmark evidence")
        if not panel_path.is_file():
            raise BenchmarkError(f"benchmark panel does not exist: {panel_path}")

        code_path = Path(__file__).resolve()
        code_sha_before = sha256_file(code_path)
        contract_sha_before = sha256_file(repository / "contracts" / "panel_spec.toml")
        benchmark_sha_before = sha256_file(benchmark_path)
        panel_sha_before = sha256_file(panel_path)
        causal_run = ""
        causal_manifest_sha = ""
        if release:
            try:
                verify_run(
                    root=root,
                    repo=repository,
                    required_stages=REQUIRED_CAUSAL_STAGES,
                )
            except ProvenanceError as exc:
                raise BenchmarkError(str(exc)) from exc
            causal_run, causal_manifest_sha = verify_stage07_binding(
                root,
                panel_path,
                panel_sha_before,
            )

        benchmarks = load_benchmarks(benchmark_path, release=release, layout=layout)
        if benchmarks.empty:
            if release or args.require_benchmarks:
                raise BenchmarkError("zero configured external benchmarks cannot pass release mode")
            results = [
                {
                    **{column: "" for column in OUTPUT_COLUMNS},
                    "benchmark_id": "no_benchmarks_configured",
                    "status": "REVIEW",
                    "failure_reason": "External benchmarks are not configured.",
                    "official_source": str(benchmark_path),
                    "panel_sha256": panel_sha_before,
                    "benchmark_contract_sha256": benchmark_sha_before,
                }
            ]
            covered_years: set[int] = set()
            families: set[str] = set()
        else:
            normalized, covered_years, families, selected_columns = normalized_rows(
                benchmarks,
                layout=layout,
                release=release,
            )
            if release:
                enforce_release_coverage(normalized, covered_years, families, layout)
                verify_source_evidence(normalized, repository=repository)
            dataset = ds.dataset(str(panel_path), format="parquet")
            missing_columns = sorted(selected_columns - set(dataset.schema.names))
            if missing_columns:
                raise BenchmarkError(
                    "benchmark variables or filters are absent from the panel: "
                    + ", ".join(missing_columns)
                )
            panel = dataset.to_table(columns=sorted(selected_columns)).to_pandas()
            results = evaluate(
                panel,
                normalized,
                panel_sha=panel_sha_before,
                benchmark_sha=benchmark_sha_before,
            )
            if release and any(row["status"] != "PASS" for row in results):
                raise BenchmarkError("one or more required external benchmarks failed")

        result_statuses = [str(row["status"]) for row in results]
        status = "pass" if results and set(result_statuses) == {"PASS"} else "review"
        run_id = sha256_json(
            {
                "benchmark_contract_sha256": benchmark_sha_before,
                "code_sha256": code_sha_before,
                "contract_sha256": contract_sha_before,
                "causal_run": causal_run,
                "causal_run_manifest_sha256": causal_manifest_sha,
                "mode": mode,
                "panel_sha256": panel_sha_before,
                "results": results,
                "years": requested_years,
            }
        )[:24]
        summary = {
            "benchmark_contract_path": (
                benchmark_path.relative_to(repository).as_posix()
                if benchmark_path.is_relative_to(repository)
                else benchmark_path.name
            ),
            "benchmark_contract_sha256": benchmark_sha_before,
            "benchmark_count": 0 if benchmarks.empty else len(results),
            "causal_run": causal_run,
            "causal_run_manifest_sha256": causal_manifest_sha,
            "component_families": sorted(families),
            "component_family_count": len(families),
            "contract_id": layout["contract_id"],
            "contract_sha256": contract_sha_before,
            "distinct_year_count": len(covered_years),
            "mode": mode,
            "panel_path": (
                panel_path.relative_to(root).as_posix()
                if panel_path.is_relative_to(root)
                else panel_path.name
            ),
            "panel_sha256": panel_sha_before,
            "required_component_families": layout["required_families"],
            "result_statuses": result_statuses,
            "run_id": run_id,
            "schema_version": SCHEMA_VERSION,
            "status": status,
            "verifier_path": "Scripts/QA_QC/21_external_benchmark_reconciliation.py",
            "verifier_sha256": code_sha_before,
            "years": requested_years,
        }

        if release:
            try:
                verify_run(
                    root=root,
                    repo=repository,
                    required_stages=REQUIRED_CAUSAL_STAGES,
                )
            except ProvenanceError as exc:
                raise BenchmarkError(str(exc)) from exc
            final_causal_run, final_causal_sha = verify_stage07_binding(
                root,
                panel_path,
                panel_sha_before,
            )
            if final_causal_run != causal_run or final_causal_sha != causal_manifest_sha:
                raise BenchmarkError("causal run changed during benchmark reconciliation")
        for path, expected, label in (
            (code_path, code_sha_before, "benchmark verifier"),
            (repository / "contracts" / "panel_spec.toml", contract_sha_before, "panel contract"),
            (benchmark_path, benchmark_sha_before, "benchmark contract"),
            (panel_path, panel_sha_before, "benchmark panel"),
        ):
            if sha256_file(path) != expected:
                raise BenchmarkError(f"{label} changed during benchmark reconciliation")

        if release:
            published = publish_release_bundle(output_dir, results, summary)
        else:
            published = write_development_bundle(output_dir, results, summary)
        print(f"Wrote external benchmark reconciliation to {published}")
        return 0
    except (BenchmarkError, OSError, ValueError) as exc:
        print(f"External benchmark reconciliation failed: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
