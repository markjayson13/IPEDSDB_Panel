#!/usr/bin/env python3
"""QA 01: reconcile a PRCH-cleaned panel with its authoritative run evidence.

Release QA fails closed.  It accepts only the managed Stage 07 run pointer and
proves that the bound policy, raw/clean panels, summaries, observed-code ledger,
and cell-action ledger describe the same transformation.  The legacy broad
policy remains available only through explicit ``--qa-mode development`` and
can never produce a release-passing status.

Release outputs (normally below ``Checks/v2/panel_qc``):

* ``panel_qa_summary.csv``
* ``panel_qa_coverage_matrix.csv``
* ``panel_qa_by_flag_code.csv``
* ``panel_qa_action_reconciliation.csv``
* ``panel_qa_evidence_checks.csv``
"""
from __future__ import annotations

import argparse
import csv
from collections import defaultdict
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Callable, Iterable, Iterator
import uuid

import duckdb
import pandas as pd
import pyarrow as pa
import pyarrow.dataset as ds
import pyarrow.parquet as pq

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import DEFAULT_IPEDSDB_ROOT
from prch_policy import (
    PrchPolicyContract,
    PrchPolicyRule,
    classify_flag_code,
    cleaned_child_codes,
    get_policy,
    load_policy_contract,
    review_only_codes,
)


QA_SCHEMA_VERSION = "2.0"
QA_RUN_MANIFEST = "panel_qa_run_manifest.json"
QA_OUTPUT_FILES = (
    "panel_qa_summary.csv",
    "panel_qa_coverage_matrix.csv",
    "panel_qa_by_flag_code.csv",
    "panel_qa_action_reconciliation.csv",
    "panel_qa_evidence_checks.csv",
)
_PREVIOUS_POINTER_UNSET = object()
ACTION_COLUMNS = [
    "year",
    "UNITID",
    "flag",
    "code",
    "column",
    "old_value",
    "new_value",
    "action",
    "rule_id",
    "accounting_standard",
    "form",
    "part",
    "row_predicate",
]
ACTION_SCHEMA = pa.schema(
    [
        pa.field("year", pa.int64(), nullable=False),
        pa.field("UNITID", pa.int64(), nullable=False),
        pa.field("flag", pa.string(), nullable=False),
        pa.field("code", pa.int64(), nullable=False),
        pa.field("column", pa.string(), nullable=False),
        pa.field("old_value", pa.string(), nullable=False),
        pa.field("new_value", pa.string()),
        pa.field("action", pa.string(), nullable=False),
        pa.field("rule_id", pa.string(), nullable=False),
        pa.field("accounting_standard", pa.string(), nullable=False),
        pa.field("form", pa.string(), nullable=False),
        pa.field("part", pa.string(), nullable=False),
        pa.field("row_predicate", pa.string(), nullable=False),
    ]
)
ACTUAL_CHANGE_SCHEMA = pa.schema(
    [
        pa.field("year", pa.int64(), nullable=False),
        pa.field("UNITID", pa.int64(), nullable=False),
        pa.field("column", pa.string(), nullable=False),
        pa.field("raw_value", pa.string()),
        pa.field("clean_value", pa.string()),
        pa.field("raw_missing", pa.bool_(), nullable=False),
        pa.field("clean_missing", pa.bool_(), nullable=False),
    ]
)
POLICY_COLUMNS = [
    "rule_id",
    "year_start",
    "year_end",
    "flag",
    "code",
    "action",
    "target_columns",
    "row_predicate",
    "accounting_standard",
    "form",
    "part",
    "review_status",
    "source_reference",
    "rationale",
]
CODE_EVIDENCE_COLUMNS = [
    "year",
    "flag",
    "code",
    "policy_bucket",
    "target_columns",
    "has_target_columns",
    "rows",
    "rule_id",
    "policy_mode",
]
CLEAN_SUMMARY_COLUMNS = [
    "year",
    "flag",
    "policy_mode",
    "child_codes_applied",
    "review_only_codes",
    "target_columns",
    "has_target_columns",
    "lineage_source",
    "child_rows_cleaned",
    "cells_cleaned",
    "review_only_rows",
]
REQUIRED_RUN_ARTIFACTS = {
    "panel_clean.parquet",
    "prch_current_run.json",
    "prch_run_manifest.json",
    "prch_cell_actions.parquet",
    "prch_clean_summary.csv",
    "prch_flag_code_counts.csv",
    "prch_flag_policy.csv",
}


class PanelQAError(RuntimeError):
    """Raised when PRCH QA evidence is incomplete or inconsistent."""


def setup_logging(log_path: str | None) -> None:
    if not log_path:
        return
    log_file = Path(log_path)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    stream = log_file.open("a", buffering=1)

    class Tee:
        def __init__(self, *streams: object):
            self.streams = streams

        def write(self, data: str) -> None:
            for item in self.streams:
                item.write(data)

        def flush(self) -> None:
            for item in self.streams:
                item.flush()

    sys.stdout = Tee(sys.stdout, stream)
    sys.stderr = Tee(sys.stderr, stream)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", required=True, help="Raw stitched analysis-wide parquet")
    parser.add_argument("--clean", required=True, help="PRCH-cleaned parquet or managed panel alias")
    data_root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    checks_v2 = data_root / "Checks" / "v2"
    parser.add_argument("--out-dir", default=str(checks_v2 / "panel_qc"), help="QA output directory")
    parser.add_argument(
        "--prch-qc-dir",
        default=str(checks_v2 / "prch_qc"),
        help="Managed Stage 07 run pointer in release mode; development QC directory otherwise",
    )
    parser.add_argument(
        "--prch-policy",
        default=str(Path(__file__).resolve().parents[2] / "contracts" / "prch_policy.csv"),
        help="Authoritative reviewed PRCH policy bound by the Stage 07 manifest",
    )
    parser.add_argument(
        "--qa-mode",
        choices=("release", "development"),
        default="release",
        help="Release is fail-closed; development is explicitly non-release-eligible",
    )
    parser.add_argument("--flag", default="ALL", help='Development only: flag, comma list, or "ALL"')
    parser.add_argument(
        "--flag-child",
        default="AUTO",
        help='Development only: child codes for a single flag, or "AUTO"',
    )
    parser.add_argument("--batch-rows", type=int, default=2_000, help="Streaming comparison batch size")
    parser.add_argument(
        "--action-reconciliation-mode",
        choices=("python", "duckdb"),
        default="python",
        help=(
            "Cell-action reconciliation backend. The default preserves the historical "
            "in-memory behavior; duckdb writes bounded ledgers and reconciles them on disk."
        ),
    )
    parser.add_argument(
        "--action-temp-dir",
        default=None,
        help="Parent directory for temporary disk-backed action ledgers and DuckDB spill files.",
    )
    parser.add_argument(
        "--action-buffer-rows",
        type=int,
        default=10_000,
        help="Maximum action rows buffered before a disk-backed parquet flush.",
    )
    parser.add_argument(
        "--duckdb-memory-limit",
        default=None,
        help="Optional DuckDB memory limit for disk-backed action reconciliation.",
    )
    parser.add_argument(
        "--duckdb-threads",
        type=int,
        default=None,
        help="Optional DuckDB worker-thread limit for disk-backed action reconciliation.",
    )
    parser.add_argument("--year-sep", default="|", help="Separator for year lists in CSV")
    parser.add_argument(
        "--excel-text",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Prefix year lists with an apostrophe for Excel text",
    )
    parser.add_argument(
        "--log-file",
        default=str(checks_v2 / "logs" / "01_panel_qa.log"),
        help="Optional log file path",
    )
    args = parser.parse_args()
    if args.batch_rows <= 0:
        parser.error("--batch-rows must be positive")
    if args.action_buffer_rows <= 0:
        parser.error("--action-buffer-rows must be positive")
    if args.duckdb_threads is not None and args.duckdb_threads <= 0:
        parser.error("--duckdb-threads must be positive")
    return args


def format_years(years: Iterable[object], sep: str, excel_text: bool) -> str:
    values = sorted(int(year) for year in years if pd.notna(year))
    rendered = sep.join(str(year) for year in values)
    return "'" + rendered if excel_text else rendered


def resolve_child_codes(flag: str, value: str) -> set[int]:
    """Retained for explicit development-mode compatibility."""

    if (value or "").strip().upper() == "AUTO":
        return cleaned_child_codes(flag)
    return {int(item) for item in value.split(",") if item.strip()}


def resolve_requested_flags(flag_arg: str, raw_schema_names: list[str], clean_schema_names: list[str]) -> list[str]:
    available = sorted(
        {
            str(column).upper()
            for column in set(raw_schema_names) | set(clean_schema_names)
            if str(column).upper().startswith("PRCH")
        }
    )
    spec = (flag_arg or "ALL").strip().upper()
    if spec in {"ALL", "*", "AUTO"}:
        return available
    requested = [part.strip().upper() for part in spec.split(",") if part.strip()]
    return [flag for flag in requested if flag in available]


def load_target_columns_map(prch_qc_dir: Path, schema_names: list[str]) -> dict[str, list[str]]:
    path = prch_qc_dir / "prch_clean_columns.csv"
    if not path.exists():
        return {}
    frame = pd.read_csv(path, dtype=str).fillna("")
    if "flag" not in frame.columns or "column" not in frame.columns:
        return {}
    schema_set = set(schema_names)
    output: dict[str, list[str]] = {}
    for flag, group in frame.groupby(frame["flag"].astype(str).str.upper()):
        output[flag] = sorted(
            {str(column).strip() for column in group["column"] if str(column).strip() in schema_set}
        )
    return output


def aggregate_target_nonnull_by_code(
    dataset: ds.Dataset,
    flag: str,
    target_cols: list[str],
    batch_rows: int,
) -> dict[int, dict[str, int]]:
    if flag not in dataset.schema.names:
        return {}
    scan_cols = [flag, *(column for column in target_cols if column in dataset.schema.names)]
    output: dict[int, dict[str, int]] = {}
    for batch in dataset.to_batches(columns=scan_cols, batch_size=batch_rows):
        frame = batch.to_pandas()
        flag_values = pd.to_numeric(frame[flag], errors="coerce")
        for code, count in flag_values.dropna().astype(int).value_counts().items():
            item = output.setdefault(int(code), {"rows": 0, "target_nonnull": 0})
            item["rows"] += int(count)
            mask = flag_values.eq(int(code))
            if target_cols and mask.any():
                item["target_nonnull"] += int(frame.loc[mask, target_cols].notna().sum().sum())
    return output


def determine_flag_status(
    *,
    child_rows_raw: int,
    review_rows_raw: int,
    target_columns: int,
    clean_target_nonnull: int,
) -> tuple[str, str]:
    """Legacy diagnostic status used only by explicit development QA."""

    if child_rows_raw > 0 and target_columns == 0:
        return "no_targets", "Child rows were observed but no target columns were configured for this flag."
    if child_rows_raw > 0 and clean_target_nonnull > 0:
        return "suspicious", "Targeted child-row cells remained non-null after cleaning."
    if child_rows_raw > 0:
        return "cleaned", "Observed child rows were cleaned across the targeted column family."
    if review_rows_raw > 0:
        return "review_only", "Only review-only codes were observed for this flag."
    if target_columns == 0:
        return "no_targets", "No target columns were configured and no child rows were observed."
    return "cleaned", "No child rows were observed for this flag."


def build_coverage_row(
    *,
    flag: str,
    child_codes: set[int],
    review_codes: set[int],
    target_cols: list[str],
    raw_code_stats: dict[int, dict[str, int]],
    clean_code_stats: dict[int, dict[str, int]],
) -> dict[str, object]:
    observed_codes = sorted(set(raw_code_stats) | set(clean_code_stats))
    child_rows_raw = sum(raw_code_stats.get(code, {}).get("rows", 0) for code in child_codes)
    child_rows_clean = sum(clean_code_stats.get(code, {}).get("rows", 0) for code in child_codes)
    raw_target_nonnull = sum(raw_code_stats.get(code, {}).get("target_nonnull", 0) for code in child_codes)
    clean_target_nonnull = sum(clean_code_stats.get(code, {}).get("target_nonnull", 0) for code in child_codes)
    review_rows_raw = sum(raw_code_stats.get(code, {}).get("rows", 0) for code in review_codes)
    review_rows_clean = sum(clean_code_stats.get(code, {}).get("rows", 0) for code in review_codes)
    review_target_nonnull_raw = sum(
        raw_code_stats.get(code, {}).get("target_nonnull", 0) for code in review_codes
    )
    review_target_nonnull_clean = sum(
        clean_code_stats.get(code, {}).get("target_nonnull", 0) for code in review_codes
    )
    status, reason = determine_flag_status(
        child_rows_raw=child_rows_raw,
        review_rows_raw=review_rows_raw,
        target_columns=len(target_cols),
        clean_target_nonnull=clean_target_nonnull,
    )
    policy = get_policy(flag)
    return {
        "flag": flag,
        "observed_codes": ",".join(str(code) for code in observed_codes),
        "child_codes": ",".join(str(code) for code in sorted(child_codes)),
        "review_only_codes": ",".join(str(code) for code in sorted(review_codes)),
        "policy_target_source_files": ",".join(policy.target_source_files),
        "policy_target_source_prefixes": ",".join(policy.target_source_prefixes),
        "child_rows_raw": child_rows_raw,
        "child_rows_clean": child_rows_clean,
        "review_rows_raw": review_rows_raw,
        "review_rows_clean": review_rows_clean,
        "target_columns": len(target_cols),
        "raw_target_nonnull": raw_target_nonnull,
        "clean_target_nonnull": clean_target_nonnull,
        "review_target_nonnull_raw": review_target_nonnull_raw,
        "review_target_nonnull_clean": review_target_nonnull_clean,
        "status": status,
        "status_reason": reason,
        "rationale": policy.rationale,
        "release_status": "not_release",
    }


def build_code_rows(
    flag: str,
    raw_code_stats: dict[int, dict[str, int]],
    clean_code_stats: dict[int, dict[str, int]],
) -> list[dict[str, object]]:
    return [
        {
            "flag": flag,
            "code": code,
            "policy_bucket": classify_flag_code(flag, code),
            "raw_rows": raw_code_stats.get(code, {}).get("rows", 0),
            "clean_rows": clean_code_stats.get(code, {}).get("rows", 0),
            "raw_target_nonnull": raw_code_stats.get(code, {}).get("target_nonnull", 0),
            "clean_target_nonnull": clean_code_stats.get(code, {}).get("target_nonnull", 0),
            "status": "development_only",
        }
        for code in sorted(set(raw_code_stats) | set(clean_code_stats))
    ]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_path_tree(path: Path) -> str:
    """Hash a parquet file or a deterministic directory-backed dataset."""

    resolved = path.resolve(strict=True)
    if resolved.is_file():
        return sha256_file(resolved)
    if not resolved.is_dir():
        raise PanelQAError(f"Cannot hash non-file dataset input: {path}")
    files = sorted(item for item in resolved.rglob("*") if item.is_file())
    if not files:
        raise PanelQAError(f"Dataset input directory contains no files: {path}")
    digest = hashlib.sha256()
    for item in files:
        relative = item.relative_to(resolved).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(str(item.stat().st_size).encode("ascii"))
        digest.update(b"\0")
        digest.update(sha256_file(item).encode("ascii"))
        digest.update(b"\n")
    return digest.hexdigest()


def key_fingerprint(keys: Iterable[tuple[int, int]]) -> str:
    digest = hashlib.sha256()
    for year, unitid in sorted(keys):
        digest.update(f"{year},{unitid}\n".encode("ascii"))
    return digest.hexdigest()


def _reject_duplicate_json_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    output: dict[str, object] = {}
    for key, value in pairs:
        if key in output:
            raise PanelQAError(f"JSON evidence repeats key {key!r}")
        output[key] = value
    return output


def read_json_object(path: Path) -> dict[str, object]:
    if not path.exists() or not path.is_file():
        raise PanelQAError(f"Missing JSON evidence: {path}")
    if path.stat().st_size == 0:
        raise PanelQAError(f"JSON evidence is empty: {path}")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=_reject_duplicate_json_keys)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PanelQAError(f"Invalid JSON evidence {path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise PanelQAError(f"JSON evidence must be an object: {path}")
    return payload


def _path_size(path: Path) -> int:
    return path.stat().st_size if path.is_file() else 0


def validate_structural_integrity(
    raw_path: Path,
    clean_path: Path,
) -> tuple[ds.Dataset, ds.Dataset, list[tuple[int, int]], list[int]]:
    if not raw_path.exists():
        raise PanelQAError(f"Raw panel does not exist: {raw_path}")
    if not clean_path.exists():
        raise PanelQAError(f"Clean panel does not exist: {clean_path}")
    raw = ds.dataset(str(raw_path), format="parquet")
    clean = ds.dataset(str(clean_path), format="parquet")
    if not raw.schema.equals(clean.schema, check_metadata=False):
        raise PanelQAError(
            "Raw/clean exact schema equality failed: "
            f"raw={raw.schema} clean={clean.schema}"
        )
    if raw.schema.names != clean.schema.names:
        raise PanelQAError("Raw/clean column order differs")
    for key in ("year", "UNITID"):
        if key not in raw.schema.names:
            raise PanelQAError(f"Raw/clean panels are missing key column {key}")
        if not pa.types.is_integer(raw.schema.field(key).type):
            raise PanelQAError(f"{key} must have an integer Arrow type")

    raw_keys = raw.to_table(columns=["year", "UNITID"]).to_pandas()
    clean_keys = clean.to_table(columns=["year", "UNITID"]).to_pandas()
    if len(raw_keys) != len(clean_keys):
        raise PanelQAError(
            f"Raw/clean row equality failed: raw={len(raw_keys)} clean={len(clean_keys)}"
        )
    for label, frame in (("raw", raw_keys), ("clean", clean_keys)):
        if frame[["year", "UNITID"]].isna().any().any():
            raise PanelQAError(f"{label} panel contains null year/UNITID keys")
        duplicated = frame.duplicated(["year", "UNITID"], keep=False)
        if duplicated.any():
            examples = frame.loc[duplicated, ["year", "UNITID"]].head(5).to_dict("records")
            raise PanelQAError(f"{label} panel contains duplicate year/UNITID keys: {examples}")
    raw_pairs = [(int(year), int(unitid)) for year, unitid in raw_keys.itertuples(index=False, name=None)]
    clean_pairs = [
        (int(year), int(unitid)) for year, unitid in clean_keys.itertuples(index=False, name=None)
    ]
    if raw_pairs != clean_pairs:
        raise PanelQAError("Raw/clean exact key equality and order failed")
    years = sorted({year for year, _unitid in raw_pairs})
    if not years:
        raise PanelQAError("Raw/clean panels contain no rows")
    return raw, clean, raw_pairs, years


def resolve_managed_run(pointer: Path, clean_path: Path) -> Path:
    if not pointer.is_symlink():
        raise PanelQAError(
            f"Release QA requires an authoritative managed PRCH run pointer symlink: {pointer}"
        )
    try:
        run_dir = pointer.resolve(strict=True)
    except FileNotFoundError as exc:
        raise PanelQAError(f"Managed PRCH run pointer is broken: {pointer}") from exc
    expected_store = (pointer.parent / f"{pointer.name}_runs").resolve()
    if not run_dir.is_dir() or run_dir.parent != expected_store:
        raise PanelQAError(
            f"Managed PRCH run pointer targets an invalid run store: {pointer} -> {run_dir}"
        )
    managed_panel = run_dir / "panel_clean.parquet"
    if not managed_panel.is_file():
        raise PanelQAError(f"Managed PRCH run is missing panel_clean.parquet: {run_dir}")
    if not clean_path.is_symlink():
        raise PanelQAError(
            f"Release clean panel must be the managed Stage 07 panel symlink: {clean_path}"
        )
    if clean_path.resolve(strict=True) != managed_panel.resolve(strict=True):
        raise PanelQAError(
            f"Clean panel does not follow the authoritative managed run: {clean_path}"
        )
    return run_dir


def validate_manifest(
    run_dir: Path,
    pointer: Path,
    raw_path: Path,
    clean_path: Path,
    policy_path: Path,
    raw: ds.Dataset,
    clean: ds.Dataset,
    keys: list[tuple[int, int]],
) -> tuple[dict[str, object], list[dict[str, str]]]:
    manifest_path = run_dir / "prch_run_manifest.json"
    manifest = read_json_object(manifest_path)
    required = {
        "schema_version",
        "run_id",
        "status",
        "policy_mode",
        "input",
        "output",
        "row_count",
        "key_sha256",
        "input_schema",
        "output_schema",
        "policy_path",
        "policy_sha256",
        "artifacts",
    }
    missing = required - set(manifest)
    if missing:
        raise PanelQAError(f"PRCH run manifest is missing fields: {', '.join(sorted(missing))}")
    if manifest["schema_version"] != "1.0":
        raise PanelQAError(f"Unsupported PRCH run manifest schema: {manifest['schema_version']!r}")
    if manifest["status"] != "complete" or manifest["policy_mode"] != "release":
        raise PanelQAError(
            "Release QA requires prch_run_manifest status=complete and policy_mode=release"
        )
    run_id = str(manifest["run_id"])
    if run_id != run_dir.name:
        raise PanelQAError(f"PRCH run_id does not match managed run directory: {run_id!r}")
    try:
        manifest_input = Path(str(manifest["input"])).resolve(strict=True)
        manifest_output = Path(str(manifest["output"])).resolve(strict=True)
        manifest_policy = Path(str(manifest["policy_path"])).resolve(strict=True)
    except FileNotFoundError as exc:
        raise PanelQAError(f"PRCH manifest binds a missing path: {exc.filename}") from exc
    if manifest_input != raw_path.resolve(strict=True):
        raise PanelQAError("PRCH manifest input path does not match --raw")
    if manifest_output != clean_path.resolve(strict=True):
        raise PanelQAError("PRCH manifest output path does not match --clean")
    if manifest_policy != policy_path.resolve(strict=True):
        raise PanelQAError("PRCH manifest policy_path does not match --prch-policy")
    policy_hash = sha256_file(policy_path)
    if str(manifest["policy_sha256"]) != policy_hash:
        raise PanelQAError("PRCH policy hash differs from the policy hash bound by the run manifest")
    if int(manifest["row_count"]) != len(keys):
        raise PanelQAError("PRCH manifest row_count does not match the raw/clean panels")
    if str(manifest["key_sha256"]) != key_fingerprint(keys):
        raise PanelQAError("PRCH manifest key_sha256 does not match exact panel keys")
    if str(manifest["input_schema"]) != str(raw.schema):
        raise PanelQAError("PRCH manifest input_schema does not match the raw panel")
    if str(manifest["output_schema"]) != str(clean.schema):
        raise PanelQAError("PRCH manifest output_schema does not match the clean panel")

    artifacts = manifest["artifacts"]
    if not isinstance(artifacts, list) or not artifacts:
        raise PanelQAError("PRCH run manifest artifacts must be a nonempty list")
    records: list[dict[str, str]] = []
    seen: set[str] = set()
    for raw_record in artifacts:
        if not isinstance(raw_record, dict):
            raise PanelQAError("PRCH run manifest artifact records must be objects")
        if set(raw_record) != {"name", "bytes", "sha256"}:
            raise PanelQAError("PRCH run manifest artifact records require name, bytes, and sha256")
        name = str(raw_record["name"])
        if not name or Path(name).name != name or name in seen:
            raise PanelQAError(f"Invalid or duplicate PRCH manifest artifact name: {name!r}")
        seen.add(name)
        artifact_path = run_dir / name
        if not artifact_path.is_file() or artifact_path.is_symlink():
            raise PanelQAError(f"PRCH manifest artifact is missing or not immutable: {artifact_path}")
        size = artifact_path.stat().st_size
        if size <= 0:
            raise PanelQAError(f"PRCH manifest artifact is empty: {artifact_path}")
        if int(raw_record["bytes"]) != size:
            raise PanelQAError(f"PRCH manifest byte count mismatch for {name}")
        actual_hash = sha256_file(artifact_path)
        if str(raw_record["sha256"]) != actual_hash:
            raise PanelQAError(f"PRCH manifest sha256 mismatch for {name}")
        records.append({"name": name, "bytes": str(size), "sha256": actual_hash})
    listed_with_manifest = seen | {manifest_path.name}
    missing_required = REQUIRED_RUN_ARTIFACTS - listed_with_manifest
    if missing_required:
        raise PanelQAError(
            "Managed PRCH run is missing required evidence: " + ", ".join(sorted(missing_required))
        )
    actual_files = {path.name for path in run_dir.iterdir() if path.is_file()}
    if actual_files != listed_with_manifest:
        missing_files = sorted(listed_with_manifest - actual_files)
        unlisted_files = sorted(actual_files - listed_with_manifest)
        raise PanelQAError(
            f"PRCH manifest artifact inventory is not exact; missing={missing_files} unlisted={unlisted_files}"
        )

    current = read_json_object(run_dir / "prch_current_run.json")
    if current.get("schema_version") != "1.0" or current.get("status") != "complete":
        raise PanelQAError("prch_current_run.json is not a complete supported run pointer receipt")
    if str(current.get("run_id")) != run_id:
        raise PanelQAError("prch_current_run.json run_id does not match the manifest")
    if Path(str(current.get("run_path"))).resolve() != run_dir:
        raise PanelQAError("prch_current_run.json run_path does not match the managed pointer")
    if Path(str(current.get("panel"))).resolve() != (run_dir / "panel_clean.parquet").resolve():
        raise PanelQAError("prch_current_run.json panel does not match the managed panel")
    if pointer.resolve(strict=True) != run_dir:
        raise PanelQAError("PRCH run pointer changed during QA")
    records.append(
        {
            "name": manifest_path.name,
            "bytes": str(manifest_path.stat().st_size),
            "sha256": sha256_file(manifest_path),
        }
    )
    return manifest, records


def verify_run_snapshot(
    pointer: Path,
    run_dir: Path,
    policy_path: Path,
    policy_sha256: str,
    artifact_records: list[dict[str, str]],
) -> None:
    """Close the pointer/artifact time-of-check-to-time-of-use window."""

    if not pointer.is_symlink() or pointer.resolve(strict=True) != run_dir:
        raise PanelQAError("Authoritative managed PRCH run pointer changed during QA")
    if sha256_file(policy_path) != policy_sha256:
        raise PanelQAError("Authoritative PRCH policy bytes changed during QA")
    for record in artifact_records:
        path = run_dir / record["name"]
        if not path.is_file() or path.is_symlink():
            raise PanelQAError(f"Managed PRCH run artifact changed during QA: {path}")
        if str(path.stat().st_size) != record["bytes"] or sha256_file(path) != record["sha256"]:
            raise PanelQAError(f"Managed PRCH run artifact changed during QA: {path.name}")


def contract_policy_records(contract: PrchPolicyContract) -> list[dict[str, str]]:
    return [
        {
            "rule_id": rule.rule_id,
            "year_start": str(rule.year_start),
            "year_end": str(rule.year_end),
            "flag": rule.flag,
            "code": str(rule.code),
            "action": rule.action,
            "target_columns": "|".join(rule.target_columns),
            "row_predicate": rule.row_predicate_json,
            "accounting_standard": rule.accounting_standard,
            "form": rule.form,
            "part": rule.part,
            "review_status": rule.review_status,
            "source_reference": rule.source_reference,
            "rationale": rule.rationale,
        }
        for rule in contract.rules
    ]


def read_exact_csv(path: Path, expected_columns: list[str], label: str) -> list[dict[str, str]]:
    if not path.is_file() or path.stat().st_size == 0:
        raise PanelQAError(f"{label} evidence is missing or empty: {path}")
    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            columns = reader.fieldnames or []
            if columns != expected_columns or len(columns) != len(set(columns)):
                raise PanelQAError(
                    f"{label} evidence has an unexpected schema: expected={expected_columns} actual={columns}"
                )
            rows = [dict(row) for row in reader]
    except UnicodeDecodeError as exc:
        raise PanelQAError(f"{label} evidence is not strict UTF-8: {path}") from exc
    return rows


def compare_exact_records(
    actual: list[dict[str, str]],
    expected: list[dict[str, str]],
    label: str,
) -> None:
    if actual == expected:
        return
    limit = min(len(actual), len(expected))
    mismatch = next((index for index in range(limit) if actual[index] != expected[index]), None)
    if mismatch is not None:
        raise PanelQAError(
            f"{label} evidence does not match the exact contract-resolved records at row {mismatch + 2}: "
            f"expected={expected[mismatch]} actual={actual[mismatch]}"
        )
    raise PanelQAError(
        f"{label} evidence row count differs from exact contract-resolved records: "
        f"expected={len(expected)} actual={len(actual)}"
    )


def _parse_integral_code(value: object, *, year: int, flag: str, unitid: int) -> int:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        raise PanelQAError("Internal error: missing code passed to integral parser")
    try:
        numeric = float(str(value).strip())
    except ValueError as exc:
        raise PanelQAError(
            f"Unmatched/malformed PRCH code at year={year} UNITID={unitid} flag={flag}: {value!r}"
        ) from exc
    if not math.isfinite(numeric) or not numeric.is_integer():
        raise PanelQAError(
            f"Unmatched/malformed PRCH code at year={year} UNITID={unitid} flag={flag}: {value!r}"
        )
    return int(numeric)


def is_missing(value: object) -> bool:
    if value is None:
        return True
    try:
        result = pd.isna(value)
        return bool(result) if not isinstance(result, (list, tuple)) else False
    except (TypeError, ValueError):
        return False


def values_equal(left: object, right: object) -> bool:
    if is_missing(left) and is_missing(right):
        return True
    if is_missing(left) or is_missing(right):
        return False
    try:
        result = left == right
        return bool(result)
    except (TypeError, ValueError):
        return False


class BoundedParquetLedgerWriter:
    """Write a fixed-schema parquet ledger without retaining the full ledger."""

    def __init__(self, path: Path, schema: pa.Schema, *, buffer_rows: int) -> None:
        if buffer_rows < 1:
            raise ValueError("buffer_rows must be positive")
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.schema = schema
        self.buffer_rows = int(buffer_rows)
        self.writer = pq.ParquetWriter(path, schema, compression="snappy")
        self.columns: dict[str, list[object]] = {field.name: [] for field in schema}
        self.rows_written = 0

    def append(self, record: dict[str, object]) -> None:
        for field in self.schema:
            self.columns[field.name].append(record.get(field.name))
        if len(self.columns[self.schema.names[0]]) >= self.buffer_rows:
            self.flush()

    def flush(self) -> None:
        row_count = len(self.columns[self.schema.names[0]])
        if row_count == 0:
            return
        self.writer.write_table(pa.Table.from_pydict(self.columns, schema=self.schema))
        self.rows_written += row_count
        self.columns = {field.name: [] for field in self.schema}

    def close(self) -> None:
        self.flush()
        self.writer.close()

    def __enter__(self) -> "BoundedParquetLedgerWriter":
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()


def sql_quote(value: object) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def open_action_duckdb(
    workspace: Path,
    *,
    memory_limit: str | None,
    threads: int | None,
) -> duckdb.DuckDBPyConnection:
    """Open one disk-backed action-reconciliation connection with external spill."""
    workspace.mkdir(parents=True, exist_ok=True)
    spill = workspace / "duckdb_spill"
    spill.mkdir(parents=True, exist_ok=True)
    con = duckdb.connect(str(workspace / "panel_qa_actions.duckdb"))
    try:
        con.execute("SET preserve_insertion_order=false")
        con.execute(f"SET temp_directory={sql_quote(spill)}")
        if memory_limit:
            con.execute(f"SET memory_limit={sql_quote(memory_limit)}")
        if threads is not None:
            con.execute(f"SET threads={int(threads)}")
    except BaseException:
        con.close()
        raise
    return con


def scan_expected_release_actions(
    raw: ds.Dataset,
    contract: PrchPolicyContract,
    years: list[int],
    *,
    batch_rows: int,
    action_ledger_path: Path | None = None,
    action_buffer_rows: int = 10_000,
) -> dict[str, object]:
    schema_names = raw.schema.names
    upper_to_names: dict[str, list[str]] = defaultdict(list)
    for name in schema_names:
        upper_to_names[name.upper()].append(name)
    collisions = [names for names in upper_to_names.values() if len(names) > 1]
    if collisions:
        raise PanelQAError(f"Case-insensitive panel column collisions prevent policy resolution: {collisions}")
    lookup = {upper: names[0] for upper, names in upper_to_names.items()}
    flags = [name for name in schema_names if name.upper().startswith("PRCH")]
    if not flags:
        raise PanelQAError("Release QA found no PRCH flags")
    noncanonical_flags = [flag for flag in flags if flag != flag.upper()]
    if noncanonical_flags:
        raise PanelQAError(
            "Release PRCH flags must use canonical uppercase names: "
            + ", ".join(noncanonical_flags)
        )
    year_set = set(years)
    scoped_rules = [
        rule
        for rule in contract.rules
        if any(rule.year_start <= year <= rule.year_end for year in year_set)
    ]
    scoped_flags = {rule.flag for rule in scoped_rules}
    missing_contract_flags = sorted(set(flag.upper() for flag in flags) - scoped_flags)
    missing_panel_flags = sorted(scoped_flags - set(flag.upper() for flag in flags))
    if missing_contract_flags or missing_panel_flags:
        raise PanelQAError(
            "PRCH policy/panel flag coverage is unmatched: "
            f"panel_without_policy={missing_contract_flags} policy_without_panel={missing_panel_flags}"
        )
    for rule in scoped_rules:
        missing_predicates = sorted(column for column in rule.predicate_columns if column not in lookup)
        missing_targets = sorted(column for column in rule.target_columns if column not in schema_names)
        if missing_predicates or missing_targets:
            raise PanelQAError(
                f"PRCH rule {rule.rule_id} has unresolved columns: "
                f"predicates={missing_predicates} targets={missing_targets}"
            )
        if rule.action == "null" and not rule.target_columns:
            raise PanelQAError(f"PRCH rule {rule.rule_id} has no_targets for a null action")

    needed = {"year", "UNITID", *flags}
    needed.update(lookup[column] for rule in scoped_rules for column in rule.predicate_columns)
    needed.update(column for rule in scoped_rules for column in rule.target_columns)
    scan_columns = [name for name in schema_names if name in needed]
    expected_actions: dict[tuple[int, int, str], dict[str, object]] | None = (
        {} if action_ledger_path is None else None
    )
    code_counts: dict[tuple[int, str, int], int] = defaultdict(int)
    rule_rows: dict[tuple[int, str, int, str], int] = defaultdict(int)
    action_groups: dict[tuple[int, str, int, str, str, str], int] = defaultdict(int)
    action_counts: dict[tuple[int, str, int], int] = defaultdict(int)
    action_flags: set[str] = set()
    expected_action_count = 0
    ledger = (
        BoundedParquetLedgerWriter(
            action_ledger_path,
            ACTION_SCHEMA,
            buffer_rows=action_buffer_rows,
        )
        if action_ledger_path is not None
        else None
    )
    try:
        for batch in raw.to_batches(columns=scan_columns, batch_size=batch_rows):
            values = batch.to_pydict()
            for index in range(batch.num_rows):
                year = int(values["year"][index])
                unitid = int(values["UNITID"][index])
                row_mapping = {name.upper(): values[name][index] for name in scan_columns}
                for flag in flags:
                    raw_code = values[flag][index]
                    if is_missing(raw_code) or str(raw_code).strip() == "":
                        continue
                    code = _parse_integral_code(raw_code, year=year, flag=flag, unitid=unitid)
                    code_counts[(year, flag, code)] += 1
                    candidates = contract.matching_rules(year, flag, code)
                    if not candidates:
                        raise PanelQAError(
                            f"Unmatched PRCH observation: year={year} UNITID={unitid} flag={flag} code={code}"
                        )
                    matching = [rule for rule in candidates if rule.matches_mapping(row_mapping)]
                    if len(matching) != 1:
                        state = "unmatched" if not matching else "ambiguous"
                        raise PanelQAError(
                            f"PRCH predicate resolution is {state}: year={year} UNITID={unitid} "
                            f"flag={flag} code={code} candidates={[rule.rule_id for rule in candidates]}"
                        )
                    rule = matching[0]
                    rule_rows[(year, flag, code, rule.rule_id)] += 1
                    if rule.action != "null":
                        continue
                    for column in rule.target_columns:
                        old_value = values[column][index]
                        if is_missing(old_value):
                            continue
                        cell_key = (year, unitid, column)
                        expected = {
                            "year": year,
                            "UNITID": unitid,
                            "flag": rule.flag,
                            "code": code,
                            "column": column,
                            "old_value": str(old_value),
                            "new_value": None,
                            "action": "null",
                            "rule_id": rule.rule_id,
                            "accounting_standard": rule.accounting_standard,
                            "form": rule.form,
                            "part": rule.part,
                            "row_predicate": rule.row_predicate_json,
                        }
                        if expected_actions is not None:
                            if cell_key in expected_actions:
                                previous = expected_actions[cell_key]
                                raise PanelQAError(
                                    f"Multiple PRCH rules expect the same cell change {cell_key}: "
                                    f"{previous['rule_id']} and {rule.rule_id}"
                                )
                            expected_actions[cell_key] = expected
                        else:
                            assert ledger is not None
                            ledger.append(expected)
                        expected_action_count += 1
                        action_counts[(year, rule.flag, code)] += 1
                        action_flags.add(rule.flag)
                        group_key = (
                            year,
                            rule.flag,
                            code,
                            rule.rule_id,
                            rule.row_predicate_json,
                            column,
                        )
                        action_groups[group_key] += 1
    finally:
        if ledger is not None:
            ledger.close()
    return {
        "flags": flags,
        "scoped_rules": scoped_rules,
        "expected_actions": expected_actions,
        "code_counts": code_counts,
        "rule_rows": rule_rows,
        "action_groups": action_groups,
        "action_counts": action_counts,
        "action_flags": action_flags,
        "expected_action_count": expected_action_count,
        "action_ledger_path": action_ledger_path,
    }


def expected_code_evidence(
    contract: PrchPolicyContract,
    code_counts: dict[tuple[int, str, int], int],
) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    for (year, flag, code), count in sorted(code_counts.items()):
        rules = contract.matching_rules(year, flag, code)
        if not rules:
            raise PanelQAError(f"Unmatched PRCH code-count evidence key: {(year, flag, code)}")
        actions = {rule.action for rule in rules}
        bucket = next(iter(actions)) if len(actions) == 1 else "predicate_scoped"
        targets = {column for rule in rules for column in rule.target_columns}
        if "null" in actions and not targets:
            raise PanelQAError(f"no_targets for observed PRCH null policy: {(year, flag, code)}")
        output.append(
            {
                "year": str(year),
                "flag": flag,
                "code": str(code),
                "policy_bucket": bucket,
                "target_columns": str(len(targets)),
                "has_target_columns": str(bool(targets)),
                "rows": str(count),
                "rule_id": "|".join(sorted(rule.rule_id for rule in rules)),
                "policy_mode": "release",
            }
        )
    if not output:
        raise PanelQAError("prch_flag_code_counts evidence would be empty; no observed PRCH codes")
    return output


def expected_clean_summary(
    contract: PrchPolicyContract,
    years: list[int],
    flags: list[str],
    rule_rows: dict[tuple[int, str, int, str], int],
    action_groups: dict[tuple[int, str, int, str, str, str], int],
) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    for year in years:
        for flag in flags:
            rules = [
                rule
                for rule in contract.rules
                if rule.flag == flag and rule.year_start <= year <= rule.year_end
            ]
            null_rules = [rule for rule in rules if rule.action == "null"]
            targets = {column for rule in rules for column in rule.target_columns}
            child_rows = sum(
                rule_rows.get((year, flag, rule.code, rule.rule_id), 0) for rule in null_rules
            )
            cells = sum(
                count
                for (group_year, group_flag, _code, _rule_id, _predicate, _column), count in action_groups.items()
                if group_year == year and group_flag == flag
            )
            if child_rows > 0 and not targets:
                raise PanelQAError(f"no_targets in PRCH clean summary for year={year} flag={flag}")
            output.append(
                {
                    "year": str(year),
                    "flag": flag,
                    "policy_mode": "release",
                    "child_codes_applied": ",".join(
                        str(code) for code in sorted({rule.code for rule in null_rules})
                    ),
                    "review_only_codes": "",
                    "target_columns": str(len(targets)),
                    "has_target_columns": str(bool(targets)),
                    "lineage_source": "column_lineage",
                    "child_rows_cleaned": str(child_rows),
                    "cells_cleaned": str(cells),
                    "review_only_rows": "0",
                }
            )
    return output


def reconcile_action_evidence(
    path: Path,
    expected_actions: dict[tuple[int, int, str], dict[str, object]],
    expected_groups: dict[tuple[int, str, int, str, str, str], int],
) -> tuple[list[dict[str, object]], int]:
    if not path.is_file() or path.stat().st_size == 0:
        raise PanelQAError(f"prch_cell_actions evidence is missing or empty: {path}")
    table = pq.read_table(path)
    if table.column_names != ACTION_COLUMNS:
        raise PanelQAError(
            f"prch_cell_actions has an unexpected schema: expected={ACTION_COLUMNS} actual={table.column_names}"
        )
    if table.num_rows == 0:
        raise PanelQAError("prch_cell_actions evidence is empty; release QA requires nonempty change evidence")
    frame = table.to_pandas()
    actual_keys: set[tuple[int, int, str]] = set()
    actual_groups: dict[tuple[int, str, int, str, str, str], int] = defaultdict(int)
    for row_number, row in enumerate(frame.to_dict("records"), start=1):
        cell_key = (int(row["year"]), int(row["UNITID"]), str(row["column"]))
        if cell_key in actual_keys:
            raise PanelQAError(f"prch_cell_actions contains a duplicate cell action: {cell_key}")
        actual_keys.add(cell_key)
        expected = expected_actions.get(cell_key)
        if expected is None:
            raise PanelQAError(f"prch_cell_actions row {row_number} has no exact raw-to-clean change: {cell_key}")
        if not is_missing(row["new_value"]):
            raise PanelQAError(f"prch_cell_actions row {row_number} new_value must be null")
        for field in ACTION_COLUMNS:
            if field == "new_value":
                continue
            actual_value = str(row[field])
            expected_value = str(expected[field])
            if actual_value != expected_value:
                raise PanelQAError(
                    f"prch_cell_actions row {row_number} {field} mismatch: "
                    f"expected={expected_value!r} actual={actual_value!r}"
                )
        group_key = (
            int(row["year"]),
            str(row["flag"]),
            int(row["code"]),
            str(row["rule_id"]),
            str(row["row_predicate"]),
            str(row["column"]),
        )
        actual_groups[group_key] += 1
    if actual_keys != set(expected_actions):
        missing = sorted(set(expected_actions) - actual_keys)[:10]
        extra = sorted(actual_keys - set(expected_actions))[:10]
        raise PanelQAError(f"prch_cell_actions cell set is inconsistent; missing={missing} extra={extra}")
    if dict(actual_groups) != dict(expected_groups):
        raise PanelQAError(
            "prch_cell_actions grouped counts do not reconcile by "
            "year/flag/code/rule/predicate/column"
        )
    reconciliation = [
        {
            "year": key[0],
            "flag": key[1],
            "code": key[2],
            "rule_id": key[3],
            "row_predicate": key[4],
            "column": key[5],
            "expected_changes": expected_groups.get(key, 0),
            "recorded_actions": actual_groups.get(key, 0),
            "status": "pass",
            "status_reason": "Exact raw-to-null action count and policy identity reconciled.",
        }
        for key in sorted(set(expected_groups) | set(actual_groups))
    ]
    return reconciliation, len(frame)


def reconcile_action_evidence_duckdb(
    con: duckdb.DuckDBPyConnection,
    actual_path: Path,
    expected_path: Path,
    expected_groups: dict[tuple[int, str, int, str, str, str], int],
) -> tuple[list[dict[str, object]], int]:
    """Reconcile full action ledgers with bounded DuckDB operators."""
    if not actual_path.is_file() or actual_path.stat().st_size == 0:
        raise PanelQAError(f"prch_cell_actions evidence is missing or empty: {actual_path}")
    actual_schema = pq.ParquetFile(actual_path).schema_arrow
    if actual_schema.names != ACTION_COLUMNS:
        raise PanelQAError(
            f"prch_cell_actions has an unexpected schema: expected={ACTION_COLUMNS} actual={actual_schema.names}"
        )
    con.execute(
        f"CREATE OR REPLACE VIEW expected_actions AS SELECT * FROM read_parquet({sql_quote(expected_path)})"
    )
    con.execute(
        f"CREATE OR REPLACE VIEW recorded_actions AS SELECT * FROM read_parquet({sql_quote(actual_path)})"
    )
    action_key_join = """
        TRY_CAST(a.year AS BIGINT) = e.year
        AND TRY_CAST(a.UNITID AS BIGINT) = e.UNITID
        AND CAST(a."column" AS VARCHAR) = CAST(e."column" AS VARCHAR)
    """
    expected_rows = int(con.execute("SELECT COUNT(*) FROM expected_actions").fetchone()[0])
    actual_rows = int(con.execute("SELECT COUNT(*) FROM recorded_actions").fetchone()[0])
    if actual_rows == 0:
        raise PanelQAError("prch_cell_actions evidence is empty; release QA requires nonempty change evidence")

    duplicate_expected = con.execute(
        """
        SELECT year, UNITID, "column", MIN(rule_id), MAX(rule_id), COUNT(*)
        FROM expected_actions
        GROUP BY year, UNITID, "column"
        HAVING COUNT(*) > 1
        ORDER BY year, UNITID, "column"
        LIMIT 1
        """
    ).fetchone()
    if duplicate_expected is not None:
        cell_key = tuple(duplicate_expected[:3])
        raise PanelQAError(
            f"Multiple PRCH rules expect the same cell change {cell_key}: "
            f"{duplicate_expected[3]} and {duplicate_expected[4]}"
        )
    duplicate_actual = con.execute(
        """
        SELECT year, UNITID, "column", COUNT(*)
        FROM recorded_actions
        GROUP BY year, UNITID, "column"
        HAVING COUNT(*) > 1
        ORDER BY year, UNITID, "column"
        LIMIT 1
        """
    ).fetchone()
    if duplicate_actual is not None:
        raise PanelQAError(
            "prch_cell_actions contains a duplicate cell action: "
            f"{tuple(duplicate_actual[:3])}"
        )
    nonnull_new = con.execute(
        """
        SELECT year, UNITID, "column"
        FROM recorded_actions
        WHERE new_value IS NOT NULL
        ORDER BY year, UNITID, "column"
        LIMIT 1
        """
    ).fetchone()
    if nonnull_new is not None:
        raise PanelQAError(
            f"prch_cell_actions cell {tuple(nonnull_new)} new_value must be null"
        )

    extra = con.execute(
        f"""
        SELECT a.year, a.UNITID, a."column"
        FROM recorded_actions AS a
        LEFT JOIN expected_actions AS e
          ON {action_key_join}
        WHERE e.rule_id IS NULL
        ORDER BY a.year, a.UNITID, a."column"
        LIMIT 1
        """
    ).fetchone()
    if extra is not None:
        raise PanelQAError(f"prch_cell_actions row has no exact raw-to-clean change: {tuple(extra)}")

    # Match the historical Python backend exactly: every recorded field except
    # new_value is compared by its rendered value.  In particular, do not let
    # DuckDB's join/comparison coercions make numeric-looking string lexemes
    # such as "02022" or "03" equivalent to their canonical integer values.
    comparable_fields = [field for field in ACTION_COLUMNS if field != "new_value"]
    for field in comparable_fields:
        quoted = '"' + field.replace('"', '""') + '"'
        mismatch = con.execute(
            f"""
            SELECT a.year, a.UNITID, a."column", a.{quoted}, e.{quoted}
            FROM recorded_actions AS a
            JOIN expected_actions AS e
              ON {action_key_join}
            WHERE CAST(a.{quoted} AS VARCHAR)
                  IS DISTINCT FROM CAST(e.{quoted} AS VARCHAR)
            ORDER BY a.year, a.UNITID, a."column"
            LIMIT 1
            """
        ).fetchone()
        if mismatch is not None:
            raise PanelQAError(
                f"prch_cell_actions cell {tuple(mismatch[:3])} {field} mismatch: "
                f"expected={mismatch[4]!r} actual={mismatch[3]!r}"
            )

    missing = con.execute(
        f"""
        SELECT e.year, e.UNITID, e."column"
        FROM expected_actions AS e
        LEFT JOIN recorded_actions AS a
          ON {action_key_join}
        WHERE a.rule_id IS NULL
        ORDER BY e.year, e.UNITID, e."column"
        LIMIT 10
        """
    ).fetchall()
    if missing or actual_rows != expected_rows:
        raise PanelQAError(
            "prch_cell_actions cell set is inconsistent; "
            f"missing={[tuple(row) for row in missing]} expected_rows={expected_rows} actual_rows={actual_rows}"
        )

    actual_groups = {
        (int(year), str(flag), int(code), str(rule_id), str(predicate), str(column)): int(count)
        for year, flag, code, rule_id, predicate, column, count in con.execute(
            """
            SELECT year, flag, code, rule_id, row_predicate, "column", COUNT(*)
            FROM recorded_actions
            GROUP BY year, flag, code, rule_id, row_predicate, "column"
            """
        ).fetchall()
    }
    if actual_groups != expected_groups:
        raise PanelQAError(
            "prch_cell_actions grouped counts do not reconcile by "
            "year/flag/code/rule/predicate/column"
        )
    reconciliation = [
        {
            "year": key[0],
            "flag": key[1],
            "code": key[2],
            "rule_id": key[3],
            "row_predicate": key[4],
            "column": key[5],
            "expected_changes": expected_groups.get(key, 0),
            "recorded_actions": actual_groups.get(key, 0),
            "status": "pass",
            "status_reason": "Exact raw-to-null action count and policy identity reconciled.",
        }
        for key in sorted(set(expected_groups) | set(actual_groups))
    ]
    return reconciliation, actual_rows


def aligned_batches(
    raw: ds.Dataset,
    clean: ds.Dataset,
    *,
    batch_rows: int,
) -> Iterator[tuple[pa.RecordBatch, pa.RecordBatch]]:
    raw_iter = iter(raw.to_batches(batch_size=batch_rows))
    clean_iter = iter(clean.to_batches(batch_size=batch_rows))
    raw_batch = next(raw_iter, None)
    clean_batch = next(clean_iter, None)
    raw_offset = clean_offset = 0
    while raw_batch is not None and clean_batch is not None:
        count = min(raw_batch.num_rows - raw_offset, clean_batch.num_rows - clean_offset)
        yield raw_batch.slice(raw_offset, count), clean_batch.slice(clean_offset, count)
        raw_offset += count
        clean_offset += count
        if raw_offset == raw_batch.num_rows:
            raw_batch = next(raw_iter, None)
            raw_offset = 0
        if clean_offset == clean_batch.num_rows:
            clean_batch = next(clean_iter, None)
            clean_offset = 0
    if raw_batch is not None or clean_batch is not None:
        raise PanelQAError("Raw/clean streaming row boundaries did not reconcile")


def write_actual_changes_ledger(
    raw: ds.Dataset,
    clean: ds.Dataset,
    path: Path,
    *,
    batch_rows: int,
    action_buffer_rows: int,
) -> int:
    """Write every raw/clean difference to a bounded temporary ledger."""
    names = raw.schema.names
    year_index = names.index("year")
    unitid_index = names.index("UNITID")
    with BoundedParquetLedgerWriter(
        path,
        ACTUAL_CHANGE_SCHEMA,
        buffer_rows=action_buffer_rows,
    ) as ledger:
        for raw_batch, clean_batch in aligned_batches(raw, clean, batch_rows=batch_rows):
            years = raw_batch.column(year_index).to_pylist()
            unitids = raw_batch.column(unitid_index).to_pylist()
            for column_index, column in enumerate(names):
                raw_array = raw_batch.column(column_index)
                clean_array = clean_batch.column(column_index)
                if raw_array.equals(clean_array):
                    continue
                raw_values = raw_array.to_pylist()
                clean_values = clean_array.to_pylist()
                for row_index, (raw_value, clean_value) in enumerate(zip(raw_values, clean_values)):
                    if values_equal(raw_value, clean_value):
                        continue
                    raw_missing = is_missing(raw_value)
                    clean_missing = is_missing(clean_value)
                    ledger.append(
                        {
                            "year": int(years[row_index]),
                            "UNITID": int(unitids[row_index]),
                            "column": column,
                            "raw_value": None if raw_missing else str(raw_value),
                            "clean_value": None if clean_missing else str(clean_value),
                            "raw_missing": raw_missing,
                            "clean_missing": clean_missing,
                        }
                    )
        return ledger.rows_written + len(ledger.columns[ledger.schema.names[0]])


def validate_exact_value_changes_duckdb(
    con: duckdb.DuckDBPyConnection,
    actual_changes_path: Path,
) -> int:
    """Compare the bounded raw/clean difference ledger to expected actions."""
    con.execute(
        f"CREATE OR REPLACE VIEW actual_changes AS SELECT * FROM read_parquet({sql_quote(actual_changes_path)})"
    )
    unexpected = con.execute(
        """
        SELECT c.year, c.UNITID, c."column", c.raw_value, c.clean_value
        FROM actual_changes AS c
        LEFT JOIN expected_actions AS e
          ON c.year = e.year AND c.UNITID = e.UNITID AND c."column" = e."column"
        WHERE e.rule_id IS NULL
        ORDER BY c.year, c.UNITID, c."column"
        LIMIT 1
        """
    ).fetchone()
    if unexpected is not None:
        raise PanelQAError(
            f"Unaffected value changed outside prch_cell_actions at {tuple(unexpected[:3])}: "
            f"raw={unexpected[3]!r} clean={unexpected[4]!r}"
        )
    invalid_transition = con.execute(
        """
        SELECT c.year, c.UNITID, c."column", c.raw_value, c.clean_value
        FROM actual_changes AS c
        JOIN expected_actions AS e
          ON c.year = e.year AND c.UNITID = e.UNITID AND c."column" = e."column"
        WHERE c.raw_missing OR NOT c.clean_missing
        ORDER BY c.year, c.UNITID, c."column"
        LIMIT 1
        """
    ).fetchone()
    if invalid_transition is not None:
        raise PanelQAError(
            f"PRCH change is not an exact old-to-null transition at {tuple(invalid_transition[:3])}: "
            f"raw={invalid_transition[3]!r} clean={invalid_transition[4]!r}"
        )
    old_mismatch = con.execute(
        """
        SELECT c.year, c.UNITID, c."column", c.raw_value, e.old_value
        FROM actual_changes AS c
        JOIN expected_actions AS e
          ON c.year = e.year AND c.UNITID = e.UNITID AND c."column" = e."column"
        WHERE c.raw_value IS DISTINCT FROM e.old_value
        ORDER BY c.year, c.UNITID, c."column"
        LIMIT 1
        """
    ).fetchone()
    if old_mismatch is not None:
        raise PanelQAError(
            f"Raw old_value differs from prch_cell_actions at {tuple(old_mismatch[:3])}: "
            f"raw={old_mismatch[3]!r} action={old_mismatch[4]!r}"
        )
    missing = con.execute(
        """
        SELECT e.year, e.UNITID, e."column"
        FROM expected_actions AS e
        LEFT JOIN actual_changes AS c
          ON c.year = e.year AND c.UNITID = e.UNITID AND c."column" = e."column"
        WHERE c."column" IS NULL
        ORDER BY e.year, e.UNITID, e."column"
        LIMIT 10
        """
    ).fetchall()
    actual_count = int(con.execute("SELECT COUNT(*) FROM actual_changes").fetchone()[0])
    expected_count = int(con.execute("SELECT COUNT(*) FROM expected_actions").fetchone()[0])
    if missing or actual_count != expected_count:
        raise PanelQAError(
            "Exact raw-to-clean cell changes do not reconcile; "
            f"missing={[tuple(row) for row in missing]} expected={expected_count} actual={actual_count}"
        )
    return actual_count


def validate_exact_value_changes(
    raw: ds.Dataset,
    clean: ds.Dataset,
    expected_actions: dict[tuple[int, int, str], dict[str, object]],
    *,
    batch_rows: int,
) -> int:
    actual_changes: set[tuple[int, int, str]] = set()
    names = raw.schema.names
    year_index = names.index("year")
    unitid_index = names.index("UNITID")
    for raw_batch, clean_batch in aligned_batches(raw, clean, batch_rows=batch_rows):
        years = raw_batch.column(year_index).to_pylist()
        unitids = raw_batch.column(unitid_index).to_pylist()
        for column_index, column in enumerate(names):
            raw_array = raw_batch.column(column_index)
            clean_array = clean_batch.column(column_index)
            if raw_array.equals(clean_array):
                continue
            raw_values = raw_array.to_pylist()
            clean_values = clean_array.to_pylist()
            for row_index, (raw_value, clean_value) in enumerate(zip(raw_values, clean_values)):
                if values_equal(raw_value, clean_value):
                    continue
                cell_key = (int(years[row_index]), int(unitids[row_index]), column)
                expected = expected_actions.get(cell_key)
                if expected is None:
                    raise PanelQAError(
                        f"Unaffected value changed outside prch_cell_actions at {cell_key}: "
                        f"raw={raw_value!r} clean={clean_value!r}"
                    )
                if is_missing(raw_value) or not is_missing(clean_value):
                    raise PanelQAError(
                        f"PRCH change is not an exact old-to-null transition at {cell_key}: "
                        f"raw={raw_value!r} clean={clean_value!r}"
                    )
                if str(raw_value) != str(expected["old_value"]):
                    raise PanelQAError(
                        f"Raw old_value differs from prch_cell_actions at {cell_key}: "
                        f"raw={raw_value!r} action={expected['old_value']!r}"
                    )
                actual_changes.add(cell_key)
    if actual_changes != set(expected_actions):
        missing = sorted(set(expected_actions) - actual_changes)[:10]
        extra = sorted(actual_changes - set(expected_actions))[:10]
        raise PanelQAError(f"Exact raw-to-clean cell changes do not reconcile; missing={missing} extra={extra}")
    return len(actual_changes)


def build_release_coverage(
    rules: list[PrchPolicyRule],
    years: list[int],
    rule_rows: dict[tuple[int, str, int, str], int],
    action_groups: dict[tuple[int, str, int, str, str, str], int],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for year in years:
        for rule in rules:
            if not rule.year_start <= year <= rule.year_end:
                continue
            changed = sum(
                count
                for (group_year, _flag, _code, group_rule, _predicate, _column), count in action_groups.items()
                if group_year == year and group_rule == rule.rule_id
            )
            rows.append(
                {
                    "year": year,
                    "flag": rule.flag,
                    "code": rule.code,
                    "rule_id": rule.rule_id,
                    "policy_action": rule.action,
                    "row_predicate": rule.row_predicate_json,
                    "target_columns": "|".join(rule.target_columns),
                    "observed_rows": rule_rows.get((year, rule.flag, rule.code, rule.rule_id), 0),
                    "expected_changes": changed,
                    "status": "pass",
                    "status_reason": "Observed rows and exact policy resolution reconciled.",
                }
            )
    return rows


def build_release_code_rows(
    expected_records: list[dict[str, str]],
    expected_actions: dict[tuple[int, int, str], dict[str, object]] | None,
    *,
    action_counts: dict[tuple[int, str, int], int] | None = None,
) -> list[dict[str, object]]:
    resolved_action_counts: dict[tuple[int, str, int], int] = defaultdict(int)
    if action_counts is not None:
        resolved_action_counts.update(action_counts)
    elif expected_actions is not None:
        for action in expected_actions.values():
            resolved_action_counts[
                (int(action["year"]), str(action["flag"]), int(action["code"]))
            ] += 1
    else:
        raise ValueError("expected_actions or action_counts is required")
    return [
        {
            "year": int(record["year"]),
            "flag": record["flag"],
            "code": int(record["code"]),
            "policy_bucket": record["policy_bucket"],
            "raw_rows": int(record["rows"]),
            "clean_rows": int(record["rows"]),
            "target_columns": int(record["target_columns"]),
            "has_target_columns": record["has_target_columns"] == "True",
            "rule_id": record["rule_id"],
            "recorded_cell_actions": resolved_action_counts[
                (int(record["year"]), record["flag"], int(record["code"]))
            ],
            "status": "pass",
            "status_reason": "Raw/clean code counts and contract rules reconciled.",
        }
        for record in expected_records
    ]


def matched_policy_metrics(
    rules: list[PrchPolicyRule],
    years: list[int],
    rule_rows: dict[tuple[int, str, int, str], int],
) -> dict[str, object]:
    """Derive row/flag coverage from resolved policy rows, not changed cells.

    The current reviewed contract has two actions. ``null`` is the child-row
    cleaning class. ``retain`` is the reviewed retain/review-only class; its
    rows remain visible and are counted independently from cell actions.
    """

    child_rows = 0
    retained_rows = 0
    child_flags: set[str] = set()
    retained_flags: set[str] = set()
    year_set = set(years)
    for rule in rules:
        for year in year_set:
            if not rule.year_start <= year <= rule.year_end:
                continue
            count = rule_rows.get((year, rule.flag, rule.code, rule.rule_id), 0)
            if count <= 0:
                continue
            if rule.action == "null":
                child_rows += count
                child_flags.add(rule.flag)
            elif rule.action == "retain":
                retained_rows += count
                retained_flags.add(rule.flag)
    return {
        "child_rows": child_rows,
        "child_flags": child_flags,
        "review_only_rows": retained_rows,
        "review_only_flags": retained_flags,
    }


def write_csv_atomic(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    staged = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        frame.to_csv(staged, index=False)
        os.replace(staged, path)
    finally:
        if staged.exists():
            staged.unlink()


def validate_qa_output_pointer(out_dir: Path) -> tuple[Path, Path | None]:
    """Return the managed run store and the currently published bundle."""

    out_dir.parent.mkdir(parents=True, exist_ok=True)
    runs_dir = out_dir.parent / f"{out_dir.name}_runs"
    runs_dir.mkdir(parents=True, exist_ok=True)
    previous: Path | None = None
    if out_dir.is_symlink():
        try:
            previous = out_dir.resolve(strict=True)
        except FileNotFoundError as exc:
            raise PanelQAError(f"QA output pointer is broken: {out_dir}") from exc
        if previous.parent != runs_dir.resolve() or not previous.is_dir():
            raise PanelQAError(
                f"QA output pointer targets an unmanaged bundle: {out_dir} -> {previous}"
            )
    elif out_dir.exists():
        raise PanelQAError(
            f"QA output must be absent or a managed run pointer symlink, not a directory: {out_dir}"
        )
    return runs_dir, previous


def bind_qa_frame(
    frame: pd.DataFrame,
    *,
    qa_run_id: str,
    prch_run_id: str,
    prch_manifest_sha256: str,
) -> pd.DataFrame:
    reserved = {"qa_run_id", "prch_run_id", "prch_manifest_sha256"}
    overlap = reserved & set(frame.columns)
    if overlap:
        raise PanelQAError(f"QA frame attempts to predeclare managed binding columns: {sorted(overlap)}")
    bound = frame.copy()
    bound.insert(0, "prch_manifest_sha256", prch_manifest_sha256)
    bound.insert(0, "prch_run_id", prch_run_id)
    bound.insert(0, "qa_run_id", qa_run_id)
    return bound


def validate_staged_qa_bundle(
    run_dir: Path,
    *,
    qa_run_id: str,
    prch_run_id: str,
    prch_manifest_sha256: str,
) -> None:
    manifest = read_json_object(run_dir / QA_RUN_MANIFEST)
    required = {
        "schema_version",
        "qa_run_id",
        "status",
        "qa_status",
        "qa_mode",
        "release_eligible",
        "prch_run_id",
        "prch_manifest_sha256",
        "raw_input_sha256",
        "artifacts",
    }
    if set(manifest) != required:
        raise PanelQAError(
            f"QA run manifest schema is not exact: expected={sorted(required)} actual={sorted(manifest)}"
        )
    if manifest["schema_version"] != "1.0" or manifest["status"] != "complete":
        raise PanelQAError("QA run manifest is not a complete supported bundle")
    if manifest["qa_run_id"] != qa_run_id:
        raise PanelQAError("QA run manifest qa_run_id mismatch")
    if manifest["prch_run_id"] != prch_run_id:
        raise PanelQAError("QA run manifest prch_run_id mismatch")
    if manifest["prch_manifest_sha256"] != prch_manifest_sha256:
        raise PanelQAError("QA run manifest PRCH manifest binding mismatch")
    artifacts = manifest["artifacts"]
    if not isinstance(artifacts, list) or len(artifacts) != len(QA_OUTPUT_FILES):
        raise PanelQAError("QA run manifest artifact inventory is incomplete")
    by_name: dict[str, dict[str, object]] = {}
    for record in artifacts:
        if not isinstance(record, dict) or set(record) != {"name", "bytes", "sha256"}:
            raise PanelQAError("QA run manifest artifact records require name, bytes, and sha256")
        name = str(record["name"])
        if name in by_name or Path(name).name != name:
            raise PanelQAError(f"Invalid or duplicate QA artifact name: {name!r}")
        by_name[name] = record
    if set(by_name) != set(QA_OUTPUT_FILES):
        raise PanelQAError(
            f"QA run manifest artifact names are not exact: {sorted(by_name)}"
        )
    actual_files = {path.name for path in run_dir.iterdir() if path.is_file()}
    if actual_files != set(QA_OUTPUT_FILES) | {QA_RUN_MANIFEST}:
        raise PanelQAError(
            f"QA bundle file inventory is not exact: {sorted(actual_files)}"
        )
    for name in QA_OUTPUT_FILES:
        path = run_dir / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size <= 0:
            raise PanelQAError(f"QA bundle artifact is missing, empty, or mutable: {path}")
        record = by_name[name]
        if int(record["bytes"]) != path.stat().st_size or str(record["sha256"]) != sha256_file(path):
            raise PanelQAError(f"QA bundle artifact hash/size mismatch: {name}")
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            columns = reader.fieldnames or []
            for binding in ("qa_run_id", "prch_run_id", "prch_manifest_sha256"):
                if binding not in columns:
                    raise PanelQAError(f"QA artifact {name} lacks binding column {binding}")
            for row in reader:
                if row["qa_run_id"] != qa_run_id:
                    raise PanelQAError(f"QA artifact {name} has a mismatched qa_run_id")
                if row["prch_run_id"] != prch_run_id:
                    raise PanelQAError(f"QA artifact {name} has a mismatched prch_run_id")
                if row["prch_manifest_sha256"] != prch_manifest_sha256:
                    raise PanelQAError(
                        f"QA artifact {name} has a mismatched prch_manifest_sha256"
                    )


def switch_qa_pointer(out_dir: Path, run_dir: Path, *, qa_run_id: str) -> None:
    staged = out_dir.with_name(f".{out_dir.name}.{qa_run_id}.tmp")
    target = os.path.relpath(run_dir, out_dir.parent)
    try:
        os.symlink(target, staged)
        os.replace(staged, out_dir)
    finally:
        if staged.is_symlink() or staged.exists():
            staged.unlink()


def publish_qa_bundle(
    out_dir: Path,
    frames: dict[str, pd.DataFrame],
    *,
    qa_mode: str,
    release_eligible: bool,
    prch_run_id: str,
    prch_manifest_sha256: str,
    raw_input_sha256: str = "not-recorded",
    reverify: Callable[[], None] | None,
    expected_previous: Path | None | object = _PREVIOUS_POINTER_UNSET,
) -> Path:
    """Seal all QA artifacts and publish them with one atomic pointer swap."""

    if set(frames) != set(QA_OUTPUT_FILES):
        raise PanelQAError(
            f"QA publication requires exactly {list(QA_OUTPUT_FILES)}; got {sorted(frames)}"
        )
    runs_dir, previous = validate_qa_output_pointer(out_dir)
    if expected_previous is not _PREVIOUS_POINTER_UNSET and previous != expected_previous:
        raise PanelQAError(
            "QA output pointer changed while the candidate bundle was being validated"
        )
    qa_run_id = f"qa-{os.getpid()}-{uuid.uuid4().hex}"
    staged_dir = runs_dir / f".{qa_run_id}.staging"
    final_dir = runs_dir / qa_run_id
    staged_dir.mkdir()
    renamed = False
    try:
        bound_frames: dict[str, pd.DataFrame] = {}
        for name in QA_OUTPUT_FILES:
            bound = bind_qa_frame(
                frames[name],
                qa_run_id=qa_run_id,
                prch_run_id=prch_run_id,
                prch_manifest_sha256=prch_manifest_sha256,
            )
            bound_frames[name] = bound
            write_csv_atomic(bound, staged_dir / name)
        summary = bound_frames["panel_qa_summary.csv"]
        if summary.empty or "status" not in summary.columns:
            raise PanelQAError("QA summary must contain a semantic status row")
        qa_status = str(summary.iloc[0]["status"])
        artifacts = [
            {
                "name": name,
                "bytes": (staged_dir / name).stat().st_size,
                "sha256": sha256_file(staged_dir / name),
            }
            for name in QA_OUTPUT_FILES
        ]
        manifest = {
            "schema_version": "1.0",
            "qa_run_id": qa_run_id,
            "status": "complete",
            "qa_status": qa_status,
            "qa_mode": qa_mode,
            "release_eligible": bool(release_eligible),
            "prch_run_id": prch_run_id,
            "prch_manifest_sha256": prch_manifest_sha256,
            "raw_input_sha256": raw_input_sha256,
            "artifacts": artifacts,
        }
        (staged_dir / QA_RUN_MANIFEST).write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        validate_staged_qa_bundle(
            staged_dir,
            qa_run_id=qa_run_id,
            prch_run_id=prch_run_id,
            prch_manifest_sha256=prch_manifest_sha256,
        )
        os.replace(staged_dir, final_dir)
        renamed = True

        if previous is None:
            if out_dir.exists() or out_dir.is_symlink():
                raise PanelQAError("QA output pointer appeared concurrently before promotion")
        elif not out_dir.is_symlink() or out_dir.resolve(strict=True) != previous:
            raise PanelQAError("QA output pointer changed concurrently before promotion")
        if reverify is not None:
            reverify()
        switch_qa_pointer(out_dir, final_dir, qa_run_id=qa_run_id)
        return final_dir
    finally:
        if staged_dir.exists():
            shutil.rmtree(staged_dir)
        # A sealed but unpromoted run is intentionally retained as diagnostic
        # evidence when final input revalidation or the pointer switch fails.
        if not renamed and final_dir.exists():
            shutil.rmtree(final_dir)


def run_release_qa(args: argparse.Namespace) -> None:
    raw_path = Path(args.raw)
    clean_path = Path(args.clean)
    pointer = Path(args.prch_qc_dir)
    policy_path = Path(args.prch_policy)
    qa_output = Path(args.out_dir)
    _qa_runs_dir, qa_previous = validate_qa_output_pointer(qa_output)
    run_dir = resolve_managed_run(pointer, clean_path)
    raw, clean, keys, years = validate_structural_integrity(raw_path, clean_path)
    manifest, artifact_records = validate_manifest(
        run_dir,
        pointer,
        raw_path,
        clean_path,
        policy_path,
        raw,
        clean,
        keys,
    )
    raw_input_sha256 = sha256_path_tree(raw_path)
    prch_manifest_sha256 = next(
        record["sha256"] for record in artifact_records if record["name"] == "prch_run_manifest.json"
    )
    contract = load_policy_contract(policy_path, release_mode=True)
    policy_actual = read_exact_csv(run_dir / "prch_flag_policy.csv", POLICY_COLUMNS, "resolved policy")
    policy_expected = contract_policy_records(contract)
    compare_exact_records(policy_actual, policy_expected, "resolved policy")

    action_workspace: tempfile.TemporaryDirectory[str] | None = None
    expected_action_ledger: Path | None = None
    if args.action_reconciliation_mode == "duckdb":
        action_temp_parent = (
            Path(args.action_temp_dir)
            if args.action_temp_dir
            else qa_output.parent / "panel_qa_action_tmp"
        )
        action_temp_parent.mkdir(parents=True, exist_ok=True)
        action_workspace = tempfile.TemporaryDirectory(
            prefix="panel-qa-actions-",
            dir=action_temp_parent,
        )
        expected_action_ledger = Path(action_workspace.name) / "expected_actions.parquet"

    scan = scan_expected_release_actions(
        raw,
        contract,
        years,
        batch_rows=args.batch_rows,
        action_ledger_path=expected_action_ledger,
        action_buffer_rows=args.action_buffer_rows,
    )
    expected_codes = expected_code_evidence(contract, scan["code_counts"])
    actual_codes = read_exact_csv(
        run_dir / "prch_flag_code_counts.csv",
        CODE_EVIDENCE_COLUMNS,
        "prch_flag_code_counts",
    )
    compare_exact_records(actual_codes, expected_codes, "prch_flag_code_counts")
    expected_summary = expected_clean_summary(
        contract,
        years,
        scan["flags"],
        scan["rule_rows"],
        scan["action_groups"],
    )
    actual_summary = read_exact_csv(
        run_dir / "prch_clean_summary.csv",
        CLEAN_SUMMARY_COLUMNS,
        "prch_clean_summary",
    )
    compare_exact_records(actual_summary, expected_summary, "prch_clean_summary")

    if action_workspace is not None:
        workspace = Path(action_workspace.name)
        assert expected_action_ledger is not None
        con = open_action_duckdb(
            workspace,
            memory_limit=args.duckdb_memory_limit,
            threads=args.duckdb_threads,
        )
        try:
            action_reconciliation, action_rows = reconcile_action_evidence_duckdb(
                con,
                run_dir / "prch_cell_actions.parquet",
                expected_action_ledger,
                scan["action_groups"],
            )
            actual_changes_ledger = workspace / "actual_changes.parquet"
            write_actual_changes_ledger(
                raw,
                clean,
                actual_changes_ledger,
                batch_rows=args.batch_rows,
                action_buffer_rows=args.action_buffer_rows,
            )
            changed_cells = validate_exact_value_changes_duckdb(
                con,
                actual_changes_ledger,
            )
        finally:
            con.close()
    else:
        expected_actions = scan["expected_actions"]
        assert isinstance(expected_actions, dict)
        action_reconciliation, action_rows = reconcile_action_evidence(
            run_dir / "prch_cell_actions.parquet",
            expected_actions,
            scan["action_groups"],
        )
        changed_cells = validate_exact_value_changes(
            raw,
            clean,
            expected_actions,
            batch_rows=args.batch_rows,
        )
    if changed_cells <= 0 or action_rows <= 0:
        raise PanelQAError("Release QA requires nonempty PRCH changes and cell-action evidence")

    evidence_checks = [
        {
            "check_id": "managed_run_pointer",
            "status": "pass",
            "evidence_path": str(pointer),
            "details": f"Pointer resolves to immutable run {run_dir.name}.",
        },
        {
            "check_id": "run_manifest",
            "status": "pass",
            "evidence_path": str(run_dir / "prch_run_manifest.json"),
            "details": f"Complete release manifest with {len(artifact_records)} hashed artifacts.",
        },
        {
            "check_id": "policy_binding",
            "status": "pass",
            "evidence_path": str(policy_path),
            "details": f"Exact path and sha256 {manifest['policy_sha256']} verified.",
        },
        {
            "check_id": "raw_clean_schema_rows_keys",
            "status": "pass",
            "evidence_path": str(clean_path),
            "details": f"Exact schema, {len(keys)} rows, and ordered unique keys verified.",
        },
        {
            "check_id": "resolved_policy_rows",
            "status": "pass",
            "evidence_path": str(run_dir / "prch_flag_policy.csv"),
            "details": f"{len(policy_expected)} exact reviewed policy rows verified.",
        },
        {
            "check_id": "flag_code_counts",
            "status": "pass",
            "evidence_path": str(run_dir / "prch_flag_code_counts.csv"),
            "details": f"{len(expected_codes)} observed year/flag/code groups fully resolved.",
        },
        {
            "check_id": "clean_summary",
            "status": "pass",
            "evidence_path": str(run_dir / "prch_clean_summary.csv"),
            "details": f"{len(expected_summary)} year/flag summaries exactly reconciled.",
        },
        {
            "check_id": "cell_actions",
            "status": "pass",
            "evidence_path": str(run_dir / "prch_cell_actions.parquet"),
            "details": f"{action_rows} exact old-to-null actions reconciled by policy predicate and column.",
        },
        {
            "check_id": "unaffected_values",
            "status": "pass",
            "evidence_path": str(raw_path),
            "details": "Every cell outside the action ledger is value-equivalent.",
        },
    ]
    coverage = build_release_coverage(
        scan["scoped_rules"],
        years,
        scan["rule_rows"],
        scan["action_groups"],
    )
    code_rows = build_release_code_rows(
        expected_codes,
        scan["expected_actions"],
        action_counts=scan["action_counts"] if action_workspace is not None else None,
    )
    flags_with_actions = set(scan["action_flags"])
    policy_metrics = matched_policy_metrics(
        scan["scoped_rules"],
        years,
        scan["rule_rows"],
    )
    child_flags = set(policy_metrics["child_flags"])
    review_flags = set(policy_metrics["review_only_flags"])
    summary = pd.DataFrame(
        [
            {
                "qa_schema_version": QA_SCHEMA_VERSION,
                "qa_mode": "release",
                "status": "pass",
                "release_eligible": True,
                "run_id": manifest["run_id"],
                "run_path": str(run_dir),
                "policy_path": str(policy_path.resolve()),
                "policy_sha256": manifest["policy_sha256"],
                "raw_years": format_years(years, args.year_sep, args.excel_text),
                "clean_years": format_years(years, args.year_sep, args.excel_text),
                "raw_years_min": min(years),
                "raw_years_max": max(years),
                "raw_years_count": len(years),
                "clean_years_min": min(years),
                "clean_years_max": max(years),
                "clean_years_count": len(years),
                "raw_rows": len(keys),
                "clean_rows": len(keys),
                "raw_size_bytes": _path_size(raw_path),
                "clean_size_bytes": _path_size(clean_path),
                "flags_evaluated": len(scan["flags"]),
                "flags_with_child_rows": len(child_flags),
                "child_rows_policy_matched": int(policy_metrics["child_rows"]),
                "flags_with_recorded_actions": len(flags_with_actions),
                "cleaned_flags": len(flags_with_actions),
                "no_target_flags": 0,
                "review_only_flags": len(review_flags),
                "review_only_rows": int(policy_metrics["review_only_rows"]),
                "suspicious_flags": 0,
                "suspicious_flag_list": "",
                "no_target_flag_list": "",
                "review_only_flag_list": ",".join(sorted(review_flags)),
                "review_metric_basis": "matched reviewed retain-policy rows",
                "changed_cells": changed_cells,
                "action_rows": action_rows,
                "evidence_checks": len(evidence_checks),
                "status_reason": "All managed PRCH release evidence and exact cell changes reconciled.",
            }
        ]
    )
    frames = {
            "panel_qa_summary.csv": summary,
            "panel_qa_coverage_matrix.csv": pd.DataFrame(coverage),
            "panel_qa_by_flag_code.csv": pd.DataFrame(code_rows),
            "panel_qa_action_reconciliation.csv": pd.DataFrame(action_reconciliation),
            "panel_qa_evidence_checks.csv": pd.DataFrame(evidence_checks),
    }

    def reverify_release_inputs() -> None:
        verify_run_snapshot(
            pointer,
            run_dir,
            policy_path,
            str(manifest["policy_sha256"]),
            artifact_records,
        )
        if sha256_path_tree(raw_path) != raw_input_sha256:
            raise PanelQAError("Raw analysis-wide input changed during QA")

    qa_run_dir = publish_qa_bundle(
        qa_output,
        frames,
        qa_mode="release",
        release_eligible=True,
        prch_run_id=str(manifest["run_id"]),
        prch_manifest_sha256=prch_manifest_sha256,
        raw_input_sha256=raw_input_sha256,
        reverify=reverify_release_inputs,
        expected_previous=qa_previous,
    )
    if action_workspace is not None:
        action_workspace.cleanup()
    print(f"PRCH release QA passed for managed run {manifest['run_id']}")
    print(f"Reconciled {changed_cells:,} exact old-to-null cell actions")
    print(f"Promoted immutable v2 panel QA bundle {qa_run_dir} via {args.out_dir}")


def run_development_qa(args: argparse.Namespace) -> None:
    raw_path = Path(args.raw)
    clean_path = Path(args.clean)
    qa_output = Path(args.out_dir)
    _qa_runs_dir, qa_previous = validate_qa_output_pointer(qa_output)
    raw, clean, keys, years = validate_structural_integrity(raw_path, clean_path)
    flags = resolve_requested_flags(args.flag, raw.schema.names, clean.schema.names)
    if not flags:
        raise PanelQAError("No PRCH flags were found for development QA")
    target_map = load_target_columns_map(Path(args.prch_qc_dir), raw.schema.names)
    coverage_rows: list[dict[str, object]] = []
    code_rows: list[dict[str, object]] = []
    for flag in flags:
        child_codes = resolve_child_codes(flag, args.flag_child if len(flags) == 1 else "AUTO")
        target_cols = target_map.get(flag, [])
        raw_stats = aggregate_target_nonnull_by_code(raw, flag, target_cols, args.batch_rows)
        clean_stats = aggregate_target_nonnull_by_code(clean, flag, target_cols, args.batch_rows)
        coverage_rows.append(
            build_coverage_row(
                flag=flag,
                child_codes=child_codes,
                review_codes=review_only_codes(flag),
                target_cols=target_cols,
                raw_code_stats=raw_stats,
                clean_code_stats=clean_stats,
            )
        )
        code_rows.extend(build_code_rows(flag, raw_stats, clean_stats))
    coverage = pd.DataFrame(coverage_rows)
    counts = coverage["status"].value_counts().to_dict()
    summary = pd.DataFrame(
        [
            {
                "qa_schema_version": QA_SCHEMA_VERSION,
                "qa_mode": "development",
                "status": "development_only",
                "release_eligible": False,
                "raw_years": format_years(years, args.year_sep, args.excel_text),
                "clean_years": format_years(years, args.year_sep, args.excel_text),
                "raw_years_min": min(years),
                "raw_years_max": max(years),
                "raw_years_count": len(years),
                "clean_years_min": min(years),
                "clean_years_max": max(years),
                "clean_years_count": len(years),
                "raw_rows": len(keys),
                "clean_rows": len(keys),
                "raw_size_bytes": _path_size(raw_path),
                "clean_size_bytes": _path_size(clean_path),
                "flags_evaluated": len(coverage),
                "flags_with_child_rows": int((coverage["child_rows_raw"] > 0).sum()),
                "cleaned_flags": int(counts.get("cleaned", 0)),
                "no_target_flags": int(counts.get("no_targets", 0)),
                "review_only_flags": int(counts.get("review_only", 0)),
                "suspicious_flags": int(counts.get("suspicious", 0)),
                "suspicious_flag_list": ",".join(
                    coverage.loc[coverage["status"] == "suspicious", "flag"].tolist()
                ),
                "no_target_flag_list": ",".join(
                    coverage.loc[coverage["status"] == "no_targets", "flag"].tolist()
                ),
                "review_only_flag_list": ",".join(
                    coverage.loc[coverage["status"] == "review_only", "flag"].tolist()
                ),
                "status_reason": "Explicit legacy development QA; never eligible for release.",
            }
        ]
    )
    action_columns = [
        "year",
        "flag",
        "code",
        "rule_id",
        "row_predicate",
        "column",
        "expected_changes",
        "recorded_actions",
        "status",
        "status_reason",
    ]
    evidence = pd.DataFrame(
        [
            {
                "check_id": "development_mode",
                "status": "not_release",
                "evidence_path": str(Path(args.prch_qc_dir)),
                "details": "Legacy broad policy diagnostics were explicitly requested.",
            }
        ]
    )
    qa_run_dir = publish_qa_bundle(
        qa_output,
        {
            "panel_qa_summary.csv": summary,
            "panel_qa_coverage_matrix.csv": coverage,
            "panel_qa_by_flag_code.csv": pd.DataFrame(code_rows),
            "panel_qa_action_reconciliation.csv": pd.DataFrame(columns=action_columns),
            "panel_qa_evidence_checks.csv": evidence,
        },
        qa_mode="development",
        release_eligible=False,
        prch_run_id="development-unmanaged",
        prch_manifest_sha256="not-applicable",
        raw_input_sha256=sha256_path_tree(raw_path),
        reverify=None,
        expected_previous=qa_previous,
    )
    print("[development-only] Panel QA completed; release_eligible=false")
    print(f"Promoted immutable development QA bundle {qa_run_dir} via {args.out_dir}")


def best_effort_failure_binding(args: argparse.Namespace) -> tuple[str, str, str]:
    prch_run_id = "unavailable"
    prch_manifest_sha256 = "unavailable"
    raw_input_sha256 = "unavailable"
    try:
        pointer = Path(args.prch_qc_dir)
        if pointer.is_symlink():
            run_dir = pointer.resolve(strict=True)
            prch_run_id = run_dir.name
            manifest_path = run_dir / "prch_run_manifest.json"
            if manifest_path.is_file():
                prch_manifest_sha256 = sha256_file(manifest_path)
    except Exception:
        pass
    try:
        raw_input_sha256 = sha256_path_tree(Path(args.raw))
    except Exception:
        pass
    return prch_run_id, prch_manifest_sha256, raw_input_sha256


def write_failure_summary(args: argparse.Namespace, error: Exception) -> None:
    try:
        prch_run_id, prch_manifest_sha256, raw_input_sha256 = best_effort_failure_binding(args)
        failure = {
            "qa_schema_version": QA_SCHEMA_VERSION,
            "qa_mode": args.qa_mode,
            "status": "fail",
            "release_eligible": False,
            "status_reason": str(error),
        }
        publish_qa_bundle(
            Path(args.out_dir),
            {
                "panel_qa_summary.csv": pd.DataFrame([failure]),
                "panel_qa_coverage_matrix.csv": pd.DataFrame(
                    [{"status": "fail", "status_reason": str(error)}]
                ),
                "panel_qa_by_flag_code.csv": pd.DataFrame(
                    [{"status": "fail", "status_reason": str(error)}]
                ),
                "panel_qa_action_reconciliation.csv": pd.DataFrame(
                    [{"status": "fail", "status_reason": str(error)}]
                ),
                "panel_qa_evidence_checks.csv": pd.DataFrame(
                    [
                        {
                            "check_id": "release_qa",
                            "status": "fail",
                            "evidence_path": "",
                            "details": str(error),
                        }
                    ]
                ),
            },
            qa_mode=args.qa_mode,
            release_eligible=False,
            prch_run_id=prch_run_id,
            prch_manifest_sha256=prch_manifest_sha256,
            raw_input_sha256=raw_input_sha256,
            reverify=None,
        )
    except Exception as write_error:  # The original validation failure remains authoritative.
        print(f"Unable to write failure summary: {write_error}", file=sys.stderr)


def main() -> None:
    args = parse_args()
    setup_logging(args.log_file)
    try:
        if args.qa_mode == "release":
            run_release_qa(args)
        else:
            run_development_qa(args)
    except Exception as exc:
        write_failure_summary(args, exc)
        raise SystemExit(f"Panel QA failed closed: {exc}") from exc


if __name__ == "__main__":
    main()
