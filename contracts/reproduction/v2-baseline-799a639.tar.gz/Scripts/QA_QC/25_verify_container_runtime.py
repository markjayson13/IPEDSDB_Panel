#!/usr/bin/env python3
"""Fail-closed preflight for the governed IPEDSDB release container.

The host wrapper launches an inspected immutable image ID containing a
standalone, clean Git checkout at ``/repo`` on the read-only image root, with
only the external data root mounted read-write at ``/data``.  This entrypoint
verifies those bindings again before executing the requested command.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import stat
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Mapping, Sequence


IMAGE_DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
GIT_COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")

DEFAULT_REPO = Path("/repo")
DEFAULT_DATA_ROOT = Path("/data")
DEFAULT_EMBEDDED_REVISION = Path("/opt/ipedsdb/image-revision")
DEFAULT_EMBEDDED_LOCK_SHA256 = Path(
    "/opt/ipedsdb/requirements-lock.sha256"
)
DEFAULT_DOCKER_SOCKET = Path("/var/run/docker.sock")


class ContainerRuntimeError(RuntimeError):
    """The executing container is not the host-verified release boundary."""


@dataclass(frozen=True)
class RuntimeBinding:
    git_commit: str
    image_digest: str
    image_revision: str
    requirements_lock_sha256: str


def _safe_git_environment() -> dict[str, str]:
    environment = {
        name: os.environ[name]
        for name in (
            "LANG",
            "LC_ALL",
            "PATH",
            "TEMP",
            "TMP",
            "TMPDIR",
        )
        if name in os.environ
    }
    environment.update(
        {
            "GIT_ATTR_NOSYSTEM": "1",
            "GIT_CONFIG_COUNT": "0",
            "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_INDEX_VERSION": "2",
            "GIT_NO_REPLACE_OBJECTS": "1",
            "GIT_OPTIONAL_LOCKS": "0",
            "HOME": "/nonexistent",
        }
    )
    return environment


def _run_git(repo: Path, *args: str, binary: bool = False) -> str | bytes:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo,
        env=_safe_git_environment(),
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=not binary,
    )
    if completed.returncode != 0:
        details = (
            completed.stderr.strip()
            if isinstance(completed.stderr, str)
            else completed.stderr.decode("utf-8", errors="replace").strip()
        )
        raise ContainerRuntimeError(
            f"Git verification failed for {' '.join(args)}: {details}"
        )
    return completed.stdout


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _regular_non_symlink(path: Path) -> bool:
    try:
        mode = path.lstat().st_mode
    except OSError:
        return False
    return stat.S_ISREG(mode) and not path.is_symlink()


def _read_binding(path: Path, pattern: re.Pattern[str], label: str) -> str:
    if not _regular_non_symlink(path):
        raise ContainerRuntimeError(
            f"Embedded {label} must be a regular non-symlink file: {path}"
        )
    value = path.read_text(encoding="utf-8").strip()
    if not pattern.fullmatch(value):
        raise ContainerRuntimeError(f"Embedded {label} is malformed: {value!r}")
    return value


def _standalone_git_commit(repo: Path) -> str:
    repo = repo.resolve()
    git_dir = repo / ".git"
    if git_dir.is_symlink() or not git_dir.is_dir():
        raise ContainerRuntimeError(
            f"/repo must contain a standalone .git directory: {repo}"
        )
    top = Path(
        str(_run_git(repo, "rev-parse", "--show-toplevel")).strip()
    ).resolve()
    actual_git_dir = Path(
        str(_run_git(repo, "rev-parse", "--absolute-git-dir")).strip()
    ).resolve()
    common_git_dir = Path(
        str(_run_git(repo, "rev-parse", "--path-format=absolute", "--git-common-dir")).strip()
    ).resolve()
    if top != repo or actual_git_dir != git_dir.resolve() or common_git_dir != git_dir.resolve():
        raise ContainerRuntimeError(
            "/repo Git metadata is not standalone and self-contained"
        )
    alternates = git_dir / "objects" / "info" / "alternates"
    if alternates.exists() or alternates.is_symlink():
        raise ContainerRuntimeError(
            "/repo Git object alternates are not permitted"
        )
    grafts = git_dir / "info" / "grafts"
    if grafts.exists() or grafts.is_symlink():
        raise ContainerRuntimeError("/repo Git grafts are not permitted")
    replace_refs = str(
        _run_git(
            repo,
            "for-each-ref",
            "--format=%(refname)",
            "refs/replace",
        )
    ).strip()
    if replace_refs:
        raise ContainerRuntimeError(
            "/repo Git replacement refs are not permitted"
        )
    objects = git_dir / "objects"
    if any(path.is_symlink() for path in objects.rglob("*")):
        raise ContainerRuntimeError(
            "/repo Git objects cannot contain symlinks"
        )
    commit = str(
        _run_git(repo, "rev-parse", "--verify", "HEAD^{commit}")
    ).strip()
    if not GIT_COMMIT_RE.fullmatch(commit):
        raise ContainerRuntimeError("/repo HEAD is not a full Git commit")
    status = _run_git(
        repo,
        "status",
        "--porcelain=v1",
        "-z",
        "--untracked-files=all",
        binary=True,
    )
    if status:
        raise ContainerRuntimeError("/repo must be status-clean")
    index_records = bytes(
        _run_git(
            repo,
            "ls-files",
            "-v",
            "-z",
            binary=True,
        )
    ).split(b"\0")
    if any(record and record[:2] != b"H " for record in index_records):
        raise ContainerRuntimeError(
            "/repo index contains nondefault concealment flags"
        )
    ignored = _run_git(
        repo,
        "ls-files",
        "-z",
        "--others",
        "--ignored",
        "--exclude-standard",
        binary=True,
    )
    if ignored:
        raise ContainerRuntimeError(
            "/repo cannot contain ignored workspace files"
        )
    return commit


def _mount_mode_from_proc(path: Path) -> str:
    """Return ``ro`` or ``rw`` for the longest matching Linux mountpoint."""

    target = path.resolve()
    mountinfo = Path("/proc/self/mountinfo")
    if not mountinfo.is_file():
        raise ContainerRuntimeError(
            "Cannot verify mount modes without /proc/self/mountinfo"
        )
    best: tuple[int, str] | None = None
    for raw_line in mountinfo.read_text(encoding="utf-8").splitlines():
        before, separator, _after = raw_line.partition(" - ")
        if not separator:
            continue
        fields = before.split()
        if len(fields) < 6:
            continue
        mountpoint = Path(
            fields[4]
            .replace("\\040", " ")
            .replace("\\011", "\t")
            .replace("\\012", "\n")
            .replace("\\134", "\\")
        )
        try:
            target.relative_to(mountpoint)
        except ValueError:
            continue
        options = fields[5].split(",")
        mode = "ro" if "ro" in options else "rw" if "rw" in options else ""
        if mode and (best is None or len(mountpoint.parts) > best[0]):
            best = (len(mountpoint.parts), mode)
    if best is None:
        raise ContainerRuntimeError(f"Cannot resolve mount mode for {target}")
    return best[1]


def verify_container_runtime(
    *,
    repo: Path = DEFAULT_REPO,
    data_root: Path = DEFAULT_DATA_ROOT,
    environ: Mapping[str, str] | None = None,
    embedded_revision_path: Path = DEFAULT_EMBEDDED_REVISION,
    embedded_lock_sha256_path: Path = DEFAULT_EMBEDDED_LOCK_SHA256,
    mount_mode: Callable[[Path], str] = _mount_mode_from_proc,
    docker_socket_path: Path = DEFAULT_DOCKER_SOCKET,
) -> RuntimeBinding:
    """Verify all image/source/data bindings without writing any output."""

    environ = os.environ if environ is None else environ
    repo = repo.expanduser().absolute()
    data_root = data_root.expanduser().absolute()
    if repo.is_symlink() or not repo.is_dir():
        raise ContainerRuntimeError(f"/repo must be a real directory: {repo}")
    if data_root.is_symlink() or not data_root.is_dir():
        raise ContainerRuntimeError(
            f"/data must be a real directory: {data_root}"
        )
    if docker_socket_path.exists() or docker_socket_path.is_symlink():
        raise ContainerRuntimeError(
            f"Docker socket must not be available in the release container: "
            f"{docker_socket_path}"
        )

    commit = _standalone_git_commit(repo)
    image_digest = str(environ.get("CONTAINER_IMAGE_DIGEST", "")).strip()
    image_revision = str(environ.get("CONTAINER_IMAGE_REVISION", "")).strip()
    environment_lock_sha256 = str(
        environ.get("CONTAINER_REQUIREMENTS_LOCK_SHA256", "")
    ).strip()
    if not IMAGE_DIGEST_RE.fullmatch(image_digest):
        raise ContainerRuntimeError(
            "CONTAINER_IMAGE_DIGEST must match sha256:<64 lowercase hex>"
        )
    if not GIT_COMMIT_RE.fullmatch(image_revision):
        raise ContainerRuntimeError(
            "CONTAINER_IMAGE_REVISION must be a full lowercase Git revision"
        )
    if image_revision != commit:
        raise ContainerRuntimeError(
            "Container image revision does not match /repo HEAD"
        )
    if not SHA256_RE.fullmatch(environment_lock_sha256):
        raise ContainerRuntimeError(
            "CONTAINER_REQUIREMENTS_LOCK_SHA256 must be a lowercase SHA-256"
        )

    embedded_revision = _read_binding(
        embedded_revision_path,
        GIT_COMMIT_RE,
        "image revision",
    )
    embedded_lock_sha256 = _read_binding(
        embedded_lock_sha256_path,
        SHA256_RE,
        "requirements lock SHA-256",
    )
    if embedded_revision != commit or embedded_revision != image_revision:
        raise ContainerRuntimeError(
            "Embedded image revision does not match the environment and /repo "
            "HEAD"
        )
    source_lock = repo / "requirements-lock.txt"
    if not _regular_non_symlink(source_lock):
        raise ContainerRuntimeError(
            f"Mounted requirements lock must be a regular file: {source_lock}"
        )
    actual_lock_sha256 = _sha256_file(source_lock)
    if (
        embedded_lock_sha256 != actual_lock_sha256
        or environment_lock_sha256 != actual_lock_sha256
    ):
        raise ContainerRuntimeError(
            "Embedded/environment requirements lock binding does not match "
            "/repo/requirements-lock.txt"
        )

    if mount_mode(repo) != "ro":
        raise ContainerRuntimeError("/repo must be mounted read-only")
    if mount_mode(data_root) != "rw":
        raise ContainerRuntimeError("/data must be mounted read-write")

    return RuntimeBinding(
        git_commit=commit,
        image_digest=image_digest,
        image_revision=image_revision,
        requirements_lock_sha256=actual_lock_sha256,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=DEFAULT_REPO)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument(
        "command",
        nargs=argparse.REMAINDER,
        help="Command to exec after a literal -- separator.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    command = list(args.command)
    if command and command[0] == "--":
        command = command[1:]
    try:
        binding = verify_container_runtime(
            repo=args.repo,
            data_root=args.data_root,
        )
    except ContainerRuntimeError as exc:
        print(f"CONTAINER_RUNTIME_VERIFICATION_FAILED: {exc}", file=sys.stderr)
        return 1
    if not command:
        print(
            "CONTAINER_RUNTIME_VERIFIED "
            f"image={binding.image_digest} revision={binding.image_revision} "
            f"lock={binding.requirements_lock_sha256}"
        )
        return 0
    os.execvp(command[0], command)
    return 127  # pragma: no cover - exec only returns on failure


if __name__ == "__main__":
    raise SystemExit(main())
