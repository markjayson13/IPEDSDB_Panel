#!/usr/bin/env python3
"""Build deterministic UNITID continuity evidence and conservative join-risk candidates.

The canonical v2 invocation reads the reviewed PRCH-cleaned panel and publishes
an immutable evidence bundle behind one atomic directory-symlink swap.  A row in
the output describes observed evidence; it never asserts that two UNITIDs are
the same institution.  Predecessor/successor candidates require a shared,
nonblank stable identifier at adjacent, non-overlapping UNITID spans.

Canonical reads:
- ``Panels/v2/panel_clean_prch_<start>_<end>.parquet``

Canonical writes (through an immutable managed run):
- ``Checks/v2/entity_continuity/entity_continuity_crosswalk.csv``
- ``Checks/v2/entity_continuity/entity_continuity_summary.csv``
- ``Checks/v2/entity_continuity/entity_continuity_summary.md``
- ``Checks/v2/entity_continuity/entity_continuity_manifest.json``
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import shutil
import sys
import tomllib
import unicodedata
import uuid
from pathlib import Path
from typing import Iterable, Sequence

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import (  # noqa: E402
    DEFAULT_IPEDSDB_ROOT,
    atomic_write_json,
    atomic_write_text,
    compute_file_metadata,
    data_layout,
    parse_years,
    repo_root,
)
from stage_provenance import (  # noqa: E402
    ProvenanceError,
    current_contract_hashes,
    git_state,
    resolve_run_dir,
    sha256_file as provenance_sha256_file,
    tool_versions,
    verify_run,
)


SCHEMA_VERSION = "entity-continuity-v2.1"
REQUIRED_CAUSAL_STAGES = (
    "01",
    "02",
    "03",
    "04",
    "05",
    "06",
    "07",
    "qa00",
    "qa01",
)
CANONICAL_CONTINUITY_CROSSWALK = (
    "Checks/v2/entity_continuity/entity_continuity_crosswalk.csv"
)
CANONICAL_CONTINUITY_MANIFEST = (
    "Checks/v2/entity_continuity/entity_continuity_manifest.json"
)
CANONICAL_CONTINUITY_VALUE_LINEAGE = (
    "Checks/v2/entity_continuity/entity_continuity_value_lineage.parquet"
)
CANONICAL_CONTINUITY_VERIFICATION = (
    "Checks/v2/entity_continuity_verification/entity_continuity_verification.json"
)
NULL_TOKENS = {"", "<na>", "na", "nan", "nat", "none", "null"}
FULL_OPEID_SENTINELS = {"00000000", "99999999"}
NORMALIZED_PLACEHOLDERS = {
    "missing",
    "na",
    "none",
    "notapplicable",
    "notavailable",
    "notreported",
    "null",
    "unk",
    "unknown",
    "unavailable",
    "unreported",
}

INSTITUTION_NAME_CANDIDATES = ("INSTNM", "INSTITUTION_NAME")
OPEID_CANDIDATES = ("OPEID", "OPEIDB", "OPEID6", "OPEID_6")
SECTOR_CANDIDATES = ("SECTOR",)
CONTROL_CANDIDATES = ("CONTROL",)
LEVEL_CANDIDATES = ("ICLEVEL", "INSTLEVEL", "LEVEL")
PARENT_CHILD_EXPLICIT_CANDIDATES = {
    "PARENT_UNITID",
    "PARENTUNITID",
    "PARENT_UNIT_ID",
    "PARENTID",
    "PARENT_OPEID",
    "PARENTOPEID",
    "SYSTEM_ID",
    "SYSTEMID",
    "F1SYSCOD",
    "F1SYSNAM",
}

CROSSWALK_COLUMNS = [
    "UNITID",
    "first_year",
    "last_year",
    "years_observed_count",
    "years_observed",
    "has_internal_gap",
    "internal_gap_count",
    "internal_gap_years",
    "institution_name_change_count",
    "institution_name_history",
    "opeid_change_count",
    "opeid_history",
    "opeid_count",
    "opeid_values",
    "opeid6_count",
    "opeid6_values",
    "parent_child_change_count",
    "parent_child_history",
    "prch_review_values",
    "sector_change_count",
    "sector_history",
    "control_change_count",
    "control_history",
    "level_change_count",
    "level_history",
    "potential_predecessor_unitids",
    "potential_predecessor_evidence",
    "potential_successor_unitids",
    "potential_successor_evidence",
    "candidate_link_status",
    "join_risk_flags",
    "join_risk_level",
    "evidence_sufficiency",
    "insufficient_evidence_reasons",
    "release_eligible",
    "invalid_opeid_tokens",
    "institution_name_source_column",
    "opeid_source_columns",
    "parent_child_source_columns",
    "sector_source_column",
    "control_source_column",
    "level_source_column",
    "candidate_link_source_columns",
    "evidence_source_columns",
    "evidence_variable_ids",
    "evidence_source_files",
    "evidence_access_tables",
    "value_lineage_rows",
]

RISK_FLAG_ORDER = [
    "potential_identity_link",
    "internal_year_gap",
    "single_year_observation",
    "missing_institution_name",
    "institution_name_change",
    "multi_opeid",
    "multi_opeid6",
    "opeid_change",
    "parent_child_flag_observed",
    "parent_child_change",
    "sector_change",
    "control_change",
    "level_change",
    "invalid_opeid_evidence",
    "insufficient_evidence",
]

REQUIRED_LINEAGE_COLUMNS = {
    "contract_id",
    "UNITID",
    "year",
    "analysis_column",
    "variable_id",
    "source_varnumber",
    "varname",
    "source_row_id",
    "source_row_hash",
    "source_file",
    "access_table_name",
    "transformation_id",
    "normalized_value",
    "lineage_role",
}


class ContinuityError(RuntimeError):
    """Raised when continuity evidence cannot be built without ambiguity."""


def reviewed_release_layout(repo: Path) -> dict[str, object]:
    contract_path = repo / "contracts" / "panel_spec.toml"
    try:
        contract = tomllib.loads(contract_path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ContinuityError(f"Cannot read reviewed release contract {contract_path}: {exc}") from exc
    release = contract.get("release", {})
    dataset = contract.get("dataset", {})
    outputs = contract.get("outputs", {})
    artifacts = contract.get("artifacts", {})
    qa = contract.get("qa", {})
    try:
        start_year = int(release["start_year"])
        end_year = int(release["end_year"])
        panel_path = str(outputs["prch_cleaned"])
        lineage_path = str(outputs["column_lineage"])
        continuity_path = str(qa["entity_continuity"])
        continuity_manifest_path = str(qa["entity_continuity_manifest"])
        continuity_value_lineage_path = str(qa["entity_continuity_value_lineage"])
        continuity_verification_path = str(qa["entity_continuity_verification"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ContinuityError("Reviewed release contract lacks continuity scope or paths") from exc
    if start_year < 1 or end_year < start_year:
        raise ContinuityError("Reviewed release contract has an invalid year interval")
    expected_year_spec = f"{start_year}:{end_year}"
    if release.get("default_year_spec") != expected_year_spec:
        raise ContinuityError("Reviewed release contract default_year_spec is inconsistent")
    artifact_prch = artifacts.get("prch_cleaned", {}) if isinstance(artifacts, dict) else {}
    artifact_lineage = artifacts.get("lineage", {}) if isinstance(artifacts, dict) else {}
    canonical_paths = {
        panel_path,
        str(dataset.get("canonical_output", "")),
        str(artifact_prch.get("path", "")) if isinstance(artifact_prch, dict) else "",
    }
    if canonical_paths != {panel_path}:
        raise ContinuityError("Reviewed release contract disagrees on the canonical clean panel")
    if (
        not isinstance(artifact_lineage, dict)
        or str(artifact_lineage.get("path", "")) != lineage_path
    ):
        raise ContinuityError("Reviewed release contract disagrees on canonical Stage 06 lineage")
    if continuity_path != CANONICAL_CONTINUITY_CROSSWALK:
        raise ContinuityError("Reviewed release contract has an invalid continuity QA path")
    expected_continuity_paths = {
        "crosswalk": CANONICAL_CONTINUITY_CROSSWALK,
        "manifest": CANONICAL_CONTINUITY_MANIFEST,
        "value_lineage": CANONICAL_CONTINUITY_VALUE_LINEAGE,
        "verification": CANONICAL_CONTINUITY_VERIFICATION,
    }
    observed_continuity_paths = {
        "crosswalk": continuity_path,
        "manifest": continuity_manifest_path,
        "value_lineage": continuity_value_lineage_path,
        "verification": continuity_verification_path,
    }
    if observed_continuity_paths != expected_continuity_paths:
        raise ContinuityError("Reviewed release contract has invalid continuity evidence paths")
    for label, relative in (
        ("panel", panel_path),
        ("lineage", lineage_path),
        *observed_continuity_paths.items(),
    ):
        path = Path(relative)
        if path.is_absolute() or ".." in path.parts:
            raise ContinuityError(f"Reviewed release contract {label} path is not portable")
    return {
        "continuity_output": Path(continuity_path).parent.as_posix(),
        "continuity_manifest": continuity_manifest_path,
        "continuity_value_lineage": continuity_value_lineage_path,
        "continuity_verification": continuity_verification_path,
        "lineage_input": lineage_path,
        "panel_input": panel_path,
        "years": list(range(start_year, end_year + 1)),
    }


def parse_args() -> argparse.Namespace:
    root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(root), help="External IPEDSDB_ROOT")
    parser.add_argument("--years", default="2004:2023")
    parser.add_argument("--panel", default=None)
    parser.add_argument("--value-lineage", default=None)
    parser.add_argument("--out-dir", default=None)
    parser.add_argument("--repo", default=None, help="Repository containing the reviewed v2 contracts")
    parser.add_argument(
        "--mode",
        choices=("development", "release"),
        default=None,
        help="Defaults to release for canonical v2 output and development with explicit --out-dir.",
    )
    parser.add_argument(
        "--require-complete-year-scope",
        action=argparse.BooleanOptionalAction,
        default=None,
        help=(
            "Require every requested year to occur in the input. Defaults to true for the canonical "
            "v2 output and false for an explicitly supplied development --out-dir."
        ),
    )
    return parser.parse_args()


def json_compact(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def sha256_json(value: object) -> str:
    return sha256_text(json_compact(value))


def file_sha256(path: Path) -> str:
    _, digest = compute_file_metadata(path)
    if not digest:
        raise ContinuityError(f"Cannot hash missing file: {path}")
    return digest


def portable_relative_path(path: Path, base: Path, *, release: bool) -> str:
    resolved = path.expanduser().absolute()
    resolved_base = base.expanduser().absolute()
    try:
        return resolved.relative_to(resolved_base).as_posix()
    except ValueError as exc:
        if release:
            raise ContinuityError(f"Release artifact is outside its portable root {resolved_base}: {resolved}") from exc
        return f"development-external/{resolved.name}"


def portable_tool_bindings(raw: dict[str, object]) -> dict[str, object]:
    system_tools: dict[str, object] = {}
    raw_system = raw.get("system_tools", {})
    if isinstance(raw_system, dict):
        for name, binding in sorted(raw_system.items()):
            record = binding if isinstance(binding, dict) else {}
            system_tools[str(name)] = {
                "executable": Path(str(record.get("path", ""))).name if record.get("path") else "",
                "sha256": str(record.get("sha256", "")),
                "version": str(record.get("version", "")),
            }
    return {
        "container_image_digest": str(raw.get("container_image_digest", "")),
        "implementation": str(raw.get("implementation", "")),
        "packages": dict(raw.get("packages", {})) if isinstance(raw.get("packages"), dict) else {},
        "platform": str(raw.get("platform", "")),
        "python": str(raw.get("python", "")),
        "system_tools": system_tools,
    }


def load_json_object(path: Path) -> dict[str, object]:
    def reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
        output: dict[str, object] = {}
        for key, value in pairs:
            if key in output:
                raise ContinuityError(f"JSON evidence repeats key {key!r}: {path}")
            output[key] = value
        return output

    try:
        value = json.loads(
            path.read_text(encoding="utf-8"), object_pairs_hook=reject_duplicate_keys
        )
    except (OSError, json.JSONDecodeError, ContinuityError) as exc:
        raise ContinuityError(f"Cannot read JSON evidence {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ContinuityError(f"JSON evidence must contain an object: {path}")
    return value


def causal_artifact_binding(run_dir: Path, *, stage: str, path: Path, expected_sha256: str) -> None:
    stage_manifest = load_json_object(run_dir / f"{stage}.json")
    metadata = stage_manifest.get("output_metadata", {})
    if not isinstance(metadata, dict):
        raise ContinuityError(f"Stage {stage} causal output metadata is malformed")
    target = str(path.expanduser().absolute())
    record = metadata.get(target)
    if not isinstance(record, dict):
        raise ContinuityError(f"Stage {stage} causal receipt does not bind required artifact: {target}")
    if str(record.get("sha256", "")) != expected_sha256:
        raise ContinuityError(f"Stage {stage} causal receipt hash is stale for {target}")


def build_runtime_bindings(
    *,
    root: Path,
    repo: Path,
    mode: str,
    panel_path: Path,
    panel_sha256: str,
    lineage_path: Path | None,
    lineage_sha256: str,
) -> dict[str, object]:
    release = mode == "release"
    try:
        git = git_state(repo)
        contract_id, contract_hashes = current_contract_hashes(repo)
        tools = portable_tool_bindings(tool_versions())
    except ProvenanceError as exc:
        raise ContinuityError(str(exc)) from exc
    code_paths = [
        repo / "Scripts" / "QA_QC" / "22_build_entity_continuity_crosswalk.py",
        repo / "Scripts" / "access_build_utils.py",
        repo / "Scripts" / "stage_provenance.py",
    ]
    missing_code = [path for path in code_paths if not path.is_file()]
    if missing_code:
        raise ContinuityError("Imported build code is missing: " + ", ".join(str(path) for path in missing_code))
    code_hashes = {path.relative_to(repo).as_posix(): file_sha256(path) for path in code_paths}
    causal_path = ""
    causal_sha = ""
    if release:
        if bool(git.get("git_dirty")):
            raise ContinuityError("Release continuity evidence requires a clean Git tree")
        container_digest = str(tools.get("container_image_digest", "")).strip()
        if not re.fullmatch(r"sha256:[0-9a-fA-F]{64}", container_digest):
            raise ContinuityError(
                "Release continuity evidence requires an immutable sha256 container digest"
            )
        try:
            verify_run(
                root=root,
                repo=repo,
                required_stages=REQUIRED_CAUSAL_STAGES,
            )
            causal_run = resolve_run_dir(root)
        except ProvenanceError as exc:
            raise ContinuityError(f"Release causal provenance verification failed: {exc}") from exc
        causal_manifest = causal_run / "run_manifest.json"
        causal_path = portable_relative_path(causal_manifest, root, release=True)
        causal_sha = provenance_sha256_file(causal_manifest)
        causal_artifact_binding(causal_run, stage="07", path=panel_path, expected_sha256=panel_sha256)
        if lineage_path is None:
            raise ContinuityError("Release continuity evidence requires Stage 06 value lineage")
        causal_artifact_binding(causal_run, stage="06", path=lineage_path, expected_sha256=lineage_sha256)
    else:
        try:
            causal_run = resolve_run_dir(root)
            causal_manifest = causal_run / "run_manifest.json"
            if causal_manifest.is_file():
                causal_path = portable_relative_path(causal_manifest, root, release=False)
                causal_sha = provenance_sha256_file(causal_manifest)
        except ProvenanceError:
            pass
    return {
        "causal_run_manifest_path": causal_path,
        "causal_run_manifest_sha256": causal_sha,
        "code_hashes": code_hashes,
        "contract_hashes": contract_hashes,
        "contract_id": contract_id,
        "git_commit": str(git.get("git_commit", "")),
        "git_dirty": bool(git.get("git_dirty")),
        "tool_versions": tools,
    }


def canonical_scalar(value: object) -> str:
    """Return a stable, whitespace-normalized scalar representation."""

    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if not math.isfinite(value):
            return ""
        if value.is_integer():
            return str(int(value))
        return format(value, ".15g")
    text = re.sub(r"\s+", " ", str(value).strip())
    return "" if text.casefold() in NULL_TOKENS else text


def normalize_institution_name(value: object) -> str:
    text = unicodedata.normalize("NFKD", canonical_scalar(value).casefold())
    normalized = "".join(character for character in text if character.isalnum())
    if normalized in NORMALIZED_PLACEHOLDERS or set(normalized) in ({"0"}, {"9"}):
        return ""
    return normalized


def normalize_full_opeid(value: object) -> tuple[str, str]:
    """Return an eight-digit semantic OPEID and status without treating OPEID6 as stable."""

    text = canonical_scalar(value)
    if not text:
        return "", "missing"
    compact = re.sub(r"[\s-]+", "", text)
    if not re.fullmatch(r"[0-9]{1,8}", compact):
        return "", "invalid"
    normalized = compact.zfill(8)
    if normalized in FULL_OPEID_SENTINELS or normalized[:6] in {"000000", "999999"}:
        return "", "sentinel"
    return normalized, "valid"


def normalize_opeid6_for_history(value: object) -> tuple[str, str]:
    text = canonical_scalar(value)
    if not text:
        return "", "missing"
    compact = re.sub(r"[\s-]+", "", text)
    if not re.fullmatch(r"[0-9]{1,6}", compact):
        return "", "invalid"
    normalized = compact.zfill(6)
    if normalized in {"000000", "999999"}:
        return "", "sentinel"
    return normalized, "valid"


def canonical_integer(value: object, *, field: str, row_number: int, minimum: int = 0) -> int:
    text = canonical_scalar(value)
    if not text:
        raise ContinuityError(f"{field} is blank at input row {row_number}")
    if not re.fullmatch(r"[+-]?[0-9]+", text):
        raise ContinuityError(f"{field} must be an integer at input row {row_number}: {text!r}")
    number = int(text)
    if number < minimum:
        raise ContinuityError(f"{field} must be at least {minimum} at input row {row_number}: {number}")
    return number


def column_index(columns: Iterable[str]) -> dict[str, list[str]]:
    index: dict[str, list[str]] = {}
    for raw in columns:
        column = str(raw)
        index.setdefault(column.upper(), []).append(column)
    collisions = {key: values for key, values in index.items() if len(values) > 1}
    if collisions:
        details = "; ".join(f"{key}={values}" for key, values in sorted(collisions.items()))
        raise ContinuityError(f"Case-insensitive duplicate input columns are ambiguous: {details}")
    return index


def first_column(index: dict[str, list[str]], candidates: Sequence[str]) -> str:
    for candidate in candidates:
        values = index.get(candidate.upper(), [])
        if values:
            return values[0]
    return ""


def all_columns(index: dict[str, list[str]], candidates: Sequence[str]) -> list[str]:
    found: list[str] = []
    for candidate in candidates:
        values = index.get(candidate.upper(), [])
        if values and values[0] not in found:
            found.append(values[0])
    return sorted(found, key=lambda value: value.upper())


def history_for_column(group: pd.DataFrame, year_col: str, column: str) -> list[dict[str, object]]:
    if not column:
        return []
    return [
        {"year": int(row[year_col]), "value": canonical_scalar(row[column])}
        for _, row in group.iterrows()
    ]


def history_for_columns(group: pd.DataFrame, year_col: str, columns: Sequence[str]) -> list[dict[str, object]]:
    if not columns:
        return []
    history: list[dict[str, object]] = []
    for _, row in group.iterrows():
        values = {
            column: canonical_scalar(row[column])
            for column in columns
            if canonical_scalar(row[column])
        }
        history.append({"year": int(row[year_col]), "values": values})
    return history


def semantic_opeid_history(
    group: pd.DataFrame,
    *,
    year_col: str,
    full_columns: Sequence[str],
    opeid6_columns: Sequence[str],
) -> tuple[list[dict[str, object]], list[str], list[str], list[str]]:
    if not full_columns and not opeid6_columns:
        return [], [], [], []
    history: list[dict[str, object]] = []
    all_full: set[str] = set()
    all_opeid6: set[str] = set()
    invalid_tokens: set[str] = set()
    for _, row in group.iterrows():
        normalized_full: set[str] = set()
        normalized_opeid6: set[str] = set()
        sources: dict[str, str] = {}
        for column in full_columns:
            raw = canonical_scalar(row[column])
            normalized, status = normalize_full_opeid(raw)
            if raw:
                sources[column] = raw
            if status == "valid":
                normalized_full.add(normalized)
                all_full.add(normalized)
            elif status in {"invalid", "sentinel"}:
                invalid_tokens.add(f"{column}:{raw}:{status}")
        for column in opeid6_columns:
            raw = canonical_scalar(row[column])
            normalized, status = normalize_opeid6_for_history(raw)
            if raw:
                sources[column] = raw
            if status == "valid":
                normalized_opeid6.add(normalized)
                all_opeid6.add(normalized)
            elif status in {"invalid", "sentinel"}:
                invalid_tokens.add(f"{column}:{raw}:{status}")
        history.append(
            {
                "normalized_full_opeids": sorted(normalized_full),
                "normalized_opeid6_values": sorted(normalized_opeid6),
                "source_values": sources,
                "year": int(row[year_col]),
            }
        )
    return history, sorted(all_full), sorted(all_opeid6), sorted(invalid_tokens)


def semantic_opeid_change_count(history: Sequence[dict[str, object]]) -> int:
    changes = 0
    previous: tuple[str, ...] | None = None
    for entry in history:
        raw_values = entry.get("normalized_full_opeids", [])
        values = tuple(str(value) for value in raw_values) if isinstance(raw_values, list) else ()
        if not values:
            continue
        if previous is not None and values != previous:
            changes += 1
        previous = values
    return changes


def simple_change_count(history: Sequence[dict[str, object]]) -> int:
    changes = 0
    previous = ""
    for entry in history:
        value = str(entry.get("value", ""))
        if previous and value and value != previous:
            changes += 1
        if value:
            previous = value
    return changes


def mapping_change_count(history: Sequence[dict[str, object]]) -> int:
    changes = 0
    previous: dict[str, str] | None = None
    for entry in history:
        raw_values = entry.get("values", {})
        values = dict(raw_values) if isinstance(raw_values, dict) else {}
        if not values:
            continue
        if previous is not None and values != previous:
            changes += 1
        previous = values
    return changes


def values_for_columns(group: pd.DataFrame, columns: Sequence[str]) -> dict[str, list[str]]:
    values: dict[str, list[str]] = {}
    for column in columns:
        observed = sorted({canonical_scalar(value) for value in group[column] if canonical_scalar(value)})
        values[column] = observed
    return values


def is_candidate_identifier(value: str) -> bool:
    text = canonical_scalar(value)
    normalized = unicodedata.normalize("NFKD", text)
    compact = "".join(character for character in normalized if character.isalnum()).upper()
    if compact in {
        "",
        "NA",
        "NONE",
        "NULL",
        "UNK",
        "UNKNOWN",
        "MISSING",
        "NOTAPPLICABLE",
        "NOTAVAILABLE",
        "NOTREPORTED",
        "UNAVAILABLE",
        "UNREPORTED",
    }:
        return False
    if any(character.isdigit() and character not in "0123456789" for character in text):
        return False
    if set(compact) in ({"0"}, {"9"}):
        return False
    numeric_match = re.fullmatch(r"[+-]?([0-9]+)(?:\.0+)?", text)
    if numeric_match:
        if text.startswith("-"):
            return False
        digits = numeric_match.group(1)
        number = int(digits)
        return number > 0 and set(digits) != {"9"}
    return any(character != "0" for character in compact)


def normalize_relationship_identifier(column: str, value: object) -> str:
    text = canonical_scalar(value)
    upper = column.upper()
    if upper in {"PARENT_OPEID", "PARENTOPEID"}:
        normalized, status = normalize_full_opeid(text)
        return normalized if status == "valid" else ""
    if upper in {"PARENT_UNITID", "PARENTUNITID", "PARENT_UNIT_ID", "PARENTID"}:
        if not re.fullmatch(r"[+-]?[0-9]+", text):
            return ""
        number = int(text)
        digits = text.lstrip("+-")
        return str(number) if number > 0 and set(digits) != {"9"} else ""
    return text if is_candidate_identifier(text) else ""


def has_parent_child_evidence(row: pd.Series, columns: Sequence[str]) -> bool:
    for column in columns:
        value = canonical_scalar(row[column])
        if not value:
            continue
        if column.upper().startswith("PRCH") or normalize_relationship_identifier(column, value):
            return True
    return False


def build_candidate_evidence(
    panel: pd.DataFrame,
    *,
    unitid_col: str,
    year_col: str,
    full_opeid_columns: Sequence[str],
    institution_name_column: str,
    relationship_id_columns: Sequence[str],
    spans: dict[int, tuple[int, int]],
) -> tuple[dict[int, list[dict[str, object]]], dict[int, list[dict[str, object]]]]:
    """Derive corroborated one-to-one candidates at adjacent span boundaries."""

    predecessors: dict[int, list[dict[str, object]]] = {unitid: [] for unitid in spans}
    successors: dict[int, list[dict[str, object]]] = {unitid: [] for unitid in spans}
    if not full_opeid_columns:
        return predecessors, successors

    by_key = panel.set_index([unitid_col, year_col], drop=False)
    identifier_occurrences: dict[str, set[tuple[int, int]]] = {}
    row_identifiers: dict[tuple[int, int], set[str]] = {}
    row_has_invalid_identifier: dict[tuple[int, int], bool] = {}
    for _, row in panel.iterrows():
        unitid = int(row[unitid_col])
        year = int(row[year_col])
        key = (unitid, year)
        row_identifiers.setdefault(key, set())
        row_has_invalid_identifier.setdefault(key, False)
        for column in full_opeid_columns:
            identifier, status = normalize_full_opeid(row[column])
            if status == "valid":
                identifier_occurrences.setdefault(identifier, set()).add((unitid, year))
                row_identifiers[key].add(identifier)
            elif status in {"invalid", "sentinel"}:
                row_has_invalid_identifier[key] = True

    for identifier, occurrence_set in sorted(identifier_occurrences.items()):
        owners_by_year: dict[int, set[int]] = {}
        for unitid, year in occurrence_set:
            owners_by_year.setdefault(year, set()).add(unitid)
        units = sorted({unitid for unitid, _ in occurrence_set})
        for old_unitid in units:
            _, old_last = spans[old_unitid]
            new_first = old_last + 1
            old_owners = owners_by_year.get(old_last, set())
            new_owners = owners_by_year.get(new_first, set())
            if old_owners != {old_unitid} or len(new_owners) != 1:
                continue
            new_unitid = next(iter(new_owners))
            if new_unitid == old_unitid or spans[new_unitid][0] != new_first:
                continue
            old_key = (old_unitid, old_last)
            new_key = (new_unitid, new_first)
            if (
                row_identifiers.get(old_key) != {identifier}
                or row_identifiers.get(new_key) != {identifier}
                or row_has_invalid_identifier.get(old_key, False)
                or row_has_invalid_identifier.get(new_key, False)
            ):
                continue
            old_row = by_key.loc[(old_unitid, old_last)]
            new_row = by_key.loc[(new_unitid, new_first)]
            corroboration: list[dict[str, str]] = []
            if institution_name_column:
                old_name = normalize_institution_name(old_row[institution_name_column])
                new_name = normalize_institution_name(new_row[institution_name_column])
                if old_name and old_name == new_name:
                    corroboration.append(
                        {
                            "evidence_source_column": institution_name_column,
                            "kind": "exact_normalized_institution_name",
                            "shared_value": old_name,
                        }
                    )
            for column in relationship_id_columns:
                old_value = normalize_relationship_identifier(column, old_row[column])
                new_value = normalize_relationship_identifier(column, new_row[column])
                if (
                    old_value
                    and old_value == new_value
                    and not (
                        column.upper() in {"PARENT_OPEID", "PARENTOPEID"}
                        and old_value == identifier
                    )
                ):
                    corroboration.append(
                        {
                            "evidence_source_column": column,
                            "kind": "exact_explicit_relationship_identifier",
                            "shared_value": old_value,
                        }
                    )
            if not corroboration:
                continue
            old_opeid_sources = sorted(
                [
                    column
                    for column in full_opeid_columns
                    if normalize_full_opeid(old_row[column]) == (identifier, "valid")
                ],
                key=str.upper,
            )
            new_opeid_sources = sorted(
                [
                    column
                    for column in full_opeid_columns
                    if normalize_full_opeid(new_row[column]) == (identifier, "valid")
                ],
                key=str.upper,
            )
            opeid_sources = sorted({*old_opeid_sources, *new_opeid_sources}, key=str.upper)
            rationale = (
                "unique full OPEID ownership at adjacent non-overlapping UNITID spans with "
                "independent corroboration"
            )
            base = {
                "corroboration": corroboration,
                "evidence_source_columns": opeid_sources,
                "from_full_opeid_source_columns": old_opeid_sources,
                "from_last_year": old_last,
                "rationale": rationale,
                "shared_normalized_full_opeid": identifier,
                "to_full_opeid_source_columns": new_opeid_sources,
                "to_first_year": new_first,
            }
            successors[old_unitid].append(
                {**base, "candidate_unitid": new_unitid, "relationship": "potential_successor"}
            )
            predecessors[new_unitid].append(
                {**base, "candidate_unitid": old_unitid, "relationship": "potential_predecessor"}
            )

    def dedupe(records: list[dict[str, object]]) -> list[dict[str, object]]:
        unique = {json_compact(record): record for record in records}
        return [unique[key] for key in sorted(unique)]

    return (
        {unitid: dedupe(records) for unitid, records in predecessors.items()},
        {unitid: dedupe(records) for unitid, records in successors.items()},
    )


def frame_schema_hash(columns: Sequence[tuple[str, str]]) -> str:
    return sha256_json([{"name": name, "logical_type": logical_type} for name, logical_type in columns])


def crosswalk_logical_schema() -> list[tuple[str, str]]:
    schema: list[tuple[str, str]] = []
    for column in CROSSWALK_COLUMNS:
        if column in {"has_internal_gap", "release_eligible"}:
            logical_type = "boolean"
        elif column in {"UNITID", "first_year", "last_year", "value_lineage_rows"} or column.endswith("_count"):
            logical_type = "integer"
        else:
            logical_type = "string"
        schema.append((column, logical_type))
    return schema


def parquet_schema_hash(parquet_file: pq.ParquetFile) -> str:
    return sha256_json(
        [
            {"name": field.name, "nullable": bool(field.nullable), "physical_type": str(field.type)}
            for field in parquet_file.schema_arrow
        ]
    )


def csv_payload(frame: pd.DataFrame) -> str:
    return frame.to_csv(index=False, lineterminator="\n")


def render_summary(summary: pd.DataFrame) -> str:
    lines = ["# Entity Continuity Summary", "", "| Metric | Value |", "| --- | --- |"]
    for _, row in summary.iterrows():
        metric = str(row["metric"]).replace("|", "\\|")
        value = str(row["value"]).replace("|", "\\|")
        lines.append(f"| {metric} | {value} |")
    lines.extend(
        [
            "",
            (
                "Potential links are review candidates only. They are not asserted mergers, "
                "closures, or identity equivalences."
            ),
            "",
        ]
    )
    return "\n".join(lines)


def bind_value_lineage(
    panel: pd.DataFrame,
    *,
    unitid_col: str,
    year_col: str,
    evidence_columns: Sequence[str],
    lineage_path: Path | None,
    mode: str,
    expected_contract_id: str,
) -> tuple[pd.DataFrame, dict[int, set[str]]]:
    output_columns = sorted(REQUIRED_LINEAGE_COLUMNS)
    issues: dict[int, set[str]] = {
        int(unitid): set() for unitid in panel[unitid_col].drop_duplicates().tolist()
    }
    if lineage_path is None or not lineage_path.is_file():
        for unit_issues in issues.values():
            unit_issues.add("missing_stage06_value_lineage")
        if mode == "release":
            raise ContinuityError("Release continuity evidence requires Stage 06 value lineage parquet")
        return pd.DataFrame(columns=output_columns), issues

    parquet_file = pq.ParquetFile(lineage_path)
    missing_columns = sorted(REQUIRED_LINEAGE_COLUMNS - set(parquet_file.schema_arrow.names))
    if missing_columns:
        raise ContinuityError(f"Stage 06 value lineage is missing columns: {missing_columns}")
    for column in ("UNITID", "year"):
        field_type = parquet_file.schema_arrow.field(column).type
        if not pa.types.is_integer(field_type):
            raise ContinuityError(
                f"Stage 06 value lineage {column} must use an integer Arrow type, got {field_type}"
            )
    evidence_upper = sorted({column.upper() for column in evidence_columns})
    panel_years = sorted({int(value) for value in panel[year_col].unique()})
    lineage = pd.read_parquet(
        lineage_path,
        columns=output_columns,
        filters=[("analysis_column", "in", evidence_upper), ("year", "in", panel_years)],
    )
    if lineage.empty:
        raise ContinuityError("Stage 06 value lineage is empty")
    lineage = lineage.copy()
    lineage["UNITID"] = [
        canonical_integer(value, field="lineage UNITID", row_number=row_number, minimum=1)
        for row_number, value in enumerate(lineage["UNITID"], start=1)
    ]
    lineage["year"] = [
        canonical_integer(value, field="lineage year", row_number=row_number, minimum=1)
        for row_number, value in enumerate(lineage["year"], start=1)
    ]
    canonical_analysis_columns = lineage["analysis_column"].map(
        lambda value: canonical_scalar(value).upper()
    )
    raw_analysis_columns = lineage["analysis_column"].map(
        lambda value: "" if value is None else str(value)
    )
    if not raw_analysis_columns.equals(canonical_analysis_columns):
        raise ContinuityError(
            "Stage 06 value lineage analysis_column values must be canonical uppercase identifiers"
        )
    lineage["analysis_column"] = canonical_analysis_columns
    observed_contract_ids = {str(value) for value in lineage["contract_id"]}
    if observed_contract_ids != {expected_contract_id}:
        raise ContinuityError(
            "Stage 06 continuity lineage contract_id does not match the current reviewed contract: "
            f"expected={expected_contract_id!r} observed={sorted(observed_contract_ids)!r}"
        )
    evidence_upper_set = set(evidence_upper)
    panel_year_set = set(panel_years)
    lineage = lineage[
        lineage["analysis_column"].isin(evidence_upper_set) & lineage["year"].isin(panel_year_set)
    ].copy()
    if lineage.empty:
        raise ContinuityError("Stage 06 value lineage contains no requested continuity evidence columns")
    identity_columns = [
        "contract_id",
        "variable_id",
        "source_varnumber",
        "varname",
        "source_row_id",
        "source_row_hash",
        "source_file",
        "access_table_name",
        "transformation_id",
        "lineage_role",
    ]
    blank_identity = pd.Series(False, index=lineage.index)
    for column in identity_columns:
        blank_identity |= lineage[column].map(canonical_scalar).eq("")
    if blank_identity.any():
        raise ContinuityError(
            f"Stage 06 value lineage has {int(blank_identity.sum())} rows with blank scientific identities"
        )
    duplicate_lineage = lineage.duplicated(keep=False)
    if duplicate_lineage.any():
        examples = lineage.loc[duplicate_lineage, output_columns].head(10).to_dict("records")
        raise ContinuityError(
            f"Stage 06 continuity lineage contains exact duplicate rows; examples={examples}"
        )

    panel_keys = set(zip(panel[unitid_col].astype(int), panel[year_col].astype(int)))
    lineage_keys = set(zip(lineage["UNITID"].astype(int), lineage["year"].astype(int)))
    orphan_keys = sorted(lineage_keys - panel_keys)
    if orphan_keys:
        raise ContinuityError(f"Stage 06 continuity lineage contains keys absent from the panel: {orphan_keys[:10]}")

    lookup: dict[tuple[int, int, str], set[str]] = {
        (int(unitid), int(year), str(column)): {
            canonical_scalar(value)
            for value in group["normalized_value"]
            if canonical_scalar(value)
        }
        for (unitid, year, column), group in lineage.groupby(
            ["UNITID", "year", "analysis_column"], sort=False
        )
    }
    for _, row in panel.iterrows():
        unitid = int(row[unitid_col])
        year = int(row[year_col])
        for column in evidence_columns:
            value = canonical_scalar(row[column])
            lineage_values = lookup.get((unitid, year, column.upper()), set())
            if value and not lineage_values:
                issues[unitid].add(f"missing_value_lineage:{column}:{year}")
                continue
            expected_values = {value} if value else set()
            if lineage_values != expected_values:
                issues[unitid].add(f"value_lineage_mismatch:{column}:{year}")

    sort_columns = [
        "year",
        "UNITID",
        "analysis_column",
        "source_file",
        "access_table_name",
        "variable_id",
        "source_row_id",
    ]
    lineage = lineage.sort_values(sort_columns, kind="stable").reset_index(drop=True)
    return lineage, issues


def build_outputs(
    panel: pd.DataFrame,
    *,
    unitid_col: str,
    year_col: str,
    requested_years: list[int],
    evidence_columns: dict[str, object],
    lineage: pd.DataFrame,
    lineage_issues: dict[int, set[str]],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    name_col = str(evidence_columns["institution_name"])
    full_opeid_cols = list(evidence_columns["full_opeid"])
    opeid6_cols = list(evidence_columns["opeid6"])
    opeid_cols = [*full_opeid_cols, *opeid6_cols]
    parent_child_cols = list(evidence_columns["parent_child"])
    sector_col = str(evidence_columns["sector"])
    control_col = str(evidence_columns["control"])
    level_col = str(evidence_columns["level"])

    groups = {int(unitid): group.copy() for unitid, group in panel.groupby(unitid_col, sort=True)}
    spans = {
        unitid: (int(group[year_col].min()), int(group[year_col].max()))
        for unitid, group in groups.items()
    }
    predecessor_evidence, successor_evidence = build_candidate_evidence(
        panel,
        unitid_col=unitid_col,
        year_col=year_col,
        full_opeid_columns=full_opeid_cols,
        institution_name_column=name_col,
        relationship_id_columns=[
            column for column in parent_child_cols if not column.upper().startswith("PRCH")
        ],
        spans=spans,
    )
    lineage_summaries: dict[int, dict[str, object]] = {}
    for unitid, group in lineage.groupby("UNITID", sort=False):
        lineage_summaries[int(unitid)] = {
            "access_tables": sorted(
                {
                    canonical_scalar(value)
                    for value in group["access_table_name"]
                    if canonical_scalar(value)
                }
            ),
            "row_count": len(group),
            "source_files": sorted(
                {
                    canonical_scalar(value)
                    for value in group["source_file"]
                    if canonical_scalar(value)
                }
            ),
            "variable_ids": sorted(
                {
                    canonical_scalar(value)
                    for value in group["variable_id"]
                    if canonical_scalar(value)
                }
            ),
        }
    globally_missing_groups = {
        name
        for name, present in {
            "institution_name": bool(name_col),
            "full_opeid": bool(full_opeid_cols),
            "parent_child": bool(parent_child_cols),
            "sector": bool(sector_col),
            "control": bool(control_col),
            "level": bool(level_col),
        }.items()
        if not present
    }

    rows: list[dict[str, object]] = []
    for unitid, group in sorted(groups.items()):
        group = group.sort_values(year_col, kind="stable")
        observed_years = [int(year) for year in group[year_col].tolist()]
        first_year, last_year = observed_years[0], observed_years[-1]
        internal_gaps = [
            year
            for year in requested_years
            if first_year < year < last_year and year not in set(observed_years)
        ]

        name_history = history_for_column(group, year_col, name_col)
        opeid_history, opeid_values, opeid6_values, invalid_opeid_tokens = semantic_opeid_history(
            group,
            year_col=year_col,
            full_columns=full_opeid_cols,
            opeid6_columns=opeid6_cols,
        )
        raw_full_opeid_values = sorted(
            {
                canonical_scalar(value)
                for column in full_opeid_cols
                for value in group[column]
                if canonical_scalar(value)
            }
        )
        parent_child_history = history_for_columns(group, year_col, parent_child_cols)
        sector_history = history_for_column(group, year_col, sector_col)
        control_history = history_for_column(group, year_col, control_col)
        level_history = history_for_column(group, year_col, level_col)
        name_changes = simple_change_count(name_history)
        opeid_changes = semantic_opeid_change_count(opeid_history)
        parent_child_changes = mapping_change_count(parent_child_history)
        sector_changes = simple_change_count(sector_history)
        control_changes = simple_change_count(control_history)
        level_changes = simple_change_count(level_history)

        parent_values = values_for_columns(group, parent_child_cols)
        prch_hits = [
            f"{column}:{'|'.join(values)}"
            for column, values in parent_values.items()
            if column.upper().startswith("PRCH") and any(value not in {"0", "1"} for value in values)
        ]

        predecessors = predecessor_evidence[unitid]
        successors = successor_evidence[unitid]
        candidate_sources = sorted(
            {
                str(column)
                for record in [*predecessors, *successors]
                for column in [
                    *list(record.get("evidence_source_columns", [])),
                    *[
                        item.get("evidence_source_column", "")
                        for item in record.get("corroboration", [])
                        if isinstance(item, dict)
                    ],
                ]
                if column
            },
            key=str.upper,
        )
        insufficient_reasons = {f"missing_evidence_column:{name}" for name in globally_missing_groups}
        insufficient_reasons.update(lineage_issues.get(unitid, set()))
        for _, evidence_row in group.iterrows():
            year = int(evidence_row[year_col])
            if name_col and not normalize_institution_name(evidence_row[name_col]):
                insufficient_reasons.add(f"missing_institution_name:{year}")
            valid_full = {
                normalize_full_opeid(evidence_row[column])[0]
                for column in full_opeid_cols
                if normalize_full_opeid(evidence_row[column])[1] == "valid"
            }
            if full_opeid_cols and not valid_full:
                insufficient_reasons.add(f"missing_valid_full_opeid:{year}")
            if len(valid_full) > 1:
                insufficient_reasons.add(f"ambiguous_full_opeid:{year}")
            if parent_child_cols and not has_parent_child_evidence(
                evidence_row, parent_child_cols
            ):
                insufficient_reasons.add(f"missing_parent_child_evidence:{year}")
            for label, column in (
                ("sector", sector_col),
                ("control", control_col),
                ("level", level_col),
            ):
                if column and not canonical_scalar(evidence_row[column]):
                    insufficient_reasons.add(f"missing_{label}_evidence:{year}")
        if invalid_opeid_tokens:
            insufficient_reasons.add("invalid_or_sentinel_opeid")
        lineage_summary = lineage_summaries.get(
            unitid,
            {"access_tables": [], "row_count": 0, "source_files": [], "variable_ids": []},
        )
        lineage_variable_ids = list(lineage_summary["variable_ids"])
        lineage_source_files = list(lineage_summary["source_files"])
        lineage_access_tables = list(lineage_summary["access_tables"])
        flags: set[str] = set()
        if predecessors or successors:
            flags.add("potential_identity_link")
        if internal_gaps:
            flags.add("internal_year_gap")
        if len(observed_years) == 1:
            flags.add("single_year_observation")
        # A missing optional name column is reported at the bundle level.  Only
        # row-level missingness in an available name source is a UNITID risk.
        if name_col and any(
            not normalize_institution_name(entry.get("value", "")) for entry in name_history
        ):
            flags.add("missing_institution_name")
        if name_changes:
            flags.add("institution_name_change")
        if len(opeid_values) > 1 or (not opeid_values and len(raw_full_opeid_values) > 1):
            flags.add("multi_opeid")
        if len(opeid6_values) > 1:
            flags.add("multi_opeid6")
        if opeid_changes:
            flags.add("opeid_change")
        if prch_hits:
            flags.add("parent_child_flag_observed")
        if parent_child_changes:
            flags.add("parent_child_change")
        if sector_changes:
            flags.add("sector_change")
        if control_changes:
            flags.add("control_change")
        if level_changes:
            flags.add("level_change")
        if invalid_opeid_tokens:
            flags.add("invalid_opeid_evidence")
        if insufficient_reasons:
            flags.add("insufficient_evidence")
        ordered_flags = [flag for flag in RISK_FLAG_ORDER if flag in flags]
        observed_review_flags = flags - {"insufficient_evidence", "invalid_opeid_evidence"}
        risk_level = (
            "high"
            if "potential_identity_link" in flags
            else "review"
            if observed_review_flags
            else "insufficient"
            if insufficient_reasons
            else "standard"
        )
        all_sources = sorted(
            {
                unitid_col,
                year_col,
                name_col,
                sector_col,
                control_col,
                level_col,
                *opeid_cols,
                *parent_child_cols,
            }
            - {""},
            key=str.upper,
        )
        rows.append(
            {
                "UNITID": unitid,
                "first_year": first_year,
                "last_year": last_year,
                "years_observed_count": len(observed_years),
                "years_observed": "|".join(str(year) for year in observed_years),
                "has_internal_gap": bool(internal_gaps),
                "internal_gap_count": len(internal_gaps),
                "internal_gap_years": "|".join(str(year) for year in internal_gaps),
                "institution_name_change_count": name_changes,
                "institution_name_history": json_compact(name_history),
                "opeid_change_count": opeid_changes,
                "opeid_history": json_compact(opeid_history),
                "opeid_count": len(opeid_values),
                "opeid_values": "|".join(opeid_values),
                "opeid6_count": len(opeid6_values),
                "opeid6_values": "|".join(opeid6_values),
                "parent_child_change_count": parent_child_changes,
                "parent_child_history": json_compact(parent_child_history),
                "prch_review_values": ";".join(prch_hits),
                "sector_change_count": sector_changes,
                "sector_history": json_compact(sector_history),
                "control_change_count": control_changes,
                "control_history": json_compact(control_history),
                "level_change_count": level_changes,
                "level_history": json_compact(level_history),
                "potential_predecessor_unitids": json_compact(
                    sorted({int(record["candidate_unitid"]) for record in predecessors})
                ),
                "potential_predecessor_evidence": json_compact(predecessors),
                "potential_successor_unitids": json_compact(
                    sorted({int(record["candidate_unitid"]) for record in successors})
                ),
                "potential_successor_evidence": json_compact(successors),
                "candidate_link_status": (
                    "potential_only_unique_full_opeid_with_corroboration"
                    if predecessors or successors
                    else ""
                ),
                "join_risk_flags": "|".join(ordered_flags),
                "join_risk_level": risk_level,
                "evidence_sufficiency": "insufficient" if insufficient_reasons else "complete",
                "insufficient_evidence_reasons": "|".join(sorted(insufficient_reasons)),
                "release_eligible": not insufficient_reasons,
                "invalid_opeid_tokens": "|".join(invalid_opeid_tokens),
                "institution_name_source_column": name_col,
                "opeid_source_columns": "|".join(opeid_cols),
                "parent_child_source_columns": "|".join(parent_child_cols),
                "sector_source_column": sector_col,
                "control_source_column": control_col,
                "level_source_column": level_col,
                "candidate_link_source_columns": "|".join(candidate_sources),
                "evidence_source_columns": "|".join(all_sources),
                "evidence_variable_ids": "|".join(lineage_variable_ids),
                "evidence_source_files": "|".join(lineage_source_files),
                "evidence_access_tables": "|".join(lineage_access_tables),
                "value_lineage_rows": int(lineage_summary["row_count"]),
            }
        )

    crosswalk = (
        pd.DataFrame(rows, columns=CROSSWALK_COLUMNS)
        .sort_values("UNITID", kind="stable")
        .reset_index(drop=True)
    )
    optional_groups = {
        "institution_name": bool(name_col),
        "full_opeid": bool(full_opeid_cols),
        "opeid6_history_only": bool(opeid6_cols),
        "parent_child": bool(parent_child_cols),
        "sector": bool(sector_col),
        "control": bool(control_col),
        "level": bool(level_col),
    }
    summary_rows: list[dict[str, object]] = [
        {"metric": "unitids", "value": len(crosswalk)},
        {"metric": "input_rows", "value": len(panel)},
        {"metric": "requested_years", "value": "|".join(str(year) for year in requested_years)},
        {"metric": "observed_years", "value": "|".join(str(year) for year in sorted(panel[year_col].unique()))},
        {"metric": "high_risk_unitids", "value": int((crosswalk["join_risk_level"] == "high").sum())},
        {"metric": "review_unitids", "value": int((crosswalk["join_risk_level"] == "review").sum())},
        {
            "metric": "insufficient_evidence_unitids",
            "value": int((crosswalk["evidence_sufficiency"] == "insufficient").sum()),
        },
        {
            "metric": "release_eligible_unitids",
            "value": int(crosswalk["release_eligible"].sum()),
        },
        {"metric": "standard_unitids", "value": int((crosswalk["join_risk_level"] == "standard").sum())},
        {"metric": "internal_gap_unitids", "value": int(crosswalk["has_internal_gap"].sum())},
        {
            "metric": "institution_name_change_unitids",
            "value": int((crosswalk["institution_name_change_count"] > 0).sum()),
        },
        {"metric": "multi_opeid_unitids", "value": int((crosswalk["opeid_count"] > 1).sum())},
        {"metric": "multi_opeid6_unitids", "value": int((crosswalk["opeid6_count"] > 1).sum())},
        {"metric": "opeid_change_unitids", "value": int((crosswalk["opeid_change_count"] > 0).sum())},
        {
            "metric": "parent_child_flag_unitids",
            "value": int(crosswalk["prch_review_values"].astype(str).ne("").sum()),
        },
        {
            "metric": "parent_child_change_unitids",
            "value": int((crosswalk["parent_child_change_count"] > 0).sum()),
        },
        {"metric": "sector_change_unitids", "value": int((crosswalk["sector_change_count"] > 0).sum())},
        {"metric": "control_change_unitids", "value": int((crosswalk["control_change_count"] > 0).sum())},
        {"metric": "level_change_unitids", "value": int((crosswalk["level_change_count"] > 0).sum())},
        {
            "metric": "potential_predecessor_unitids",
            "value": int(crosswalk["potential_predecessor_unitids"].ne("[]").sum()),
        },
        {
            "metric": "potential_successor_unitids",
            "value": int(crosswalk["potential_successor_unitids"].ne("[]").sum()),
        },
        {
            "metric": "missing_optional_evidence_groups",
            "value": "|".join(sorted(name for name, present in optional_groups.items() if not present)),
        },
        {
            "metric": "missing_release_evidence_groups",
            "value": "|".join(sorted(globally_missing_groups)),
        },
    ]
    summary = pd.DataFrame(summary_rows, columns=["metric", "value"])
    return crosswalk, summary


def output_record(path: Path, *, row_count: int, schema_sha256: str) -> dict[str, object]:
    size, digest = compute_file_metadata(path)
    if not size or not digest:
        raise ContinuityError(f"Output artifact is missing or empty: {path}")
    return {
        "bytes": int(size),
        "path": path.name,
        "row_count": int(row_count),
        "schema_sha256": schema_sha256,
        "sha256": digest,
    }


def write_parquet_atomic(
    frame: pd.DataFrame,
    path: Path,
    *,
    schema: pa.Schema | None = None,
) -> None:
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.part")
    try:
        table = pa.Table.from_pandas(
            frame,
            schema=schema,
            preserve_index=False,
            safe=True,
        )
        pq.write_table(table, temporary)
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def same_bundle(left: Path, right: Path) -> bool:
    left_entries = list(left.iterdir())
    right_entries = list(right.iterdir())
    if any(path.is_symlink() or not path.is_file() for path in [*left_entries, *right_entries]):
        return False
    left_files = sorted(path.relative_to(left) for path in left_entries)
    right_files = sorted(path.relative_to(right) for path in right_entries)
    if left_files != right_files:
        return False
    return all(file_sha256(left / relative) == file_sha256(right / relative) for relative in left_files)


def publish_managed_bundle(staged_dir: Path, *, out_dir: Path, run_id: str) -> Path:
    out_dir.parent.mkdir(parents=True, exist_ok=True)
    if out_dir.exists() and not out_dir.is_symlink():
        raise ContinuityError(
            f"Refusing to replace unmanaged entity-continuity directory: {out_dir}. "
            "Use a fresh v2 output path or remove/archive the legacy directory explicitly."
        )
    run_store = out_dir.parent / f".{out_dir.name}.runs"
    if run_store.is_symlink() or (run_store.exists() and not run_store.is_dir()):
        raise ContinuityError(f"Managed continuity run store is not a directory: {run_store}")
    run_store.mkdir(parents=True, exist_ok=True)
    final_run = run_store / run_id
    if final_run.exists():
        if final_run.is_symlink() or not final_run.is_dir() or not same_bundle(staged_dir, final_run):
            raise ContinuityError(f"Immutable continuity run-id collision or drift: {final_run}")
        shutil.rmtree(staged_dir)
    else:
        try:
            os.replace(staged_dir, final_run)
        except OSError:
            # A concurrent identical builder may have won the immutable-run
            # rename. Reuse it only after exact bundle parity is established.
            if final_run.is_symlink() or not final_run.is_dir() or not same_bundle(staged_dir, final_run):
                raise
            shutil.rmtree(staged_dir)

    target = os.path.relpath(final_run, out_dir.parent)
    pointer = out_dir.parent / f".{out_dir.name}.pointer-{uuid.uuid4().hex}"
    try:
        pointer.symlink_to(target, target_is_directory=True)
        os.replace(pointer, out_dir)
    finally:
        pointer.unlink(missing_ok=True)
    return final_run


def run_build(
    *,
    root: Path,
    repo: Path,
    mode: str,
    panel_path: Path,
    lineage_path: Path | None,
    out_dir: Path,
    requested_years: list[int],
    require_complete_year_scope: bool,
) -> Path:
    root = root.expanduser().absolute()
    repo = repo.expanduser().absolute()
    panel_path = panel_path.expanduser().absolute()
    lineage_path = lineage_path.expanduser().absolute() if lineage_path is not None else None
    out_dir = out_dir.expanduser().absolute()
    if mode not in {"development", "release"}:
        raise ContinuityError(f"Unsupported continuity mode: {mode!r}")
    release = mode == "release"
    release_layout = reviewed_release_layout(repo)
    canonical_output = root / str(release_layout["continuity_output"])
    resolved_output_location = out_dir.parent.resolve() / out_dir.name
    resolved_canonical_location = canonical_output.parent.resolve() / canonical_output.name
    if not release and (
        out_dir == canonical_output or resolved_output_location == resolved_canonical_location
    ):
        raise ContinuityError(
            "Development continuity builds require an explicit noncanonical output directory"
        )
    if release and not require_complete_year_scope:
        raise ContinuityError("Release continuity evidence cannot disable complete requested-year scope")
    if (
        not requested_years
        or len(requested_years) != len(set(requested_years))
        or any(year < 1 for year in requested_years)
    ):
        raise ContinuityError("Requested years must be a nonempty unique set of positive integers")
    requested_years = sorted(requested_years)
    if requested_years != list(range(requested_years[0], requested_years[-1] + 1)):
        raise ContinuityError("Requested years must form one contiguous inclusive interval")
    if release:
        contract_years = list(release_layout["years"])
        if requested_years != contract_years:
            raise ContinuityError(
                "Release continuity years must match the reviewed contract: "
                f"expected={contract_years[0]}:{contract_years[-1]}"
            )
        expected_panel = root / str(release_layout["panel_input"])
        expected_lineage = root / str(release_layout["lineage_input"])
        expected_output = canonical_output
        if panel_path != expected_panel:
            raise ContinuityError(f"Release continuity input must be canonical: {expected_panel}")
        if lineage_path is not None and lineage_path != expected_lineage:
            raise ContinuityError(f"Release continuity lineage must be canonical: {expected_lineage}")
        if out_dir != expected_output:
            raise ContinuityError(f"Release continuity output must be canonical: {expected_output}")
        resolved_root = root.resolve()
        for label, artifact_path in (("panel", panel_path), ("lineage", lineage_path)):
            if artifact_path is None:
                continue
            try:
                artifact_path.resolve().relative_to(resolved_root)
            except ValueError as exc:
                raise ContinuityError(
                    f"Release continuity {label} resolves outside IPEDSDB_ROOT: {artifact_path}"
                ) from exc
        try:
            out_dir.parent.resolve().relative_to(resolved_root)
        except ValueError as exc:
            raise ContinuityError(
                f"Release continuity output parent resolves outside IPEDSDB_ROOT: {out_dir.parent}"
            ) from exc
    if not panel_path.is_file():
        raise ContinuityError(f"Panel file does not exist: {panel_path}")
    panel_hash_before = file_sha256(panel_path)
    parquet_file = pq.ParquetFile(panel_path)
    input_row_count = int(parquet_file.metadata.num_rows)
    if input_row_count == 0:
        raise ContinuityError("Entity-continuity input panel is empty")
    schema_names = [str(name) for name in parquet_file.schema_arrow.names]
    index = column_index(schema_names)
    unitid_col = first_column(index, ("UNITID",))
    year_col = first_column(index, ("YEAR",))
    if not unitid_col or not year_col:
        raise ContinuityError("Panel must include the required identity columns UNITID and year")
    if unitid_col != "UNITID" or year_col != "year":
        raise ContinuityError("Panel must use the exact canonical identity columns UNITID and year")

    institution_name_col = first_column(index, INSTITUTION_NAME_CANDIDATES)
    opeid_cols = all_columns(index, OPEID_CANDIDATES)
    full_opeid_cols = [column for column in opeid_cols if column.upper() in {"OPEID", "OPEIDB"}]
    opeid6_cols = [column for column in opeid_cols if column.upper() in {"OPEID6", "OPEID_6"}]
    sector_col = first_column(index, SECTOR_CANDIDATES)
    control_col = first_column(index, CONTROL_CANDIDATES)
    level_col = first_column(index, LEVEL_CANDIDATES)
    parent_child_cols = sorted(
        [
            column
            for column in schema_names
            if column.upper().startswith("PRCH")
            or column.upper() in PARENT_CHILD_EXPLICIT_CANDIDATES
        ],
        key=str.upper,
    )
    evidence_columns: dict[str, object] = {
        "institution_name": institution_name_col,
        "full_opeid": full_opeid_cols,
        "opeid6": opeid6_cols,
        "parent_child": parent_child_cols,
        "sector": sector_col,
        "control": control_col,
        "level": level_col,
    }
    selected = {
        unitid_col,
        year_col,
        institution_name_col,
        sector_col,
        control_col,
        level_col,
        *opeid_cols,
        *parent_child_cols,
    } - {""}
    selected_columns = [column for column in schema_names if column in selected]
    panel = pd.read_parquet(panel_path, columns=selected_columns)
    if len(panel) != input_row_count:
        raise ContinuityError(
            f"Parquet metadata/data row-count mismatch: metadata={input_row_count} loaded={len(panel)}"
        )

    canonical_unitids = [
        canonical_integer(value, field="UNITID", row_number=row_number, minimum=1)
        for row_number, value in enumerate(panel[unitid_col], start=1)
    ]
    canonical_years = [
        canonical_integer(value, field="year", row_number=row_number, minimum=1)
        for row_number, value in enumerate(panel[year_col], start=1)
    ]
    panel = panel.copy()
    panel[unitid_col] = canonical_unitids
    panel[year_col] = canonical_years
    duplicates = panel.duplicated([unitid_col, year_col], keep=False)
    if duplicates.any():
        examples = (
            panel.loc[duplicates, [unitid_col, year_col]]
            .drop_duplicates()
            .sort_values([unitid_col, year_col], kind="stable")
            .head(10)
            .to_dict("records")
        )
        raise ContinuityError(f"Input must be unique on UNITID-year; duplicate keys include {examples}")
    observed_years = sorted(set(canonical_years))
    outside = sorted(set(observed_years) - set(requested_years))
    missing = sorted(set(requested_years) - set(observed_years))
    if outside:
        raise ContinuityError(
            f"Input contains years outside the requested scope: outside={outside} requested={requested_years}"
        )
    if require_complete_year_scope and missing:
        raise ContinuityError(
            f"Canonical v2 continuity evidence requires complete requested-year coverage; missing={missing}"
        )

    evidence_source_columns = [
        column for column in selected_columns if column not in {unitid_col, year_col}
    ]
    lineage_hash = file_sha256(lineage_path) if lineage_path is not None and lineage_path.is_file() else ""
    runtime_bindings = build_runtime_bindings(
        root=root,
        repo=repo,
        mode=mode,
        panel_path=panel_path,
        panel_sha256=panel_hash_before,
        lineage_path=lineage_path,
        lineage_sha256=lineage_hash,
    )
    lineage, lineage_issues = bind_value_lineage(
        panel,
        unitid_col=unitid_col,
        year_col=year_col,
        evidence_columns=evidence_source_columns,
        lineage_path=lineage_path,
        mode=mode,
        expected_contract_id=str(runtime_bindings["contract_id"]),
    )

    crosswalk, summary = build_outputs(
        panel,
        unitid_col=unitid_col,
        year_col=year_col,
        requested_years=requested_years,
        evidence_columns=evidence_columns,
        lineage=lineage,
        lineage_issues=lineage_issues,
    )
    if crosswalk["UNITID"].duplicated().any() or len(crosswalk) != panel[unitid_col].nunique():
        raise ContinuityError("Internal error: output is not exactly one row per UNITID")
    insufficient_count = int((~crosswalk["release_eligible"]).sum())
    if release and insufficient_count:
        examples = crosswalk.loc[
            ~crosswalk["release_eligible"], ["UNITID", "insufficient_evidence_reasons"]
        ].head(10)
        raise ContinuityError(
            f"Release continuity evidence is scientifically insufficient for {insufficient_count} UNITIDs: "
            f"{examples.to_dict('records')}"
        )
    builder_hash = file_sha256(Path(__file__).resolve())
    input_schema_hash = parquet_schema_hash(parquet_file)
    input_relative_path = portable_relative_path(panel_path, root, release=release)
    lineage_relative_path = (
        portable_relative_path(lineage_path, root, release=release) if lineage_path is not None else ""
    )
    lineage_schema_hash = ""
    lineage_row_count = 0
    if lineage_path is not None and lineage_path.is_file():
        lineage_parquet = pq.ParquetFile(lineage_path)
        lineage_schema_hash = parquet_schema_hash(lineage_parquet)
        lineage_row_count = int(lineage_parquet.metadata.num_rows)
    run_id = "continuity-" + sha256_json(
        {
            "builder_sha256": builder_hash,
            "input_path": input_relative_path,
            "input_sha256": panel_hash_before,
            "input_schema_sha256": input_schema_hash,
            "lineage_path": lineage_relative_path,
            "lineage_sha256": lineage_hash,
            "runtime_bindings": runtime_bindings,
            "mode": mode,
            "require_complete_year_scope": require_complete_year_scope,
            "requested_years": requested_years,
            "schema_version": SCHEMA_VERSION,
        }
    )[:24]

    out_dir.parent.mkdir(parents=True, exist_ok=True)
    run_store = out_dir.parent / f".{out_dir.name}.runs"
    if run_store.is_symlink():
        raise ContinuityError(f"Managed continuity run store cannot be a symlink: {run_store}")
    run_store.mkdir(parents=True, exist_ok=True)
    staged_dir = run_store / f".{run_id}.staging-{uuid.uuid4().hex}"
    staged_dir.mkdir()
    try:
        crosswalk_path = staged_dir / "entity_continuity_crosswalk.csv"
        summary_path = staged_dir / "entity_continuity_summary.csv"
        markdown_path = staged_dir / "entity_continuity_summary.md"
        lineage_output_path = staged_dir / "entity_continuity_value_lineage.parquet"
        atomic_write_text(crosswalk_path, csv_payload(crosswalk))
        atomic_write_text(summary_path, csv_payload(summary))
        markdown = render_summary(summary)
        atomic_write_text(markdown_path, markdown)
        lineage_output_schema: pa.Schema | None = None
        if lineage_path is not None and lineage_path.is_file():
            source_schema = pq.ParquetFile(lineage_path).schema_arrow
            lineage_output_schema = pa.schema(
                [source_schema.field(column) for column in lineage.columns]
            )
        write_parquet_atomic(
            lineage,
            lineage_output_path,
            schema=lineage_output_schema,
        )
        crosswalk_schema_hash = frame_schema_hash(crosswalk_logical_schema())
        summary_schema_hash = frame_schema_hash([("metric", "string"), ("value", "string")])
        lineage_output_schema_hash = parquet_schema_hash(pq.ParquetFile(lineage_output_path))
        output_artifacts = [
            output_record(crosswalk_path, row_count=len(crosswalk), schema_sha256=crosswalk_schema_hash),
            output_record(summary_path, row_count=len(summary), schema_sha256=summary_schema_hash),
            output_record(
                markdown_path,
                row_count=len(markdown.splitlines()),
                schema_sha256=sha256_json([{"name": "markdown", "logical_type": "text"}]),
            ),
            output_record(
                lineage_output_path,
                row_count=len(lineage),
                schema_sha256=lineage_output_schema_hash,
            ),
        ]
        manifest = {
            "builder_path": "Scripts/QA_QC/22_build_entity_continuity_crosswalk.py",
            "builder_sha256": builder_hash,
            "complete_year_scope": not missing,
            "crosswalk_columns": CROSSWALK_COLUMNS,
            "crosswalk_schema_sha256": crosswalk_schema_hash,
            "evidence_columns": evidence_columns,
            "expected_bundle_files": [
                "entity_continuity_crosswalk.csv",
                "entity_continuity_manifest.json",
                "entity_continuity_summary.csv",
                "entity_continuity_summary.md",
                "entity_continuity_value_lineage.parquet",
            ],
            "input_path": input_relative_path,
            "input_column_count": len(schema_names),
            "input_row_count": input_row_count,
            "input_schema_sha256": input_schema_hash,
            "input_sha256": panel_hash_before,
            "lineage_input_path": lineage_relative_path,
            "lineage_input_row_count": lineage_row_count,
            "lineage_input_schema_sha256": lineage_schema_hash,
            "lineage_input_sha256": lineage_hash,
            "lineage_output_row_count": len(lineage),
            "loaded_evidence_column_count": len(selected_columns),
            "missing_requested_years": missing,
            "observed_years": observed_years,
            "output_artifacts": output_artifacts,
            "output_unitid_count": len(crosswalk),
            "release_eligible": insufficient_count == 0 and not missing,
            "runtime_bindings": runtime_bindings,
            "requested_years": requested_years,
            "require_complete_year_scope": require_complete_year_scope,
            "run_id": run_id,
            "schema_version": SCHEMA_VERSION,
            "mode": mode,
        }
        atomic_write_json(staged_dir / "entity_continuity_manifest.json", manifest)
        if file_sha256(panel_path) != panel_hash_before:
            raise ContinuityError("Input panel changed while continuity evidence was being built")
        if lineage_path is not None and lineage_path.is_file() and file_sha256(lineage_path) != lineage_hash:
            raise ContinuityError("Stage 06 value lineage changed while continuity evidence was being built")
        current_bindings = build_runtime_bindings(
            root=root,
            repo=repo,
            mode=mode,
            panel_path=panel_path,
            panel_sha256=panel_hash_before,
            lineage_path=lineage_path,
            lineage_sha256=lineage_hash,
        )
        if current_bindings != runtime_bindings:
            raise ContinuityError("Repository, contracts, causal chain, code, or tools changed during build")
        final_run = publish_managed_bundle(staged_dir, out_dir=out_dir, run_id=run_id)
    except Exception:
        shutil.rmtree(staged_dir, ignore_errors=True)
        raise
    return final_run


def main() -> int:
    args = parse_args()
    root = Path(args.root).expanduser()
    layout = data_layout(root)
    try:
        years = parse_years(args.years)
    except (TypeError, ValueError) as exc:
        raise SystemExit(f"Invalid --years specification: {args.years!r}: {exc}") from exc
    if not years:
        raise SystemExit("--years resolved to an empty set")
    panel_path = (
        Path(args.panel).expanduser()
        if args.panel
        else layout.panels / "v2" / f"panel_clean_prch_{min(years)}_{max(years)}.parquet"
    )
    lineage_path = (
        Path(args.value_lineage).expanduser()
        if args.value_lineage
        else layout.checks / "v2" / "wide_qc" / "qc_value_lineage.parquet"
    )
    out_dir = Path(args.out_dir).expanduser() if args.out_dir else layout.checks / "v2" / "entity_continuity"
    mode = args.mode or ("development" if args.out_dir else "release")
    repository = Path(args.repo).expanduser() if args.repo else repo_root()
    require_complete = args.require_complete_year_scope
    if require_complete is None:
        require_complete = mode == "release"
    try:
        final_run = run_build(
            root=root,
            repo=repository,
            mode=mode,
            panel_path=panel_path,
            lineage_path=lineage_path,
            out_dir=out_dir,
            requested_years=years,
            require_complete_year_scope=bool(require_complete),
        )
    except (ContinuityError, OSError, ValueError) as exc:
        raise SystemExit(f"Entity continuity build failed: {exc}") from exc
    print(f"Published entity continuity evidence atomically: {out_dir} -> {final_run}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
