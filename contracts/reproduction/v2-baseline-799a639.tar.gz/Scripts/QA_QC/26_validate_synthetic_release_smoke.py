#!/usr/bin/env python3
"""Validate the isolated synthetic Access integration build.

This verifier has no release authority.  It accepts only the repository's
synthetic integration receipt, requires development-namespaced stage outputs,
and fails if any canonical or public-release output namespace was created.
It deliberately does not call the production panel-contract validator,
external review-evidence verifier, release gate, or bundle publisher.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tomllib
from pathlib import Path
from typing import Mapping

import pandas as pd
import pyarrow.dataset as ds


SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import atomic_write_json, parse_years
from stage_provenance import (
    MANIFEST_SCHEMA_VERSION,
    _path_entry,
    current_contract_hashes,
    git_state,
    sha256_file,
    tool_versions,
)


CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
EXPECTED_YEARS = list(range(2004, 2024))
EXPECTED_STAGES = ("01", "02", "03", "04", "05", "06", "07", "qa00", "qa01")
SCOPE_RECEIPT_RELATIVE = Path("Artifacts/synthetic_release_smoke_scope.json")
ACCESS_FIXTURE_RELATIVE = Path("tests/fixtures/access_db/synthetic_ipeds.mdb")
ACCESS_FIXTURE_SHA256 = "0230aabb99cb9f1362c4634e8278cbe19367df2ab6bf68633f558ccac71c8c13"
SYNTHETIC_CONTRACT_PATHS = (
    "contracts/panel_spec.toml",
    "contracts/source_releases.csv",
    "contracts/table_grain.csv",
    "contracts/source_columns.csv",
    "contracts/analysis_schema.csv",
    "contracts/discrete_families.csv",
    "contracts/prch_policy.csv",
    "contracts/metadata_backfill_approvals.csv",
    "contracts/dictionary_ambiguity_overrides.csv",
    "contracts/external_benchmarks.csv",
)
FORBIDDEN_COMMAND_TOKENS = (
    "Scripts/QA_QC/11_validate_panel_contract.py",
    "Scripts/QA_QC/24_verify_contract_review_evidence.py",
    "Scripts/QA_QC/release_gate.sh",
    "--require-release-ready",
    "Scripts/QA_QC/14_build_public_release_bundle.py",
)


class SyntheticSmokeError(RuntimeError):
    """The synthetic integration build escaped scope or failed validation."""


def reject_duplicate_json_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    output: dict[str, object] = {}
    for key, value in pairs:
        if key in output:
            raise SyntheticSmokeError(f"JSON repeats key {key!r}")
        output[key] = value
    return output


def read_json_object(path: Path) -> dict[str, object]:
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=reject_duplicate_json_keys,
        )
    except (OSError, json.JSONDecodeError) as exc:
        raise SyntheticSmokeError(f"cannot read JSON object {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise SyntheticSmokeError(f"JSON payload is not an object: {path}")
    return value


def exact_relative_path(path: Path, *, root: Path, label: str) -> str:
    try:
        return path.resolve(strict=True).relative_to(root.resolve(strict=True)).as_posix()
    except (OSError, ValueError) as exc:
        raise SyntheticSmokeError(f"{label} must resolve inside {root}") from exc


def load_scope_receipt(
    *,
    repo: Path,
    receipt_path: Path,
    years: list[int],
) -> dict[str, object]:
    relative = exact_relative_path(receipt_path, root=repo, label="scope receipt")
    if relative != SCOPE_RECEIPT_RELATIVE.as_posix():
        raise SyntheticSmokeError(
            "synthetic scope receipt path is not the repository-defined path: "
            f"{relative}"
        )
    receipt = read_json_object(receipt_path)
    expected_keys = {
        "schema_version",
        "scope_kind",
        "pipeline_mode",
        "production_authority",
        "public_promotion_authorized",
        "contract_id",
        "years",
        "access_fixture_sha256",
        "contract_sha256",
        "source_archives",
    }
    if set(receipt) != expected_keys:
        raise SyntheticSmokeError("synthetic scope receipt fields are not exact")
    expected_literals = {
        "schema_version": 1,
        "scope_kind": "synthetic_integration_only",
        "pipeline_mode": "development",
        "production_authority": False,
        "public_promotion_authorized": False,
        "contract_id": CONTRACT_ID,
        "years": years,
        "access_fixture_sha256": ACCESS_FIXTURE_SHA256,
    }
    for field, expected in expected_literals.items():
        if receipt.get(field) != expected:
            raise SyntheticSmokeError(
                f"synthetic scope receipt {field} is not exact: "
                f"{receipt.get(field)!r}"
            )

    fixture_path = repo / ACCESS_FIXTURE_RELATIVE
    if not fixture_path.is_file() or sha256_file(fixture_path) != ACCESS_FIXTURE_SHA256:
        raise SyntheticSmokeError("tracked synthetic Access fixture hash is stale")

    contract_hashes = receipt.get("contract_sha256")
    if not isinstance(contract_hashes, dict) or set(contract_hashes) != set(
        SYNTHETIC_CONTRACT_PATHS
    ):
        raise SyntheticSmokeError("synthetic contract hash inventory is not exact")
    for relative_path in SYNTHETIC_CONTRACT_PATHS:
        path = repo / relative_path
        if not path.is_file() or contract_hashes.get(relative_path) != sha256_file(path):
            raise SyntheticSmokeError(
                f"synthetic contract hash is stale: {relative_path}"
            )

    with (repo / "contracts" / "panel_spec.toml").open("rb") as handle:
        panel_spec = tomllib.load(handle)
    if (
        panel_spec.get("contract_id") != CONTRACT_ID
        or panel_spec.get("status") != "release-candidate"
        or panel_spec.get("release_ready") is not False
    ):
        raise SyntheticSmokeError(
            "synthetic panel contract must remain release-candidate and not "
            "release-ready"
        )

    source_archives = receipt.get("source_archives")
    if (
        not isinstance(source_archives, dict)
        or set(source_archives) != {"access.zip", "documentation.zip"}
        or not all(
            isinstance(value, str)
            and len(value) == 64
            and all(character in "0123456789abcdef" for character in value)
            for value in source_archives.values()
        )
    ):
        raise SyntheticSmokeError("synthetic source-archive hash inventory is malformed")
    releases = pd.read_csv(
        repo / "contracts" / "source_releases.csv",
        dtype=str,
        keep_default_na=False,
    )
    if (
        len(releases) != len(years)
        or sorted(releases["year"].astype(int).tolist()) != years
        or set(releases["contract_id"]) != {CONTRACT_ID}
        or set(releases["access_filename"]) != {"access.zip"}
        or set(releases["documentation_filename"]) != {"documentation.zip"}
        or set(releases["expected_access_sha256"])
        != {source_archives["access.zip"]}
        or set(releases["expected_documentation_sha256"])
        != {source_archives["documentation.zip"]}
        or set(releases["lock_status"]) != {"approved"}
        or not releases["access_url"].str.startswith(
            "https://fixture.invalid/"
        ).all()
        or not releases["documentation_url"].str.startswith(
            "https://fixture.invalid/"
        ).all()
    ):
        raise SyntheticSmokeError(
            "synthetic source-release contract is not exact and fixture-local"
        )
    return receipt


def validate_download_bindings(
    *,
    root: Path,
    years: list[int],
    source_archives: Mapping[str, object],
) -> dict[str, str]:
    stage_root = root / "development"
    observed: dict[str, str] = {}
    for year in years:
        downloads = stage_root / "Raw_Access_Databases" / str(year) / "downloads"
        for filename in ("access.zip", "documentation.zip"):
            path = downloads / filename
            expected = str(source_archives[filename])
            if not path.is_file() or sha256_file(path) != expected:
                raise SyntheticSmokeError(
                    f"cached synthetic source archive is missing or stale: {path}"
                )
            observed[f"{year}:{filename}"] = expected
    return observed


def compare_inventory(
    recorded: object,
    *,
    stage: str,
    lane: str,
) -> None:
    if not isinstance(recorded, dict):
        raise SyntheticSmokeError(f"stage {stage} {lane} inventory is malformed")
    for raw_path, raw_entry in recorded.items():
        if not isinstance(raw_entry, dict):
            raise SyntheticSmokeError(
                f"stage {stage} {lane} inventory entry is malformed: {raw_path}"
            )
        current = _path_entry(Path(raw_path))
        for field in ("kind", "sha256", "row_count", "schema_hash"):
            if raw_entry.get(field) != current.get(field):
                raise SyntheticSmokeError(
                    f"stage {stage} {lane} {field} changed: {raw_path}"
                )


def validate_stage_chain(*, repo: Path, root: Path) -> dict[str, object]:
    stage_root = root / "development"
    pointer_dir = stage_root / "Checks" / "v2" / "stage_manifests"
    pointer = pointer_dir / "CURRENT-DEVELOPMENT"
    if not pointer.is_file() or pointer.is_symlink():
        raise SyntheticSmokeError(
            "synthetic integration lacks a regular development provenance pointer"
        )
    relative = pointer.read_text(encoding="utf-8").strip()
    run_dir = (pointer_dir / relative).resolve()
    runs_dir = (pointer_dir / "runs").resolve()
    if run_dir.parent != runs_dir or not run_dir.is_dir():
        raise SyntheticSmokeError(
            f"unsafe synthetic development provenance pointer: {relative!r}"
        )

    state = git_state(repo)
    if bool(state["git_dirty"]):
        raise SyntheticSmokeError("synthetic integration repository is dirty")
    contract_id, contract_hashes = current_contract_hashes(repo)
    current_tools = tool_versions()
    if any(
        str(current_tools.get(field, "")).strip()
        for field in (
            "container_image_digest",
            "container_image_revision",
            "container_requirements_lock_sha256",
        )
    ):
        raise SyntheticSmokeError(
            "synthetic integration cannot inherit production container bindings"
        )
    run_manifest_path = run_dir / "run_manifest.json"
    run_manifest = read_json_object(run_manifest_path)
    expected_run_values = {
        "manifest_schema_version": MANIFEST_SCHEMA_VERSION,
        "mode": "development",
        "status": "success",
        "git_commit": state["git_commit"],
        "git_dirty": False,
        "contract_id": contract_id,
        "contract_hashes": contract_hashes,
        "ordered_stages": list(EXPECTED_STAGES),
        "tool_versions": current_tools,
    }
    for field, expected in expected_run_values.items():
        if run_manifest.get(field) != expected:
            raise SyntheticSmokeError(
                f"synthetic run manifest {field} is stale or out of scope"
            )

    recorded_hashes = run_manifest.get("stage_manifest_hashes")
    if not isinstance(recorded_hashes, dict) or set(recorded_hashes) != set(
        EXPECTED_STAGES
    ):
        raise SyntheticSmokeError("synthetic stage-manifest hash inventory is not exact")

    previous_path: Path | None = None
    for stage in EXPECTED_STAGES:
        manifest_path = run_dir / f"{stage}.json"
        if not manifest_path.is_file():
            raise SyntheticSmokeError(f"synthetic stage manifest is missing: {stage}")
        if recorded_hashes.get(stage) != sha256_file(manifest_path):
            raise SyntheticSmokeError(
                f"synthetic stage manifest hash is stale: {stage}"
            )
        manifest = read_json_object(manifest_path)
        expected_previous = (
            {}
            if previous_path is None
            else {
                "path": str(previous_path.absolute()),
                "sha256": sha256_file(previous_path),
            }
        )
        expected_stage_values = {
            "manifest_schema_version": MANIFEST_SCHEMA_VERSION,
            "stage_id": stage,
            "status": "success",
            "git_commit": state["git_commit"],
            "git_dirty": False,
            "contract_id": contract_id,
            "contract_hashes": contract_hashes,
            "tool_versions": current_tools,
            "previous_stage_manifest": expected_previous,
        }
        for field, expected in expected_stage_values.items():
            if manifest.get(field) != expected:
                raise SyntheticSmokeError(
                    f"synthetic stage {stage} {field} is stale or out of scope"
                )
        runtime_config = manifest.get("runtime_config")
        if not isinstance(runtime_config, dict) or runtime_config.get(
            "pipeline_mode"
        ) != "development":
            raise SyntheticSmokeError(
                f"synthetic stage {stage} was not run in development mode"
            )
        command = manifest.get("command")
        if not isinstance(command, list) or not all(
            isinstance(token, str) for token in command
        ):
            raise SyntheticSmokeError(f"synthetic stage {stage} command is malformed")
        command_text = " ".join(command)
        forbidden = [
            token for token in FORBIDDEN_COMMAND_TOKENS if token in command_text
        ]
        if forbidden:
            raise SyntheticSmokeError(
                f"synthetic stage {stage} invoked production-only command: "
                + ",".join(forbidden)
            )
        compare_inventory(manifest.get("input_metadata"), stage=stage, lane="input")
        compare_inventory(manifest.get("output_metadata"), stage=stage, lane="output")
        previous_path = manifest_path

    return {
        "git_commit": state["git_commit"],
        "run_id": run_manifest.get("run_id"),
        "run_manifest_sha256": sha256_file(run_manifest_path),
        "stage_manifest_hashes": recorded_hashes,
    }


def year_values(path: Path) -> list[int]:
    dataset = ds.dataset(str(path), format="parquet")
    table = dataset.to_table(columns=["year"])
    return sorted(
        {
            int(value)
            for value in table.column("year").to_pylist()
            if value is not None
        }
    )


def validate_data_outputs(
    *,
    root: Path,
    years: list[int],
) -> dict[str, dict[str, object]]:
    start, end = years[0], years[-1]
    expected = {
        "dictionary": root
        / "development"
        / "Dictionary"
        / "v2"
        / "dictionary_lake.parquet",
        "scalar_long": root
        / "Panels"
        / "development"
        / "v2"
        / f"panel_long_scalar_{start}_{end}.parquet",
        "dimensioned_long": root
        / "Panels"
        / "development"
        / "v2"
        / f"panel_long_dimensioned_{start}_{end}.parquet",
        "analysis_wide": root
        / "Panels"
        / "development"
        / "v2"
        / f"panel_wide_analysis_{start}_{end}.parquet",
        "raw_wide": root
        / "Panels"
        / "development"
        / "v2"
        / f"panel_wide_raw_{start}_{end}.parquet",
        "clean": root
        / "Panels"
        / "development"
        / "v2"
        / f"panel_clean_prch_{start}_{end}.parquet",
        "lineage": root
        / "Checks"
        / "development"
        / "v2"
        / "wide_qc"
        / "qc_value_lineage.parquet",
    }
    result: dict[str, dict[str, object]] = {}
    for label, path in expected.items():
        if not path.is_file():
            raise SyntheticSmokeError(
                f"synthetic development artifact is missing: {label}={path}"
            )
        metadata = _path_entry(path)
        if int(metadata.get("row_count", 0)) <= 0:
            raise SyntheticSmokeError(
                f"synthetic development artifact is empty: {label}"
            )
        if label != "dictionary" and year_values(path) != years:
            raise SyntheticSmokeError(
                f"synthetic development artifact has incomplete years: {label}"
            )
        result[label] = {
            "path": path.relative_to(root).as_posix(),
            "row_count": int(metadata["row_count"]),
            "sha256": metadata["sha256"],
            "schema_hash": metadata["schema_hash"],
        }

    clean = pd.read_parquet(expected["clean"], columns=["UNITID", "year"])
    if len(clean) != len(years) or clean.duplicated(["UNITID", "year"]).any():
        raise SyntheticSmokeError(
            "synthetic clean panel is not exactly one institution row per year"
        )
    dimensioned = pd.read_parquet(
        expected["dimensioned_long"],
        columns=["UNITID", "year", "dimension_key"],
    )
    if (
        dimensioned["dimension_key"].isna().any()
        or dimensioned["dimension_key"].astype(str).str.strip().eq("").any()
    ):
        raise SyntheticSmokeError(
            "synthetic dimensioned lane contains a blank dimension key"
        )
    return result


def validate_qa_outputs(*, root: Path) -> dict[str, object]:
    dictionary_summary = (
        root
        / "development"
        / "Checks"
        / "dictionary_qc"
        / "dictionary_qaqc_summary.csv"
    )
    panel_summary = (
        root
        / "Checks"
        / "development"
        / "v2"
        / "panel_qc"
        / "panel_qa_summary.csv"
    )
    if not dictionary_summary.is_file() or not panel_summary.is_file():
        raise SyntheticSmokeError("synthetic development QA summaries are missing")
    dictionary = pd.read_csv(dictionary_summary)
    panel = pd.read_csv(panel_summary)
    if (
        len(dictionary) != 1
        or int(dictionary.iloc[0].get("integrity_failures", -1)) != 0
    ):
        raise SyntheticSmokeError("synthetic dictionary QA has integrity failures")
    if (
        len(panel) != 1
        or str(panel.iloc[0].get("qa_mode", "")) != "development"
        or str(panel.iloc[0].get("status", "")) != "development_only"
        or bool(panel.iloc[0].get("release_eligible", True))
        or int(panel.iloc[0].get("suspicious_flags", -1)) != 0
    ):
        raise SyntheticSmokeError(
            "synthetic panel QA is not a clean development-only result"
        )
    return {
        "dictionary_summary_sha256": sha256_file(dictionary_summary),
        "panel_summary_sha256": sha256_file(panel_summary),
    }


def assert_nonproduction_namespace(root: Path) -> None:
    forbidden = (
        root / "Releases",
        root / "Panels" / "v2",
        root / "Checks" / "v2",
    )
    present = [str(path) for path in forbidden if path.exists() or path.is_symlink()]
    if present:
        raise SyntheticSmokeError(
            "synthetic integration created a production or public namespace: "
            + ",".join(present)
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True)
    parser.add_argument("--root", required=True)
    parser.add_argument("--years", required=True)
    parser.add_argument("--scope-receipt", required=True)
    parser.add_argument("--report", default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo = Path(args.repo).expanduser().resolve(strict=True)
    root = Path(args.root).expanduser().resolve(strict=True)
    if root == repo or root.is_relative_to(repo) or repo.is_relative_to(root):
        raise SystemExit("synthetic repository and data root must be disjoint")
    years = parse_years(args.years)
    if years != EXPECTED_YEARS:
        raise SystemExit("synthetic integration requires the exact 2004:2023 scope")
    receipt_path = Path(args.scope_receipt).expanduser().resolve(strict=True)
    report_path = (
        Path(args.report).expanduser().resolve()
        if args.report
        else root
        / "development"
        / "Checks"
        / "synthetic_release_smoke"
        / "synthetic_smoke_report.json"
    )
    try:
        assert_nonproduction_namespace(root)
        receipt = load_scope_receipt(
            repo=repo,
            receipt_path=receipt_path,
            years=years,
        )
        download_bindings = validate_download_bindings(
            root=root,
            years=years,
            source_archives=receipt["source_archives"],
        )
        stage_chain = validate_stage_chain(repo=repo, root=root)
        data_outputs = validate_data_outputs(root=root, years=years)
        qa_outputs = validate_qa_outputs(root=root)
        assert_nonproduction_namespace(root)
        result = {
            "schema_version": 1,
            "status": "pass",
            "scope_kind": "synthetic_integration_only",
            "pipeline_mode": "development",
            "production_authority": False,
            "public_promotion_authorized": False,
            "contract_id": CONTRACT_ID,
            "years": years,
            "scope_receipt_sha256": sha256_file(receipt_path),
            "download_bindings_sha256": hashlib.sha256(
                json.dumps(
                    download_bindings,
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
            ).hexdigest(),
            "stage_chain": stage_chain,
            "data_outputs": data_outputs,
            "qa_outputs": qa_outputs,
        }
        report_path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write_json(report_path, result)
        assert_nonproduction_namespace(root)
    except (OSError, ValueError, SyntheticSmokeError) as exc:
        raise SystemExit(f"Synthetic integration validation failed: {exc}") from exc
    print(f"Synthetic integration validation passed: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
