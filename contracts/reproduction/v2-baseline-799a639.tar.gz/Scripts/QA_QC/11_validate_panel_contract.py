#!/usr/bin/env python3
"""
QA 11: validate the declared panel contract against current code policy.

Reads:
- `contracts/panel_spec.toml`
- wide-build parser defaults
- shared PRCH policy module

Writes:
- no files; exits nonzero if the contract drifts from code defaults or the
  shared cleaning policy
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import tomllib
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[2]

REQUIRED_ARTIFACTS = {
    "scalar_long",
    "dimensioned_long",
    "analysis_wide",
    "raw_wide",
    "prch_cleaned",
    "dictionary",
    "lineage",
    "qa",
    "release_bundle",
}

REQUIRED_POLICIES = {
    "source_releases",
    "source_columns",
    "table_grain",
    "analysis_schema",
    "discrete_families",
    "prch",
    "metadata_backfill_approvals",
    "external_benchmarks",
}

SHA256_RE = re.compile(r"[0-9a-f]{64}")

INITIAL_REVIEWED_B03_B04_SOURCE_COMMIT = (
    "aee3c807807716744910924e9c63f1cc1a20e610"
)
SUPPLEMENTAL_REVIEWED_B03_B04_SOURCE_COMMIT = (
    "bc85e087e21e62a2d6083065c0ef9257379e58f8"
)
REVIEWED_B03_B04_AUTHOR = "Mark Jayson Martinez Farol"
INITIAL_REVIEWED_B03_B04_DATE = "2026-07-23"
SUPPLEMENTAL_REVIEWED_B03_B04_DATE = "2026-07-24"
B03_SAL2009_SCHEMA_SHA256 = (
    "bd888895b0571233ff6139378c7f3c8467d0b93817054d24bdef1d1ea100f88d"
)
REVIEWED_SOURCE_METADATA_ALIASES_SHA256 = (
    "fbd3fd6a1637bef0fbd5dc10fd91f8bf5204ddf781ec7fcc81aa1160ff109473"
)
PANEL_CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
EXPECTED_DECISION_IDS = {
    "B03-ZERO-001",
    "B04-ALIAS-001",
    *(f"B04-GAP-{number:03d}" for number in range(1, 27)),
}
SUPPLEMENTAL_DECISION_IDS = {
    "B04-GAP-005",
    "B04-GAP-018",
    "B04-GAP-019",
    "B04-GAP-020",
    "B04-GAP-025",
    "B04-GAP-026",
}
EXPECTED_DECISION_SOURCE_COMMITS = {
    decision_id: (
        SUPPLEMENTAL_REVIEWED_B03_B04_SOURCE_COMMIT
        if decision_id in SUPPLEMENTAL_DECISION_IDS
        else INITIAL_REVIEWED_B03_B04_SOURCE_COMMIT
    )
    for decision_id in EXPECTED_DECISION_IDS
}
EXPECTED_DECISION_REVIEW_DATES = {
    decision_id: (
        SUPPLEMENTAL_REVIEWED_B03_B04_DATE
        if decision_id in SUPPLEMENTAL_DECISION_IDS
        else INITIAL_REVIEWED_B03_B04_DATE
    )
    for decision_id in EXPECTED_DECISION_IDS
}
EXPECTED_SUPPORTED_DECISION_IDS = EXPECTED_DECISION_IDS
EXPECTED_DECISION_CHOICES = {
    **{
        decision_id: "assign_role"
        for decision_id in EXPECTED_DECISION_IDS
        if decision_id.startswith("B04-GAP-")
    },
    "B03-ZERO-001": "approve_intended_grain",
    "B04-ALIAS-001": "approve_controlled_crosswalk",
    "B04-GAP-003": "intentionally_exclude",
    "B04-GAP-025": "intentionally_exclude",
    "B04-GAP-026": "intentionally_exclude",
}
EXPECTED_DECISION_AFFECTED_ROWS = {
    **{decision_id: 1 for decision_id in EXPECTED_DECISION_IDS},
    "B04-ALIAS-001": 343,
    "B04-GAP-001": 7,
    **{f"B04-GAP-{number:03d}": 3 for number in range(6, 18)},
}
EXPECTED_SOURCE_COLUMN_DECISION_COUNTS = {
    "B04-GAP-001": 7,
    "B04-GAP-002": 1,
    "B04-GAP-003": 1,
    "B04-GAP-004": 1,
    "B04-GAP-005": 1,
    **{f"B04-GAP-{number:03d}": 3 for number in range(6, 18)},
    **{f"B04-GAP-{number:03d}": 1 for number in range(18, 27)},
}
EXPECTED_SOURCE_COLUMN_ROLE_COUNTS = {
    "metadata": 49,
    "measure": 3,
    "dimension": 1,
    "excluded": 3,
}
EXPECTED_ALIAS_GROUP_COUNTS = {
    ("SFA2223_P1", "SFA2223_P2", "39"): 97,
    ("SFA2223_P2", "SFA2223_P1", "77"): 36,
    ("SFA2223_P2", "SFA2223_P1", "78"): 105,
    ("SFA2223_P2", "SFA2223_P1", "79"): 105,
}
DECISION_REGISTER_COLUMNS = [
    "decision_id",
    "subsystem",
    "scope",
    "affected_year_table_column_rows",
    "question",
    "evidence_based_proposal",
    "allowed_decisions",
    "approved_role_or_grain",
    "decision",
    "justification",
    "reviewer",
    "reviewed_at",
    "source_commit",
]
TABLE_GRAIN_COLUMNS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "grain_class",
    "unit_key_columns",
    "dimension_columns",
    "measure_selection_rule",
    "expected_rows_per_unit",
    "aggregation_policy",
    "source_evidence",
    "review_note",
    "reviewed",
]
SOURCE_COLUMN_COLUMNS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "column_name",
    "role",
    "canonical_dimension",
    "exclusion_reason",
    "source_evidence",
    "review_note",
    "reviewed",
]
SOURCE_METADATA_ALIAS_COLUMNS = [
    "contract_id",
    "decision_id",
    "year",
    "source_file",
    "source_access_table_name",
    "source_varname",
    "selected_access_table_name",
    "selected_file_number",
    "selected_source_varnumber",
    "selected_varname",
    "selected_metadata_source",
    "selected_metadata_table_name",
    "evidence",
    "justification",
    "review_status",
    "reviewer",
    "review_date",
]

ANALYSIS_SCHEMA_COLUMNS = [
    "contract_id",
    "analysis_column",
    "logical_type",
    "source_variables",
    "transformation",
    "inclusion_reason",
    "first_year",
    "last_year",
    "nullable",
    "status",
]
DISCRETE_FAMILY_COLUMNS = [
    "contract_id",
    "source_file",
    "family_id",
    "component_varname",
    "component_code",
    "semantic_type",
    "active_tokens",
    "inactive_tokens",
    "missing_tokens",
    "output_column",
    "output_type",
    "multi_active_policy",
    "drop_components",
    "source_evidence",
    "review_note",
]
PRCH_POLICY_COLUMNS = [
    "rule_id",
    "year_start",
    "year_end",
    "flag",
    "code",
    "action",
    "target_columns",
    "row_predicate",
    "accounting_standard",
    "form",
    "part",
    "review_status",
    "source_reference",
    "rationale",
]
EXTERNAL_BENCHMARK_COLUMNS = [
    "benchmark_id",
    "contract_id",
    "artifact",
    "year",
    "metric",
    "variable",
    "filters",
    "component_family",
    "expected_value",
    "absolute_tolerance",
    "relative_tolerance",
    "tolerance_rationale",
    "official_source",
    "source_date_or_version",
    "source_evidence_path",
    "source_evidence_sha256",
    "review_status",
    "reviewer",
    "review_date",
    "definition",
    "notes",
]
METADATA_BACKFILL_COLUMNS = [
    "approval_id",
    "contract_id",
    "target_year",
    "source_file",
    "access_table_name",
    "donor_year",
    "variable_id",
    "target_varname",
    "expected_data_type",
    "expected_title",
    "fields_backfilled",
    "compatibility_status",
    "compatibility_evidence",
    "approval_status",
    "reviewer",
    "review_date",
    "justification",
]

SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH = Path(
    "docs/release/B03_B09_AUTHOR_COUNTERSIGN_2026-07-24.csv"
)
SIGNED_PROJECTION_RECEIPT_COLUMNS = [
    "authorization_id",
    "contract_id",
    "author_name",
    "author_date",
    "decision",
    "register_sha256",
    "scope_sha256",
    "transitive_target_sha256",
    "canonicalized_statement_sha256",
    "source_channel",
    "receipt_status",
    "verbatim_statement",
]
SIGNED_PROJECTION_AUTHORIZATION_ID = "AUTH-B03-B09-20260724"
SIGNED_PROJECTION_DECISION = "authorize_exact_canonical_application_only"
SIGNED_PROJECTION_REGISTER_SHA256 = (
    "72c12fd2b61f0470bb4cec1aee51c8d342bef12e8c572bea1e3feb538c2ff4a0"
)
SIGNED_PROJECTION_SCOPE_SHA256 = (
    "bf7cd2c9c58baf9419fd5fbb6ebda6615cc9e8a18aa82670da092dc406b2c882"
)
SIGNED_PROJECTION_TRANSITIVE_TARGET_SHA256 = (
    "cd4a57a982098747cb2b794b2c5f1a4f4b431fe55cde6ddefa50a3df709b2c3b"
)
SIGNED_PROJECTION_AUTHOR_DATE = "2026-07-24"
SIGNED_PROJECTION_SOURCE_CHANNEL = "codex_user_message"
SIGNED_PROJECTION_RECEIPT_STATUS = "verified_exact_author_countersign"
SIGNED_PROJECTION_VERBATIM_STATEMENT = (
    "I, Mark Jayson Martinez Farol, dated 2026-07-24, countersign "
    "`AUTHOR_DECISION_REGISTER.csv` SHA-256 "
    "`72c12fd2b61f0470bb4cec1aee51c8d342bef12e8c572bea1e3feb538c2ff4a0`, "
    "`CANONICAL_APPLICATION_SCOPE.csv` SHA-256 "
    "`bf7cd2c9c58baf9419fd5fbb6ebda6615cc9e8a18aa82670da092dc406b2c882`, "
    "and transitive review-target SHA-256 "
    "`cd4a57a982098747cb2b794b2c5f1a4f4b431fe55cde6ddefa50a3df709b2c3b`. "
    "I authorize Codex to replace only the seven canonical B03-B09 paths "
    "listed in that scope, only when every canonical pre-hash, candidate hash, "
    "expected post-hash, row count, child decision scope, evidence manifest, "
    "and input manifest matches exactly. I approve every proposed child "
    "decision exactly within the listed hash-bound scopes, including the "
    "explicit all-empty B04 exclusions. Any mismatch voids this authorization "
    "and requires a stop. This authorizes canonical contract application only; "
    "it does not authorize Stage 02 extraction, a full build, release, "
    "deployment, cleanup, deletion, installation, Docker, or Colima."
)
SIGNED_PROJECTION_STATEMENT_SHA256 = (
    "c5c7fcf60c890fcb7679ed3c0e639d35b455edbaddfb84ee14b39ee8dcfe59db"
)
B05_AMENDMENT_RECEIPT_RELATIVE_PATH = Path(
    "docs/release/B05_CMP1PY0_AMENDMENT_2026-08-02.csv"
)
B05_AMENDMENT_RECEIPT_COLUMNS = [
    "amendment_id",
    "contract_id",
    "author_name",
    "author_date",
    "decision",
    "target_contract_path",
    "analysis_column",
    "source_variable_id",
    "first_year",
    "last_year",
    "authorized_status",
    "authorized_reason",
    "analysis_schema_pre_sha256",
    "analysis_schema_post_sha256",
    "preserved_source_columns_sha256",
    "preserved_original_receipt_sha256",
    "failed_run_id",
    "failed_run_receipt_path",
    "failed_run_receipt_sha256",
    "coverage_evidence_path",
    "coverage_evidence_sha256",
    "eligible_row_count",
    "non_null_row_count",
    "source_role",
    "source_provenance_decision_id",
    "authorization_statement_sha256",
    "source_channel",
    "receipt_status",
    "verbatim_statement",
]
B05_AMENDMENT_ANALYSIS_SCHEMA_PRE_SHA256 = (
    "c284398e1a5189f639a939a722eb100b3853748a06a74c197b4b6bdab17d21c4"
)
B05_AMENDMENT_ANALYSIS_SCHEMA_POST_SHA256 = (
    "7878a8ecd22afae536190ee087f3bff107e3e5d63e99b8d44ee7e3d6e2c81859"
)
B05_AMENDMENT_SOURCE_COLUMNS_SHA256 = (
    "22d72c86a94c03fc9490f7eb2947604a04f14b62de5ef6e8cab6fcddd93b5bc2"
)
B05_AMENDMENT_ORIGINAL_RECEIPT_SHA256 = (
    "6b32846e1dabd493ae99508f0c48488078b5ef50aef87e94b81d9fec77c56b7e"
)
B05_AMENDMENT_VERBATIM_STATEMENT = (
    "I authorize excluding only nces:IC_PY:00015091:CMP1PY0 from B05 as "
    "excluded_all_null/no_observed_values for 2009–2012, while preserving its "
    "B04 measure provenance and every other canonical decision. I authorize "
    "the bounded Stage 06 compatibility and performance repairs, tests, and "
    "Stage 06 retry."
)
B05_AMENDMENT_STATEMENT_SHA256 = (
    "d97443cc3c340db1b1657104b94b2bb484a4073f8b9ae1230fdf6704c40dfdf9"
)
B05_AMENDMENT_PRESERVED_BINDINGS = {
    "contracts/table_grain.csv": "fd5cf7273b8aeaea9f6a7bd2d66a3799972e59e17e6f58087fa1bc1767717d70",
    "contracts/source_columns.csv": B05_AMENDMENT_SOURCE_COLUMNS_SHA256,
    "contracts/discrete_families.csv": "67c022b560691fb82413758513b0be5b810ec0bec15f396d1aee065a09bb3f65",
    "contracts/metadata_backfill_approvals.csv": "c5efc85b8b567d0729864702ac528fabe5632862753b6790142f5f8debe53b4a",
    "contracts/external_benchmarks.csv": "0159f7dedca341519eca5727f2d49d1bb0d1d46de7fc673c3334fe2d07c24eb1",
    SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH.as_posix(): B05_AMENDMENT_ORIGINAL_RECEIPT_SHA256,
}
B07_AMENDMENT_RECEIPT_RELATIVE_PATH = Path(
    "docs/release/B07_PRCH_AL_AMENDMENT_2026-08-03.csv"
)
B07_AMENDMENT_EVIDENCE_RELATIVE_PATH = Path(
    "docs/release/B07_PRCH_AL_SOURCE_EVIDENCE_2026-08-03.csv"
)
B07_AMENDMENT_PRE_SHA256 = (
    "c3320783366c7d9bc6bb808bcc7432398bf2a0cb4347fa44e070dd48b5fa4258"
)
B07_AMENDMENT_POST_SHA256 = (
    "67fca57085ec759944152f6e6e38374fac75991ef2dbd0489d241641d310e4f3"
)
B07_AMENDMENT_EVIDENCE_SHA256 = (
    "bce18c765b3c8cb4f0076315d1c03559abb6e80d372fade435c5fe600834b8f0"
)
B07_AMENDMENT_B05_RECEIPT_SHA256 = (
    "8c708ee252a9538ad860cff79404ae37b225b26c8ac7871eaf3d3814a0eae41c"
)
B07_AMENDMENT_VERBATIM_STATEMENT = (
    "I authorize the exact 38-rule B07 PRCH_AL amendment described above, "
    "the bounded evidence-generator and regression-test repairs, "
    "preservation of every other canonical decision, rebuilding the low-RAM "
    "image, and retrying Stage 07."
)
B07_AMENDMENT_STATEMENT_SHA256 = (
    "17f39db7a39a52e13a8e9af3d3041462aed0ff6ead368fa00bd01e4b01089fee"
)
B07_AMENDMENT_RECEIPT_COLUMNS = [
    "authorization_id",
    "contract_id",
    "author_name",
    "author_date",
    "decision",
    "canonical_path",
    "canonical_pre_sha256",
    "canonical_pre_row_count",
    "canonical_post_sha256",
    "canonical_post_row_count",
    "added_rule_count",
    "retain_rule_count",
    "null_rule_count",
    "observed_identity_count",
    "predicate_scope_count",
    "observed_row_count",
    "target_lineage_row_count",
    "nulled_source_row_count",
    "nulled_cell_count",
    "rule_identity_scope_sha256",
    "ordered_rule_ids_sha256",
    "target19_sha256",
    "target20_sha256",
    "source_evidence_manifest_path",
    "source_evidence_manifest_sha256",
    "stage06_run_id",
    "stage06_bundle_manifest_sha256",
    "stage06_value_lineage_sha256",
    "stage06_lane_coverage_sha256",
    "preserved_analysis_schema_sha256",
    "preserved_source_columns_sha256",
    "preserved_table_grain_sha256",
    "preserved_discrete_families_sha256",
    "preserved_metadata_backfill_sha256",
    "preserved_external_benchmarks_sha256",
    "preserved_original_receipt_sha256",
    "preserved_b05_amendment_receipt_sha256",
    "generator_commit",
    "authorization_statement_sha256",
    "source_channel",
    "receipt_status",
    "verbatim_statement",
]
B07_AMENDMENT_EVIDENCE_COLUMNS = [
    "evidence_id",
    "evidence_kind",
    "year",
    "path_scope",
    "path",
    "byte_size",
    "row_count",
    "sha256",
    "identity",
    "verification_status",
]
B07_AMENDMENT_PRESERVED_BINDINGS = {
    "contracts/table_grain.csv": "fd5cf7273b8aeaea9f6a7bd2d66a3799972e59e17e6f58087fa1bc1767717d70",
    "contracts/source_columns.csv": B05_AMENDMENT_SOURCE_COLUMNS_SHA256,
    "contracts/analysis_schema.csv": B05_AMENDMENT_ANALYSIS_SCHEMA_POST_SHA256,
    "contracts/discrete_families.csv": "67c022b560691fb82413758513b0be5b810ec0bec15f396d1aee065a09bb3f65",
    "contracts/metadata_backfill_approvals.csv": "c5efc85b8b567d0729864702ac528fabe5632862753b6790142f5f8debe53b4a",
    "contracts/external_benchmarks.csv": "0159f7dedca341519eca5727f2d49d1bb0d1d46de7fc673c3334fe2d07c24eb1",
    SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH.as_posix(): B05_AMENDMENT_ORIGINAL_RECEIPT_SHA256,
    B05_AMENDMENT_RECEIPT_RELATIVE_PATH.as_posix(): B07_AMENDMENT_B05_RECEIPT_SHA256,
}
SIGNED_PROJECTION_BINDINGS = {
    "contracts/table_grain.csv": {
        "sha256": "fd5cf7273b8aeaea9f6a7bd2d66a3799972e59e17e6f58087fa1bc1767717d70",
        "row_count": 114,
        "columns": TABLE_GRAIN_COLUMNS,
    },
    "contracts/source_columns.csv": {
        "sha256": "22d72c86a94c03fc9490f7eb2947604a04f14b62de5ef6e8cab6fcddd93b5bc2",
        "row_count": 4681,
        "columns": SOURCE_COLUMN_COLUMNS,
    },
    "contracts/analysis_schema.csv": {
        "sha256": B05_AMENDMENT_ANALYSIS_SCHEMA_POST_SHA256,
        "row_count": 2720,
        "columns": ANALYSIS_SCHEMA_COLUMNS,
    },
    "contracts/discrete_families.csv": {
        "sha256": "67c022b560691fb82413758513b0be5b810ec0bec15f396d1aee065a09bb3f65",
        "row_count": 411,
        "columns": DISCRETE_FAMILY_COLUMNS,
    },
    "contracts/prch_policy.csv": {
        "sha256": B07_AMENDMENT_POST_SHA256,
        "row_count": 1658,
        "columns": PRCH_POLICY_COLUMNS,
    },
    "contracts/external_benchmarks.csv": {
        "sha256": "0159f7dedca341519eca5727f2d49d1bb0d1d46de7fc673c3334fe2d07c24eb1",
        "row_count": 18,
        "columns": EXTERNAL_BENCHMARK_COLUMNS,
    },
    "contracts/metadata_backfill_approvals.csv": {
        "sha256": "c5efc85b8b567d0729864702ac528fabe5632862753b6790142f5f8debe53b4a",
        "row_count": 4,
        "columns": METADATA_BACKFILL_COLUMNS,
    },
}
LEGACY_CANONICAL_SHA256 = {
    "contracts/table_grain.csv": (
        "f802dbc670f443e81ea3047469f65ff0143baa56b3f7dc307861a267ba5aee48"
    ),
    "contracts/source_columns.csv": (
        "7929a50b8436ebbad57a30f2f739bb506706c5c849675feabee5ae49d9e28fcd"
    ),
    "contracts/analysis_schema.csv": (
        "2e5ec59201020a74309bcdc8e64f232c06d8a22b2085934e508f4f44f1292286"
    ),
    "contracts/discrete_families.csv": (
        "712bc309b0f8ceb28067617af8fe7d46072418896385322becc65f492775040d"
    ),
    "contracts/prch_policy.csv": (
        "92424ec99fc24b60e1acf286a2e9dd7e0f7bc3a6402c35567c8d36ec3e4e17ea"
    ),
    "contracts/external_benchmarks.csv": (
        "d11ca73db7f174d0f12243d0444cff0eb08492412aeb8a10b8da605d49438e1a"
    ),
    "contracts/metadata_backfill_approvals.csv": (
        "38b64161d868db79bbdea62238423f26984d965809a1be2d70dbf029965464ce"
    ),
}
SIGNED_B08_EVIDENCE_PATH = (
    "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
    "B08_OFFICIAL_BENCHMARK_EVIDENCE_RECEIPT.json"
)
SIGNED_B08_EVIDENCE_SHA256 = (
    "8d2cbfd1652897010e6086347e5e4ca6b1d2af62bfbe34ab44b52693704831eb"
)

EXPECTED_ARTIFACTS: dict[str, dict[str, list[str] | str]] = {
    "scalar_long": {
        "path": "Panels/v2/panel_long_scalar_2004_2023.parquet",
        "key": ["UNITID", "year", "variable_id", "source_file"],
        "required_columns": [
            "UNITID",
            "year",
            "variable_id",
            "source_varnumber",
            "source_file",
            "access_table_name",
            "source_row_id",
            "source_row_hash",
            "raw_value",
            "value_status",
            "value",
        ],
    },
    "dimensioned_long": {
        "path": "Panels/v2/panel_long_dimensioned_2004_2023.parquet",
        "key": [
            "UNITID",
            "year",
            "source_file",
            "access_table_name",
            "dimension_key",
            "variable_id",
        ],
        "required_columns": [
            "UNITID",
            "year",
            "variable_id",
            "source_varnumber",
            "source_file",
            "access_table_name",
            "source_row_id",
            "source_row_hash",
            "dimension_key",
            "dimension_json",
            "raw_value",
            "value_status",
            "value",
        ],
    },
    "analysis_wide": {
        "path": "Panels/v2/panel_wide_analysis_2004_2023.parquet",
        "key": ["UNITID", "year"],
        "required_columns": ["UNITID", "year"],
    },
    "raw_wide": {
        "path": "Panels/v2/panel_wide_raw_2004_2023.parquet",
        "key": ["UNITID", "year"],
        "required_columns": ["UNITID", "year"],
    },
    "prch_cleaned": {
        "path": "Panels/v2/panel_clean_prch_2004_2023.parquet",
        "key": ["UNITID", "year"],
        "required_columns": ["UNITID", "year"],
    },
    "dictionary": {
        "path": "Dictionary/v2/dictionary_lake.parquet",
        "key": ["variable_id", "year", "source_file", "access_table_name"],
        "required_columns": [
            "variable_id",
            "source_varnumber",
            "variable_origin",
            "is_synthetic",
            "source_metadata_year",
            "metadata_file_number",
            "year",
            "source_file",
            "access_table_name",
            "varname",
            "title",
            "description",
        ],
    },
    "lineage": {
        "path": "Checks/v2/wide_qc/qc_value_lineage.parquet",
        "key": ["UNITID", "year", "analysis_column", "variable_id", "source_row_id"],
        "required_columns": [
            "UNITID",
            "year",
            "analysis_column",
            "variable_id",
            "source_row_id",
            "source_file",
            "access_table_name",
            "transformation_id",
            "output_normalized_value",
        ],
    },
    "qa": {
        "path": "Checks/v2/acceptance_qc/acceptance_summary.csv",
        "key": ["check_id"],
        "required_columns": ["check_id", "status", "evidence_path", "details"],
    },
    "release_bundle": {
        "path": "Releases/ipedsdb-panel-v2/current/bundle_manifest.csv",
        "key": ["bundle_relative_path"],
        "required_columns": [
            "bundle_relative_path",
            "bundle_sha256",
            "bundle_size_bytes",
            "role",
        ],
    },
}


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument(
        "--repo-root",
        default=str(REPO_ROOT),
        help=(
            "Repository root whose contracts, signed receipt, and portable "
            "evidence paths are validated."
        ),
    )
    p.add_argument(
        "--contract",
        default=None,
        help=(
            "Panel spec path. Defaults to contracts/panel_spec.toml below "
            "--repo-root."
        ),
    )
    return p.parse_args(argv)


def load_contract(path: Path) -> dict[str, Any]:
    with path.open("rb") as fh:
        return tomllib.load(fh)


def fail(rows: list[str], message: str) -> None:
    rows.append(message)


def compare_value(rows: list[str], label: str, actual: Any, expected: Any) -> None:
    if actual != expected:
        fail(rows, f"{label}: contract={actual!r} code={expected!r}")


def validate_contract_identity(contract: dict[str, Any], rows: list[str]) -> None:
    compare_value(rows, "schema_version", contract.get("schema_version"), "2.0")
    contract_id = str(contract.get("contract_id", "")).strip()
    if not contract_id.endswith("-v2"):
        fail(rows, f"contract_id must identify v2: {contract_id!r}")
    status = contract.get("status")
    if status not in {"release-candidate", "active"}:
        fail(rows, "status must be release-candidate or active")
    release_ready = contract.get("release_ready")
    if not isinstance(release_ready, bool):
        fail(rows, "release_ready must be an explicit boolean")
    elif release_ready and status != "active":
        fail(rows, "release_ready=true requires status=active")


def validate_artifacts(contract: dict[str, Any], rows: list[str]) -> None:
    artifacts = contract.get("artifacts")
    if not isinstance(artifacts, dict):
        fail(rows, "artifacts section is missing")
        return
    actual = set(artifacts)
    missing = sorted(REQUIRED_ARTIFACTS - actual)
    extra = sorted(actual - REQUIRED_ARTIFACTS)
    if missing:
        fail(rows, f"artifacts missing definitions: {', '.join(missing)}")
    if extra:
        fail(rows, f"artifacts include undeclared definitions: {', '.join(extra)}")
    paths: dict[str, str] = {}
    for name in sorted(REQUIRED_ARTIFACTS):
        artifact = artifacts.get(name)
        if not isinstance(artifact, dict):
            continue
        path = str(artifact.get("path", "")).strip()
        key = artifact.get("key")
        required_columns = artifact.get("required_columns")
        if not path:
            fail(rows, f"artifacts.{name}.path is missing")
        elif path in paths:
            fail(rows, f"artifacts.{name}.path duplicates artifacts.{paths[path]}.path")
        else:
            paths[path] = name
        if not isinstance(key, list) or not key or not all(str(value).strip() for value in key):
            fail(rows, f"artifacts.{name}.key is missing or empty")
        if not isinstance(required_columns, list) or not required_columns or not all(
            str(value).strip() for value in required_columns
        ):
            fail(rows, f"artifacts.{name}.required_columns is missing or empty")
            continue
        if isinstance(key, list):
            missing_key_columns = sorted(set(key) - set(required_columns))
            if missing_key_columns:
                fail(
                    rows,
                    f"artifacts.{name}.key columns missing from required_columns: "
                    + ", ".join(missing_key_columns),
                )

    for name, expected in EXPECTED_ARTIFACTS.items():
        artifact = artifacts.get(name, {})
        if isinstance(artifact, dict):
            for field in ("path", "key", "required_columns"):
                compare_value(
                    rows,
                    f"artifacts.{name}.{field}",
                    artifact.get(field),
                    expected[field],
                )


def validate_policy_references(contract: dict[str, Any], rows: list[str]) -> None:
    policies = contract.get("policies")
    if not isinstance(policies, dict):
        fail(rows, "policies section is missing")
        return
    actual = set(policies)
    missing = sorted(REQUIRED_POLICIES - actual)
    extra = sorted(actual - REQUIRED_POLICIES)
    if missing:
        fail(rows, f"policies missing references: {', '.join(missing)}")
    if extra:
        fail(rows, f"policies include undeclared references: {', '.join(extra)}")
    for name in sorted(REQUIRED_POLICIES):
        rel_path = str(policies.get(name, "")).strip()
        if not rel_path:
            fail(rows, f"policies.{name} is missing")
        elif not rel_path.startswith("contracts/"):
            fail(rows, f"policies.{name} must reference contracts/: {rel_path}")


def validate_wide_build(contract: dict[str, Any], rows: list[str]) -> None:
    wide = contract.get("wide_build", {})
    expected = {
        "release_input": "scalar_long",
        "lane_split_stage": 4,
        "explicit_schema_required": True,
        "fail_on_unclassified_variables": True,
        "fail_on_scalar_conflicts": True,
        "fail_on_cast_errors": True,
        "dynamic_discovery_release_authority": False,
        "drop_globally_null_post": False,
        "drop_disc_components_without_validated_derivation": False,
        "legacy_prefix_lane_fallback": "development-only",
    }
    for key, expected_value in expected.items():
        compare_value(rows, f"wide_build.{key}", wide.get(key), expected_value)


def validate_cleaning(contract: dict[str, Any], rows: list[str]) -> None:
    cleaning = contract.get("cleaning", {})
    expected = {
        "row_preserving": True,
        "policy_contract": "contracts/prch_policy.csv",
        "preserve_raw_values": True,
        "change_log_required": True,
        "fail_on_unknown_codes": True,
        "fail_on_zero_target_child_rows": True,
        "schema_cast_failure": "fatal",
    }
    for key, expected_value in expected.items():
        compare_value(rows, f"cleaning.{key}", cleaning.get(key), expected_value)


def validate_release(contract: dict[str, Any], rows: list[str]) -> None:
    release = contract.get("release", {})
    compare_value(rows, "release.default_year_spec", release.get("default_year_spec"), "2004:2023")
    compare_value(rows, "release.start_year", release.get("start_year"), 2004)
    compare_value(rows, "release.end_year", release.get("end_year"), 2023)
    compare_value(rows, "release.final_only", release.get("final_only"), True)
    compare_value(rows, "release.include_provisional", release.get("include_provisional"), False)
    for key in [
        "require_source_lock",
        "require_external_benchmarks",
        "require_clean_git",
        "require_complete_stage_manifests",
    ]:
        compare_value(rows, f"release.{key}", release.get(key), True)


def validate_external_validation(contract: dict[str, Any], rows: list[str]) -> None:
    external = contract.get("external_validation", {})
    expected = {
        "min_benchmark_checks": 15,
        "min_distinct_years": 3,
        "min_component_families": 6,
        "required_component_families": [
            "institution_counts",
            "enrollment",
            "completions",
            "staffing",
            "tuition_price",
            "finance",
        ],
    }
    if not isinstance(external, dict):
        fail(rows, "external_validation section is missing")
        return
    missing = sorted(set(expected) - set(external))
    extra = sorted(set(external) - set(expected))
    if missing:
        fail(rows, f"external_validation missing definitions: {', '.join(missing)}")
    if extra:
        fail(rows, f"external_validation includes undeclared definitions: {', '.join(extra)}")
    for key, value in expected.items():
        compare_value(rows, f"external_validation.{key}", external.get(key), value)


def validate_qa_artifacts(contract: dict[str, Any], rows: list[str]) -> None:
    qa = contract.get("qa", {})
    expected = {
        "dictionary_qc": "Checks/dictionary_qc/dictionary_qaqc_summary.csv",
        "panel_qc": "Checks/v2/panel_qc/panel_qa_summary.csv",
        "acceptance_summary": "Checks/v2/acceptance_qc/acceptance_summary.csv",
        "release_manifest": "Checks/v2/release_manifest/release_manifest.csv",
        "release_manifest_verification": "Checks/v2/release_manifest/release_manifest_verification.csv",
        "release_bundle_manifest": "Releases/ipedsdb-panel-v2/current/bundle_manifest.csv",
        "release_comparison": "Checks/v2/release_compare/release_comparison.csv",
        "datapackage": "Checks/v2/release_metadata/datapackage.json",
        "build_provenance": "Checks/v2/release_metadata/build_provenance.json",
        "environment_report": "Checks/v2/release_metadata/environment_report.json",
        "entity_continuity": "Checks/v2/entity_continuity/entity_continuity_crosswalk.csv",
        "entity_continuity_manifest": "Checks/v2/entity_continuity/entity_continuity_manifest.json",
        "entity_continuity_value_lineage": (
            "Checks/v2/entity_continuity/entity_continuity_value_lineage.parquet"
        ),
        "entity_continuity_verification": (
            "Checks/v2/entity_continuity_verification/entity_continuity_verification.json"
        ),
        "external_benchmarks": "Checks/v2/external_benchmarks/external_benchmark_reconciliation.csv",
    }
    if not isinstance(qa, dict):
        fail(rows, "qa section is missing")
        return
    missing = sorted(set(expected) - set(qa))
    extra = sorted(set(qa) - set(expected))
    if missing:
        fail(rows, f"qa paths missing definitions: {', '.join(missing)}")
    if extra:
        fail(rows, f"qa paths include undeclared definitions: {', '.join(extra)}")
    for key, value in expected.items():
        compare_value(rows, f"qa.{key}", qa.get(key), value)


def validate_dictionary_overrides(
    contract: dict[str, Any],
    rows: list[str],
    *,
    repo_root: Path = REPO_ROOT,
) -> None:
    inputs = contract.get("inputs", {})
    rel_path = inputs.get("dictionary_ambiguity_overrides")
    if not rel_path:
        fail(rows, "inputs.dictionary_ambiguity_overrides is missing")
        return
    path = repo_root / str(rel_path)
    if not path.exists():
        fail(rows, f"dictionary ambiguity override file does not exist: {rel_path}")
        return
    required = {
        "contract_id",
        "year_start",
        "year_end",
        "source_file",
        "access_table_name",
        "varname",
        "selected_source_varnumber",
        "selected_metadata_source",
        "selected_metadata_table_name",
        "evidence",
        "justification",
        "review_status",
        "reviewer",
        "review_date",
    }
    with path.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        header = set(reader.fieldnames or [])
        missing = required - header
        if missing:
            fail(rows, f"dictionary ambiguity override file missing columns: {', '.join(sorted(missing))}")
        parsed_rows: list[tuple[int, dict[str, str]]] = []
        for idx, row in enumerate(reader, start=2):
            if not any((value or "").strip() for value in row.values()):
                continue
            normalized = {key: (value or "").strip() for key, value in row.items() if key is not None}
            parsed_rows.append((idx, normalized))
            if normalized.get("contract_id") != str(contract.get("contract_id", "")).strip():
                fail(rows, f"dictionary ambiguity override row {idx} is not bound to the current contract_id")
            try:
                year_start = int(normalized.get("year_start", ""))
                year_end = int(normalized.get("year_end", ""))
                if len(normalized.get("year_start", "")) != 4 or len(normalized.get("year_end", "")) != 4:
                    raise ValueError
                if year_start > year_end:
                    raise ValueError
            except ValueError:
                fail(rows, f"dictionary ambiguity override row {idx} has an invalid inclusive year range")
            if not (normalized.get("source_file") or normalized.get("access_table_name")):
                fail(rows, f"dictionary ambiguity override row {idx} lacks source_file/access_table_name")
            if not normalized.get("varname"):
                fail(rows, f"dictionary ambiguity override row {idx} lacks varname")
            if not normalized.get("selected_source_varnumber"):
                fail(rows, f"dictionary ambiguity override row {idx} lacks selected_source_varnumber")
            if not normalized.get("evidence"):
                fail(rows, f"dictionary ambiguity override row {idx} lacks evidence")
            if not normalized.get("justification"):
                fail(rows, f"dictionary ambiguity override row {idx} lacks justification")
            status = normalized.get("review_status", "").lower()
            if status not in {"pending", "approved"}:
                fail(rows, f"dictionary ambiguity override row {idx} has invalid review_status")
            if status == "approved":
                if not normalized.get("reviewer"):
                    fail(rows, f"dictionary ambiguity override row {idx} lacks reviewer")
                try:
                    datetime.strptime(normalized.get("review_date", ""), "%Y-%m-%d")
                except ValueError:
                    fail(rows, f"dictionary ambiguity override row {idx} lacks a valid ISO review_date")
            if contract.get("release_ready") is True and status != "approved":
                fail(rows, f"dictionary ambiguity override row {idx} is pending in a release-ready contract")

        for left_position, (left_idx, left) in enumerate(parsed_rows):
            for right_idx, right in parsed_rows[left_position + 1 :]:
                if left.get("contract_id") != right.get("contract_id"):
                    continue
                if left.get("varname", "").upper() != right.get("varname", "").upper():
                    continue
                try:
                    years_overlap = int(left["year_start"]) <= int(right["year_end"]) and int(
                        right["year_start"]
                    ) <= int(left["year_end"])
                except (KeyError, ValueError):
                    continue
                left_source = left.get("source_file", "").upper()
                right_source = right.get("source_file", "").upper()
                left_table = left.get("access_table_name", "").upper()
                right_table = right.get("access_table_name", "").upper()
                sources_overlap = not left_source or not right_source or left_source == right_source
                tables_overlap = not left_table or not right_table or left_table == right_table
                if years_overlap and sources_overlap and tables_overlap:
                    fail(
                        rows,
                        "dictionary ambiguity override rows "
                        f"{left_idx} and {right_idx} have overlapping match scopes",
                    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def portable_repo_file(
    raw_path: str,
    *,
    repo_root: Path,
    label: str,
    rows: list[str],
) -> Path | None:
    value = raw_path.strip()
    relative = PurePosixPath(value)
    if (
        not value
        or "\\" in value
        or relative.is_absolute()
        or ".." in relative.parts
        or value.startswith("~")
        or re.match(r"^[A-Za-z]:", value) is not None
    ):
        fail(rows, f"{label} must be a portable repository-relative path: {value!r}")
        return None
    try:
        resolved = (repo_root / Path(*relative.parts)).resolve(strict=True)
        resolved.relative_to(repo_root.resolve())
    except FileNotFoundError:
        fail(rows, f"{label} does not exist: {value}")
        return None
    except ValueError:
        fail(rows, f"{label} resolves outside the repository: {value}")
        return None
    except OSError as exc:
        fail(rows, f"{label} cannot be resolved: {value} ({exc})")
        return None
    if not resolved.is_file():
        fail(rows, f"{label} is not a file: {value}")
        return None
    return resolved


def validate_external_benchmark_row(
    row: dict[str, str | None],
    *,
    row_number: int,
    repo_root: Path,
    rows: list[str],
) -> None:
    label = f"contracts/external_benchmarks.csv row {row_number}"
    evidence = portable_repo_file(
        row.get("source_evidence_path", "") or "",
        repo_root=repo_root,
        label=f"{label} source_evidence_path",
        rows=rows,
    )
    expected_hash = (row.get("source_evidence_sha256", "") or "").strip().lower()
    if not SHA256_RE.fullmatch(expected_hash):
        fail(rows, f"{label} has an invalid source_evidence_sha256")
        return
    if evidence is not None:
        actual_hash = sha256_file(evidence)
        if actual_hash != expected_hash:
            fail(
                rows,
                f"{label} source evidence SHA-256 mismatch: "
                f"declared={expected_hash} actual={actual_hash}",
            )


def read_governance_csv(
    path: Path,
    *,
    required_columns: list[str],
    label: str,
    rows: list[str],
) -> list[dict[str, str]]:
    if not path.exists():
        fail(rows, f"governance file does not exist: {label}")
        return []
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        fieldnames = list(reader.fieldnames or [])
        if len(fieldnames) != len(set(fieldnames)):
            fail(rows, f"{label} contains duplicate column names")
        missing = [column for column in required_columns if column not in fieldnames]
        if missing:
            fail(rows, f"{label} missing columns: {', '.join(missing)}")
        parsed: list[dict[str, str]] = []
        for raw in reader:
            normalized = {
                str(key): str(value or "").strip()
                for key, value in raw.items()
                if key is not None
            }
            if any(normalized.values()):
                parsed.append(normalized)
        return parsed


def canonicalize_author_statement(value: str) -> str:
    """Normalize Unicode whitespace only; preserve every non-whitespace byte."""

    return " ".join(value.split())


def repository_relative_path_has_symlink(
    repo_root: Path,
    relative_path: str | Path,
) -> bool:
    current = repo_root
    for part in PurePosixPath(str(relative_path)).parts:
        current = current / part
        if current.is_symlink():
            return True
    return False


def validate_legacy_canonical_prestate(
    rows: list[str],
    *,
    repo_root: Path,
    expected_hashes: dict[str, str] = LEGACY_CANONICAL_SHA256,
    signed_bindings: dict[str, dict[str, Any]] = SIGNED_PROJECTION_BINDINGS,
) -> None:
    expected_paths = set(SIGNED_PROJECTION_BINDINGS)
    if set(expected_hashes) != expected_paths or set(signed_bindings) != expected_paths:
        fail(rows, "legacy pre-state hash gate must cover exactly B03-B09 canonical paths")
        return
    drift: list[str] = []
    for relative_path, expected_hash in expected_hashes.items():
        path = repo_root / relative_path
        if (
            repository_relative_path_has_symlink(repo_root, relative_path)
            or not path.is_file()
        ):
            drift.append(f"{relative_path}[missing_or_non_regular]")
            continue
        observed_hash = sha256_file(path)
        if observed_hash == expected_hash:
            continue
        signed_hash = str(signed_bindings[relative_path]["sha256"])
        state = (
            "known_signed_candidate_without_receipt"
            if observed_hash == signed_hash
            else "unexpected_canonical_drift"
        )
        drift.append(
            f"{relative_path}[{state};expected={expected_hash};observed={observed_hash}]"
        )
    if drift:
        fail(
            rows,
            "signed projection receipt is absent; orphan/partial signed projection "
            "or canonical drift detected; exact legacy pre-state is required across "
            "all seven canonical paths: "
            + "; ".join(drift),
        )


def validate_signed_projection_receipt(
    rows: list[str],
    *,
    repo_root: Path,
) -> dict[str, str] | None:
    label = SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH.as_posix()
    path = repo_root / SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH
    if not path.exists():
        fail(rows, f"signed projection receipt does not exist: {label}")
        return None
    if (
        repository_relative_path_has_symlink(repo_root, SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH)
        or not path.is_file()
    ):
        fail(rows, f"signed projection receipt must be a regular repository file: {label}")
        return None
    try:
        with path.open(newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            fieldnames = list(reader.fieldnames or [])
            raw_receipts = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        fail(rows, f"signed projection receipt cannot be read: {label} ({exc})")
        return None

    if fieldnames != SIGNED_PROJECTION_RECEIPT_COLUMNS:
        fail(
            rows,
            f"{label} receipt header must exactly equal "
            + ",".join(SIGNED_PROJECTION_RECEIPT_COLUMNS),
        )
    if len(raw_receipts) != 1:
        fail(rows, f"{label} must contain exactly one author receipt row")
        return None
    if None in raw_receipts[0]:
        fail(rows, f"{label} contains values outside its declared receipt schema")
    receipt = {
        str(key): str(value or "")
        for key, value in raw_receipts[0].items()
        if key is not None
    }
    expected = {
        "authorization_id": SIGNED_PROJECTION_AUTHORIZATION_ID,
        "contract_id": PANEL_CONTRACT_ID,
        "author_name": REVIEWED_B03_B04_AUTHOR,
        "author_date": SIGNED_PROJECTION_AUTHOR_DATE,
        "decision": SIGNED_PROJECTION_DECISION,
        "register_sha256": SIGNED_PROJECTION_REGISTER_SHA256,
        "scope_sha256": SIGNED_PROJECTION_SCOPE_SHA256,
        "transitive_target_sha256": SIGNED_PROJECTION_TRANSITIVE_TARGET_SHA256,
        "canonicalized_statement_sha256": SIGNED_PROJECTION_STATEMENT_SHA256,
        "source_channel": SIGNED_PROJECTION_SOURCE_CHANNEL,
        "receipt_status": SIGNED_PROJECTION_RECEIPT_STATUS,
    }
    for field, expected_value in expected.items():
        if receipt.get(field, "") != receipt.get(field, "").strip():
            fail(rows, f"{label} {field} contains surrounding whitespace")
        if receipt.get(field) != expected_value:
            fail(
                rows,
                f"{label} {field} must equal {expected_value!r}",
            )

    statement = receipt.get("verbatim_statement", "")
    canonical_statement = canonicalize_author_statement(statement)
    if canonical_statement != SIGNED_PROJECTION_VERBATIM_STATEMENT:
        fail(rows, f"{label} verbatim_statement does not match the required countersign")
    actual_statement_hash = hashlib.sha256(
        canonical_statement.encode("utf-8")
    ).hexdigest()
    if actual_statement_hash != receipt.get("canonicalized_statement_sha256"):
        fail(
            rows,
            f"{label} canonicalized_statement_sha256 does not match verbatim_statement",
        )
    return receipt


def validate_b05_amendment_governance(
    rows: list[str],
    *,
    repo_root: Path,
) -> dict[str, str] | None:
    """Validate the exact author-approved CMP1PY0 all-null amendment chain."""
    label = "B05 amendment receipt"
    path = repo_root / B05_AMENDMENT_RECEIPT_RELATIVE_PATH
    if not path.exists() or not path.is_file():
        fail(
            rows,
            f"{label} does not exist: "
            f"{B05_AMENDMENT_RECEIPT_RELATIVE_PATH.as_posix()}",
        )
        return None
    try:
        with path.open(newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            fieldnames = list(reader.fieldnames or [])
            raw_receipts = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        fail(rows, f"{label} cannot be read: {exc}")
        return None
    if fieldnames != B05_AMENDMENT_RECEIPT_COLUMNS:
        fail(
            rows,
            f"{label} header must exactly equal "
            + ",".join(B05_AMENDMENT_RECEIPT_COLUMNS),
        )
    if len(raw_receipts) != 1:
        fail(rows, f"{label} must contain exactly one author amendment row")
        return None
    if None in raw_receipts[0]:
        fail(rows, f"{label} contains values outside its declared schema")
    receipt = {
        str(key): str(value or "")
        for key, value in raw_receipts[0].items()
        if key is not None
    }
    expected = {
        "amendment_id": "AUTH-B05-CMP1PY0-20260802",
        "contract_id": PANEL_CONTRACT_ID,
        "author_name": REVIEWED_B03_B04_AUTHOR,
        "author_date": "2026-08-02",
        "decision": "authorize_exact_b05_exclusion_only",
        "target_contract_path": "contracts/analysis_schema.csv",
        "analysis_column": "CMP1PY0",
        "source_variable_id": "nces:IC_PY:00015091:CMP1PY0",
        "first_year": "2009",
        "last_year": "2012",
        "authorized_status": "excluded_all_null",
        "authorized_reason": "no_observed_values",
        "analysis_schema_pre_sha256": B05_AMENDMENT_ANALYSIS_SCHEMA_PRE_SHA256,
        "analysis_schema_post_sha256": B05_AMENDMENT_ANALYSIS_SCHEMA_POST_SHA256,
        "preserved_source_columns_sha256": B05_AMENDMENT_SOURCE_COLUMNS_SHA256,
        "preserved_original_receipt_sha256": B05_AMENDMENT_ORIGINAL_RECEIPT_SHA256,
        "failed_run_id": "20260802T090421.594935Z-3cb471e1e2bc46dca0e0abbca6b39486",
        "failed_run_receipt_path": (
            "Panels/v2/wide_release/failed/"
            "20260802T090421.594935Z-3cb471e1e2bc46dca0e0abbca6b39486/"
            "failure.json"
        ),
        "failed_run_receipt_sha256": (
            "ded38d8f2dbdefb52c8e35a59f934dede5f22babcae0868f6b022ad806fb4b2f"
        ),
        "coverage_evidence_path": (
            "Panels/v2/wide_release/failed/"
            "20260802T090421.594935Z-3cb471e1e2bc46dca0e0abbca6b39486/"
            "qc/wide_qc/qc_canonical_column_coverage.csv"
        ),
        "coverage_evidence_sha256": (
            "aaefc637a9d2e0ef256aaf40a1e8e173847c4f01d823be5fc9df40987265a24d"
        ),
        "eligible_row_count": "10449",
        "non_null_row_count": "0",
        "source_role": "measure",
        "source_provenance_decision_id": "B04-PROJ-DB6A0BBAD18E",
        "authorization_statement_sha256": B05_AMENDMENT_STATEMENT_SHA256,
        "source_channel": "codex_user_message",
        "receipt_status": "verified_exact_author_amendment",
        "verbatim_statement": B05_AMENDMENT_VERBATIM_STATEMENT,
    }
    for field, expected_value in expected.items():
        if receipt.get(field) != expected_value:
            fail(rows, f"{label} {field} must equal {expected_value!r}")

    statement = receipt.get("verbatim_statement", "")
    statement_hash = hashlib.sha256(statement.encode("utf-8")).hexdigest()
    if statement_hash != receipt.get("authorization_statement_sha256"):
        fail(
            rows,
            f"{label} authorization_statement_sha256 does not match "
            "verbatim_statement",
        )

    analysis_path = repo_root / "contracts/analysis_schema.csv"
    if not analysis_path.is_file():
        fail(rows, "contracts/analysis_schema.csv is missing for B05 amendment")
    elif sha256_file(analysis_path) != B05_AMENDMENT_ANALYSIS_SCHEMA_POST_SHA256:
        fail(
            rows,
            "contracts/analysis_schema.csv does not match the authorized B05 "
            "amendment post-hash",
        )

    for relative_path, expected_hash in B05_AMENDMENT_PRESERVED_BINDINGS.items():
        preserved = repo_root / relative_path
        if not preserved.is_file():
            fail(rows, f"{relative_path} is missing from the preserved B05 prestate")
        elif sha256_file(preserved) != expected_hash:
            fail(
                rows,
                f"{relative_path} changed outside the authorized B05 amendment",
            )

    if analysis_path.is_file():
        governed = read_governance_csv(
            analysis_path,
            required_columns=ANALYSIS_SCHEMA_COLUMNS,
            label="contracts/analysis_schema.csv",
            rows=rows,
        )
        matches = [
            item
            for item in governed
            if item.get("analysis_column") == "CMP1PY0"
            and item.get("source_variables")
            == "variable_id:nces:IC_PY:00015091:CMP1PY0"
        ]
        if len(matches) != 1:
            fail(rows, "B05 amendment must govern exactly one CMP1PY0 identity")
        elif (
            matches[0].get("status") != "excluded_all_null"
            or matches[0].get("inclusion_reason") != "no_observed_values"
            or matches[0].get("first_year") != "2009"
            or matches[0].get("last_year") != "2012"
        ):
            fail(rows, "B05 amendment CMP1PY0 row does not match its exact scope")

    source_path = repo_root / "contracts/source_columns.csv"
    if source_path.is_file():
        source_rows = read_governance_csv(
            source_path,
            required_columns=SOURCE_COLUMN_COLUMNS,
            label="contracts/source_columns.csv",
            rows=rows,
        )
        source_matches = [
            item
            for item in source_rows
            if item.get("decision_id") == "B04-PROJ-DB6A0BBAD18E"
            and item.get("source_file") == "IC_PY"
            and item.get("column_name") == "CMP1PY0"
        ]
        if len(source_matches) != 1 or source_matches[0].get("role") != "measure":
            fail(rows, "B04 CMP1PY0 measure provenance is not preserved")
    return receipt


def validate_b07_prch_al_amendment_governance(
    rows: list[str],
    *,
    repo_root: Path,
) -> dict[str, str] | None:
    """Validate the exact author-approved early Academic Libraries rules."""

    label = "B07 PRCH_AL amendment receipt"
    path = repo_root / B07_AMENDMENT_RECEIPT_RELATIVE_PATH
    if not path.is_file():
        fail(rows, f"{label} does not exist: {B07_AMENDMENT_RECEIPT_RELATIVE_PATH}")
        return None
    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            fieldnames = list(reader.fieldnames or [])
            raw = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        fail(rows, f"{label} cannot be read: {exc}")
        return None
    if fieldnames != B07_AMENDMENT_RECEIPT_COLUMNS:
        fail(
            rows,
            f"{label} header must exactly equal "
            + ",".join(B07_AMENDMENT_RECEIPT_COLUMNS),
        )
    if len(raw) != 1:
        fail(rows, f"{label} must contain exactly one author amendment row")
        return None
    if None in raw[0]:
        fail(rows, f"{label} contains values outside its declared schema")
    receipt = {
        str(key): str(value or "")
        for key, value in raw[0].items()
        if key is not None
    }
    expected = {
        "authorization_id": "AUTH-B07-PRCH-AL-20260803",
        "contract_id": PANEL_CONTRACT_ID,
        "author_name": REVIEWED_B03_B04_AUTHOR,
        "author_date": "2026-08-03",
        "decision": "authorize_exact_38_rule_early_prch_al_amendment",
        "canonical_path": "contracts/prch_policy.csv",
        "canonical_pre_sha256": B07_AMENDMENT_PRE_SHA256,
        "canonical_pre_row_count": "1620",
        "canonical_post_sha256": B07_AMENDMENT_POST_SHA256,
        "canonical_post_row_count": "1658",
        "added_rule_count": "38",
        "retain_rule_count": "29",
        "null_rule_count": "9",
        "observed_identity_count": "12",
        "predicate_scope_count": "38",
        "observed_row_count": "16361",
        "target_lineage_row_count": "176",
        "nulled_source_row_count": "1135",
        "nulled_cell_count": "22225",
        "rule_identity_scope_sha256": (
            "50ebeb92400afafeb6bd07628f3f62a9f48b6dfa047a1e064c971c035de07da5"
        ),
        "ordered_rule_ids_sha256": (
            "3f2f381cb96c3f2473230a392494020136e533f5175926447c00ca6085abcb8c"
        ),
        "target19_sha256": (
            "40e943f60b752faa4b7b29c21771d82e6394edefdb4e20f87088baf8ff7a8881"
        ),
        "target20_sha256": (
            "6f8b8e691019f3222863348812d22c1867ce7271e8e53d24a2910a57c11a48c3"
        ),
        "source_evidence_manifest_path": (
            B07_AMENDMENT_EVIDENCE_RELATIVE_PATH.as_posix()
        ),
        "source_evidence_manifest_sha256": B07_AMENDMENT_EVIDENCE_SHA256,
        "stage06_run_id": (
            "20260803T075553.278036Z-ebc6f4f023094c19b15f8260ec53b4e1"
        ),
        "stage06_bundle_manifest_sha256": (
            "1eb50a879548d13736488c482c0239ace1badc9beee96d2f63913dddc498cbe3"
        ),
        "stage06_value_lineage_sha256": (
            "bf6859329a5f845472f084582ae3ca78699c95823b6f1726eaf39c0540637f26"
        ),
        "stage06_lane_coverage_sha256": (
            "a9d7e7952eb3d8603f43fb7eb8004115cdc398b581afdee22bca48c005d5b789"
        ),
        "preserved_analysis_schema_sha256": B05_AMENDMENT_ANALYSIS_SCHEMA_POST_SHA256,
        "preserved_source_columns_sha256": B05_AMENDMENT_SOURCE_COLUMNS_SHA256,
        "preserved_table_grain_sha256": (
            "fd5cf7273b8aeaea9f6a7bd2d66a3799972e59e17e6f58087fa1bc1767717d70"
        ),
        "preserved_discrete_families_sha256": (
            "67c022b560691fb82413758513b0be5b810ec0bec15f396d1aee065a09bb3f65"
        ),
        "preserved_metadata_backfill_sha256": (
            "c5efc85b8b567d0729864702ac528fabe5632862753b6790142f5f8debe53b4a"
        ),
        "preserved_external_benchmarks_sha256": (
            "0159f7dedca341519eca5727f2d49d1bb0d1d46de7fc673c3334fe2d07c24eb1"
        ),
        "preserved_original_receipt_sha256": B05_AMENDMENT_ORIGINAL_RECEIPT_SHA256,
        "preserved_b05_amendment_receipt_sha256": B07_AMENDMENT_B05_RECEIPT_SHA256,
        "generator_commit": "ce2e05e02b4e418b31c24c9eca3aa48886831de0",
        "authorization_statement_sha256": B07_AMENDMENT_STATEMENT_SHA256,
        "source_channel": "codex_user_message",
        "receipt_status": "verified_exact_author_amendment",
        "verbatim_statement": B07_AMENDMENT_VERBATIM_STATEMENT,
    }
    for field, expected_value in expected.items():
        if receipt.get(field) != expected_value:
            fail(rows, f"{label} {field} must equal {expected_value!r}")

    statement_hash = hashlib.sha256(
        receipt.get("verbatim_statement", "").encode("utf-8")
    ).hexdigest()
    if statement_hash != receipt.get("authorization_statement_sha256"):
        fail(
            rows,
            f"{label} authorization_statement_sha256 does not match "
            "verbatim_statement",
        )

    evidence_path = repo_root / B07_AMENDMENT_EVIDENCE_RELATIVE_PATH
    if not evidence_path.is_file():
        fail(rows, f"{B07_AMENDMENT_EVIDENCE_RELATIVE_PATH.as_posix()} is missing")
    elif sha256_file(evidence_path) != B07_AMENDMENT_EVIDENCE_SHA256:
        fail(
            rows,
            f"{B07_AMENDMENT_EVIDENCE_RELATIVE_PATH.as_posix()} hash drifted",
        )
    else:
        evidence = read_governance_csv(
            evidence_path,
            required_columns=B07_AMENDMENT_EVIDENCE_COLUMNS,
            label=B07_AMENDMENT_EVIDENCE_RELATIVE_PATH.as_posix(),
            rows=rows,
        )
        if len(evidence) != 28:
            fail(rows, "B07 PRCH_AL source evidence must contain exactly 28 rows")
        if any(item.get("verification_status") != "verified_exact" for item in evidence):
            fail(rows, "B07 PRCH_AL source evidence contains an unverified row")

    policy_path = repo_root / "contracts/prch_policy.csv"
    if not policy_path.is_file():
        fail(rows, "contracts/prch_policy.csv is missing for B07 amendment")
    elif sha256_file(policy_path) != B07_AMENDMENT_POST_SHA256:
        fail(rows, "contracts/prch_policy.csv does not match the authorized B07 post-hash")
    else:
        policy_rows = read_governance_csv(
            policy_path,
            required_columns=PRCH_POLICY_COLUMNS,
            label="contracts/prch_policy.csv",
            rows=rows,
        )
        if len(policy_rows) != 1658:
            fail(rows, "authorized B07 policy must contain exactly 1658 rows")
        years = {2006, 2008, 2010, 2012}
        amended = [
            item
            for item in policy_rows
            if item.get("flag") == "PRCH_AL"
            and item.get("year_start", "").isdigit()
            and int(item["year_start"]) in years
        ]
        expected_predicates = {
            2006: {-2: (1, 2, 3, 4), 1: (1, 2, 4), 2: (1, 4)},
            2008: {-2: (1, 2, 3, 4), 1: (1, 2, 4), 2: (1, 4)},
            2010: {-2: (1, 2, 3, 4), 1: (1, 2, 3, 4), 2: (1, 3, 4)},
            2012: {-2: (1, 2, 3, 4), 1: (1, 2, 4), 2: (1, 4)},
        }
        expected_scope = {
            (year, code, predicate)
            for year, codes in expected_predicates.items()
            for code, predicates in codes.items()
            for predicate in predicates
        }
        actual_scope: set[tuple[int, int, int]] = set()
        for item in amended:
            try:
                predicate = json.loads(item.get("row_predicate", ""))
                actual_scope.add(
                    (
                        int(item["year_start"]),
                        int(item["code"]),
                        int(predicate["STAT_AL"]),
                    )
                )
            except (KeyError, TypeError, ValueError, json.JSONDecodeError):
                fail(rows, f"B07 amended rule has invalid exact scope: {item.get('rule_id')}")
        if len(amended) != 38 or actual_scope != expected_scope:
            fail(rows, "B07 amendment does not contain the exact 38 authorized scopes")
        if any(
            item.get("review_status") != "approved"
            or "AUTH-B07-PRCH-AL-20260803" not in item.get("rationale", "")
            or B07_AMENDMENT_EVIDENCE_SHA256 not in item.get("source_reference", "")
            for item in amended
        ):
            fail(rows, "B07 amended rules lack exact approval/evidence binding")

    for relative_path, expected_hash in B07_AMENDMENT_PRESERVED_BINDINGS.items():
        preserved = repo_root / relative_path
        if not preserved.is_file():
            fail(rows, f"{relative_path} is missing from the preserved B07 prestate")
        elif sha256_file(preserved) != expected_hash:
            fail(rows, f"{relative_path} changed outside the authorized B07 amendment")
    return receipt


def read_signed_projection_csv(
    rows: list[str],
    *,
    repo_root: Path,
    relative_path: str,
    binding: dict[str, Any],
) -> list[dict[str, str]]:
    path = repo_root / relative_path
    if not path.exists() or not path.is_file():
        fail(rows, f"signed projection contract does not exist: {relative_path}")
        return []
    if repository_relative_path_has_symlink(repo_root, relative_path):
        fail(rows, f"{relative_path} must be a regular non-symlink file")
        return []
    actual_hash = sha256_file(path)
    expected_hash = str(binding["sha256"])
    if actual_hash != expected_hash:
        fail(
            rows,
            f"{relative_path} SHA-256 must equal {expected_hash}; observed={actual_hash}",
        )
    try:
        with path.open(newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            fieldnames = list(reader.fieldnames or [])
            raw_rows = list(reader)
    except (OSError, UnicodeError, csv.Error) as exc:
        fail(rows, f"{relative_path} cannot be read: {exc}")
        return []
    expected_columns = list(binding["columns"])
    if fieldnames != expected_columns:
        fail(
            rows,
            f"{relative_path} header must exactly equal "
            + ",".join(expected_columns),
        )
    if any(None in row for row in raw_rows):
        fail(rows, f"{relative_path} contains values outside its declared schema")
    parsed = [
        {
            str(key): str(value or "").strip()
            for key, value in raw.items()
            if key is not None
        }
        for raw in raw_rows
    ]
    expected_count = int(binding["row_count"])
    if len(parsed) != expected_count:
        fail(
            rows,
            f"{relative_path} row count must equal {expected_count}; "
            f"observed={len(parsed)}",
        )
    return parsed


def projection_year_range(
    row: dict[str, str],
    *,
    label: str,
    row_number: int,
    rows: list[str],
) -> tuple[int, int] | None:
    try:
        start = int(row.get("year_start", ""))
        end = int(row.get("year_end", ""))
    except ValueError:
        fail(rows, f"{label} row {row_number} has a non-integer year range")
        return None
    if (
        len(row.get("year_start", "")) != 4
        or len(row.get("year_end", "")) != 4
        or start < 2004
        or end > 2023
        or start > end
    ):
        fail(rows, f"{label} row {row_number} has an invalid 2004-2023 year range")
        return None
    return start, end


def split_pipe_tokens(
    value: str,
    *,
    label: str,
    row_number: int,
    field: str,
    rows: list[str],
    allow_empty: bool,
) -> list[str]:
    if not value:
        if not allow_empty:
            fail(rows, f"{label} row {row_number} lacks {field}")
        return []
    tokens = value.split("|")
    if any(not token or token.strip() != token for token in tokens):
        fail(rows, f"{label} row {row_number} has malformed {field}")
    normalized = [token.upper() for token in tokens if token]
    if len(normalized) != len(set(normalized)):
        fail(rows, f"{label} row {row_number} has duplicate {field} tokens")
    return normalized


def patterns_intersect(left: str, right: str) -> bool:
    return left == "*" or right == "*" or left.upper() == right.upper()


def validate_projection_scope_overlaps(
    contract_rows: list[dict[str, str]],
    *,
    label: str,
    rows: list[str],
    column_field: str | None = None,
) -> None:
    scopes: dict[tuple[str, str], list[tuple[int, int, str, int]]] = defaultdict(list)
    for row_number, row in enumerate(contract_rows, start=2):
        years = projection_year_range(
            row,
            label=label,
            row_number=row_number,
            rows=rows,
        )
        if years is None:
            continue
        pattern = row.get("access_table_pattern", "")
        if not pattern:
            fail(rows, f"{label} row {row_number} lacks access_table_pattern")
            continue
        if pattern != "*" and any(token in pattern for token in "*?[]"):
            fail(
                rows,
                f"{label} row {row_number} uses an unsupported partial wildcard pattern",
            )
            continue
        source = row.get("source_file", "").upper()
        column = row.get(column_field, "").upper() if column_field else ""
        scopes[(source, column)].append((*years, pattern.upper(), row_number))

    for (source, column), grouped in scopes.items():
        grouped.sort(key=lambda value: (value[0], value[1], value[2], value[3]))
        active: list[tuple[int, int, str, int]] = []
        for scope in grouped:
            start, end, pattern, row_number = scope
            active = [candidate for candidate in active if candidate[1] >= start]
            for other_start, other_end, other_pattern, other_row_number in active:
                if patterns_intersect(pattern, other_pattern):
                    detail = f"source_file={source!r}"
                    if column_field:
                        detail += f" {column_field}={column!r}"
                    fail(
                        rows,
                        f"{label} rows {other_row_number} and {row_number} have "
                        f"overlapping match scopes ({detail})",
                    )
            active.append(scope)


def validate_signed_table_grain_rows(
    table_rows: list[dict[str, str]],
    *,
    rows: list[str],
) -> None:
    label = "contracts/table_grain.csv"
    decision_ids: list[str] = []
    for row_number, table_row in enumerate(table_rows, start=2):
        decision_id = table_row.get("decision_id", "")
        decision_ids.append(decision_id)
        if re.fullmatch(r"B03-PROJ-[0-9A-F]{12}", decision_id) is None:
            fail(rows, f"{label} row {row_number} has an invalid projection decision_id")
        if table_row.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        if not table_row.get("source_file"):
            fail(rows, f"{label} row {row_number} lacks source_file")
        projection_year_range(
            table_row,
            label=label,
            row_number=row_number,
            rows=rows,
        )
        if table_row.get("reviewed") != "true":
            fail(rows, f"{label} row {row_number} is not reviewed")
        grain = table_row.get("grain_class", "")
        if grain not in {"scalar", "dimensioned"}:
            fail(rows, f"{label} row {row_number} has unsupported grain_class {grain!r}")
        unit_keys = split_pipe_tokens(
            table_row.get("unit_key_columns", ""),
            label=label,
            row_number=row_number,
            field="unit_key_columns",
            rows=rows,
            allow_empty=False,
        )
        dimensions = split_pipe_tokens(
            table_row.get("dimension_columns", ""),
            label=label,
            row_number=row_number,
            field="dimension_columns",
            rows=rows,
            allow_empty=True,
        )
        if grain == "scalar":
            if unit_keys != ["UNITID"] or dimensions:
                fail(
                    rows,
                    f"{label} row {row_number} scalar grain must use UNITID and no dimensions",
                )
            if table_row.get("expected_rows_per_unit") != "1":
                fail(rows, f"{label} row {row_number} scalar grain must expect one row")
        elif grain == "dimensioned":
            if not dimensions or unit_keys != ["UNITID", *dimensions]:
                fail(
                    rows,
                    f"{label} row {row_number} dimensioned key must equal "
                    "UNITID plus dimension_columns in order",
                )
            if table_row.get("expected_rows_per_unit") not in {"many", "one_or_more"}:
                fail(
                    rows,
                    f"{label} row {row_number} dimensioned grain must expect multiple rows",
                )
        if table_row.get("measure_selection_rule") != "source_columns_contract":
            fail(
                rows,
                f"{label} row {row_number} must use source_columns_contract selection",
            )
        if table_row.get("aggregation_policy") != "exact_duplicate_only":
            fail(
                rows,
                f"{label} row {row_number} must use exact_duplicate_only aggregation",
            )
        for field in ("source_evidence", "review_note"):
            if not table_row.get(field):
                fail(rows, f"{label} row {row_number} lacks {field}")
    if len(decision_ids) != len(set(decision_ids)):
        fail(rows, f"{label} contains a duplicate decision_id")
    validate_projection_scope_overlaps(table_rows, label=label, rows=rows)


def validate_signed_source_column_rows(
    source_rows: list[dict[str, str]],
    *,
    table_rows: list[dict[str, str]],
    rows: list[str],
) -> None:
    label = "contracts/source_columns.csv"
    decision_ids: list[str] = []
    allowed_roles = {"identifier", "dimension", "measure", "metadata", "excluded"}
    table_dimensions: list[tuple[int, int, str, str, set[str]]] = []
    for table_row in table_rows:
        try:
            start = int(table_row.get("year_start", ""))
            end = int(table_row.get("year_end", ""))
        except ValueError:
            continue
        table_dimensions.append(
            (
                start,
                end,
                table_row.get("source_file", "").upper(),
                table_row.get("access_table_pattern", "").upper(),
                {
                    token.upper()
                    for token in table_row.get("dimension_columns", "").split("|")
                    if token
                },
            )
        )

    for row_number, source_row in enumerate(source_rows, start=2):
        decision_id = source_row.get("decision_id", "")
        decision_ids.append(decision_id)
        if re.fullmatch(r"B04-PROJ-[0-9A-F]{12}", decision_id) is None:
            fail(rows, f"{label} row {row_number} has an invalid projection decision_id")
        if source_row.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        years = projection_year_range(
            source_row,
            label=label,
            row_number=row_number,
            rows=rows,
        )
        if not source_row.get("source_file"):
            fail(rows, f"{label} row {row_number} lacks source_file")
        if not source_row.get("column_name"):
            fail(rows, f"{label} row {row_number} lacks column_name")
        if source_row.get("reviewed") != "true":
            fail(rows, f"{label} row {row_number} is not reviewed")
        role = source_row.get("role", "")
        if role not in allowed_roles:
            fail(rows, f"{label} row {row_number} has unsupported role {role!r}")
        canonical_dimension = source_row.get("canonical_dimension", "")
        if role == "identifier":
            if source_row.get("column_name", "").upper() != "UNITID":
                fail(rows, f"{label} row {row_number} identifier must be UNITID")
            if canonical_dimension:
                fail(rows, f"{label} row {row_number} identifier has canonical_dimension")
        elif role == "dimension":
            if canonical_dimension.upper() != source_row.get("column_name", "").upper():
                fail(
                    rows,
                    f"{label} row {row_number} canonical_dimension must equal column_name",
                )
            if years is not None and canonical_dimension:
                start, end = years
                for year in range(start, end + 1):
                    supported = any(
                        table_start <= year <= table_end
                        and table_source == source_row.get("source_file", "").upper()
                        and patterns_intersect(
                            table_pattern,
                            source_row.get("access_table_pattern", "").upper(),
                        )
                        and canonical_dimension.upper() in dimensions
                        for (
                            table_start,
                            table_end,
                            table_source,
                            table_pattern,
                            dimensions,
                        ) in table_dimensions
                    )
                    if not supported:
                        fail(
                            rows,
                            f"{label} row {row_number} dimension "
                            f"{canonical_dimension!r} lacks table-grain support in {year}",
                        )
                        break
        elif canonical_dimension:
            fail(
                rows,
                f"{label} row {row_number} non-dimension role has canonical_dimension",
            )
        exclusion_reason = source_row.get("exclusion_reason", "")
        if role == "excluded" and not exclusion_reason:
            fail(rows, f"{label} row {row_number} excluded role lacks exclusion_reason")
        if role != "excluded" and exclusion_reason:
            fail(
                rows,
                f"{label} row {row_number} non-excluded role has exclusion_reason",
            )
        for field in ("source_evidence", "review_note"):
            if not source_row.get(field):
                fail(rows, f"{label} row {row_number} lacks {field}")
    if len(decision_ids) != len(set(decision_ids)):
        fail(rows, f"{label} contains a duplicate decision_id")
    validate_projection_scope_overlaps(
        source_rows,
        label=label,
        rows=rows,
        column_field="column_name",
    )


def validate_signed_analysis_schema_rows(
    schema_rows: list[dict[str, str]],
    *,
    rows: list[str],
) -> None:
    label = "contracts/analysis_schema.csv"
    identifiers: list[str] = []
    source_variables: list[str] = []
    allowed_types = {"float", "categorical string", "free text"}
    authorized_exclusion_count = 0
    for row_number, schema_row in enumerate(schema_rows, start=2):
        if schema_row.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        analysis_column = schema_row.get("analysis_column", "")
        identifiers.append(analysis_column.upper())
        source_variables.append(schema_row.get("source_variables", "").upper())
        if not analysis_column:
            fail(rows, f"{label} row {row_number} lacks analysis_column")
        if schema_row.get("logical_type") not in allowed_types:
            fail(rows, f"{label} row {row_number} has unsupported logical_type")
        if not schema_row.get("source_variables", "").startswith("variable_id:nces:"):
            fail(rows, f"{label} row {row_number} lacks an exact NCES variable_id")
        if schema_row.get("transformation") != "identity":
            fail(rows, f"{label} row {row_number} must use identity transformation")
        status = schema_row.get("status")
        if schema_row.get("nullable") != "true":
            fail(rows, f"{label} row {row_number} must be nullable")
        if status == "excluded_all_null":
            authorized_exclusion_count += 1
            if analysis_column != "CMP1PY0":
                fail(
                    rows,
                    f"{label} row {row_number} excluded_all_null is authorized "
                    "only for CMP1PY0",
                )
            if schema_row.get("source_variables") != (
                "variable_id:nces:IC_PY:00015091:CMP1PY0"
            ):
                fail(
                    rows,
                    f"{label} CMP1PY0 source_variables must equal the exact "
                    "authorized NCES identity",
                )
            if schema_row.get("inclusion_reason") != "no_observed_values":
                fail(
                    rows,
                    f"{label} CMP1PY0 exclusion reason must be "
                    "no_observed_values",
                )
            if (
                schema_row.get("first_year") != "2009"
                or schema_row.get("last_year") != "2012"
            ):
                fail(
                    rows,
                    f"{label} CMP1PY0 excluded_all_null window must be "
                    "2009 through 2012",
                )
        elif status != "active":
            fail(
                rows,
                f"{label} row {row_number} must be active or the exact "
                "authorized CMP1PY0 excluded_all_null decision",
            )
        try:
            first = int(schema_row.get("first_year", ""))
            last = int(schema_row.get("last_year", ""))
        except ValueError:
            first, last = 0, -1
        if first < 2004 or last > 2023 or first > last:
            fail(rows, f"{label} row {row_number} has an invalid year range")
        if not schema_row.get("inclusion_reason"):
            fail(rows, f"{label} row {row_number} lacks inclusion_reason")
    if len(identifiers) != len(set(identifiers)):
        fail(rows, f"{label} contains duplicate analysis_column identities")
    if len(source_variables) != len(set(source_variables)):
        fail(rows, f"{label} contains duplicate source_variables identities")
    if authorized_exclusion_count > 1:
        fail(rows, f"{label} contains more than one CMP1PY0 excluded_all_null row")


def validate_signed_discrete_family_rows(
    family_rows: list[dict[str, str]],
    *,
    rows: list[str],
) -> None:
    label = "contracts/discrete_families.csv"
    family_ids: list[str] = []
    component_ids: list[tuple[str, str, str]] = []
    derived_fields = (
        "active_tokens",
        "inactive_tokens",
        "missing_tokens",
        "output_column",
        "output_type",
        "multi_active_policy",
    )
    for row_number, family_row in enumerate(family_rows, start=2):
        if family_row.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        family_ids.append(family_row.get("family_id", "").upper())
        component_ids.append(
            (
                family_row.get("source_file", "").upper(),
                family_row.get("component_varname", "").upper(),
                family_row.get("component_code", ""),
            )
        )
        if not all(
            family_row.get(field)
            for field in ("source_file", "family_id", "component_varname", "component_code")
        ):
            fail(rows, f"{label} row {row_number} lacks an exact component identity")
        if family_row.get("semantic_type") != "not_collapsible":
            fail(rows, f"{label} row {row_number} must remain not_collapsible")
        if any(family_row.get(field) for field in derived_fields):
            fail(rows, f"{label} row {row_number} manufactures unsupported derived semantics")
        if family_row.get("drop_components") != "false":
            fail(rows, f"{label} row {row_number} must retain source components")
        for field in ("source_evidence", "review_note"):
            if not family_row.get(field):
                fail(rows, f"{label} row {row_number} lacks {field}")
    if len(family_ids) != len(set(family_ids)):
        fail(rows, f"{label} contains duplicate family_id identities")
    if len(component_ids) != len(set(component_ids)):
        fail(rows, f"{label} contains duplicate component identities")


def validate_signed_prch_rows(
    policy_rows: list[dict[str, str]],
    *,
    rows: list[str],
) -> None:
    label = "contracts/prch_policy.csv"
    rule_ids: list[str] = []
    scopes: list[tuple[str, str, str, str, str]] = []
    for row_number, policy_row in enumerate(policy_rows, start=2):
        rule_id = policy_row.get("rule_id", "")
        rule_ids.append(rule_id)
        if re.fullmatch(r"B07-POL-[0-9A-F]{12}", rule_id) is None:
            fail(rows, f"{label} row {row_number} has an invalid rule_id")
        projection_year_range(
            policy_row,
            label=label,
            row_number=row_number,
            rows=rows,
        )
        if not policy_row.get("flag"):
            fail(rows, f"{label} row {row_number} lacks flag")
        try:
            int(policy_row.get("code", ""))
        except ValueError:
            fail(rows, f"{label} row {row_number} has a non-integer code")
        action = policy_row.get("action", "")
        if action not in {"retain", "null"}:
            fail(rows, f"{label} row {row_number} has unsupported action {action!r}")
        targets = split_pipe_tokens(
            policy_row.get("target_columns", ""),
            label=label,
            row_number=row_number,
            field="target_columns",
            rows=rows,
            allow_empty=action == "retain",
        )
        if action == "retain" and targets:
            fail(rows, f"{label} row {row_number} retain action must not target values")
        if any(any(token in target for token in "*?[]") for target in targets):
            fail(rows, f"{label} row {row_number} uses wildcard target_columns")
        try:
            predicate = json.loads(policy_row.get("row_predicate", ""))
        except json.JSONDecodeError:
            predicate = None
        if not isinstance(predicate, dict) or not predicate:
            fail(rows, f"{label} row {row_number} has an invalid row_predicate")
        if policy_row.get("review_status") != "approved":
            fail(rows, f"{label} row {row_number} is not approved")
        for field in (
            "accounting_standard",
            "form",
            "part",
            "source_reference",
            "rationale",
        ):
            if not policy_row.get(field):
                fail(rows, f"{label} row {row_number} lacks {field}")
        scopes.append(
            (
                policy_row.get("year_start", ""),
                policy_row.get("year_end", ""),
                policy_row.get("flag", "").upper(),
                policy_row.get("code", ""),
                policy_row.get("row_predicate", ""),
            )
        )
    if len(rule_ids) != len(set(rule_ids)):
        fail(rows, f"{label} contains duplicate rule_id identities")
    if len(scopes) != len(set(scopes)):
        fail(rows, f"{label} contains duplicate rule scopes")


def validate_signed_benchmark_rows(
    benchmark_rows: list[dict[str, str]],
    *,
    repo_root: Path,
    rows: list[str],
    evidence_path: str,
    evidence_sha256: str,
) -> None:
    label = "contracts/external_benchmarks.csv"
    benchmark_ids: list[str] = []
    if repository_relative_path_has_symlink(repo_root, evidence_path):
        fail(rows, "B08 source evidence must be a regular non-symlink file")
    for row_number, benchmark_row in enumerate(benchmark_rows, start=2):
        benchmark_ids.append(benchmark_row.get("benchmark_id", "").upper())
        if benchmark_row.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        if benchmark_row.get("source_evidence_path") != evidence_path:
            fail(
                rows,
                f"{label} row {row_number} source_evidence_path must equal "
                f"{evidence_path!r}",
            )
        if benchmark_row.get("source_evidence_sha256") != evidence_sha256:
            fail(
                rows,
                f"{label} row {row_number} source_evidence_sha256 must equal "
                f"{evidence_sha256}",
            )
        if benchmark_row.get("review_status") != "approved":
            fail(rows, f"{label} row {row_number} is not approved")
        if benchmark_row.get("reviewer") != REVIEWED_B03_B04_AUTHOR:
            fail(rows, f"{label} row {row_number} has the wrong reviewer")
        if benchmark_row.get("review_date") != SIGNED_PROJECTION_AUTHOR_DATE:
            fail(rows, f"{label} row {row_number} has the wrong review_date")
        for field in (
            "artifact",
            "year",
            "metric",
            "variable",
            "component_family",
            "expected_value",
            "absolute_tolerance",
            "relative_tolerance",
            "tolerance_rationale",
            "official_source",
            "source_date_or_version",
            "definition",
        ):
            if not benchmark_row.get(field):
                fail(rows, f"{label} row {row_number} lacks {field}")
        validate_external_benchmark_row(
            benchmark_row,
            row_number=row_number,
            repo_root=repo_root,
            rows=rows,
        )
    if len(benchmark_ids) != len(set(benchmark_ids)):
        fail(rows, f"{label} contains duplicate benchmark_id identities")


def validate_signed_backfill_rows(
    backfill_rows: list[dict[str, str]],
    *,
    rows: list[str],
) -> None:
    label = "contracts/metadata_backfill_approvals.csv"
    approval_ids: list[str] = []
    target_ids: list[tuple[str, str, str, str]] = []
    expected_fields = "varTitle|longDescription|DataType|format|Fieldwidth"
    for row_number, backfill in enumerate(backfill_rows, start=2):
        approval_ids.append(backfill.get("approval_id", "").upper())
        target_ids.append(
            (
                backfill.get("target_year", ""),
                backfill.get("source_file", "").upper(),
                backfill.get("access_table_name", "").upper(),
                backfill.get("target_varname", "").upper(),
            )
        )
        if backfill.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        if backfill.get("target_year") != "2010":
            fail(rows, f"{label} row {row_number} target_year must equal '2010'")
        if backfill.get("donor_year") != "2011":
            fail(rows, f"{label} row {row_number} donor_year must equal '2011'")
        if backfill.get("fields_backfilled") != expected_fields:
            fail(rows, f"{label} row {row_number} must backfill metadata fields only")
        if backfill.get("compatibility_status") != "exact_adjacent_donor_semantics_match":
            fail(rows, f"{label} row {row_number} lacks exact donor compatibility")
        if backfill.get("approval_status") != "approved":
            fail(rows, f"{label} row {row_number} is not approved")
        if backfill.get("reviewer") != REVIEWED_B03_B04_AUTHOR:
            fail(rows, f"{label} row {row_number} has the wrong reviewer")
        if backfill.get("review_date") != SIGNED_PROJECTION_AUTHOR_DATE:
            fail(rows, f"{label} row {row_number} has the wrong review_date")
        for field in (
            "approval_id",
            "source_file",
            "access_table_name",
            "variable_id",
            "target_varname",
            "expected_data_type",
            "expected_title",
            "compatibility_evidence",
            "justification",
        ):
            if not backfill.get(field):
                fail(rows, f"{label} row {row_number} lacks {field}")
    if len(approval_ids) != len(set(approval_ids)):
        fail(rows, f"{label} contains duplicate approval_id identities")
    if len(target_ids) != len(set(target_ids)):
        fail(rows, f"{label} contains duplicate metadata target identities")


def validate_signed_projection_governance(
    rows: list[str],
    *,
    repo_root: Path,
    bindings: dict[str, dict[str, Any]] = SIGNED_PROJECTION_BINDINGS,
    b08_evidence_path: str = SIGNED_B08_EVIDENCE_PATH,
    b08_evidence_sha256: str = SIGNED_B08_EVIDENCE_SHA256,
) -> None:
    validate_signed_projection_receipt(rows, repo_root=repo_root)
    analysis_binding = bindings.get("contracts/analysis_schema.csv", {})
    if (
        analysis_binding.get("sha256")
        == B05_AMENDMENT_ANALYSIS_SCHEMA_POST_SHA256
    ):
        validate_b05_amendment_governance(rows, repo_root=repo_root)
    prch_binding = bindings.get("contracts/prch_policy.csv", {})
    if prch_binding.get("sha256") == B07_AMENDMENT_POST_SHA256:
        validate_b07_prch_al_amendment_governance(rows, repo_root=repo_root)
    expected_paths = set(SIGNED_PROJECTION_BINDINGS)
    if set(bindings) != expected_paths:
        fail(rows, "signed projection bindings must cover exactly B03-B09 canonical paths")
        return
    parsed: dict[str, list[dict[str, str]]] = {}
    for relative_path in SIGNED_PROJECTION_BINDINGS:
        parsed[relative_path] = read_signed_projection_csv(
            rows,
            repo_root=repo_root,
            relative_path=relative_path,
            binding=bindings[relative_path],
        )

    table_rows = parsed["contracts/table_grain.csv"]
    source_rows = parsed["contracts/source_columns.csv"]
    validate_signed_table_grain_rows(table_rows, rows=rows)
    validate_signed_source_column_rows(
        source_rows,
        table_rows=table_rows,
        rows=rows,
    )
    validate_signed_analysis_schema_rows(
        parsed["contracts/analysis_schema.csv"],
        rows=rows,
    )
    validate_signed_discrete_family_rows(
        parsed["contracts/discrete_families.csv"],
        rows=rows,
    )
    validate_signed_prch_rows(parsed["contracts/prch_policy.csv"], rows=rows)
    validate_signed_benchmark_rows(
        parsed["contracts/external_benchmarks.csv"],
        repo_root=repo_root,
        rows=rows,
        evidence_path=b08_evidence_path,
        evidence_sha256=b08_evidence_sha256,
    )
    validate_signed_backfill_rows(
        parsed["contracts/metadata_backfill_approvals.csv"],
        rows=rows,
    )
    validate_source_metadata_alias_decision(
        rows,
        repo_root=repo_root,
        decisions=None,
    )


def validate_decision_register(
    rows: list[str],
    *,
    repo_root: Path,
) -> dict[str, dict[str, str]]:
    label = "contracts/b03_b04_decisions.csv"
    decisions = read_governance_csv(
        repo_root / label,
        required_columns=DECISION_REGISTER_COLUMNS,
        label=label,
        rows=rows,
    )
    decision_ids = [row.get("decision_id", "") for row in decisions]
    if (
        len(decisions) != 28
        or len(set(decision_ids)) != 28
        or set(decision_ids) != EXPECTED_DECISION_IDS
    ):
        fail(rows, f"{label} must contain exactly the expected 28 unique decision_id values")

    by_id: dict[str, dict[str, str]] = {}
    for row_number, decision in enumerate(decisions, start=2):
        decision_id = decision.get("decision_id", "")
        if decision_id and decision_id not in by_id:
            by_id[decision_id] = decision
        blank = [
            field
            for field in DECISION_REGISTER_COLUMNS
            if not decision.get(field, "").strip()
        ]
        if blank:
            fail(
                rows,
                f"{label} row {row_number} has blank reviewed fields: "
                + ", ".join(blank),
            )
        expected_source_commit = EXPECTED_DECISION_SOURCE_COMMITS.get(decision_id)
        if decision.get("source_commit") != expected_source_commit:
            fail(
                rows,
                f"{label} row {row_number} source_commit must equal "
                f"{expected_source_commit}",
            )
        if decision.get("reviewer") != REVIEWED_B03_B04_AUTHOR:
            fail(
                rows,
                f"{label} row {row_number} reviewer must equal "
                f"{REVIEWED_B03_B04_AUTHOR!r}",
            )
        expected_review_date = EXPECTED_DECISION_REVIEW_DATES.get(decision_id)
        if decision.get("reviewed_at") != expected_review_date:
            fail(
                rows,
                f"{label} row {row_number} reviewed_at must equal "
                f"{expected_review_date}",
            )
        allowed = {
            value.strip()
            for value in decision.get("allowed_decisions", "").split("|")
            if value.strip()
        }
        if decision.get("decision") not in allowed:
            fail(
                rows,
                f"{label} row {row_number} decision is not listed in allowed_decisions",
            )
        expected_decision = EXPECTED_DECISION_CHOICES.get(decision_id)
        if expected_decision is not None and decision.get("decision") != expected_decision:
            fail(
                rows,
                f"{label} {decision_id} decision must remain {expected_decision}",
            )
        expected_affected = EXPECTED_DECISION_AFFECTED_ROWS.get(decision_id)
        try:
            affected = int(decision.get("affected_year_table_column_rows", ""))
        except ValueError:
            affected = -1
        if expected_affected is not None and affected != expected_affected:
            fail(
                rows,
                f"{label} {decision_id} affected row count must equal "
                f"{expected_affected}",
            )

    blocked = {
        decision_id
        for decision_id, decision in by_id.items()
        if decision.get("decision") == "request_more_evidence"
    }
    if blocked:
        fail(
            rows,
            f"{label} must contain no request_more_evidence decisions; observed: "
            + ", ".join(sorted(blocked)),
        )
    supported = {
        decision_id
        for decision_id, decision in by_id.items()
        if decision.get("decision") != "request_more_evidence"
    }
    if supported != EXPECTED_SUPPORTED_DECISION_IDS:
        fail(rows, f"{label} must contain exactly the 28 supported decisions")
    return by_id


def validate_applied_decision_references(
    contract_rows: list[dict[str, str]],
    *,
    label: str,
    decisions: dict[str, dict[str, str]],
    rows: list[str],
) -> None:
    for row_number, contract_row in enumerate(contract_rows, start=2):
        decision_id = contract_row.get("decision_id", "")
        decision = decisions.get(decision_id)
        if decision is None:
            fail(
                rows,
                f"{label} row {row_number} references unknown decision_id "
                f"{decision_id!r}",
            )
        elif decision.get("decision") == "request_more_evidence":
            fail(
                rows,
                f"{label} row {row_number} applies request_more_evidence decision_id "
                f"{decision_id}",
            )


def validate_table_grain_decision(
    rows: list[str],
    *,
    repo_root: Path,
    decisions: dict[str, dict[str, str]],
) -> None:
    label = "contracts/table_grain.csv"
    table_rows = read_governance_csv(
        repo_root / label,
        required_columns=TABLE_GRAIN_COLUMNS,
        label=label,
        rows=rows,
    )
    validate_applied_decision_references(
        table_rows,
        label=label,
        decisions=decisions,
        rows=rows,
    )
    if len(table_rows) != 1 or [
        row.get("decision_id") for row in table_rows
    ] != ["B03-ZERO-001"]:
        fail(rows, "table_grain must contain exactly one B03-ZERO-001 row")
        return
    expected = {
        "contract_id": PANEL_CONTRACT_ID,
        "year_start": "2009",
        "year_end": "2009",
        "source_file": "SAL_A_LT",
        "access_table_pattern": "SAL2009_A_LT9",
        "grain_class": "dimensioned",
        "unit_key_columns": "UNITID|ARANK",
        "dimension_columns": "ARANK",
        "measure_selection_rule": "source_columns_contract",
        "expected_rows_per_unit": "many",
        "aggregation_policy": "exact_duplicate_only",
        "reviewed": "true",
    }
    table_row = table_rows[0]
    for field, value in expected.items():
        if table_row.get(field, "") != value:
            fail(
                rows,
                f"{label} B03-ZERO-001 {field} must equal {value!r}",
            )
    for field in ("source_evidence", "review_note"):
        if not table_row.get(field, ""):
            fail(rows, f"{label} B03-ZERO-001 lacks {field}")
    if B03_SAL2009_SCHEMA_SHA256 not in table_row.get("source_evidence", ""):
        fail(
            rows,
            f"{label} B03-ZERO-001 archived schema SHA-256 must equal "
            f"{B03_SAL2009_SCHEMA_SHA256}",
        )


def expected_source_column_scopes() -> set[tuple[str, str, str, str, str, str, str]]:
    expected: set[tuple[str, str, str, str, str, str, str]] = set()

    def add(
        decision_id: str,
        year: int,
        source_file: str,
        table: str,
        column: str,
        role: str,
    ) -> None:
        expected.add(
            (
                decision_id,
                str(year),
                str(year),
                source_file,
                table,
                column,
                role,
            )
        )

    for year in range(2017, 2024):
        add("B04-GAP-001", year, "CUSTOMCGIDS", f"CUSTOMCGIDS{year}", "CGCITY", "metadata")
    add("B04-GAP-002", 2023, "CUSTOMCGIDS", "CUSTOMCGIDS2023", "CYACTIVE", "metadata")
    add("B04-GAP-003", 2023, "CUSTOMCGIDS", "CUSTOMCGIDS2023", "MATCH", "excluded")
    add("B04-GAP-004", 2023, "CUSTOMCGIDS", "CUSTOMCGIDS2023", "SECTOR", "metadata")
    add("B04-GAP-005", 2014, "DRVHR", "DRVHR2014", "ACT", "metadata")
    flag_columns = {
        6: "REV_ADM",
        7: "REV_AL",
        8: "REV_C",
        9: "REV_E12",
        10: "REV_EF",
        11: "REV_F",
        12: "REV_GR",
        13: "REV_GR2",
        14: "REV_HR",
        15: "REV_IC",
        16: "REV_OM",
        17: "REV_SFA",
    }
    for number, column in flag_columns.items():
        for year in (2017, 2018, 2021):
            add(
                f"B04-GAP-{number:03d}",
                year,
                "FLAGS",
                f"FLAGS{year}",
                column,
                "metadata",
            )
    add("B04-GAP-018", 2023, "IC", "IC2023", "TUITVRY1", "metadata")
    add("B04-GAP-019", 2023, "IC", "IC2023", "TUITVRY2", "metadata")
    add("B04-GAP-020", 2023, "IC", "IC2023", "TUITVRY3", "metadata")
    add("B04-GAP-021", 2010, "SAL_A_LT", "SAL2010_A_LT9", "ARANK", "dimension")
    add("B04-GAP-022", 2010, "SAL_A_LT", "SAL2010_A_LT9", "EMPCNTM", "measure")
    add("B04-GAP-023", 2010, "SAL_A_LT", "SAL2010_A_LT9", "EMPCNTT", "measure")
    add("B04-GAP-024", 2010, "SAL_A_LT", "SAL2010_A_LT9", "EMPCNTW", "measure")
    add("B04-GAP-025", 2010, "SAL_FACULTY", "SAL2010_FACULTY", "DROP", "excluded")
    add("B04-GAP-026", 2010, "SAL_FACULTY", "SAL2010_FACULTY", "I", "excluded")
    return expected


def validate_source_column_decisions(
    rows: list[str],
    *,
    repo_root: Path,
    decisions: dict[str, dict[str, str]],
) -> None:
    label = "contracts/source_columns.csv"
    source_rows = read_governance_csv(
        repo_root / label,
        required_columns=SOURCE_COLUMN_COLUMNS,
        label=label,
        rows=rows,
    )
    validate_applied_decision_references(
        source_rows,
        label=label,
        decisions=decisions,
        rows=rows,
    )
    if len(source_rows) != 56:
        fail(rows, f"{label} must contain exactly 56 supported role rows")

    decision_counts = Counter(row.get("decision_id", "") for row in source_rows)
    if dict(decision_counts) != EXPECTED_SOURCE_COLUMN_DECISION_COUNTS:
        fail(
            rows,
            f"{label} decision counts do not match the 50 countersigned role rows",
        )
    role_counts = Counter(row.get("role", "").lower() for row in source_rows)
    if dict(role_counts) != EXPECTED_SOURCE_COLUMN_ROLE_COUNTS:
        fail(
            rows,
            f"{label} source_columns role counts must equal "
            f"{EXPECTED_SOURCE_COLUMN_ROLE_COUNTS}; observed={dict(role_counts)}",
        )

    actual_scopes = [
        (
            row.get("decision_id", ""),
            row.get("year_start", ""),
            row.get("year_end", ""),
            row.get("source_file", "").upper(),
            row.get("access_table_pattern", "").upper(),
            row.get("column_name", "").upper(),
            row.get("role", "").lower(),
        )
        for row in source_rows
    ]
    expected_scopes = expected_source_column_scopes()
    if set(actual_scopes) != expected_scopes or len(actual_scopes) != len(set(actual_scopes)):
        missing = len(expected_scopes - set(actual_scopes))
        unexpected = len(set(actual_scopes) - expected_scopes)
        fail(
            rows,
            f"{label} exact reviewed scopes differ: missing={missing} "
            f"unexpected={unexpected} duplicate_rows={len(actual_scopes) - len(set(actual_scopes))}",
        )

    for row_number, source_row in enumerate(source_rows, start=2):
        if source_row.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        if source_row.get("reviewed", "").lower() not in {"1", "true", "yes", "approved"}:
            fail(rows, f"{label} row {row_number} is not reviewed")
        for field in ("source_evidence", "review_note"):
            if not source_row.get(field, ""):
                fail(rows, f"{label} row {row_number} lacks {field}")
        role = source_row.get("role", "").lower()
        if role == "dimension" and source_row.get("canonical_dimension", "").upper() != "ARANK":
            fail(rows, f"{label} row {row_number} dimension must canonically bind ARANK")
        if role == "excluded" and not source_row.get("exclusion_reason", ""):
            fail(rows, f"{label} row {row_number} excluded role lacks exclusion_reason")

def validate_source_metadata_alias_decision(
    rows: list[str],
    *,
    repo_root: Path,
    decisions: dict[str, dict[str, str]] | None,
) -> None:
    label = "contracts/source_metadata_aliases.csv"
    alias_rows = read_governance_csv(
        repo_root / label,
        required_columns=SOURCE_METADATA_ALIAS_COLUMNS,
        label=label,
        rows=rows,
    )
    actual_alias_hash = sha256_file(repo_root / label)
    if actual_alias_hash != REVIEWED_SOURCE_METADATA_ALIASES_SHA256:
        fail(
            rows,
            f"{label} reviewed SHA-256 must equal "
            f"{REVIEWED_SOURCE_METADATA_ALIASES_SHA256}; "
            f"observed={actual_alias_hash}",
        )
    if decisions is not None:
        validate_applied_decision_references(
            alias_rows,
            label=label,
            decisions=decisions,
            rows=rows,
        )
    if len(alias_rows) != 343:
        fail(rows, f"{label} must contain exactly 343 reviewed aliases")

    source_keys: list[tuple[str, str, str, str]] = []
    target_keys: list[tuple[str, str, str, str, str, str, str]] = []
    for row_number, alias in enumerate(alias_rows, start=2):
        if alias.get("contract_id") != PANEL_CONTRACT_ID:
            fail(rows, f"{label} row {row_number} is not bound to the current contract_id")
        if alias.get("decision_id") != "B04-ALIAS-001":
            fail(rows, f"{label} row {row_number} must reference B04-ALIAS-001")
        if alias.get("year") != "2023":
            fail(rows, f"{label} row {row_number} must be scoped to exact year 2023")
        if alias.get("source_file", "").upper() != "SFA_P":
            fail(rows, f"{label} row {row_number} must use source_file SFA_P")
        if alias.get("review_status", "").lower() != "approved":
            fail(rows, f"{label} row {row_number} alias review_status must be approved")
        if alias.get("reviewer") != REVIEWED_B03_B04_AUTHOR:
            fail(
                rows,
                f"{label} row {row_number} alias reviewer must equal "
                f"{REVIEWED_B03_B04_AUTHOR!r}",
            )
        if alias.get("review_date") != INITIAL_REVIEWED_B03_B04_DATE:
            fail(
                rows,
                f"{label} row {row_number} alias review_date must equal "
                f"{INITIAL_REVIEWED_B03_B04_DATE}",
            )
        for field in (
            "source_access_table_name",
            "source_varname",
            "selected_access_table_name",
            "selected_file_number",
            "selected_source_varnumber",
            "selected_varname",
            "selected_metadata_source",
            "selected_metadata_table_name",
            "evidence",
            "justification",
        ):
            if not alias.get(field, ""):
                fail(rows, f"{label} row {row_number} lacks {field}")
        source_scope_fields = (
            alias.get("year", ""),
            alias.get("source_file", ""),
            alias.get("source_access_table_name", ""),
            alias.get("source_varname", ""),
        )
        if any(any(token in value for token in "*?[]") for value in source_scope_fields):
            fail(
                rows,
                f"{label} row {row_number} has a non-exact or overlapping source scope",
            )
        if alias.get("source_varname", "").upper() != alias.get(
            "selected_varname", ""
        ).upper():
            fail(
                rows,
                f"{label} row {row_number} redirects a source value to another varname",
            )
        if alias.get("selected_metadata_source", "") != "access_varlist":
            fail(rows, f"{label} row {row_number} metadata source must be access_varlist")
        if alias.get("selected_metadata_table_name", "") != "vartable23":
            fail(rows, f"{label} row {row_number} metadata table must be vartable23")
        source_keys.append(tuple(value.upper() for value in source_scope_fields))
        target_keys.append(
            (
                alias.get("year", ""),
                alias.get("selected_access_table_name", "").upper(),
                alias.get("selected_file_number", ""),
                alias.get("selected_source_varnumber", ""),
                alias.get("selected_varname", "").upper(),
                alias.get("selected_metadata_source", ""),
                alias.get("selected_metadata_table_name", ""),
            )
        )

    if len(source_keys) != len(set(source_keys)):
        fail(rows, f"{label} has duplicate or overlapping source identities")
    if len(target_keys) != len(set(target_keys)):
        fail(rows, f"{label} has duplicate selected metadata identities")

    group_counts = Counter(
        (
            alias.get("source_access_table_name", "").upper(),
            alias.get("selected_access_table_name", "").upper(),
            alias.get("selected_file_number", ""),
        )
        for alias in alias_rows
    )
    if dict(group_counts) != EXPECTED_ALIAS_GROUP_COUNTS:
        fail(
            rows,
            f"{label} alias group counts must equal {EXPECTED_ALIAS_GROUP_COUNTS}; "
            f"observed={dict(group_counts)}",
        )


def validate_b03_b04_governance(
    rows: list[str],
    *,
    repo_root: Path,
) -> None:
    decisions = validate_decision_register(rows, repo_root=repo_root)
    validate_table_grain_decision(
        rows,
        repo_root=repo_root,
        decisions=decisions,
    )
    validate_source_column_decisions(
        rows,
        repo_root=repo_root,
        decisions=decisions,
    )
    validate_source_metadata_alias_decision(
        rows,
        repo_root=repo_root,
        decisions=decisions,
    )


def validate_release_governance_files(
    rows: list[str],
    *,
    repo_root: Path = REPO_ROOT,
) -> None:
    checks = {
        "contracts/release_diff_overrides.csv": {
            "category",
            "artifact_key",
            "relative_path",
            "field",
            "baseline",
            "current",
            "justification",
        },
        "contracts/known_limitations.csv": {
            "limitation_id",
            "scope",
            "status",
            "first_release",
            "last_reviewed",
            "description",
            "evidence_path",
            "mitigation",
        },
        "contracts/transformation_ledger.csv": {
            "transformation_id",
            "stage",
            "scope",
            "status",
            "first_release",
            "description",
            "evidence_path",
            "release_policy",
            "reviewer_note",
        },
        "contracts/external_benchmarks.csv": {
            "benchmark_id",
            "contract_id",
            "artifact",
            "year",
            "metric",
            "variable",
            "filters",
            "component_family",
            "expected_value",
            "absolute_tolerance",
            "relative_tolerance",
            "tolerance_rationale",
            "official_source",
            "source_date_or_version",
            "source_evidence_path",
            "source_evidence_sha256",
            "review_status",
            "reviewer",
            "review_date",
            "definition",
            "notes",
        },
    }
    for rel_path, required in checks.items():
        path = repo_root / rel_path
        if not path.exists():
            fail(rows, f"governance file does not exist: {rel_path}")
            continue
        with path.open(newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            header = set(reader.fieldnames or [])
            missing = required - header
            if missing:
                fail(rows, f"{rel_path} missing columns: {', '.join(sorted(missing))}")
            for idx, row in enumerate(reader, start=2):
                if not any((value or "").strip() for value in row.values()):
                    continue
                if "justification" in required and not row.get("justification", "").strip():
                    fail(rows, f"{rel_path} row {idx} lacks justification")
                if "limitation_id" in required and not row.get("limitation_id", "").strip():
                    fail(rows, f"{rel_path} row {idx} lacks limitation_id")
                if "transformation_id" in required and not row.get("transformation_id", "").strip():
                    fail(rows, f"{rel_path} row {idx} lacks transformation_id")
                if rel_path == "contracts/external_benchmarks.csv":
                    validate_external_benchmark_row(
                        row,
                        row_number=idx,
                        repo_root=repo_root,
                        rows=rows,
                    )
    receipt_path = repo_root / SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH
    if (
        receipt_path.exists()
        or receipt_path.is_symlink()
        or repository_relative_path_has_symlink(
            repo_root,
            SIGNED_PROJECTION_RECEIPT_RELATIVE_PATH,
        )
    ):
        validate_signed_projection_governance(rows, repo_root=repo_root)
    else:
        validate_legacy_canonical_prestate(rows, repo_root=repo_root)
        validate_b03_b04_governance(rows, repo_root=repo_root)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    repo_root = Path(args.repo_root).expanduser().resolve()
    contract_path = (
        Path(args.contract)
        if args.contract is not None
        else repo_root / "contracts" / "panel_spec.toml"
    )
    contract = load_contract(contract_path)
    failures: list[str] = []
    validate_contract_identity(contract, failures)
    validate_artifacts(contract, failures)
    validate_policy_references(contract, failures)
    validate_release(contract, failures)
    validate_external_validation(contract, failures)
    validate_qa_artifacts(contract, failures)
    validate_wide_build(contract, failures)
    validate_cleaning(contract, failures)
    validate_dictionary_overrides(contract, failures, repo_root=repo_root)
    validate_release_governance_files(failures, repo_root=repo_root)
    if failures:
        print("Panel contract validation failed:")
        for row in failures:
            print(f"  - {row}")
        return 1
    print(f"Panel contract validation passed: {contract_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
