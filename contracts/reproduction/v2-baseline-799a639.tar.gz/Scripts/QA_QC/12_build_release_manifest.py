#!/usr/bin/env python3
"""
QA 12: build a release manifest with checksums and lightweight file metadata.

Reads:
- generated `IPEDSDB_ROOT` artifacts
- tracked release contracts and method docs in the repo

Writes:
- `Checks/v2/release_manifest/release_manifest.csv`
- `Checks/v2/release_manifest/release_manifest.json`
- `Checks/v2/release_manifest/release_manifest_summary.csv`
- `Checks/v2/release_manifest/release_manifest_summary.md`

This script creates the checksum ledger for a citable data release. It does not
decide whether a build is release-ready; run the acceptance audit first.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

import pandas as pd
import pyarrow.parquet as pq

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import DEFAULT_IPEDSDB_ROOT, compute_file_metadata, ensure_data_layout, parse_years, repo_root
from stage_provenance import ProvenanceError, resolve_run_dir, verify_run


MANIFEST_VERSION = "1.0"
REQUIRED_CAUSAL_STAGES = ("01", "02", "03", "04", "05", "06", "07", "qa00", "qa01")
CAUSAL_RECEIPT_FILES = (*[f"{stage}.json" for stage in REQUIRED_CAUSAL_STAGES], "run_manifest.json")

# These evidence files are produced as one immutable or content-addressed
# release decision.  Keep the human-facing descriptions for the high-level
# artifacts and generate descriptions for the lower-level bundle members
# below.  In strict release mode every member is required and no extra member
# is admitted into the public manifest.
CORE_REQUIRED_QA_ARTIFACTS = [
    (
        "Checks/v2/acceptance_qc/acceptance_summary.csv",
        "Semantic acceptance decision required by the release gate",
    ),
    (
        "Checks/v2/acceptance_qc/acceptance_summary.md",
        "Human-readable semantic acceptance decision",
    ),
    (
        "Checks/v2/acceptance_qc/acceptance_manifest.json",
        "Acceptance verifier, contract, run, and check bindings",
    ),
    (
        "Checks/v2/external_benchmarks/external_benchmark_reconciliation.csv",
        "Mandatory independently sourced benchmark reconciliation",
    ),
    (
        "Checks/v2/external_benchmarks/external_benchmark_reconciliation.json",
        "Benchmark verifier and causal-input bindings",
    ),
    (
        "Checks/v2/external_benchmarks/external_benchmark_reconciliation.md",
        "Human-readable benchmark reconciliation",
    ),
    (
        "Checks/v2/entity_continuity/entity_continuity_crosswalk.csv",
        "Canonical institution continuity risk evidence",
    ),
    (
        "Checks/v2/entity_continuity/entity_continuity_manifest.json",
        "Content and runtime bindings for continuity evidence",
    ),
    (
        "Checks/v2/entity_continuity/entity_continuity_summary.csv",
        "Machine-readable entity continuity summary",
    ),
    (
        "Checks/v2/entity_continuity/entity_continuity_summary.md",
        "Human-readable entity continuity summary",
    ),
    (
        "Checks/v2/entity_continuity/entity_continuity_value_lineage.parquet",
        "Stage 06 value lineage retained for continuity evidence",
    ),
    (
        "Checks/v2/entity_continuity_verification/entity_continuity_verification.json",
        "Independent continuity verification decision and bindings",
    ),
    (
        "Checks/v2/panel_qc/panel_qa_summary.csv",
        "Authoritative managed PRCH panel-QA summary",
    ),
    (
        "Checks/v2/panel_qc/panel_qa_coverage_matrix.csv",
        "PRCH policy coverage matrix",
    ),
    (
        "Checks/v2/panel_qc/panel_qa_by_flag_code.csv",
        "PRCH flag-code reconciliation",
    ),
    (
        "Checks/v2/panel_qc/panel_qa_action_reconciliation.csv",
        "Exact raw-to-clean action reconciliation",
    ),
    (
        "Checks/v2/panel_qc/panel_qa_evidence_checks.csv",
        "Independent panel-QA evidence decisions",
    ),
    (
        "Checks/v2/panel_qc/panel_qa_run_manifest.json",
        "Panel-QA run and artifact bindings",
    ),
]

STRICT_QA_ARTIFACT_NAMES_BY_DIR: dict[str, tuple[str, ...]] = {
    "Checks/download_qc": (
        "download_failures.csv",
        "missing_years.csv",
        "release_inventory.csv",
    ),
    "Checks/extract_qc": (
        "extract_failures.csv",
        "table_inventory_all_years.csv",
    ),
    "Checks/dictionary_qc": (
        "auxiliary_expected_metadata_tables.csv",
        "derived_or_custom_metadata_tables.csv",
        "dictionary_duplicates.csv",
        "dictionary_identity_issues.csv",
        "dictionary_metadata_candidates.csv",
        "dictionary_metadata_candidates_snapshot.csv",
        "dictionary_qaqc_summary.csv",
        "metadata_backfill_report.csv",
        "metadata_code_label_conflicts.csv",
        "metadata_code_label_conflicts_release.csv",
        "metadata_code_records.csv",
        "metadata_description_conflicts.csv",
        "metadata_description_records.csv",
        "metadata_varlist_conflicts.csv",
        "metadata_varlist_records.csv",
        "missing_descriptions_by_source_year.csv",
        "noncanonical_inventory_metadata_tables.csv",
        "noncanonical_metadata_tables.csv",
        "noncanonical_source_categories.csv",
        "source_file_conflicts.csv",
        "source_file_years.csv",
        "synthetic_rows_summary.csv",
        "unmapped_inventory_metadata_tables.csv",
        "unmapped_metadata_tables.csv",
        "varnumber_varname_collisions.csv",
    ),
    "Checks/v2/harmonize_qc": ("stitch_summary.csv",),
    "Checks/v2/wide_qc": (
        "qc_ambiguous_analysis_mappings.csv",
        "qc_analysis_schema_candidates.csv",
        "qc_canonical_column_coverage.csv",
        "qc_cast_diagnostics.csv",
        "qc_cast_summary.csv",
        "qc_contradictory_dictionary_discovery.csv",
        "qc_discrete_component_conflicts.csv",
        "qc_discrete_conflicts.csv",
        "qc_duplicate_source_column_inventory.csv",
        "qc_duplicate_value_lineage.csv",
        "qc_final_wide_conflicts.csv",
        "qc_final_wide_conflicts_summary.csv",
        "qc_irreversible_discrete_derivations.csv",
        "qc_lane_coverage.csv",
        "qc_lane_coverage_summary.csv",
        "qc_missing_dictionary_inventory.csv",
        "qc_missing_stage04_classification.csv",
        "qc_nonnullable_missing.csv",
        "qc_scalar_input_key_duplicates.csv",
        "qc_unknown_discrete_families.csv",
        "qc_unknown_discrete_tokens.csv",
        "qc_unknown_value_statuses.csv",
        "qc_unreviewed_source_column_inventory.csv",
        "qc_value_lineage.parquet",
        "wide_panel_qc_summary.csv",
    ),
    "Checks/v2/disc_qc": ("semantic_discrete_family_summary.csv",),
    "Checks/v2/prch_qc": (
        "panel_clean.parquet",
        "prch_cell_actions.parquet",
        "prch_clean_columns.csv",
        "prch_clean_summary.csv",
        "prch_current_run.json",
        "prch_flag_code_counts.csv",
        "prch_flag_policy.csv",
        "prch_lineage_summary.csv",
        "prch_run_manifest.json",
    ),
    "Checks/v2/panel_qc": (
        "panel_qa_action_reconciliation.csv",
        "panel_qa_by_flag_code.csv",
        "panel_qa_coverage_matrix.csv",
        "panel_qa_evidence_checks.csv",
        "panel_qa_run_manifest.json",
        "panel_qa_summary.csv",
    ),
    "Checks/v2/acceptance_qc": (
        "acceptance_manifest.json",
        "acceptance_summary.csv",
        "acceptance_summary.md",
    ),
    "Checks/v2/external_benchmarks": (
        "external_benchmark_reconciliation.csv",
        "external_benchmark_reconciliation.json",
        "external_benchmark_reconciliation.md",
    ),
    "Checks/v2/entity_continuity": (
        "entity_continuity_crosswalk.csv",
        "entity_continuity_manifest.json",
        "entity_continuity_summary.csv",
        "entity_continuity_summary.md",
        "entity_continuity_value_lineage.parquet",
    ),
    "Checks/v2/entity_continuity_verification": (
        "entity_continuity_verification.json",
    ),
}
QA_DIRS = tuple(STRICT_QA_ARTIFACT_NAMES_BY_DIR)

_CORE_REQUIRED_QA_NOTES = dict(CORE_REQUIRED_QA_ARTIFACTS)
REQUIRED_QA_ARTIFACTS = tuple(
    (
        f"{directory}/{name}",
        _CORE_REQUIRED_QA_NOTES.get(
            f"{directory}/{name}",
            f"Mandatory release evidence member from {directory}",
        ),
    )
    for directory, names in STRICT_QA_ARTIFACT_NAMES_BY_DIR.items()
    for name in names
)

RAW_METADATA_FILES = (
    "extraction_receipt.csv",
    "row_count_report.csv",
    "table_columns.csv",
    "table_inventory.csv",
    "table_schema.sql",
)
REPO_RELEASE_FILES = [
    "Dockerfile",
    ".dockerignore",
    "requirements-lock.txt",
    "LICENSE",
    "DATA_LICENSE.md",
    "CONTACT.md",
    "ACKNOWLEDGMENTS.md",
    "CITATION.cff",
    "README.md",
    "CONTRIBUTING.md",
    "SECURITY.md",
    "GOVERNANCE.md",
    "CHANGELOG.md",
    "MIGRATION.md",
    "METHODS_PANEL_CONSTRUCTION.md",
    "METHODS_PRCH_CLEANING.md",
    "codemeta.json",
    ".zenodo.json",
    ".github/CODEOWNERS",
    ".github/PULL_REQUEST_TEMPLATE.md",
    ".github/workflows/ci.yml",
    "requirements.txt",
    "contracts/panel_spec.toml",
    "contracts/b03_b04_decisions.csv",
    "contracts/dictionary_ambiguity_overrides.csv",
    "contracts/source_metadata_aliases.csv",
    "contracts/metadata_backfill_approvals.csv",
    "contracts/source_releases.csv",
    "contracts/source_columns.csv",
    "contracts/table_grain.csv",
    "contracts/analysis_schema.csv",
    "contracts/discrete_families.csv",
    "contracts/prch_policy.csv",
    "contracts/release_diff_overrides.csv",
    "contracts/known_limitations.csv",
    "contracts/transformation_ledger.csv",
    "contracts/external_benchmarks.csv",
    "Artifacts/release_validation_plan.md",
    "Artifacts/table_release_validation_metrics_template.csv",
    "Artifacts/legacy_analysis_schema_seed.csv",
    "docs/releases.html",
]


def parse_args() -> argparse.Namespace:
    data_root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default=str(data_root), help="External IPEDSDB_ROOT")
    p.add_argument("--years", default="2004:2023", help='Release year span, e.g. "2004:2023"')
    p.add_argument("--out-dir", default=None, help="Output directory. Defaults to Checks/v2/release_manifest under root.")
    p.add_argument("--include-qa-files", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require-clean-git", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--verify-causal-chain", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require-container-digest", action=argparse.BooleanOptionalAction, default=True)
    return p.parse_args()


def git_value(args: list[str], cwd: Path) -> str:
    try:
        return subprocess.check_output(["git", *args], cwd=cwd, text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return ""


def git_metadata(cwd: Path) -> dict[str, str]:
    status = git_value(["status", "--porcelain"], cwd)
    return {
        "git_commit": git_value(["rev-parse", "HEAD"], cwd),
        "git_branch": git_value(["branch", "--show-current"], cwd),
        "git_dirty": "true" if status else "false",
    }


def parquet_shape(path: Path) -> tuple[str, str]:
    if not path.exists() or path.suffix.lower() != ".parquet":
        return "", ""
    meta = pq.ParquetFile(path).metadata
    return str(int(meta.num_rows)), str(int(meta.num_columns))


def rel_or_blank(path: Path, base: Path) -> str:
    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


def artifact_id(role: str, path_base: str, relative_path: str) -> str:
    safe = relative_path.replace("/", "__").replace(" ", "_")
    return f"{role}:{path_base}:{safe}"


def build_artifact_row(
    *,
    role: str,
    path_base: str,
    base_dir: Path,
    relative_path: str,
    years_spec: str,
    generated_at_utc: str,
    git_meta: dict[str, str],
    notes: str = "",
) -> dict[str, object]:
    path = base_dir / relative_path
    present = path.exists() and path.is_file()
    size_bytes, sha256 = compute_file_metadata(path)
    rows, columns = parquet_shape(path)
    return {
        "manifest_version": MANIFEST_VERSION,
        "generated_at_utc": generated_at_utc,
        "artifact_id": artifact_id(role, path_base, relative_path),
        "role": role,
        "path_base": path_base,
        "relative_path": relative_path,
        "present": bool(present),
        "size_bytes": size_bytes,
        "sha256": sha256,
        "rows": rows,
        "columns": columns,
        "file_format": path.suffix.lower().lstrip("."),
        "years": years_spec,
        "git_commit": git_meta.get("git_commit", ""),
        "git_branch": git_meta.get("git_branch", ""),
        "git_dirty": git_meta.get("git_dirty", ""),
        "notes": notes,
    }


def discover_files(root: Path, rel_dir: str) -> Iterable[str]:
    base = root / rel_dir
    if not base.exists():
        return []
    return sorted(str(path.relative_to(root)) for path in base.rglob("*") if path.is_file())


def validate_directory_boundary(root: Path, rel_dir: str) -> None:
    """Reject a release evidence pointer that resolves outside IPEDSDB_ROOT."""

    base = root / rel_dir
    if not base.exists():
        return
    try:
        base.resolve(strict=True).relative_to(root.resolve(strict=True))
    except ValueError as exc:
        raise SystemExit(f"Release artifact directory escapes IPEDSDB_ROOT: {rel_dir}") from exc


def reject_unexpected_files(root: Path, rel_dir: str, expected: set[str]) -> None:
    """Require an exact file-name inventory for a strict release directory."""

    validate_directory_boundary(root, rel_dir)
    actual = set(discover_files(root, rel_dir))
    if actual:
        root_resolved = root.resolve(strict=True)
        for relative in sorted(actual):
            try:
                (root / relative).resolve(strict=True).relative_to(root_resolved)
            except ValueError as exc:
                raise SystemExit(f"Release artifact escapes IPEDSDB_ROOT: {relative}") from exc
    unexpected = sorted(actual - expected)
    if unexpected:
        raise SystemExit(
            f"Unexpected files in strict release artifact directory {rel_dir}: "
            + ", ".join(unexpected)
        )


def required_qa_artifacts(years: list[int]) -> list[tuple[str, str]]:
    artifacts = list(REQUIRED_QA_ARTIFACTS)
    for year in years:
        for name, description in (
            (f"source_column_coverage_{year}.csv", "Stage 04 source-column classification coverage"),
            (f"harmonize_summary_{year}.csv", "Stage 04 harmonization reconciliation"),
            (f"dropped_missing_unitid_{year}.csv", "Stage 04 missing-identifier rejection evidence"),
        ):
            artifacts.append((f"Checks/v2/harmonize_qc/{name}", description))
    return artifacts


def portable_manifest_leaf(value: object, *, field: str, manifest_path: Path) -> str:
    text = str(value).strip()
    path = Path(text)
    if (
        not text
        or path.is_absolute()
        or len(path.parts) != 1
        or path.name in {".", ".."}
        or "\\" in text
    ):
        raise SystemExit(f"{manifest_path}: {field} is not a portable filename: {text!r}")
    return text


def expected_download_paths(root: Path, year: int) -> list[str]:
    """Derive the two approved source downloads from the sealed year receipt."""

    manifest_path = root / "Raw_Access_Databases" / str(year) / "manifest.csv"
    if not manifest_path.is_file():
        return []
    try:
        frame = pd.read_csv(manifest_path, dtype=str, keep_default_na=False)
    except (OSError, pd.errors.ParserError, UnicodeError) as exc:
        raise SystemExit(f"Cannot read source manifest {manifest_path}: {exc}") from exc
    if len(frame) != 1:
        raise SystemExit(f"Source manifest must contain exactly one row: {manifest_path}")
    required = {"access_filename", "doc_filename"}
    missing = sorted(required - set(frame.columns))
    if missing:
        raise SystemExit(f"Source manifest is missing filename columns {missing}: {manifest_path}")
    row = frame.iloc[0]
    names = [
        portable_manifest_leaf(row[field], field=field, manifest_path=manifest_path)
        for field in ("access_filename", "doc_filename")
    ]
    if len({name.casefold() for name in names}) != len(names):
        raise SystemExit(f"Source manifest repeats a download filename: {manifest_path}")
    return [f"Raw_Access_Databases/{year}/downloads/{name}" for name in names]


def expected_root_artifacts(
    root: Path,
    years: list[int],
    include_qa_files: bool,
    *,
    require_release_evidence: bool = True,
) -> list[tuple[str, str, str]]:
    start, end = years[0], years[-1]
    artifacts: list[tuple[str, str, str]] = [
        ("dictionary_artifact", "Dictionary/v2/dictionary_lake.parquet", "V2 stitched variable metadata"),
        ("dictionary_artifact", "Dictionary/v2/dictionary_codes.parquet", "V2 dictionary code labels"),
        ("panel_output", f"Panels/v2/panel_long_scalar_{start}_{end}.parquet", "V2 scalar long lane"),
        ("panel_output", f"Panels/v2/panel_long_dimensioned_{start}_{end}.parquet", "V2 dimensioned long lane"),
        ("panel_output", f"Panels/v2/panel_source_rows_{start}_{end}.parquet", "V2 physical source-row ledger"),
        ("panel_output", f"Panels/v2/panel_wide_analysis_{start}_{end}.parquet", "V2 wide analysis panel"),
        ("panel_output", f"Panels/v2/panel_wide_raw_{start}_{end}.parquet", "V2 pre-cleaning raw wide panel"),
        ("panel_output", f"Panels/v2/panel_clean_prch_{start}_{end}.parquet", "V2 reviewed PRCH-cleaned panel"),
        ("causal_provenance", "Checks/v2/stage_manifests/CURRENT", "Authoritative causal build pointer"),
    ]
    for year in years:
        artifacts.append(
            (
                "raw_manifest",
                f"Raw_Access_Databases/{year}/manifest.csv",
                "Year-level download/extract manifest",
            )
        )
        download_dir = f"Raw_Access_Databases/{year}/downloads"
        metadata_dir = f"Raw_Access_Databases/{year}/metadata"
        if require_release_evidence:
            download_paths = expected_download_paths(root, year)
            reject_unexpected_files(root, download_dir, set(download_paths))
            metadata_paths = {
                f"{metadata_dir}/{name}"
                for name in RAW_METADATA_FILES
            }
            reject_unexpected_files(root, metadata_dir, metadata_paths)
            artifacts.extend(
                ("raw_download", rel, "Downloaded NCES source artifact")
                for rel in download_paths
            )
            artifacts.extend(
                ("extract_metadata", rel, "Required Access extraction metadata")
                for rel in sorted(metadata_paths)
            )
        else:
            artifacts.extend(
                ("raw_download", rel, "Downloaded NCES source artifact")
                for rel in discover_files(root, download_dir)
            )
            artifacts.extend(
                ("extract_metadata", rel, "Extracted Access metadata")
                for rel in discover_files(root, metadata_dir)
            )
        artifacts.append(("long_year_output", f"Cross_sections/v2/panel_long_scalar_{year}.parquet", "Per-year scalar long output"))
        artifacts.append(("long_year_output", f"Cross_sections/v2/panel_long_dimensioned_{year}.parquet", "Per-year dimensioned long output"))
        artifacts.append(("long_year_output", f"Cross_sections/v2/panel_source_rows_{year}.parquet", "Per-year physical source-row ledger"))
    if include_qa_files:
        if require_release_evidence:
            required_qa = required_qa_artifacts(years)
            required_qa_paths = {path for path, _description in required_qa}
            for qa_dir in QA_DIRS:
                expected_in_dir = {
                    path
                    for path in required_qa_paths
                    if Path(path).parent.as_posix() == qa_dir
                }
                reject_unexpected_files(root, qa_dir, expected_in_dir)
            artifacts.extend(
                ("required_qa_artifact", path, description)
                for path, description in required_qa
            )
        else:
            for qa_dir in QA_DIRS:
                artifacts.extend(
                    ("qa_artifact", rel, f"QA artifact from {qa_dir}")
                    for rel in discover_files(root, qa_dir)
                )
    try:
        causal_run = resolve_run_dir(root)
    except ProvenanceError:
        causal_run = None
    if causal_run is not None:
        if require_release_evidence:
            try:
                run_relative = causal_run.resolve(strict=True).relative_to(root.resolve(strict=True))
            except ValueError as exc:
                raise SystemExit("Causal run directory escapes IPEDSDB_ROOT") from exc
            expected_receipts = {
                (run_relative / name).as_posix()
                for name in CAUSAL_RECEIPT_FILES
            }
            reject_unexpected_files(root, run_relative.as_posix(), expected_receipts)
            artifacts.extend(
                ("causal_provenance", rel, "Required sealed causal stage receipt")
                for rel in sorted(expected_receipts)
            )
        else:
            artifacts.extend(
                ("causal_provenance", str(path.relative_to(root)), "Sealed causal stage receipt")
                for path in sorted(causal_run.glob("*.json"))
                if path.is_file()
            )
    relative_paths = [relative for _role, relative, _notes in artifacts]
    duplicates = sorted({path for path in relative_paths if relative_paths.count(path) > 1})
    if duplicates:
        raise SystemExit("Release artifact inventory repeats paths: " + ", ".join(duplicates))
    return artifacts


def expected_repo_artifacts() -> list[tuple[str, str, str]]:
    artifacts = [
        ("repo_contract", rel, "Tracked release contract or method document")
        for rel in REPO_RELEASE_FILES
    ]
    repository = repo_root().resolve()
    benchmark_contract = repository / "contracts" / "external_benchmarks.csv"
    if benchmark_contract.is_file():
        try:
            frame = pd.read_csv(benchmark_contract, dtype=str, keep_default_na=False)
        except (OSError, pd.errors.ParserError, UnicodeError) as exc:
            raise SystemExit(f"Cannot read external benchmark contract: {exc}") from exc
        if "source_evidence_path" in frame:
            evidence_paths = sorted(set(frame["source_evidence_path"].str.strip()) - {""})
            unsafe: list[str] = []
            for value in evidence_paths:
                path = Path(value)
                if (
                    not path.parts
                    or value in {".", ".."}
                    or value.startswith("~")
                    or (len(value) >= 2 and value[0].isalpha() and value[1] == ":")
                    or path.is_absolute()
                    or ".." in path.parts
                    or "\\" in value
                    or path.as_posix() != value
                ):
                    unsafe.append(value)
                    continue
                try:
                    (repository / path).resolve(strict=False).relative_to(repository)
                except ValueError:
                    unsafe.append(value)
            if unsafe:
                raise SystemExit("External benchmark evidence paths are not portable: " + ", ".join(unsafe))
            duplicate_contract_paths = sorted(set(evidence_paths) & set(REPO_RELEASE_FILES))
            if duplicate_contract_paths:
                raise SystemExit(
                    "External benchmark evidence paths duplicate release contract paths: "
                    + ", ".join(duplicate_contract_paths)
                )
            artifacts.extend(
                (
                    "repo_benchmark_evidence",
                    relative,
                    "Reviewed external benchmark source snapshot",
                )
                for relative in evidence_paths
            )
    return artifacts


def render_summary(summary: dict[str, object]) -> str:
    lines = [
        "# Release Manifest Summary",
        "",
        f"- generated_at_utc: `{summary['generated_at_utc']}`",
        f"- years: `{summary['years']}`",
        f"- git_commit: `{summary['git_commit']}`",
        f"- git_dirty: `{summary['git_dirty']}`",
        f"- artifact_rows: `{summary['artifact_rows']}`",
        f"- present_artifacts: `{summary['present_artifacts']}`",
        f"- missing_artifacts: `{summary['missing_artifacts']}`",
        f"- total_present_bytes: `{summary['total_present_bytes']}`",
        "",
        "Run `Scripts/QA_QC/13_verify_release_manifest.py` against `release_manifest.csv` before archiving.",
        "",
    ]
    return "\n".join(lines)


def main() -> int:
    args = parse_args()
    layout = ensure_data_layout(args.root)
    years = parse_years(args.years)
    years_spec = f"{years[0]}:{years[-1]}"
    out_dir = Path(args.out_dir).expanduser() if args.out_dir else layout.checks / "v2" / "release_manifest"
    strict_release_manifest = any(
        (
            bool(args.require_clean_git),
            bool(args.verify_causal_chain),
            bool(args.require_container_digest),
        )
    )
    if strict_release_manifest and not bool(args.include_qa_files):
        raise SystemExit("Strict release manifests cannot omit QA evidence.")
    canonical_out_dir = layout.checks / "v2" / "release_manifest"
    if strict_release_manifest and out_dir.resolve(strict=False) != canonical_out_dir.resolve(strict=False):
        raise SystemExit(
            "Strict release manifests must use the canonical output directory: "
            f"{canonical_out_dir}"
        )
    out_dir.mkdir(parents=True, exist_ok=True)
    repo = repo_root()
    git_meta = git_metadata(repo)
    if args.require_clean_git and git_meta.get("git_dirty") != "false":
        raise SystemExit("Release manifest requires a clean Git tree.")
    if args.verify_causal_chain:
        try:
            verify_run(
                root=layout.root,
                repo=repo,
                required_stages=REQUIRED_CAUSAL_STAGES,
                require_clean=bool(args.require_clean_git),
                require_container_digest=bool(args.require_container_digest),
            )
        except ProvenanceError as exc:
            raise SystemExit(str(exc)) from exc
    generated_at_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    rows: list[dict[str, object]] = []
    for role, rel, notes in expected_root_artifacts(
        layout.root,
        years,
        bool(args.include_qa_files),
        require_release_evidence=strict_release_manifest,
    ):
        rows.append(
            build_artifact_row(
                role=role,
                path_base="IPEDSDB_ROOT",
                base_dir=layout.root,
                relative_path=rel,
                years_spec=years_spec,
                generated_at_utc=generated_at_utc,
                git_meta=git_meta,
                notes=notes,
            )
        )
    for role, rel, notes in expected_repo_artifacts():
        rows.append(
            build_artifact_row(
                role=role,
                path_base="repo",
                base_dir=repo,
                relative_path=rel,
                years_spec=years_spec,
                generated_at_utc=generated_at_utc,
                git_meta=git_meta,
                notes=notes,
            )
        )

    manifest = pd.DataFrame(rows).sort_values(["role", "path_base", "relative_path"], kind="mergesort")
    manifest_csv = out_dir / "release_manifest.csv"
    manifest_json = out_dir / "release_manifest.json"
    manifest.to_csv(manifest_csv, index=False)
    manifest_json.write_text(json.dumps(manifest.to_dict("records"), indent=2), encoding="utf-8")

    present = manifest["present"].astype(bool)
    size_numeric = pd.to_numeric(manifest.loc[present, "size_bytes"], errors="coerce").fillna(0)
    summary = {
        "generated_at_utc": generated_at_utc,
        "years": years_spec,
        "git_commit": git_meta.get("git_commit", ""),
        "git_branch": git_meta.get("git_branch", ""),
        "git_dirty": git_meta.get("git_dirty", ""),
        "artifact_rows": int(len(manifest)),
        "present_artifacts": int(present.sum()),
        "missing_artifacts": int((~present).sum()),
        "total_present_bytes": int(size_numeric.sum()),
        "manifest_csv": rel_or_blank(manifest_csv, layout.root),
        "manifest_json": rel_or_blank(manifest_json, layout.root),
    }
    pd.DataFrame([summary]).to_csv(out_dir / "release_manifest_summary.csv", index=False)
    (out_dir / "release_manifest_summary.md").write_text(render_summary(summary), encoding="utf-8")

    print(f"Wrote release manifest to {manifest_csv}")
    if summary["missing_artifacts"]:
        print(f"[warn] release manifest contains missing artifacts: {summary['missing_artifacts']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
