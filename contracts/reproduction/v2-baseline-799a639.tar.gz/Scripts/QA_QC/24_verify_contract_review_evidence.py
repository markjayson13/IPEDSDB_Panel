#!/usr/bin/env python3
"""Verify the external B03/B04 review evidence against a tracked receipt.

Production verification consumes the exact receipt-bound ZIP and verifies the
whole archive, its manifest, every member, and the approval-grade semantic
invariants.  Direct directory verification remains an explicit developer/test
interface; the production release gate does not expose it.
"""

from __future__ import annotations

import argparse
import contextlib
import csv
import hashlib
import io
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import zipfile
from collections import Counter
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Mapping, Sequence


REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_RECEIPT = (
    REPO_ROOT
    / "contracts"
    / "review_evidence"
    / "B03_B04_EVIDENCE_RECEIPT.json"
)

REQUIRED_ARTIFACTS = (
    "table_grain_enriched.csv",
    "table_key_candidate_details.csv",
    "source_column_enriched.csv",
    "source_column_exceptions.csv",
    "imputation_link_reconciliation.csv",
    "source_column_2023_missing_diagnostics.csv",
)

RECEIPT_FIELDS = {
    "schema_version",
    "contract_id",
    "evidence_set_id",
    "generator_commit",
    "artifact_manifest_sha256",
    "input_manifest_sha256",
    "canonical_hash_comparison_sha256",
    "author_decision_register_sha256",
    "canonical_application_scope_sha256",
    "transitive_review_target_sha256",
    "bundle",
    "artifacts",
    "invariants",
}
ARTIFACT_FIELDS = {"path", "byte_size", "sha256", "row_count"}
BUNDLE_FIELDS = {
    "artifact_manifest_member",
    "artifact_manifest_row_count",
    "artifact_manifest_sha256",
    "byte_size",
    "file_count",
    "member_prefix",
    "sha256",
    "total_uncompressed_bytes",
}
MANIFEST_FIELDS = (
    "path",
    "byte_size",
    "sha256",
    "generator_commit",
    "input_manifest_sha256",
    "canonical_hash_comparison_sha256",
)
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")

PRODUCTION_CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
PRODUCTION_AUTHORITY = {
    "author_decision_register_sha256": (
        "72c12fd2b61f0470bb4cec1aee51c8d342bef12e8c572bea1e3feb538c2ff4a0"
    ),
    "canonical_application_scope_sha256": (
        "bf7cd2c9c58baf9419fd5fbb6ebda6615cc9e8a18aa82670da092dc406b2c882"
    ),
    "transitive_review_target_sha256": (
        "cd4a57a982098747cb2b794b2c5f1a4f4b431fe55cde6ddefa50a3df709b2c3b"
    ),
}
PRODUCTION_LINEAGE = {
    "generator_commit": "248af014509b2b1bafca8c70f9eafbf5a39d4efa",
    "artifact_manifest_sha256": (
        "9839dda1c8ce45e3aa6b372f70d291b263761ffd889ffea7dd610a6427dde6d4"
    ),
    "input_manifest_sha256": (
        "a02ce85a38a64838afac309937b0ff342cf190338d0c51a58ab9bcc9dc6045c4"
    ),
    "canonical_hash_comparison_sha256": (
        "f8b6103b9ad5160e9c6767ea1a115a6463714113de505c8e5a704eb534836ba8"
    ),
}
PRODUCTION_BUNDLE = {
    "artifact_manifest_member": (
        "b03_b04_package_rebaseline_2026-07-24/"
        "B03_B04_artifact_manifest.csv"
    ),
    "artifact_manifest_row_count": 20,
    "artifact_manifest_sha256": (
        "9839dda1c8ce45e3aa6b372f70d291b263761ffd889ffea7dd610a6427dde6d4"
    ),
    "byte_size": 6458992,
    "file_count": 21,
    "member_prefix": "b03_b04_package_rebaseline_2026-07-24/",
    "sha256": (
        "5d21f18bad35e876b0fcbd4fab263c6ad5599706cdb4fb13ac9c9dcfd5068ce0"
    ),
    "total_uncompressed_bytes": 74516311,
}

TABLE_REQUIRED_COLUMNS = {
    "year",
    "access_table_name",
    "candidate_key_test_status",
    "candidate_minimal_key",
    "duplicate_rows_on_candidate_key",
    "null_rows_on_candidate_key",
    "candidate_grain",
    "table_metadata_match_status",
}
KEY_DETAIL_REQUIRED_COLUMNS = {"accepted_as_candidate"}
SOURCE_REQUIRED_COLUMNS = {
    "year",
    "access_table_name",
    "column_name",
    "nonempty_count",
    "column_metadata_match_status",
    "matched_varnumber",
    "matched_varname",
    "matched_metadata_source",
    "metadata_decision_source",
    "candidate_role",
    "role_decision_id",
    "role_decision_source",
    "unresolved_reason",
}
IMPUTATION_REQUIRED_COLUMNS = {
    "flag_column_present",
    "flag_metadata_present",
}


class EvidenceVerificationError(ValueError):
    """Raised when evidence cannot be trusted as the receipt-bound set."""


def _fail(message: str) -> None:
    raise EvidenceVerificationError(message)


def _is_regular_non_symlink(path: Path) -> bool:
    try:
        mode = path.lstat().st_mode
    except OSError:
        return False
    return stat.S_ISREG(mode) and not path.is_symlink()


def _require_regular_non_symlink(path: Path, *, label: str) -> None:
    if not _is_regular_non_symlink(path):
        _fail(f"{label} must be a regular non-symlink file: {path}")


def _require_exact_keys(
    payload: Mapping[str, Any],
    expected: set[str],
    *,
    label: str,
) -> None:
    actual = set(payload)
    if actual != expected:
        missing = sorted(expected - actual)
        extra = sorted(actual - expected)
        _fail(f"{label} fields differ: missing={missing}, extra={extra}")


def _require_sha256(value: Any, *, label: str) -> None:
    if not isinstance(value, str) or not SHA256_RE.fullmatch(value):
        _fail(f"{label} must be a lowercase SHA-256")


def _require_string(value: Any, *, label: str) -> None:
    if not isinstance(value, str) or not value or value != value.strip():
        _fail(f"{label} must be a nonempty trimmed string")


def _validate_identity_proofs(
    value: Any,
    *,
    label: str,
    required_fields: set[str],
) -> None:
    if not isinstance(value, list):
        _fail(f"{label} must be a list")
    identities: set[tuple[str, str, str]] = set()
    for index, row in enumerate(value):
        if not isinstance(row, dict):
            _fail(f"{label}[{index}] must be an object")
        if not required_fields.issubset(row):
            _fail(
                f"{label}[{index}] is missing fields: "
                f"{sorted(required_fields - set(row))}"
            )
        identity = (
            str(row["year"]),
            str(row["access_table_name"]).casefold(),
            str(row["column_name"]).casefold(),
        )
        if identity in identities:
            _fail(f"{label} contains a duplicate identity: {identity}")
        identities.add(identity)
        for field in required_fields:
            if not isinstance(row[field], str):
                _fail(f"{label}[{index}].{field} must be a string")


def _validate_invariants(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        _fail("receipt invariants must be an object")
    required = {
        "accepted_key_candidate_count",
        "allowed_column_metadata_statuses",
        "allowed_table_metadata_statuses",
        "exact_metadata_identity_proofs",
        "imputation_all_flag_columns_absent",
        "imputation_all_metadata_present",
        "reviewed_b02_count",
        "reviewed_b04_alias_count",
        "role_decision_counts",
        "role_decision_identity_proofs",
        "source_exception_count",
        "source_imputation_field_count",
        "source_nonempty_unresolved_count",
        "table_candidate_unvalidated_count",
        "table_proven_complete_count",
        "zero_row_non_scalar_identities",
    }
    _require_exact_keys(value, required, label="receipt invariants")

    for name in (
        "accepted_key_candidate_count",
        "reviewed_b02_count",
        "reviewed_b04_alias_count",
        "source_exception_count",
        "source_imputation_field_count",
        "source_nonempty_unresolved_count",
        "table_candidate_unvalidated_count",
        "table_proven_complete_count",
    ):
        if not isinstance(value[name], int) or value[name] < 0:
            _fail(f"invariant {name} must be a nonnegative integer")
    for name in (
        "imputation_all_flag_columns_absent",
        "imputation_all_metadata_present",
    ):
        if not isinstance(value[name], bool):
            _fail(f"invariant {name} must be boolean")
    for name in (
        "allowed_column_metadata_statuses",
        "allowed_table_metadata_statuses",
    ):
        statuses = value[name]
        if (
            not isinstance(statuses, list)
            or not statuses
            or any(not isinstance(item, str) or not item for item in statuses)
            or len(statuses) != len(set(statuses))
        ):
            _fail(f"invariant {name} must be a unique nonempty string list")
    role_counts = value["role_decision_counts"]
    if (
        not isinstance(role_counts, dict)
        or any(
            not isinstance(key, str)
            or not key
            or not isinstance(count, int)
            or count < 0
            for key, count in role_counts.items()
        )
    ):
        _fail("invariant role_decision_counts is invalid")

    _validate_identity_proofs(
        value["exact_metadata_identity_proofs"],
        label="exact_metadata_identity_proofs",
        required_fields={
            "year",
            "access_table_name",
            "column_name",
            "matched_varnumber",
            "metadata_decision_source",
        },
    )
    _validate_identity_proofs(
        value["role_decision_identity_proofs"],
        label="role_decision_identity_proofs",
        required_fields={
            "year",
            "access_table_name",
            "column_name",
            "candidate_role",
            "role_decision_id",
        },
    )
    zero_rows = value["zero_row_non_scalar_identities"]
    if not isinstance(zero_rows, list) or not zero_rows:
        _fail("zero_row_non_scalar_identities must be a nonempty list")
    seen: set[tuple[str, str]] = set()
    for index, row in enumerate(zero_rows):
        if not isinstance(row, dict) or set(row) != {
            "year",
            "access_table_name",
        }:
            _fail(
                "zero_row_non_scalar_identities entries must contain only "
                "year and access_table_name"
            )
        identity = (str(row["year"]), str(row["access_table_name"]).casefold())
        if not all(identity) or identity in seen:
            _fail(
                "zero_row_non_scalar_identities contains an empty or duplicate "
                f"identity at index {index}"
            )
        seen.add(identity)
    return dict(value)


def _validate_bundle_receipt(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        _fail("receipt bundle must be an object")
    _require_exact_keys(value, BUNDLE_FIELDS, label="receipt bundle")
    for name in ("sha256", "artifact_manifest_sha256"):
        _require_sha256(value[name], label=f"bundle {name}")
    prefix = value["member_prefix"]
    if (
        not isinstance(prefix, str)
        or not prefix
        or not prefix.endswith("/")
        or prefix.startswith("/")
        or "\\" in prefix
        or any(part in {"", ".", ".."} for part in prefix[:-1].split("/"))
    ):
        _fail("bundle member_prefix must be one safe relative directory")
    manifest_member = value["artifact_manifest_member"]
    if (
        not isinstance(manifest_member, str)
        or not manifest_member.startswith(prefix)
        or manifest_member != prefix + "B03_B04_artifact_manifest.csv"
    ):
        _fail("bundle artifact_manifest_member is invalid")
    for name in (
        "byte_size",
        "file_count",
        "total_uncompressed_bytes",
        "artifact_manifest_row_count",
    ):
        if not isinstance(value[name], int) or value[name] <= 0:
            _fail(f"bundle {name} must be a positive integer")
    return dict(value)


def load_and_validate_receipt(path: Path) -> dict[str, Any]:
    """Load a receipt and validate its complete schema without evidence access."""

    _require_regular_non_symlink(path, label="evidence receipt")
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        _fail(f"evidence receipt is not valid UTF-8 JSON: {exc}")
    if not isinstance(payload, dict):
        _fail("evidence receipt root must be an object")
    _require_exact_keys(payload, RECEIPT_FIELDS, label="evidence receipt")
    if payload["schema_version"] != 2:
        _fail("evidence receipt schema_version must equal 2")
    for name in ("contract_id", "evidence_set_id"):
        _require_string(payload[name], label=name)
    if (
        not isinstance(payload["generator_commit"], str)
        or not COMMIT_RE.fullmatch(payload["generator_commit"])
    ):
        _fail("generator_commit must be a lowercase 40-character Git object id")
    for name in (
        "artifact_manifest_sha256",
        "input_manifest_sha256",
        "canonical_hash_comparison_sha256",
        "author_decision_register_sha256",
        "canonical_application_scope_sha256",
        "transitive_review_target_sha256",
    ):
        _require_sha256(payload[name], label=name)

    artifacts = payload["artifacts"]
    if not isinstance(artifacts, list):
        _fail("receipt artifacts must be a list")
    paths: list[str] = []
    for index, row in enumerate(artifacts):
        if not isinstance(row, dict):
            _fail(f"receipt artifact {index} must be an object")
        _require_exact_keys(row, ARTIFACT_FIELDS, label=f"artifact {index}")
        relative = row["path"]
        if (
            not isinstance(relative, str)
            or PurePosixPath(relative).is_absolute()
            or len(PurePosixPath(relative).parts) != 1
            or relative in {"", ".", ".."}
        ):
            _fail("receipt artifact paths must be single relative filenames")
        paths.append(relative)
        _require_sha256(row["sha256"], label=f"artifact {relative} sha256")
        for name in ("byte_size", "row_count"):
            if not isinstance(row[name], int) or row[name] < 0:
                _fail(f"artifact {relative} {name} must be nonnegative integer")
    if paths != list(REQUIRED_ARTIFACTS):
        _fail(
            "receipt artifact paths/order differ from required evidence set: "
            f"actual={paths}, expected={list(REQUIRED_ARTIFACTS)}"
        )
    if len(paths) != len(set(paths)):
        _fail("receipt artifact paths must be unique")
    payload["bundle"] = _validate_bundle_receipt(payload["bundle"])
    payload["invariants"] = _validate_invariants(payload["invariants"])
    if payload["contract_id"] == PRODUCTION_CONTRACT_ID:
        if payload["evidence_set_id"] != "B03_B04_APPROVAL_GRADE_2026-07-24":
            _fail("production evidence_set_id does not match the locked policy")
        for name, expected in {
            **PRODUCTION_AUTHORITY,
            **PRODUCTION_LINEAGE,
        }.items():
            if payload[name] != expected:
                _fail(
                    f"production receipt {name} differs from the locked policy"
                )
        if payload["bundle"] != PRODUCTION_BUNDLE:
            _fail("production receipt bundle differs from the locked policy")
    return payload


def _artifact_path(root: Path, relative: str) -> Path:
    if root.is_symlink() or not root.is_dir():
        _fail(f"evidence root must be a real directory: {root}")
    path = root / relative
    _require_regular_non_symlink(path, label=f"evidence artifact {relative}")
    return path


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _csv_rows(
    path: Path,
    *,
    required_columns: set[str],
) -> Iterable[dict[str, str]]:
    try:
        handle = path.open(newline="", encoding="utf-8")
    except (OSError, UnicodeError) as exc:
        _fail(f"cannot open evidence CSV {path.name}: {exc}")
    with handle:
        reader = csv.DictReader(handle)
        header = list(reader.fieldnames or [])
        if not header:
            _fail(f"evidence CSV has no header: {path.name}")
        if len(header) != len(set(header)):
            _fail(f"evidence CSV has duplicate headers: {path.name}")
        missing = sorted(required_columns - set(header))
        if missing:
            _fail(f"evidence CSV {path.name} is missing columns: {missing}")
        try:
            for row in reader:
                if None in row:
                    _fail(
                        f"evidence CSV {path.name} contains values outside its "
                        "declared header"
                    )
                yield {key: value or "" for key, value in row.items()}
        except (csv.Error, UnicodeError) as exc:
            _fail(f"evidence CSV {path.name} cannot be parsed: {exc}")


def _as_nonnegative_int(value: str, *, label: str) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        _fail(f"{label} must be an integer, got {value!r}")
    if parsed < 0:
        _fail(f"{label} must be nonnegative, got {parsed}")
    return parsed


def _verify_table_evidence(
    path: Path,
    invariants: Mapping[str, Any],
) -> None:
    proven = 0
    unvalidated = 0
    expected_zero = {
        (row["year"], row["access_table_name"].casefold())
        for row in invariants["zero_row_non_scalar_identities"]
    }
    observed_zero: set[tuple[str, str]] = set()
    allowed = set(invariants["allowed_table_metadata_statuses"])
    for row in _csv_rows(path, required_columns=TABLE_REQUIRED_COLUMNS):
        identity = (row["year"], row["access_table_name"].casefold())
        status = row["table_metadata_match_status"]
        if status not in allowed:
            _fail(
                f"table metadata status is not allowed for {identity}: {status!r}"
            )
        key_status = row["candidate_key_test_status"]
        if key_status == "candidate_unvalidated":
            unvalidated += 1
        if key_status == "proven_complete":
            proven += 1
            if row["duplicate_rows_on_candidate_key"] != "0":
                _fail(f"proven table key has duplicate rows: {identity}")
            if row["null_rows_on_candidate_key"] != "0":
                _fail(f"proven table key has null rows: {identity}")
            key = [part for part in row["candidate_minimal_key"].split("|") if part]
            if not key:
                _fail(f"proven table key is empty: {identity}")
            expected_grain = "scalar" if len(key) == 1 else "dimensioned"
            if row["candidate_grain"] != expected_grain:
                _fail(
                    f"proven table grain disagrees with key for {identity}: "
                    f"{row['candidate_grain']!r} != {expected_grain!r}"
                )
        if identity in expected_zero:
            observed_zero.add(identity)
            if row["candidate_grain"] == "scalar":
                _fail(f"zero-row table was mechanically marked scalar: {identity}")
    if proven != invariants["table_proven_complete_count"]:
        _fail(
            "table proven-complete count mismatch: "
            f"{proven} != {invariants['table_proven_complete_count']}"
        )
    if unvalidated != invariants["table_candidate_unvalidated_count"]:
        _fail(
            "table candidate-unvalidated count mismatch: "
            f"{unvalidated} != "
            f"{invariants['table_candidate_unvalidated_count']}"
        )
    missing_zero = sorted(expected_zero - observed_zero)
    if missing_zero:
        _fail(f"zero-row evidence identities are absent: {missing_zero}")


def _verify_key_details(
    path: Path,
    invariants: Mapping[str, Any],
) -> None:
    accepted = sum(
        row["accepted_as_candidate"] == "true"
        for row in _csv_rows(path, required_columns=KEY_DETAIL_REQUIRED_COLUMNS)
    )
    if accepted != invariants["accepted_key_candidate_count"]:
        _fail(
            "accepted key-candidate count mismatch: "
            f"{accepted} != {invariants['accepted_key_candidate_count']}"
        )


def _identity_map(
    proofs: Sequence[Mapping[str, str]],
) -> dict[tuple[str, str, str], Mapping[str, str]]:
    return {
        (
            row["year"],
            row["access_table_name"].casefold(),
            row["column_name"].casefold(),
        ): row
        for row in proofs
    }


def _verify_source_evidence(
    path: Path,
    invariants: Mapping[str, Any],
) -> None:
    reviewed_b02 = 0
    reviewed_b04_alias = 0
    nonempty_unresolved = 0
    imputation_fields = 0
    role_counts: Counter[str] = Counter()
    allowed = set(invariants["allowed_column_metadata_statuses"])
    exact_proofs = _identity_map(invariants["exact_metadata_identity_proofs"])
    role_proofs = _identity_map(invariants["role_decision_identity_proofs"])
    seen_exact: set[tuple[str, str, str]] = set()
    seen_roles: set[tuple[str, str, str]] = set()

    for row in _csv_rows(path, required_columns=SOURCE_REQUIRED_COLUMNS):
        identity = (
            row["year"],
            row["access_table_name"].casefold(),
            row["column_name"].casefold(),
        )
        status = row["column_metadata_match_status"]
        if status not in allowed:
            _fail(
                f"column metadata status is not allowed for {identity}: {status!r}"
            )
        if status.startswith("exact") and row["unresolved_reason"] == "missing_metadata":
            _fail(f"exact metadata row is labeled missing_metadata: {identity}")
        if row["candidate_role"] == "imputation_field":
            imputation_fields += 1
        decision_source = row["metadata_decision_source"]
        if decision_source == "reviewed B02":
            reviewed_b02 += 1
            if status != "exact":
                _fail(f"reviewed B02 row is not exact: {identity}")
        if decision_source == "reviewed B04 alias":
            reviewed_b04_alias += 1
            if status != "exact":
                _fail(f"reviewed B04 alias row is not exact: {identity}")
        if (
            row["candidate_role"] == "unresolved"
            and _as_nonnegative_int(
                row["nonempty_count"],
                label=f"nonempty_count for {identity}",
            )
            > 0
        ):
            nonempty_unresolved += 1

        if row["role_decision_id"]:
            role_counts[row["candidate_role"]] += 1
            if status != "missing":
                _fail(f"reviewed role row fabricated metadata status: {identity}")
            if any(
                row[name]
                for name in (
                    "matched_varnumber",
                    "matched_varname",
                    "matched_metadata_source",
                    "metadata_decision_source",
                )
            ):
                _fail(f"reviewed role row fabricated metadata identity: {identity}")
            if row["role_decision_source"] != "reviewed B04 role":
                _fail(f"reviewed role row has wrong provenance: {identity}")

        exact = exact_proofs.get(identity)
        if exact is not None:
            seen_exact.add(identity)
            if (
                status != "exact"
                or row["matched_varnumber"] != exact["matched_varnumber"]
                or row["metadata_decision_source"]
                != exact["metadata_decision_source"]
            ):
                _fail(f"exact metadata identity proof mismatch: {identity}")

        role = role_proofs.get(identity)
        if role is not None:
            seen_roles.add(identity)
            if (
                row["candidate_role"] != role["candidate_role"]
                or row["role_decision_id"] != role["role_decision_id"]
                or status != "missing"
                or row["unresolved_reason"]
            ):
                _fail(f"reviewed role identity proof mismatch: {identity}")

    expected_role_counts = Counter(invariants["role_decision_counts"])
    if role_counts != expected_role_counts:
        _fail(
            "reviewed role-decision counts mismatch: "
            f"{dict(role_counts)} != {dict(expected_role_counts)}"
        )
    for actual, expected, label in (
        (reviewed_b02, invariants["reviewed_b02_count"], "reviewed B02"),
        (
            reviewed_b04_alias,
            invariants["reviewed_b04_alias_count"],
            "reviewed B04 alias",
        ),
        (
            nonempty_unresolved,
            invariants["source_nonempty_unresolved_count"],
            "nonempty unresolved",
        ),
        (
            imputation_fields,
            invariants["source_imputation_field_count"],
            "source imputation-field",
        ),
    ):
        if actual != expected:
            _fail(f"{label} count mismatch: {actual} != {expected}")
    missing_exact = sorted(set(exact_proofs) - seen_exact)
    if missing_exact:
        _fail(f"exact metadata identity proofs are absent: {missing_exact}")
    missing_roles = sorted(set(role_proofs) - seen_roles)
    if missing_roles:
        _fail(f"reviewed role identity proofs are absent: {missing_roles}")


def _verify_imputation_evidence(
    path: Path,
    invariants: Mapping[str, Any],
) -> None:
    flags_absent = True
    metadata_present = True
    for row in _csv_rows(path, required_columns=IMPUTATION_REQUIRED_COLUMNS):
        flags_absent = flags_absent and row["flag_column_present"] == "false"
        metadata_present = (
            metadata_present and row["flag_metadata_present"] == "true"
        )
    if flags_absent != invariants["imputation_all_flag_columns_absent"]:
        _fail(
            "imputation flag-column absence invariant mismatch: "
            f"{flags_absent} != "
            f"{invariants['imputation_all_flag_columns_absent']}"
        )
    if metadata_present != invariants["imputation_all_metadata_present"]:
        _fail(
            "imputation metadata-presence invariant mismatch: "
            f"{metadata_present} != "
            f"{invariants['imputation_all_metadata_present']}"
        )


def _count_csv_rows(path: Path) -> int:
    return sum(1 for _ in _csv_rows(path, required_columns=set()))


def verify_evidence(evidence_root: Path, receipt_path: Path) -> dict[str, Any]:
    """Verify byte identities, CSV inventories, and semantic invariants."""

    receipt = load_and_validate_receipt(receipt_path)
    evidence_root = evidence_root.absolute()
    paths: dict[str, Path] = {}
    for record in receipt["artifacts"]:
        relative = record["path"]
        path = _artifact_path(evidence_root, relative)
        paths[relative] = path
        actual_size = path.stat().st_size
        if actual_size != record["byte_size"]:
            _fail(
                f"artifact byte-size mismatch for {relative}: "
                f"{actual_size} != {record['byte_size']}"
            )
        actual_hash = _sha256_file(path)
        if actual_hash != record["sha256"]:
            _fail(
                f"artifact hash mismatch for {relative}: "
                f"{actual_hash} != {record['sha256']}"
            )
        actual_rows = _count_csv_rows(path)
        if actual_rows != record["row_count"]:
            _fail(
                f"artifact row-count mismatch for {relative}: "
                f"{actual_rows} != {record['row_count']}"
            )

    invariants = receipt["invariants"]
    _verify_table_evidence(paths["table_grain_enriched.csv"], invariants)
    _verify_key_details(paths["table_key_candidate_details.csv"], invariants)
    _verify_source_evidence(paths["source_column_enriched.csv"], invariants)
    exception_count = _count_csv_rows(paths["source_column_exceptions.csv"])
    if exception_count != invariants["source_exception_count"]:
        _fail(
            "source exception count mismatch: "
            f"{exception_count} != {invariants['source_exception_count']}"
        )
    _verify_imputation_evidence(
        paths["imputation_link_reconciliation.csv"],
        invariants,
    )

    return {
        "artifact_count": len(paths),
        "contract_id": receipt["contract_id"],
        "evidence_set_id": receipt["evidence_set_id"],
        "status": "verified",
        "transitive_review_target_sha256": (
            receipt["transitive_review_target_sha256"]
        ),
    }


@contextlib.contextmanager
def _open_bundle_once(path: Path):
    """Open, fstat, hash, and parse one immutable file descriptor."""

    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        _fail(f"cannot open evidence bundle without following symlinks: {exc}")
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode):
            _fail(f"evidence bundle must be a regular file: {path}")
        with os.fdopen(descriptor, "rb", closefd=False) as handle:
            digest = hashlib.sha256()
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
            handle.seek(0)
            yield handle, metadata.st_size, digest.hexdigest()
    finally:
        os.close(descriptor)


def _validate_zip_name(name: str) -> PurePosixPath:
    if (
        not name
        or "\\" in name
        or name.startswith("/")
        or re.match(r"^[A-Za-z]:", name)
    ):
        _fail(f"unsafe ZIP member name: {name!r}")
    relative = PurePosixPath(name)
    if relative.is_absolute() or any(
        part in {"", ".", ".."} for part in relative.parts
    ):
        _fail(f"unsafe ZIP member name: {name!r}")
    return relative


def _zip_member_sha256(archive: zipfile.ZipFile, info: zipfile.ZipInfo) -> str:
    digest = hashlib.sha256()
    with archive.open(info, "r") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_artifact_manifest(
    archive: zipfile.ZipFile,
    info: zipfile.ZipInfo,
) -> list[dict[str, str]]:
    try:
        with archive.open(info, "r") as raw:
            with io.TextIOWrapper(raw, encoding="utf-8", newline="") as text:
                reader = csv.DictReader(text, strict=True)
                if tuple(reader.fieldnames or ()) != MANIFEST_FIELDS:
                    _fail(
                        "artifact manifest header differs from the exact "
                        f"schema: {reader.fieldnames}"
                    )
                rows = list(reader)
    except (UnicodeError, csv.Error, OSError) as exc:
        _fail(f"artifact manifest cannot be parsed: {exc}")
    for row in rows:
        if None in row:
            _fail("artifact manifest contains values outside its header")
    return rows


def _validate_bundle_members(
    archive: zipfile.ZipFile,
    receipt: Mapping[str, Any],
) -> tuple[dict[str, zipfile.ZipInfo], list[dict[str, str]]]:
    bundle = receipt["bundle"]
    infos = archive.infolist()
    names = [info.filename for info in infos]
    duplicates = sorted(
        name for name, count in Counter(names).items() if count > 1
    )
    if duplicates:
        _fail(f"evidence ZIP contains duplicate member names: {duplicates}")
    if len(infos) > 64:
        _fail("evidence ZIP exceeds the 64-entry safety cap")

    prefix = bundle["member_prefix"]
    file_infos: dict[str, zipfile.ZipInfo] = {}
    directory_names: list[str] = []
    for info in infos:
        _validate_zip_name(info.filename.rstrip("/"))
        if info.flag_bits & 0x1:
            _fail(f"encrypted ZIP member is not allowed: {info.filename}")
        if info.compress_type not in {
            zipfile.ZIP_STORED,
            zipfile.ZIP_DEFLATED,
        }:
            _fail(
                f"unsupported ZIP compression method for {info.filename}: "
                f"{info.compress_type}"
            )
        unix_mode = (info.external_attr >> 16) & 0xFFFF
        file_type = stat.S_IFMT(unix_mode)
        if file_type == stat.S_IFLNK:
            _fail(f"symlink ZIP member is not allowed: {info.filename}")
        if info.is_dir():
            directory_names.append(info.filename)
            continue
        if not info.filename.startswith(prefix):
            _fail(
                f"ZIP member is outside the required prefix {prefix!r}: "
                f"{info.filename}"
            )
        suffix = info.filename[len(prefix) :]
        if "/" in suffix or not suffix:
            _fail(f"ZIP member nesting is not allowed: {info.filename}")
        if info.file_size > 80 * 1024 * 1024:
            _fail(f"ZIP member exceeds the 80 MiB safety cap: {info.filename}")
        file_infos[info.filename] = info
    if directory_names != [prefix]:
        _fail(
            "evidence ZIP must contain exactly its declared directory entry: "
            f"{directory_names}"
        )
    if len(file_infos) != bundle["file_count"]:
        _fail(
            "evidence ZIP file-count mismatch: "
            f"{len(file_infos)} != {bundle['file_count']}"
        )
    total_uncompressed = sum(info.file_size for info in file_infos.values())
    if total_uncompressed != bundle["total_uncompressed_bytes"]:
        _fail(
            "evidence ZIP uncompressed-size mismatch: "
            f"{total_uncompressed} != {bundle['total_uncompressed_bytes']}"
        )
    if total_uncompressed > 128 * 1024 * 1024:
        _fail("evidence ZIP exceeds the 128 MiB uncompressed safety cap")

    manifest_member = bundle["artifact_manifest_member"]
    manifest_info = file_infos.get(manifest_member)
    if manifest_info is None:
        _fail(f"evidence ZIP is missing its artifact manifest: {manifest_member}")
    manifest_hash = _zip_member_sha256(archive, manifest_info)
    if (
        manifest_hash != bundle["artifact_manifest_sha256"]
        or manifest_hash != receipt["artifact_manifest_sha256"]
    ):
        _fail("artifact manifest hash differs from the tracked receipt")
    rows = _read_artifact_manifest(archive, manifest_info)
    if len(rows) != bundle["artifact_manifest_row_count"]:
        _fail(
            "artifact manifest row-count mismatch: "
            f"{len(rows)} != {bundle['artifact_manifest_row_count']}"
        )
    return file_infos, rows


def _verify_manifest_members(
    archive: zipfile.ZipFile,
    file_infos: Mapping[str, zipfile.ZipInfo],
    manifest_rows: Sequence[Mapping[str, str]],
    receipt: Mapping[str, Any],
) -> dict[str, Mapping[str, str]]:
    prefix = receipt["bundle"]["member_prefix"]
    manifest_member = receipt["bundle"]["artifact_manifest_member"]
    manifest_prefix = "Artifacts/review_v2/" + prefix
    by_basename: dict[str, Mapping[str, str]] = {}
    expected_zip_members = {manifest_member}
    for index, row in enumerate(manifest_rows):
        raw_path = row.get("path", "")
        if not raw_path.startswith(manifest_prefix):
            _fail(
                f"artifact manifest row {index} is outside its exact prefix: "
                f"{raw_path!r}"
            )
        basename = raw_path[len(manifest_prefix) :]
        if (
            not basename
            or "/" in basename
            or "\\" in basename
            or basename in by_basename
        ):
            _fail(
                "artifact manifest contains an unsafe or duplicate basename: "
                f"{basename!r}"
            )
        zip_name = prefix + basename
        expected_zip_members.add(zip_name)
        info = file_infos.get(zip_name)
        if info is None:
            _fail(f"artifact manifest member is absent from ZIP: {zip_name}")
        try:
            expected_size = int(row.get("byte_size", ""))
        except ValueError:
            _fail(
                f"artifact manifest byte_size is invalid for {basename}: "
                f"{row.get('byte_size')!r}"
            )
        if expected_size != info.file_size:
            _fail(
                f"artifact manifest byte-size mismatch for {basename}: "
                f"{info.file_size} != {expected_size}"
            )
        expected_hash = row.get("sha256", "")
        _require_sha256(expected_hash, label=f"manifest {basename} sha256")
        actual_hash = _zip_member_sha256(archive, info)
        if actual_hash != expected_hash:
            _fail(
                f"artifact manifest hash mismatch for {basename}: "
                f"{actual_hash} != {expected_hash}"
            )
        for field in (
            "generator_commit",
            "input_manifest_sha256",
            "canonical_hash_comparison_sha256",
        ):
            if row.get(field) != receipt[field]:
                _fail(
                    f"artifact manifest {field} mismatch for {basename}"
                )
        by_basename[basename] = row
    if set(file_infos) != expected_zip_members:
        missing = sorted(expected_zip_members - set(file_infos))
        extra = sorted(set(file_infos) - expected_zip_members)
        _fail(
            f"artifact manifest/ZIP member set mismatch: "
            f"missing={missing}, extra={extra}"
        )

    for record in receipt["artifacts"]:
        manifest_row = by_basename.get(record["path"])
        if manifest_row is None:
            _fail(
                f"receipt core artifact is absent from manifest: "
                f"{record['path']}"
            )
        if (
            int(manifest_row["byte_size"]) != record["byte_size"]
            or manifest_row["sha256"] != record["sha256"]
        ):
            _fail(
                f"receipt core artifact differs from manifest: "
                f"{record['path']}"
            )
    return by_basename


def verify_evidence_bundle(
    bundle_path: Path,
    receipt_path: Path = DEFAULT_RECEIPT,
) -> dict[str, Any]:
    """Verify the authoritative ZIP, every member, and core semantics."""

    receipt = load_and_validate_receipt(receipt_path)
    bundle_path = bundle_path.expanduser().absolute()
    with _open_bundle_once(bundle_path) as (
        bundle_handle,
        bundle_size,
        bundle_hash,
    ):
        expected = receipt["bundle"]
        if bundle_size != expected["byte_size"]:
            _fail(
                "evidence bundle byte-size mismatch: "
                f"{bundle_size} != {expected['byte_size']}"
            )
        if bundle_hash != expected["sha256"]:
            _fail(
                "evidence bundle hash mismatch: "
                f"{bundle_hash} != {expected['sha256']}"
            )
        try:
            with zipfile.ZipFile(bundle_handle, "r") as archive:
                file_infos, manifest_rows = _validate_bundle_members(
                    archive,
                    receipt,
                )
                _verify_manifest_members(
                    archive,
                    file_infos,
                    manifest_rows,
                    receipt,
                )
                with tempfile.TemporaryDirectory(
                    prefix="ipedsdb-b03-b04-evidence-"
                ) as temporary:
                    evidence_root = Path(temporary)
                    prefix = receipt["bundle"]["member_prefix"]
                    for record in receipt["artifacts"]:
                        info = file_infos[prefix + record["path"]]
                        destination = evidence_root / record["path"]
                        with archive.open(info, "r") as source:
                            with destination.open("wb") as output:
                                shutil.copyfileobj(
                                    source,
                                    output,
                                    length=1024 * 1024,
                                )
                    result = verify_evidence(evidence_root, receipt_path)
        except (zipfile.BadZipFile, zipfile.LargeZipFile) as exc:
            _fail(f"evidence bundle is not a valid bounded ZIP: {exc}")
    return {
        **result,
        "bundle_sha256": bundle_hash,
        "manifest_row_count": len(manifest_rows),
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--evidence-bundle",
        type=Path,
        help="Receipt-bound authoritative B03/B04 evidence ZIP.",
    )
    source.add_argument(
        "--evidence-root",
        type=Path,
        help="Developer/test-only directory containing the six core CSVs.",
    )
    parser.add_argument(
        "--receipt",
        type=Path,
        default=DEFAULT_RECEIPT,
        help="Tracked B03/B04 evidence receipt.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.evidence_bundle is not None:
            result = verify_evidence_bundle(
                args.evidence_bundle,
                args.receipt,
            )
        else:
            result = verify_evidence(args.evidence_root, args.receipt)
    except EvidenceVerificationError as exc:
        print(
            f"B03_B04_EVIDENCE_VERIFICATION_FAILED: {exc}",
            file=sys.stderr,
        )
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
