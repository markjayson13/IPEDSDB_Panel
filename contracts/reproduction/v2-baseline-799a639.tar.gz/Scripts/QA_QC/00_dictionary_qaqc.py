#!/usr/bin/env python3
"""
QA 00: audit the stitched metadata dictionaries for consistency and coverage.

Reads:
- `Dictionary/v2/dictionary_lake.parquet`
- `Dictionary/v2/dictionary_codes.parquet`
- `Checks/extract_qc/table_inventory_all_years.csv` when present

Writes:
- `Checks/dictionary_qc/*`

Focus:
- duplicate dictionary rows
- source-file conflicts
- unmapped metadata tables
- missing-description rates
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import pandas as pd

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import CANONICAL_SOURCE_FILES, DEFAULT_IPEDSDB_ROOT, source_file_qaqc_category


def parse_args() -> argparse.Namespace:
    default_root = DEFAULT_IPEDSDB_ROOT
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=str(default_root), help="External IPEDSDB_ROOT")
    return ap.parse_args()


def years_text(series: pd.Series) -> str:
    vals = sorted({str(int(v)) for v in series.dropna().tolist()})
    return "'" + "|".join(vals) if vals else ""


def normalize_varnumber(value: object) -> str:
    txt = str(value or "").strip()
    if txt.lower() in {"", "nan", "none", "<na>", "na", "nat"}:
        return ""
    return txt.zfill(8) if txt.isdigit() else txt


def find_code_label_conflicts(codes: pd.DataFrame) -> pd.DataFrame:
    key_cols = [
        "year",
        "source_file",
        "access_table_name",
        "varnumber",
        "varname",
        "codevalue",
        "label_scope",
    ]
    output_cols = key_cols + ["n_distinct_labels", "candidate_labels", "metadata_tables"]
    if codes.empty:
        return pd.DataFrame(columns=output_cols)
    df = codes.copy()
    for col in key_cols + ["valuelabel", "metadata_table_name"]:
        if col not in df.columns:
            df[col] = ""
    df["varnumber"] = df["varnumber"].map(normalize_varnumber)
    for col in ("source_file", "access_table_name", "varname", "codevalue", "label_scope", "valuelabel"):
        df[col] = df[col].fillna("").astype(str).str.strip()
    df["source_file"] = df["source_file"].str.upper()
    df["varname"] = df["varname"].str.upper()
    rows: list[dict[str, object]] = []
    for key, group in df.groupby(key_cols, dropna=False, sort=True):
        labels = sorted(set(label for label in group["valuelabel"] if label))
        if len(labels) <= 1:
            continue
        row = dict(zip(key_cols, key, strict=True))
        row.update(
            {
                "n_distinct_labels": len(labels),
                "candidate_labels": "|".join(labels),
                "metadata_tables": "|".join(sorted(set(group["metadata_table_name"].astype(str)))),
            }
        )
        rows.append(row)
    return pd.DataFrame(rows, columns=output_cols)


def find_description_conflicts(lake: pd.DataFrame) -> pd.DataFrame:
    key_cols = ["year", "source_file", "access_table_name", "source_varnumber", "varname"]
    output_cols = key_cols + ["n_distinct_descriptions", "candidate_descriptions"]
    if lake.empty or "longDescription" not in lake.columns:
        return pd.DataFrame(columns=output_cols)
    df = lake.copy()
    for col in key_cols:
        if col not in df.columns:
            df[col] = ""
    df["longDescription"] = df["longDescription"].fillna("").astype(str).str.strip()
    rows: list[dict[str, object]] = []
    for key, group in df.groupby(key_cols, dropna=False, sort=True):
        values = sorted(set(value for value in group["longDescription"] if value))
        if len(values) <= 1:
            continue
        row = dict(zip(key_cols, key, strict=True))
        row.update(
            {
                "n_distinct_descriptions": len(values),
                "candidate_descriptions": "|".join(values),
            }
        )
        rows.append(row)
    return pd.DataFrame(rows, columns=output_cols)


def find_dictionary_identity_issues(lake: pd.DataFrame) -> pd.DataFrame:
    issue_columns = ["row_index", "year", "source_file", "varname", "metadata_source", "issue_type", "detail"]
    if lake.empty:
        return pd.DataFrame(columns=issue_columns)
    df = lake.copy()
    for col in (
        "year",
        "source_file",
        "varname",
        "metadata_source",
        "variable_id",
        "source_varnumber",
        "variable_origin",
        "is_synthetic",
        "source_metadata_year",
    ):
        if col not in df.columns:
            df[col] = ""
    rows: list[dict[str, object]] = []
    for idx, row in df.iterrows():
        base = {
            "row_index": idx,
            "year": row.get("year", ""),
            "source_file": row.get("source_file", ""),
            "varname": row.get("varname", ""),
            "metadata_source": row.get("metadata_source", ""),
        }
        variable_id_raw = row.get("variable_id", "")
        metadata_source_raw = row.get("metadata_source", "")
        variable_id = "" if pd.isna(variable_id_raw) else str(variable_id_raw).strip()
        metadata_source = "" if pd.isna(metadata_source_raw) else str(metadata_source_raw).strip()
        source_number_raw = row.get("source_varnumber", "")
        source_number = "" if pd.isna(source_number_raw) else str(source_number_raw).strip()
        synthetic = metadata_source.startswith("synthetic_")
        source_derived_backfill = metadata_source.startswith("synthetic_backfill_")
        generated_synthetic = synthetic and not source_derived_backfill
        if not variable_id:
            rows.append({**base, "issue_type": "missing_variable_id", "detail": "variable_id is blank"})
        elif generated_synthetic and not variable_id.startswith("synthetic:"):
            rows.append(
                {**base, "issue_type": "synthetic_id_not_namespaced", "detail": f"variable_id={variable_id}"}
            )
        elif (not synthetic or source_derived_backfill) and not variable_id.startswith("nces:"):
            rows.append({**base, "issue_type": "source_id_not_namespaced", "detail": f"variable_id={variable_id}"})
        if generated_synthetic and source_number:
            rows.append(
                {
                    **base,
                    "issue_type": "synthetic_has_source_varnumber",
                    "detail": f"source_varnumber={source_number}",
                }
            )
        if (not synthetic or source_derived_backfill) and not source_number:
            rows.append(
                {**base, "issue_type": "source_row_missing_varnumber", "detail": "source_varnumber is blank"}
            )
        if metadata_source.startswith("synthetic_backfill_"):
            for field in ("backfill_donor_year", "backfill_approval_id", "backfill_justification"):
                value = row.get(field, "")
                if pd.isna(value) or not str(value).strip():
                    rows.append(
                        {**base, "issue_type": "backfill_trace_missing", "detail": f"missing {field}"}
                    )
        expected_origin = (
            "backfill"
            if source_derived_backfill
            else "synthetic_imputation"
            if metadata_source.startswith("synthetic_imputation")
            else "synthetic_unitid"
            if metadata_source.startswith("synthetic_unitid")
            else "nces"
        )
        if str(row.get("variable_origin", "")).strip() != expected_origin:
            rows.append(
                {
                    **base,
                    "issue_type": "variable_origin_mismatch",
                    "detail": f"expected={expected_origin} observed={row.get('variable_origin', '')}",
                }
            )
        expected_synthetic = synthetic
        observed_synthetic = str(row.get("is_synthetic", "")).strip().lower() in {"true", "1"}
        if observed_synthetic != expected_synthetic:
            rows.append(
                {
                    **base,
                    "issue_type": "synthetic_flag_mismatch",
                    "detail": f"expected={expected_synthetic} observed={row.get('is_synthetic', '')}",
                }
            )
        source_metadata_year = row.get("source_metadata_year", "")
        if not generated_synthetic and (pd.isna(source_metadata_year) or not str(source_metadata_year).strip()):
            rows.append(
                {**base, "issue_type": "missing_source_metadata_year", "detail": "source_metadata_year is blank"}
            )
    return pd.DataFrame(rows, columns=issue_columns)


def main() -> None:
    args = parse_args()
    root = Path(args.root)
    checks_dir = root / "Checks" / "dictionary_qc"
    checks_dir.mkdir(parents=True, exist_ok=True)

    lake_path = root / "Dictionary" / "v2" / "dictionary_lake.parquet"
    codes_path = root / "Dictionary" / "v2" / "dictionary_codes.parquet"
    inventory_all_path = root / "Checks" / "extract_qc" / "table_inventory_all_years.csv"
    candidate_path = checks_dir / "dictionary_metadata_candidates.csv"

    if not lake_path.exists():
        raise SystemExit(f"Missing dictionary lake: {lake_path}")
    lake = pd.read_parquet(lake_path)
    for col in (
        "year",
        "source_file",
        "varnumber",
        "varname",
        "longDescription",
        "metadata_source",
        "access_table_name",
    ):
        if col not in lake.columns:
            lake[col] = ""
    lake["varnumber"] = lake["varnumber"].map(normalize_varnumber)
    lake["source_file"] = lake["source_file"].fillna("").astype(str).str.strip()
    lake["varname"] = lake["varname"].fillna("").astype(str).str.upper().str.strip()
    lake["access_table_name"] = lake["access_table_name"].fillna("").astype(str).str.strip()

    identity_issues = find_dictionary_identity_issues(lake)
    identity_issues.to_csv(checks_dir / "dictionary_identity_issues.csv", index=False)

    description_conflict_path = checks_dir / "metadata_description_conflicts.csv"
    if description_conflict_path.exists():
        description_conflicts = pd.read_csv(description_conflict_path, dtype=str).fillna("")
    else:
        description_conflicts = find_description_conflicts(lake)
        description_conflicts.to_csv(description_conflict_path, index=False)

    if codes_path.exists():
        codes = pd.read_parquet(codes_path)
    else:
        codes = pd.DataFrame()
    all_code_conflict_path = checks_dir / "metadata_code_label_conflicts.csv"
    release_code_conflict_path = checks_dir / "metadata_code_label_conflicts_release.csv"
    if release_code_conflict_path.exists():
        code_label_conflicts = pd.read_csv(release_code_conflict_path, dtype=str).fillna("")
    elif all_code_conflict_path.exists():
        all_code_conflicts = pd.read_csv(all_code_conflict_path, dtype=str).fillna("")
        if "observed_in_source_data" in all_code_conflicts.columns:
            code_label_conflicts = all_code_conflicts[
                all_code_conflicts["observed_in_source_data"].astype(str).str.lower().isin({"true", "1"})
            ].copy()
        else:
            code_label_conflicts = all_code_conflicts
    else:
        code_label_conflicts = find_code_label_conflicts(codes)
        code_label_conflicts.to_csv(all_code_conflict_path, index=False)
    code_label_conflicts.to_csv(release_code_conflict_path, index=False)

    varlist_conflict_path = checks_dir / "metadata_varlist_conflicts.csv"
    varlist_conflicts = (
        pd.read_csv(varlist_conflict_path, dtype=str).fillna("")
        if varlist_conflict_path.exists()
        else pd.DataFrame()
    )

    duplicates = lake.groupby(["year", "source_file", "varnumber", "varname"]).size().reset_index(name="n_rows")
    duplicates = duplicates[duplicates["n_rows"] > 1].copy()
    duplicates.to_csv(checks_dir / "dictionary_duplicates.csv", index=False)

    source_conflicts = (
        lake[lake["access_table_name"] != ""]
        .groupby(["year", "access_table_name"])["source_file"]
        .agg(lambda s: sorted(set(x for x in s if x)))
        .reset_index(name="source_files")
    )
    source_conflicts["n_source_files"] = source_conflicts["source_files"].str.len()
    source_conflicts = source_conflicts[source_conflicts["n_source_files"] > 1].copy()
    source_conflicts["source_files"] = source_conflicts["source_files"].map("|".join)
    source_conflicts.to_csv(checks_dir / "source_file_conflicts.csv", index=False)

    missing_desc = (
        lake.groupby(["year", "source_file"], as_index=False)
        .agg(
            rows=("varname", "size"),
            missing_long_description=("longDescription", lambda s: int((s.fillna("").astype(str).str.strip() == "").sum())),
        )
    )
    missing_desc["missing_long_description_rate"] = missing_desc["missing_long_description"] / missing_desc["rows"]
    missing_desc.to_csv(checks_dir / "missing_descriptions_by_source_year.csv", index=False)

    source_years = (
        lake.groupby("source_file", as_index=False)
        .agg(
            years=("year", years_text),
            rows=("varname", "size"),
        )
        .sort_values("source_file")
    )
    source_years.to_csv(checks_dir / "source_file_years.csv", index=False)

    collisions = (
        lake.groupby(["year", "source_file", "varnumber"])["varname"]
        .agg(lambda s: sorted(set(v for v in s if v)))
        .reset_index(name="varnames")
    )
    collisions["n_varnames"] = collisions["varnames"].str.len()
    collisions = collisions[collisions["n_varnames"] > 1].copy()
    collisions["varnames"] = collisions["varnames"].map("|".join)
    collisions.to_csv(checks_dir / "varnumber_varname_collisions.csv", index=False)

    noncanonical_rows = lake[~lake["source_file"].isin(CANONICAL_SOURCE_FILES)].copy()
    noncanonical_rows["source_category"] = noncanonical_rows["source_file"].map(source_file_qaqc_category)
    noncanonical_rows.to_csv(checks_dir / "noncanonical_metadata_tables.csv", index=False)

    unmapped_rows = noncanonical_rows[noncanonical_rows["source_category"].isin({"actionable_canonical_gap", "needs_review"})].copy()
    unmapped_rows.to_csv(checks_dir / "unmapped_metadata_tables.csv", index=False)

    auxiliary_rows = noncanonical_rows[noncanonical_rows["source_category"] == "auxiliary_expected"].copy()
    auxiliary_rows.to_csv(checks_dir / "auxiliary_expected_metadata_tables.csv", index=False)

    derived_rows = noncanonical_rows[noncanonical_rows["source_category"] == "derived_or_custom"].copy()
    derived_rows.to_csv(checks_dir / "derived_or_custom_metadata_tables.csv", index=False)

    category_counts = (
        noncanonical_rows.groupby("source_category", as_index=False)
        .agg(rows=("varname", "size"), source_files=("source_file", "nunique"))
        .sort_values(["rows", "source_category"], ascending=[False, True])
    )
    category_counts.to_csv(checks_dir / "noncanonical_source_categories.csv", index=False)

    if inventory_all_path.exists():
        inventory_all = pd.read_csv(inventory_all_path, dtype=str).fillna("")
        inventory_all["normalized_table_name"] = inventory_all["normalized_table_name"].fillna("").astype(str)
        metadata_inventory = inventory_all[inventory_all["table_role"].str.startswith("metadata")].copy()
        inventory_unmapped = metadata_inventory[~metadata_inventory["normalized_table_name"].isin(CANONICAL_SOURCE_FILES)].copy()
        inventory_unmapped["source_category"] = inventory_unmapped["normalized_table_name"].map(source_file_qaqc_category)
        inventory_unmapped.to_csv(checks_dir / "noncanonical_inventory_metadata_tables.csv", index=False)
        inventory_unmapped = inventory_unmapped[
            inventory_unmapped["source_category"].isin({"actionable_canonical_gap", "needs_review"})
        ].copy()
        inventory_unmapped.to_csv(checks_dir / "unmapped_inventory_metadata_tables.csv", index=False)

    if candidate_path.exists():
        candidate_df = pd.read_csv(candidate_path, dtype=str).fillna("")
        candidate_df.to_csv(checks_dir / "dictionary_metadata_candidates_snapshot.csv", index=False)

    summary_rows = [
        {
            "lake_rows": len(lake),
            "lake_source_files": lake["source_file"].replace("", pd.NA).nunique(dropna=True),
            "duplicate_rows": len(duplicates),
            "source_file_conflicts": len(source_conflicts),
            "varnumber_collisions": len(collisions),
            "noncanonical_rows_total": len(noncanonical_rows),
            "unmapped_rows": len(unmapped_rows),
            "auxiliary_expected_rows": len(auxiliary_rows),
            "derived_or_custom_rows": len(derived_rows),
            "needs_review_rows": int((noncanonical_rows["source_category"] == "needs_review").sum()),
            "description_conflicts": len(description_conflicts),
            "code_label_conflicts": len(code_label_conflicts),
            "identity_issues": len(identity_issues),
            "varlist_conflicts": len(varlist_conflicts),
            "integrity_failures": (
                len(varlist_conflicts) + len(description_conflicts) + len(code_label_conflicts) + len(identity_issues)
            ),
        }
    ]
    if codes_path.exists():
        summary_rows[0]["code_rows"] = len(codes)
    pd.DataFrame(summary_rows).to_csv(checks_dir / "dictionary_qaqc_summary.csv", index=False)
    print(f"Wrote dictionary QA/QC to {checks_dir}")
    if summary_rows[0]["integrity_failures"]:
        raise SystemExit(
            "Dictionary QA/QC found dictionary integrity failures: "
            f"varlist={len(varlist_conflicts)} descriptions={len(description_conflicts)} "
            f"code_labels={len(code_label_conflicts)} "
            f"identity={len(identity_issues)}"
        )


if __name__ == "__main__":
    main()
