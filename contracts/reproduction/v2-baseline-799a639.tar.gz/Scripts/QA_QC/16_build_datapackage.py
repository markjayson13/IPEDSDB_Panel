#!/usr/bin/env python3
"""
QA 16: build Frictionless-style Data Package metadata for a release.

Reads:
- `Checks/v2/release_manifest/release_manifest.csv`
- present CSV and parquet artifacts listed in the manifest

Writes:
- `Checks/v2/release_metadata/datapackage.json`
"""
from __future__ import annotations

import argparse
import os
import sys
import tomllib
from pathlib import Path

import pandas as pd
import pyarrow.parquet as pq

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import (
    DEFAULT_IPEDSDB_ROOT,
    atomic_write_json,
    compute_file_metadata,
    data_layout,
    parse_years,
    repo_root,
)


def parse_args() -> argparse.Namespace:
    root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default=str(root), help="External IPEDSDB_ROOT")
    p.add_argument("--years", default="2004:2023")
    p.add_argument("--manifest", default=None)
    p.add_argument("--verification", default=None)
    p.add_argument("--out", default=None)
    p.add_argument("--repo-root", default=str(repo_root()))
    p.add_argument("--require-verified-manifest", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--name", default="ipedsdb_panel")
    p.add_argument("--title", default="IPEDSDB_Panel")
    p.add_argument("--version", default="", help="Must match contracts/panel_spec.toml; defaults to contract_id.")
    p.add_argument("--homepage", default="https://github.com/markjayson13/IPEDSDB_Panel")
    return p.parse_args()


def boolish(value: object) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "y"}


def resource_name(relative_path: str) -> str:
    return (
        relative_path.lower()
        .replace("/", "_")
        .replace("-", "_")
        .replace(".", "_")
        .replace(" ", "_")
    )


def resolve_path(row: pd.Series, root: Path, repo: Path) -> Path:
    base = str(row.get("path_base", "")).strip()
    rel = str(row.get("relative_path", "")).strip()
    if base == "IPEDSDB_ROOT":
        return root / rel
    if base == "repo":
        return repo / rel
    absolute = str(row.get("absolute_path", "")).strip()
    return Path(absolute) if absolute else Path(rel)


def parquet_fields(path: Path) -> list[dict[str, str]]:
    fields = []
    schema = pq.ParquetFile(path).schema_arrow
    for field in schema:
        fields.append({"name": field.name, "type": str(field.type)})
    return fields


def csv_fields(path: Path) -> list[dict[str, str]]:
    try:
        columns = list(pd.read_csv(path, nrows=0).columns)
    except Exception:
        return []
    return [{"name": str(col), "type": "string"} for col in columns]


def fields_for(path: Path) -> list[dict[str, str]]:
    suffix = path.suffix.lower()
    if suffix == ".parquet":
        return parquet_fields(path)
    if suffix == ".csv":
        return csv_fields(path)
    return []


def primary_key(relative_path: str, fields: list[dict[str, str]]) -> list[str]:
    names = {field["name"] for field in fields}
    if relative_path.startswith("Panels/") and {"UNITID", "year"}.issubset(names):
        return ["UNITID", "year"]
    if "release_manifest.csv" in relative_path and "artifact_id" in names:
        return ["artifact_id"]
    return []


def contract_id(repo: Path) -> str:
    path = repo / "contracts" / "panel_spec.toml"
    if not path.is_file():
        raise SystemExit(f"Panel contract does not exist: {path}")
    with path.open("rb") as handle:
        value = str(tomllib.load(handle).get("contract_id", "")).strip()
    if not value:
        raise SystemExit("Panel contract lacks contract_id.")
    return value


def require_manifest_verification(manifest_path: Path, verification_path: Path) -> None:
    if not verification_path.is_file():
        raise SystemExit(f"Release-manifest verification does not exist: {verification_path}")
    verification = pd.read_csv(verification_path, dtype=str).fillna("")
    required = {"passed", "verified_manifest_sha256"}
    missing = required - set(verification.columns)
    if missing:
        raise SystemExit(f"Release-manifest verification missing columns: {', '.join(sorted(missing))}")
    if verification.empty or not verification["passed"].map(boolish).all():
        raise SystemExit("Release-manifest verification is empty or contains failing rows.")
    hashes = {value.strip() for value in verification["verified_manifest_sha256"] if value.strip()}
    _, actual_hash = compute_file_metadata(manifest_path)
    if hashes != {actual_hash}:
        raise SystemExit("Release-manifest verification is not bound to the exact manifest bytes.")


def main() -> int:
    args = parse_args()
    root = Path(args.root).expanduser()
    repo = Path(args.repo_root).expanduser()
    layout = data_layout(root)
    years = parse_years(args.years)
    manifest_path = Path(args.manifest).expanduser() if args.manifest else layout.checks / "v2" / "release_manifest" / "release_manifest.csv"
    verification_path = (
        Path(args.verification).expanduser()
        if args.verification
        else manifest_path.parent / "release_manifest_verification.csv"
    )
    out_path = Path(args.out).expanduser() if args.out else layout.checks / "v2" / "release_metadata" / "datapackage.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)

    expected_version = contract_id(repo)
    version = str(args.version).strip() or expected_version
    if version != expected_version:
        raise SystemExit(f"Data Package version must match contract_id {expected_version!r}.")
    if args.require_verified_manifest:
        require_manifest_verification(manifest_path, verification_path)

    manifest = pd.read_csv(manifest_path, dtype=str).fillna("")
    if manifest.empty or "present" not in manifest.columns:
        raise SystemExit("Release manifest is empty or malformed.")
    if not manifest["present"].map(boolish).all():
        raise SystemExit("Release manifest records missing artifacts.")
    resources = []
    for _, row in manifest.iterrows():
        if not boolish(row.get("present", "")):
            continue
        rel = str(row.get("relative_path", "")).strip()
        path = resolve_path(row, root, repo)
        if not path.exists() or not path.is_file():
            raise SystemExit(f"Manifest resource is missing: {path}")
        path_base = str(row.get("path_base", "")).strip()
        package_path = f"{path_base}/{rel}" if path_base else rel
        fmt = str(row.get("file_format", "")).strip().lower()
        fields = fields_for(path)
        schema = {"fields": fields}
        pkey = primary_key(rel, fields)
        if pkey:
            schema["primaryKey"] = pkey
        resources.append(
            {
                "name": resource_name(package_path),
                "path": package_path,
                "title": rel,
                "profile": "tabular-data-resource" if fields else "data-resource",
                "format": fmt,
                "bytes": int(row["size_bytes"]) if str(row.get("size_bytes", "")).isdigit() else None,
                "hash": row.get("sha256", ""),
                "schema": schema if fields else {},
            }
        )

    package = {
        "profile": "data-package",
        "name": args.name,
        "title": args.title,
        "version": version,
        "homepage": args.homepage,
        "created": pd.Timestamp.utcnow().replace(microsecond=0).isoformat(),
        "description": f"IPEDSDB_Panel release metadata for {years[0]}:{years[-1]}.",
        "contributors": [{"title": "Mark Jayson Farol", "role": "author"}],
        "resources": sorted(resources, key=lambda item: item["path"]),
    }
    atomic_write_json(out_path, package)
    print(f"Wrote Data Package metadata to {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
