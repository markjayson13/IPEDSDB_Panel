#!/usr/bin/env python3
"""
QA 08: audit the generated IPEDSDB_ROOT artifacts against core acceptance criteria.

Reads:
- final panel artifacts under `Panels/`
- dictionary and QA summaries under `Checks/`
- release inventory under `Checks/download_qc/`

Writes in release mode:
- `Checks/v2/acceptance_qc/acceptance_summary.csv`
- `Checks/v2/acceptance_qc/acceptance_summary.md`
- `Checks/v2/acceptance_qc/acceptance_manifest.json`

Focus:
- exact requested year coverage
- row and key preservation
- zero unresolved dictionary and panel QA failures
- readable, reusable acceptance status for the live build

Open this file when you want the repo's final answer to: "Is the current generated build release-ready, or did it merely run to completion?"

Method context:
- this script certifies the evidence written by the pipeline
- it does not replace the method notes, but it is where the release claim becomes a concrete pass/fail artifact
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import sys
import tomllib
import uuid
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

import duckdb
import pandas as pd
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.dataset as ds

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import (
    DEFAULT_IPEDSDB_ROOT,
    canonicalize_nces_source_variable_id,
    ensure_data_layout,
    parse_years,
    repo_root,
)
from stage_provenance import ProvenanceError, resolve_run_dir, tool_versions, verify_run


ACCEPTANCE_SCHEMA_VERSION = "semantic-acceptance-v2.0"
CANONICAL_ACCEPTANCE = "Checks/v2/acceptance_qc/acceptance_summary.csv"
PASS_TOKENS = {"pass", "passed", "true", "1", "yes"}
APPROVED_BACKFILL_COMPATIBILITY_STATUS = "exact_adjacent_donor_semantics_match"
REQUIRED_CAUSAL_STAGES = ("01", "02", "03", "04", "05", "06", "07", "qa00", "qa01")
REQUIRED_RELEASE_CHECK_IDS = frozenset(
    {
        "contract:exact_v2_scope_and_paths",
        "provenance:current_causal_stage_chain",
        "source_lock:complete_approved_final_rows",
        "source_lock:stage01_receipts_and_download_hashes",
        "extraction:no_failures",
        "extraction:all_access_tables_reconciled",
        "dictionary:resolved_identity_conflicts",
        "dictionary:metadata_backfills_approved",
        "harmonize:all_source_columns_classified",
        "harmonize:source_rows_reconciled_without_skips",
        "panel:scalar_scientific_key",
        "panel:dimensioned_scientific_key",
        "panel:source_rows_scientific_key",
        "panel:analysis_wide_scientific_key",
        "panel:raw_wide_scientific_key",
        "panel:clean_scientific_key",
        "panel:row_preservation_through_cleaning",
        "lineage:long_cells_match_lossless_source_rows",
        "lineage:wide_values_have_current_source_evidence",
        "wide:semantic_release_qc",
        "prch:managed_semantic_qa",
        "continuity:independently_verified_current_evidence",
        "benchmarks:mandatory_external_reconciliation",
    }
)
RELEASE_FAILURE_ONLY_CHECK_IDS = frozenset(
    {"acceptance:execution"}
)
WIDE_QC_ZERO_ISSUE_FILES = frozenset(
    {
        "qc_unreviewed_source_column_inventory.csv",
        "qc_duplicate_source_column_inventory.csv",
        "qc_missing_dictionary_inventory.csv",
        "qc_contradictory_dictionary_discovery.csv",
        "qc_missing_stage04_classification.csv",
        "qc_unknown_value_statuses.csv",
        "qc_scalar_input_key_duplicates.csv",
        "qc_ambiguous_analysis_mappings.csv",
        "qc_unknown_discrete_families.csv",
        "qc_unknown_discrete_tokens.csv",
        "qc_discrete_component_conflicts.csv",
        "qc_discrete_conflicts.csv",
        "qc_irreversible_discrete_derivations.csv",
        "qc_final_wide_conflicts.csv",
        "qc_nonnullable_missing.csv",
        "qc_duplicate_value_lineage.csv",
    }
)
WIDE_QC_EXPECTED_FILES = frozenset(
    set(WIDE_QC_ZERO_ISSUE_FILES)
    | {
        "qc_analysis_schema_candidates.csv",
        "qc_analysis_schema_exclusions.csv",
        "qc_canonical_column_coverage.csv",
        "qc_cast_diagnostics.csv",
        "qc_cast_summary.csv",
        "qc_final_wide_conflicts_summary.csv",
        "qc_lane_coverage.csv",
        "qc_lane_coverage_summary.csv",
        "qc_value_lineage.parquet",
        "wide_panel_qc_summary.csv",
    }
)
WIDE_QC_CSV_SCHEMAS = {
    "qc_ambiguous_analysis_mappings.csv": [
        "year", "UNITID", "variable_id", "source_file", "source_row_id", "analysis_columns"
    ],
    "qc_analysis_schema_candidates.csv": [
        "variable_id", "varname", "source_files", "source_rows", "non_null_rows", "analysis_schema_status"
    ],
    "qc_analysis_schema_exclusions.csv": [
        "analysis_column", "status", "exclusion_reason", "match_type", "match_value",
        "first_year", "last_year", "year", "eligible_rows", "non_null_rows"
    ],
    "qc_canonical_column_coverage.csv": [
        "analysis_column", "transformation", "first_year", "last_year", "eligible_value_rows", "non_null_value_rows"
    ],
    "qc_cast_diagnostics.csv": [
        "UNITID", "year", "analysis_column", "variable_id", "source_file", "source_row_id",
        "raw_value", "value", "value_status", "logical_type", "cast_status", "cast_reason"
    ],
    "qc_cast_summary.csv": ["logical_type", "value_status", "cast_status", "cast_reason", "rows"],
    "qc_contradictory_dictionary_discovery.csv": [
        "year", "variable_id", "source_file", "varname", "discovery_classes"
    ],
    "qc_discrete_component_conflicts.csv": [
        "UNITID", "year", "source_file", "family_id", "component_varname", "distinct_tokens"
    ],
    "qc_discrete_conflicts.csv": [
        "UNITID", "year", "source_file", "family_id", "n_active", "active_codes"
    ],
    "qc_duplicate_source_column_inventory.csv": [
        "year", "source_file", "access_table_name", "column_name", "rows"
    ],
    "qc_duplicate_value_lineage.csv": [
        "UNITID", "year", "analysis_column", "variable_id", "source_row_id", "rows"
    ],
    "qc_final_wide_conflicts.csv": [
        "UNITID", "year", "analysis_column", "normalized_value", "value_status", "transformation",
        "variable_id", "source_file", "access_table_name", "source_row_id", "distinct_values"
    ],
    "qc_final_wide_conflicts_summary.csv": ["total_conflict_keys", "sample_row_limit"],
    "qc_irreversible_discrete_derivations.csv": [
        "UNITID", "year", "source_file", "family_id", "observed_components", "missing_components"
    ],
    "qc_lane_coverage.csv": [
        "year", "variable_id", "varname", "source_file", "access_table_name", "reviewed_role",
        "reviewed", "resolution", "nonempty_tokens", "scalar_rows", "dimensioned_rows",
        "output_rows", "output_destination", "exclusion_reason"
    ],
    "qc_lane_coverage_summary.csv": [
        "output_destination", "reviewed_nonempty_source_tokens", "scalar_rows", "dimensioned_rows",
        "output_rows", "inventory_rows"
    ],
    "qc_missing_dictionary_inventory.csv": [
        "year", "variable_id", "source_varnumber", "varname", "source_file", "lane"
    ],
    "qc_missing_stage04_classification.csv": [
        "year", "source_file", "access_table_name", "varname", "lane"
    ],
    "qc_nonnullable_missing.csv": ["UNITID", "year", "analysis_column"],
    "qc_scalar_input_key_duplicates.csv": ["UNITID", "year", "variable_id", "source_file", "rows"],
    "qc_unknown_discrete_families.csv": ["year", "source_file", "component_varname", "variable_id", "status"],
    "qc_unknown_discrete_tokens.csv": [
        "UNITID", "year", "source_file", "family_id", "component_varname", "raw_value",
        "value_status", "contract_token"
    ],
    "qc_unknown_value_statuses.csv": ["value_status"],
    "qc_unreviewed_source_column_inventory.csv": [
        "year", "source_file", "access_table_name", "column_name", "role", "reviewed",
        "nonempty_tokens", "resolution"
    ],
    "wide_panel_qc_summary.csv": [
        "contract_id", "build_mode", "input_rows", "panel_rows", "analysis_columns", "lineage_rows",
        "unresolved_conflicts", "unresolved_casts", "schema_contract", "discrete_contract", "output"
    ],
}
BENCHMARK_RESULT_COLUMNS = [
    "benchmark_id",
    "contract_id",
    "artifact",
    "year",
    "metric",
    "variable",
    "filters",
    "component_family",
    "actual_value",
    "expected_value",
    "delta",
    "absolute_tolerance",
    "relative_tolerance",
    "allowed_delta",
    "status",
    "failure_reason",
    "tolerance_rationale",
    "official_source",
    "source_date_or_version",
    "source_evidence_path",
    "source_evidence_sha256",
    "review_status",
    "reviewer",
    "review_date",
    "definition",
    "notes",
    "panel_sha256",
    "benchmark_contract_sha256",
]
BENCHMARK_CONTRACT_COLUMNS = [
    "benchmark_id",
    "contract_id",
    "artifact",
    "year",
    "metric",
    "variable",
    "filters",
    "component_family",
    "expected_value",
    "absolute_tolerance",
    "relative_tolerance",
    "tolerance_rationale",
    "official_source",
    "source_date_or_version",
    "source_evidence_path",
    "source_evidence_sha256",
    "review_status",
    "reviewer",
    "review_date",
    "definition",
    "notes",
]
PRCH_ACTION_COLUMNS = [
    "year",
    "UNITID",
    "flag",
    "code",
    "column",
    "old_value",
    "new_value",
    "action",
    "rule_id",
    "accounting_standard",
    "form",
    "part",
    "row_predicate",
]
EXTRACT_INVENTORY_COLUMNS = [
    "year",
    "access_db_file",
    "table_name",
    "normalized_table_name",
    "table_role",
    "csv_path",
    "has_unitid",
    "row_count_csv",
    "column_count",
    "csv_sha256",
    "export_status",
    "has_varnumber",
    "has_varname",
    "has_vartitle",
    "has_longdesc",
    "has_codevalue",
    "has_valuelabel",
    "has_imputation_markers",
]
EXTRACT_COUNT_COLUMNS = [
    "year",
    "table_name",
    "row_count_csv",
    "row_count_access",
    "row_count_match",
]
EXTRACT_FAILURE_COLUMNS = ["year", "table_name", "error"]


def parse_args() -> argparse.Namespace:
    data_root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default=str(data_root), help="External IPEDSDB_ROOT")
    p.add_argument("--repo", default=None, help="Repository containing the reviewed v2 contracts")
    p.add_argument("--years", default="2004:2023", help='Expected year span, e.g. "2004:2023"')
    p.add_argument("--out-dir", default=None, help="Development-only acceptance output directory")
    p.add_argument("--mode", choices=("development", "release"), default="release")
    return p.parse_args()


def build_row(
    check_name: str,
    passed: bool,
    *,
    value: object = "",
    expected: object = "",
    details: str = "",
    evidence_path: str = "",
    evidence_sha256: str = "",
) -> dict[str, object]:
    return {
        "check_id": check_name,
        "check_name": check_name,
        "status": "PASS" if passed else "FAIL",
        "passed": bool(passed),
        "actual": value,
        "value": value,
        "expected": expected,
        "evidence_path": evidence_path,
        "evidence_sha256": evidence_sha256,
        "details": details,
    }


def safe_read_csv(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def series_or_default(df: pd.DataFrame, column: str, default: str = "") -> pd.Series:
    if column in df.columns:
        return df[column]
    return pd.Series([default] * len(df), index=df.index, dtype="string")


def year_coverage(path: Path) -> list[int]:
    dataset = ds.dataset(str(path), format="parquet")
    values = dataset.to_table(columns=["year"]).column(0)
    return sorted(int(v) for v in pc.unique(values).to_pylist() if v is not None)


def null_or_blank_key_counts(path: Path, key_cols: list[str]) -> dict[str, int]:
    dataset = ds.dataset(str(path), format="parquet")
    counts = {col: 0 for col in key_cols}
    for batch in dataset.to_batches(columns=key_cols, batch_size=200_000):
        schema_names = list(batch.schema.names)
        for col in key_cols:
            arr = batch.column(schema_names.index(col))
            counts[col] += int(arr.null_count)
            if pa.types.is_string(arr.type) or pa.types.is_large_string(arr.type):
                counts[col] += int(pc.sum(pc.equal(pc.utf8_trim_whitespace(arr), "")).as_py() or 0)
    return counts


def duplicate_key_count(path: Path, key_cols: list[str]) -> int:
    dataset = ds.dataset(str(path), format="parquet")
    df = dataset.to_table(columns=key_cols).to_pandas()
    return int(df.duplicated(subset=key_cols).sum())


def collect_acceptance_rows(root: Path, years: list[int]) -> list[dict[str, object]]:
    layout = ensure_data_layout(root)
    start, end = years[0], years[-1]
    expected_years = years

    long_path = layout.panels / f"{start}-{end}" / f"panel_long_varnum_{start}_{end}.parquet"
    wide_path = layout.panels / f"panel_wide_analysis_{start}_{end}.parquet"
    clean_path = layout.panels / f"panel_clean_analysis_{start}_{end}.parquet"
    dict_path = layout.dictionary / "dictionary_lake.parquet"
    dict_qc_path = layout.checks / "dictionary_qc" / "dictionary_qaqc_summary.csv"
    panel_qc_path = layout.checks / "panel_qc" / "panel_qa_summary.csv"
    panel_cov_path = layout.checks / "panel_qc" / "panel_qa_coverage_matrix.csv"
    panel_structure_path = layout.checks / "panel_qc" / "panel_structure_summary.csv"
    entry_exit_path = layout.checks / "panel_qc" / "entry_exit_gap_summary.csv"
    identifier_linkage_path = layout.checks / "panel_qc" / "identifier_linkage_summary.csv"
    component_timing_path = layout.checks / "panel_qc" / "component_timing_reference.csv"
    finance_compare_path = layout.checks / "panel_qc" / "finance_comparability_summary.csv"
    class_stability_path = layout.checks / "panel_qc" / "classification_stability_summary.csv"
    disc_summary_path = layout.checks / "disc_qc" / "disc_conflicts_summary_all_years.csv"
    release_inventory_path = layout.checks / "download_qc" / "release_inventory.csv"

    rows: list[dict[str, object]] = []

    required_paths = {
        "dictionary_lake": dict_path,
        "panel_long": long_path,
        "panel_wide": wide_path,
        "panel_clean": clean_path,
        "dictionary_qaqc_summary": dict_qc_path,
        "panel_qa_summary": panel_qc_path,
        "panel_qa_coverage_matrix": panel_cov_path,
        "panel_structure_summary": panel_structure_path,
        "entry_exit_gap_summary": entry_exit_path,
        "identifier_linkage_summary": identifier_linkage_path,
        "component_timing_reference": component_timing_path,
        "finance_comparability_summary": finance_compare_path,
        "classification_stability_summary": class_stability_path,
        "release_inventory": release_inventory_path,
    }
    for label, path in required_paths.items():
        rows.append(
            build_row(
                f"exists:{label}",
                path.exists(),
                value=str(path),
                expected="file exists",
                details="" if path.exists() else "Required artifact is missing.",
            )
        )

    per_year_missing = [
        year for year in expected_years if not (layout.cross_sections / f"panel_long_varnum_{year}.parquet").exists()
    ]
    rows.append(
        build_row(
            "cross_sections:per_year_long_files",
            not per_year_missing,
            value=",".join(str(y) for y in expected_years),
            expected="all requested years present",
            details="" if not per_year_missing else f"Missing per-year long files for: {per_year_missing}",
        )
    )

    if release_inventory_path.exists():
        release_df = safe_read_csv(release_inventory_path)
        release_df["year"] = pd.to_numeric(series_or_default(release_df, "year"), errors="coerce").astype("Int64")
        release_df["release_type"] = series_or_default(release_df, "release_type").fillna("").astype(str).str.strip().str.lower()
        final_years = sorted(int(y) for y in release_df.loc[release_df["release_type"] == "final", "year"].dropna().tolist())
        final_ok = final_years == expected_years
        rows.append(
            build_row(
                "release_inventory:final_year_coverage",
                final_ok,
                value=",".join(str(y) for y in final_years),
                expected=",".join(str(y) for y in expected_years),
                details="" if final_ok else "Final release years did not match the expected analysis window.",
            )
        )
        if "download_status" in release_df.columns:
            release_df["download_status"] = series_or_default(release_df, "download_status").fillna("").astype(str).str.strip().str.lower()
            requested_release_rows = release_df[release_df["year"].isin(expected_years)]
            download_ok = requested_release_rows["download_status"].isin({"downloaded", "existing"}).all()
            rows.append(
                build_row(
                    "release_inventory:download_status",
                    bool(download_ok),
                    value=",".join(sorted(set(requested_release_rows["download_status"].astype(str)))),
                    expected="downloaded/existing only",
                    details="" if download_ok else "One or more requested years were not marked downloaded/existing.",
                )
            )
        else:
            rows.append(
                build_row(
                    "release_inventory:download_status",
                    True,
                    value="column absent",
                    expected="column optional",
                    details="release_inventory.csv does not include download_status; downstream artifact existence is used instead.",
                )
            )

    if long_path.exists():
        long_years = year_coverage(long_path)
        long_nulls = null_or_blank_key_counts(long_path, ["year", "UNITID", "varnumber", "source_file"])
        rows.append(
            build_row(
                "panel_long:year_coverage",
                long_years == expected_years,
                value=",".join(str(y) for y in long_years),
                expected=",".join(str(y) for y in expected_years),
                details="" if long_years == expected_years else "Stitched long panel year coverage mismatch.",
            )
        )
        rows.append(
            build_row(
                "panel_long:key_nulls",
                all(v == 0 for v in long_nulls.values()),
                value=str(long_nulls),
                expected="all zero",
                details="" if all(v == 0 for v in long_nulls.values()) else "Long panel contains null or blank key fields.",
            )
        )

    wide_rows = None
    clean_rows = None
    if wide_path.exists():
        wide_dataset = ds.dataset(str(wide_path), format="parquet")
        wide_rows = int(wide_dataset.count_rows())
        wide_years = year_coverage(wide_path)
        wide_dup = duplicate_key_count(wide_path, ["UNITID", "year"])
        rows.append(
            build_row(
                "panel_wide:year_coverage",
                wide_years == expected_years,
                value=",".join(str(y) for y in wide_years),
                expected=",".join(str(y) for y in expected_years),
                details="" if wide_years == expected_years else "Wide panel year coverage mismatch.",
            )
        )
        rows.append(
            build_row(
                "panel_wide:duplicate_unitid_year",
                wide_dup == 0,
                value=wide_dup,
                expected=0,
                details="" if wide_dup == 0 else "Wide panel contains duplicate UNITID-year rows.",
            )
        )

    if clean_path.exists():
        clean_dataset = ds.dataset(str(clean_path), format="parquet")
        clean_rows = int(clean_dataset.count_rows())
        clean_years = year_coverage(clean_path)
        clean_dup = duplicate_key_count(clean_path, ["UNITID", "year"])
        rows.append(
            build_row(
                "panel_clean:year_coverage",
                clean_years == expected_years,
                value=",".join(str(y) for y in clean_years),
                expected=",".join(str(y) for y in expected_years),
                details="" if clean_years == expected_years else "Clean panel year coverage mismatch.",
            )
        )
        rows.append(
            build_row(
                "panel_clean:duplicate_unitid_year",
                clean_dup == 0,
                value=clean_dup,
                expected=0,
                details="" if clean_dup == 0 else "Clean panel contains duplicate UNITID-year rows.",
            )
        )

    if wide_rows is not None and clean_rows is not None:
        rows.append(
            build_row(
                "panel_clean:row_preservation",
                wide_rows == clean_rows,
                value=clean_rows,
                expected=wide_rows,
                details="" if wide_rows == clean_rows else "Raw and cleaned panel row counts differ.",
            )
        )

    if dict_qc_path.exists():
        dict_summary = safe_read_csv(dict_qc_path).iloc[0].to_dict()
        for field in ["duplicate_rows", "source_file_conflicts", "varnumber_collisions", "unmapped_rows", "needs_review_rows"]:
            value = int(dict_summary.get(field, 0) or 0)
            rows.append(
                build_row(
                    f"dictionary_qaqc:{field}",
                    value == 0,
                    value=value,
                    expected=0,
                    details="" if value == 0 else f"Dictionary QA reported nonzero {field}.",
                )
            )

    if panel_qc_path.exists():
        panel_summary = safe_read_csv(panel_qc_path).iloc[0].to_dict()
        suspicious = int(panel_summary.get("suspicious_flags", 0) or 0)
        raw_rows_value = int(panel_summary.get("raw_rows", 0) or 0)
        clean_rows_value = int(panel_summary.get("clean_rows", 0) or 0)
        rows.append(
            build_row(
                "panel_qaqc:suspicious_flags",
                suspicious == 0,
                value=suspicious,
                expected=0,
                details="" if suspicious == 0 else "Panel QA reported unresolved suspicious PRCH flags.",
            )
        )
        rows.append(
            build_row(
                "panel_qaqc:raw_clean_rows_match",
                raw_rows_value == clean_rows_value,
                value=clean_rows_value,
                expected=raw_rows_value,
                details="" if raw_rows_value == clean_rows_value else "Panel QA reported row-count mismatch.",
            )
        )

    if panel_cov_path.exists():
        coverage = safe_read_csv(panel_cov_path)
        suspicious_cov = int((coverage.get("status", pd.Series(dtype=str)).astype(str) == "suspicious").sum())
        rows.append(
            build_row(
                "panel_qaqc:coverage_matrix_suspicious_rows",
                suspicious_cov == 0,
                value=suspicious_cov,
                expected=0,
                details="" if suspicious_cov == 0 else "Coverage matrix still has suspicious flag rows.",
            )
        )

    panel_qc_reference_paths = {
        "panel_structure_summary": panel_structure_path,
        "entry_exit_gap_summary": entry_exit_path,
        "identifier_linkage_summary": identifier_linkage_path,
        "component_timing_reference": component_timing_path,
        "finance_comparability_summary": finance_compare_path,
        "classification_stability_summary": class_stability_path,
    }
    for label, path in panel_qc_reference_paths.items():
        if path.exists():
            frame = safe_read_csv(path)
            rows.append(
                build_row(
                    f"panel_qaqc:{label}_nonempty",
                    len(frame) > 0,
                    value=len(frame),
                    expected="> 0 rows",
                    details="" if len(frame) > 0 else f"{label}.csv was present but empty.",
                )
            )

    if disc_summary_path.exists():
        disc_summary = safe_read_csv(disc_summary_path)
        high_signal = int(pd.to_numeric(disc_summary.get("high_signal"), errors="coerce").fillna(0).astype(int).sum()) if not disc_summary.empty else 0
        rows.append(
            build_row(
                "disc_qaqc:high_signal_groups",
                high_signal == 0,
                value=high_signal,
                expected=0,
                details="" if high_signal == 0 else "Discrete conflict summary still contains high-signal groups.",
            )
        )

    return rows


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def evidence_fingerprint(path: Path) -> str:
    """Hash a file or bind a managed projection to its exact symlink target."""
    if path.is_symlink():
        target = os.readlink(path)
        return hashlib.sha256(f"symlink\0{target}".encode("utf-8")).hexdigest()
    if path.is_file():
        return sha256_file(path)
    return ""


def causal_run_binding(root: Path, repo: Path) -> dict[str, str]:
    result = verify_run(root=root, repo=repo, required_stages=REQUIRED_CAUSAL_STAGES)
    run_dir = Path(str(result.get("run_dir", ""))).resolve(strict=True)
    root_resolved = root.resolve(strict=True)
    try:
        relative_run = run_dir.relative_to(root_resolved).as_posix()
    except ValueError as exc:
        raise ProvenanceError("verified causal run escapes IPEDSDB_ROOT") from exc
    manifest = run_dir / "run_manifest.json"
    pointer = root / "Checks" / "v2" / "stage_manifests" / "CURRENT"
    if not pointer.is_file() or pointer.is_symlink() or not manifest.is_file():
        raise ProvenanceError("verified causal run lacks its managed pointer or manifest")
    pointer_target = pointer.read_text(encoding="utf-8").strip()
    expected_target = run_dir.relative_to(pointer.parent.resolve(strict=True)).as_posix()
    if not pointer_target or Path(pointer_target).is_absolute() or pointer_target != expected_target:
        raise ProvenanceError("verified causal run differs from its authoritative pointer")
    return {
        "run_dir": relative_run,
        "run_manifest_sha256": sha256_file(manifest),
        "pointer_target": pointer_target,
    }


def portable_release_text(value: object, *, root: Path, repo: Path) -> object:
    if not isinstance(value, str):
        return value
    return value.replace(str(root), "$IPEDSDB_ROOT").replace(str(repo), "$REPO")


def portable_release_rows(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
) -> list[dict[str, object]]:
    return [
        {
            key: portable_release_text(value, root=root, repo=repo)
            for key, value in row.items()
        }
        for row in rows
    ]


def strict_json(path: Path) -> dict[str, object]:
    def reject_duplicates(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON key {key!r}")
            result[key] = value
        return result

    value = json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=reject_duplicates)
    if not isinstance(value, dict):
        raise ValueError("JSON document is not an object")
    return value


def strict_csv(path: Path) -> pd.DataFrame:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, strict=True)
        try:
            header = next(reader)
        except StopIteration as exc:
            raise ValueError("CSV is empty and has no header") from exc
        for _ in reader:
            pass
    if len(header) != len(set(header)):
        raise ValueError("CSV contains duplicate column names")
    return pd.read_csv(path, dtype=str, keep_default_na=False)


def strict_csv_shape(path: Path) -> tuple[list[str], int]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle, strict=True)
        try:
            header = next(reader)
        except StopIteration as exc:
            raise ValueError(f"CSV has no header: {path}") from exc
        if not header or len(header) != len(set(header)):
            raise ValueError(f"CSV has an empty or duplicate header: {path}")
        rows = sum(1 for _record in reader)
    return header, rows


def relative_evidence(path: Path, *, root: Path, repo: Path) -> str:
    resolved = path.expanduser().absolute()
    if resolved.is_relative_to(root.absolute()):
        return resolved.relative_to(root.absolute()).as_posix()
    if resolved.is_relative_to(repo.absolute()):
        return resolved.relative_to(repo.absolute()).as_posix()
    return path.name


def add_release_check(
    rows: list[dict[str, object]],
    check_id: str,
    passed: bool,
    *,
    value: object,
    expected: object,
    evidence: Path | None,
    root: Path,
    repo: Path,
    details: str = "",
) -> None:
    evidence_path = ""
    evidence_sha = ""
    if evidence is not None:
        evidence_path = relative_evidence(evidence, root=root, repo=repo)
        evidence_sha = evidence_fingerprint(evidence)
    rows.append(
        build_row(
            check_id,
            passed,
            value=value,
            expected=expected,
            details=details,
            evidence_path=evidence_path,
            evidence_sha256=evidence_sha,
        )
    )


def truthy(value: object) -> bool:
    return str(value).strip().lower() in PASS_TOKENS


def exact_contract_layout(repo: Path) -> dict[str, object]:
    contract_path = repo / "contracts" / "panel_spec.toml"
    with contract_path.open("rb") as handle:
        contract = tomllib.load(handle)
    release = contract["release"]
    outputs = contract["outputs"]
    inputs = contract["inputs"]
    policies = contract["policies"]
    qa = contract["qa"]
    external = contract["external_validation"]
    years = list(range(int(release["start_year"]), int(release["end_year"]) + 1))
    if release.get("default_year_spec") != f"{years[0]}:{years[-1]}":
        raise ValueError("reviewed contract release years are inconsistent")
    if qa.get("acceptance_summary") != CANONICAL_ACCEPTANCE:
        raise ValueError("reviewed contract acceptance path is not canonical")
    paths: dict[str, str] = {
        "acceptance": str(qa["acceptance_summary"]),
        "analysis_wide": str(outputs["analysis_wide"]),
        "analysis_schema": str(policies["analysis_schema"]),
        "benchmark_contract": str(policies["external_benchmarks"]),
        "backfill_approvals": str(policies["metadata_backfill_approvals"]),
        "benchmarks": str(qa["external_benchmarks"]),
        "clean": str(outputs["prch_cleaned"]),
        "cleaning_changes": str(outputs["cleaning_changes"]),
        "continuity_crosswalk": str(qa["entity_continuity"]),
        "continuity_manifest": str(qa["entity_continuity_manifest"]),
        "continuity_value_lineage": str(qa["entity_continuity_value_lineage"]),
        "continuity_verification": str(qa["entity_continuity_verification"]),
        "dictionary": str(inputs["dictionary_lake"]),
        "dimensioned": str(outputs["dimensioned_long"]),
        "discrete_families": str(policies["discrete_families"]),
        "lineage": str(outputs["column_lineage"]),
        "panel_qa": str(qa["panel_qc"]),
        "raw_wide": str(outputs["raw_wide"]),
        "scalar": str(outputs["scalar_long"]),
        "source_lock": str(policies["source_releases"]),
    }
    for label, relative in paths.items():
        candidate = Path(relative)
        if not relative or candidate.is_absolute() or ".." in candidate.parts:
            raise ValueError(f"reviewed contract has a nonportable {label} path")
    scalar = Path(paths["scalar"])
    paths["source_rows"] = scalar.with_name(
        scalar.name.replace("panel_long_scalar_", "panel_source_rows_")
    ).as_posix()
    return {
        "contract": contract,
        "contract_id": str(contract["contract_id"]),
        "external": external,
        "paths": paths,
        "years": years,
    }


def validate_source_lock(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    years: list[int],
    contract_id: str,
    source_lock_path: Path,
) -> None:
    errors: list[str] = []
    locked_by_year: dict[int, dict[str, str]] = {}
    try:
        source_lock = strict_csv(source_lock_path)
        numeric_years = pd.to_numeric(source_lock.get("year"), errors="coerce")
        for year in years:
            matches = source_lock[numeric_years == year]
            if len(matches) != 1:
                errors.append(f"year {year}: source-lock rows={len(matches)}")
                continue
            record = matches.iloc[0].to_dict()
            locked_by_year[year] = record
            required = {
                "contract_id": contract_id,
                "release_type": "Final",
                "lock_status": "approved",
            }
            for field, expected in required.items():
                if str(record.get(field, "")).strip().lower() != str(expected).lower():
                    errors.append(f"year {year}: {field} is not {expected}")
            for field in ("expected_access_sha256", "expected_documentation_sha256"):
                if not re.fullmatch(r"[0-9a-f]{64}", str(record.get(field, "")).strip()):
                    errors.append(f"year {year}: {field} is not a SHA-256")
            for field in ("access_size_bytes", "documentation_size_bytes"):
                try:
                    if int(str(record.get(field, "")).strip()) <= 0:
                        raise ValueError
                except ValueError:
                    errors.append(f"year {year}: {field} is not positive")
    except (OSError, ValueError, pd.errors.ParserError) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "source_lock:complete_approved_final_rows",
        not errors,
        value=f"bound_years={len(locked_by_year)}; errors={len(errors)}",
        expected=f"one approved final row for each of {len(years)} years",
        evidence=source_lock_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:8]),
    )

    receipt_errors: list[str] = []
    for year in years:
        locked = locked_by_year.get(year)
        manifest_path = root / "Raw_Access_Databases" / str(year) / "manifest.csv"
        if locked is None:
            continue
        try:
            manifest = strict_csv(manifest_path)
            if len(manifest) != 1:
                raise ValueError(f"manifest rows={len(manifest)}")
            receipt = manifest.iloc[0].to_dict()
            comparisons = {
                "contract_id": "contract_id",
                "access_filename": "access_filename",
                "expected_access_sha256": "access_expected_sha256",
                "access_size_bytes": "access_expected_filesize_bytes",
                "documentation_filename": "doc_filename",
                "expected_documentation_sha256": "doc_expected_sha256",
                "documentation_size_bytes": "doc_expected_filesize_bytes",
            }
            for lock_field, receipt_field in comparisons.items():
                if str(locked.get(lock_field, "")).strip() != str(receipt.get(receipt_field, "")).strip():
                    receipt_errors.append(f"year {year}: stale {receipt_field}")
            if str(receipt.get("source_lock_status", "")).strip().lower() != "verified":
                receipt_errors.append(f"year {year}: source lock was not verified")
            for name_field, hash_field, size_field in (
                ("access_filename", "access_expected_sha256", "access_expected_filesize_bytes"),
                ("doc_filename", "doc_expected_sha256", "doc_expected_filesize_bytes"),
            ):
                artifact = manifest_path.parent / "downloads" / str(receipt.get(name_field, "")).strip()
                if not artifact.is_file():
                    receipt_errors.append(f"year {year}: missing {name_field} artifact")
                    continue
                if sha256_file(artifact) != str(receipt.get(hash_field, "")).strip():
                    receipt_errors.append(f"year {year}: {name_field} hash mismatch")
                if artifact.stat().st_size != int(str(receipt.get(size_field, "0")).strip() or 0):
                    receipt_errors.append(f"year {year}: {name_field} size mismatch")
        except (OSError, ValueError, pd.errors.ParserError) as exc:
            receipt_errors.append(f"year {year}: {exc}")
    add_release_check(
        rows,
        "source_lock:stage01_receipts_and_download_hashes",
        not receipt_errors and len(locked_by_year) == len(years),
        value=f"errors={len(receipt_errors)}",
        expected="all manifests and downloaded artifacts match the reviewed source lock",
        evidence=root / "Raw_Access_Databases",
        root=root,
        repo=repo,
        details="; ".join(receipt_errors[:8]),
    )


def validate_extraction(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    years: list[int],
) -> None:
    failures_path = root / "Checks" / "extract_qc" / "extract_failures.csv"
    try:
        failures = strict_csv(failures_path)
        failure_ok = list(failures.columns) == EXTRACT_FAILURE_COLUMNS and failures.empty
        failure_details = "" if failure_ok else f"failure rows={len(failures)}"
    except (OSError, ValueError, pd.errors.ParserError) as exc:
        failure_ok = False
        failure_details = str(exc)
    add_release_check(
        rows,
        "extraction:no_failures",
        failure_ok,
        value=0 if failure_ok else failure_details,
        expected=0,
        evidence=failures_path,
        root=root,
        repo=repo,
        details=failure_details,
    )

    errors: list[str] = []
    reconciled_tables = 0
    per_year_inventories: list[pd.DataFrame] = []
    current_tools = tool_versions().get("system_tools", {})
    for year in years:
        metadata = root / "Raw_Access_Databases" / str(year) / "metadata"
        try:
            receipt = strict_csv(metadata / "extraction_receipt.csv")
            if len(receipt) != 1:
                raise ValueError(f"extraction receipt rows={len(receipt)}")
            receipt_row = receipt.iloc[0]
            if str(receipt_row.get("extraction_status", "")).strip().lower() not in {
                "extracted",
                "skipped_verified",
            }:
                errors.append(f"year {year}: extraction status is not verified")
            if not truthy(receipt_row.get("extraction_release_strict", "")):
                errors.append(f"year {year}: extraction was not release-strict")
            extracted_dir = metadata.parent / "extracted_db"
            pointer = extracted_dir / "CURRENT"
            active_dir = extracted_dir
            if pointer.is_file():
                relative = PurePosixPath(pointer.read_text(encoding="utf-8").strip())
                if (
                    relative.is_absolute()
                    or len(relative.parts) != 2
                    or relative.parts[0] != ".versions"
                    or any(part in {"", ".", ".."} for part in relative.parts)
                ):
                    raise ValueError(f"invalid extraction CURRENT pointer: {relative.as_posix()!r}")
                active_dir = extracted_dir.joinpath(*relative.parts)
                if not active_dir.is_dir() or active_dir.is_symlink():
                    raise ValueError("extraction CURRENT pointer does not resolve to a regular directory")
            access_databases = sorted(
                path
                for suffix in ("*.mdb", "*.accdb")
                for path in active_dir.rglob(suffix)
                if path.is_file()
            )
            if len(access_databases) != 1 or access_databases[0].is_symlink():
                raise ValueError(
                    f"active extraction must contain exactly one regular Access database; found={len(access_databases)}"
                )
            extracted_database = access_databases[0]
            extraction_bindings = {
                "extracted_access_db_file": extracted_database.name,
                "extracted_access_db_sha256": sha256_file(extracted_database),
            }
            for field, expected in extraction_bindings.items():
                if str(receipt_row.get(field, "")).strip() != str(expected).strip():
                    errors.append(f"year {year}: stale {field}")
            for tool in ("mdb-export", "mdb-schema", "mdb-tables", "mdb-count"):
                prefix = tool.replace("-", "_")
                current = current_tools.get(tool, {}) if isinstance(current_tools, dict) else {}
                if not isinstance(current, dict):
                    current = {}
                for suffix in ("path", "sha256", "version"):
                    observed = str(receipt_row.get(f"{prefix}_{suffix}", "")).strip()
                    expected = str(current.get(suffix, "")).strip()
                    if not observed or observed != expected:
                        errors.append(f"year {year}: stale {prefix}_{suffix}")
            counts = strict_csv(metadata / "row_count_report.csv")
            inventory = strict_csv(metadata / "table_inventory.csv")
            per_year_failures = strict_csv(metadata.parent / "qc" / "extract_failures.csv")
            if list(counts.columns) != EXTRACT_COUNT_COLUMNS:
                errors.append(f"year {year}: row-count report schema is invalid")
            if list(inventory.columns) != EXTRACT_INVENTORY_COLUMNS:
                errors.append(f"year {year}: table inventory schema is invalid")
            if list(per_year_failures.columns) != EXTRACT_FAILURE_COLUMNS:
                errors.append(f"year {year}: extraction failure schema is invalid")
            if not per_year_failures.empty:
                errors.append(f"year {year}: extraction failure rows={len(per_year_failures)}")
            if counts.empty or inventory.empty:
                errors.append(f"year {year}: extraction inventory is empty")
                continue
            if counts["table_name"].duplicated().any() or inventory["table_name"].duplicated().any():
                errors.append(f"year {year}: duplicate table identities")
                continue
            if set(counts["table_name"]) != set(inventory["table_name"]):
                errors.append(f"year {year}: row-count/inventory table identities differ")
                continue
            if not counts["year"].eq(str(year)).all() or not inventory["year"].eq(str(year)).all():
                errors.append(f"year {year}: extraction evidence contains another year")
            per_year_inventories.append(inventory.copy())
            count_lookup = counts.set_index("table_name", drop=False)
            for record in inventory.to_dict("records"):
                table_name = str(record["table_name"])
                count_record = count_lookup.loc[table_name]
                csv_count = pd.to_numeric(count_record.get("row_count_csv", ""), errors="coerce")
                access_count = pd.to_numeric(
                    count_record.get("row_count_access", ""),
                    errors="coerce",
                )
                inventory_count = pd.to_numeric(record.get("row_count_csv", ""), errors="coerce")
                if (
                    pd.isna(csv_count)
                    or pd.isna(access_count)
                    or pd.isna(inventory_count)
                    or int(csv_count) < 0
                    or int(access_count) < 0
                    or int(inventory_count) < 0
                    or int(csv_count) != int(access_count)
                    or int(csv_count) != int(inventory_count)
                ):
                    errors.append(f"year {year}: numeric row-count mismatch for {table_name}")
                    continue
                if not truthy(count_record.get("row_count_match", "")):
                    errors.append(f"year {year}: row_count_match is not true for {table_name}")
                raw_csv_path = str(record.get("csv_path", "")).strip()
                relative_csv_path = Path(raw_csv_path)
                if (
                    not raw_csv_path
                    or raw_csv_path.startswith("~")
                    or "\\" in raw_csv_path
                    or re.match(r"^[A-Za-z]:", raw_csv_path)
                    or relative_csv_path.is_absolute()
                    or ".." in relative_csv_path.parts
                    or relative_csv_path.as_posix() != raw_csv_path
                ):
                    errors.append(f"year {year}: nonportable csv_path for {table_name}")
                    continue
                csv_path = (metadata.parent / relative_csv_path).resolve(strict=True)
                try:
                    csv_path.relative_to(metadata.parent.resolve(strict=True))
                except ValueError:
                    errors.append(f"year {year}: csv_path escapes year directory for {table_name}")
                    continue
                header, actual_rows = strict_csv_shape(csv_path)
                if actual_rows != int(csv_count):
                    errors.append(f"year {year}: exported CSV recount mismatch for {table_name}")
                if len(header) != int(str(record.get("column_count", "0")) or 0):
                    errors.append(f"year {year}: exported CSV column count mismatch for {table_name}")
                if sha256_file(csv_path) != str(record.get("csv_sha256", "")).strip():
                    errors.append(f"year {year}: exported CSV hash mismatch for {table_name}")
            bad_exports = ~inventory["export_status"].str.lower().isin({"exported", "skipped_verified"})
            if bad_exports.any():
                errors.append(f"year {year}: failed/unverified exports={int(bad_exports.sum())}")
            reconciled_tables += len(counts)
        except (OSError, KeyError, ValueError, pd.errors.ParserError) as exc:
            errors.append(f"year {year}: {exc}")

    global_inventory_path = root / "Checks" / "extract_qc" / "table_inventory_all_years.csv"
    try:
        global_inventory = strict_csv(global_inventory_path)
        if list(global_inventory.columns) != EXTRACT_INVENTORY_COLUMNS:
            errors.append("global extraction inventory schema is invalid")
        elif global_inventory.duplicated(["year", "table_name"]).any():
            errors.append("global extraction inventory repeats year/table identities")
        elif len(per_year_inventories) == len(years):
            expected_inventory = pd.concat(per_year_inventories, ignore_index=True)
            sort_columns = ["year", "table_name"]
            observed = global_inventory.sort_values(sort_columns).reset_index(drop=True)
            expected = expected_inventory.sort_values(sort_columns).reset_index(drop=True)
            if not observed.equals(expected):
                errors.append("global extraction inventory differs from per-year inventories")
    except (OSError, KeyError, ValueError, pd.errors.ParserError) as exc:
        errors.append(f"global extraction inventory: {exc}")
    add_release_check(
        rows,
        "extraction:all_access_tables_reconciled",
        not errors,
        value=f"tables={reconciled_tables}; errors={len(errors)}",
        expected="nonempty release-strict inventories with exact Access/CSV row counts",
        evidence=global_inventory_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:8]),
    )


def validate_dictionary(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    dictionary_path: Path,
    approval_path: Path,
    contract_id: str,
) -> None:
    summary_path = root / "Checks" / "dictionary_qc" / "dictionary_qaqc_summary.csv"
    zero_fields = [
        "duplicate_rows",
        "source_file_conflicts",
        "varnumber_collisions",
        "unmapped_rows",
        "needs_review_rows",
        "description_conflicts",
        "code_label_conflicts",
        "identity_issues",
        "varlist_conflicts",
        "integrity_failures",
    ]
    errors: list[str] = []
    try:
        summary = strict_csv(summary_path)
        if len(summary) != 1:
            raise ValueError(f"dictionary summary rows={len(summary)}")
        for field in zero_fields:
            if field not in summary.columns or int(float(summary.iloc[0][field] or 0)) != 0:
                errors.append(f"{field} is nonzero or missing")
        dataset = ds.dataset(str(dictionary_path), format="parquet")
        required = {
            "contract_id",
            "year",
            "variable_id",
            "source_varnumber",
            "variable_origin",
            "is_synthetic",
            "source_file",
            "access_table_name",
            "varname",
        }
        missing = sorted(required - set(dataset.schema.names))
        if missing or dataset.count_rows() == 0:
            errors.append("dictionary is empty or lacks identity fields: " + ",".join(missing))
    except (OSError, ValueError, pd.errors.ParserError) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "dictionary:resolved_identity_conflicts",
        not errors,
        value=f"errors={len(errors)}",
        expected="nonempty v2 dictionary and zero unresolved identity/metadata conflicts",
        evidence=summary_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:8]),
    )

    backfill_path = root / "Checks" / "dictionary_qc" / "metadata_backfill_report.csv"
    backfill_errors: list[str] = []
    try:
        backfills = strict_csv(backfill_path)
        approvals = strict_csv(approval_path)
        if not backfills.empty:
            required = {
                "target_year",
                "donor_year",
                "source_file",
                "access_table_name",
                "varname",
                "variable_id",
                "fields_backfilled",
                "compatibility_status",
                "approval_id",
                "compatibility_evidence",
                "reviewer",
                "review_date",
            }
            missing = required - set(backfills.columns)
            if missing:
                backfill_errors.append("missing fields=" + ",".join(sorted(missing)))
            else:
                invalid = (
                    backfills["compatibility_status"].ne(
                        APPROVED_BACKFILL_COMPATIBILITY_STATUS
                    )
                    | backfills[list(required - {"compatibility_status"})]
                    .apply(lambda col: col.str.strip().eq(""))
                    .any(axis=1)
                )
                if invalid.any():
                    backfill_errors.append(f"unapproved/incomplete rows={int(invalid.sum())}")
                if backfills["approval_id"].duplicated().any():
                    backfill_errors.append("metadata backfill report repeats approval_id")
                if "approval_id" not in approvals or approvals["approval_id"].duplicated().any():
                    backfill_errors.append("reviewed backfill approvals lack unique approval_id values")
                else:
                    selected_ids = set(backfills["approval_id"])
                    selected = approvals[approvals["approval_id"].isin(selected_ids)].copy()
                    if set(selected["approval_id"]) != selected_ids:
                        backfill_errors.append("one or more backfills lacks a reviewed approval row")
                    else:
                        selected = selected.set_index("approval_id", drop=False)
                        comparisons = {
                            "target_year": "target_year",
                            "donor_year": "donor_year",
                            "source_file": "source_file",
                            "access_table_name": "access_table_name",
                            "varname": "target_varname",
                            "variable_id": "variable_id",
                            "fields_backfilled": "fields_backfilled",
                            "compatibility_status": "compatibility_status",
                            "compatibility_evidence": "compatibility_evidence",
                            "reviewer": "reviewer",
                            "review_date": "review_date",
                        }
                        for row in backfills.to_dict("records"):
                            reviewed = selected.loc[str(row["approval_id"])]
                            if (
                                str(reviewed.get("contract_id", "")).strip() != contract_id
                                or str(reviewed.get("approval_status", "")).strip().lower()
                                != "approved"
                            ):
                                backfill_errors.append(
                                    f"approval {row['approval_id']} is not approved for this contract"
                                )
                                continue
                            for report_field, approval_field in comparisons.items():
                                report_value = str(row[report_field]).strip()
                                approval_value = str(
                                    reviewed.get(approval_field, "")
                                ).strip()
                                if report_field == "variable_id":
                                    try:
                                        report_value = canonicalize_nces_source_variable_id(
                                            report_value
                                        )
                                        approval_value = canonicalize_nces_source_variable_id(
                                            approval_value
                                        )
                                    except ValueError as exc:
                                        backfill_errors.append(
                                            f"approval {row['approval_id']} {exc}"
                                        )
                                        continue
                                if report_value != approval_value:
                                    backfill_errors.append(
                                        f"approval {row['approval_id']} {report_field} drift"
                                    )
    except (OSError, ValueError, pd.errors.ParserError) as exc:
        backfill_errors.append(str(exc))
    add_release_check(
        rows,
        "dictionary:metadata_backfills_approved",
        not backfill_errors,
        value=f"errors={len(backfill_errors)}",
        expected="zero unapproved or incompletely documented backfills",
        evidence=backfill_path,
        root=root,
        repo=repo,
        details="; ".join(backfill_errors[:8]),
    )


def validate_harmonization(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    years: list[int],
) -> None:
    directory = root / "Checks" / "v2" / "harmonize_qc"
    classification_errors: list[str] = []
    reconciliation_errors: list[str] = []
    inventory_rows = 0
    for year in years:
        try:
            coverage = strict_csv(directory / f"source_column_coverage_{year}.csv")
            summary = strict_csv(directory / f"harmonize_summary_{year}.csv")
            dropped = strict_csv(directory / f"dropped_missing_unitid_{year}.csv")
            if coverage.empty or summary.empty:
                classification_errors.append(f"year {year}: empty coverage/summary")
                continue
            inventory_rows += len(coverage)
            invalid_coverage = (
                ~coverage["reviewed"].map(truthy)
                | coverage["resolution"].str.lower().ne("classified")
                | coverage["role"].str.lower().isin({"", "unknown"})
            )
            if invalid_coverage.any():
                classification_errors.append(f"year {year}: unresolved columns={int(invalid_coverage.sum())}")
            read_counts = pd.to_numeric(summary["source_rows_read"], errors="coerce")
            written_counts = pd.to_numeric(summary["source_rows_written"], errors="coerce")
            mismatch = read_counts.isna() | written_counts.isna() | read_counts.ne(written_counts)
            if mismatch.any():
                reconciliation_errors.append(f"year {year}: source-row mismatches={int(mismatch.sum())}")
            if not dropped.empty:
                dropped_count = pd.to_numeric(
                    dropped.get("dropped_rows_missing_UNITID"),
                    errors="coerce",
                ).fillna(0).sum()
                if dropped_count:
                    reconciliation_errors.append(f"year {year}: dropped missing-UNITID rows={int(dropped_count)}")
        except (OSError, KeyError, ValueError, pd.errors.ParserError) as exc:
            classification_errors.append(f"year {year}: {exc}")
            reconciliation_errors.append(f"year {year}: {exc}")
    add_release_check(
        rows,
        "harmonize:all_source_columns_classified",
        not classification_errors,
        value=f"inventory_rows={inventory_rows}; errors={len(classification_errors)}",
        expected="all nonempty source columns are reviewed and classified",
        evidence=directory,
        root=root,
        repo=repo,
        details="; ".join(classification_errors[:8]),
    )
    add_release_check(
        rows,
        "harmonize:source_rows_reconciled_without_skips",
        not reconciliation_errors,
        value=f"errors={len(reconciliation_errors)}",
        expected="source rows read equal rows retained in the lossless source-row ledger",
        evidence=directory,
        root=root,
        repo=repo,
        details="; ".join(reconciliation_errors[:8]),
    )


def parquet_key_result(path: Path, key: list[str], years: list[int]) -> tuple[bool, int, str]:
    if not path.is_file():
        return False, 0, "artifact is missing"
    dataset = ds.dataset(str(path), format="parquet")
    missing = sorted(set([*key, "year"]) - set(dataset.schema.names))
    if missing:
        return False, 0, "missing columns=" + ",".join(missing)
    escaped = str(path).replace("'", "''")
    quoted = [f'"{column.replace(chr(34), chr(34) * 2)}"' for column in key]
    con = duckdb.connect()
    try:
        observed_years = [
            int(value[0])
            for value in con.execute(
                f"SELECT DISTINCT year FROM read_parquet('{escaped}') WHERE year IS NOT NULL ORDER BY year"
            ).fetchall()
        ]
        total = int(con.execute(f"SELECT COUNT(*) FROM read_parquet('{escaped}')").fetchone()[0])
        null_predicates = [
            f"{column} IS NULL OR TRIM(CAST({column} AS VARCHAR)) = ''"
            for column in quoted
        ]
        invalid = int(
            con.execute(
                f"SELECT COUNT(*) FROM read_parquet('{escaped}') WHERE " + " OR ".join(null_predicates)
            ).fetchone()[0]
        )
        key_sql = ", ".join(quoted)
        duplicates = int(
            con.execute(
                "SELECT COALESCE(SUM(rows - 1), 0) FROM ("
                f"SELECT COUNT(*) AS rows FROM read_parquet('{escaped}') "
                f"GROUP BY {key_sql} HAVING COUNT(*) > 1) q"
            ).fetchone()[0]
        )
    finally:
        con.close()
    failures: list[str] = []
    if observed_years != years:
        failures.append(f"years={observed_years}")
    if total <= 0:
        failures.append("zero rows")
    if invalid:
        failures.append(f"blank/null key cells={invalid}")
    if duplicates:
        failures.append(f"duplicate keys={duplicates}")
    return not failures, total, "; ".join(failures)


def validate_panel_artifacts(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    years: list[int],
    paths: dict[str, str],
) -> None:
    keys = {
        "scalar": ["UNITID", "year", "variable_id", "source_file"],
        "dimensioned": [
            "UNITID",
            "year",
            "source_file",
            "access_table_name",
            "dimension_key",
            "variable_id",
        ],
        "source_rows": ["contract_id", "year", "source_file", "access_table_name", "source_row_id"],
        "analysis_wide": ["UNITID", "year"],
        "raw_wide": ["UNITID", "year"],
        "clean": ["UNITID", "year"],
    }
    counts: dict[str, int] = {}
    for label, key in keys.items():
        path = root / paths[label]
        try:
            passed, count, details = parquet_key_result(path, key, years)
        except (OSError, ValueError, duckdb.Error) as exc:
            passed, count, details = False, 0, str(exc)
        counts[label] = count
        add_release_check(
            rows,
            f"panel:{label}_scientific_key",
            passed,
            value=f"rows={count}",
            expected=f"nonempty; exact years; unique nonblank key={','.join(key)}",
            evidence=path,
            root=root,
            repo=repo,
            details=details,
        )


def scalar_values_equal(left: object, right: object) -> bool:
    if left is None or right is None:
        return left is None and right is None
    try:
        if bool(pd.isna(left)) or bool(pd.isna(right)):
            return bool(pd.isna(left)) and bool(pd.isna(right))
    except (TypeError, ValueError):
        pass
    return bool(left == right)


def validate_cleaning_reconciliation(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    paths: dict[str, str],
) -> None:
    raw_path = root / paths["raw_wide"]
    clean_path = root / paths["clean"]
    actions_path = root / paths["cleaning_changes"]
    errors: list[str] = []
    changed_cells = 0
    try:
        raw = ds.dataset(str(raw_path), format="parquet")
        clean = ds.dataset(str(clean_path), format="parquet")
        if not raw.schema.equals(clean.schema, check_metadata=False):
            raise ValueError("raw/clean Arrow schemas differ")
        if raw.schema.names != clean.schema.names:
            raise ValueError("raw/clean column order differs")
        actions_table = ds.dataset(str(actions_path), format="parquet").to_table()
        if actions_table.column_names != PRCH_ACTION_COLUMNS:
            raise ValueError("cleaning action ledger schema or column order is invalid")
        if actions_table.num_rows <= 0:
            raise ValueError("cleaning action ledger is empty")
        actions: dict[tuple[int, int, str], dict[str, object]] = {}
        for record in actions_table.to_pylist():
            key = (int(record["year"]), int(record["UNITID"]), str(record["column"]))
            if key in actions:
                raise ValueError(f"cleaning action ledger repeats cell {key}")
            if key[2] not in raw.schema.names:
                raise ValueError(f"cleaning action targets an unknown column: {key[2]}")
            if str(record["action"]).strip().lower() != "null" or record["new_value"] is not None:
                raise ValueError(f"cleaning action is not an exact old-to-null transition: {key}")
            actions[key] = record

        raw_iter = iter(raw.to_batches(batch_size=50_000))
        clean_iter = iter(clean.to_batches(batch_size=50_000))
        raw_batch = next(raw_iter, None)
        clean_batch = next(clean_iter, None)
        raw_offset = clean_offset = 0
        observed_changes: set[tuple[int, int, str]] = set()
        names = raw.schema.names
        year_index = names.index("year")
        unitid_index = names.index("UNITID")
        row_count = 0
        while raw_batch is not None and clean_batch is not None:
            count = min(
                raw_batch.num_rows - raw_offset,
                clean_batch.num_rows - clean_offset,
            )
            raw_slice = raw_batch.slice(raw_offset, count)
            clean_slice = clean_batch.slice(clean_offset, count)
            row_count += count
            raw_years = raw_slice.column(year_index).to_pylist()
            raw_unitids = raw_slice.column(unitid_index).to_pylist()
            if raw_years != clean_slice.column(year_index).to_pylist() or raw_unitids != clean_slice.column(
                unitid_index
            ).to_pylist():
                raise ValueError("raw/clean exact key equality and order failed")
            for column_index, column in enumerate(names):
                raw_array = raw_slice.column(column_index)
                clean_array = clean_slice.column(column_index)
                if raw_array.equals(clean_array):
                    continue
                for row_index, (raw_value, clean_value) in enumerate(
                    zip(raw_array.to_pylist(), clean_array.to_pylist(), strict=True)
                ):
                    if scalar_values_equal(raw_value, clean_value):
                        continue
                    key = (int(raw_years[row_index]), int(raw_unitids[row_index]), column)
                    action = actions.get(key)
                    if action is None:
                        raise ValueError(f"unrecorded raw-to-clean value change: {key}")
                    if raw_value is None or clean_value is not None:
                        raise ValueError(f"non-null-policy raw-to-clean value change: {key}")
                    if str(raw_value) != str(action["old_value"]):
                        raise ValueError(f"cleaning action old_value differs from raw panel: {key}")
                    observed_changes.add(key)
            raw_offset += count
            clean_offset += count
            if raw_offset == raw_batch.num_rows:
                raw_batch = next(raw_iter, None)
                raw_offset = 0
            if clean_offset == clean_batch.num_rows:
                clean_batch = next(clean_iter, None)
                clean_offset = 0
        if raw_batch is not None or clean_batch is not None or row_count <= 0:
            raise ValueError("raw/clean row counts differ or are empty")
        if observed_changes != set(actions):
            missing = len(set(actions) - observed_changes)
            extra = len(observed_changes - set(actions))
            raise ValueError(f"cleaning action cell set differs: missing={missing} extra={extra}")
        changed_cells = len(observed_changes)
    except (OSError, KeyError, TypeError, ValueError, duckdb.Error) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "panel:row_preservation_through_cleaning",
        not errors,
        value=f"changed_cells={changed_cells}; errors={len(errors)}",
        expected="identical ordered keys/schema and only ledger-recorded old-to-null cell changes",
        evidence=actions_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:10]),
    )


def validate_source_row_lineage(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    paths: dict[str, str],
) -> None:
    scalar = root / paths["scalar"]
    dimensioned = root / paths["dimensioned"]
    source_rows = root / paths["source_rows"]
    errors: list[str] = []
    cell_count = 0
    malformed_arrays = 0
    invalid_members = 0
    invalid_source_identities = 0
    raw_value_mismatches = 0
    try:
        if not all(path.is_file() for path in (scalar, dimensioned, source_rows)):
            raise ValueError("one or more long/source-row artifacts are missing")
        scalar_sql = str(scalar).replace("'", "''")
        dimensioned_sql = str(dimensioned).replace("'", "''")
        source_sql = str(source_rows).replace("'", "''")
        con = duckdb.connect()
        try:
            con.execute(
                f"""
                CREATE TEMP TABLE acceptance_long_cells AS
                WITH combined AS (
                    SELECT 'scalar' AS cell_lane, contract_id, UNITID, year, source_file,
                           access_table_name, source_row_id, source_row_hash,
                           source_row_ordinal, source_csv_sha256, dimension_key, dimension_json,
                           source_duplicate_count, source_row_ids_json,
                           source_row_ordinals_json, varname, raw_value
                    FROM read_parquet('{scalar_sql}')
                    UNION ALL
                    SELECT 'dimensioned' AS cell_lane, contract_id, UNITID, year, source_file,
                           access_table_name, source_row_id, source_row_hash,
                           source_row_ordinal, source_csv_sha256, dimension_key, dimension_json,
                           source_duplicate_count, source_row_ids_json,
                           source_row_ordinals_json, varname, raw_value
                    FROM read_parquet('{dimensioned_sql}')
                )
                SELECT ROW_NUMBER() OVER () AS acceptance_cell_id, *
                FROM combined
                """
            )
            query = f"""
                WITH representative_matches AS (
                    SELECT
                        c.acceptance_cell_id,
                        COUNT(s.source_row_id) AS matches,
                        COUNT(*) FILTER (
                            WHERE s.source_row_id IS NOT NULL
                              AND (
                                  c.contract_id <> s.contract_id
                                  OR c.UNITID <> s.UNITID
                                  OR c.source_row_hash <> s.source_row_hash
                                  OR c.source_row_ordinal <> s.source_row_ordinal
                                  OR c.source_csv_sha256 <> s.source_csv_sha256
                                  OR c.source_duplicate_count <> s.source_duplicate_count
                                  OR c.source_row_ids_json <> s.source_row_ids_json
                                  OR c.source_row_ordinals_json <> s.source_row_ordinals_json
                                  OR c.dimension_key <> s.dimension_key
                                  OR c.dimension_json <> s.dimension_json
                              )
                        ) AS inconsistent_matches
                    FROM acceptance_long_cells c
                    LEFT JOIN read_parquet('{source_sql}') s
                      ON c.contract_id = s.contract_id
                     AND c.year = s.year
                     AND c.source_file = s.source_file
                     AND c.access_table_name = s.access_table_name
                     AND c.source_row_id = s.source_row_id
                    GROUP BY c.acceptance_cell_id
                )
                SELECT
                    COUNT(*) AS cells,
                    COUNT(*) FILTER (
                        WHERE matches <> 1 OR inconsistent_matches <> 0
                    ) AS invalid_cells
                FROM representative_matches
            """
            cell_count, invalid = (int(value) for value in con.execute(query).fetchone())
            malformed_arrays, invalid_members = (
                int(value)
                for value in con.execute(
                    f"""
                    WITH array_shape AS (
                        SELECT
                            acceptance_cell_id,
                            source_duplicate_count,
                            TRY_CAST(JSON_ARRAY_LENGTH(source_row_ids_json) AS BIGINT)
                                AS id_count,
                            TRY_CAST(JSON_ARRAY_LENGTH(source_row_ordinals_json) AS BIGINT)
                                AS ordinal_count
                        FROM acceptance_long_cells
                    ), expanded AS (
                        SELECT
                            c.acceptance_cell_id,
                            ids.key AS array_index,
                            JSON_EXTRACT_STRING(
                                c.source_row_ids_json,
                                '$[' || ids.key || ']'
                            ) AS linked_source_row_id,
                            TRY_CAST(
                                JSON_EXTRACT_STRING(
                                    c.source_row_ordinals_json,
                                    '$[' || ids.key || ']'
                                ) AS BIGINT
                            ) AS linked_source_row_ordinal,
                            c.contract_id,
                            c.year,
                            c.source_file,
                            c.access_table_name,
                            c.source_csv_sha256,
                            c.source_row_hash,
                            c.source_duplicate_count,
                            c.source_row_ids_json,
                            c.source_row_ordinals_json,
                            c.dimension_key,
                            c.dimension_json
                        FROM acceptance_long_cells c,
                             JSON_EACH(c.source_row_ids_json) ids
                    ), member_matches AS (
                        SELECT
                            e.acceptance_cell_id,
                            e.array_index,
                            COUNT(s.source_row_id) AS matches,
                            COUNT(*) FILTER (
                                WHERE s.source_row_id IS NOT NULL
                                  AND (
                                      e.source_duplicate_count <> s.source_duplicate_count
                                      OR e.source_row_ids_json <> s.source_row_ids_json
                                      OR e.source_row_ordinals_json <> s.source_row_ordinals_json
                                      OR e.dimension_key <> s.dimension_key
                                      OR e.dimension_json <> s.dimension_json
                                  )
                            ) AS inconsistent_matches
                        FROM expanded e
                        LEFT JOIN read_parquet('{source_sql}') s
                          ON e.contract_id = s.contract_id
                         AND e.year = s.year
                         AND e.source_file = s.source_file
                         AND e.access_table_name = s.access_table_name
                         AND e.source_csv_sha256 = s.source_csv_sha256
                         AND e.source_row_hash = s.source_row_hash
                         AND e.linked_source_row_id = s.source_row_id
                         AND e.linked_source_row_ordinal = s.source_row_ordinal
                        GROUP BY e.acceptance_cell_id, e.array_index
                    )
                    SELECT
                        (
                            SELECT COUNT(*)
                            FROM array_shape
                            WHERE source_duplicate_count IS NULL
                               OR source_duplicate_count <= 0
                               OR id_count IS NULL
                               OR ordinal_count IS NULL
                               OR id_count <> source_duplicate_count
                               OR ordinal_count <> source_duplicate_count
                        ) AS malformed_arrays,
                        (
                            SELECT COUNT(*)
                            FROM member_matches
                            WHERE matches <> 1 OR inconsistent_matches <> 0
                        ) AS invalid_members
                    """
                ).fetchone()
            )
            invalid_source_identities = int(
                con.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM read_parquet('{source_sql}')
                    WHERE source_row_hash <> SHA256(source_row_json)
                       OR dimension_key <> SHA256(dimension_json)
                       OR source_row_id <> SHA256(
                           contract_id || CHR(0)
                           || CAST(year AS VARCHAR) || CHR(0)
                           || source_csv_sha256 || CHR(0)
                           || UPPER(TRIM(source_file)) || CHR(0)
                           || UPPER(TRIM(access_table_name)) || CHR(0)
                           || CAST(source_row_ordinal AS VARCHAR) || CHR(0)
                           || source_row_hash
                       )
                    """
                ).fetchone()[0]
            )
            raw_value_mismatches = int(
                con.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM acceptance_long_cells c
                    INNER JOIN read_parquet('{source_sql}') s
                      ON c.contract_id = s.contract_id
                     AND c.year = s.year
                     AND c.source_file = s.source_file
                     AND c.access_table_name = s.access_table_name
                     AND c.source_row_id = s.source_row_id
                    WHERE JSON_TYPE(s.source_row_json, c.varname) IS NULL
                       OR COALESCE(CAST(c.raw_value AS VARCHAR), '')
                            <> COALESCE(JSON_EXTRACT_STRING(s.source_row_json, c.varname), '')
                    """
                ).fetchone()[0]
            )
        finally:
            con.close()
        if cell_count <= 0:
            errors.append("long-cell artifacts are empty")
        if invalid:
            errors.append(f"orphaned or inconsistent cell/source-row links={invalid}")
        if malformed_arrays:
            errors.append(f"malformed duplicate-source arrays={malformed_arrays}")
        if invalid_members:
            errors.append(f"unreconciled physical duplicate-source members={invalid_members}")
        if invalid_source_identities:
            errors.append(f"invalid recomputed source-row identities={invalid_source_identities}")
        if raw_value_mismatches:
            errors.append(f"long-cell/source-token mismatches={raw_value_mismatches}")
    except (OSError, ValueError, duckdb.Error) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "lineage:long_cells_match_lossless_source_rows",
        not errors,
        value=f"cells={cell_count}; errors={len(errors)}",
        expected="every scalar and dimensioned cell matches exactly one physical source-row identity",
        evidence=source_rows,
        root=root,
        repo=repo,
        details="; ".join(errors[:8]),
    )


def validate_wide_value_lineage(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    paths: dict[str, str],
    years: list[int],
    contract_id: str,
) -> None:
    panel_path = root / paths["analysis_wide"]
    lineage_path = root / paths["lineage"]
    errors: list[str] = []
    lineage_rows = 0
    try:
        panel = ds.dataset(str(panel_path), format="parquet")
        lineage = ds.dataset(str(lineage_path), format="parquet")
        required = {
            "contract_id",
            "UNITID",
            "year",
            "analysis_column",
            "variable_id",
            "source_varnumber",
            "varname",
            "source_row_id",
            "source_row_hash",
            "source_file",
            "access_table_name",
            "transformation_id",
            "normalized_value",
            "output_normalized_value",
            "lineage_role",
        }
        missing = sorted(required - set(lineage.schema.names))
        if missing:
            raise ValueError("value lineage lacks fields=" + ",".join(missing))
        analysis_columns = [name for name in panel.schema.names if name not in {"UNITID", "year"}]
        if not analysis_columns:
            raise ValueError("analysis-wide panel has no analysis columns")
        panel_sql = str(panel_path).replace("'", "''")
        lineage_sql = str(lineage_path).replace("'", "''")
        analysis_schema = strict_csv(repo / paths["analysis_schema"])
        if analysis_schema.empty:
            raise ValueError("reviewed analysis schema is empty")
        if not {"contract_id", "analysis_column", "logical_type", "status"}.issubset(
            analysis_schema.columns
        ):
            raise ValueError("reviewed analysis schema lacks value-reconciliation fields")
        approved_types = analysis_schema.loc[
            analysis_schema["status"].str.lower().eq("approved"),
            ["contract_id", "analysis_column", "logical_type"],
        ].copy()
        if approved_types.empty or approved_types["analysis_column"].duplicated().any():
            raise ValueError("reviewed analysis schema is empty or repeats analysis columns")
        if not approved_types["contract_id"].eq(contract_id).all():
            raise ValueError("reviewed analysis schema is bound to another contract")
        con = duckdb.connect()
        try:
            con.register("acceptance_analysis_types", approved_types)
            lineage_rows = int(
                con.execute(f"SELECT COUNT(*) FROM read_parquet('{lineage_sql}')").fetchone()[0]
            )
            observed_years = [
                int(value[0])
                for value in con.execute(
                    f"SELECT DISTINCT year FROM read_parquet('{lineage_sql}') ORDER BY year"
                ).fetchall()
            ]
            blank_identities = int(
                con.execute(
                    f"""
                    SELECT COUNT(*) FROM read_parquet('{lineage_sql}')
                    WHERE UNITID IS NULL OR year IS NULL
                       OR COALESCE(TRIM(contract_id), '') = ''
                       OR COALESCE(TRIM(analysis_column), '') = ''
                       OR COALESCE(TRIM(variable_id), '') = ''
                       OR COALESCE(TRIM(source_row_id), '') = ''
                       OR COALESCE(TRIM(source_row_hash), '') = ''
                       OR COALESCE(TRIM(source_file), '') = ''
                       OR COALESCE(TRIM(access_table_name), '') = ''
                       OR COALESCE(TRIM(transformation_id), '') = ''
                       OR COALESCE(TRIM(lineage_role), '') = ''
                    """
                ).fetchone()[0]
            )
            duplicate_keys = int(
                con.execute(
                    f"""
                    SELECT COALESCE(SUM(rows - 1), 0) FROM (
                        SELECT COUNT(*) AS rows
                        FROM read_parquet('{lineage_sql}')
                        GROUP BY UNITID, year, analysis_column, variable_id, source_row_id
                        HAVING COUNT(*) > 1
                    ) q
                    """
                ).fetchone()[0]
            )
            orphan_keys = int(
                con.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM read_parquet('{lineage_sql}') l
                    LEFT JOIN read_parquet('{panel_sql}') p USING (UNITID, year)
                    WHERE p.UNITID IS NULL
                    """
                ).fetchone()[0]
            )
            wrong_contract_rows = int(
                con.execute(
                    f"""
                    SELECT COUNT(*) FROM read_parquet('{lineage_sql}')
                    WHERE contract_id <> ?
                    """,
                    [contract_id],
                ).fetchone()[0]
            )
            coverage_rows = con.execute(
                f"""
                SELECT analysis_column, COUNT(DISTINCT (UNITID, year)) AS cells
                FROM read_parquet('{lineage_sql}')
                GROUP BY analysis_column
                """
            ).fetchall()
            missing_nonnull_cells = int(
                con.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM (
                        UNPIVOT read_parquet('{panel_sql}')
                        ON COLUMNS(* EXCLUDE (UNITID, year))::VARCHAR
                        INTO NAME analysis_column VALUE panel_value
                    ) p
                    LEFT JOIN (
                        SELECT DISTINCT UNITID, year, analysis_column
                        FROM read_parquet('{lineage_sql}')
                    ) l USING (UNITID, year, analysis_column)
                    WHERE l.UNITID IS NULL
                    """
                ).fetchone()[0]
            )
            mismatched_value_cells = int(
                con.execute(
                    f"""
                    WITH panel_cells AS (
                        UNPIVOT read_parquet('{panel_sql}')
                        ON COLUMNS(* EXCLUDE (UNITID, year))::VARCHAR
                        INTO NAME analysis_column VALUE panel_value
                    ), lineage_cells AS (
                        SELECT
                            UNITID,
                            year,
                            analysis_column,
                            COUNT(DISTINCT output_normalized_value) AS distinct_outputs,
                            MIN(output_normalized_value) AS output_value
                        FROM read_parquet('{lineage_sql}')
                        GROUP BY UNITID, year, analysis_column
                    )
                    SELECT COUNT(*)
                    FROM panel_cells p
                    LEFT JOIN lineage_cells l USING (UNITID, year, analysis_column)
                    LEFT JOIN acceptance_analysis_types t USING (analysis_column)
                    WHERE l.UNITID IS NULL
                       OR t.analysis_column IS NULL
                       OR l.distinct_outputs <> 1
                       OR NOT CASE
                           WHEN t.logical_type = 'integer' THEN
                               TRY_CAST(p.panel_value AS BIGINT)
                                   = TRY_CAST(l.output_value AS BIGINT)
                           WHEN t.logical_type = 'decimal' THEN
                               TRY_CAST(p.panel_value AS DECIMAL(38, 10))
                                   = TRY_CAST(l.output_value AS DECIMAL(38, 10))
                           WHEN t.logical_type = 'float' THEN
                               TRY_CAST(p.panel_value AS DOUBLE)
                                   = TRY_CAST(l.output_value AS DOUBLE)
                           WHEN t.logical_type = 'boolean' THEN
                               LOWER(p.panel_value) = CASE
                                   WHEN LOWER(l.output_value) IN ('1', 'true', 'yes', 'y')
                                       THEN 'true'
                                   WHEN LOWER(l.output_value) IN ('0', 'false', 'no', 'n')
                                       THEN 'false'
                                   ELSE NULL
                               END
                           ELSE p.panel_value = l.output_value
                       END
                    """
                ).fetchone()[0]
            )
        finally:
            con.close()
        lineage_cells = {str(column): int(count) for column, count in coverage_rows}
        if observed_years != years:
            errors.append(f"lineage years={observed_years}")
        if lineage_rows <= 0:
            errors.append("value lineage is empty")
        if blank_identities:
            errors.append(f"blank scientific identity rows={blank_identities}")
        if duplicate_keys:
            errors.append(f"duplicate lineage keys={duplicate_keys}")
        if orphan_keys:
            errors.append(f"lineage rows with orphan panel keys={orphan_keys}")
        if wrong_contract_rows:
            errors.append(f"lineage rows bound to another contract={wrong_contract_rows}")
        if set(lineage_cells) != set(analysis_columns):
            errors.append("lineage analysis-column set differs from the panel schema")
        if missing_nonnull_cells:
            errors.append(f"nonnull panel cells without exact lineage={missing_nonnull_cells}")
        if mismatched_value_cells:
            errors.append(f"panel cells with stale or incorrect lineage values={mismatched_value_cells}")
    except (OSError, ValueError, duckdb.Error) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "lineage:wide_values_have_current_source_evidence",
        not errors,
        value=f"lineage_rows={lineage_rows}; errors={len(errors)}",
        expected="complete nonblank, unique, nonorphan value lineage for every analysis column/cell",
        evidence=lineage_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:20]),
    )


def validate_wide_qc(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    contract_id: str,
    lineage_path: Path,
    paths: dict[str, str],
) -> None:
    directory = lineage_path.parent
    summary_path = directory / "wide_panel_qc_summary.csv"
    errors: list[str] = []
    try:
        if not directory.is_symlink():
            errors.append("wide-QC directory is not a managed projection symlink")
        resolved_directory = directory.resolve(strict=True)
        observed_files = {path.name for path in resolved_directory.iterdir() if path.is_file()}
        if observed_files != WIDE_QC_EXPECTED_FILES:
            errors.append(
                "wide-QC inventory mismatch: "
                f"missing={sorted(WIDE_QC_EXPECTED_FILES - observed_files)} "
                f"extra={sorted(observed_files - WIDE_QC_EXPECTED_FILES)}"
            )
        for name, expected_columns in WIDE_QC_CSV_SCHEMAS.items():
            frame = strict_csv(directory / name)
            if list(frame.columns) != expected_columns:
                errors.append(f"wide-QC schema drift: {name}")

        run_directory = resolved_directory.parents[1]
        bundle_manifest_path = run_directory / "bundle_manifest.csv"
        bundle_manifest = strict_csv(bundle_manifest_path)
        if list(bundle_manifest.columns) != ["relative_path", "bytes", "sha256"]:
            errors.append("wide release bundle manifest schema is invalid")
        elif bundle_manifest["relative_path"].duplicated().any():
            errors.append("wide release bundle manifest repeats paths")
        else:
            declared_files = set(bundle_manifest["relative_path"])
            actual_files = {
                path.relative_to(run_directory).as_posix()
                for path in run_directory.rglob("*")
                if path.is_file() and path != bundle_manifest_path
            }
            if declared_files != actual_files:
                errors.append("wide release bundle manifest inventory is not exact")
            for record in bundle_manifest.to_dict("records"):
                artifact = run_directory / str(record["relative_path"])
                if (
                    not artifact.is_file()
                    or str(artifact.stat().st_size) != str(record["bytes"])
                    or sha256_file(artifact) != str(record["sha256"])
                ):
                    errors.append(f"wide release bundle binding is stale: {record['relative_path']}")

        summary = strict_csv(summary_path)
        if len(summary) != 1:
            raise ValueError(f"wide summary rows={len(summary)}")
        record = summary.iloc[0]
        expected = {
            "contract_id": contract_id,
            "build_mode": "release",
            "unresolved_conflicts": "0",
            "unresolved_casts": "0",
            "schema_contract": paths["analysis_schema"],
            "discrete_contract": paths["discrete_families"],
            "output": paths["analysis_wide"],
        }
        for field, expected_value in expected.items():
            if str(record.get(field, "")).strip().lower() != expected_value.lower():
                errors.append(f"{field}={record.get(field, '')!r}")
        coverage = strict_csv(directory / "qc_canonical_column_coverage.csv")
        eligible = pd.to_numeric(coverage["eligible_value_rows"], errors="coerce")
        nonnull = pd.to_numeric(coverage["non_null_value_rows"], errors="coerce")
        invalid_coverage = coverage.empty or eligible.isna().any() or (eligible <= 0).any() or (nonnull <= 0).any()
        if invalid_coverage:
            errors.append("canonical analysis coverage contains missing/all-null columns")
        exclusions = strict_csv(directory / "qc_analysis_schema_exclusions.csv")
        if not exclusions.empty:
            exclusion_eligible = pd.to_numeric(
                exclusions["eligible_rows"], errors="coerce"
            )
            exclusion_nonnull = pd.to_numeric(
                exclusions["non_null_rows"], errors="coerce"
            )
            invalid_exclusions = (
                exclusion_eligible.isna().any()
                or (exclusion_eligible <= 0).any()
                or exclusion_nonnull.isna().any()
                or (exclusion_nonnull != 0).any()
                or not exclusions["status"].eq("excluded_all_null").all()
                or not exclusions["exclusion_reason"].eq("no_observed_values").all()
            )
            if invalid_exclusions:
                errors.append("analysis-schema exclusion evidence is invalid")
        cast_summary = strict_csv(directory / "qc_cast_summary.csv")
        if not cast_summary.empty and "cast_status" in cast_summary:
            invalid_casts = pd.to_numeric(
                cast_summary.loc[cast_summary["cast_status"].str.lower() == "invalid", "rows"],
                errors="coerce",
            ).fillna(0).sum()
            if invalid_casts:
                errors.append(f"invalid casts={int(invalid_casts)}")
        lane = strict_csv(directory / "qc_lane_coverage.csv")
        if lane.empty:
            errors.append("lane-coverage ledger is empty")
    except (OSError, KeyError, ValueError, pd.errors.ParserError) as exc:
        errors.append(str(exc))

    issue_rows = 0
    for name in sorted(WIDE_QC_ZERO_ISSUE_FILES):
        path = directory / name
        if not path.is_file():
            errors.append(f"missing required zero-issue ledger: {name}")
            continue
        try:
            frame = strict_csv(path)
            issue_rows += len(frame)
            if not frame.empty:
                errors.append(f"{name} rows={len(frame)}")
        except (OSError, ValueError, pd.errors.ParserError) as exc:
            errors.append(f"{name}: {exc}")
    add_release_check(
        rows,
        "wide:semantic_release_qc",
        not errors,
        value=f"issue_rows={issue_rows}; errors={len(errors)}",
        expected="release build, complete non-null schema, zero unresolved conflicts/casts/discrete issues",
        evidence=summary_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:10]),
    )


def validate_panel_qa(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    summary_path: Path,
) -> None:
    errors: list[str] = []
    try:
        pointer = summary_path.parent
        if not pointer.is_symlink():
            errors.append("panel QA bundle is not an atomic managed pointer")
        resolved = pointer.resolve(strict=True)
        expected_files = {
            "panel_qa_summary.csv",
            "panel_qa_coverage_matrix.csv",
            "panel_qa_by_flag_code.csv",
            "panel_qa_action_reconciliation.csv",
            "panel_qa_evidence_checks.csv",
            "panel_qa_run_manifest.json",
        }
        observed_files = {path.name for path in resolved.iterdir() if path.is_file()}
        if observed_files != expected_files:
            errors.append("panel QA bundle inventory is incomplete or contains extra files")
        qa_manifest = strict_json(resolved / "panel_qa_run_manifest.json")
        manifest_expectations = {
            "status": "complete",
            "qa_status": "pass",
            "qa_mode": "release",
            "release_eligible": True,
        }
        for field, expected in manifest_expectations.items():
            if qa_manifest.get(field) != expected:
                errors.append(f"panel QA manifest {field} is invalid")
        artifact_records = qa_manifest.get("artifacts", [])
        if not isinstance(artifact_records, list):
            errors.append("panel QA artifact inventory is malformed")
            artifact_records = []
        declared = {
            str(record.get("name", "")): record
            for record in artifact_records
            if isinstance(record, dict)
        }
        if set(declared) != expected_files - {"panel_qa_run_manifest.json"}:
            errors.append("panel QA manifest artifact inventory is incomplete")
        for name, record in declared.items():
            artifact = resolved / name
            if (
                not artifact.is_file()
                or record.get("sha256") != sha256_file(artifact)
                or record.get("bytes") != artifact.stat().st_size
            ):
                errors.append(f"panel QA artifact binding is stale: {name}")
        summary = strict_csv(summary_path)
        if len(summary) != 1:
            raise ValueError(f"panel QA summary rows={len(summary)}")
        record = summary.iloc[0]
        expectations = {
            "qa_mode": "release",
            "status": "pass",
            "release_eligible": "true",
            "suspicious_flags": "0",
            "no_target_flags": "0",
        }
        for field, expected in expectations.items():
            observed = str(record.get(field, "")).strip().lower()
            if field == "release_eligible":
                valid = truthy(observed)
            else:
                valid = observed == expected
            if not valid:
                errors.append(f"{field}={observed!r}")
        if int(float(record.get("raw_rows", "0") or 0)) != int(float(record.get("clean_rows", "-1") or -1)):
            errors.append("raw_rows and clean_rows differ")
        if int(float(record.get("action_rows", "0") or 0)) <= 0:
            errors.append("cell-action evidence is empty")
        evidence_checks = strict_csv(summary_path.parent / "panel_qa_evidence_checks.csv")
        expected_evidence_ids = {
            "managed_run_pointer",
            "run_manifest",
            "policy_binding",
            "raw_clean_schema_rows_keys",
            "resolved_policy_rows",
            "flag_code_counts",
            "clean_summary",
            "cell_actions",
            "unaffected_values",
        }
        if (
            evidence_checks.empty
            or set(evidence_checks.get("check_id", pd.Series(dtype=str))) != expected_evidence_ids
            or not evidence_checks["status"].str.lower().eq("pass").all()
        ):
            errors.append("panel QA evidence checks are empty or not all pass")
        for name in expected_files - {"panel_qa_run_manifest.json"}:
            frame = strict_csv(resolved / name)
            if frame.empty:
                errors.append(f"panel QA artifact is empty: {name}")
                continue
            bindings = {
                "qa_run_id": qa_manifest.get("qa_run_id"),
                "prch_run_id": qa_manifest.get("prch_run_id"),
                "prch_manifest_sha256": qa_manifest.get("prch_manifest_sha256"),
            }
            for field, expected in bindings.items():
                if field not in frame or set(frame[field]) != {str(expected)}:
                    errors.append(f"panel QA {name} has a stale {field} binding")
    except (OSError, KeyError, ValueError, pd.errors.ParserError) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "prch:managed_semantic_qa",
        not errors,
        value=f"errors={len(errors)}",
        expected="current managed release QA with exact policy/action reconciliation",
        evidence=summary_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:10]),
    )


def validate_continuity(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    paths: dict[str, str],
    years: list[int] | None = None,
) -> None:
    report_path = root / paths["continuity_verification"]
    manifest_path = root / paths["continuity_manifest"]
    crosswalk_path = root / paths["continuity_crosswalk"]
    lineage_output = root / paths["continuity_value_lineage"]
    panel_path = root / paths["clean"]
    lineage_input = root / paths["lineage"]
    errors: list[str] = []
    try:
        report = strict_json(report_path)
        manifest = strict_json(manifest_path)
        expected_bundle = str(Path(paths["continuity_crosswalk"]).parent)
        expected = {
            "status": "pass",
            "mode": "release",
            "bundle_path": expected_bundle,
        }
        for field, expected_value in expected.items():
            if report.get(field) != expected_value:
                errors.append(f"{field} is stale or invalid")
        if report.get("failures") != []:
            errors.append("continuity verification reports failures")
        pointer = manifest_path.parent
        if not pointer.is_symlink():
            errors.append("continuity bundle is not an atomic managed pointer")
        resolved_bundle = pointer.resolve(strict=True)
        expected_store = (pointer.parent / f".{pointer.name}.runs").resolve()
        if resolved_bundle.parent != expected_store:
            errors.append("continuity pointer targets an unmanaged run store")
        if resolved_bundle.name != manifest.get("run_id"):
            errors.append("continuity run directory does not match its run_id")
        resolved_manifest = (resolved_bundle / "entity_continuity_manifest.json").resolve(
            strict=True
        )
        expected_manifest_path = resolved_manifest.relative_to(root.resolve(strict=True)).as_posix()
        if report.get("continuity_manifest_path") != expected_manifest_path:
            errors.append("continuity_manifest_path is stale or invalid")
        expected_files = {
            "entity_continuity_crosswalk.csv",
            "entity_continuity_manifest.json",
            "entity_continuity_summary.csv",
            "entity_continuity_summary.md",
            "entity_continuity_value_lineage.parquet",
        }
        observed_files = {path.name for path in resolved_bundle.iterdir() if path.is_file()}
        if observed_files != expected_files:
            errors.append("continuity bundle inventory is incomplete or contains extra files")
        manifest_expectations: dict[str, object] = {
            "mode": "release",
            "release_eligible": True,
            "complete_year_scope": True,
            "require_complete_year_scope": True,
            "missing_requested_years": [],
            "builder_path": "Scripts/QA_QC/22_build_entity_continuity_crosswalk.py",
        }
        if years is not None:
            manifest_expectations["requested_years"] = years
            manifest_expectations["observed_years"] = years
        for field, expected_value in manifest_expectations.items():
            if manifest.get(field) != expected_value:
                errors.append(f"continuity manifest {field} is stale or invalid")
        builder = repo / "Scripts" / "QA_QC" / "22_build_entity_continuity_crosswalk.py"
        if manifest.get("builder_sha256") != sha256_file(builder):
            errors.append("continuity builder code hash is stale")
        if report.get("continuity_manifest_sha256") != sha256_file(manifest_path):
            errors.append("continuity manifest hash is stale")
        if report.get("run_id") != manifest.get("run_id"):
            errors.append("continuity run_id does not match its manifest")
        verifier = repo / "Scripts" / "QA_QC" / "23_verify_entity_continuity.py"
        if report.get("verifier_sha256") != sha256_file(verifier):
            errors.append("continuity verifier code hash is stale")
        if report.get("verifier_path") != "Scripts/QA_QC/23_verify_entity_continuity.py":
            errors.append("continuity verifier path is stale")
        inputs = report.get("input_bindings", {})
        if not isinstance(inputs, dict):
            errors.append("continuity input bindings are malformed")
        else:
            expected_inputs = {
                "panel_path": paths["clean"],
                "panel_sha256": sha256_file(panel_path),
                "value_lineage_path": paths["lineage"],
                "value_lineage_sha256": sha256_file(lineage_input),
            }
            for field, expected_value in expected_inputs.items():
                if inputs.get(field) != expected_value:
                    errors.append(f"continuity {field} is stale")
            direct_manifest_inputs = {
                "input_path": paths["clean"],
                "input_sha256": expected_inputs["panel_sha256"],
                "lineage_input_path": paths["lineage"],
                "lineage_input_sha256": expected_inputs["value_lineage_sha256"],
            }
            for field, expected_value in direct_manifest_inputs.items():
                if manifest.get(field) != expected_value:
                    errors.append(f"continuity manifest {field} is stale")
        artifact_records = manifest.get("output_artifacts", [])
        if not isinstance(artifact_records, list):
            artifact_records = []
            errors.append("continuity output artifact inventory is malformed")
        expected_outputs = expected_files - {"entity_continuity_manifest.json"}
        declared_outputs = {
            str(record.get("path", "")): record
            for record in artifact_records
            if isinstance(record, dict)
        }
        if set(declared_outputs) != expected_outputs or len(artifact_records) != len(expected_outputs):
            errors.append("continuity output artifact inventory is not exact")
        if report.get("output_bindings") != artifact_records:
            errors.append("continuity verifier output bindings differ from the manifest")
        for name, record in declared_outputs.items():
            artifact = resolved_bundle / name
            if (
                not artifact.is_file()
                or record.get("sha256") != sha256_file(artifact)
                or record.get("bytes") != artifact.stat().st_size
            ):
                errors.append(f"continuity output binding is stale: {name}")
        crosswalk = strict_csv(crosswalk_path)
        if crosswalk.empty:
            errors.append("continuity crosswalk is empty")
        if not lineage_output.is_file() or ds.dataset(str(lineage_output), format="parquet").count_rows() <= 0:
            errors.append("continuity value lineage is missing or empty")
    except (OSError, KeyError, ValueError, pd.errors.ParserError) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "continuity:independently_verified_current_evidence",
        not errors,
        value=f"errors={len(errors)}",
        expected="release-mode pass report bound to current manifest, code, panel, and Stage 06 lineage",
        evidence=report_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:20]),
    )


def benchmark_filter(raw: str) -> dict[str, object]:
    def reject_duplicates(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate filter key {key!r}")
            result[key] = value
        return result

    value = json.loads(raw, object_pairs_hook=reject_duplicates)
    if not isinstance(value, dict):
        raise ValueError("benchmark filters are not a JSON object")
    for key, expected in value.items():
        if not key:
            raise ValueError("benchmark filter has a blank column")
        values = expected if isinstance(expected, list) else [expected]
        if isinstance(expected, list) and not values:
            raise ValueError(f"benchmark filter {key!r} has an empty list")
        if any(isinstance(item, (dict, list)) for item in values):
            raise ValueError(f"benchmark filter {key!r} is nested")
    return value


def benchmark_years(raw: str) -> list[int]:
    normalized = raw.replace("..", ":")
    parts = normalized.split(":")
    if len(parts) not in {1, 2} or not all(re.fullmatch(r"\d{4}", part) for part in parts):
        raise ValueError(f"invalid benchmark year scope {raw!r}")
    start = int(parts[0])
    end = int(parts[-1])
    if end < start:
        raise ValueError(f"descending benchmark year scope {raw!r}")
    return list(range(start, end + 1))


def benchmark_metric(panel: pd.DataFrame, metric: str, variable: str) -> float:
    if panel.empty:
        raise ValueError("benchmark scope selected zero panel rows")
    if metric == "panel_rows":
        return float(len(panel))
    if metric == "distinct_unitid":
        return float(panel["UNITID"].nunique(dropna=True))
    if metric == "distinct_count":
        return float(panel[variable].nunique(dropna=True))
    if metric == "nonnull_count":
        return float(panel[variable].notna().sum())
    source = panel[variable]
    numeric = pd.to_numeric(source, errors="coerce")
    invalid = source.notna() & numeric.isna()
    if invalid.any():
        raise ValueError(f"numeric benchmark has invalid nonnull tokens={int(invalid.sum())}")
    if metric == "sum":
        value = numeric.sum(skipna=True, min_count=1)
    elif metric == "mean":
        value = numeric.mean(skipna=True)
    else:
        raise ValueError(f"unsupported benchmark metric {metric!r}")
    if pd.isna(value) or not math.isfinite(float(value)):
        raise ValueError("benchmark metric is nonfinite")
    return float(value)


def independently_recompute_benchmarks(
    frame: pd.DataFrame,
    contract: pd.DataFrame,
    panel_path: Path,
) -> list[str]:
    errors: list[str] = []
    copied_fields = [
        column
        for column in BENCHMARK_CONTRACT_COLUMNS
        if column != "benchmark_id"
    ]
    contract_by_id = contract.set_index("benchmark_id", drop=False)
    selected = {"UNITID", "year"}
    parsed: list[tuple[pd.Series, dict[str, object], list[int]]] = []
    for _, result in frame.iterrows():
        benchmark_id = str(result.get("benchmark_id", ""))
        if benchmark_id not in contract_by_id.index:
            errors.append(f"unexpected benchmark result {benchmark_id!r}")
            continue
        reviewed = contract_by_id.loc[benchmark_id]
        if isinstance(reviewed, pd.DataFrame):
            errors.append(f"benchmark contract repeats {benchmark_id!r}")
            continue
        for field in copied_fields:
            if str(result.get(field, "")) != str(reviewed.get(field, "")):
                errors.append(f"benchmark {benchmark_id}: {field} drift")
        try:
            filters = benchmark_filter(str(reviewed["filters"]))
            scope_years = benchmark_years(str(reviewed["year"]))
            selected.add(str(reviewed["variable"]))
            selected.update(filters)
            parsed.append((result, filters, scope_years))
        except (json.JSONDecodeError, ValueError) as exc:
            errors.append(f"benchmark {benchmark_id}: {exc}")
    dataset = ds.dataset(str(panel_path), format="parquet")
    missing = sorted(selected - set(dataset.schema.names))
    if missing:
        return errors + ["benchmark panel columns are missing: " + ",".join(missing)]
    panel = dataset.to_table(columns=sorted(selected)).to_pandas()
    numeric_year = pd.to_numeric(panel["year"], errors="coerce")
    for result, filters, scope_years in parsed:
        benchmark_id = str(result["benchmark_id"])
        try:
            mask = numeric_year.isin(scope_years)
            for column, expected in filters.items():
                values = expected if isinstance(expected, list) else [expected]
                column_mask = pd.Series(False, index=panel.index)
                for value in values:
                    column_mask |= panel[column].isna() if value is None else panel[column].eq(value)
                mask &= column_mask
            actual = benchmark_metric(
                panel.loc[mask],
                str(result["metric"]).lower(),
                str(result["variable"]),
            )
            recorded_actual = float(result["actual_value"])
            expected = float(result["expected_value"])
            absolute = float(result["absolute_tolerance"])
            relative = float(result["relative_tolerance"])
            recorded_delta = float(result["delta"])
            recorded_allowed = float(result["allowed_delta"])
            values = [actual, recorded_actual, expected, absolute, relative, recorded_delta, recorded_allowed]
            if not all(math.isfinite(value) for value in values):
                raise ValueError("reconciliation contains a nonfinite number")
            allowed = max(absolute, abs(expected) * relative)
            if absolute < 0 or relative < 0:
                raise ValueError("reconciliation contains a negative tolerance")
            if not math.isclose(recorded_actual, actual, rel_tol=1e-12, abs_tol=1e-9):
                raise ValueError("recorded actual differs from independent recomputation")
            if not math.isclose(recorded_delta, actual - expected, rel_tol=1e-12, abs_tol=1e-9):
                raise ValueError("recorded delta is incorrect")
            if not math.isclose(recorded_allowed, allowed, rel_tol=1e-12, abs_tol=1e-9):
                raise ValueError("recorded allowed delta is incorrect")
            if abs(actual - expected) > allowed:
                raise ValueError("independently recomputed benchmark exceeds tolerance")
        except (KeyError, TypeError, ValueError) as exc:
            errors.append(f"benchmark {benchmark_id}: {exc}")
    return errors


def validate_benchmarks(
    rows: list[dict[str, object]],
    *,
    root: Path,
    repo: Path,
    layout: dict[str, object],
    paths: dict[str, str],
) -> None:
    csv_path = root / paths["benchmarks"]
    json_path = csv_path.with_suffix(".json")
    panel_path = root / paths["clean"]
    benchmark_contract = repo / paths["benchmark_contract"]
    errors: list[str] = []
    try:
        frame = strict_csv(csv_path)
        summary = strict_json(json_path)
        if list(frame.columns) != BENCHMARK_RESULT_COLUMNS:
            errors.append("benchmark reconciliation schema or column order is invalid")
        reviewed = strict_csv(benchmark_contract)
        if list(reviewed.columns) != BENCHMARK_CONTRACT_COLUMNS:
            errors.append("reviewed benchmark-contract schema or column order is invalid")
        if frame.empty:
            errors.append("benchmark reconciliation is empty")
        if frame.get("benchmark_id", pd.Series(dtype=str)).duplicated().any():
            errors.append("benchmark reconciliation repeats IDs")
        if not frame.get("status", pd.Series(dtype=str)).str.upper().eq("PASS").all():
            errors.append("one or more benchmark rows are not PASS")
        if frame.get("failure_reason", pd.Series(dtype=str)).str.strip().ne("").any():
            errors.append("one or more passing benchmark rows retains a failure reason")
        if not frame.get("review_status", pd.Series(dtype=str)).str.lower().eq("approved").all():
            errors.append("one or more benchmark rows lacks approved review")
        if frame.get("reviewer", pd.Series(dtype=str)).str.strip().eq("").any():
            errors.append("one or more benchmark rows lacks a reviewer")
        review_dates = pd.to_datetime(
            frame.get("review_date", pd.Series(dtype=str)),
            format="%Y-%m-%d",
            errors="coerce",
        )
        if review_dates.isna().any():
            errors.append("one or more benchmark rows has an invalid review date")
        invalid_source_hash = ~frame.get("source_evidence_sha256", pd.Series(dtype=str)).str.fullmatch(
            r"[0-9a-f]{64}"
        )
        if invalid_source_hash.any():
            errors.append("one or more benchmark rows lacks a source-evidence SHA-256")
        for record in frame.to_dict("records"):
            raw_path = str(record.get("source_evidence_path", "")).strip()
            relative = Path(raw_path)
            if (
                not raw_path
                or raw_path.startswith("~")
                or "\\" in raw_path
                or re.match(r"^[A-Za-z]:", raw_path)
                or relative.is_absolute()
                or ".." in relative.parts
                or relative.as_posix() != raw_path
            ):
                errors.append(
                    f"benchmark {record.get('benchmark_id', '')} has a nonportable source-evidence path"
                )
                continue
            evidence = (repo / relative).resolve(strict=True)
            try:
                evidence.relative_to(repo.resolve())
            except ValueError:
                errors.append(
                    f"benchmark {record.get('benchmark_id', '')} source evidence escapes the repository"
                )
                continue
            if not evidence.is_file():
                errors.append(
                    f"benchmark {record.get('benchmark_id', '')} source evidence is not a file"
                )
                continue
            if sha256_file(evidence) != str(record.get("source_evidence_sha256", "")):
                errors.append(
                    f"benchmark {record.get('benchmark_id', '')} source-evidence hash is stale"
                )
        invalid_source_url = frame.get("official_source", pd.Series(dtype=str)).map(
            lambda value: urlparse(str(value)).scheme not in {"http", "https"}
            or not urlparse(str(value)).netloc
        )
        if invalid_source_url.any():
            errors.append("one or more benchmark rows lacks an external HTTP(S) source")
        contract_id = str(layout["contract_id"])
        if not frame.get("contract_id", pd.Series(dtype=str)).eq(contract_id).all():
            errors.append("benchmark rows are not bound to the current contract")
        if not frame.get("artifact", pd.Series(dtype=str)).eq(paths["clean"]).all():
            errors.append("benchmark rows target a noncanonical artifact")
        panel_sha = sha256_file(panel_path)
        benchmark_sha = sha256_file(benchmark_contract)
        if not frame.get("panel_sha256", pd.Series(dtype=str)).eq(panel_sha).all():
            errors.append("benchmark panel hash is stale")
        if not frame.get("benchmark_contract_sha256", pd.Series(dtype=str)).eq(benchmark_sha).all():
            errors.append("benchmark contract hash is stale")
        external = layout["external"]
        families = set(frame.get("component_family", pd.Series(dtype=str)).str.lower())
        year_values: set[int] = set()
        for scope in frame.get("year", pd.Series(dtype=str)):
            parts = str(scope).replace("..", ":").split(":")
            start = int(parts[0])
            end = int(parts[-1])
            year_values.update(range(start, end + 1))
        if len(frame) < int(external["min_benchmark_checks"]):
            errors.append("benchmark check-count floor is not met")
        if len(year_values) < int(external["min_distinct_years"]):
            errors.append("benchmark year-coverage floor is not met")
        if len(families) < int(external["min_component_families"]):
            errors.append("benchmark family-coverage floor is not met")
        if not set(external["required_component_families"]).issubset(families):
            errors.append("one or more required benchmark families are absent")
        if set(frame.get("benchmark_id", pd.Series(dtype=str))) != set(
            reviewed.get("benchmark_id", pd.Series(dtype=str))
        ):
            errors.append("benchmark result IDs do not exactly match the reviewed contract")
        errors.extend(independently_recompute_benchmarks(frame, reviewed, panel_path))
        verifier = repo / "Scripts" / "QA_QC" / "21_external_benchmark_reconciliation.py"
        expected_summary = {
            "status": "pass",
            "mode": "release",
            "contract_id": contract_id,
            "contract_sha256": sha256_file(repo / "contracts" / "panel_spec.toml"),
            "panel_path": paths["clean"],
            "panel_sha256": panel_sha,
            "benchmark_contract_sha256": benchmark_sha,
            "verifier_sha256": sha256_file(verifier),
            "benchmark_count": len(frame),
            "distinct_year_count": len(year_values),
            "component_family_count": len(families),
        }
        for field, expected in expected_summary.items():
            if summary.get(field) != expected:
                errors.append(f"benchmark summary {field} is stale or invalid")
        if summary.get("result_statuses") != ["PASS"] * len(frame):
            errors.append("benchmark summary statuses do not match the reconciliation")
        causal_manifest = resolve_run_dir(root) / "run_manifest.json"
        expected_causal_run = causal_manifest.parent.relative_to(root).as_posix()
        if summary.get("causal_run") != expected_causal_run:
            errors.append("benchmark causal-run path is stale")
        if summary.get("causal_run_manifest_sha256") != sha256_file(causal_manifest):
            errors.append("benchmark causal-run binding is stale")
    except (OSError, KeyError, TypeError, ValueError, pd.errors.ParserError) as exc:
        errors.append(str(exc))
    add_release_check(
        rows,
        "benchmarks:mandatory_external_reconciliation",
        not errors,
        value=f"errors={len(errors)}",
        expected="nonempty, coverage-complete, independently sourced PASS rows bound to current inputs",
        evidence=csv_path,
        root=root,
        repo=repo,
        details="; ".join(errors[:10]),
    )


def collect_release_acceptance_rows(
    root: Path,
    years: list[int],
    *,
    repo: Path | None = None,
) -> list[dict[str, object]]:
    root = root.expanduser().resolve()
    repository = (repo or repo_root()).expanduser().resolve()
    layout = exact_contract_layout(repository)
    if years != layout["years"]:
        raise ValueError("release acceptance years do not match the reviewed contract")
    paths = layout["paths"]
    rows: list[dict[str, object]] = []
    add_release_check(
        rows,
        "contract:exact_v2_scope_and_paths",
        True,
        value=f"{layout['contract_id']}:{years[0]}:{years[-1]}",
        expected="reviewed v2 contract, exact 2004:2023 scope, portable canonical paths",
        evidence=repository / "contracts" / "panel_spec.toml",
        root=root,
        repo=repository,
    )
    try:
        result = verify_run(root=root, repo=repository, required_stages=REQUIRED_CAUSAL_STAGES)
        causal_ok = result.get("status") == "pass"
        run_dir = Path(str(result.get("run_dir", "")))
        causal_value = relative_evidence(run_dir, root=root, repo=repository)
        causal_details = ""
    except ProvenanceError as exc:
        causal_ok = False
        causal_value = "invalid"
        causal_details = str(exc).replace("\n", " | ")
    pointer = root / "Checks" / "v2" / "stage_manifests" / "CURRENT"
    add_release_check(
        rows,
        "provenance:current_causal_stage_chain",
        causal_ok,
        value=causal_value,
        expected="current release-mode Stage 01-through-07 chain bound to code/contracts/tools/inputs",
        evidence=pointer,
        root=root,
        repo=repository,
        details=causal_details,
    )
    validate_source_lock(
        rows,
        root=root,
        repo=repository,
        years=years,
        contract_id=str(layout["contract_id"]),
        source_lock_path=repository / paths["source_lock"],
    )
    validate_extraction(rows, root=root, repo=repository, years=years)
    validate_dictionary(
        rows,
        root=root,
        repo=repository,
        dictionary_path=root / paths["dictionary"],
        approval_path=repository / paths["backfill_approvals"],
        contract_id=str(layout["contract_id"]),
    )
    validate_harmonization(rows, root=root, repo=repository, years=years)
    validate_panel_artifacts(
        rows,
        root=root,
        repo=repository,
        years=years,
        paths=paths,
    )
    validate_cleaning_reconciliation(
        rows,
        root=root,
        repo=repository,
        paths=paths,
    )
    validate_source_row_lineage(rows, root=root, repo=repository, paths=paths)
    validate_wide_value_lineage(
        rows,
        root=root,
        repo=repository,
        paths=paths,
        years=years,
        contract_id=str(layout["contract_id"]),
    )
    validate_wide_qc(
        rows,
        root=root,
        repo=repository,
        contract_id=str(layout["contract_id"]),
        lineage_path=root / paths["lineage"],
        paths=paths,
    )
    validate_panel_qa(
        rows,
        root=root,
        repo=repository,
        summary_path=root / paths["panel_qa"],
    )
    validate_continuity(rows, root=root, repo=repository, paths=paths, years=years)
    validate_benchmarks(
        rows,
        root=root,
        repo=repository,
        layout=layout,
        paths=paths,
    )
    return rows


def render_markdown(rows: list[dict[str, object]], years: list[int]) -> str:
    passed = sum(1 for row in rows if row["passed"])
    failed = len(rows) - passed
    lines = [
        "# Acceptance Audit",
        "",
        f"- Years: `{years[0]}:{years[-1]}`",
        f"- Checks passed: `{passed}`",
        f"- Checks failed: `{failed}`",
        "",
        "| Check | Status | Value | Expected | Details |",
        "| --- | --- | --- | --- | --- |",
    ]
    for row in rows:
        lines.append(
            f"| `{row['check_name']}` | {row['status']} | `{row['value']}` | `{row['expected']}` | {row['details']} |"
        )
    return "\n".join(lines) + "\n"


def acceptance_csv(rows: list[dict[str, object]]) -> pd.DataFrame:
    payload: list[dict[str, object]] = []
    for row in rows:
        details = str(row.get("details", "")).strip()
        context = f"actual={row.get('actual', '')!s}; expected={row.get('expected', '')!s}"
        payload.append(
            {
                "check_id": row["check_id"],
                "status": row["status"],
                "evidence_path": row.get("evidence_path", ""),
                "details": f"{context}; {details}" if details else context,
            }
        )
    return pd.DataFrame(payload, columns=["check_id", "status", "evidence_path", "details"])


def acceptance_schema_errors(
    rows: list[dict[str, object]],
    *,
    release: bool,
) -> list[str]:
    check_ids = [str(row.get("check_id", "")) for row in rows]
    errors: list[str] = []
    if not check_ids or any(not value for value in check_ids):
        errors.append("acceptance check IDs must be nonblank")
    if len(check_ids) != len(set(check_ids)):
        errors.append("acceptance check IDs must be unique")
    invalid_statuses = sorted(
        {
            str(row.get("status", ""))
            for row in rows
            if str(row.get("status", "")) not in {"PASS", "FAIL"}
        }
    )
    if invalid_statuses:
        errors.append("invalid acceptance statuses=" + ",".join(invalid_statuses))
    if release:
        observed = set(check_ids)
        required_before_schema = REQUIRED_RELEASE_CHECK_IDS | {
            "acceptance:final_drift_recheck"
        }
        missing = sorted(required_before_schema - observed)
        unexpected = sorted(
            observed - required_before_schema - RELEASE_FAILURE_ONLY_CHECK_IDS
        )
        if missing:
            errors.append("missing required acceptance checks=" + ",".join(missing))
        if unexpected:
            errors.append("unexpected acceptance checks=" + ",".join(unexpected))
    return errors


def write_acceptance_payload(
    directory: Path,
    rows: list[dict[str, object]],
    years: list[int],
    manifest: dict[str, object],
) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    acceptance_csv(rows).to_csv(directory / "acceptance_summary.csv", index=False)
    (directory / "acceptance_summary.md").write_text(
        render_markdown(rows, years),
        encoding="utf-8",
    )
    (directory / "acceptance_manifest.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def publish_acceptance_run(
    pointer: Path,
    rows: list[dict[str, object]],
    years: list[int],
    manifest: dict[str, object],
    *,
    promote: bool,
) -> Path:
    if pointer.exists() and not pointer.is_symlink():
        raise ValueError(f"canonical acceptance output is not an atomic managed pointer: {pointer}")
    pointer.parent.mkdir(parents=True, exist_ok=True)
    runs = pointer.parent / f".{pointer.name}.runs"
    if runs.is_symlink():
        raise ValueError(f"managed acceptance run store cannot be a symlink: {runs}")
    runs.mkdir(parents=True, exist_ok=True)
    run_id = str(manifest["run_id"])
    staging = runs / f".{run_id}.staging-{uuid.uuid4().hex}"
    final = runs / run_id
    try:
        write_acceptance_payload(staging, rows, years, manifest)
        if final.exists():
            expected = {
                path.name: sha256_file(path)
                for path in staging.iterdir()
                if path.is_file()
            }
            observed = {
                path.name: sha256_file(path)
                for path in final.iterdir()
                if path.is_file()
            }
            if expected != observed:
                raise ValueError(f"content-addressed acceptance run already exists with drift: {run_id}")
            shutil.rmtree(staging)
        else:
            os.replace(staging, final)
        if promote:
            temporary = pointer.parent / f".{pointer.name}.pointer-{uuid.uuid4().hex}"
            os.symlink(os.path.relpath(final, pointer.parent), temporary)
            os.replace(temporary, pointer)
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise
    return final


def write_development_acceptance(
    directory: Path,
    rows: list[dict[str, object]],
    years: list[int],
    manifest: dict[str, object],
) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    staging = directory.parent / f".{directory.name}.staging-{uuid.uuid4().hex}"
    try:
        write_acceptance_payload(staging, rows, years, manifest)
        for path in staging.iterdir():
            os.replace(path, directory / path.name)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def main() -> None:
    args = parse_args()
    root = Path(args.root).expanduser().resolve()
    repository = Path(args.repo).expanduser().resolve() if args.repo else repo_root().resolve()
    years = parse_years(args.years)
    release = args.mode == "release"
    layout = exact_contract_layout(repository)
    canonical_dir = root / Path(str(layout["paths"]["acceptance"])).parent
    if release and args.out_dir:
        raise SystemExit("Release acceptance does not permit an output override.")
    if not release and not args.out_dir:
        raise SystemExit("Development acceptance requires an explicit noncanonical --out-dir.")
    out_dir = Path(args.out_dir).expanduser().resolve() if args.out_dir else canonical_dir
    if not release and out_dir == canonical_dir:
        raise SystemExit("Development acceptance cannot publish canonical release evidence.")

    code_path = Path(__file__).resolve()
    contract_path = repository / "contracts" / "panel_spec.toml"
    code_sha_before = sha256_file(code_path)
    contract_sha_before = sha256_file(contract_path)
    causal_before: dict[str, str] = {}
    causal_before_error = ""
    if release:
        try:
            causal_before = causal_run_binding(root, repository)
        except (OSError, ProvenanceError, ValueError) as exc:
            causal_before_error = str(exc).replace("\n", " | ")
    try:
        rows = (
            collect_release_acceptance_rows(root, years, repo=repository)
            if release
            else collect_acceptance_rows(root, years)
        )
    except Exception as exc:  # noqa: BLE001 - the audit must record a machine-readable failure.
        rows = [
            build_row(
                "acceptance:execution",
                False,
                value=type(exc).__name__,
                expected="semantic acceptance completes",
                details=str(exc),
            )
        ]

    if release:
        final_errors: list[str] = []
        if causal_before_error:
            final_errors.append("initial causal binding invalid: " + causal_before_error)
        if sha256_file(code_path) != code_sha_before:
            final_errors.append("acceptance verifier changed during execution")
        if sha256_file(contract_path) != contract_sha_before:
            final_errors.append("panel contract changed during acceptance")
        try:
            causal_after = causal_run_binding(root, repository)
            if causal_after != causal_before:
                final_errors.append("causal run, manifest, or managed pointer changed during acceptance")
        except (OSError, ProvenanceError, ValueError) as exc:
            final_errors.append(str(exc).replace("\n", " | "))

        try:
            revalidated_rows = collect_release_acceptance_rows(root, years, repo=repository)
            if revalidated_rows != rows:
                final_errors.append("semantic acceptance results changed during final revalidation")
        except Exception as exc:  # noqa: BLE001 - record a fail-closed immutable attempt.
            final_errors.append(
                f"final semantic revalidation failed: {type(exc).__name__}: {exc}"
            )

        for row in rows:
            evidence_path = str(row.get("evidence_path", "")).strip()
            expected_sha = str(row.get("evidence_sha256", "")).strip()
            if not evidence_path or not expected_sha:
                continue
            root_candidate = root / evidence_path
            repo_candidate = repository / evidence_path
            candidate = (
                root_candidate
                if root_candidate.exists() or root_candidate.is_symlink()
                else repo_candidate
            )
            if evidence_fingerprint(candidate) != expected_sha:
                final_errors.append(f"acceptance evidence changed after validation: {evidence_path}")
        rows.append(
            build_row(
                "acceptance:final_drift_recheck",
                not final_errors,
                value=f"errors={len(final_errors)}",
                expected="same causal run and identical second semantic validation",
                details="; ".join(final_errors),
            )
        )

    schema_errors = acceptance_schema_errors(rows, release=release)
    if release or schema_errors:
        rows.append(
            build_row(
                "acceptance:output_schema",
                not schema_errors,
                value=f"errors={len(schema_errors)}",
                expected="exact required check-ID set, unique IDs, and PASS/FAIL statuses",
                details="; ".join(schema_errors),
            )
        )

    if release:
        rows = portable_release_rows(rows, root=root, repo=repository)

    failed = sum(1 for row in rows if not bool(row["passed"]))
    status = "pass" if failed == 0 else "fail"
    run_id = hashlib.sha256(
        json.dumps(
            {
                "code_sha256": code_sha_before,
                "contract_sha256": contract_sha_before,
                "mode": args.mode,
                "rows": rows,
                "years": years,
            },
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
    ).hexdigest()[:24]
    manifest = {
        "acceptance_schema_version": ACCEPTANCE_SCHEMA_VERSION,
        "check_count": len(rows),
        "contract_id": layout["contract_id"],
        "contract_sha256": contract_sha_before,
        "failed_check_count": failed,
        "mode": args.mode,
        "run_id": run_id,
        "status": status,
        "verifier_path": "Scripts/QA_QC/08_acceptance_audit.py",
        "verifier_sha256": code_sha_before,
        "years": years,
        "checks": rows,
    }
    if release:
        manifest["causal_binding"] = causal_before
        manifest["semantic_evidence_sha256"] = hashlib.sha256(
            json.dumps(rows, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
                "utf-8"
            )
        ).hexdigest()
    if release:
        published = publish_acceptance_run(
            out_dir,
            rows,
            years,
            manifest,
            promote=failed == 0,
        )
        csv_path = published / "acceptance_summary.csv"
    else:
        write_development_acceptance(out_dir, rows, years, manifest)
        csv_path = out_dir / "acceptance_summary.csv"

    print(f"Wrote acceptance audit attempt: {csv_path}")
    if failed:
        raise SystemExit(f"Acceptance audit failed: {failed} checks failed")
    print(f"Acceptance audit passed and promoted: {out_dir}")


if __name__ == "__main__":
    main()
