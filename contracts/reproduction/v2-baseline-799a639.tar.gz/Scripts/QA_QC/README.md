# QA/QC guide

This folder contains validation, parity, monitoring, and repository-guard scripts.

This folder answers three questions:

- did the build run correctly?
- does the cleaned panel still preserve the intended institution-year structure?
- do the independently bound scientific and publication gates permit release?

If you are not sure where to start, do not start with the most detailed CSV. Start with the smallest summary that still answers your question.

## Main QA scripts

| File | Purpose |
| --- | --- |
| `00_dictionary_qaqc.py` | audit dictionary integrity, separate actionable mapping gaps from auxiliary/custom families, and summarize noncanonical sources |
| `01_panel_qa.py` | transactionally verify one immutable Stage 07 run, its policy coverage, action lineage, and row/key/schema preservation |
| `02_access_vs_flatfile_parity.py` | produce non-authoritative regression comparison against the flat-file project |
| `03_monitored_analysis_build.py` | run a monitored wide build with durable logs |
| `04_certify_analysis_build.py` | legacy-named regression comparison; it does not certify scientific validity |
| `08_acceptance_audit.py` | run semantic acceptance checks over causally bound v2 artifacts |
| `09_panel_structure_qc.py` | emit literature-guided diagnostics for panel structure, identifier linkage, timing, finance comparability, and classification stability |
| `10_release_metrics.py` | create development-only manuscript/archive summary tables; it is not a release gate |
| `11_validate_panel_contract.py` | fail if `contracts/panel_spec.toml` drifts from current wide-build defaults or PRCH policy |
| `12_build_release_manifest.py` | write the v2 artifact ledger only after clean-git, container, and causal-chain verification |
| `13_verify_release_manifest.py` | re-check files, git state, and causal stage identity before publication or after download |
| `14_build_public_release_bundle.py` | seal one immutable bundle and atomically promote its current pointer |
| `15_compare_release_to_baseline.py` | compare a current release against a baseline manifest and fail on schema, row-count, dictionary, year-window, or PRCH drift |
| `16_build_datapackage.py` | write table-level Data Package metadata from the release manifest |
| `17_build_provenance.py` | bind release metadata to the sealed causal run, commit, contracts, environment, and container |
| `18_public_release_guard.py` | fail if public-release policy, ownership, citation, archive, or intake files are missing or inconsistent |
| `19_docs_style_guard.py` | scan release-facing prose for generated-text patterns before publication |
| `20_environment_report.py` | write Python, package, tool, lockfile, and platform metadata for the release |
| `21_external_benchmark_reconciliation.py` | require independently sourced benchmark coverage and reconcile selected panel metrics |
| `22_build_entity_continuity_crosswalk.py` | build `UNITID` join-risk and entity-continuity review outputs |
| `24_verify_contract_review_evidence.py` | verify the authoritative external B03/B04 ZIP, every manifested member, and recomputed core evidence semantics |
| `25_verify_container_runtime.py` | verify immutable image/source/lock bindings and read-only/read-write mount boundaries inside the release container |
| `26_validate_synthetic_release_smoke.py` | validate the isolated development-only synthetic stage chain and reject production output namespaces |
| `07_task_monitor_summary.py` | roll monitored-build telemetry into CSV and Markdown summaries |
| `release_gate.sh` | run the release checks, metadata builders, bundle builder, repo guards, and tests |

## Repo guards

| File | Purpose |
| --- | --- |
| `05_repo_size_guard.py` | fail if tracked files make the repo too large |
| `06_staged_repo_guard.py` | block staged generated artifacts and oversized files |
| `18_public_release_guard.py` | check public-facing ownership, license, citation, and intake files |
| `19_docs_style_guard.py` | check published prose before release |

## Typical use

- after a standard build: run `qc_only.sh`
- during deeper debugging: inspect `Checks/dictionary_qc/noncanonical_source_categories.csv` and `Checks/v2/panel_qc/panel_qa_coverage_matrix.csv` first
- for semantic acceptance: inspect `Checks/v2/acceptance_qc/acceptance_summary.csv` and its bound manifest; still verify the causal chain and benchmark gate separately
- during parity work: use `02_access_vs_flatfile_parity.py`
- during long-run monitoring: use `03_monitored_analysis_build.py` and inspect `Checks/real_parity_runs/summary/`
- for development manuscript or archive tables: use `10_release_metrics.py` after acceptance artifacts exist and keep it outside canonical `Checks/v2`
- after changing build defaults or PRCH rules: run `11_validate_panel_contract.py`
- before archiving or sharing a public build: run
  `tools/release_container.py gate` from a clean standalone clone with the
  exact receipt-bound B03/B04 evidence ZIP
- before replacing an archived release: run `15_compare_release_to_baseline.py`
- before any archive preparation: verify the 18 approved definitions in `contracts/external_benchmarks.csv` and run their reconciliation; approval of definitions is not a benchmark pass
- before external joins: inspect `Checks/v2/entity_continuity/entity_continuity_crosswalk.csv`
- after changing Stage 06 or Stage 07 lineage behavior: inspect `Checks/v2/wide_qc/qc_value_lineage.parquet` and the immutable `Checks/v2/prch_qc/` run
- before committing: run the repo guards

## Files to open first

1. `Checks/v2/acceptance_qc/acceptance_summary.md`
2. `Checks/v2/panel_qc/panel_qa_summary.csv`
3. `Checks/v2/panel_qc/panel_structure_summary.csv`
4. `Checks/v2/entity_continuity/entity_continuity_crosswalk.csv`
5. `Checks/dictionary_qc/dictionary_qaqc_summary.csv`
6. `Checks/v2/disc_qc/`
7. only then, the year-level detail files

`qc_only.sh` now runs:

- dictionary QA
- panel QA
- panel structure QA
- acceptance audit

For repo tests in this environment, use:

```bash
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q
```

For the exact reviewed parent-child boundary, read `METHODS_PRCH_CLEANING.md`.

For the literature-guided whole-panel method, read `METHODS_PANEL_CONSTRUCTION.md`.

Operational split:

- `Checks/v2/panel_qc/` explains whether one bound cleaning run behaved correctly
- `Checks/v2/acceptance_qc/` explains whether semantic checks passed

That distinction matters. Neither directory alone establishes a release: source
locks, causal manifests, external benchmarks, environment identity, manifest
verification, and the atomic bundle must also pass.
