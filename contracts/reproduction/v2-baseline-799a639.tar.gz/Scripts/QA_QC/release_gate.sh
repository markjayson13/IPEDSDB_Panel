#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
DEFAULT_IPEDSDB_ROOT="$(dirname "$REPO_ROOT")/IPEDSDB_ROOT"
ROOT="${IPEDSDB_ROOT:-$DEFAULT_IPEDSDB_ROOT}"
YEARS="${YEARS:-2004:2023}"
PYTHON_BIN="${PYTHON_BIN:-python3}"
BASELINE_MANIFEST="${BASELINE_MANIFEST:-}"
BASELINE_ROOT="${BASELINE_ROOT:-}"
cd "$REPO_ROOT"

"$PYTHON_BIN" Scripts/QA_QC/11_validate_panel_contract.py
CONTRACT_REVIEW_EVIDENCE_BUNDLE="${CONTRACT_REVIEW_EVIDENCE_BUNDLE:?set CONTRACT_REVIEW_EVIDENCE_BUNDLE to the mounted B03/B04 evidence ZIP}"
"$PYTHON_BIN" Scripts/QA_QC/24_verify_contract_review_evidence.py \
  --evidence-bundle "$CONTRACT_REVIEW_EVIDENCE_BUNDLE" \
  --receipt "$REPO_ROOT/contracts/review_evidence/B03_B04_EVIDENCE_RECEIPT.json"
"$PYTHON_BIN" Scripts/QA_QC/18_public_release_guard.py
"$PYTHON_BIN" Scripts/QA_QC/19_docs_style_guard.py
"$PYTHON_BIN" Scripts/QA_QC/20_environment_report.py \
  --root "$ROOT"
"$PYTHON_BIN" Scripts/stage_provenance.py verify \
  --root "$ROOT" \
  --require-stages "01,02,03,04,05,06,07,qa00,qa01"
"$PYTHON_BIN" Scripts/QA_QC/05_repo_size_guard.py
"$PYTHON_BIN" Scripts/QA_QC/06_staged_repo_guard.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 "$PYTHON_BIN" -m pytest -p no:cacheprovider -q

"$PYTHON_BIN" Scripts/QA_QC/22_build_entity_continuity_crosswalk.py \
  --root "$ROOT" \
  --years "$YEARS" \
  --mode release
"$PYTHON_BIN" Scripts/QA_QC/23_verify_entity_continuity.py \
  --root "$ROOT" \
  --mode release
"$PYTHON_BIN" Scripts/QA_QC/21_external_benchmark_reconciliation.py \
  --root "$ROOT" \
  --years "$YEARS" \
  --mode release
"$PYTHON_BIN" Scripts/QA_QC/08_acceptance_audit.py \
  --root "$ROOT" \
  --years "$YEARS" \
  --mode release

"$PYTHON_BIN" Scripts/QA_QC/12_build_release_manifest.py \
  --root "$ROOT" \
  --years "$YEARS"
"$PYTHON_BIN" Scripts/QA_QC/13_verify_release_manifest.py \
  --manifest "$ROOT/Checks/v2/release_manifest/release_manifest.csv" \
  --root "$ROOT"
"$PYTHON_BIN" Scripts/QA_QC/16_build_datapackage.py \
  --root "$ROOT" \
  --years "$YEARS" \
  --manifest "$ROOT/Checks/v2/release_manifest/release_manifest.csv" \
  --verification "$ROOT/Checks/v2/release_manifest/release_manifest_verification.csv"
"$PYTHON_BIN" Scripts/QA_QC/17_build_provenance.py \
  --root "$ROOT" \
  --manifest "$ROOT/Checks/v2/release_manifest/release_manifest.csv" \
  --verification "$ROOT/Checks/v2/release_manifest/release_manifest_verification.csv"

if [[ -n "$BASELINE_MANIFEST" ]]; then
  args=(
    --baseline-manifest "$BASELINE_MANIFEST"
    --current-manifest "$ROOT/Checks/v2/release_manifest/release_manifest.csv"
    --current-root "$ROOT"
    --out-dir "$ROOT/Checks/v2/release_compare"
  )
  if [[ -n "$BASELINE_ROOT" ]]; then
    args+=(--baseline-root "$BASELINE_ROOT")
  fi
  "$PYTHON_BIN" Scripts/QA_QC/15_compare_release_to_baseline.py "${args[@]}"
fi

"$PYTHON_BIN" Scripts/QA_QC/18_public_release_guard.py --require-release-ready
"$PYTHON_BIN" Scripts/QA_QC/14_build_public_release_bundle.py \
  --root "$ROOT" \
  --years "$YEARS" \
  --manifest "$ROOT/Checks/v2/release_manifest/release_manifest.csv" \
  --verification "$ROOT/Checks/v2/release_manifest/release_manifest_verification.csv"
