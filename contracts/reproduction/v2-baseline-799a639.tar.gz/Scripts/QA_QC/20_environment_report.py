#!/usr/bin/env python3
"""
QA 20: write runtime and dependency metadata for a release.

Reads:
- Python runtime
- installed Python package versions
- command-line tool versions
- requirements-lock.txt

Writes:
- Checks/v2/release_metadata/environment_report.json
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from access_build_utils import DEFAULT_IPEDSDB_ROOT, atomic_write_json, data_layout, repo_root
from stage_provenance import (
    git_state,
    missing_system_tool_bindings,
    tool_versions,
    validate_release_container_bindings,
)

DIRECT_PACKAGES = ["pandas", "pyarrow", "openpyxl", "requests", "beautifulsoup4", "duckdb", "pytest"]


def parse_args() -> argparse.Namespace:
    root = Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default=str(root), help="External IPEDSDB_ROOT")
    p.add_argument("--repo-root", default=str(repo_root()))
    p.add_argument("--out", default=None)
    p.add_argument("--require-lock-parity", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require-installed-lock", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require-container-digest", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require-system-tools", action=argparse.BooleanOptionalAction, default=True)
    return p.parse_args()


def file_sha256(path: Path) -> str:
    if not path.exists() or not path.is_file():
        return ""
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def package_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return ""


def pip_freeze() -> list[str]:
    try:
        out = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True, stderr=subprocess.DEVNULL)
    except Exception:
        return []
    return sorted(line.strip() for line in out.splitlines() if line.strip())


def locked_versions(lock_path: Path) -> dict[str, str]:
    versions: dict[str, str] = {}
    if not lock_path.is_file():
        return versions
    for raw_line in lock_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "==" not in line or any(token in line for token in (";", "[", " @ ")):
            raise SystemExit(f"Unsupported release-lock requirement: {line}")
        name, version = line.split("==", 1)
        normalized = name.strip().lower().replace("_", "-")
        if not normalized or not version.strip() or normalized in versions:
            raise SystemExit(f"Malformed or duplicate release-lock requirement: {line}")
        versions[normalized] = version.strip()
    return versions


def main() -> int:
    args = parse_args()
    root = Path(args.root).expanduser()
    repo = Path(args.repo_root).expanduser()
    layout = data_layout(root)
    out_path = Path(args.out).expanduser() if args.out else layout.checks / "v2" / "release_metadata" / "environment_report.json"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = repo / "requirements-lock.txt"
    requirements_path = repo / "requirements.txt"
    lock_sha = file_sha256(lock_path)
    requirements_sha = file_sha256(requirements_path)
    if args.require_lock_parity and (not lock_sha or lock_sha != requirements_sha):
        raise SystemExit("requirements.txt must be byte-identical to requirements-lock.txt for release metadata.")
    container_digest = os.environ.get("CONTAINER_IMAGE_DIGEST", "").strip()
    expected_versions = locked_versions(lock_path)
    installed_versions = {
        name: package_version(name)
        for name in expected_versions
    }
    mismatches = {
        name: {
            "locked": expected_versions[name],
            "installed": installed_versions[name],
        }
        for name in expected_versions
        if installed_versions[name] != expected_versions[name]
    }
    if args.require_installed_lock and mismatches:
        details = ", ".join(
            f"{name}={values['installed'] or '<missing>'} (locked {values['locked']})"
            for name, values in sorted(mismatches.items())
        )
        raise SystemExit(
            "Installed dependencies do not match requirements-lock.txt: "
            + details
        )
    runtime_bindings = tool_versions()
    if args.require_container_digest:
        state = git_state(repo)
        try:
            validate_release_container_bindings(
                repo=repo,
                git_commit=str(state["git_commit"]),
                bindings=runtime_bindings,
            )
        except RuntimeError as exc:
            raise SystemExit(str(exc)) from exc
    missing_tools = missing_system_tool_bindings(runtime_bindings)
    if args.require_system_tools and missing_tools:
        raise SystemExit("Required system tool bindings are missing: " + ", ".join(missing_tools))
    report = {
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "repo_root": str(repo),
        "data_root": str(root),
        "container_image_digest": container_digest,
        "container_image_revision": runtime_bindings[
            "container_image_revision"
        ],
        "container_requirements_lock_sha256": runtime_bindings[
            "container_requirements_lock_sha256"
        ],
        "python": {
            "executable": sys.executable,
            "version": sys.version.split()[0],
            "implementation": platform.python_implementation(),
        },
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "machine": platform.machine(),
            "platform": platform.platform(),
        },
        "direct_packages": {name: package_version(name) for name in DIRECT_PACKAGES},
        "runtime_bindings": runtime_bindings,
        "requirements_lock": {
            "path": "requirements-lock.txt",
            "sha256": lock_sha,
            "lines": lock_path.read_text(encoding="utf-8").splitlines() if lock_path.exists() else [],
        },
        "requirements_entrypoint": {
            "path": "requirements.txt",
            "sha256": requirements_sha,
            "matches_lock": bool(lock_sha and lock_sha == requirements_sha),
        },
        "installed_lock_check": {
            "locked_versions": expected_versions,
            "installed_versions": installed_versions,
            "mismatches": mismatches,
            "matches": not mismatches,
        },
        "pip_freeze": pip_freeze(),
    }
    atomic_write_json(out_path, report)
    print(f"Wrote environment report to {out_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
