#!/usr/bin/env python3
"""
Stage 07: apply PRCH parent/child cleaning to the stitched wide panel.

Reads:
- `Panels/panel_wide_analysis_*.parquet`
- `Dictionary/dictionary_lake.parquet`
- `Checks/wide_qc/qc_column_lineage.csv` when provided

Writes:
- `Panels/panel_clean_analysis_*.parquet`
- `Checks/prch_qc/*`

Policy modes:
- release (default): use a reviewed annual/code-level CSV contract and fail
  before output creation on unknown codes, unreviewed rules, or empty targets
- development: explicitly opt into the legacy broad family mapping

Open this file when you want to see the actual row-preserving parent/child cleaning logic used to produce the final released panel.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
import uuid
from pathlib import Path
import pathlib

import pandas as pd
import pyarrow as pa
import pyarrow.dataset as ds
import pyarrow.parquet as pq

from prch_policy import (
    PrchPolicyContract,
    PrchPolicyError,
    PrchPolicyRule,
    classify_flag_code,
    cleaned_child_codes,
    load_policy_contract,
    policy_rows,
    review_only_codes,
    targets_source_file,
)
from access_build_utils import DEFAULT_IPEDSDB_ROOT


def setup_logging(log_path: str | None) -> None:
    if not log_path:
        return
    log_file = Path(log_path)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    f = log_file.open("a", buffering=1)

    class Tee:
        def __init__(self, *streams):
            self.streams = streams

        def write(self, data):
            for s in self.streams:
                s.write(data)

        def flush(self):
            for s in self.streams:
                s.flush()

    sys.stdout = Tee(sys.stdout, f)
    sys.stderr = Tee(sys.stderr, f)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--input", required=True, help="Input stitched wide parquet")
    p.add_argument("--output", required=True, help="Output cleaned parquet")
    p.add_argument("--dictionary", required=True, help="dictionary_lake.parquet")
    p.add_argument("--column-lineage", default=None, help="Stage 06 column lineage CSV/parquet. Preferred over dictionary fallback.")
    p.add_argument(
        "--prch-policy",
        default=str(Path(__file__).resolve().parents[1] / "contracts" / "prch_policy.csv"),
        help="Reviewed annual/code-level PRCH policy CSV (required in release mode)",
    )
    p.add_argument(
        "--policy-mode",
        choices=("release", "development"),
        default="release",
        help="Release fails closed; development explicitly enables the legacy broad mapping",
    )
    p.add_argument("--qc-dir", default=None, help="Write QC summaries here")
    p.add_argument("--batch-rows", type=int, default=100_000, help="Batch size for streaming")
    p.add_argument(
        "--output-row-group-rows",
        type=int,
        default=4_096,
        help="Rows buffered per output Parquet row group (default: 4096)",
    )
    p.add_argument("--log-every", type=int, default=50, help="Log progress every N batches")
    p.add_argument("--drop-imputation-flags", action=argparse.BooleanOptionalAction, default=False, help="Drop X* imputation columns")
    data_root = pathlib.Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT)))
    logs_root = data_root / "Checks" / "logs"
    p.add_argument("--log-file", default=str(logs_root / "07_clean_panel.log"), help="Optional log file path")
    return p.parse_args()


def parse_source_files(value: object) -> set[str]:
    if value is None:
        return set()
    try:
        if bool(pd.isna(value)):
            return set()
    except (TypeError, ValueError):
        pass
    text = str(value).strip()
    if not text:
        return set()
    parts: list[str] = []
    for chunk in text.replace(",", "|").split("|"):
        source = chunk.strip().upper()
        if source:
            parts.append(source)
    return set(parts)


def build_source_map_from_dictionary(dictionary_path: Path) -> dict[str, set[str]]:
    df = pd.read_parquet(dictionary_path, columns=["varname", "source_file"])
    df["varname"] = df["varname"].fillna("").astype(str).str.strip().str.upper()
    df["source_file"] = df["source_file"].fillna("").astype(str).str.strip().str.upper()
    df = df[df["varname"] != ""]
    return df.groupby("varname")["source_file"].agg(lambda values: {v for v in values if v}).to_dict()


def build_source_map_from_column_lineage(
    lineage_path: Path,
    panel_columns: list[str],
    *,
    require_v2: bool = False,
    batch_rows: int = 100_000,
) -> dict[str, set[str]]:
    """Reduce value-level lineage to a bounded column/source mapping.

    Stage 06 release lineage contains one row per source-backed panel value.
    Only the column and source identities are needed here, so parquet lineage
    must be projected and scanned in bounded batches rather than materialized
    as a many-column pandas frame.
    """

    if not lineage_path.exists():
        raise SystemExit(f"Column lineage file does not exist: {lineage_path}")
    if batch_rows <= 0:
        raise ValueError("lineage batch_rows must be positive")

    out: dict[str, set[str]] = {}
    canonical_columns = {"analysis_column", "source_file"}
    legacy_columns = {"output_column", "source_files"}

    parquet_dataset: ds.Dataset | None = None
    csv_frame: pd.DataFrame | None = None
    if lineage_path.suffix.lower() == ".parquet":
        parquet_dataset = ds.dataset(str(lineage_path), format="parquet")
        available_columns = set(parquet_dataset.schema.names)
    else:
        csv_frame = pd.read_csv(lineage_path)
        available_columns = set(csv_frame.columns)

    if canonical_columns.issubset(available_columns):
        selected_columns = ["analysis_column", "source_file"]
        if parquet_dataset is not None:
            lineage_batches = (
                batch.to_pandas()
                for batch in parquet_dataset.to_batches(
                    columns=selected_columns,
                    batch_size=batch_rows,
                    use_threads=False,
                    batch_readahead=1,
                    fragment_readahead=1,
                )
            )
        else:
            assert csv_frame is not None
            lineage_batches = iter([csv_frame[selected_columns].copy()])
        for frame in lineage_batches:
            frame["analysis_column"] = (
                frame["analysis_column"]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            frame["source_file"] = frame["source_file"].fillna("").astype(str)
            blank_identity = (frame["analysis_column"] == "") | (
                frame["source_file"].str.strip() == ""
            )
            if blank_identity.any():
                raise SystemExit(
                    "Canonical v2 column lineage contains blank "
                    "analysis_column or source_file values"
                )
            for row in frame.to_dict("records"):
                column = str(row["analysis_column"]).strip().upper()
                out.setdefault(column, set()).update(
                    parse_source_files(row["source_file"])
                )
    elif legacy_columns.issubset(available_columns):
        if require_v2:
            raise SystemExit(
                "Release PRCH cleaning requires canonical v2 row-level lineage columns: "
                "analysis_column, source_file"
            )
        selected_columns = ["output_column", "source_files"]
        if "primary_source_file" in available_columns:
            selected_columns.append("primary_source_file")
        if parquet_dataset is not None:
            lineage_batches = (
                batch.to_pandas()
                for batch in parquet_dataset.to_batches(
                    columns=selected_columns,
                    batch_size=batch_rows,
                    use_threads=False,
                    batch_readahead=1,
                    fragment_readahead=1,
                )
            )
        else:
            assert csv_frame is not None
            lineage_batches = iter([csv_frame[selected_columns].copy()])
        for frame in lineage_batches:
            frame["output_column"] = (
                frame["output_column"]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.upper()
            )
            frame["source_files"] = frame["source_files"].fillna("").astype(str)
            if "primary_source_file" in frame.columns:
                frame["primary_source_file"] = (
                    frame["primary_source_file"].fillna("").astype(str)
                )
            else:
                frame["primary_source_file"] = ""
            for row in frame.to_dict("records"):
                column = str(row.get("output_column", "")).strip().upper()
                if not column:
                    continue
                sources = parse_source_files(
                    row.get("source_files")
                ) | parse_source_files(row.get("primary_source_file"))
                out.setdefault(column, set()).update(sources)
    else:
        expected = sorted(canonical_columns if require_v2 else canonical_columns | legacy_columns)
        raise SystemExit(
            "Column lineage is missing a supported source-identity schema; expected columns include: "
            + ", ".join(expected)
        )

    panel_lookup = {c.upper(): c for c in panel_columns}
    exempt = {"YEAR", "UNITID"}
    missing = sorted(original for upper, original in panel_lookup.items() if upper not in exempt and upper not in out)
    if missing:
        preview = ", ".join(missing[:20])
        suffix = " ..." if len(missing) > 20 else ""
        raise SystemExit(f"Column lineage is missing {len(missing)} input panel columns: {preview}{suffix}")
    return out


class SchemaAlignmentError(RuntimeError):
    """Raised when a cleaned batch cannot satisfy the input panel schema."""


def cast_table_to_schema(table: pa.Table, target_schema: pa.Schema) -> pa.Table:
    """Align and safely cast a table, reporting the fields that failed.

    Stage 07 is row/value cleaning, not a type-coercion stage. Unsafe casts or
    swallowed cast errors would make batches differ by year, so any mismatch is
    fatal and the staged output is discarded.
    """

    actual_names = table.column_names
    missing = [name for name in target_schema.names if name not in actual_names]
    extra = [name for name in actual_names if name not in target_schema.names]
    if missing or extra:
        details = []
        if missing:
            details.append("missing columns: " + ", ".join(missing))
        if extra:
            details.append("extra columns: " + ", ".join(extra))
        raise SchemaAlignmentError("Cleaned batch schema mismatch; " + "; ".join(details))
    if actual_names != target_schema.names:
        raise SchemaAlignmentError(
            "Cleaned batch column order differs from the input schema; no implicit reordering is allowed"
        )
    try:
        return table.cast(target_schema, safe=True)
    except (pa.ArrowInvalid, pa.ArrowNotImplementedError, pa.ArrowTypeError) as exc:
        failed_fields: list[str] = []
        for field in target_schema:
            one_field_schema = pa.schema([field])
            one_field_table = pa.table([table[field.name]], names=[field.name])
            try:
                one_field_table.cast(one_field_schema, safe=True)
            except (pa.ArrowInvalid, pa.ArrowNotImplementedError, pa.ArrowTypeError):
                failed_fields.append(field.name)
        detail = ", ".join(failed_fields) if failed_fields else "unknown fields"
        raise SchemaAlignmentError(
            f"Cleaned batch does not match the input schema; failed fields: {detail}. Original error: {exc}"
        ) from exc


class PanelIntegrityError(RuntimeError):
    """Raised when Stage 07 would change panel keys, rows, or schema."""


def validate_case_unique_columns(schema: pa.Schema) -> None:
    by_casefold: dict[str, list[str]] = {}
    for name in schema.names:
        by_casefold.setdefault(name.casefold(), []).append(name)
    collisions = [names for names in by_casefold.values() if len(names) > 1]
    if collisions:
        rendered = "; ".join("/".join(names) for names in collisions)
        raise PanelIntegrityError(
            f"Input schema contains case-insensitive duplicate column names: {rendered}"
        )


def validate_panel_keys(dataset: ds.Dataset) -> tuple[list[tuple[int, int]], list[int]]:
    """Require a unique, non-null, integral institution-year panel key."""

    for column in ("year", "UNITID"):
        field = dataset.schema.field(column)
        if not pa.types.is_integer(field.type):
            raise PanelIntegrityError(
                f"{column} must use an integer Arrow type; found {field.type}"
            )
    key_frame = dataset.to_table(columns=["year", "UNITID"]).to_pandas()
    for column in ("year", "UNITID"):
        null_count = int(key_frame[column].isna().sum())
        if null_count:
            raise PanelIntegrityError(f"{column} contains null values ({null_count} rows)")
    duplicates = key_frame.duplicated(["year", "UNITID"], keep=False)
    if duplicates.any():
        examples = key_frame.loc[duplicates, ["year", "UNITID"]].drop_duplicates().head(5)
        rendered = ", ".join(
            f"({int(row.year)}, {int(row.UNITID)})" for row in examples.itertuples(index=False)
        )
        raise PanelIntegrityError(
            f"Input contains duplicate (year, UNITID) keys: {rendered}"
        )
    keys = sorted((int(year), int(unitid)) for year, unitid in key_frame.itertuples(index=False, name=None))
    years = sorted({year for year, _unitid in keys})
    return keys, years


def key_fingerprint(keys: list[tuple[int, int]]) -> str:
    digest = hashlib.sha256()
    for year, unitid in keys:
        digest.update(f"{year},{unitid}\n".encode("ascii"))
    return digest.hexdigest()


def validate_staged_output(
    staged_path: Path,
    *,
    expected_schema: pa.Schema,
    input_keys: list[tuple[int, int]],
) -> None:
    output_dataset = ds.dataset(str(staged_path), format="parquet")
    if not output_dataset.schema.equals(expected_schema, check_metadata=False):
        raise PanelIntegrityError(
            f"Output schema differs from the declared Stage 07 schema: "
            f"expected={expected_schema} actual={output_dataset.schema}"
        )
    output_keys, _years = validate_panel_keys(output_dataset)
    if len(output_keys) != len(input_keys):
        raise PanelIntegrityError(
            f"Output row count changed during cleaning: input={len(input_keys)} output={len(output_keys)}"
        )
    if output_keys != input_keys:
        input_set = set(input_keys)
        output_set = set(output_keys)
        missing = sorted(input_set - output_set)[:5]
        extra = sorted(output_set - input_set)[:5]
        raise PanelIntegrityError(
            f"Output (year, UNITID) keys differ from input; missing={missing} extra={extra}"
        )


def _observed_codes(series: pd.Series, *, year: int, flag: str) -> pd.Series:
    """Return integral observed PRCH codes or fail on malformed tokens."""

    nonmissing = series.notna() & series.astype(str).str.strip().ne("")
    numeric = pd.to_numeric(series, errors="coerce")
    invalid = nonmissing & numeric.isna()
    infinite = numeric.isin([float("inf"), float("-inf")])
    fractional = numeric.notna() & ((numeric % 1) != 0)
    bad = invalid | infinite | fractional
    if bad.any():
        examples = ", ".join(repr(value) for value in series.loc[bad].head(5).tolist())
        raise PrchPolicyError(
            f"Invalid PRCH code token(s) for year={year} flag={flag}: {examples}. "
            "Release policy codes must be explicit integers."
        )
    return numeric.dropna().astype(int)


def collect_observed_code_counts(
    dataset: ds.Dataset,
    years: list[int],
    prch_flags: list[str],
    *,
    batch_rows: int,
) -> dict[tuple[int, str, int], int]:
    counts: dict[tuple[int, str, int], int] = {}
    if not prch_flags:
        return counts
    for year in years:
        scanner = dataset.scanner(
            columns=prch_flags,
            filter=ds.field("year") == year,
            batch_size=batch_rows,
            use_threads=False,
            batch_readahead=1,
            fragment_readahead=1,
        )
        for batch in scanner.to_batches():
            frame = batch.to_pandas()
            for flag in prch_flags:
                codes = _observed_codes(frame[flag], year=year, flag=flag)
                for code, count in codes.value_counts().items():
                    key = (year, flag, int(code))
                    counts[key] = counts.get(key, 0) + int(count)
    return counts


def build_release_plan(
    contract: PrchPolicyContract,
    years: list[int],
    panel_columns: list[str],
) -> dict[str, list[str]]:
    """Resolve every exact selector for every in-scope release rule."""

    plan: dict[str, list[str]] = {}
    panel_names = set(panel_columns)
    panel_lookup = {column.upper(): column for column in panel_columns}
    scoped_rules = [
        rule
        for rule in contract.rules
        if any(rule.year_start <= year <= rule.year_end for year in years)
    ]
    predicate_columns = {column for rule in scoped_rules for column in rule.predicate_columns}
    protected_columns = {
        "YEAR",
        "UNITID",
        *predicate_columns,
        *(flag.upper() for flag in panel_columns if flag.upper().startswith("PRCH")),
    }
    for rule in scoped_rules:
        missing_predicates = sorted(set(rule.predicate_columns) - set(panel_lookup))
        if missing_predicates:
            raise PrchPolicyError(
                f"PRCH rule {rule.rule_id} references missing row-predicate columns: "
                + ", ".join(missing_predicates)
            )
        missing_targets = sorted(set(rule.target_columns) - panel_names)
        if missing_targets:
            raise PrchPolicyError(
                f"PRCH rule {rule.rule_id} has unresolved exact target columns: "
                + ", ".join(missing_targets)
            )
        targets = rule.select_target_columns(panel_columns)
        protected_targets = sorted(target for target in targets if target.upper() in protected_columns)
        if protected_targets:
            raise PrchPolicyError(
                f"PRCH rule {rule.rule_id} targets protected key/flag/predicate columns: "
                f"{', '.join(protected_targets)}"
            )
        plan[rule.rule_id] = targets
    return plan


def rule_predicate_mask(frame: pd.DataFrame, rule: PrchPolicyRule) -> pd.Series:
    mask = pd.Series(True, index=frame.index, dtype=bool)
    column_lookup = {column.upper(): column for column in frame.columns}
    for predicate_column, expected in rule.row_predicate:
        column = column_lookup[predicate_column]
        values = frame[column]
        if expected is None:
            clause = values.isna()
        elif isinstance(expected, bool):
            clause = values.eq(expected)
        elif isinstance(expected, (int, float)) and not isinstance(expected, bool):
            clause = pd.to_numeric(values, errors="coerce").eq(float(expected))
        else:
            clause = values.astype("string").str.strip().str.upper().eq(str(expected).strip().upper()).fillna(False)
        mask &= clause.fillna(False)
    return mask


def preflight_release_rows(
    dataset: ds.Dataset,
    years: list[int],
    prch_flags: list[str],
    contract: PrchPolicyContract,
    *,
    batch_rows: int,
) -> dict[tuple[int, str, int], int]:
    """Prove each nonmissing PRCH row matches exactly one reviewed rule."""

    counts: dict[tuple[int, str, int], int] = {}
    scoped_rules = [
        rule
        for rule in contract.rules
        if any(rule.year_start <= year <= rule.year_end for year in years)
    ]
    predicate_columns = sorted({column for rule in scoped_rules for column in rule.predicate_columns})
    panel_lookup = {column.upper(): column for column in dataset.schema.names}
    scan_columns = ["UNITID", *prch_flags, *(panel_lookup[column] for column in predicate_columns)]
    scan_columns = list(dict.fromkeys(scan_columns))
    for year in years:
        scanner = dataset.scanner(
            columns=scan_columns,
            filter=ds.field("year") == year,
            batch_size=batch_rows,
            use_threads=False,
            batch_readahead=1,
            fragment_readahead=1,
        )
        for batch in scanner.to_batches():
            frame = batch.to_pandas()
            for flag in prch_flags:
                codes = _observed_codes(frame[flag], year=year, flag=flag)
                flag_numeric = pd.to_numeric(frame[flag], errors="coerce")
                for code, count in codes.value_counts().items():
                    code_int = int(code)
                    key = (year, flag, code_int)
                    counts[key] = counts.get(key, 0) + int(count)
                    base_mask = flag_numeric.eq(code_int)
                    candidates = contract.matching_rules(year, flag, code_int)
                    if not candidates:
                        raise PrchPolicyError(
                            f"No approved PRCH rule for year={year} flag={flag} code={code_int}. "
                            f"Add a reviewed exact-column rule to {contract.path}; release output was not modified."
                        )
                    match_count = pd.Series(0, index=frame.index, dtype="int16")
                    for rule in candidates:
                        match_count += (base_mask & rule_predicate_mask(frame, rule)).astype("int16")
                    unmatched = base_mask & match_count.eq(0)
                    ambiguous = base_mask & match_count.gt(1)
                    if unmatched.any() or ambiguous.any():
                        problem = unmatched if unmatched.any() else ambiguous
                        state = "no rule" if unmatched.any() else "multiple rules"
                        unitids = ", ".join(str(value) for value in frame.loc[problem, "UNITID"].head(5).tolist())
                        raise PrchPolicyError(
                            f"PRCH row predicate resolution produced {state} for year={year} flag={flag} "
                            f"code={code_int}; example UNITIDs: {unitids}"
                        )
    return counts


ACTION_SCHEMA = pa.schema(
    [
        pa.field("year", pa.int64(), nullable=False),
        pa.field("UNITID", pa.int64(), nullable=False),
        pa.field("flag", pa.string(), nullable=False),
        pa.field("code", pa.int64(), nullable=False),
        pa.field("column", pa.string(), nullable=False),
        pa.field("old_value", pa.string(), nullable=False),
        pa.field("new_value", pa.string()),
        pa.field("action", pa.string(), nullable=False),
        pa.field("rule_id", pa.string(), nullable=False),
        pa.field("accounting_standard", pa.string(), nullable=False),
        pa.field("form", pa.string(), nullable=False),
        pa.field("part", pa.string(), nullable=False),
        pa.field("row_predicate", pa.string(), nullable=False),
    ]
)


class BufferedParquetWriter:
    """Coalesce small tables into bounded deterministic Parquet row groups."""

    def __init__(
        self,
        path: Path,
        schema: pa.Schema,
        *,
        row_group_rows: int,
        compression: str = "snappy",
    ) -> None:
        if row_group_rows <= 0:
            raise ValueError("row_group_rows must be positive")
        self.schema = schema
        self.row_group_rows = row_group_rows
        self._writer = pq.ParquetWriter(path, schema, compression=compression)
        self._tables: list[pa.Table] = []
        self._rows_buffered = 0
        self.rows_received = 0
        self._closed = False

    def write_table(self, table: pa.Table) -> None:
        if self._closed:
            raise RuntimeError("cannot write to a closed BufferedParquetWriter")
        if not table.schema.equals(self.schema, check_metadata=False):
            raise SchemaAlignmentError(
                "Buffered Parquet table schema differs from the declared output schema"
            )
        if table.num_rows == 0:
            return
        self._tables.append(table)
        self._rows_buffered += table.num_rows
        self.rows_received += table.num_rows
        self._flush(final=False)

    def _flush(self, *, final: bool) -> None:
        if not self._tables:
            return
        if not final and self._rows_buffered < self.row_group_rows:
            return

        combined = pa.concat_tables(self._tables)
        offset = 0
        while combined.num_rows - offset >= self.row_group_rows:
            chunk = combined.slice(offset, self.row_group_rows)
            self._writer.write_table(chunk, row_group_size=self.row_group_rows)
            offset += self.row_group_rows
        if final and offset < combined.num_rows:
            self._writer.write_table(
                combined.slice(offset),
                row_group_size=self.row_group_rows,
            )
            offset = combined.num_rows

        remaining = combined.num_rows - offset
        self._tables = [combined.slice(offset)] if remaining else []
        self._rows_buffered = remaining

    def close(self) -> None:
        if self._closed:
            return
        self._flush(final=True)
        self._writer.close()
        self._closed = True

    def flush(self) -> None:
        """Seal the current logical boundary, including its final remainder."""

        if self._closed:
            raise RuntimeError("cannot flush a closed BufferedParquetWriter")
        self._flush(final=True)

    def abort(self) -> None:
        """Close a failed staged writer without flushing pending row data."""

        if self._closed:
            return
        self._tables.clear()
        self._rows_buffered = 0
        self._writer.close()
        self._closed = True


def write_cell_actions(
    writer: BufferedParquetWriter | None,
    frame: pd.DataFrame,
    mask: pd.Series,
    columns: list[str],
    rule: PrchPolicyRule,
) -> int:
    if writer is None:
        return 0
    total = 0
    for column in columns:
        changed = mask & frame[column].notna()
        rows = [
            {
                "year": int(frame.at[index, "year"]),
                "UNITID": int(frame.at[index, "UNITID"]),
                "flag": rule.flag,
                "code": rule.code,
                "column": column,
                "old_value": str(frame.at[index, column]),
                "new_value": None,
                "action": rule.action,
                "rule_id": rule.rule_id,
                "accounting_standard": rule.accounting_standard,
                "form": rule.form,
                "part": rule.part,
                "row_predicate": rule.row_predicate_json,
            }
            for index in frame.index[changed]
        ]
        if rows:
            writer.write_table(pa.Table.from_pylist(rows, schema=ACTION_SCHEMA))
            total += len(rows)
    return total


def contract_policy_rows(contract: PrchPolicyContract) -> list[dict[str, object]]:
    return [
        {
            "rule_id": rule.rule_id,
            "year_start": rule.year_start,
            "year_end": rule.year_end,
            "flag": rule.flag,
            "code": rule.code,
            "action": rule.action,
            "target_columns": "|".join(rule.target_columns),
            "row_predicate": rule.row_predicate_json,
            "accounting_standard": rule.accounting_standard,
            "form": rule.form,
            "part": rule.part,
            "review_status": rule.review_status,
            "source_reference": rule.source_reference,
            "rationale": rule.rationale,
        }
        for rule in contract.rules
    ]


def write_csv_atomic(frame: pd.DataFrame, path: Path, *, run_token: str) -> None:
    staged = path.with_name(f".{path.name}.{run_token}.tmp")
    try:
        frame.to_csv(staged, index=False)
        os.replace(staged, path)
    finally:
        if staged.exists():
            staged.unlink()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json_atomic(payload: dict[str, object], path: Path, *, run_token: str) -> None:
    staged = path.with_name(f".{path.name}.{run_token}.tmp")
    try:
        staged.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(staged, path)
    finally:
        if staged.exists():
            staged.unlink()


def validate_managed_release_paths(qc_dir: Path, runs_dir: Path, out_path: Path) -> None:
    """Refuse release publication over unmanaged directories or panel files."""

    if qc_dir.exists() and not qc_dir.is_symlink():
        raise PrchPolicyError(
            f"Release --qc-dir must be absent or a managed run pointer symlink, not a directory: {qc_dir}. "
            "Use a fresh v2 QC path; legacy evidence is never replaced in place."
        )
    if qc_dir.is_symlink():
        resolved = (qc_dir.parent / os.readlink(qc_dir)).resolve()
        if resolved.parent != runs_dir.resolve():
            raise PrchPolicyError(f"Release --qc-dir points outside its managed run store: {qc_dir} -> {resolved}")
    if out_path.exists() and not out_path.is_symlink():
        raise PrchPolicyError(
            f"Release --output must be absent or the managed panel symlink, not a regular file: {out_path}. "
            "Use a fresh v2 output path; legacy panels are never overwritten in place."
        )


def ensure_managed_panel_link(out_path: Path, qc_dir: Path, *, run_token: str) -> None:
    """Create the stable panel alias that follows the single QC run pointer."""

    logical_target = qc_dir / "panel_clean.parquet"
    expected_target = os.path.relpath(logical_target, out_path.parent)
    if out_path.is_symlink():
        current_target = os.readlink(out_path)
        if current_target != expected_target:
            raise PrchPolicyError(
                f"Release --output is an unmanaged symlink: {out_path} -> {current_target}; "
                f"expected {expected_target}"
            )
        return
    if out_path.exists():
        raise PrchPolicyError(f"Release --output appeared during publication and is not managed: {out_path}")
    staged = out_path.with_name(f".{out_path.name}.{run_token}.tmp")
    try:
        os.symlink(expected_target, staged)
        os.replace(staged, out_path)
    finally:
        if staged.is_symlink() or staged.exists():
            staged.unlink()


def switch_run_pointer(qc_dir: Path, final_run_dir: Path, *, run_token: str) -> None:
    staged = qc_dir.with_name(f".{qc_dir.name}.{run_token}.tmp")
    target = os.path.relpath(final_run_dir, qc_dir.parent)
    try:
        os.symlink(target, staged)
        os.replace(staged, qc_dir)
    finally:
        if staged.is_symlink() or staged.exists():
            staged.unlink()


def main() -> None:
    args = parse_args()
    setup_logging(args.log_file)
    if args.output_row_group_rows <= 0:
        raise SystemExit("--output-row-group-rows must be positive")
    in_path = Path(args.input)
    out_path = Path(args.output)
    if in_path.resolve() == out_path.resolve():
        raise SystemExit("--output must differ from --input; Stage 07 never modifies the raw wide panel in place.")

    dataset = ds.dataset(str(in_path), format="parquet")
    validate_case_unique_columns(dataset.schema)
    required_key_columns = {"year", "UNITID"}
    missing_key_columns = required_key_columns - set(dataset.schema.names)
    if missing_key_columns:
        raise SystemExit(
            "Input is missing required PRCH cleaning key columns: "
            + ", ".join(sorted(missing_key_columns))
        )

    input_keys, years_sorted = validate_panel_keys(dataset)
    if not years_sorted:
        raise SystemExit("Input contains no non-null years for PRCH cleaning.")
    if len(years_sorted) == 1:
        yr = years_sorted[0]
        raise SystemExit(
            f"Refusing to run: input appears to contain only one year ({yr}). "
            "Provide the full stitched panel to avoid a single-year cleaned output."
        )
    all_cols = dataset.schema.names
    prch_flags = [c for c in all_cols if c.upper().startswith("PRCH")]

    release_contract: PrchPolicyContract | None = None
    if args.policy_mode == "release":
        # Load the reviewed contract before creating output or QC paths. The
        # checked-in contract intentionally blocks until mappings are approved.
        release_contract = load_policy_contract(Path(args.prch_policy), release_mode=True)
        if not prch_flags:
            raise PrchPolicyError(
                "Release PRCH cleaning found no PRCH flag columns in the input panel; "
                "this indicates an upstream schema/coverage failure."
            )
        scoped_contract_flags = {
            rule.flag
            for rule in release_contract.rules
            if any(rule.year_start <= year <= rule.year_end for year in years_sorted)
        }
        panel_flag_names = {flag.upper() for flag in prch_flags}
        unmapped_flags = sorted(panel_flag_names - scoped_contract_flags)
        if unmapped_flags:
            raise PrchPolicyError(
                "Release PRCH contract has no year-overlapping rules for input flags: "
                + ", ".join(unmapped_flags)
            )
        missing_panel_flags = sorted(scoped_contract_flags - panel_flag_names)
        if missing_panel_flags:
            raise PrchPolicyError(
                "Release PRCH contract expects flags missing from the input panel: "
                + ", ".join(missing_panel_flags)
            )
        if not args.column_lineage:
            raise PrchPolicyError(
                "Release PRCH cleaning requires --column-lineage; dictionary fallback is development-only."
            )
        if not args.qc_dir:
            raise PrchPolicyError(
                "Release PRCH cleaning requires --qc-dir so cell-level action lineage and policy evidence are retained."
            )

    if args.column_lineage:
        column_sources = build_source_map_from_column_lineage(
            Path(args.column_lineage),
            all_cols,
            require_v2=release_contract is not None,
            batch_rows=args.batch_rows,
        )
        lineage_source = "column_lineage"
    else:
        column_sources = build_source_map_from_dictionary(Path(args.dictionary))
        lineage_source = "dictionary_source_set_fallback"
        print(
            "[development-only] --column-lineage not provided; using dictionary source sets "
            "with the legacy broad PRCH mapping."
        )

    release_plan: dict[str, list[str]] = {}
    flag_cols: dict[str, list[str]] = {flag: [] for flag in prch_flags}
    year_flag_cols: dict[tuple[int, str], set[str]] = {}
    if release_contract is not None:
        release_plan = build_release_plan(release_contract, years_sorted, all_cols)
        observed_counts = preflight_release_rows(
            dataset,
            years_sorted,
            prch_flags,
            release_contract,
            batch_rows=args.batch_rows,
        )
        for rule in release_contract.rules:
            columns = release_plan.get(rule.rule_id, [])
            flag_cols.setdefault(rule.flag, []).extend(columns)
            for year in years_sorted:
                if rule.year_start <= year <= rule.year_end:
                    year_flag_cols.setdefault((year, rule.flag), set()).update(columns)
    else:
        observed_counts = collect_observed_code_counts(
            dataset,
            years_sorted,
            prch_flags,
            batch_rows=args.batch_rows,
        )
        print(
            "[development-only] Applying the legacy broad PRCH family policy. "
            "This mode is not eligible for release."
        )
        for col in all_cols:
            if col in prch_flags:
                continue
            source_files = column_sources.get(col.upper(), set())
            for flag in prch_flags:
                if any(targets_source_file(flag, source_file) for source_file in source_files):
                    flag_cols[flag].append(col)
        for year in years_sorted:
            for flag, columns in flag_cols.items():
                year_flag_cols[(year, flag)] = set(columns)
    flag_cols = {flag: sorted(set(columns)) for flag, columns in flag_cols.items()}

    qc_child_counts: dict[tuple[int, str], int] = {}
    qc_review_counts: dict[tuple[int, str], int] = {}
    qc_cell_counts: dict[tuple[int, str], int] = {}
    qc_code_counts: dict[tuple[int, str, int], int] = dict(observed_counts)

    # All policy/code/target checks above happen before staging any output.
    out_path.parent.mkdir(parents=True, exist_ok=True)
    run_token = f"{os.getpid()}-{uuid.uuid4().hex}"
    qc_dir = Path(args.qc_dir) if args.qc_dir else None
    release_mode = release_contract is not None
    staged_run_dir: Path | None = None
    final_run_dir: Path | None = None
    if release_mode:
        assert qc_dir is not None
        qc_dir.parent.mkdir(parents=True, exist_ok=True)
        runs_dir = qc_dir.parent / f"{qc_dir.name}_runs"
        validate_managed_release_paths(qc_dir, runs_dir, out_path)
        runs_dir.mkdir(parents=True, exist_ok=True)
        staged_run_dir = runs_dir / f".{run_token}.staging"
        final_run_dir = runs_dir / run_token
        staged_run_dir.mkdir()
        staged_out_path = staged_run_dir / "panel_clean.parquet"
        evidence_dir = staged_run_dir
    else:
        if out_path.is_symlink():
            raise PrchPolicyError(
                f"Development mode refuses to replace managed/symlinked output {out_path}; "
                "choose a development-only regular output path."
            )
        staged_out_path = out_path.with_name(f".{out_path.name}.{run_token}.tmp")
        evidence_dir = qc_dir
        if qc_dir is not None:
            stale_release_evidence = [
                path
                for path in (
                    qc_dir / "prch_cell_actions.parquet",
                    qc_dir / "prch_current_run.json",
                )
                if path.exists()
            ]
            if stale_release_evidence:
                raise PrchPolicyError(
                    "Development mode refuses to mix evidence with an existing release QC directory. "
                    "Choose a separate --qc-dir; found: "
                    + ", ".join(str(path) for path in stale_release_evidence)
                )
            qc_dir.mkdir(parents=True, exist_ok=True)

    staged_actions_path: Path | None = None
    if release_mode:
        assert staged_run_dir is not None
        staged_actions_path = staged_run_dir / "prch_cell_actions.parquet"

    panel_writer: BufferedParquetWriter | None = None
    action_writer: BufferedParquetWriter | None = None
    batch_idx = 0
    rows_processed = 0
    last_log = time.time()
    target_schema = dataset.schema
    expected_output_schema = target_schema
    if args.drop_imputation_flags:
        expected_output_schema = pa.schema(
            [field for field in target_schema if not field.name.upper().startswith("X")],
            metadata=target_schema.metadata,
        )

    try:
        panel_writer = BufferedParquetWriter(
            staged_out_path,
            expected_output_schema,
            row_group_rows=args.output_row_group_rows,
        )
        if staged_actions_path is not None:
            action_writer = BufferedParquetWriter(
                staged_actions_path,
                ACTION_SCHEMA,
                row_group_rows=args.output_row_group_rows,
            )
        for year in years_sorted:
            print(f"[year] start {year}")
            year_rows = 0
            scanner = dataset.scanner(
                filter=ds.field("year") == year,
                batch_size=args.batch_rows,
                use_threads=False,
                batch_readahead=1,
                fragment_readahead=1,
            )
            for batch in scanner.to_batches():
                frame = batch.to_pandas()
                batch_idx += 1
                rows_processed += len(frame)
                year_rows += len(frame)
                for flag in prch_flags:
                    flag_num = pd.to_numeric(frame[flag], errors="coerce")
                    if release_contract is not None:
                        for code in sorted(flag_num.dropna().astype(int).unique()):
                            for rule in release_contract.matching_rules(year, flag, int(code)):
                                mask = flag_num.eq(code) & rule_predicate_mask(frame, rule)
                                if not mask.any() or rule.action != "null":
                                    continue
                                columns = release_plan[rule.rule_id]
                                changed_cells = write_cell_actions(action_writer, frame, mask, columns, rule)
                                frame.loc[mask, columns] = pd.NA
                                key = (year, flag)
                                qc_child_counts[key] = qc_child_counts.get(key, 0) + int(mask.sum())
                                qc_cell_counts[key] = qc_cell_counts.get(key, 0) + changed_cells
                    else:
                        child_mask = flag_num.isin(cleaned_child_codes(flag))
                        review_mask = flag_num.isin(review_only_codes(flag))
                        if child_mask.any():
                            key = (year, flag)
                            qc_child_counts[key] = qc_child_counts.get(key, 0) + int(child_mask.sum())
                        if review_mask.any():
                            key = (year, flag)
                            qc_review_counts[key] = qc_review_counts.get(key, 0) + int(review_mask.sum())
                        columns = flag_cols.get(flag, [])
                        if child_mask.any() and columns:
                            key = (year, flag)
                            changed_cells = int(frame.loc[child_mask, columns].notna().sum().sum())
                            qc_cell_counts[key] = qc_cell_counts.get(key, 0) + changed_cells
                            frame.loc[child_mask, columns] = pd.NA

                table = pa.Table.from_pandas(frame, preserve_index=False)
                table = cast_table_to_schema(table, target_schema)
                if args.drop_imputation_flags:
                    drop_cols = [column for column in table.column_names if column.upper().startswith("X")]
                    if drop_cols:
                        table = table.drop(drop_cols)
                panel_writer.write_table(table)

                if args.log_every and batch_idx % args.log_every == 0:
                    now = time.time()
                    if now - last_log >= 1:
                        print(
                            f"[progress] batches={batch_idx} rows={rows_processed:,} "
                            f"current_year={year} year_rows={year_rows:,}"
                        )
                        sys.stdout.flush()
                        last_log = now
            panel_writer.flush()
            if action_writer is not None:
                action_writer.flush()
            print(f"[year] done {year} rows={year_rows:,}")

        if panel_writer.rows_received == 0:
            raise RuntimeError("PRCH cleaning produced no output batches")
        panel_writer.close()
        panel_writer = None
        if action_writer is not None:
            action_writer.close()
            action_writer = None

        validate_staged_output(
            staged_out_path,
            expected_schema=expected_output_schema,
            input_keys=input_keys,
        )

        if evidence_dir is not None:
            legacy_by_flag = {row["flag"]: row for row in policy_rows(prch_flags)}
            summary_rows = []
            for year in years_sorted:
                for flag in prch_flags:
                    if release_contract is not None:
                        matching = [
                            rule
                            for rule in release_contract.rules
                            if rule.flag == flag and rule.year_start <= year <= rule.year_end
                        ]
                        child_codes = ",".join(
                            str(code) for code in sorted({rule.code for rule in matching if rule.action == "null"})
                        )
                        review_codes = ""
                    else:
                        legacy = legacy_by_flag.get(
                            flag,
                            {"child_codes_applied": "", "review_only_codes": ""},
                        )
                        child_codes = legacy["child_codes_applied"]
                        review_codes = legacy["review_only_codes"]
                    targets = sorted(year_flag_cols.get((year, flag), set()))
                    summary_rows.append(
                        {
                            "year": year,
                            "flag": flag,
                            "policy_mode": args.policy_mode,
                            "child_codes_applied": child_codes,
                            "review_only_codes": review_codes,
                            "target_columns": len(targets),
                            "has_target_columns": bool(targets),
                            "lineage_source": lineage_source,
                            "child_rows_cleaned": qc_child_counts.get((year, flag), 0),
                            "cells_cleaned": qc_cell_counts.get((year, flag), 0),
                            "review_only_rows": qc_review_counts.get((year, flag), 0),
                        }
                    )
            write_csv_atomic(
                pd.DataFrame(summary_rows),
                evidence_dir / "prch_clean_summary.csv",
                run_token=run_token,
            )

            col_rows = []
            for flag, columns in flag_cols.items():
                for column in columns:
                    col_rows.append(
                        {
                            "flag": flag,
                            "column": column,
                            "source_files": "|".join(sorted(column_sources.get(column.upper(), set()))),
                            "lineage_source": lineage_source,
                            "policy_mode": args.policy_mode,
                        }
                    )
            write_csv_atomic(
                pd.DataFrame(
                    col_rows,
                    columns=["flag", "column", "source_files", "lineage_source", "policy_mode"],
                ),
                evidence_dir / "prch_clean_columns.csv",
                run_token=run_token,
            )
            write_csv_atomic(
                pd.DataFrame(
                    [
                        {
                            "lineage_source": lineage_source,
                            "panel_columns": len(all_cols),
                            "panel_columns_with_lineage": sum(
                                1 for column in all_cols if column.upper() in column_sources
                            ),
                            "prch_flags": len(prch_flags),
                            "policy_mode": args.policy_mode,
                        }
                    ]
                ),
                evidence_dir / "prch_lineage_summary.csv",
                run_token=run_token,
            )
            policy_output = (
                contract_policy_rows(release_contract)
                if release_contract is not None
                else policy_rows(prch_flags)
            )
            write_csv_atomic(
                pd.DataFrame(policy_output),
                evidence_dir / "prch_flag_policy.csv",
                run_token=run_token,
            )
            code_rows = []
            for (year, flag, code), count in sorted(qc_code_counts.items()):
                if release_contract is not None:
                    matching_rules = release_contract.matching_rules(year, flag, code)
                    actions = {rule.action for rule in matching_rules}
                    policy_bucket = next(iter(actions)) if len(actions) == 1 else "predicate_scoped"
                    target_count = len(
                        {
                            target
                            for rule in matching_rules
                            for target in release_plan.get(rule.rule_id, [])
                        }
                    )
                    rule_id = "|".join(sorted(rule.rule_id for rule in matching_rules))
                else:
                    policy_bucket = classify_flag_code(flag, code)
                    target_count = len(flag_cols.get(flag, []))
                    rule_id = "legacy-development-policy"
                code_rows.append(
                    {
                        "year": year,
                        "flag": flag,
                        "code": code,
                        "policy_bucket": policy_bucket,
                        "target_columns": target_count,
                        "has_target_columns": bool(target_count),
                        "rows": count,
                        "rule_id": rule_id,
                        "policy_mode": args.policy_mode,
                    }
                )
            write_csv_atomic(
                pd.DataFrame(code_rows),
                evidence_dir / "prch_flag_code_counts.csv",
                run_token=run_token,
            )

        if release_mode:
            assert staged_run_dir is not None
            assert final_run_dir is not None
            assert qc_dir is not None
            current_payload = {
                "schema_version": "1.0",
                "run_id": run_token,
                "run_path": str(final_run_dir),
                "panel": str(final_run_dir / "panel_clean.parquet"),
                "status": "complete",
            }
            (staged_run_dir / "prch_current_run.json").write_text(
                json.dumps(current_payload, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
            artifact_paths = sorted(
                path for path in staged_run_dir.iterdir() if path.is_file()
            )
            manifest = {
                "schema_version": "1.0",
                "run_id": run_token,
                "status": "complete",
                "policy_mode": "release",
                "input": str(in_path),
                "output": str(out_path),
                "row_count": len(input_keys),
                "key_sha256": key_fingerprint(input_keys),
                "input_schema": str(dataset.schema),
                "output_schema": str(expected_output_schema),
                "policy_path": str(release_contract.path),
                "policy_sha256": sha256_file(release_contract.path),
                "artifacts": [
                    {
                        "name": path.name,
                        "bytes": path.stat().st_size,
                        "sha256": sha256_file(path),
                    }
                    for path in artifact_paths
                ],
            }
            (staged_run_dir / "prch_run_manifest.json").write_text(
                json.dumps(manifest, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )

            # One directory rename seals a complete immutable run. The stable
            # panel symlink follows the QC pointer, and one atomic symlink
            # replacement switches panel plus all evidence together.
            os.replace(staged_run_dir, final_run_dir)
            ensure_managed_panel_link(out_path, qc_dir, run_token=run_token)
            switch_run_pointer(qc_dir, final_run_dir, run_token=run_token)
            print(f"Promoted complete PRCH run atomically: {final_run_dir}")
        else:
            development_manifest = {
                "schema_version": "1.0",
                "policy_mode": "development",
                "release_eligible": False,
                "warning": "Legacy broad PRCH behavior; this output is not release eligible.",
                "input": str(in_path),
                "output": str(out_path),
                "row_count": len(input_keys),
                "key_sha256": key_fingerprint(input_keys),
                "output_sha256": sha256_file(staged_out_path),
            }
            write_json_atomic(
                development_manifest,
                out_path.with_suffix(out_path.suffix + ".development.json"),
                run_token=run_token,
            )
            os.replace(staged_out_path, out_path)
        print(f"Wrote cleaned panel atomically: {out_path}")
        if qc_dir is not None:
            print(f"QC written to {qc_dir}")
    finally:
        if panel_writer is not None:
            panel_writer.abort()
        if action_writer is not None:
            action_writer.abort()
        if staged_out_path.exists():
            staged_out_path.unlink()
        if staged_actions_path is not None and staged_actions_path.exists():
            staged_actions_path.unlink()
        if staged_run_dir is not None and staged_run_dir.exists():
            shutil.rmtree(staged_run_dir)


if __name__ == "__main__":
    main()
    
