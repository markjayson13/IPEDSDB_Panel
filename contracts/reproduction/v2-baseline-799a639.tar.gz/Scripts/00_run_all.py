#!/usr/bin/env python3
"""
Stage 00: orchestrate the end-to-end Access-to-panel workflow.

Reads:
- `IPEDSDB_ROOT` configuration
- stage-level inputs expected by `Scripts/01-09`

Writes:
- the staged outputs produced by any enabled pipeline step
- release artifacts under `Panels/v2/` only in explicit release mode
- isolated development artifacts under `Panels/development/v2/`
- mode-isolated QA and causal provenance when `--run-qaqc` is enabled

This is the main Python entrypoint behind `manual_commands.sh`.
Open this file when you want to see the real stage order or understand which skip flags bypass which parts of the pipeline.
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path
from typing import Mapping, Sequence

import pyarrow.compute as pc
import pyarrow.dataset as ds
import pyarrow.parquet as pq

from access_build_utils import DEFAULT_IPEDSDB_ROOT, ensure_data_layout, parse_years, repo_root
from stage_provenance import (
    CANONICAL_STAGE_VERSIONS,
    ProvenanceError,
    finalize_run,
    git_state,
    inventory,
    missing_system_tool_bindings,
    new_run_dir,
    tool_versions,
    utc_now,
    validate_release_container_bindings,
    write_stage_manifest,
)


SCRIPTS_DIR = Path(__file__).resolve().parent

STAGE_VERSIONS = dict(CANONICAL_STAGE_VERSIONS)


class ProvenanceSession:
    """Ordered receipt state for one invocation-wide build."""

    def __init__(self, *, root: Path, repo: Path, mode: str) -> None:
        self.root = root
        self.repo = repo
        self.mode = mode
        self.run_dir = new_run_dir(root)
        self.previous_manifest: Path | None = None
        self.stages: list[str] = []

    def record(
        self,
        *,
        stage_id: str,
        started_at: str,
        command: Sequence[str],
        runtime_config: Mapping[str, object],
        input_paths: Sequence[str | Path],
        captured_inputs: Mapping[str, Mapping[str, object]],
        output_paths: Sequence[str | Path],
        status: str,
    ) -> None:
        manifest = write_stage_manifest(
            run_dir=self.run_dir,
            stage_id=stage_id,
            stage_version=STAGE_VERSIONS[stage_id],
            started_at=started_at,
            command=command,
            runtime_config=runtime_config,
            input_paths=input_paths,
            captured_inputs=captured_inputs,
            output_paths=output_paths,
            repo=self.repo,
            status=status,
            previous_manifest=self.previous_manifest,
            require_outputs=status == "success",
        )
        self.previous_manifest = manifest
        self.stages.append(stage_id)

    def finalize(self) -> Path:
        return finalize_run(
            root=self.root,
            run_dir=self.run_dir,
            stages=self.stages,
            repo=self.repo,
            mode=self.mode,
            promote=True,
        )


def run(
    cmd: list[str],
    dry_run: bool,
    *,
    session: ProvenanceSession | None = None,
    stage_id: str = "",
    runtime_config: Mapping[str, object] | None = None,
    input_paths: Sequence[str | Path] = (),
    output_paths: Sequence[str | Path] = (),
) -> None:
    print("+", " ".join(cmd))
    if dry_run:
        return
    started_at = utc_now()
    captured_inputs = inventory(input_paths) if session is not None else {}
    res = subprocess.run(cmd, check=False)
    if session is not None:
        session.record(
            stage_id=stage_id,
            started_at=started_at,
            command=cmd,
            runtime_config=runtime_config or {},
            input_paths=input_paths,
            captured_inputs=captured_inputs,
            output_paths=output_paths,
            status="success" if res.returncode == 0 else "failed",
        )
    if res.returncode != 0:
        raise SystemExit(res.returncode)


def main() -> None:
    repo = repo_root()
    default_root = os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT))
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=default_root, help="External IPEDSDB_ROOT")
    ap.add_argument("--years", default="2004:2023", help='Year span, e.g. "2004:2023"')
    ap.add_argument("--skip-download", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--skip-extract", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--skip-dictionary", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--skip-harmonize", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--skip-stitch", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--skip-wide", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--run-cleaning", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--run-qaqc", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--build-custom", action=argparse.BooleanOptionalAction, default=False)
    ap.add_argument("--custom-vars", default=None)
    ap.add_argument("--custom-vars-file", default=None)
    ap.add_argument("--custom-output", default=None)
    ap.add_argument(
        "--pipeline-mode",
        choices=("development", "release"),
        default="development",
        help="Release mode requires an unskipped clean build and seals an authoritative causal chain.",
    )
    ap.add_argument(
        "--prch-policy-mode",
        choices=("release", "development"),
        default=None,
        help="Defaults to release policy in release builds and development policy otherwise.",
    )
    ap.add_argument(
        "--memory-profile",
        choices=("standard", "low"),
        default="standard",
        help=(
            "Resource profile for the causal build. The low profile keeps "
            "DuckDB at 2 GB/one thread, reduces streaming batches, and places "
            "all spill files under the external data root."
        ),
    )
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    if args.pipeline_mode == "release":
        skipped = [
            name
            for name in ("download", "extract", "dictionary", "harmonize", "stitch", "wide")
            if bool(getattr(args, f"skip_{name}"))
        ]
        if skipped:
            raise SystemExit(
                "Release mode cannot skip causal stages; rebuild the complete chain. Skipped: "
                + ", ".join(skipped)
            )
        if not args.run_cleaning or not args.run_qaqc:
            raise SystemExit("Release mode requires --run-cleaning and --run-qaqc.")
        if args.prch_policy_mode == "development":
            raise SystemExit("Release mode cannot use the development PRCH policy.")
        if not args.dry_run:
            state = git_state(repo)
            if bool(state["git_dirty"]):
                raise SystemExit("Release mode requires a clean Git tree before any stage runs.")
            versions = tool_versions()
            try:
                validate_release_container_bindings(
                    repo=repo,
                    git_commit=str(state["git_commit"]),
                    bindings=versions,
                )
            except ProvenanceError as exc:
                raise SystemExit(str(exc)) from exc
            missing_tools = missing_system_tool_bindings(versions)
            if missing_tools:
                raise SystemExit(
                    "Release mode requires immutable executable bindings for system tools: "
                    + ", ".join(missing_tools)
                )

    layout = ensure_data_layout(args.root)
    stage_layout = (
        layout
        if args.pipeline_mode == "release"
        else ensure_data_layout(layout.root / "development")
    )
    years = parse_years(args.years)
    year_spec = f"{years[0]}:{years[-1]}"
    year_token = f"{years[0]}_{years[-1]}"
    cross_sections_v2 = stage_layout.cross_sections / "v2"
    panels_v2 = (
        layout.panels / "v2"
        if args.pipeline_mode == "release"
        else layout.panels / "development" / "v2"
    )
    checks_v2 = (
        layout.checks / "v2"
        if args.pipeline_mode == "release"
        else layout.checks / "development" / "v2"
    )
    if args.pipeline_mode == "development" and args.custom_output:
        custom_path = Path(args.custom_output).expanduser().resolve()
        canonical_roots = [
            (layout.panels / "v2").resolve(),
            (layout.checks / "v2").resolve(),
        ]
        if any(custom_path == root or root in custom_path.parents for root in canonical_roots):
            raise SystemExit(
                "Development custom outputs cannot write canonical Panels/v2 or Checks/v2 destinations."
            )
    scalar_long_out = panels_v2 / f"panel_long_scalar_{year_token}.parquet"
    dimensioned_long_out = panels_v2 / f"panel_long_dimensioned_{year_token}.parquet"
    source_rows_out = panels_v2 / f"panel_source_rows_{year_token}.parquet"
    wide_out = panels_v2 / f"panel_wide_analysis_{year_token}.parquet"
    raw_wide_out = panels_v2 / f"panel_wide_raw_{year_token}.parquet"
    clean_out = panels_v2 / f"panel_clean_prch_{year_token}.parquet"
    dict_lake = stage_layout.dictionary / "v2" / "dictionary_lake.parquet"
    column_lineage = checks_v2 / "wide_qc" / "qc_value_lineage.parquet"
    ambiguity_overrides = repo / "contracts" / "dictionary_ambiguity_overrides.csv"
    source_metadata_aliases = repo / "contracts" / "source_metadata_aliases.csv"
    panel_contract = repo / "contracts" / "panel_spec.toml"
    source_lock = repo / "contracts" / "source_releases.csv"
    table_grain = repo / "contracts" / "table_grain.csv"
    source_columns = repo / "contracts" / "source_columns.csv"
    metadata_backfills = repo / "contracts" / "metadata_backfill_approvals.csv"
    analysis_schema = repo / "contracts" / "analysis_schema.csv"
    discrete_families = repo / "contracts" / "discrete_families.csv"
    prch_policy = repo / "contracts" / "prch_policy.csv"
    session = None if args.dry_run else ProvenanceSession(
        root=stage_layout.root,
        repo=repo,
        mode=args.pipeline_mode,
    )
    runtime_base = {
        "pipeline_mode": args.pipeline_mode,
        "years": year_spec,
        "root": str(layout.root),
        "stage_root": str(stage_layout.root),
        "memory_profile": args.memory_profile,
    }
    low_memory = args.memory_profile == "low"
    strict_flag = "--release-strict" if args.pipeline_mode == "release" else "--no-release-strict"
    if args.dry_run:
        print(
            "[namespace] "
            f"stage_root={stage_layout.root} panels={panels_v2} checks={checks_v2} "
            f"provenance={stage_layout.root / 'Checks' / 'v2' / 'stage_manifests' / 'runs'}"
        )

    if args.pipeline_mode == "release":
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "QA_QC" / "11_validate_panel_contract.py"),
                "--contract",
                str(panel_contract),
            ],
            args.dry_run,
        )

    if not args.skip_download:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "01_download_access_databases.py"),
                "--root",
                str(stage_layout.root),
                "--years",
                year_spec,
                strict_flag,
            ],
            args.dry_run,
            session=session,
            stage_id="01",
            runtime_config=runtime_base,
            input_paths=[panel_contract, source_lock],
            output_paths=[
                path
                for year in years
                for path in (
                    stage_layout.raw_access / str(year) / "manifest.csv",
                    stage_layout.raw_access / str(year) / "downloads",
                )
            ],
        )

    if not args.skip_extract:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "02_extract_access_db.py"),
                "--root",
                str(stage_layout.root),
                "--years",
                year_spec,
                strict_flag,
            ],
            args.dry_run,
            session=session,
            stage_id="02",
            runtime_config=runtime_base,
            input_paths=[
                panel_contract,
                source_lock,
                *[
                    path
                    for year in years
                    for path in (
                        stage_layout.raw_access / str(year) / "manifest.csv",
                        stage_layout.raw_access / str(year) / "downloads",
                    )
                ],
            ],
            output_paths=[
                stage_layout.checks / "extract_qc",
                *[
                    path
                    for year in years
                    for path in (
                        stage_layout.raw_access / str(year) / "extracted_db",
                        stage_layout.raw_access / str(year) / "tables_csv",
                        stage_layout.raw_access / str(year) / "metadata",
                        stage_layout.raw_access / str(year) / "qc",
                    )
                ],
            ],
        )

    if not args.skip_dictionary:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "03_dictionary_ingest.py"),
                "--root",
                str(stage_layout.root),
                "--years",
                year_spec,
            ],
            args.dry_run,
            session=session,
            stage_id="03",
            runtime_config=runtime_base,
            input_paths=[
                panel_contract,
                metadata_backfills,
                *[
                    path
                    for year in years
                    for path in (
                        stage_layout.raw_access / str(year) / "manifest.csv",
                        stage_layout.raw_access / str(year) / "metadata",
                        stage_layout.raw_access / str(year) / "tables_csv",
                    )
                ],
            ],
            output_paths=[
                dict_lake,
                stage_layout.dictionary / "v2" / "dictionary_codes.parquet",
            ],
        )

    if not args.skip_harmonize:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "04_harmonize.py"),
                "--root",
                str(stage_layout.root),
                "--years",
                year_spec,
                "--output-dir",
                str(cross_sections_v2),
                "--parts-dir-base",
                str(stage_layout.build / "v2" / "harmonize_parts"),
                "--dictionary",
                str(dict_lake),
                "--dictionary-ambiguity-overrides",
                str(ambiguity_overrides),
                "--source-metadata-aliases",
                str(source_metadata_aliases),
                *(
                    [
                        "--chunksize",
                        "2000",
                        "--value-cols-per-chunk",
                        "25",
                        "--dedupe-temp-dir",
                        str(stage_layout.build / "v2" / "harmonize_duckdb_tmp"),
                        "--dedupe-threads",
                        "1",
                        "--duckdb-memory-limit",
                        "1GB",
                    ]
                    if low_memory
                    else []
                ),
                strict_flag,
            ],
            args.dry_run,
            session=session,
            stage_id="04",
            runtime_config=runtime_base,
            input_paths=[
                panel_contract,
                table_grain,
                source_columns,
                ambiguity_overrides,
                source_metadata_aliases,
                dict_lake,
                *[
                    path
                    for year in years
                    for path in (
                        stage_layout.raw_access / str(year) / "manifest.csv",
                        stage_layout.raw_access / str(year) / "metadata" / "table_inventory.csv",
                        stage_layout.raw_access / str(year) / "tables_csv",
                    )
                ],
            ],
            output_paths=[
                cross_sections_v2,
                *[
                    stage_layout.checks / "v2" / "harmonize_qc" / f"source_column_coverage_{year}.csv"
                    for year in years
                ],
                *[
                    stage_layout.checks / "v2" / "harmonize_qc" / f"harmonize_summary_{year}.csv"
                    for year in years
                ],
                *[
                    stage_layout.checks / "v2" / "harmonize_qc" / f"dropped_missing_unitid_{year}.csv"
                    for year in years
                ],
                *[
                    stage_layout.checks / "v2" / "release_qc" / f"release_summary_{year}.csv"
                    for year in years
                ],
            ],
        )

    if not args.skip_stitch:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "05_stitch_long.py"),
                "--root",
                str(stage_layout.root),
                "--years",
                year_spec,
                "--cross-sections-dir",
                str(cross_sections_v2),
                "--output",
                str(scalar_long_out),
                "--dimensioned-output",
                str(dimensioned_long_out),
                "--source-rows-output",
                str(source_rows_out),
                *(
                    [
                        "--duckdb-memory-limit",
                        "1GB",
                        "--duckdb-threads",
                        "1",
                        "--duckdb-temp-dir",
                        str(stage_layout.build / "v2" / "stitch_duckdb_tmp"),
                        "--batch-rows",
                        "10000",
                        "--stitch-batch-rows",
                        "65536",
                    ]
                    if low_memory
                    else []
                ),
            ],
            args.dry_run,
            session=session,
            stage_id="05",
            runtime_config=runtime_base,
            input_paths=[panel_contract, cross_sections_v2],
            output_paths=[
                scalar_long_out,
                dimensioned_long_out,
                source_rows_out,
                stage_layout.checks / "v2" / "harmonize_qc" / "stitch_summary.csv",
            ],
        )

    if not args.skip_wide:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "06_build_wide_panel.py"),
                "--root",
                str(layout.root),
                "--input",
                str(scalar_long_out),
                "--dimensioned-input",
                str(dimensioned_long_out),
                "--source-column-coverage",
                str(stage_layout.checks / "v2" / "harmonize_qc"),
                "--out_dir",
                str(stage_layout.build / "v2" / "wide_analysis_parts"),
                "--years",
                year_spec,
                "--dictionary",
                str(dict_lake),
                "--build-mode",
                args.pipeline_mode,
                "--analysis-schema-contract",
                str(analysis_schema),
                "--discrete-family-contract",
                str(discrete_families),
                "--wide-analysis-out",
                str(wide_out),
                "--raw-wide-out",
                str(raw_wide_out),
                "--typed-output",
                "--collapse-disc",
                "--qc-dir",
                str(checks_v2 / "wide_qc"),
                "--column-lineage-out",
                str(column_lineage),
                "--disc-qc-dir",
                str(checks_v2 / "disc_qc"),
                "--release-bundle-root",
                str(panels_v2 / "wide_release"),
                "--duckdb-path",
                str(stage_layout.build / "v2" / "ipedsdb_build.duckdb"),
                "--duckdb-temp-dir",
                str(stage_layout.build / "v2" / "duckdb_tmp"),
                *(
                    [
                        "--duckdb-memory-limit",
                        "1GB",
                        "--duckdb-threads",
                        "1",
                        "--scan-batch-rows",
                        "25000",
                        "--wide-parquet-row-group-size",
                        "8192",
                    ]
                    if low_memory
                    else []
                ),
                "--log-file",
                str(stage_layout.build / "v2" / "logs" / "06_build_wide_panel.log"),
                "--persist-duckdb",
            ],
            args.dry_run,
            session=session,
            stage_id="06",
            runtime_config={**runtime_base, "wide_build_mode": args.pipeline_mode},
            input_paths=[
                panel_contract,
                analysis_schema,
                discrete_families,
                scalar_long_out,
                dimensioned_long_out,
                dict_lake,
                stage_layout.checks / "v2" / "harmonize_qc",
            ],
            output_paths=[
                wide_out,
                raw_wide_out,
                column_lineage,
                checks_v2 / "wide_qc",
                checks_v2 / "disc_qc",
            ],
        )

    if args.run_cleaning:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "07_clean_panel.py"),
                "--input",
                str(wide_out),
                "--output",
                str(clean_out),
                "--dictionary",
                str(dict_lake),
                "--column-lineage",
                str(column_lineage),
                "--qc-dir",
                str(checks_v2 / "prch_qc"),
                "--prch-policy",
                str(prch_policy),
                "--policy-mode",
                args.prch_policy_mode or ("release" if args.pipeline_mode == "release" else "development"),
                *(
                    [
                        "--batch-rows",
                        "250",
                        "--output-row-group-rows",
                        "4096",
                    ]
                    if low_memory
                    else []
                ),
            ],
            args.dry_run,
            session=session,
            stage_id="07",
            runtime_config={
                **runtime_base,
                "prch_policy_mode": args.prch_policy_mode
                or ("release" if args.pipeline_mode == "release" else "development"),
            },
            input_paths=[panel_contract, prch_policy, wide_out, dict_lake, column_lineage],
            output_paths=[clean_out, checks_v2 / "prch_qc"],
        )

    if args.build_custom:
        custom_output = args.custom_output or str(
            panels_v2 / f"custom_panel_{years[0]}_{years[-1]}.parquet"
        )
        cmd = [
            sys.executable,
            str(SCRIPTS_DIR / "08_build_custom_panel.py"),
            "--input",
            str(clean_out if args.run_cleaning else wide_out),
            "--output",
            custom_output,
            "--years",
            year_spec,
        ]
        if args.custom_vars:
            cmd += ["--vars", args.custom_vars]
        if args.custom_vars_file:
            cmd += ["--vars-file", args.custom_vars_file]
        run(
            cmd,
            args.dry_run,
            session=session,
            stage_id="08",
            runtime_config={**runtime_base, "custom_vars": args.custom_vars or ""},
            input_paths=[clean_out if args.run_cleaning else wide_out],
            output_paths=[custom_output],
        )

    if args.run_qaqc:
        run(
            [
                sys.executable,
                str(SCRIPTS_DIR / "QA_QC" / "00_dictionary_qaqc.py"),
                "--root",
                str(stage_layout.root),
            ],
            args.dry_run,
            session=session,
            stage_id="qa00",
            runtime_config=runtime_base,
            input_paths=[
                panel_contract,
                dict_lake,
                stage_layout.dictionary / "v2" / "dictionary_codes.parquet",
            ],
            output_paths=[stage_layout.checks / "dictionary_qc"],
        )
        if args.run_cleaning:
            run(
                [
                    sys.executable,
                    str(SCRIPTS_DIR / "QA_QC" / "01_panel_qa.py"),
                    "--raw",
                    str(wide_out),
                    "--clean",
                    str(clean_out),
                    "--out-dir",
                    str(checks_v2 / "panel_qc"),
                    "--prch-qc-dir",
                    str(checks_v2 / "prch_qc"),
                    "--prch-policy",
                    str(prch_policy),
                    "--qa-mode",
                    args.pipeline_mode,
                    *(
                        [
                            "--batch-rows",
                            "250",
                            "--action-reconciliation-mode",
                            "duckdb",
                            "--action-temp-dir",
                            str(stage_layout.build / "v2" / "panel_qa_action_tmp"),
                            "--action-buffer-rows",
                            "10000",
                            "--duckdb-memory-limit",
                            "1GB",
                            "--duckdb-threads",
                            "1",
                        ]
                        if low_memory
                        else []
                    ),
                ],
                args.dry_run,
                session=session,
                stage_id="qa01",
                runtime_config={**runtime_base, "qa_mode": args.pipeline_mode},
                input_paths=[
                    panel_contract,
                    wide_out,
                    clean_out,
                    checks_v2 / "prch_qc",
                    prch_policy,
                ],
                output_paths=[checks_v2 / "panel_qc"],
            )

    if session is not None:
        try:
            sealed = session.finalize()
        except ProvenanceError as exc:
            raise SystemExit(f"Could not seal causal stage chain: {exc}") from exc
        pointer_kind = "release" if args.pipeline_mode == "release" else "development"
        print(f"[provenance] sealed {pointer_kind} run: {sealed}")

    if not args.dry_run and scalar_long_out.exists():
        dataset = ds.dataset(str(scalar_long_out), format="parquet")
        unique_year_values: set[int] = set()
        for batch in dataset.to_batches(columns=["year"], batch_size=100_000):
            year_values = batch.column(0)
            unique_year_values.update(
                int(value)
                for value in pc.unique(year_values).to_pylist()
                if value is not None
            )
        unique_years = sorted(unique_year_values)
        print(f"[summary] long panel years={unique_years[:3]}...{unique_years[-3:]}")
        pq.ParquetFile(scalar_long_out)
        print(f"[summary] stitched scalar long panel: {scalar_long_out}")
    if not args.dry_run and dimensioned_long_out.exists():
        pq.ParquetFile(dimensioned_long_out)
        print(f"[summary] stitched dimensioned long panel: {dimensioned_long_out}")
    if not args.dry_run and wide_out.exists():
        pq.ParquetFile(wide_out)
        print(f"[summary] wide analysis panel: {wide_out}")
    if not args.dry_run and clean_out.exists():
        pq.ParquetFile(clean_out)
        print(f"[summary] clean analysis panel: {clean_out}")


if __name__ == "__main__":
    main()
