#!/usr/bin/env python3
"""Create and verify causal, per-stage pipeline manifests.

The release manifest in ``QA_QC/12_build_release_manifest.py`` inventories a
finished release.  This module serves a different purpose: it records the
inputs that actually caused each stage output.  A release chain is valid only
while its commit, contracts, inputs, outputs, schemas, runtime, and ordered
stage-manifest hashes still match.

Stage 00 imports the functions below directly.  The CLI is intentionally small
so CI and operators can independently verify an already-built chain.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import tomllib
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import pyarrow.parquet as pq

from access_build_utils import atomic_write_json, atomic_write_text, repo_root


MANIFEST_SCHEMA_VERSION = "1.0"
DEFAULT_REQUIRED_STAGES = ("01", "02", "03", "04", "05", "06", "07")
DIRECT_PACKAGES = ("pandas", "pyarrow", "openpyxl", "requests", "beautifulsoup4", "duckdb")
SYSTEM_TOOLS = ("mdb-tables", "mdb-schema", "mdb-export", "mdb-count")
CONTAINER_IMAGE_DIGEST_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
CONTAINER_IMAGE_REVISION_RE = re.compile(r"^[0-9a-f]{40}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
CANONICAL_STAGE_SPECS = {
    "01": ("01-download-access-v2", "Scripts/01_download_access_databases.py"),
    "02": ("02-extract-access-v2", "Scripts/02_extract_access_db.py"),
    "03": ("03-dictionary-v2", "Scripts/03_dictionary_ingest.py"),
    "04": ("04-lossless-harmonize-v2", "Scripts/04_harmonize.py"),
    "05": ("05-split-lane-stitch-v2", "Scripts/05_stitch_long.py"),
    "06": ("06-reviewed-wide-v2", "Scripts/06_build_wide_panel.py"),
    "07": ("07-reviewed-prch-v2", "Scripts/07_clean_panel.py"),
    "08": ("08-custom-panel-v1", "Scripts/08_build_custom_panel.py"),
    "qa00": ("qa00-dictionary-v2", "Scripts/QA_QC/00_dictionary_qaqc.py"),
    "qa01": ("qa01-panel-release-v2", "Scripts/QA_QC/01_panel_qa.py"),
}
CANONICAL_STAGE_VERSIONS = {
    stage: version for stage, (version, _script) in CANONICAL_STAGE_SPECS.items()
}


class ProvenanceError(RuntimeError):
    """A causal manifest cannot be created or verified."""


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_json(value: object) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _path_entry(path: Path) -> dict[str, object]:
    """Return content metadata for a file, directory, or symlink target."""
    path = path.expanduser().absolute()
    if not path.exists():
        return {"path": str(path), "kind": "missing", "sha256": ""}
    if path.is_dir():
        members: list[dict[str, object]] = []
        for member in sorted((item for item in path.rglob("*") if item.is_file()), key=lambda item: item.as_posix()):
            relative = member.relative_to(path).as_posix()
            members.append(
                {
                    "relative_path": relative,
                    "size_bytes": member.stat().st_size,
                    "sha256": sha256_file(member),
                }
            )
        return {
            "path": str(path),
            "kind": "directory",
            "file_count": len(members),
            "size_bytes": sum(int(row["size_bytes"]) for row in members),
            "sha256": sha256_json(members),
        }

    entry: dict[str, object] = {
        "path": str(path),
        "kind": "file",
        "size_bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }
    if path.suffix.lower() == ".parquet":
        parquet = pq.ParquetFile(path)
        schema = parquet.schema_arrow
        schema_payload = [
            {"name": field.name, "type": str(field.type), "nullable": bool(field.nullable)}
            for field in schema
        ]
        entry["row_count"] = int(parquet.metadata.num_rows)
        entry["schema_hash"] = sha256_json(schema_payload)
    elif path.suffix.lower() == ".csv":
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.reader(handle, strict=True)
                header = next(reader, [])
                rows = sum(1 for _ in reader)
        except (UnicodeError, csv.Error) as exc:
            raise ProvenanceError(f"Cannot inventory malformed CSV {path}: {exc}") from exc
        entry["row_count"] = rows
        entry["schema_hash"] = sha256_json(header)
    return entry


def inventory(paths: Iterable[str | Path]) -> dict[str, dict[str, object]]:
    entries: dict[str, dict[str, object]] = {}
    for raw_path in paths:
        path = Path(raw_path).expanduser().absolute()
        key = str(path)
        if key in entries:
            continue
        entries[key] = _path_entry(path)
    return entries


def _git_value(repo: Path, *args: str) -> str:
    try:
        return subprocess.check_output(
            ["git", *args], cwd=repo, text=True, stderr=subprocess.DEVNULL
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return ""


def git_state(repo: Path) -> dict[str, object]:
    commit = _git_value(repo, "rev-parse", "HEAD")
    if not commit:
        raise ProvenanceError(f"Repository has no resolvable Git commit: {repo}")
    return {
        "git_commit": commit,
        "git_branch": _git_value(repo, "branch", "--show-current"),
        "git_dirty": bool(_git_value(repo, "status", "--porcelain", "--untracked-files=all")),
    }


def _package_version(name: str) -> str:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return ""


def _system_tool_binding(name: str) -> dict[str, str]:
    executable = shutil.which(name)
    if not executable:
        return {"path": "", "sha256": "", "version": ""}
    resolved = Path(executable).resolve()
    try:
        completed = subprocess.run(
            [str(resolved), "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=10,
        )
        version = (completed.stdout or completed.stderr).strip().splitlines()[0]
    except (OSError, subprocess.SubprocessError, IndexError):
        version = ""
    return {
        "path": str(resolved),
        "sha256": sha256_file(resolved) if resolved.is_file() else "",
        "version": version,
    }


def tool_versions() -> dict[str, object]:
    return {
        "python": sys.version.split()[0],
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "packages": {name: _package_version(name) for name in DIRECT_PACKAGES},
        "system_tools": {name: _system_tool_binding(name) for name in SYSTEM_TOOLS},
        "container_image_digest": os.environ.get("CONTAINER_IMAGE_DIGEST", "").strip(),
        "container_image_revision": os.environ.get(
            "CONTAINER_IMAGE_REVISION",
            "",
        ).strip(),
        "container_requirements_lock_sha256": os.environ.get(
            "CONTAINER_REQUIREMENTS_LOCK_SHA256",
            "",
        ).strip(),
    }


def validate_release_container_bindings(
    *,
    repo: Path,
    git_commit: str,
    bindings: Mapping[str, object],
) -> None:
    """Require an exact image/source/lock identity for release execution."""

    repo = repo.expanduser().absolute()
    digest = str(bindings.get("container_image_digest", "")).strip()
    revision = str(bindings.get("container_image_revision", "")).strip()
    lock_sha256 = str(
        bindings.get("container_requirements_lock_sha256", "")
    ).strip()
    if not CONTAINER_IMAGE_DIGEST_RE.fullmatch(digest):
        raise ProvenanceError(
            "Release container image digest must match sha256:<64 lowercase hex>."
        )
    if not CONTAINER_IMAGE_REVISION_RE.fullmatch(revision):
        raise ProvenanceError(
            "Release container image revision must be a full lowercase Git "
            "commit."
        )
    if revision != git_commit:
        raise ProvenanceError(
            "Release container image revision does not match the mounted "
            "source HEAD."
        )
    if not SHA256_RE.fullmatch(lock_sha256):
        raise ProvenanceError(
            "Release container requirements lock binding must be a lowercase "
            "SHA-256."
        )
    lock_path = repo / "requirements-lock.txt"
    if not lock_path.is_file():
        raise ProvenanceError(
            f"Release container requirements lock is missing: {lock_path}"
        )
    actual_lock_sha256 = sha256_file(lock_path)
    if lock_sha256 != actual_lock_sha256:
        raise ProvenanceError(
            "Release container requirements lock binding differs from the "
            "mounted source requirements lock."
        )


def missing_system_tool_bindings(receipt: Mapping[str, object]) -> list[str]:
    bindings = receipt.get("system_tools", {})
    if not isinstance(bindings, dict):
        return list(SYSTEM_TOOLS)
    missing: list[str] = []
    for name in SYSTEM_TOOLS:
        binding = bindings.get(name)
        if not isinstance(binding, dict) or not all(
            str(binding.get(field, "")).strip() for field in ("path", "sha256", "version")
        ):
            missing.append(name)
    return missing


def panel_contract(repo: Path) -> tuple[str, list[Path]]:
    spec_path = repo / "contracts" / "panel_spec.toml"
    if not spec_path.is_file():
        raise ProvenanceError(f"Missing panel contract: {spec_path}")
    with spec_path.open("rb") as handle:
        spec = tomllib.load(handle)
    contract_id = str(spec.get("contract_id", "")).strip()
    if not contract_id:
        raise ProvenanceError(f"Panel contract lacks contract_id: {spec_path}")
    contract_paths = [spec_path]
    policies = spec.get("policies", {})
    if isinstance(policies, dict):
        for relative in policies.values():
            contract_paths.append(repo / str(relative))
    contract_paths.append(repo / "requirements-lock.txt")
    unique = sorted({path.absolute() for path in contract_paths}, key=lambda path: str(path))
    missing = [str(path) for path in unique if not path.is_file()]
    if missing:
        raise ProvenanceError("Missing release contract inputs: " + ", ".join(missing))
    return contract_id, unique


def current_contract_hashes(repo: Path) -> tuple[str, dict[str, str]]:
    contract_id, paths = panel_contract(repo)
    return contract_id, {path.relative_to(repo).as_posix(): sha256_file(path) for path in paths}


def new_run_dir(root: Path, *, run_id: str | None = None) -> Path:
    token = run_id or datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:12]
    if "/" in token or token in {"", ".", ".."}:
        raise ProvenanceError(f"Unsafe provenance run id: {token!r}")
    run_dir = root.expanduser().absolute() / "Checks" / "v2" / "stage_manifests" / "runs" / token
    run_dir.mkdir(parents=True, exist_ok=False)
    return run_dir


def _required_present(entries: Mapping[str, Mapping[str, object]], label: str) -> None:
    missing = [path for path, entry in entries.items() if entry.get("kind") == "missing"]
    if missing:
        raise ProvenanceError(f"Stage {label} has missing artifacts: " + ", ".join(missing))


def write_stage_manifest(
    *,
    run_dir: Path,
    stage_id: str,
    stage_version: str,
    started_at: str,
    command: Sequence[str],
    runtime_config: Mapping[str, object],
    input_paths: Sequence[str | Path],
    output_paths: Sequence[str | Path],
    captured_inputs: Mapping[str, Mapping[str, object]] | None = None,
    repo: Path | None = None,
    status: str = "success",
    previous_manifest: Path | None = None,
    require_outputs: bool = True,
) -> Path:
    """Write one immutable stage receipt after the command finishes."""
    repo = (repo or repo_root()).expanduser().absolute()
    run_dir = run_dir.expanduser().absolute()
    manifest_path = run_dir / f"{stage_id}.json"
    if manifest_path.exists():
        raise ProvenanceError(f"Stage manifest is immutable and already exists: {manifest_path}")
    contract_id, contract_hashes = current_contract_hashes(repo)
    git = git_state(repo)
    # The orchestrator captures inputs before launching the stage.  Computing
    # them only after completion would miss a stage that mutated its own input.
    inputs = (
        {str(path): dict(entry) for path, entry in captured_inputs.items()}
        if captured_inputs is not None
        else inventory(input_paths)
    )
    outputs = inventory(output_paths)
    if status == "success":
        _required_present(inputs, f"{stage_id} inputs")
    if require_outputs and status == "success":
        _required_present(outputs, f"{stage_id} outputs")

    previous: dict[str, str] = {}
    if previous_manifest is not None:
        resolved = previous_manifest.expanduser().absolute()
        if not resolved.is_file():
            raise ProvenanceError(f"Previous stage manifest is missing: {resolved}")
        previous = {"path": str(resolved), "sha256": sha256_file(resolved)}

    manifest = {
        "manifest_schema_version": MANIFEST_SCHEMA_VERSION,
        "stage_id": str(stage_id),
        "stage_version": str(stage_version),
        "started_at": started_at,
        "completed_at": utc_now(),
        "git_commit": git["git_commit"],
        "git_branch": git["git_branch"],
        "git_dirty": git["git_dirty"],
        "contract_id": contract_id,
        "contract_hashes": contract_hashes,
        "command": list(command),
        "runtime_config": dict(runtime_config),
        "input_paths": list(inputs),
        "input_hashes": {path: entry.get("sha256", "") for path, entry in inputs.items()},
        "input_metadata": inputs,
        "tool_versions": tool_versions(),
        "output_paths": list(outputs),
        "output_hashes": {path: entry.get("sha256", "") for path, entry in outputs.items()},
        "row_counts": {
            path: entry["row_count"] for path, entry in outputs.items() if "row_count" in entry
        },
        "schema_hashes": {
            path: entry["schema_hash"] for path, entry in outputs.items() if "schema_hash" in entry
        },
        "output_metadata": outputs,
        "previous_stage_manifest": previous,
        "status": status,
    }
    atomic_write_json(manifest_path, manifest)
    return manifest_path


def _reject_duplicate_json_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
    output: dict[str, object] = {}
    for key, value in pairs:
        if key in output:
            raise ProvenanceError(f"Provenance JSON repeats key {key!r}")
        output[key] = value
    return output


def _load_json(path: Path) -> dict[str, object]:
    try:
        value = json.loads(
            path.read_text(encoding="utf-8"),
            object_pairs_hook=_reject_duplicate_json_keys,
        )
    except (OSError, json.JSONDecodeError, ProvenanceError) as exc:
        raise ProvenanceError(f"Cannot read provenance JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise ProvenanceError(f"Provenance JSON must contain an object: {path}")
    return value


def _metadata_projection(
    metadata: object,
    field: str,
) -> dict[str, object]:
    if not isinstance(metadata, dict):
        return {}
    return {
        str(path): entry.get(field, "")
        for path, entry in metadata.items()
        if isinstance(entry, dict) and field in entry
    }


def _validate_recorded_inventory_fields(
    manifest: Mapping[str, object],
    *,
    stage: str,
    failures: list[str],
) -> None:
    for lane in ("input", "output"):
        metadata = manifest.get(f"{lane}_metadata")
        paths = manifest.get(f"{lane}_paths")
        hashes = manifest.get(f"{lane}_hashes")
        if not isinstance(metadata, dict):
            failures.append(f"stage {stage} {lane}_metadata is malformed")
            continue
        if (
            not isinstance(paths, list)
            or len(paths) != len(metadata)
            or set(paths) != set(metadata)
        ):
            failures.append(f"stage {stage} {lane}_paths do not match {lane}_metadata")
        expected_hashes = {
            str(path): entry.get("sha256", "")
            for path, entry in metadata.items()
            if isinstance(entry, dict)
        }
        if hashes != expected_hashes:
            failures.append(f"stage {stage} {lane}_hashes do not match {lane}_metadata")
    output_metadata = manifest.get("output_metadata")
    if manifest.get("row_counts") != _metadata_projection(output_metadata, "row_count"):
        failures.append(f"stage {stage} row_counts do not match output_metadata")
    if manifest.get("schema_hashes") != _metadata_projection(output_metadata, "schema_hash"):
        failures.append(f"stage {stage} schema_hashes do not match output_metadata")


def _valid_interval(started: object, completed: object) -> bool:
    try:
        start_value = datetime.fromisoformat(str(started))
        complete_value = datetime.fromisoformat(str(completed))
    except ValueError:
        return False
    return start_value.tzinfo is not None and complete_value.tzinfo is not None and complete_value >= start_value


def canonical_stage_identity_failures(
    manifest: Mapping[str, object],
    *,
    stage: str,
    repo: Path,
) -> list[str]:
    """Bind a release receipt to the reviewed stage version and script path."""
    expected = CANONICAL_STAGE_SPECS.get(stage)
    if expected is None:
        return [f"release stage {stage} is not declared in the canonical stage registry"]
    expected_version, relative_script = expected
    failures: list[str] = []
    if manifest.get("stage_version") != expected_version:
        failures.append(
            f"stage {stage} version is not canonical: {manifest.get('stage_version')!r}"
        )
    command = manifest.get("command")
    if not isinstance(command, list) or len(command) < 2:
        failures.append(f"stage {stage} command does not identify its canonical script")
        return failures
    raw_script = Path(str(command[1])).expanduser()
    observed_script = (
        raw_script if raw_script.is_absolute() else repo / raw_script
    ).absolute()
    expected_script = (repo / relative_script).absolute()
    if observed_script != expected_script:
        failures.append(
            f"stage {stage} command script is not canonical: {observed_script}"
        )
    return failures


def finalize_run(
    *,
    root: Path,
    run_dir: Path,
    stages: Sequence[str],
    repo: Path | None = None,
    mode: str = "development",
    promote: bool = False,
) -> Path:
    """Seal a complete run and optionally switch the authoritative pointer."""
    repo = (repo or repo_root()).expanduser().absolute()
    run_dir = run_dir.expanduser().absolute()
    run_manifest_path = run_dir / "run_manifest.json"
    if run_manifest_path.exists():
        raise ProvenanceError(f"Run manifest is immutable and already exists: {run_manifest_path}")
    if not stages or len(stages) != len(set(stages)):
        raise ProvenanceError("Cannot seal a run with an empty or duplicate ordered stage list")
    if mode == "release":
        required_positions = [stages.index(stage) for stage in DEFAULT_REQUIRED_STAGES if stage in stages]
        if (
            len(required_positions) != len(DEFAULT_REQUIRED_STAGES)
            or required_positions != sorted(required_positions)
        ):
            raise ProvenanceError("Release run lacks the ordered Stage 01-through-07 chain")
    contract_id, contract_hashes = current_contract_hashes(repo)
    git = git_state(repo)
    tools = tool_versions()
    if mode == "release" and bool(git["git_dirty"]):
        raise ProvenanceError("Release run cannot be sealed from a dirty Git tree")
    if mode == "release":
        validate_release_container_bindings(
            repo=repo,
            git_commit=str(git["git_commit"]),
            bindings=tools,
        )
    missing_tools = missing_system_tool_bindings(tools)
    if mode == "release" and missing_tools:
        raise ProvenanceError(
            "Release run cannot be sealed without bound system tools: " + ", ".join(missing_tools)
        )

    stage_hashes: dict[str, str] = {}
    previous: Path | None = None
    for stage in stages:
        path = run_dir / f"{stage}.json"
        if not path.is_file():
            raise ProvenanceError(f"Cannot seal run; stage manifest is missing: {path}")
        manifest = _load_json(path)
        expected_link = {} if previous is None else {
            "path": str(previous.absolute()),
            "sha256": sha256_file(previous),
        }
        if manifest.get("manifest_schema_version") != MANIFEST_SCHEMA_VERSION:
            raise ProvenanceError(f"Cannot seal run; stage {stage} has an unsupported manifest schema")
        if manifest.get("stage_id") != stage or manifest.get("status") != "success":
            raise ProvenanceError(f"Cannot seal run; stage {stage} is not a matching successful receipt")
        if manifest.get("previous_stage_manifest") != expected_link:
            raise ProvenanceError(f"Cannot seal run; stage {stage} has a broken causal predecessor link")
        if manifest.get("git_commit") != git["git_commit"]:
            raise ProvenanceError(f"Cannot seal run; stage {stage} was built at a different commit")
        if mode == "release" and bool(manifest.get("git_dirty")):
            raise ProvenanceError(f"Cannot seal run; stage {stage} was built from a dirty tree")
        if (
            manifest.get("contract_id") != contract_id
            or manifest.get("contract_hashes") != contract_hashes
        ):
            raise ProvenanceError(f"Cannot seal run; stage {stage} has stale contract hashes")
        if manifest.get("tool_versions") != tools:
            raise ProvenanceError(f"Cannot seal run; stage {stage} has stale tool/runtime bindings")
        if mode == "release":
            identity_failures = canonical_stage_identity_failures(
                manifest,
                stage=stage,
                repo=repo,
            )
            if identity_failures:
                raise ProvenanceError(
                    "Cannot seal run; " + "; ".join(identity_failures)
                )
        stage_hashes[stage] = sha256_file(path)
        previous = path
    run_manifest = {
        "manifest_schema_version": MANIFEST_SCHEMA_VERSION,
        "run_id": run_dir.name,
        "mode": mode,
        "completed_at": utc_now(),
        "git_commit": git["git_commit"],
        "git_dirty": git["git_dirty"],
        "contract_id": contract_id,
        "contract_hashes": contract_hashes,
        "ordered_stages": list(stages),
        "stage_manifest_hashes": stage_hashes,
        "tool_versions": tools,
        "status": "success",
    }
    atomic_write_json(run_manifest_path, run_manifest)
    if mode == "release":
        # Re-inventory every causal input and output before publication. A
        # failed verification leaves the previous CURRENT pointer untouched.
        verify_run(
            root=root,
            repo=repo,
            run_dir=run_dir,
            required_stages=DEFAULT_REQUIRED_STAGES,
            require_clean=True,
            require_current_tools=True,
            require_container_digest=True,
            require_system_tools=True,
        )
    if promote:
        pointer_dir = root.expanduser().absolute() / "Checks" / "v2" / "stage_manifests"
        pointer_dir.mkdir(parents=True, exist_ok=True)
        pointer_name = "CURRENT" if mode == "release" else "CURRENT-DEVELOPMENT"
        relative = run_dir.relative_to(pointer_dir).as_posix()
        atomic_write_text(pointer_dir / pointer_name, relative + "\n")
    return run_manifest_path


def resolve_run_dir(root: Path, run_dir: Path | None = None) -> Path:
    if run_dir is not None:
        return run_dir.expanduser().absolute()
    pointer_dir = root.expanduser().absolute() / "Checks" / "v2" / "stage_manifests"
    pointer = pointer_dir / "CURRENT"
    if not pointer.is_file():
        raise ProvenanceError(f"Missing authoritative release provenance pointer: {pointer}")
    relative = pointer.read_text(encoding="utf-8").strip()
    candidate = (pointer_dir / relative).resolve()
    runs_dir = (pointer_dir / "runs").resolve()
    if candidate.parent != runs_dir:
        raise ProvenanceError(f"Unsafe release provenance pointer target: {relative!r}")
    return candidate


def _compare_inventory(recorded: object, *, label: str, failures: list[str]) -> None:
    if not isinstance(recorded, dict):
        failures.append(f"{label}: metadata is not an object")
        return
    for raw_path, raw_entry in recorded.items():
        if not isinstance(raw_entry, dict):
            failures.append(f"{label}: malformed entry for {raw_path}")
            continue
        current = _path_entry(Path(raw_path))
        if current.get("sha256") != raw_entry.get("sha256"):
            failures.append(f"{label}: content hash changed for {raw_path}")
        if current.get("kind") != raw_entry.get("kind"):
            failures.append(f"{label}: artifact kind changed for {raw_path}")
        for field in ("row_count", "schema_hash"):
            if raw_entry.get(field) != current.get(field):
                failures.append(f"{label}: {field} changed for {raw_path}")


def verify_run(
    *,
    root: Path,
    repo: Path | None = None,
    run_dir: Path | None = None,
    required_stages: Sequence[str] = DEFAULT_REQUIRED_STAGES,
    require_clean: bool = True,
    require_current_tools: bool = True,
    require_container_digest: bool = True,
    require_system_tools: bool = True,
) -> dict[str, object]:
    """Verify the sealed chain against the current repository and filesystem."""
    repo = (repo or repo_root()).expanduser().absolute()
    resolved_run = resolve_run_dir(root, run_dir)
    run_manifest_path = resolved_run / "run_manifest.json"
    run_manifest = _load_json(run_manifest_path)
    failures: list[str] = []
    git = git_state(repo)
    contract_id, contract_hashes = current_contract_hashes(repo)
    tools = tool_versions()

    if run_manifest.get("manifest_schema_version") != MANIFEST_SCHEMA_VERSION:
        failures.append("run manifest schema version is unsupported")
    if run_manifest.get("status") != "success":
        failures.append("run manifest status is not success")
    if run_manifest.get("mode") != "release":
        failures.append("authoritative run mode is not release")
    ordered_stages = list(run_manifest.get("ordered_stages", []))
    if not all(isinstance(stage, str) and stage for stage in ordered_stages):
        failures.append("ordered stage list is malformed")
        ordered_stages = []
    if len(ordered_stages) != len(set(ordered_stages)):
        failures.append("ordered stage list contains duplicates")
    required_positions = [ordered_stages.index(stage) for stage in required_stages if stage in ordered_stages]
    if (
        len(required_positions) != len(required_stages)
        or required_positions != sorted(required_positions)
    ):
        failures.append("ordered stage list does not contain the required release chain in order")
    if run_manifest.get("git_commit") != git["git_commit"]:
        failures.append("run manifest commit is stale")
    if run_manifest.get("contract_id") != contract_id or run_manifest.get("contract_hashes") != contract_hashes:
        failures.append("run manifest contract hashes are stale")
    if require_clean and (bool(git["git_dirty"]) or bool(run_manifest.get("git_dirty"))):
        failures.append("release provenance requires a clean Git tree")
    if require_current_tools and run_manifest.get("tool_versions") != tools:
        failures.append("run manifest tool/runtime receipt differs from the current environment")
    if require_container_digest:
        try:
            validate_release_container_bindings(
                repo=repo,
                git_commit=str(git["git_commit"]),
                bindings=tools,
            )
        except ProvenanceError as exc:
            failures.append(str(exc))
    if require_system_tools:
        missing_tools = missing_system_tool_bindings(tools)
        if missing_tools:
            failures.append("required system tool bindings are missing: " + ",".join(missing_tools))

    recorded_stage_hashes = run_manifest.get("stage_manifest_hashes", {})
    if not isinstance(recorded_stage_hashes, dict):
        recorded_stage_hashes = {}
        failures.append("run manifest stage hashes are malformed")
    elif set(recorded_stage_hashes) != set(ordered_stages):
        failures.append("run manifest stage-hash inventory does not match ordered stages")

    previous_path: Path | None = None
    # Verify every sealed receipt, including optional custom/QA stages, while
    # separately requiring the canonical 01-through-07 release subsequence.
    for stage in ordered_stages:
        path = resolved_run / f"{stage}.json"
        if not path.is_file():
            failures.append(f"missing stage manifest: {stage}")
            previous_path = path
            continue
        observed_manifest_sha = sha256_file(path)
        if recorded_stage_hashes.get(stage) != observed_manifest_sha:
            failures.append(f"sealed stage-manifest hash changed: {stage}")
        manifest = _load_json(path)
        required_fields = {
            "manifest_schema_version", "stage_id", "stage_version", "started_at", "completed_at", "git_commit", "git_dirty",
            "contract_id", "contract_hashes", "command", "runtime_config", "input_paths", "input_hashes",
            "input_metadata", "tool_versions", "output_paths", "output_hashes", "row_counts", "schema_hashes",
            "output_metadata", "previous_stage_manifest", "status",
        }
        missing_fields = sorted(required_fields - set(manifest))
        if missing_fields:
            failures.append(f"stage {stage} is missing fields: {','.join(missing_fields)}")
        if manifest.get("stage_id") != stage:
            failures.append(f"stage id mismatch in {path.name}")
        if manifest.get("manifest_schema_version") != MANIFEST_SCHEMA_VERSION:
            failures.append(f"stage {stage} manifest schema version is unsupported")
        if not str(manifest.get("stage_version", "")).strip():
            failures.append(f"stage {stage} has a blank stage version")
        if not _valid_interval(manifest.get("started_at"), manifest.get("completed_at")):
            failures.append(f"stage {stage} has an invalid execution interval")
        if not isinstance(manifest.get("command"), list) or not manifest.get("command"):
            failures.append(f"stage {stage} has no recorded command")
        if not isinstance(manifest.get("runtime_config"), dict):
            failures.append(f"stage {stage} runtime configuration is malformed")
        if manifest.get("status") != "success":
            failures.append(f"stage {stage} status is not success")
        if manifest.get("git_commit") != git["git_commit"]:
            failures.append(f"stage {stage} commit is stale")
        if require_clean and bool(manifest.get("git_dirty")):
            failures.append(f"stage {stage} was produced from a dirty Git tree")
        if manifest.get("contract_id") != contract_id or manifest.get("contract_hashes") != contract_hashes:
            failures.append(f"stage {stage} contract hashes are stale")
        if require_current_tools and manifest.get("tool_versions") != tools:
            failures.append(f"stage {stage} tool/runtime receipt differs from current environment")
        if run_manifest.get("mode") == "release":
            failures.extend(
                canonical_stage_identity_failures(manifest, stage=stage, repo=repo)
            )
        _validate_recorded_inventory_fields(manifest, stage=stage, failures=failures)
        _compare_inventory(manifest.get("input_metadata"), label=f"stage {stage} input", failures=failures)
        _compare_inventory(manifest.get("output_metadata"), label=f"stage {stage} output", failures=failures)

        link = manifest.get("previous_stage_manifest", {})
        if previous_path is None:
            if link not in ({}, None):
                failures.append(f"first stage {stage} unexpectedly links to a previous manifest")
        else:
            if not isinstance(link, dict):
                failures.append(f"stage {stage} previous-manifest link is malformed")
            else:
                if link.get("path") != str(previous_path.absolute()):
                    failures.append(f"stage {stage} previous-manifest path is wrong")
                if previous_path.is_file() and link.get("sha256") != sha256_file(previous_path):
                    failures.append(f"stage {stage} previous-manifest hash is stale")
        previous_path = path

    result = {
        "status": "pass" if not failures else "fail",
        "run_dir": str(resolved_run),
        "required_stages": list(required_stages),
        "verified_stages": ordered_stages,
        "failure_count": len(failures),
        "failures": failures,
    }
    if failures:
        raise ProvenanceError("Causal stage-manifest verification failed:\n- " + "\n- ".join(failures))
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    verify = subparsers.add_parser("verify", help="verify an authoritative or explicit run")
    verify.add_argument("--root", required=True)
    verify.add_argument("--repo-root", default=str(repo_root()))
    verify.add_argument("--run-dir", default=None)
    verify.add_argument("--require-stages", default=",".join(DEFAULT_REQUIRED_STAGES))
    verify.add_argument("--require-clean", action=argparse.BooleanOptionalAction, default=True)
    verify.add_argument("--require-current-tools", action=argparse.BooleanOptionalAction, default=True)
    verify.add_argument("--require-container-digest", action=argparse.BooleanOptionalAction, default=True)
    verify.add_argument("--require-system-tools", action=argparse.BooleanOptionalAction, default=True)
    verify.add_argument("--report", default=None)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.command == "verify":
        stages = tuple(value.strip() for value in args.require_stages.split(",") if value.strip())
        try:
            result = verify_run(
                root=Path(args.root),
                repo=Path(args.repo_root),
                run_dir=Path(args.run_dir) if args.run_dir else None,
                required_stages=stages,
                require_clean=bool(args.require_clean),
                require_current_tools=bool(args.require_current_tools),
                require_container_digest=bool(args.require_container_digest),
                require_system_tools=bool(args.require_system_tools),
            )
        except ProvenanceError as exc:
            print(str(exc), file=sys.stderr)
            return 1
        if args.report:
            atomic_write_json(Path(args.report), result)
        print(f"Causal stage-manifest verification passed: {len(stages)} stages")
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
