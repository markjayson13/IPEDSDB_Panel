#!/usr/bin/env python3
"""
Stage 02: extract each yearly Access database and inventory its tables.

Reads:
- `Raw_Access_Databases/<year>/downloads/*.zip`
- yearly `manifest.csv`

Release-strict extraction requires a verified source-lock manifest and exact
Access/CSV row-count agreement for every exported table.

Writes:
- `Raw_Access_Databases/<year>/extracted_db/*`
- `Raw_Access_Databases/<year>/tables_csv/*`
- `Raw_Access_Databases/<year>/metadata/*`
- `Raw_Access_Databases/<year>/qc/*`
- `Checks/extract_qc/*`

The Stage 01 ``manifest.csv`` is an immutable acquisition receipt. Stage 02
writes its own ``metadata/extraction_receipt.csv`` instead of rewriting that
upstream input.
"""
from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import tempfile
import tomllib
import uuid
import zipfile

import pandas as pd

from access_build_utils import (
    atomic_write_json,
    atomic_write_text,
    can_serve_metadata_role_from_capabilities,
    canonical_source_file,
    classify_table_role,
    compute_file_metadata,
    csv_header_and_rowcount,
    decode_tool_output,
    ensure_data_layout,
    executable_identity,
    maybe_mdb_count_binary,
    normalize_table_name,
    normalize_text_key,
    parse_years,
    read_json_object,
    require_mdb_tools,
    run_checked,
    safe_table_filename,
    table_role_capabilities,
    validate_file_integrity,
)


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE_LOCK = REPO_ROOT / "contracts" / "source_releases.csv"
DEFAULT_PANEL_CONTRACT = REPO_ROOT / "contracts" / "panel_spec.toml"
STAGE_VERSION = "02-extract-access-v2"
EXPORT_NORMALIZATION_CHUNK_SIZE = 1024 * 1024


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=None, help="External IPEDSDB_ROOT")
    ap.add_argument("--years", default="2004:2023")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--fail-on-missing-metadata", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument(
        "--release-strict",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Require source-lock integrity and complete Access/CSV row-count agreement.",
    )
    ap.add_argument("--source-lock", default=str(DEFAULT_SOURCE_LOCK))
    ap.add_argument("--contract", default=str(DEFAULT_PANEL_CONTRACT))
    return ap.parse_args()


def load_contract_id(path: Path) -> str:
    with path.open("rb") as fh:
        contract_id = str(tomllib.load(fh).get("contract_id", "")).strip()
    if not contract_id:
        raise ValueError(f"Panel contract lacks contract_id: {path}")
    return contract_id


def load_source_lock_row(path: Path, year: int) -> dict[str, str]:
    with path.open(newline="", encoding="utf-8") as fh:
        rows = [
            {str(key): str(value or "").strip() for key, value in row.items()}
            for row in csv.DictReader(fh)
            if str(row.get("year", "")).strip() == str(year)
        ]
    if len(rows) != 1:
        raise ValueError(f"Expected exactly one source-lock row for year {year}, found {len(rows)}")
    return rows[0]


def verify_stage01_source_receipt(
    manifest_row: dict[str, object],
    *,
    year: int,
    source_lock_path: Path,
    contract_path: Path,
) -> dict[str, str]:
    contract_id = load_contract_id(contract_path)
    if str(manifest_row.get("contract_id", "")).strip() != contract_id:
        raise ValueError(f"Stage 01 contract_id does not match current contract for year {year}")
    lock_size, lock_sha = validate_file_integrity(
        source_lock_path,
        expected_size=str(manifest_row.get("source_lock_filesize_bytes", "")).strip(),
        expected_sha256=str(manifest_row.get("source_lock_sha256", "")).strip(),
        require_expectations=True,
    )
    del lock_size, lock_sha
    locked = load_source_lock_row(source_lock_path, year)
    if locked.get("contract_id", "") != contract_id:
        raise ValueError(f"Source-lock contract_id does not match current contract for year {year}")
    if locked.get("lock_status", "").lower() != "approved":
        raise ValueError(f"Source-lock row is not approved for year {year}")
    comparisons = {
        "access_filename": "access_filename",
        "expected_access_sha256": "access_expected_sha256",
        "access_size_bytes": "access_expected_filesize_bytes",
        "documentation_filename": "doc_filename",
        "expected_documentation_sha256": "doc_expected_sha256",
        "documentation_size_bytes": "doc_expected_filesize_bytes",
    }
    for lock_field, manifest_field in comparisons.items():
        if locked.get(lock_field, "") != str(manifest_row.get(manifest_field, "")).strip():
            raise ValueError(
                f"Stage 01 manifest {manifest_field} does not match source lock for year {year}"
            )
    return locked


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".part", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def _safe_member_path(info: zipfile.ZipInfo) -> PurePosixPath:
    raw = info.filename.replace("\\", "/")
    member = PurePosixPath(raw)
    unix_mode = info.external_attr >> 16
    file_type = stat.S_IFMT(unix_mode)
    if (
        not raw
        or member.is_absolute()
        or any(part in {"", ".", ".."} for part in member.parts)
        or (member.parts and ":" in member.parts[0])
        or file_type == stat.S_IFLNK
        or file_type not in {0, stat.S_IFREG, stat.S_IFDIR}
    ):
        raise ValueError(f"unsafe ZIP member: {info.filename!r}")
    if info.flag_bits & 0x1:
        raise ValueError(f"unsafe ZIP member (encrypted): {info.filename!r}")
    return member


def _directory_inventory(directory: Path) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    if not directory.is_dir():
        return rows
    for path in sorted(directory.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"Symlink is not allowed in extracted cache: {path}")
        if not path.is_file():
            continue
        size, sha256 = validate_file_integrity(path)
        rows.append({"path": path.relative_to(directory).as_posix(), "size_bytes": size, "sha256": sha256})
    return rows


def _extraction_cache_matches(
    zip_path: Path,
    extracted_dir: Path,
    cache_manifest_path: Path,
) -> bool:
    receipt = read_json_object(cache_manifest_path)
    if receipt is None or receipt.get("manifest_version") != 1:
        return False
    archive_size, archive_sha = validate_file_integrity(zip_path)
    if receipt.get("archive_size_bytes") != archive_size or receipt.get("archive_sha256") != archive_sha:
        return False
    try:
        active_dir = resolve_active_extraction(extracted_dir)
        observed_files = _directory_inventory(active_dir)
    except ValueError:
        return False
    return (
        receipt.get("active_version") == active_dir.relative_to(extracted_dir).as_posix()
        and receipt.get("extracted_files") == observed_files
        and bool(observed_files)
    )


def resolve_active_extraction(extracted_dir: Path) -> Path:
    pointer = extracted_dir / "CURRENT"
    if not pointer.is_file():
        return extracted_dir
    relative_text = pointer.read_text(encoding="utf-8").strip()
    relative = PurePosixPath(relative_text)
    if (
        relative.is_absolute()
        or len(relative.parts) != 2
        or relative.parts[0] != ".versions"
        or any(part in {"", ".", ".."} for part in relative.parts)
    ):
        raise ValueError(f"Invalid extraction CURRENT pointer: {pointer}: {relative_text!r}")
    active = extracted_dir.joinpath(*relative.parts)
    if not active.is_dir() or active.is_symlink():
        raise ValueError(f"Extraction CURRENT pointer does not resolve to a directory: {active}")
    return active


def _promote_extraction_version(staging_dir: Path, extracted_dir: Path, archive_sha: str) -> Path:
    """Promote a version, then atomically switch the stable CURRENT pointer."""
    extracted_dir.mkdir(parents=True, exist_ok=True)
    versions_dir = extracted_dir / ".versions"
    versions_dir.mkdir(parents=True, exist_ok=True)
    version_dir = versions_dir / f"{archive_sha}-{uuid.uuid4().hex}"
    os.replace(staging_dir, version_dir)
    relative = version_dir.relative_to(extracted_dir).as_posix()
    atomic_write_text(extracted_dir / "CURRENT", relative + "\n")

    # Old versions and legacy extracted files are never active after CURRENT
    # switches. Cleanup happens only after the atomic pointer update, so a
    # crash can leave inert files but cannot make them current.
    for child in list(extracted_dir.iterdir()):
        if child.name in {".versions", "CURRENT"}:
            continue
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child)
        else:
            child.unlink(missing_ok=True)
    for child in list(versions_dir.iterdir()):
        if child != version_dir:
            shutil.rmtree(child)
    return version_dir


def unzip_archive(
    zip_path: Path,
    extracted_dir: Path,
    force: bool,
    *,
    cache_manifest_path: Path | None = None,
) -> str:
    """Safely extract into staging and atomically replace a verified cache."""
    receipt_path = cache_manifest_path or extracted_dir.with_suffix(".extraction-manifest.json")
    if not force and _extraction_cache_matches(zip_path, extracted_dir, receipt_path):
        return "skipped_verified"

    archive_size, archive_sha = validate_file_integrity(zip_path)
    extracted_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{extracted_dir.name}.staging-", dir=extracted_dir.parent))
    try:
        with zipfile.ZipFile(zip_path, "r") as archive:
            members: list[tuple[zipfile.ZipInfo, PurePosixPath]] = []
            seen: set[str] = set()
            for info in archive.infolist():
                member = _safe_member_path(info)
                member_key = member.as_posix().casefold()
                if member_key in seen:
                    raise ValueError(f"unsafe ZIP member (duplicate path): {info.filename!r}")
                seen.add(member_key)
                members.append((info, member))
            for info, member in members:
                target = staging.joinpath(*member.parts)
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info, "r") as source, target.open("wb") as output:
                    shutil.copyfileobj(source, output)
                    output.flush()
                    os.fsync(output.fileno())
        if not _directory_inventory(staging):
            raise ValueError(f"ZIP archive contains no files: {zip_path}")
        try:
            validate_file_integrity(
                zip_path,
                expected_size=archive_size,
                expected_sha256=archive_sha,
                require_expectations=True,
            )
        except ValueError as exc:
            raise ValueError(f"ZIP archive changed during extraction: {zip_path}: {exc}") from exc
        extracted_files = _directory_inventory(staging)
        active_dir = _promote_extraction_version(staging, extracted_dir, archive_sha)
        active_version = active_dir.relative_to(extracted_dir).as_posix()
        atomic_write_json(
            receipt_path,
            {
                "manifest_version": 1,
                "archive_filename": zip_path.name,
                "archive_size_bytes": archive_size,
                "archive_sha256": archive_sha,
                "active_version": active_version,
                "extracted_files": extracted_files,
            },
        )
        return "extracted"
    finally:
        if staging.exists():
            shutil.rmtree(staging)


def find_access_db(extracted_dir: Path) -> Path:
    active_dir = resolve_active_extraction(extracted_dir)
    candidates = sorted([*active_dir.rglob("*.mdb"), *active_dir.rglob("*.accdb")])
    if len(candidates) != 1:
        raise SystemExit(f"Expected exactly one Access DB in {extracted_dir}, found {len(candidates)}")
    return candidates[0]


def maybe_access_row_count(
    db_path: Path,
    table_name: str,
    *,
    required: bool = False,
    binary_path: str | None = None,
) -> str:
    binary = binary_path or maybe_mdb_count_binary()
    if not binary:
        if required:
            raise RuntimeError("mdb-count is required in release-strict mode but was not found")
        return ""
    try:
        result = run_checked([binary, str(db_path), table_name])
        output = decode_tool_output(result.stdout).strip().splitlines()[0] if result.stdout else ""
        count = int(output)
        if count < 0:
            raise ValueError(f"negative row count {count}")
        return str(count)
    except Exception as exc:  # noqa: BLE001
        if required:
            raise RuntimeError(f"Unable to obtain Access row count for table {table_name}: {exc}") from exc
        return ""


def validate_row_count_match(table_name: str, *, csv_count: int, access_count: str, required: bool) -> bool | None:
    if str(access_count).strip() == "":
        if required:
            raise RuntimeError(f"Missing Access row count for table {table_name}")
        return None
    try:
        access_count_int = int(str(access_count))
    except ValueError as exc:
        raise RuntimeError(f"Invalid Access row count for table {table_name}: {access_count!r}") from exc
    if access_count_int != int(csv_count):
        raise RuntimeError(
            f"Access/CSV row-count mismatch for table {table_name}: Access={access_count_int}, CSV={csv_count}"
        )
    return True


def export_table(
    db_path: Path,
    table_name: str,
    destination: Path,
    force: bool,
    *,
    tool_binding: dict[str, str] | None = None,
    source_db_sha256: str | None = None,
    source_db_size_bytes: str | int | None = None,
    contract_id: str | None = None,
) -> str:
    binding = dict(tool_binding or executable_identity("mdb-export"))
    source_stat = db_path.stat()
    stat_identity = (
        source_stat.st_size,
        source_stat.st_mtime_ns,
        source_stat.st_ctime_ns,
        source_stat.st_ino,
    )
    if source_db_sha256:
        db_size = str(source_stat.st_size)
        if source_db_size_bytes is not None and int(source_db_size_bytes) != source_stat.st_size:
            raise ValueError(
                f"Access DB changed before export: expected size {source_db_size_bytes}, "
                f"observed {source_stat.st_size}"
            )
        source_sha = source_db_sha256
    else:
        db_size, source_sha = validate_file_integrity(db_path)
    receipt_path = destination.with_suffix(destination.suffix + ".export-manifest.json")
    expected_binding: dict[str, object] = {
        "manifest_version": 1,
        "stage_version": STAGE_VERSION,
        "contract_id": contract_id or load_contract_id(DEFAULT_PANEL_CONTRACT),
        "source_db_size_bytes": db_size,
        "source_db_sha256": source_sha,
        "table_name": table_name,
        "exporter": binding,
        "arguments": [str(db_path), table_name],
    }
    receipt = read_json_object(receipt_path)
    if destination.is_file() and not force and receipt is not None:
        reusable = all(receipt.get(key) == value for key, value in expected_binding.items())
        if reusable:
            try:
                validate_file_integrity(
                    destination,
                    expected_size=str(receipt.get("output_size_bytes", "")),
                    expected_sha256=str(receipt.get("output_sha256", "")),
                    require_expectations=True,
                )
                return "skipped_verified"
            except (FileNotFoundError, ValueError):
                pass

    destination.parent.mkdir(parents=True, exist_ok=True)
    raw_fd, raw_temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.staging-", suffix=".raw", dir=destination.parent
    )
    os.close(raw_fd)
    raw_temporary = Path(raw_temporary_name)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.staging-", suffix=".csv", dir=destination.parent
    )
    os.close(fd)
    temporary = Path(temporary_name)
    try:
        with raw_temporary.open("wb") as export_stdout:
            subprocess.run(
                [str(binding["path"]), str(db_path), table_name],
                check=True,
                stdout=export_stdout,
                stderr=subprocess.PIPE,
                text=False,
            )
            export_stdout.flush()
            os.fsync(export_stdout.fileno())
        try:
            with raw_temporary.open(
                "r", encoding="utf-8", errors="strict", newline=None
            ) as export_source, temporary.open(
                "w", encoding="utf-8", errors="strict", newline=""
            ) as normalized_output:
                while chunk := export_source.read(EXPORT_NORMALIZATION_CHUNK_SIZE):
                    normalized_output.write(chunk)
                normalized_output.flush()
                os.fsync(normalized_output.fileno())
        except UnicodeDecodeError as exc:
            raise RuntimeError(f"mdb-export output is not valid UTF-8 for table {table_name}: {exc}") from exc
        output_size, output_sha = validate_file_integrity(temporary)
        header, row_count = csv_header_and_rowcount(temporary)
        if not header:
            raise RuntimeError(f"mdb-export produced a CSV without a header for table {table_name}")
        final_stat = db_path.stat()
        final_stat_identity = (
            final_stat.st_size,
            final_stat.st_mtime_ns,
            final_stat.st_ctime_ns,
            final_stat.st_ino,
        )
        if final_stat_identity != stat_identity:
            raise ValueError(f"Access DB changed during export of table {table_name}")
        os.replace(temporary, destination)
        atomic_write_json(
            receipt_path,
            {
                **expected_binding,
                "output_size_bytes": output_size,
                "output_sha256": output_sha,
                "output_column_count": len(header),
                "output_row_count": row_count,
            },
        )
        return "exported"
    finally:
        raw_temporary.unlink(missing_ok=True)
        temporary.unlink(missing_ok=True)


def main() -> None:
    args = parse_args()
    contract_path = Path(args.contract).expanduser().resolve()
    source_lock_path = Path(args.source_lock).expanduser().resolve()
    contract_id = load_contract_id(contract_path)
    require_mdb_tools()
    count_binary = maybe_mdb_count_binary()
    if args.release_strict and count_binary is None:
        raise SystemExit("mdb-count is required in release-strict mode but was not found")
    exporter_binding = executable_identity("mdb-export")
    schema_binding = executable_identity("mdb-schema")
    tables_binding = executable_identity("mdb-tables")
    count_binding = executable_identity("mdb-count") if count_binary else None
    layout = ensure_data_layout(args.root)
    years = parse_years(args.years)
    extract_qc_dir = layout.checks / "extract_qc"
    extract_qc_dir.mkdir(parents=True, exist_ok=True)

    global_inventory_rows: list[dict] = []
    global_failures: list[dict] = []

    for year in years:
        year_dir = layout.raw_access / str(year)
        manifest_path = year_dir / "manifest.csv"
        if not manifest_path.exists():
            raise SystemExit(f"Missing manifest for year {year}: {manifest_path}")
        manifest = pd.read_csv(manifest_path, dtype=str).fillna("")
        if manifest.empty:
            raise SystemExit(f"Empty manifest for year {year}: {manifest_path}")
        manifest_row = manifest.iloc[0].to_dict()
        zip_path = year_dir / "downloads" / manifest_row["access_filename"]
        if not zip_path.exists():
            raise SystemExit(f"Missing downloaded Access archive for year {year}: {zip_path}")
        if args.release_strict and str(manifest_row.get("source_lock_status", "")) != "verified":
            raise SystemExit(
                f"Release-strict extraction requires a verified Stage 01 source lock for year {year}: {manifest_path}"
            )
        if args.release_strict:
            try:
                verify_stage01_source_receipt(
                    manifest_row,
                    year=year,
                    source_lock_path=source_lock_path,
                    contract_path=contract_path,
                )
            except (FileNotFoundError, ValueError) as exc:
                raise SystemExit(f"Stage 01 source receipt is stale or invalid for year {year}: {exc}") from exc
        if args.release_strict and "failed" in str(manifest_row.get("download_status", "")).lower():
            raise SystemExit(f"Stage 01 recorded a download failure for release year {year}: {manifest_path}")
        expected_zip_size = str(manifest_row.get("access_expected_filesize_bytes", "")).strip()
        expected_zip_sha = str(manifest_row.get("access_expected_sha256", "")).strip()
        if not expected_zip_size and not args.release_strict:
            expected_zip_size = str(manifest_row.get("access_zip_filesize_bytes", "")).strip()
        if not expected_zip_sha and not args.release_strict:
            expected_zip_sha = str(manifest_row.get("access_zip_sha256", "")).strip()
        try:
            validate_file_integrity(
                zip_path,
                expected_size=expected_zip_size,
                expected_sha256=expected_zip_sha,
                require_expectations=args.release_strict,
            )
        except (FileNotFoundError, ValueError) as exc:
            raise SystemExit(f"Downloaded Access archive failed integrity validation for year {year}: {exc}") from exc
        if args.release_strict:
            doc_filename = str(manifest_row.get("doc_filename", "")).strip()
            doc_path = year_dir / "downloads" / doc_filename
            try:
                validate_file_integrity(
                    doc_path,
                    expected_size=str(manifest_row.get("doc_expected_filesize_bytes", "")).strip(),
                    expected_sha256=str(manifest_row.get("doc_expected_sha256", "")).strip(),
                    require_expectations=True,
                )
            except (FileNotFoundError, ValueError) as exc:
                raise SystemExit(
                    f"Downloaded documentation failed integrity validation for year {year}: {exc}"
                ) from exc

        extracted_dir = year_dir / "extracted_db"
        tables_dir = year_dir / "tables_csv"
        metadata_dir = year_dir / "metadata"
        qc_dir = year_dir / "qc"
        metadata_dir.mkdir(parents=True, exist_ok=True)
        qc_dir.mkdir(parents=True, exist_ok=True)

        extraction_status = unzip_archive(
            zip_path,
            extracted_dir,
            args.force,
            cache_manifest_path=qc_dir / "extraction_cache_manifest.json",
        )
        db_path = find_access_db(extracted_dir)
        db_size, db_sha = compute_file_metadata(db_path)
        schema_sql = decode_tool_output(
            run_checked([schema_binding["path"], str(db_path), "access"]).stdout
        )
        atomic_write_text(metadata_dir / "table_schema.sql", schema_sql)
        tables_output = decode_tool_output(
            run_checked([tables_binding["path"], "-1", str(db_path)]).stdout
        )
        table_names = [line.strip() for line in tables_output.splitlines() if line.strip()]
        if not table_names:
            raise SystemExit(f"No tables found in Access DB for year {year}: {db_path}")
        destination_names: dict[str, str] = {}
        for table_name in table_names:
            destination_name = f"{safe_table_filename(table_name)}.csv"
            collision_key = destination_name.casefold()
            previous = destination_names.get(collision_key)
            if previous is not None and previous != table_name:
                raise SystemExit(
                    f"Access table names collide at the CSV destination for year {year}: "
                    f"{previous!r} and {table_name!r} -> {destination_name!r}"
                )
            destination_names[collision_key] = table_name

        inventory_rows: list[dict] = []
        column_rows: list[dict] = []
        row_count_rows: list[dict] = []
        failure_rows: list[dict] = []
        for table_name in table_names:
            csv_path = tables_dir / f"{safe_table_filename(table_name)}.csv"
            status = "failed"
            try:
                status = export_table(
                    db_path,
                    table_name,
                    csv_path,
                    args.force,
                    tool_binding=exporter_binding,
                    source_db_sha256=db_sha,
                    source_db_size_bytes=db_size,
                    contract_id=contract_id,
                )
                header, row_count = csv_header_and_rowcount(csv_path)
                access_row_count = maybe_access_row_count(
                    db_path,
                    table_name,
                    required=args.release_strict,
                    binary_path=count_binary,
                )
                row_count_match = validate_row_count_match(
                    table_name,
                    csv_count=row_count,
                    access_count=access_row_count,
                    required=args.release_strict,
                )
                role = classify_table_role(table_name, header)
                capabilities = table_role_capabilities(table_name, header)
                has_unitid = any(normalize_text_key(col) == "unitid" for col in header)
                _, csv_sha = compute_file_metadata(csv_path)
                inventory_rows.append(
                    {
                        "year": year,
                        "access_db_file": db_path.name,
                        "table_name": table_name,
                        "normalized_table_name": canonical_source_file(table_name),
                        "table_role": role,
                        "csv_path": str(csv_path.relative_to(year_dir)),
                        "has_unitid": has_unitid,
                        "row_count_csv": row_count,
                        "column_count": len(header),
                        "csv_sha256": csv_sha,
                        "export_status": status,
                        "has_varnumber": bool(capabilities["has_varnumber"]),
                        "has_varname": bool(capabilities["has_varname"]),
                        "has_vartitle": bool(capabilities["has_vartitle"]),
                        "has_longdesc": bool(capabilities["has_longdesc"]),
                        "has_codevalue": bool(capabilities["has_code"]),
                        "has_valuelabel": bool(capabilities["has_label"]),
                        "has_imputation_markers": bool(capabilities["has_imputation"]),
                    }
                )
                row_count_rows.append(
                    {
                        "year": year,
                        "table_name": table_name,
                        "row_count_csv": row_count,
                        "row_count_access": access_row_count,
                        "row_count_match": row_count_match if row_count_match is not None else "",
                    }
                )
                for idx, col_name in enumerate(header, start=1):
                    column_rows.append(
                        {
                            "year": year,
                            "table_name": table_name,
                            "normalized_table_name": canonical_source_file(table_name),
                            "ordinal_position": idx,
                            "column_name": col_name,
                            "column_name_normalized": normalize_table_name(col_name),
                        }
                    )
                global_inventory_rows.append(inventory_rows[-1])
            except Exception as exc:  # noqa: BLE001
                failure_rows.append({"year": year, "table_name": table_name, "error": str(exc)})
                global_failures.append(failure_rows[-1])

        try:
            validate_file_integrity(
                db_path,
                expected_size=db_size,
                expected_sha256=db_sha,
                require_expectations=True,
            )
        except ValueError as exc:
            raise SystemExit(f"Access DB changed during table export for year {year}: {exc}") from exc

        inventory_fields = [
            "year",
            "access_db_file",
            "table_name",
            "normalized_table_name",
            "table_role",
            "csv_path",
            "has_unitid",
            "row_count_csv",
            "column_count",
            "csv_sha256",
            "export_status",
            "has_varnumber",
            "has_varname",
            "has_vartitle",
            "has_longdesc",
            "has_codevalue",
            "has_valuelabel",
            "has_imputation_markers",
        ]
        write_csv(metadata_dir / "table_inventory.csv", inventory_rows, inventory_fields)
        write_csv(
            metadata_dir / "table_columns.csv",
            column_rows,
            [
                "year",
                "table_name",
                "normalized_table_name",
                "ordinal_position",
                "column_name",
                "column_name_normalized",
            ],
        )
        write_csv(
            metadata_dir / "row_count_report.csv",
            row_count_rows,
            ["year", "table_name", "row_count_csv", "row_count_access", "row_count_match"],
        )
        write_csv(qc_dir / "tables_with_unitid.csv", [row for row in inventory_rows if row["has_unitid"]], inventory_fields)
        write_csv(qc_dir / "zero_row_tables.csv", [row for row in inventory_rows if int(row["row_count_csv"]) == 0], inventory_fields)
        ambiguous_rows: list[dict] = []
        for role in ("metadata_varlist", "metadata_description", "metadata_codes", "metadata_imputation"):
            candidates = [row for row in inventory_rows if row["table_role"] == role]
            if len(candidates) > 1:
                ambiguous_rows.extend(candidates)
        write_csv(qc_dir / "ambiguous_metadata_tables.csv", ambiguous_rows, inventory_fields)
        write_csv(qc_dir / "extract_failures.csv", failure_rows, ["year", "table_name", "error"])

        if args.fail_on_missing_metadata:
            required_roles = {"metadata_varlist", "metadata_description", "metadata_codes"}
            found_roles = set()
            for row in inventory_rows:
                capabilities = {
                    "has_varnumber": str(row.get("has_varnumber", "")).lower() in {"true", "1"},
                    "has_varname": str(row.get("has_varname", "")).lower() in {"true", "1"},
                    "has_vartitle": str(row.get("has_vartitle", "")).lower() in {"true", "1"},
                    "has_longdesc": str(row.get("has_longdesc", "")).lower() in {"true", "1"},
                    "has_code": str(row.get("has_codevalue", "")).lower() in {"true", "1"},
                    "has_label": str(row.get("has_valuelabel", "")).lower() in {"true", "1"},
                    "has_imputation": str(row.get("has_imputation_markers", "")).lower() in {"true", "1"},
                }
                for role in required_roles:
                    if can_serve_metadata_role_from_capabilities(role, capabilities):
                        found_roles.add(role)
            missing_roles = sorted(required_roles - found_roles)
            if missing_roles:
                raise SystemExit(f"Missing required metadata table roles for year {year}: {missing_roles}")

        extraction_receipt = manifest.copy()
        extraction_receipt["extracted_access_db_file"] = db_path.name
        extraction_receipt["extracted_access_db_sha256"] = db_sha
        extraction_receipt["extraction_status"] = extraction_status
        extraction_receipt["extraction_release_strict"] = bool(args.release_strict)
        extraction_receipt["mdb_export_path"] = exporter_binding["path"]
        extraction_receipt["mdb_export_sha256"] = exporter_binding["sha256"]
        extraction_receipt["mdb_export_version"] = exporter_binding["version"]
        extraction_receipt["mdb_schema_path"] = schema_binding["path"]
        extraction_receipt["mdb_schema_sha256"] = schema_binding["sha256"]
        extraction_receipt["mdb_schema_version"] = schema_binding["version"]
        extraction_receipt["mdb_tables_path"] = tables_binding["path"]
        extraction_receipt["mdb_tables_sha256"] = tables_binding["sha256"]
        extraction_receipt["mdb_tables_version"] = tables_binding["version"]
        extraction_receipt["mdb_count_path"] = str((count_binding or {}).get("path", ""))
        extraction_receipt["mdb_count_sha256"] = str((count_binding or {}).get("sha256", ""))
        extraction_receipt["mdb_count_version"] = str((count_binding or {}).get("version", ""))
        atomic_write_text(metadata_dir / "extraction_receipt.csv", extraction_receipt.to_csv(index=False))
        print(
            f"[year {year}] extracted Access DB: {db_path.name} "
            f"status={extraction_status} tables={len(inventory_rows)}"
        )

    write_csv(
        extract_qc_dir / "table_inventory_all_years.csv",
        global_inventory_rows,
        [
            "year",
            "access_db_file",
            "table_name",
            "normalized_table_name",
            "table_role",
            "csv_path",
            "has_unitid",
            "row_count_csv",
            "column_count",
            "csv_sha256",
            "export_status",
            "has_varnumber",
            "has_varname",
            "has_vartitle",
            "has_longdesc",
            "has_codevalue",
            "has_valuelabel",
            "has_imputation_markers",
        ],
    )
    write_csv(extract_qc_dir / "extract_failures.csv", global_failures, ["year", "table_name", "error"])
    if global_failures:
        raise SystemExit("Access extraction failures encountered; inspect extract_failures.csv")


if __name__ == "__main__":
    main()
