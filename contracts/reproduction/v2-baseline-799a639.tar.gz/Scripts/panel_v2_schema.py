"""Canonical schemas and scientific keys for IPEDSDB panel contract v2."""
from __future__ import annotations

import pyarrow as pa


PANEL_CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"

LONG_PANEL_COLUMNS = [
    "year",
    "UNITID",
    "contract_id",
    "variable_id",
    "source_varnumber",
    "varname",
    "varnumber",
    "value",
    "raw_value",
    "value_status",
    "varTitle",
    "longDescription",
    "DataType",
    "format",
    "Fieldwidth",
    "imputationvar",
    "imputation_value",
    "source_file",
    "access_table_name",
    "lane",
    "source_csv_sha256",
    "source_row_ordinal",
    "source_row_hash",
    "source_row_id",
    "source_duplicate_count",
    "source_row_ids_json",
    "source_row_ordinals_json",
    "dimension_json",
    "dimension_key",
]

SOURCE_ROW_COLUMNS = [
    "year",
    "UNITID",
    "contract_id",
    "source_unitid_token",
    "source_file",
    "access_table_name",
    "lane",
    "source_csv_sha256",
    "source_row_ordinal",
    "source_row_hash",
    "source_row_id",
    "source_duplicate_count",
    "source_row_ids_json",
    "source_row_ordinals_json",
    "dimension_json",
    "dimension_key",
    "source_row_json",
]

INTEGER_FIELDS = {"year", "UNITID", "source_row_ordinal", "source_duplicate_count"}


def schema_for(columns: list[str]) -> pa.Schema:
    return pa.schema(
        [
            pa.field(name, pa.int64() if name in INTEGER_FIELDS else pa.string())
            for name in columns
        ]
    )


LONG_PANEL_SCHEMA = schema_for(LONG_PANEL_COLUMNS)
SOURCE_ROW_SCHEMA = schema_for(SOURCE_ROW_COLUMNS)

SCALAR_CELL_KEY = ["year", "UNITID", "variable_id", "source_file"]
DIMENSIONED_CELL_KEY = [
    "year",
    "UNITID",
    "source_file",
    "access_table_name",
    "dimension_key",
    "variable_id",
]
SOURCE_ROW_KEY = ["contract_id", "year", "source_file", "access_table_name", "source_row_id"]

ALLOWED_VALUE_STATUSES = {"reported", "missing"}
ALLOWED_SOURCE_LANES = {"scalar", "dimensioned", "metadata", "excluded"}
