#!/usr/bin/env python3
"""
Shared Access-pipeline helpers used across download, extraction, dictionary,
and harmonization stages.

Reads:
- environment configuration such as `IPEDSDB_ROOT`
- table names, column names, and file paths passed in by stage scripts

Writes:
- no durable project artifacts directly

Focus:
- external data-root layout
- naming normalization
- metadata-table classification
- small file and subprocess helpers used by multiple stages
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_IPEDSDB_ROOT = REPO_ROOT.parent / "IPEDSDB_ROOT"
DEFAULT_LEGACY_PANELING_ROOT = REPO_ROOT.parent / "IPEDS_Paneling"

CANONICAL_SOURCE_FILES = {
    "HD",
    "IC",
    "IC_AY",
    "IC_PY",
    "IC_CAMPUSES",
    "IC_PCCAMPUSES",
    "ADM",
    "AL",
    "C_A",
    "C_B",
    "C_C",
    "CDEP",
    "COST",
    "EAP",
    "EFA",
    "EFA_DIST",
    "EFB",
    "EFC",
    "EFCP",
    "EFFY",
    "EFFY_DIST",
    "EFIA",
    "EFIB",
    "EFIC",
    "EFID",
    "F_F",
    "F_FA",
    "F_FA_F",
    "F_FA_G",
    "GR",
    "GR200",
    "GR_PELL_SSL",
    "OM",
    "SAL_A",
    "SAL_A_LT",
    "SAL_B",
    "SAL_FACULTY",
    "SAL_IS",
    "S_ABD",
    "S_CN",
    "S_F",
    "S_G",
    "S_IS",
    "S_NH",
    "S_OC",
    "S_SIS",
    "SFA",
    "SFA_P",
    "SFAV",
    "DRVADM",
    "DRVAL",
    "DRVC",
    "DRVEF",
    "DRVEF12",
    "DRVF",
    "DRVGR",
    "DRVHR",
    "DRVIC",
    "DRVOM",
    "KEYS",
}

NONCANONICAL_AUXILIARY_SOURCE_FILES = {
    "EF",
    "EFFY_HS",
    "FLAGS",
    "GR_L",
    "GR_GENDER",
    "HD_PCUNITIDS",
    "ICMISSION",
    "SAL_NIS",
}

NONCANONICAL_DERIVED_OR_CUSTOM_SOURCE_FILES = {
    "CSTEM",
    "CUSTOMCG",
    "CUSTOMCGIDS",
    "DFR",
    "EFD",
    "EFF",
    "EFDS",
}

NONCANONICAL_ACTIONABLE_GAP_SOURCE_FILES = {
}

NULL_LIKE_TOKENS = {"", "nan", "none", "<na>", "na", "nat"}
VAR_NUMBER_CANDIDATES = {
    "varnumber",
    "var_num",
    "number",
    "variable_number",
    "var no",
    "varno",
}
VAR_NAME_CANDIDATES = {
    "varname",
    "var_name",
    "name",
    "variable",
    "variable_name",
}
VAR_TITLE_CANDIDATES = {
    "vartitle",
    "var_title",
    "var title",
    "title",
    "label",
    "variable_label",
    "variable title",
}
LONG_DESC_CANDIDATES = {
    "longdescription",
    "long description",
    "description",
    "description_text",
    "definition",
}
CODE_VALUE_CANDIDATES = {
    "codevalue",
    "code value",
    "code",
    "value",
}
VALUE_LABEL_CANDIDATES = {
    "valuelabel",
    "value label",
    "label",
    "description",
}
DATA_TABLE_CANDIDATES = {
    "table",
    "tablename",
    "table_name",
    "data_table",
    "data table",
    "source_table",
    "source table",
    "file",
    "filename",
    "file_name",
}
IMPUTATION_CANDIDATES = {
    "imputationvar",
    "imputation var",
    "imputation_var",
    "impvar",
}


@dataclass(frozen=True)
class DataRootLayout:
    root: Path
    raw_access: Path
    dictionary: Path
    cross_sections: Path
    panels: Path
    checks: Path
    build: Path


def repo_root() -> Path:
    return REPO_ROOT


def data_root() -> Path:
    return Path(os.environ.get("IPEDSDB_ROOT", str(DEFAULT_IPEDSDB_ROOT))).expanduser()


def data_layout(root: str | Path | None = None) -> DataRootLayout:
    base = Path(root).expanduser() if root is not None else data_root()
    return DataRootLayout(
        root=base,
        raw_access=base / "Raw_Access_Databases",
        dictionary=base / "Dictionary",
        cross_sections=base / "Cross_sections",
        panels=base / "Panels",
        checks=base / "Checks",
        build=base / "build",
    )


def ensure_data_layout(root: str | Path | None = None) -> DataRootLayout:
    layout = data_layout(root)
    for path in (
        layout.root,
        layout.raw_access,
        layout.dictionary,
        layout.cross_sections,
        layout.panels,
        layout.checks,
        layout.build,
    ):
        path.mkdir(parents=True, exist_ok=True)
    return layout


def parse_years(spec: str) -> list[int]:
    if ":" in spec:
        start, end = spec.split(":", 1)
        return list(range(int(start), int(end) + 1))
    return [int(part.strip()) for part in spec.split(",") if part.strip()]


def academic_year_to_start_year(label: str) -> int:
    match = re.fullmatch(r"\s*(\d{4})\s*[-/]\s*(\d{2,4})\s*", str(label))
    if not match:
        raise ValueError(f"Unsupported academic year label: {label}")
    return int(match.group(1))


def start_year_to_academic_label(year: int) -> str:
    return f"{int(year)}-{(int(year) + 1) % 100:02d}"


def normalize_token(value: object) -> str:
    txt = str(value or "").strip().upper()
    txt = re.sub(r"[^A-Z0-9]+", "_", txt)
    txt = re.sub(r"_+", "_", txt).strip("_")
    return txt


def normalize_text_key(value: object) -> str:
    txt = str(value or "").strip().lower()
    txt = re.sub(r"[^a-z0-9]+", "_", txt)
    txt = re.sub(r"_+", "_", txt).strip("_")
    return txt


def normalize_varnumber(val: object) -> str:
    if val is None:
        return ""
    txt = re.sub(r"\s+", "", str(val))
    if txt.lower() in NULL_LIKE_TOKENS:
        return ""
    if txt.isdigit():
        return txt.zfill(8)
    return txt


def canonicalize_nces_source_variable_id(value: object) -> str:
    """Return the canonical runtime form of a strict NCES variable identity.

    Reviewed evidence can retain an NCES ``VarNumber`` exactly as published
    (for example ``40131``), while runtime dictionary identities pad numeric
    source numbers to eight characters.  Only that representational
    difference is normalized here; malformed identities and substantive
    source/name changes remain errors.
    """
    text = "" if value is None else str(value).strip()
    match = re.fullmatch(
        r"nces:([A-Za-z][A-Za-z0-9_]*):([0-9]+):([A-Za-z][A-Za-z0-9_]*)",
        text,
    )
    if match is None:
        raise ValueError(f"malformed NCES variable_id: {text!r}")
    source_file, source_varnumber, varname = match.groups()
    return (
        f"nces:{source_file.upper()}:"
        f"{normalize_varnumber(source_varnumber)}:{varname.upper()}"
    )


def clean_source_label(label: str) -> str:
    txt = str(label or "")
    txt = re.sub(r"(?i)\bfile documentation for (the )?\b", "", txt)
    txt = re.sub(r"\b20\d{2}\s*[-/]\s*\d{2}\b", "", txt)
    txt = re.sub(r"\s+", " ", txt).strip(" ,")
    return txt


def normalize_table_name(name: str) -> str:
    return normalize_token(Path(str(name)).stem)


def canonical_source_file(name: str) -> str:
    norm = normalize_table_name(name)
    if not norm:
        return ""
    if "GR200" in norm:
        return "GR200"
    stripped = re.sub(r"\d+", "", norm)
    stripped = re.sub(r"_+", "_", stripped).strip("_")
    if not stripped:
        stripped = norm
    compact = stripped.replace("_", "")
    alias_map = {
        "HD": "HD",
        "IC": "IC",
        "ICAY": "IC_AY",
        "ICPY": "IC_PY",
        "ICCAMPUSES": "IC_CAMPUSES",
        "ICPCCAMPUSES": "IC_PCCAMPUSES",
        "ADM": "ADM",
        "AL": "AL",
        "CA": "C_A",
        "CB": "C_B",
        "CC": "C_C",
        "CDEP": "CDEP",
        "COST": "COST",
        "EAP": "EAP",
        "EFA": "EFA",
        "EFADIST": "EFA_DIST",
        "EFB": "EFB",
        "EFC": "EFC",
        "EFCP": "EFCP",
        "EFFY": "EFFY",
        "EFFYDIST": "EFFY_DIST",
        "EFIA": "EFIA",
        "EFIB": "EFIB",
        "EFIC": "EFIC",
        "EFID": "EFID",
        "FF": "F_F",
        "FFA": "F_FA",
        "FFAF": "F_FA_F",
        "FFAG": "F_FA_G",
        "GR": "GR",
        "GRPELLSSL": "GR_PELL_SSL",
        "OM": "OM",
        "SALA": "SAL_A",
        "SALALT": "SAL_A_LT",
        "SALB": "SAL_B",
        "SALFACULTY": "SAL_FACULTY",
        "SALIS": "SAL_IS",
        "SABD": "S_ABD",
        "SCN": "S_CN",
        "SF": "S_F",
        "SG": "S_G",
        "SIS": "S_IS",
        "SNH": "S_NH",
        "SOC": "S_OC",
        "SSIS": "S_SIS",
        "SFA": "SFA",
        "SFAV": "SFAV",
        "DRVADM": "DRVADM",
        "DRVAL": "DRVAL",
        "DRVC": "DRVC",
        "DRVEF": "DRVEF",
        "DRVEF12": "DRVEF12",
        "DRVF": "DRVF",
        "DRVGR": "DRVGR",
        "DRVHR": "DRVHR",
        "DRVIC": "DRVIC",
        "DRVOM": "DRVOM",
    }
    return alias_map.get(compact, stripped)


def source_file_qaqc_category(source_file: str) -> str:
    source_norm = normalize_token(source_file)
    if not source_norm:
        return "needs_review"
    if source_norm in CANONICAL_SOURCE_FILES:
        return "canonical"
    if source_norm in NONCANONICAL_AUXILIARY_SOURCE_FILES:
        return "auxiliary_expected"
    if source_norm in NONCANONICAL_DERIVED_OR_CUSTOM_SOURCE_FILES or source_norm.startswith("CUSTOM"):
        return "derived_or_custom"
    if source_norm in NONCANONICAL_ACTIONABLE_GAP_SOURCE_FILES:
        return "actionable_canonical_gap"
    return "needs_review"


def compute_file_metadata(path: str | Path) -> tuple[str, str]:
    fp = Path(path)
    if not fp.exists():
        return "", ""
    sha256 = hashlib.sha256()
    size = 0
    with fp.open("rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            size += len(chunk)
            sha256.update(chunk)
    return str(size), sha256.hexdigest()


def validate_file_integrity(
    path: str | Path,
    *,
    expected_size: str | int | None = None,
    expected_sha256: str | None = None,
    require_expectations: bool = False,
) -> tuple[str, str]:
    """Return observed metadata after enforcing any supplied integrity contract.

    ``require_expectations`` is intended for release-mode boundaries.  It
    prevents an observed checksum (which only describes bytes after the fact)
    from being mistaken for an independently approved source checksum.
    """
    fp = Path(path)
    if not fp.is_file():
        raise FileNotFoundError(f"Integrity target is not a file: {fp}")

    expected_size_text = "" if expected_size is None else str(expected_size).strip()
    expected_sha_text = str(expected_sha256 or "").strip().lower()
    if require_expectations and (not expected_size_text or not expected_sha_text):
        raise ValueError(f"Complete SHA-256 and size expectations are required for {fp}")
    if expected_sha_text and not re.fullmatch(r"[0-9a-f]{64}", expected_sha_text):
        raise ValueError(f"Invalid expected SHA-256 for {fp}: {expected_sha_text!r}")
    if expected_size_text:
        try:
            expected_size_int = int(expected_size_text)
        except ValueError as exc:
            raise ValueError(f"Invalid expected size for {fp}: {expected_size_text!r}") from exc
        if expected_size_int < 0:
            raise ValueError(f"Invalid expected size for {fp}: {expected_size_int}")
    else:
        expected_size_int = None

    observed_size, observed_sha = compute_file_metadata(fp)
    if expected_size_int is not None and int(observed_size) != expected_size_int:
        raise ValueError(
            f"File-size mismatch for {fp}: expected {expected_size_int}, observed {observed_size}"
        )
    if expected_sha_text and observed_sha != expected_sha_text:
        raise ValueError(
            f"SHA-256 mismatch for {fp}: expected {expected_sha_text}, observed {observed_sha}"
        )
    return observed_size, observed_sha


def atomic_write_bytes(path: str | Path, payload: bytes) -> None:
    """Durably replace a file without exposing a partial final pathname."""
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".part", dir=destination.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(payload)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def atomic_write_text(path: str | Path, text: str, *, encoding: str = "utf-8") -> None:
    atomic_write_bytes(path, text.encode(encoding))


def atomic_write_json(path: str | Path, payload: dict[str, object]) -> None:
    atomic_write_text(path, json.dumps(payload, indent=2, sort_keys=True) + "\n")


def read_json_object(path: str | Path) -> dict[str, object] | None:
    fp = Path(path)
    if not fp.is_file():
        return None
    try:
        value = json.loads(fp.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


def executable_identity(name: str) -> dict[str, str]:
    """Bind cache receipts to the exact executable bytes and version output."""
    resolved = shutil.which(name)
    if resolved is None:
        raise FileNotFoundError(f"Required executable not found: {name}")
    size, sha256 = validate_file_integrity(resolved)
    version = ""
    try:
        result = run_checked([resolved, "--version"])
        raw = result.stdout or result.stderr or b""
        version = decode_tool_output(raw).strip().splitlines()[0] if raw else ""
    except (OSError, subprocess.SubprocessError):
        # The executable hash remains a complete identity when a particular
        # mdb-tools build does not implement --version.
        version = ""
    return {"path": str(Path(resolved).resolve()), "size_bytes": size, "sha256": sha256, "version": version}


def safe_table_filename(table_name: str) -> str:
    txt = str(table_name).replace("/", "_").replace("\x00", "")
    txt = txt.replace(":", "_")
    return txt


def csv_header_and_rowcount(path: str | Path) -> tuple[list[str], int]:
    fp = Path(path)
    if not fp.exists():
        return [], 0
    with fp.open("r", newline="", encoding="utf-8", errors="strict") as fh:
        reader = csv.reader(fh, strict=True)
        header = next(reader, [])
        rows = sum(1 for _ in reader)
    return header, rows


def pick_column(columns: Iterable[str], candidates: set[str]) -> str | None:
    lookup = {normalize_text_key(col): col for col in columns}
    for candidate in candidates:
        key = normalize_text_key(candidate)
        if key in lookup:
            return lookup[key]
    return None


def has_any_column(columns: Iterable[str], candidates: set[str]) -> bool:
    return pick_column(columns, candidates) is not None


def table_role_capabilities(table_name: str, columns: Iterable[str]) -> dict[str, bool | str]:
    col_list = list(columns)
    norm_cols = {normalize_text_key(col) for col in col_list}
    name_key = normalize_text_key(table_name)
    return {
        "table_name_key": name_key,
        "has_unitid": "unitid" in norm_cols,
        "has_varnumber": has_any_column(col_list, VAR_NUMBER_CANDIDATES),
        "has_varname": has_any_column(col_list, VAR_NAME_CANDIDATES),
        "has_vartitle": has_any_column(col_list, VAR_TITLE_CANDIDATES),
        "has_longdesc": has_any_column(col_list, LONG_DESC_CANDIDATES),
        "has_code": has_any_column(col_list, CODE_VALUE_CANDIDATES),
        "has_label": has_any_column(col_list, VALUE_LABEL_CANDIDATES),
        "has_imputation": "imput" in name_key or any("imput" in col for col in norm_cols),
    }


def can_serve_metadata_role(role: str, table_name: str, columns: Iterable[str]) -> bool:
    caps = table_role_capabilities(table_name, columns)
    return can_serve_metadata_role_from_capabilities(role, caps)


def can_serve_metadata_role_from_capabilities(role: str, capabilities: dict[str, object]) -> bool:
    has_varnumber = bool(capabilities.get("has_varnumber"))
    has_varname = bool(capabilities.get("has_varname"))
    has_vartitle = bool(capabilities.get("has_vartitle"))
    has_longdesc = bool(capabilities.get("has_longdesc"))
    has_code = bool(capabilities.get("has_code"))
    has_label = bool(capabilities.get("has_label"))
    has_imputation = bool(capabilities.get("has_imputation"))
    if role == "metadata_varlist":
        return has_varnumber and has_varname and has_vartitle
    if role == "metadata_description":
        return has_longdesc and (has_varname or has_varnumber)
    if role == "metadata_codes":
        return has_code and has_label
    if role == "metadata_imputation":
        return has_code and has_label and has_imputation
    return False


def classify_table_role(table_name: str, columns: Iterable[str]) -> str:
    caps = table_role_capabilities(table_name, columns)
    name_key = str(caps["table_name_key"])
    has_unitid = bool(caps["has_unitid"])
    has_varnumber = bool(caps["has_varnumber"])
    has_varname = bool(caps["has_varname"])
    has_vartitle = bool(caps["has_vartitle"])
    has_longdesc = bool(caps["has_longdesc"])
    has_code = bool(caps["has_code"])
    has_label = bool(caps["has_label"])
    has_imputation = bool(caps["has_imputation"])

    if has_unitid and not (has_code or has_longdesc):
        return "data"
    if has_code and has_label and has_imputation:
        return "metadata_imputation"
    if has_code and has_label:
        return "metadata_codes"
    if has_varname and has_varnumber and has_vartitle:
        return "metadata_varlist"
    if has_longdesc and (has_varname or has_varnumber):
        return "metadata_description"
    if any(token in name_key for token in ("varlist", "layout", "variables")):
        return "metadata_varlist"
    if "descript" in name_key:
        return "metadata_description"
    if any(token in name_key for token in ("valueset", "frequenc", "code", "label")):
        return "metadata_codes"
    if has_varname or has_varnumber or has_longdesc or has_code:
        return "metadata_other"
    return "unknown"


def run_checked(cmd: list[str], *, cwd: str | Path | None = None, capture_output: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(
        cmd,
        cwd=str(cwd) if cwd is not None else None,
        check=True,
        capture_output=capture_output,
        text=False,
    )


def require_mdb_tools() -> None:
    missing = [name for name in ("mdb-tables", "mdb-schema", "mdb-export") if shutil.which(name) is None]
    if missing:
        raise SystemExit(
            "Missing required mdb-tools binaries: "
            + ", ".join(missing)
            + ". Install mdb-tools before running extraction."
        )


def maybe_mdb_count_binary() -> str | None:
    return shutil.which("mdb-count")


def decode_tool_output(raw: bytes) -> str:
    return raw.decode("utf-8", errors="replace").replace("\r\n", "\n").replace("\r", "\n")
