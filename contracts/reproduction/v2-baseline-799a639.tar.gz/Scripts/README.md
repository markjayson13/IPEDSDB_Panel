# Scripts guide

This folder contains the operational pipeline for building the Access-database IPEDS panel.

Start with these files:

- `00_run_all.py` coordinates the run
- `01` through `09` are the main ordered build stages
- `10_build_variable_browser.py` is optional and only helps with variable selection
- helper modules hold shared logic
- `QA_QC/` is where the build gets checked and summarized

If `README.md` describes the repo from the outside, this folder describes the build path.

## Start here

- `00_run_all.py`: main Python orchestrator
- `01_download_access_databases.py` to `09_build_panel_dictionary.py`: ordered pipeline stages
- `10_build_variable_browser.py`: optional static HTML browser for finding real panel columns and exporting `selectedvars.txt`
- `run_saved_query.py`: analyst query runner for saved SQL and result exports
- `QA_QC/`: validation, parity, monitoring, and repo guards
- `QA_QC/08_acceptance_audit.py`: top-level pass/fail audit over the generated live artifacts
- `QA_QC/09_panel_structure_qc.py`: literature-guided structure, linkage, timing, and comparability diagnostics
- `QA_QC/12_build_release_manifest.py`: citable artifact ledger with hashes and parquet shapes
- `QA_QC/14_build_public_release_bundle.py`: deposit directory builder for verified release files
- `QA_QC/15_compare_release_to_baseline.py`: baseline release audit for schema, dictionary, year-window, and PRCH drift
- `QA_QC/16_build_datapackage.py`: Data Package metadata builder
- `QA_QC/17_build_provenance.py`: provenance metadata builder
- `QA_QC/18_public_release_guard.py`: public-release file and ownership guard
- `QA_QC/19_docs_style_guard.py`: release-facing prose guard
- `QA_QC/20_environment_report.py`: runtime and dependency report
- `QA_QC/21_external_benchmark_reconciliation.py`: configured external benchmark reconciliation
- `QA_QC/22_build_entity_continuity_crosswalk.py`: `UNITID` continuity and join-risk outputs
- `QA_QC/24_verify_contract_review_evidence.py`: verify the complete
  receipt-bound external B03/B04 ZIP and recompute its core semantics
- `QA_QC/25_verify_container_runtime.py`: recheck immutable image, source,
  lockfile, and mount bindings before executing a container command
- `QA_QC/26_validate_synthetic_release_smoke.py`: validate the isolated
  development-only synthetic integration chain without production authority
- `QA_QC/release_gate.sh`: release gate wrapper
- `../tools/release_container.py`: host-side build/preflight/pipeline/gate
  wrapper for the governed release container

## File lookup

| Question | Best file to open first |
| --- | --- |
| How does the whole build get chained together? | `00_run_all.py` |
| Where do the NCES files come from? | `01_download_access_databases.py` |
| How are Access tables classified and exported? | `02_extract_access_db.py` |
| How do raw metadata tables become one dictionary? | `03_dictionary_ingest.py` |
| How do yearly tables become one long panel? | `04_harmonize.py` |
| How does the long panel become the wide analysis panel? | `06_build_wide_panel.py` |
| How are parent-child rows handled? | `07_clean_panel.py` and `../METHODS_PRCH_CLEANING.md` |
| How is the whole panel-construction method justified? | `../METHODS_PANEL_CONSTRUCTION.md` |
| Where are semantic acceptance checks implemented? | `QA_QC/08_acceptance_audit.py` |
| How do I package public-release files? | `../tools/release_container.py gate` |
| How do I compare a release with a prior one? | `QA_QC/15_compare_release_to_baseline.py` |

## Stage files

| File | Purpose |
| --- | --- |
| `00_run_all.py` | chain enabled stages into one run |
| `01_download_access_databases.py` | acquire only checksum-locked NCES Access releases in release mode |
| `02_extract_access_db.py` | unzip Access DBs and export tables |
| `03_dictionary_ingest.py` | build stitched dictionary artifacts |
| `04_harmonize.py` | classify table/column grain and preserve scalar, dimensioned, and physical source-row lineage |
| `05_stitch_long.py` | reconcile the v2 lanes separately without destructive dimension reduction |
| `06_build_wide_panel.py` | build the explicit-schema scalar-wide panel and semantic discrete outputs |
| `07_clean_panel.py` | apply exact reviewed PRCH rules and atomically publish panel plus evidence |
| `08_build_custom_panel.py` | make smaller user-selected extracts |
| `09_build_panel_dictionary.py` | build a dictionary for an actual panel output in `.csv` or formatted `.xlsx` |
| `10_build_variable_browser.py` | build a self-contained HTML browser for panel vars with semantic grouping, card/table browsing, detail inspection, presets, group/family bulk actions, saved-set lifecycle, import diffing, and export artifacts |
| `run_saved_query.py` | run saved SQL against the build DB and standard outputs |
| `prch_policy.py` | shared parent-child cleaning policy used by cleaning and QA |
| `stage_provenance.py` | pre-execution inventories, chained stage receipts, and authoritative run verification |

## Shared helpers

| File | Purpose |
| --- | --- |
| `access_build_utils.py` | path layout, normalization, table-role heuristics, subprocess helpers |
| `wide_build_common.py` | wide-build argument parsing and planning |
| `wide_build_duckdb.py` | main DuckDB execution engine |
| `wide_build_legacy.py` | legacy parity-oriented wide builder |
| `duckdb_build_utils.py` | shared DuckDB connection and export helpers |

## Reading order

If you are tracing the code for the first time:

1. `00_run_all.py`
2. `01_download_access_databases.py`
3. `02_extract_access_db.py`
4. `03_dictionary_ingest.py`
5. `04_harmonize.py`
6. `06_build_wide_panel.py`
7. `07_clean_panel.py`
8. `QA_QC/README.md`

That reading order mirrors the real data flow, so it is usually the least confusing way to understand the project.

For a short review, read `00_run_all.py`, then `07_clean_panel.py`, then `QA_QC/08_acceptance_audit.py`. That path covers orchestration, cleaning policy, and release gating.

For the documented parent-child method, read `METHODS_PRCH_CLEANING.md`.

For the documented whole-pipeline method, read `METHODS_PANEL_CONSTRUCTION.md`.

For the semantic acceptance check, run:

```bash
python Scripts/QA_QC/08_acceptance_audit.py \
  --root "$IPEDSDB_ROOT" \
  --years "2004:2023"
```

That command is not the public-release gate. Release also requires the complete
causal chain, mandatory benchmarks, the exact external B03/B04 evidence ZIP,
environment/container binding, manifest verification, and atomic bundle
promotion through `../tools/release_container.py gate`.
