#!/usr/bin/env python3
"""
Shared engine behind Stage 06: DuckDB execution for wide-panel construction.

Reads:
- proven v2 scalar-long parquet in release mode
- frozen analysis-schema and reviewed discrete-family contracts
- optional dictionary metadata for discovery auditing
- runtime planning options from `06_build_wide_panel.py`

Writes:
- wide-panel parquet outputs
- wide-build QA artifacts
- optional DuckDB database state

Focus:
- lazy long-panel reads where possible
- final analysis-key uniqueness proof and value-level lineage
- type/status and semantic-discrete QA
- development-only scalar/dimension fallback execution
- stitched wide exports
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
import re
import shutil
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.dataset as ds
import pyarrow.parquet as pq

from duckdb_build_utils import (
    bootstrap_build_db,
    copy_query_to_parquet,
    open_build_connection,
    quote_ident,
    record_build_run,
    sql_quote,
    write_query_csv,
)
from wide_build_common import (
    DIRECT_TRANSFORMATIONS,
    DISCRETE_TRANSFORMATION_PREFIX,
    WideBuildRuntime,
    WideContractError,
    build_disc_groups,
    build_numeric_targets,
    find_anti_garbage_hits,
    is_expected_disc_conflict,
    load_analysis_schema_contract,
    load_discrete_family_contract,
    load_legacy_schema_seed_manifest,
    order_targets,
    plan_legacy_schema_seeds,
    pick_col,
    pick_optional_col,
    prepare_runtime,
    resolve_disc_names,
)
from panel_v2_schema import PANEL_CONTRACT_ID

SCALAR_CONFLICT_KEY_COLS = ("UNITID", "year", "varnumber", "source_file")


def sql_upper_in(values: set[str]) -> str:
    return ", ".join(sql_quote(v) for v in sorted(values))


def build_dimension_expr(dim_sources: set[str], dim_prefixes: tuple[str, ...]) -> str:
    clauses: list[str] = []
    if dim_sources:
        clauses.append(f"source_file IN ({sql_upper_in(dim_sources)})")
    for prefix in dim_prefixes:
        clauses.append(f"SUBSTR(source_file, 1, {len(prefix)}) = {sql_quote(prefix)}")
    return " OR ".join(clauses) if clauses else "FALSE"


def build_stage_long_query(
    *,
    input_path: str,
    years: list[int],
    unitid_col: str,
    year_col: str,
    target_col: str,
    value_col: str,
    source_col: str | None,
    varnumber_col: str | None,
) -> str:
    years_sql = ", ".join(str(y) for y in years)
    source_expr = f"COALESCE(UPPER(TRIM(CAST({quote_ident(source_col)} AS VARCHAR))), '')" if source_col else "''"
    varnumber_expr = f"COALESCE(TRIM(CAST({quote_ident(varnumber_col)} AS VARCHAR)), '')" if varnumber_col else "''"
    null_tokens = ", ".join(sql_quote(x) for x in ["", ".", "nan", "none", "<na>", "na", "nat"])
    return f"""
        CREATE OR REPLACE VIEW stage.long_selected AS
        WITH src AS (
            SELECT
                TRY_CAST({quote_ident(unitid_col)} AS BIGINT) AS UNITID,
                TRY_CAST({quote_ident(year_col)} AS INTEGER) AS year,
                UPPER(TRIM(CAST({quote_ident(target_col)} AS VARCHAR))) AS varname,
                TRIM(CAST({quote_ident(value_col)} AS VARCHAR)) AS value_raw,
                {source_expr} AS source_file,
                {varnumber_expr} AS varnumber
            FROM read_parquet({sql_quote(input_path)})
            WHERE TRY_CAST({quote_ident(year_col)} AS INTEGER) IN ({years_sql})
        )
        SELECT
            UNITID,
            year,
            varname,
            CASE
                WHEN value_raw IS NULL THEN NULL
                WHEN lower(value_raw) IN ({null_tokens}) THEN NULL
                ELSE value_raw
            END AS value,
            CASE
                WHEN value_raw IS NULL THEN NULL
                WHEN lower(value_raw) IN ({null_tokens}) THEN NULL
                ELSE value_raw
            END AS value_norm,
            source_file,
            varnumber
        FROM src
        WHERE UNITID IS NOT NULL
          AND year IS NOT NULL
          AND varname IS NOT NULL
          AND varname <> ''
    """


def file_size_bytes(path: str | None) -> int:
    if not path or path == ":memory:":
        return 0
    fp = Path(path)
    if not fp.exists():
        return 0
    return int(fp.stat().st_size)


def build_where_sql(clauses: list[str]) -> str:
    clean = [c for c in clauses if c]
    if not clean:
        return ""
    return "WHERE " + " AND ".join(clean)


def build_year_base_query(
    *,
    year: int,
    extra_clauses: list[str],
    partition_sql: str,
    dedupe_order_sql: str,
) -> str:
    where_sql = build_where_sql([f"year = {int(year)}"] + extra_clauses)
    return f"""
        WITH deduped AS (
            SELECT
                UNITID,
                year,
                varname,
                value,
                value_norm,
                source_file,
                varnumber
            FROM (
                SELECT
                    *,
                    ROW_NUMBER() OVER (
                        PARTITION BY {partition_sql}
                        ORDER BY {dedupe_order_sql}
                    ) AS _rn
                FROM stage.long_selected
                {where_sql}
            )
            WHERE _rn = 1
        )
        SELECT
            ROW_NUMBER() OVER (ORDER BY {dedupe_order_sql}) AS row_id,
            UNITID,
            year,
            varname,
            value,
            value_norm,
            source_file,
            varnumber
        FROM deduped
    """


def append_query_to_parquet(
    con,
    query: str,
    out_path: str,
    writer: pq.ParquetWriter | None,
    schema: pa.Schema | None,
    *,
    rows_per_batch: int = 250_000,
) -> tuple[pq.ParquetWriter | None, pa.Schema | None, bool]:
    reader = con.execute(query).fetch_record_batch(rows_per_batch)
    wrote_any = False
    for batch in reader:
        if batch.num_rows == 0:
            continue
        table = pa.Table.from_batches([batch])
        if writer is None:
            Path(out_path).parent.mkdir(parents=True, exist_ok=True)
            schema = table.schema
            writer = pq.ParquetWriter(out_path, schema, compression="snappy")
        elif schema is not None and table.schema != schema:
            table = table.cast(schema, safe=False)
        writer.write_table(table)
        wrote_any = True
    return writer, schema, wrote_any


def append_rowid_windowed_parquet(
    con,
    *,
    source_table: str,
    select_columns: list[str],
    out_path: str,
    writer: pq.ParquetWriter | None,
    schema: pa.Schema | None,
    rows_per_batch: int = 250_000,
) -> tuple[pq.ParquetWriter | None, pa.Schema | None, bool]:
    min_row_id, max_row_id = con.execute(
        f"SELECT MIN(row_id), MAX(row_id) FROM {source_table}"
    ).fetchone()
    if min_row_id is None or max_row_id is None:
        return writer, schema, False

    wrote_any = False
    select_sql = ", ".join(select_columns)
    start = int(min_row_id)
    stop = int(max_row_id)
    while start <= stop:
        end = start + rows_per_batch - 1
        query = f"""
            SELECT {select_sql}
            FROM {source_table}
            WHERE row_id BETWEEN {start} AND {end}
        """
        reader = con.execute(query).fetch_record_batch(rows_per_batch)
        for batch in reader:
            if batch.num_rows == 0:
                continue
            table = pa.Table.from_batches([batch])
            if writer is None:
                Path(out_path).parent.mkdir(parents=True, exist_ok=True)
                schema = table.schema
                writer = pq.ParquetWriter(out_path, schema, compression="snappy")
            elif schema is not None and table.schema != schema:
                table = table.cast(schema, safe=False)
            writer.write_table(table)
            wrote_any = True
        start = end + 1
    return writer, schema, wrote_any


def build_hash_bucket_expr(
    key_cols: tuple[str, ...] | list[str],
    bucket_count: int,
    table_alias: str | None = None,
) -> str:
    if int(bucket_count) < 1:
        raise ValueError("bucket_count must be >= 1")
    prefix = f"{table_alias}." if table_alias else ""
    key_exprs: list[str] = []
    for col in key_cols:
        col_name = f"{prefix}{col}"
        if col in {"UNITID", "year"}:
            key_exprs.append(f"COALESCE(CAST({col_name} AS BIGINT), -1)")
        else:
            key_exprs.append(f"COALESCE(CAST({col_name} AS VARCHAR), '')")
    return f"CAST(HASH({', '.join(key_exprs)}) % {int(bucket_count)} AS BIGINT)"


def build_scalar_conflict_bucket_expr(bucket_count: int, table_alias: str | None = None) -> str:
    return build_hash_bucket_expr(SCALAR_CONFLICT_KEY_COLS, bucket_count, table_alias=table_alias)


def create_empty_year_scalar_conflict_keys(con) -> None:
    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE year_scalar_conflict_keys AS
        SELECT
            CAST(NULL AS BIGINT) AS UNITID,
            CAST(NULL AS INTEGER) AS year,
            CAST(NULL AS VARCHAR) AS varnumber,
            CAST(NULL AS VARCHAR) AS source_file,
            CAST(NULL AS BIGINT) AS distinct_values
        WHERE 1 = 0
        """
    )


def build_year_scalar_conflict_bucket_insert_sql(
    *,
    source_table: str,
    bucket_expr: str,
    bucket_id: int,
) -> str:
    return f"""
        INSERT INTO year_scalar_conflict_keys
        SELECT
            UNITID,
            year,
            varnumber,
            source_file,
            CAST(COUNT(DISTINCT value_norm) AS BIGINT) AS distinct_values
        FROM {source_table}
        WHERE value_norm IS NOT NULL
          AND ({bucket_expr}) = {int(bucket_id)}
        GROUP BY 1, 2, 3, 4
        HAVING COUNT(DISTINCT value_norm) > 1
    """


def resolve_profile_dir(args, runtime: WideBuildRuntime) -> Path | None:
    if args.profile_year is None:
        return None
    if args.profile_dir:
        path = Path(args.profile_dir)
    elif args.qc_dir:
        path = Path(args.qc_dir) / "sql_profiles"
    else:
        path = runtime.repo_root / "Checks" / "wide_qc" / "sql_profiles"
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_explain_artifact(
    con,
    *,
    profile_dir: Path | None,
    year: int,
    label: str,
    query: str,
    analyze: bool,
) -> None:
    if profile_dir is None:
        return
    explain_prefix = "EXPLAIN ANALYZE" if analyze else "EXPLAIN"
    plan_df = con.execute(f"{explain_prefix} {query}").fetchdf()
    out_path = profile_dir / f"year_{year}_{label}_{'analyze' if analyze else 'plan'}.txt"
    with out_path.open("w", encoding="utf-8") as fh:
        fh.write("-- QUERY\n")
        fh.write(query.strip())
        fh.write("\n\n")
        fh.write(f"-- {explain_prefix}\n")
        if "explain_value" in plan_df.columns:
            for row in plan_df.to_dict("records"):
                explain_key = str(row.get("explain_key", "") or "").strip()
                explain_value = str(row.get("explain_value", "") or "").strip()
                if explain_key:
                    fh.write(explain_key)
                    fh.write("\n")
                if explain_value:
                    fh.write(explain_value)
                    fh.write("\n")
        else:
            fh.write(plan_df.to_string(index=False))
            fh.write("\n")


def compute_year_scalar_conflict_keys_bucketed(
    con,
    *,
    year: int,
    source_table: str,
    bucket_count: int,
    log_phase_fn,
    profile_dir: Path | None,
    profile_analyze: bool,
) -> int:
    create_empty_year_scalar_conflict_keys(con)
    bucket_expr = build_scalar_conflict_bucket_expr(bucket_count)
    for bucket_id in range(int(bucket_count)):
        bucket_started = time.monotonic()
        bucket_rows = scalar_int(
            con,
            f"""
            SELECT COUNT(*)
            FROM {source_table}
            WHERE value_norm IS NOT NULL
              AND ({bucket_expr}) = {bucket_id}
            """,
        )
        log_phase_fn(
            f"year {year} scalar conflict bucket {bucket_id + 1}/{bucket_count} start",
            bucket_rows=bucket_rows,
        )
        if bucket_rows:
            insert_sql = build_year_scalar_conflict_bucket_insert_sql(
                source_table=source_table,
                bucket_expr=bucket_expr,
                bucket_id=bucket_id,
            )
            if bucket_id == 0:
                conflict_select_sql = insert_sql.split("INSERT INTO year_scalar_conflict_keys", 1)[1].strip()
                write_explain_artifact(
                    con,
                    profile_dir=profile_dir,
                    year=year,
                    label="scalar_conflict_bucket_0",
                    query=conflict_select_sql,
                    analyze=profile_analyze,
                )
            before_count = scalar_int(con, "SELECT COUNT(*) FROM year_scalar_conflict_keys")
            con.execute(insert_sql)
            after_count = scalar_int(con, "SELECT COUNT(*) FROM year_scalar_conflict_keys")
            bucket_conflict_keys = after_count - before_count
        else:
            bucket_conflict_keys = 0
            after_count = scalar_int(con, "SELECT COUNT(*) FROM year_scalar_conflict_keys")
        log_phase_fn(
            f"year {year} scalar conflict bucket {bucket_id + 1}/{bucket_count} end",
            bucket_rows=bucket_rows,
            bucket_conflict_keys=bucket_conflict_keys,
            accumulator_conflict_keys=after_count,
            elapsed_seconds=f"{time.monotonic() - bucket_started:.3f}",
        )
    return scalar_int(con, "SELECT COUNT(*) FROM year_scalar_conflict_keys")


def stitch_parquet_files(part_paths: list[str], out_path: str) -> None:
    writer: pq.ParquetWriter | None = None
    try:
        for part_path in part_paths:
            table = pq.ParquetFile(part_path).read()
            if writer is None:
                Path(out_path).parent.mkdir(parents=True, exist_ok=True)
                writer = pq.ParquetWriter(out_path, table.schema, compression="snappy")
            writer.write_table(table)
    finally:
        if writer is not None:
            writer.close()


def stitch_parquet_files_bounded(
    part_paths: list[str | Path],
    out_path: str | Path,
    *,
    batch_rows: int,
) -> None:
    """Atomically concatenate ordered Parquet parts without reading a part whole.

    Callers are responsible for supplying parts in their canonical row order.
    The bounded record batches become output row groups, so peak Arrow memory is
    controlled independently of each input part's physical row-group layout.
    """
    if batch_rows <= 0:
        raise ValueError("batch_rows must be positive")
    target = Path(out_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    staged = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
    writer: pq.ParquetWriter | None = None
    try:
        for part_path in part_paths:
            parquet = pq.ParquetFile(str(part_path))
            for batch in parquet.iter_batches(batch_size=int(batch_rows)):
                if writer is None:
                    writer = pq.ParquetWriter(
                        staged,
                        batch.schema,
                        compression="zstd",
                    )
                writer.write_batch(batch, row_group_size=int(batch_rows))
        if writer is None:
            raise ValueError("cannot stitch an empty Parquet part list")
        writer.close()
        writer = None
        os.replace(staged, target)
    finally:
        if writer is not None:
            writer.close()
        if staged.exists():
            staged.unlink()


def create_empty_conflicts(con) -> None:
    con.execute(
        """
        CREATE OR REPLACE TABLE qa.scalar_conflicts AS
        SELECT
            CAST(NULL AS BIGINT) AS row_id,
            CAST(NULL AS BIGINT) AS UNITID,
            CAST(NULL AS INTEGER) AS year,
            CAST(NULL AS VARCHAR) AS varname,
            CAST(NULL AS VARCHAR) AS value,
            CAST(NULL AS VARCHAR) AS value_norm,
            CAST(NULL AS VARCHAR) AS varnumber,
            CAST(NULL AS VARCHAR) AS source_file,
            CAST(NULL AS BIGINT) AS distinct_values
        WHERE 1 = 0
        """
    )


def create_empty_disc_conflicts(con) -> None:
    con.execute(
        """
        CREATE OR REPLACE TABLE qa.disc_conflicts AS
        SELECT
            CAST(NULL AS BIGINT) AS row_id,
            CAST(NULL AS BIGINT) AS UNITID,
            CAST(NULL AS INTEGER) AS year,
            CAST(NULL AS VARCHAR) AS varname,
            CAST(NULL AS VARCHAR) AS value,
            CAST(NULL AS VARCHAR) AS value_norm,
            CAST(NULL AS VARCHAR) AS source_file,
            CAST(NULL AS VARCHAR) AS varnumber,
            CAST(NULL AS VARCHAR) AS base,
            CAST(NULL AS VARCHAR) AS suffix,
            CAST(NULL AS BOOLEAN) AS is_active,
            CAST(NULL AS BIGINT) AS n_active
        WHERE 1 = 0
        """
    )


def create_empty_cast_report(con) -> None:
    con.execute(
        """
        CREATE OR REPLACE TABLE qa.cast_report AS
        SELECT
            CAST(NULL AS INTEGER) AS year,
            CAST(NULL AS VARCHAR) AS column,
            CAST(NULL AS BIGINT) AS non_empty_tokens,
            CAST(NULL AS BIGINT) AS parsed_numeric_tokens,
            CAST(NULL AS BIGINT) AS failed_parse_tokens
        WHERE 1 = 0
        """
    )


def register_df_as_table(con, table_name: str, df: pd.DataFrame) -> None:
    temp_name = table_name.replace(".", "_") + "_df"
    con.register(temp_name, df)
    con.execute(f"CREATE OR REPLACE TABLE {table_name} AS SELECT * FROM {temp_name}")
    con.unregister(temp_name)


def write_dataframe(path: str | None, df: pd.DataFrame) -> None:
    if not path:
        return
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.suffix.lower() == ".parquet":
        df.to_parquet(out_path, index=False)
    else:
        df.to_csv(out_path, index=False)


def joined_sorted(values: set[str]) -> str:
    return "|".join(sorted(v for v in values if v))


def build_column_lineage_df(
    *,
    source_df: pd.DataFrame,
    legacy_seed_plan_df: pd.DataFrame,
    seeded_legacy_names: set[str],
    final_targets: list[str],
    var_to_group: dict[str, tuple[str, str]],
    disc_name_map: dict[str, str],
) -> pd.DataFrame:
    source_lookup: dict[str, dict[str, object]] = {}
    for varname, grp in source_df.groupby("varname", dropna=False):
        source_files = {str(x).strip().upper() for x in grp["source_file"].fillna("").tolist() if str(x).strip()}
        varnumbers = {str(x).strip() for x in grp["varnumber"].fillna("").tolist() if str(x).strip()}
        source_lookup[str(varname)] = {
            "source_files": source_files,
            "varnumbers": varnumbers,
            "source_rows": int(pd.to_numeric(grp["source_rows"], errors="coerce").fillna(0).sum()),
            "source_non_empty_rows": int(pd.to_numeric(grp["source_non_empty_rows"], errors="coerce").fillna(0).sum()),
        }

    legacy_seed_meta = {
        str(row["column_name"]): {
            "seed_reason": str(row.get("seed_reason", "")),
            "dtype": str(row.get("dtype", "")),
            "source_contract": str(row.get("source_contract", "")),
        }
        for row in legacy_seed_plan_df.to_dict("records")
    }

    disc_components_by_output: dict[str, set[str]] = {}
    for component, (base, _) in var_to_group.items():
        output_name = disc_name_map.get(base, base)
        disc_components_by_output.setdefault(output_name, set()).add(component)

    rows: list[dict[str, object]] = []
    for rank, column in enumerate(final_targets, start=1):
        lineage_kind = "direct_scalar"
        source_vars = {column}
        seed_info = legacy_seed_meta.get(column, {})
        if column in disc_components_by_output:
            lineage_kind = "disc_collapsed"
            source_vars = set(disc_components_by_output[column])
        elif column in seeded_legacy_names or (column in legacy_seed_meta and column not in source_lookup):
            lineage_kind = "legacy_seed"

        source_files: set[str] = set()
        varnumbers: set[str] = set()
        source_rows = 0
        source_non_empty_rows = 0
        for varname in source_vars:
            info = source_lookup.get(varname, {})
            source_files.update(info.get("source_files", set()))
            varnumbers.update(info.get("varnumbers", set()))
            source_rows += int(info.get("source_rows", 0))
            source_non_empty_rows += int(info.get("source_non_empty_rows", 0))

        rows.append(
            {
                "output_column": column,
                "final_target_rank": rank,
                "lineage_kind": lineage_kind,
                "source_varnames": joined_sorted(source_vars),
                "source_varname_count": len(source_vars),
                "primary_source_file": sorted(source_files)[0] if len(source_files) == 1 else "",
                "source_files": joined_sorted(source_files),
                "source_file_count": len(source_files),
                "source_varnumbers": joined_sorted(varnumbers),
                "varnumber_count": len(varnumbers),
                "source_rows": source_rows,
                "source_non_empty_rows": source_non_empty_rows,
                "lineage_ambiguous": len(source_files) > 1,
                "seeded_for_legacy_schema": column in seeded_legacy_names,
                "legacy_seed_reason": seed_info.get("seed_reason", ""),
                "legacy_seed_dtype": seed_info.get("dtype", ""),
                "legacy_seed_source_contract": seed_info.get("source_contract", ""),
            }
        )
    return pd.DataFrame(rows)


def build_target_lineage_df(
    *,
    stage_df: pd.DataFrame,
    scalar_df: pd.DataFrame,
    legacy_seed_plan_df: pd.DataFrame,
    seeded_legacy_names: set[str],
    exclude_vars: set[str],
    targets_with_data: set[str],
    component_vars: set[str],
    var_to_group: dict[str, tuple[str, str]],
    disc_name_map: dict[str, str],
    anti_hits_initial: list[str],
    anti_hits_final: list[str],
    final_targets: list[str],
    drop_empty_cols: bool,
    drop_disc_components: bool,
    drop_anti_garbage_cols: bool,
) -> pd.DataFrame:
    stage_stats = {
        str(row["varname"]): {
            "stage_rows": int(row["stage_rows"]),
            "stage_non_empty_rows": int(row["stage_non_empty_rows"]),
        }
        for row in stage_df.to_dict("records")
    }
    scalar_stats = {
        str(row["varname"]): {
            "scalar_rows": int(row["scalar_rows"]),
            "scalar_non_empty_rows": int(row["scalar_non_empty_rows"]),
        }
        for row in scalar_df.to_dict("records")
    }
    legacy_seed_meta = {
        str(row["column_name"]): {
            "seed_reason": str(row["seed_reason"]),
            "dtype": str(row["dtype"]),
            "source_contract": str(row["source_contract"]),
        }
        for row in legacy_seed_plan_df.to_dict("records")
    }
    disc_output_lookup = {base: out for base, out in disc_name_map.items()}
    output_names = set(disc_name_map.values())
    anti_hits_initial_set = set(anti_hits_initial)
    anti_hits_final_set = set(anti_hits_final)
    final_rank = {name: idx + 1 for idx, name in enumerate(final_targets)}

    all_names = set(stage_stats) | set(scalar_stats) | set(component_vars) | set(final_targets) | output_names | exclude_vars | set(legacy_seed_meta)
    for base, out_name in disc_name_map.items():
        all_names.add(base)
        all_names.add(out_name)

    rows: list[dict] = []
    for name in sorted(all_names):
        stage_info = stage_stats.get(name, {})
        scalar_info = scalar_stats.get(name, {})
        seed_info = legacy_seed_meta.get(name, {})
        base, suffix = var_to_group.get(name, ("", ""))
        output_varname = disc_output_lookup.get(base, "") if base else ""
        rows.append(
            {
                "varname": name,
                "excluded_by_user": name in exclude_vars,
                "present_in_stage_long_selected": name in stage_stats,
                "stage_rows": int(stage_info.get("stage_rows", 0)),
                "stage_non_empty_rows": int(stage_info.get("stage_non_empty_rows", 0)),
                "present_after_lane_scalar_filter": name in scalar_stats,
                "scalar_rows": int(scalar_info.get("scalar_rows", 0)),
                "scalar_non_empty_rows": int(scalar_info.get("scalar_non_empty_rows", 0)),
                "non_empty_after_scalar_filter": name in targets_with_data,
                "dropped_as_globally_empty": bool(drop_empty_cols and name in scalar_stats and name not in targets_with_data),
                "present_in_disc_group_map": name in var_to_group,
                "disc_group_base": base,
                "disc_group_suffix": suffix,
                "disc_output_varname": output_varname,
                "legacy_seed_reason": seed_info.get("seed_reason", ""),
                "legacy_seed_dtype": seed_info.get("dtype", ""),
                "legacy_seed_source_contract": seed_info.get("source_contract", ""),
                "seeded_for_legacy_schema": name in seeded_legacy_names,
                "removed_as_disc_component": bool(drop_disc_components and name in component_vars and name not in final_rank),
                "added_as_disc_output": name in output_names,
                "anti_garbage_hit_initial": name in anti_hits_initial_set,
                "removed_as_anti_garbage": bool(drop_anti_garbage_cols and name in anti_hits_initial_set and name not in final_rank),
                "anti_garbage_hit_final": name in anti_hits_final_set,
                "final_in_all_targets": name in final_rank,
                "final_target_rank": final_rank.get(name),
            }
        )
    return pd.DataFrame(rows)


def build_wide_query(targets: list[str], source_table: str, spine_table: str = "stage.spine") -> str:
    if not targets:
        return """
            SELECT
                CAST(s.year AS INTEGER) AS year,
                CAST(s.UNITID AS BIGINT) AS UNITID
            FROM {spine_table} s
            ORDER BY s.year, s.UNITID
        """.format(spine_table=spine_table)
    exprs = [
        f"MAX(CASE WHEN a.varname = {sql_quote(t)} THEN a.value END) AS {quote_ident(t)}"
        for t in targets
    ]
    select_sql = ",\n                ".join(exprs)
    return f"""
        SELECT
            CAST(s.year AS INTEGER) AS year,
            CAST(s.UNITID AS BIGINT) AS UNITID,
            {select_sql}
        FROM {spine_table} s
        LEFT JOIN {source_table} a
          ON s.year = a.year
         AND s.UNITID = a.UNITID
        GROUP BY s.year, s.UNITID
        ORDER BY s.year, s.UNITID
    """


def build_typed_wide_query(targets: list[str], numeric_targets: set[str], source_table: str = "mart.panel_wide_raw") -> str:
    select_exprs = ["CAST(year AS INTEGER) AS year", "CAST(UNITID AS BIGINT) AS UNITID"]
    for target in targets:
        ident = quote_ident(target)
        if target in numeric_targets:
            select_exprs.append(f"TRY_CAST({ident} AS DOUBLE) AS {ident}")
        else:
            select_exprs.append(f"CAST({ident} AS VARCHAR) AS {ident}")
    return f"""
        SELECT
            {", ".join(select_exprs)}
        FROM {source_table}
        ORDER BY year, UNITID
    """


def build_non_null_count_query(targets: list[str], source_table: str = "mart.panel_wide") -> str | None:
    if not targets:
        return None
    exprs = [f"SUM(CASE WHEN {quote_ident(t)} IS NOT NULL THEN 1 ELSE 0 END) AS {quote_ident(t)}" for t in targets]
    return f"SELECT {', '.join(exprs)} FROM {source_table}"


def build_cast_report_query(numeric_targets: list[str], source_table: str = "mart.panel_wide_raw") -> str | None:
    if not numeric_targets:
        return None
    unions = []
    for target in numeric_targets:
        ident = quote_ident(target)
        unions.append(
            f"""
            SELECT
                year,
                {sql_quote(target)} AS column,
                CAST(COUNT({ident}) AS BIGINT) AS non_empty_tokens,
                CAST(SUM(CASE WHEN TRY_CAST({ident} AS DOUBLE) IS NOT NULL THEN 1 ELSE 0 END) AS BIGINT) AS parsed_numeric_tokens,
                CAST(COUNT({ident}) - SUM(CASE WHEN TRY_CAST({ident} AS DOUBLE) IS NOT NULL THEN 1 ELSE 0 END) AS BIGINT) AS failed_parse_tokens
            FROM {source_table}
            GROUP BY year
            """
        )
    return "\nUNION ALL\n".join(unions)


def log_phase(message: str, **fields) -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    suffix = " ".join(f"{key}={value}" for key, value in fields.items())
    if suffix:
        print(f"[phase {stamp}] {message} {suffix}", flush=True)
    else:
        print(f"[phase {stamp}] {message}", flush=True)


def scalar_int(con, query: str) -> int:
    value = con.execute(query).fetchone()[0]
    if value is None:
        return 0
    return int(value)


RELEASE_REQUIRED_SCALAR_COLUMNS = {
    "year",
    "UNITID",
    "contract_id",
    "variable_id",
    "source_varnumber",
    "varname",
    "value",
    "raw_value",
    "value_status",
    "source_file",
    "access_table_name",
    "lane",
    "source_row_id",
    "source_row_hash",
}
RELEASE_NULL_STATUSES = {"missing", "not_applicable", "suppressed"}
RELEASE_ALLOWED_STATUSES = RELEASE_NULL_STATUSES | {"reported", "imputed", "invalid_unresolved"}
MISSING_DICTIONARY_SAMPLE_ORDER_BY = (
    "year, lane, source_file, varname, variable_id, source_varnumber"
)


def build_missing_dictionary_query() -> str:
    """Return the exact dictionary-coverage failure query.

    Filter each source lane through a direct anti join before deduplicating the
    (normally empty) failure stream.  Keeping the anti joins explicit prevents
    DuckDB from turning a correlated NOT EXISTS over all Stage 05 cells into a
    delimiter join with a global pre-join hash aggregate.
    """
    return """
        WITH dictionary_keys AS MATERIALIZED (
            SELECT DISTINCT year, variable_id, source_varnumber, varname, source_file
            FROM release_dictionary
            WHERE metadata_source <> ''
        ),
        missing_cells AS (
            SELECT c.year, c.variable_id, c.source_varnumber, c.varname,
                   c.source_file, 'scalar' AS lane
            FROM release_scalar c
            ANTI JOIN dictionary_keys d
              ON d.year = c.year
             AND d.variable_id = c.variable_id
             AND d.source_varnumber = c.source_varnumber
             AND d.varname = c.varname
             AND d.source_file = c.source_file
            UNION ALL
            SELECT c.year, c.variable_id, c.source_varnumber, c.varname,
                   c.source_file, 'dimensioned' AS lane
            FROM release_dimensioned c
            ANTI JOIN dictionary_keys d
              ON d.year = c.year
             AND d.variable_id = c.variable_id
             AND d.source_varnumber = c.source_varnumber
             AND d.varname = c.varname
             AND d.source_file = c.source_file
        )
        SELECT DISTINCT year, variable_id, source_varnumber, varname, source_file, lane
        FROM missing_cells
    """


def _bounded_failure_sample(
    con,
    *,
    count_query: str,
    sample_order_by: str,
    output_path: Path,
    limit: int,
) -> int:
    """Count failures and always publish a deterministic, schema-bearing ledger.

    Successful release bundles need positive evidence that each failure query ran.
    A missing file is ambiguous, so the zero-failure case is represented by a
    header-only CSV rather than by omitting the ledger.
    """
    cache_path = output_path.with_name(
        f".{output_path.stem}.{uuid.uuid4().hex}.failure_rows.parquet"
    )
    log_phase("release failure gate start", ledger=output_path.name)
    try:
        count = atomic_copy_query_to_parquet(
            con,
            f"SELECT * FROM ({count_query}) AS failure_rows",
            cache_path,
        )
        order_sql = f" ORDER BY {sample_order_by}" if sample_order_by.strip() else ""
        atomic_copy_query_to_csv(
            con,
            "SELECT * FROM read_parquet("
            f"{sql_quote(str(cache_path))}, hive_partitioning=FALSE)"
            f"{order_sql} LIMIT {int(limit)}",
            output_path,
        )
    finally:
        if cache_path.exists():
            cache_path.unlink()
    log_phase(
        "release failure gate complete",
        ledger=output_path.name,
        failures=count,
    )
    if count:
        _write_release_csv(
            output_path.with_name(f"{output_path.stem}_summary.csv"),
            pd.DataFrame(
                [
                    {
                        "total_failure_rows": count,
                        "sample_rows_written": min(count, int(limit)),
                        "sample_truncated": count > int(limit),
                    }
                ]
            ),
        )
    return count


def _bounded_ambiguous_analysis_mapping_sample(
    con,
    *,
    years: list[int],
    output_path: str | Path,
    limit: int,
) -> int:
    """Prove direct-map uniqueness without a global source-row aggregate.

    A map containing one exact key type with at most one output per key is
    structurally incapable of mapping a source row to multiple columns.  Mixed
    or ``auto`` maps are checked against the compact reviewed dictionary
    signature inventory first; only observed ambiguous signatures reach the
    year-bounded source-row count and sample.
    """
    if not years:
        raise ValueError("analysis-mapping validation requires at least one year")
    target = Path(output_path)
    columns = [
        "year",
        "UNITID",
        "variable_id",
        "source_file",
        "source_row_id",
        "analysis_columns",
    ]
    summary_path = target.with_name(f"{target.stem}_summary.csv")
    if summary_path.exists():
        summary_path.unlink()
    log_phase("release failure gate start", ledger=target.name)

    map_rows = con.execute(
        """
        SELECT match_type, match_value, match_value_upper, analysis_column
        FROM stage.analysis_source_map
        """
    ).fetchall()
    output_columns = {str(row[3]) for row in map_rows}
    match_types = {str(row[0]) for row in map_rows}
    structurally_unique = not map_rows or len(output_columns) <= 1
    if not structurally_unique and match_types in ({"variable_id"}, {"varname"}):
        key_index = 1 if match_types == {"variable_id"} else 2
        outputs_by_key: dict[str, set[str]] = {}
        for row in map_rows:
            outputs_by_key.setdefault(str(row[key_index]), set()).add(str(row[3]))
        structurally_unique = all(
            len(outputs) <= 1 for outputs in outputs_by_key.values()
        )
    if structurally_unique:
        _write_release_csv(target, pd.DataFrame(columns=columns))
        log_phase(
            "release failure gate complete",
            ledger=target.name,
            failures=0,
            proof="structural_exact_key",
        )
        return 0

    total_count = 0
    sample_rows: list[dict[str, object]] = []
    remaining = max(0, int(limit))
    for year in sorted(int(value) for value in years):
        signature_relation = (
            f"release_ambiguous_mapping_signatures_{year}_{uuid.uuid4().hex}"
        )
        signature_ident = quote_ident(signature_relation)
        log_phase("release ambiguity signature year start", year=year)
        try:
            con.execute(
                f"""
                CREATE TEMP TABLE {signature_ident} AS
                WITH dictionary_signatures AS (
                    SELECT DISTINCT year, variable_id, varname, source_file
                    FROM release_dictionary
                    WHERE year = {year}
                )
                SELECT
                    d.year,
                    d.variable_id,
                    d.varname,
                    d.source_file,
                    COUNT(DISTINCT m.analysis_column) AS analysis_columns
                FROM dictionary_signatures d
                INNER JOIN stage.analysis_source_map m
                  ON {_release_match_sql('d', 'm')}
                 AND d.year BETWEEN m.first_year AND m.last_year
                GROUP BY d.year, d.variable_id, d.varname, d.source_file
                HAVING COUNT(DISTINCT m.analysis_column) > 1
                """
            )
            signature_count = scalar_int(
                con,
                f"SELECT COUNT(*) FROM {signature_ident}",
            )
            year_count = 0
            if signature_count:
                failure_query = f"""
                    SELECT
                        s.year,
                        s.UNITID,
                        s.variable_id,
                        s.source_file,
                        s.source_row_id,
                        COUNT(DISTINCT m.analysis_column) AS analysis_columns
                    FROM release_scalar s
                    INNER JOIN {signature_ident} a
                      ON a.year = s.year
                     AND a.variable_id = s.variable_id
                     AND a.varname = s.varname
                     AND a.source_file = s.source_file
                    INNER JOIN stage.analysis_source_map m
                      ON {_release_match_sql('s', 'm')}
                     AND s.year BETWEEN m.first_year AND m.last_year
                    WHERE s.year = {year}
                    GROUP BY
                        s.year,
                        s.UNITID,
                        s.variable_id,
                        s.source_file,
                        s.source_row_id
                    HAVING COUNT(DISTINCT m.analysis_column) > 1
                """
                year_count = scalar_int(
                    con,
                    f"SELECT COUNT(*) FROM ({failure_query}) failure_rows",
                )
                total_count += year_count
                if year_count and remaining:
                    rows = con.execute(
                        f"""
                        SELECT * FROM ({failure_query}) failure_rows
                        ORDER BY UNITID, variable_id, source_file, source_row_id
                        LIMIT {remaining}
                        """
                    ).fetchdf()
                    sample_rows.extend(rows.to_dict("records"))
                    remaining -= min(year_count, remaining)
            log_phase(
                "release ambiguity signature year complete",
                year=year,
                signatures=signature_count,
                failures=year_count,
            )
        finally:
            con.execute(f"DROP TABLE IF EXISTS {signature_ident}")

    sample = pd.DataFrame(sample_rows, columns=columns)
    if not sample.empty:
        sample = sample.sort_values(
            ["year", "UNITID", "variable_id", "source_file", "source_row_id"],
            kind="mergesort",
        ).reset_index(drop=True)
    _write_release_csv(target, sample)
    if total_count:
        _write_release_csv(
            summary_path,
            pd.DataFrame(
                [
                    {
                        "total_failure_rows": total_count,
                        "sample_rows_written": min(total_count, int(limit)),
                        "sample_truncated": total_count > int(limit),
                    }
                ]
            ),
        )
    log_phase(
        "release failure gate complete",
        ledger=target.name,
        failures=total_count,
        proof="reviewed_signatures_then_year_bounded_rows",
    )
    return total_count


def atomic_copy_query_to_parquet(
    con,
    query: str,
    out_path: str | Path,
    *,
    row_group_size: int | None = None,
) -> int:
    """Promote a complete parquet only after DuckDB closes the staged file."""
    target = Path(out_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    staged = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
    copy_options = ["FORMAT PARQUET", "COMPRESSION ZSTD"]
    if row_group_size is not None:
        if row_group_size < 2048 or row_group_size % 2048 != 0:
            raise ValueError(
                "row_group_size must be at least 2048 and a multiple of 2048"
            )
        copy_options.append(f"ROW_GROUP_SIZE {int(row_group_size)}")
    try:
        result = con.execute(
            f"COPY ({query}) TO {sql_quote(str(staged))} "
            f"({', '.join(copy_options)})"
        ).fetchone()
        os.replace(staged, target)
        return int(result[0]) if result else 0
    finally:
        if staged.exists():
            staged.unlink()


def atomic_copy_query_to_csv(con, query: str, out_path: str | Path) -> None:
    """Stream a query to an atomically promoted UTF-8 CSV."""
    target = Path(out_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    staged = target.with_name(f".{target.name}.{uuid.uuid4().hex}.tmp")
    try:
        con.execute(
            f"COPY ({query}) TO {sql_quote(str(staged))} "
            "(FORMAT CSV, HEADER TRUE)"
        )
        os.replace(staged, target)
    finally:
        if staged.exists():
            staged.unlink()


def _analysis_source_map(analysis_df: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for row in analysis_df.to_dict("records"):
        if str(row["status"]).strip().lower() not in {"approved", "active"}:
            continue
        transformation = str(row["transformation"]).strip()
        if transformation.lower() not in {"identity", "direct", "none"}:
            continue
        for source in row["source_variables_parsed"]:
            source_text = str(source).strip()
            lower = source_text.lower()
            if lower.startswith("variable_id:"):
                match_type, match_value = "variable_id", source_text.split(":", 1)[1]
            elif lower.startswith("varname:"):
                match_type, match_value = "varname", source_text.split(":", 1)[1].upper()
            else:
                match_type, match_value = "auto", source_text
            rows.append(
                {
                    "analysis_column": row["analysis_column"],
                    "logical_type": row["logical_type"],
                    "transformation": transformation,
                    "first_year": int(row["first_year_int"]),
                    "last_year": int(row["last_year_int"]),
                    "nullable": bool(row["nullable_bool"]),
                    "match_type": match_type,
                    "match_value": match_value,
                    "match_value_upper": match_value.upper(),
                }
            )
    return pd.DataFrame(
        rows,
        columns=[
            "analysis_column",
            "logical_type",
            "transformation",
            "first_year",
            "last_year",
            "nullable",
            "match_type",
            "match_value",
            "match_value_upper",
        ],
    )


def _analysis_exclusion_map(analysis_df: pd.DataFrame) -> pd.DataFrame:
    """Retain reviewed source identities that are governed but not emitted."""
    rows: list[dict[str, object]] = []
    for row in analysis_df.to_dict("records"):
        status = str(row["status"]).strip().lower()
        if status != "excluded_all_null":
            continue
        transformation = str(row["transformation"]).strip().lower()
        if transformation not in {"identity", "direct", "none"}:
            continue
        for source in row["source_variables_parsed"]:
            source_text = str(source).strip()
            lower = source_text.lower()
            if lower.startswith("variable_id:"):
                match_type, match_value = "variable_id", source_text.split(":", 1)[1]
            elif lower.startswith("varname:"):
                match_type, match_value = "varname", source_text.split(":", 1)[1].upper()
            else:
                match_type, match_value = "auto", source_text
            rows.append(
                {
                    "analysis_column": row["analysis_column"],
                    "status": status,
                    "exclusion_reason": row["inclusion_reason"],
                    "first_year": int(row["first_year_int"]),
                    "last_year": int(row["last_year_int"]),
                    "match_type": match_type,
                    "match_value": match_value,
                    "match_value_upper": match_value.upper(),
                }
            )
    columns = [
        "analysis_column",
        "status",
        "exclusion_reason",
        "first_year",
        "last_year",
        "match_type",
        "match_value",
        "match_value_upper",
    ]
    if not rows:
        # DuckDB otherwise infers every column in an empty pandas frame as
        # INTEGER, which breaks the ordinary (no exclusions) release path when
        # SQL compares or coalesces these identity/status fields as strings.
        return pd.DataFrame(
            {
                column: pd.Series(
                    dtype="int64" if column in {"first_year", "last_year"} else "string"
                )
                for column in columns
            }
        )
    return pd.DataFrame(rows, columns=columns)


def _register_release_contracts(con, analysis_df: pd.DataFrame, discrete_df: pd.DataFrame) -> None:
    included = analysis_df[analysis_df["status"].isin(["approved", "active"])]
    analysis_register = included[
        [
            "contract_id",
            "analysis_column",
            "logical_type",
            "transformation",
            "inclusion_reason",
            "first_year_int",
            "last_year_int",
            "nullable_bool",
            "status",
        ]
    ].copy()
    register_df_as_table(con, "stage.analysis_contract", analysis_register)
    register_df_as_table(con, "stage.analysis_source_map", _analysis_source_map(analysis_df))
    register_df_as_table(
        con,
        "stage.analysis_exclusion_map",
        _analysis_exclusion_map(analysis_df),
    )

    discrete_register = discrete_df[
        [
            "contract_id",
            "source_file",
            "family_id",
            "component_varname",
            "component_code",
            "semantic_type",
            "output_column",
            "output_type",
            "multi_active_policy",
            "drop_components_bool",
            "zero_active_policy",
            "zero_active_value",
            "source_evidence",
            "review_note",
        ]
    ].copy()
    register_df_as_table(con, "stage.discrete_contract", discrete_register)
    token_rows: list[dict[str, str]] = []
    for row in discrete_df.to_dict("records"):
        for token_class, field in [
            ("active", "active_tokens_parsed"),
            ("inactive", "inactive_tokens_parsed"),
            ("missing", "missing_tokens_parsed"),
        ]:
            for token in row[field]:
                token_rows.append(
                    {
                        "source_file": row["source_file"],
                        "family_id": row["family_id"],
                        "component_varname": row["component_varname"],
                        "token": str(token).lower(),
                        "token_class": token_class,
                    }
                )
    token_df = pd.DataFrame(
        token_rows,
        columns=["source_file", "family_id", "component_varname", "token", "token_class"],
    )
    register_df_as_table(con, "stage.discrete_tokens", token_df)


def _release_match_sql(source_alias: str = "s", map_alias: str = "m") -> str:
    return f"""
        (
            ({map_alias}.match_type = 'variable_id' AND {source_alias}.variable_id = {map_alias}.match_value)
         OR ({map_alias}.match_type = 'varname' AND UPPER({source_alias}.varname) = {map_alias}.match_value_upper)
         OR ({map_alias}.match_type = 'auto' AND (
                {source_alias}.variable_id = {map_alias}.match_value
             OR UPPER({source_alias}.varname) = {map_alias}.match_value_upper
            ))
        )
    """


def _release_direct_mapping_query(
    *,
    source_table: str = "release_scalar",
    map_table: str = "stage.analysis_source_map",
    year: int | None = None,
) -> str:
    """Return the exact direct-map join as two bounded equi-join branches.

    The historical OR predicate has one-row semantics when an ``auto`` mapping
    matches both variable_id and varname.  The second branch therefore excludes
    that already-matched pair instead of using a global DISTINCT operation.
    """
    mapped_columns = """
        m.analysis_column,
        m.logical_type,
        m.transformation,
        m.first_year,
        m.last_year,
        m.nullable
    """
    year_filter = f"WHERE s.year = {int(year)}" if year is not None else ""
    varname_filters = [
        "(m.match_type = 'varname' OR s.variable_id IS DISTINCT FROM m.match_value)"
    ]
    if year is not None:
        varname_filters.append(f"s.year = {int(year)}")
    varname_where = "WHERE " + " AND ".join(varname_filters)
    return f"""
        SELECT s.*, {mapped_columns}
        FROM {source_table} s
        INNER JOIN (
            SELECT * FROM {map_table}
            WHERE match_type IN ('variable_id', 'auto')
        ) m
          ON s.variable_id = m.match_value
        {year_filter}
        UNION ALL
        SELECT s.*, {mapped_columns}
        FROM {source_table} s
        INNER JOIN (
            SELECT * FROM {map_table}
            WHERE match_type IN ('varname', 'auto')
        ) m
          ON UPPER(s.varname) = m.match_value_upper
        {varname_where}
    """


def _materialize_release_direct_mapped(
    con,
    *,
    years: list[int],
    temp_dir: str | Path,
) -> list[Path]:
    """Write direct mappings one year at a time, then expose one lazy view."""
    root = Path(temp_dir) / "release_direct_mapped"
    staged = root.with_name(f".{root.name}.{uuid.uuid4().hex}.tmp")
    if staged.exists():
        shutil.rmtree(staged)
    parts: list[Path] = []
    try:
        for year in years:
            part = staged / f"year={int(year)}" / "part.parquet"
            log_phase("release direct mapping year start", year=int(year))
            atomic_copy_query_to_parquet(
                con,
                _release_direct_mapping_query(year=int(year)),
                part,
            )
            log_phase("release direct mapping year complete", year=int(year))
            parts.append(part)
        if root.exists():
            shutil.rmtree(root)
        os.replace(staged, root)
    finally:
        if staged.exists():
            shutil.rmtree(staged)
    final_parts = [root / f"year={int(year)}" / "part.parquet" for year in years]
    files_sql = ", ".join(sql_quote(str(path)) for path in final_parts)
    con.execute(
        "CREATE OR REPLACE TEMP VIEW release_direct_mapped AS "
        f"SELECT * FROM read_parquet([{files_sql}], "
        "union_by_name=TRUE, hive_partitioning=FALSE)"
    )
    return final_parts


def _write_release_csv(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    staged = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        df.to_csv(staged, index=False)
        os.replace(staged, path)
    finally:
        if staged.exists():
            staged.unlink()


def _release_cast_case(field: str) -> str:
    """Return a value expression for one contract logical type."""
    if field == "integer":
        return "TRY_CAST(normalized_value AS BIGINT)"
    if field == "decimal":
        return "TRY_CAST(normalized_value AS DECIMAL(38, 10))"
    if field == "float":
        return "TRY_CAST(normalized_value AS DOUBLE)"
    if field == "boolean":
        return """
            CASE
                WHEN LOWER(normalized_value) IN ('1', 'true', 'yes', 'y') THEN TRUE
                WHEN LOWER(normalized_value) IN ('0', 'false', 'no', 'n') THEN FALSE
                ELSE NULL
            END
        """
    if field in {"categorical string", "free text", "identifier string"}:
        return "CAST(normalized_value AS VARCHAR)"
    raise WideContractError(f"unsupported logical type during pivot: {field}")


def _materialize_release_unique_values(
    con,
    *,
    years: list[int],
    temp_dir: str | Path,
) -> list[Path]:
    """Prove one canonical value per key in bounded yearly partitions.

    The caller must run the final-conflict gate before invoking this helper.
    ``MAX`` is therefore a deterministic collapse of identical duplicate
    lineage values, never a conflict-resolution policy.
    """
    root = Path(temp_dir) / "release_unique_values"
    staged = root.with_name(f".{root.name}.{uuid.uuid4().hex}.tmp")
    if staged.exists():
        shutil.rmtree(staged)
    try:
        for year in years:
            year_int = int(year)
            part = staged / f"year={year_int}" / "part.parquet"
            log_phase("release unique values year start", year=year_int)
            atomic_copy_query_to_parquet(
                con,
                f"""
                SELECT UNITID, year, analysis_column,
                       MAX(normalized_value) AS normalized_value
                FROM release_all_values
                WHERE year = {year_int}
                GROUP BY 1, 2, 3
                ORDER BY UNITID, analysis_column
                """,
                part,
            )
            log_phase("release unique values year complete", year=year_int)
        if root.exists():
            shutil.rmtree(root)
        os.replace(staged, root)
    finally:
        if staged.exists():
            shutil.rmtree(staged)
    final_parts = [root / f"year={int(year)}" / "part.parquet" for year in years]
    files_sql = ", ".join(sql_quote(str(path)) for path in final_parts)
    con.execute(
        "CREATE OR REPLACE TEMP VIEW release_unique_values AS "
        f"SELECT * FROM read_parquet([{files_sql}], "
        "union_by_name=TRUE, hive_partitioning=FALSE)"
    )
    return final_parts


def _release_cast_diagnostics_query(
    source_table: str = "release_cast_inputs",
) -> str:
    """Return the row-preserving contract cast classification query."""
    return f"""
        SELECT
            m.UNITID,
            m.year,
            m.analysis_column,
            m.variable_id,
            m.source_file,
            m.source_row_id,
            m.raw_value,
            m.value,
            m.value_status,
            m.logical_type,
            CASE
                WHEN m.value_status IN ('missing', 'not_applicable', 'suppressed') THEN 'approved_null'
                WHEN m.normalized_value IS NULL THEN 'invalid'
                WHEN m.logical_type = 'integer' AND REGEXP_FULL_MATCH(m.normalized_value, '[+-]?[0-9]+')
                     AND TRY_CAST(m.normalized_value AS BIGINT) IS NOT NULL THEN 'parsed'
                WHEN m.logical_type = 'decimal' AND REGEXP_FULL_MATCH(m.normalized_value, '[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)')
                     AND TRY_CAST(m.normalized_value AS DECIMAL(38, 10)) IS NOT NULL THEN 'parsed'
                WHEN m.logical_type = 'float' AND TRY_CAST(m.normalized_value AS DOUBLE) IS NOT NULL
                     AND ISFINITE(TRY_CAST(m.normalized_value AS DOUBLE)) THEN 'parsed'
                WHEN m.logical_type = 'boolean' AND LOWER(m.normalized_value) IN ('1','0','true','false','yes','no','y','n') THEN 'parsed'
                WHEN m.logical_type IN ('categorical string', 'free text', 'identifier string') THEN 'parsed'
                ELSE 'invalid'
            END AS cast_status,
            CASE
                WHEN m.value_status IN ('missing', 'not_applicable', 'suppressed')
                    THEN 'upstream_value_status:' || m.value_status
                WHEN m.normalized_value IS NULL THEN 'reported_or_imputed_value_is_null'
                WHEN m.logical_type = 'integer' AND (
                    NOT REGEXP_FULL_MATCH(m.normalized_value, '[+-]?[0-9]+')
                    OR TRY_CAST(m.normalized_value AS BIGINT) IS NULL
                ) THEN 'invalid_integer_token_or_range'
                WHEN m.logical_type = 'decimal' AND TRY_CAST(m.normalized_value AS DECIMAL(38, 10)) IS NULL THEN 'invalid_decimal_token'
                WHEN m.logical_type = 'float' AND (TRY_CAST(m.normalized_value AS DOUBLE) IS NULL OR NOT ISFINITE(TRY_CAST(m.normalized_value AS DOUBLE))) THEN 'invalid_float_token'
                WHEN m.logical_type = 'boolean' AND LOWER(m.normalized_value) NOT IN ('1','0','true','false','yes','no','y','n') THEN 'invalid_boolean_token'
                ELSE 'contract_type_parse'
            END AS cast_reason
        FROM {source_table} m
    """


def _materialize_release_cast_summary(con) -> int:
    """Keep row diagnostics lazy and materialize only their tiny summary."""
    con.execute(
        "CREATE OR REPLACE TEMP VIEW release_cast_diagnostics AS "
        + _release_cast_diagnostics_query()
    )
    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE release_cast_summary AS
        SELECT logical_type, value_status, cast_status, cast_reason,
               COUNT(*) AS rows
        FROM release_cast_diagnostics
        GROUP BY 1, 2, 3, 4
        """
    )
    return scalar_int(
        con,
        """
        SELECT COALESCE(SUM(rows), 0)
        FROM release_cast_summary
        WHERE cast_status = 'invalid'
        """,
    )


def _materialize_release_spine(con, *, years: list[int]) -> None:
    """Build the institution-year spine one year at a time."""
    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE release_spine (
            UNITID BIGINT,
            year INTEGER
        )
        """
    )
    for year in years:
        year_int = int(year)
        log_phase("release spine year start", year=year_int)
        con.execute(
            f"""
            INSERT INTO release_spine
            SELECT DISTINCT UNITID, year
            FROM release_scalar
            WHERE year = {year_int}
            """
        )
        log_phase("release spine year complete", year=year_int)


def _materialize_release_conflict_keys(con, *, years: list[int]) -> int:
    """Evaluate final value conflicts independently by year."""
    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE release_conflict_keys (
            UNITID BIGINT,
            year INTEGER,
            analysis_column VARCHAR,
            distinct_values BIGINT
        )
        """
    )
    for year in years:
        year_int = int(year)
        log_phase("release final conflict year start", year=year_int)
        con.execute(
            f"""
            INSERT INTO release_conflict_keys
            SELECT UNITID, year, analysis_column, COUNT(*) AS distinct_values
            FROM (
                SELECT DISTINCT UNITID, year, analysis_column, normalized_value
                FROM release_all_values
                WHERE year = {year_int}
            ) distinct_values
            GROUP BY 1, 2, 3
            HAVING COUNT(*) > 1
            """
        )
        log_phase("release final conflict year complete", year=year_int)
    return scalar_int(con, "SELECT COUNT(*) FROM release_conflict_keys")


def _write_release_wide_outputs(
    con,
    *,
    years: list[int],
    analysis_df: pd.DataFrame,
    out_dir: str | Path,
    combined_path: str | Path,
    row_group_size: int | None,
) -> list[Path]:
    """Pivot, sort, and write the frozen release schema one year at a time."""
    select_exprs = ["s.year", "s.UNITID"]
    for row in analysis_df.to_dict("records"):
        column = str(row["analysis_column"])
        value_expr = _release_cast_case(str(row["logical_type"]))
        select_exprs.append(
            f"MAX(CASE WHEN v.analysis_column = {sql_quote(column)} "
            f"THEN {value_expr} END) AS {quote_ident(column)}"
        )
    parts: list[Path] = []
    for year in years:
        year_int = int(year)
        part = Path(out_dir) / f"year={year_int}" / "part.parquet"
        log_phase("release wide pivot year start", year=year_int)
        atomic_copy_query_to_parquet(
            con,
            f"""
            SELECT {', '.join(select_exprs)}
            FROM (
                SELECT UNITID, year
                FROM release_spine
                WHERE year = {year_int}
            ) s
            LEFT JOIN release_unique_values v USING (UNITID, year)
            GROUP BY s.year, s.UNITID
            ORDER BY s.UNITID
            """,
            part,
            row_group_size=row_group_size,
        )
        parts.append(part)
        log_phase("release wide pivot year complete", year=year_int)
    log_phase("release wide concatenation start", years=len(years))
    stitch_parquet_files_bounded(
        parts,
        combined_path,
        batch_rows=int(row_group_size or 65_536),
    )
    log_phase("release wide concatenation complete", years=len(years))
    return parts


def _write_release_lineage_outputs(
    con,
    *,
    lineage_query: str,
    years: list[int],
    temp_dir: str | Path,
    combined_path: str | Path,
    batch_rows: int = 65_536,
) -> tuple[int, list[Path]]:
    """Sort lineage by a total key per year and concatenate it boundedly."""
    root = Path(temp_dir) / "release_lineage"
    staged = root.with_name(f".{root.name}.{uuid.uuid4().hex}.tmp")
    if staged.exists():
        shutil.rmtree(staged)
    order_by = """
        year, UNITID, analysis_column, source_file, source_row_id,
        variable_id, source_varnumber, varname, access_table_name,
        transformation_id, lineage_role, source_row_hash, value_status,
        raw_value, normalized_value, output_normalized_value, contract_id
    """
    total_rows = 0
    try:
        for year in years:
            year_int = int(year)
            part = staged / f"year={year_int}" / "part.parquet"
            log_phase("release lineage year start", year=year_int)
            total_rows += atomic_copy_query_to_parquet(
                con,
                f"""
                SELECT *
                FROM ({lineage_query}) q
                WHERE year = {year_int}
                ORDER BY {order_by}
                """,
                part,
            )
            log_phase("release lineage year complete", year=year_int)
        if root.exists():
            shutil.rmtree(root)
        os.replace(staged, root)
    finally:
        if staged.exists():
            shutil.rmtree(staged)
    final_parts = [root / f"year={int(year)}" / "part.parquet" for year in years]
    log_phase("release lineage concatenation start", years=len(years))
    stitch_parquet_files_bounded(
        final_parts,
        combined_path,
        batch_rows=int(batch_rows),
    )
    log_phase(
        "release lineage concatenation complete",
        years=len(years),
        rows=total_rows,
    )
    return total_rows, final_parts


def _bounded_duplicate_lineage_sample(
    con,
    *,
    lineage_query: str,
    years: list[int],
    output_path: str | Path,
    limit: int,
) -> int:
    """Check lineage-key duplicates per year and retain one global sample."""
    if not years:
        raise ValueError("duplicate-lineage validation requires at least one year")
    target = Path(output_path)
    sample_relation = f"release_duplicate_lineage_sample_{uuid.uuid4().hex}"
    sample_ident = quote_ident(sample_relation)
    sample_created = False
    total_count = 0
    remaining = int(limit)
    order_by = "year, UNITID, analysis_column, variable_id, source_row_id"
    try:
        for year in sorted(int(value) for value in years):
            cache_path = target.with_name(
                f".{target.stem}.{year}.{uuid.uuid4().hex}.failure_rows.parquet"
            )
            year_query = f"""
                SELECT UNITID, year, analysis_column, variable_id, source_row_id,
                       COUNT(*) AS rows
                FROM ({lineage_query}) q
                WHERE year = {year}
                GROUP BY 1, 2, 3, 4, 5
                HAVING COUNT(*) > 1
            """
            log_phase("release duplicate lineage year start", year=year)
            year_count = 0
            try:
                year_count = atomic_copy_query_to_parquet(
                    con,
                    year_query,
                    cache_path,
                )
                total_count += year_count
                if not sample_created:
                    con.execute(
                        f"CREATE TEMP TABLE {sample_ident} AS "
                        "SELECT * FROM read_parquet("
                        f"{sql_quote(str(cache_path))}, hive_partitioning=FALSE) "
                        "WHERE FALSE"
                    )
                    sample_created = True
                if year_count and remaining > 0:
                    con.execute(
                        f"INSERT INTO {sample_ident} "
                        "SELECT * FROM read_parquet("
                        f"{sql_quote(str(cache_path))}, hive_partitioning=FALSE) "
                        f"ORDER BY {order_by} LIMIT {remaining}"
                    )
                    remaining -= min(year_count, remaining)
            finally:
                if cache_path.exists():
                    cache_path.unlink()
            log_phase(
                "release duplicate lineage year complete",
                year=year,
                failures=year_count,
            )
        atomic_copy_query_to_csv(
            con,
            f"SELECT * FROM {sample_ident} ORDER BY {order_by}",
            target,
        )
    finally:
        if sample_created:
            con.execute(f"DROP TABLE IF EXISTS {sample_ident}")
    if total_count:
        _write_release_csv(
            target.with_name(f"{target.stem}_summary.csv"),
            pd.DataFrame(
                [
                    {
                        "total_failure_rows": total_count,
                        "sample_rows_written": min(total_count, int(limit)),
                        "sample_truncated": total_count > int(limit),
                    }
                ]
            ),
        )
    return total_count


def _validate_release_schema_links(analysis_df: pd.DataFrame, discrete_df: pd.DataFrame) -> None:
    analysis_lookup = {str(row["analysis_column"]): row for row in analysis_df.to_dict("records")}
    direct_varnames: set[str] = set()
    for row in analysis_df.to_dict("records"):
        if str(row["transformation"]).strip().lower() not in DIRECT_TRANSFORMATIONS:
            continue
        for source in row["source_variables_parsed"]:
            token = str(source).strip()
            if token.lower().startswith("varname:"):
                token = token.split(":", 1)[1]
            elif token.lower().startswith("variable_id:"):
                token = token.rsplit(":", 1)[-1]
            direct_varnames.add(token.upper())
    family_outputs = discrete_df[discrete_df["output_column"] != ""].drop_duplicates(
        ["source_file", "family_id", "output_column"]
    )
    output_families: dict[str, set[tuple[str, str]]] = {}
    for row in family_outputs.to_dict("records"):
        output = str(row["output_column"])
        output_families.setdefault(output, set()).add(
            (str(row["source_file"]), str(row["family_id"]))
        )
        schema_row = analysis_lookup.get(output)
        if schema_row is None:
            raise WideContractError(
                f"discrete output {row['source_file']}/{row['family_id']} -> {output} is absent from analysis schema"
            )
        expected = f"discrete:{row['family_id']}".lower()
        if str(schema_row["transformation"]).strip().lower() != expected:
            raise WideContractError(
                f"analysis column {output} must declare transformation {expected}"
            )
        if str(schema_row["logical_type"]) != str(row["output_type"]):
            raise WideContractError(f"discrete output {output} logical type disagrees with its family contract")
        expected_sources = {
            str(value).upper()
            for value in discrete_df.loc[
                (discrete_df["source_file"] == row["source_file"])
                & (discrete_df["family_id"] == row["family_id"]),
                "component_varname",
            ].tolist()
        }
        schema_sources: set[str] = set()
        for value in schema_row["source_variables_parsed"]:
            token = str(value)
            if token.lower().startswith("variable_id:"):
                token = token.rsplit(":", 1)[-1]
            elif token.lower().startswith("varname:"):
                token = token.split(":", 1)[1]
            schema_sources.add(token.upper())
        if schema_sources != expected_sources:
            raise WideContractError(
                f"discrete output {output} source_variables do not exactly match reviewed family components"
            )
    reused_outputs = {
        output: sorted(families)
        for output, families in output_families.items()
        if len(families) > 1
    }
    if reused_outputs:
        raise WideContractError(f"discrete output columns are reused across different families: {reused_outputs}")
    for row in analysis_df.to_dict("records"):
        transformation = str(row["transformation"]).strip().lower()
        if transformation in DIRECT_TRANSFORMATIONS:
            continue
        family_id = transformation.removeprefix(DISCRETE_TRANSFORMATION_PREFIX).upper()
        linked = {
            (str(item["source_file"]), str(item["family_id"]))
            for item in family_outputs.to_dict("records")
            if str(item["output_column"]) == str(row["analysis_column"])
            and str(item["family_id"]).upper() == family_id
        }
        if len(linked) != 1:
            raise WideContractError(
                f"derived analysis transformation {transformation} for {row['analysis_column']} "
                f"must link to exactly one reviewed discrete family; linked={sorted(linked)}"
            )
    for row in discrete_df.to_dict("records"):
        must_preserve = (
            str(row["semantic_type"]) in {"multi_select", "ordinal_components", "not_collapsible"}
            or not bool(row["drop_components_bool"])
        )
        component = str(row["component_varname"])
        if must_preserve and component not in direct_varnames:
            raise WideContractError(
                f"discrete component {row['source_file']}/{component} must remain an explicit analysis column"
            )
        if bool(row["drop_components_bool"]) and str(row["semantic_type"]) != "one_hot":
            raise WideContractError("only a validated one_hot derivation may drop component columns")


def _release_coverage_files(path_value: str | None, years: list[int]) -> list[Path]:
    if not path_value:
        raise SystemExit("release mode requires --source-column-coverage from Stage 04")
    path = Path(path_value)
    if path.is_dir():
        files = sorted(path.glob("source_column_coverage_*.csv"))
    elif any(char in str(path) for char in "*?["):
        files = sorted(path.parent.glob(path.name))
    elif path.is_file():
        files = [path]
    else:
        files = []
    if not files:
        raise SystemExit(f"release source-column coverage inventory is missing: {path_value}")
    expected = set(years)
    seen: set[int] = set()
    required = {
        "year",
        "source_file",
        "access_table_name",
        "column_name",
        "role",
        "reviewed",
        "nonempty_tokens",
        "resolution",
    }
    for file in files:
        columns = set(pd.read_csv(file, nrows=0).columns)
        missing = sorted(required - columns)
        if missing:
            raise SystemExit(f"source-column coverage file {file} is missing fields: {missing}")
        match = re.search(r"source_column_coverage_(\d{4})[.]csv$", file.name)
        if match:
            seen.add(int(match.group(1)))
    if seen and not expected.issubset(seen):
        raise SystemExit(
            f"source-column coverage inventory lacks requested years: {sorted(expected - seen)}"
        )
    return files


def _validate_release_inventory_schemas(args, runtime: WideBuildRuntime) -> list[Path]:
    if not args.dictionary:
        raise SystemExit("release mode requires --dictionary as the reviewed discovery inventory")
    dictionary_path = Path(args.dictionary)
    if not dictionary_path.is_file():
        raise SystemExit(f"release dictionary/discovery inventory is missing: {dictionary_path}")
    if not args.dimensioned_input:
        raise SystemExit("release mode requires --dimensioned-input from Stage 05")
    dimensioned_path = Path(args.dimensioned_input)
    if not dimensioned_path.is_file():
        raise SystemExit(f"release dimensioned-long artifact is missing: {dimensioned_path}")
    return _release_coverage_files(args.source_column_coverage, runtime.years)


def _bind_and_validate_release_parquet(
    con,
    *,
    relation: str,
    path: str | Path,
    required: set[str],
    error_prefix: str,
) -> None:
    """Bind a release Parquet once and validate the cached raw-view schema."""
    con.execute(
        f"CREATE OR REPLACE TEMP VIEW {quote_ident(relation)} AS "
        f"SELECT * FROM read_parquet({sql_quote(str(path))}, "
        "hive_partitioning=FALSE)"
    )
    rows = con.execute(f"DESCRIBE {quote_ident(relation)}").fetchall()
    columns = {str(row[0]) for row in rows}
    missing = sorted(required - columns)
    if missing:
        raise SystemExit(f"{error_prefix}: {missing}")


def _build_release_discrete_values(
    con,
    *,
    discrete_df: pd.DataFrame,
    qc_dir: Path,
    failure_sample_rows: int,
) -> None:
    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE release_derived_values (
            UNITID BIGINT,
            year INTEGER,
            analysis_column VARCHAR,
            normalized_value VARCHAR,
            value_status VARCHAR,
            transformation VARCHAR
        )
        """
    )
    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE release_discrete_observed AS
        WITH observed AS (
            SELECT
                s.*,
                d.family_id,
                d.component_code,
                d.semantic_type,
                d.output_column,
                d.output_type,
                d.multi_active_policy,
                d.drop_components_bool,
                CASE
                    WHEN COALESCE(TRIM(CAST(s.raw_value AS VARCHAR)), '') = '' THEN '<blank>'
                    ELSE LOWER(TRIM(CAST(s.raw_value AS VARCHAR)))
                END AS contract_token
            FROM release_scalar s
            INNER JOIN stage.discrete_contract d
              ON UPPER(s.source_file) = d.source_file
             AND UPPER(s.varname) = d.component_varname
             AND d.semantic_type IN ('one_hot', 'multi_select')
        )
        SELECT o.*, t.token_class
        FROM observed o
        LEFT JOIN stage.discrete_tokens t
          ON UPPER(o.source_file) = t.source_file
         AND o.family_id = t.family_id
         AND UPPER(o.varname) = t.component_varname
         AND o.contract_token = t.token
        """
    )
    unknown_query = """
        SELECT UNITID, year, source_file, family_id, varname AS component_varname,
               raw_value, value_status, contract_token
        FROM release_discrete_observed
        WHERE token_class IS NULL
    """
    unknown_count = _bounded_failure_sample(
        con,
        count_query=unknown_query,
        sample_order_by="year, UNITID, source_file, family_id, component_varname",
        output_path=qc_dir / "qc_unknown_discrete_tokens.csv",
        limit=failure_sample_rows,
    )
    if unknown_count:
        raise SystemExit(f"unknown discrete token gate failed: rows={unknown_count}")

    component_conflict_query = """
        SELECT UNITID, year, source_file, family_id, varname AS component_varname,
               COUNT(DISTINCT token_class || ':' || contract_token) AS distinct_tokens
        FROM release_discrete_observed
        GROUP BY 1, 2, 3, 4, 5
        HAVING COUNT(DISTINCT token_class || ':' || contract_token) > 1
    """
    component_conflict_count = _bounded_failure_sample(
        con,
        count_query=component_conflict_query,
        sample_order_by="year, UNITID, source_file, family_id, component_varname",
        output_path=qc_dir / "qc_discrete_component_conflicts.csv",
        limit=failure_sample_rows,
    )
    if component_conflict_count:
        raise SystemExit(
            f"discrete component uniqueness gate failed: groups={component_conflict_count}"
        )

    family_rows = discrete_df.drop_duplicates(["source_file", "family_id"]).to_dict("records")
    for family in family_rows:
        source = sql_quote(str(family["source_file"]))
        family_id = sql_quote(str(family["family_id"]))
        output = str(family["output_column"])
        semantic = str(family["semantic_type"])
        if semantic in {"not_collapsible", "ordinal_components"} or not output:
            continue
        zero_value = str(family.get("zero_active_value", ""))
        zero_value_sql = sql_quote(zero_value) if zero_value else "NULL"
        active_summary = f"""
            WITH components AS (
                SELECT DISTINCT UNITID, year, component_code, token_class
                FROM release_discrete_observed
                WHERE UPPER(source_file) = {source}
                  AND family_id = {family_id}
            )
            SELECT
                UNITID,
                year,
                COUNT(*) FILTER (WHERE token_class = 'active') AS n_active,
                STRING_AGG(component_code, '|' ORDER BY component_code)
                    FILTER (WHERE token_class = 'active') AS active_codes
            FROM components
            GROUP BY UNITID, year
        """
        if semantic == "one_hot" and str(family["multi_active_policy"]) == "error":
            multi_query = f"""
                SELECT UNITID, year,
                       {source} AS source_file,
                       {family_id} AS family_id,
                       n_active, active_codes
                FROM ({active_summary}) q
                WHERE n_active > 1
            """
            multi_count = _bounded_failure_sample(
                con,
                count_query=multi_query,
                sample_order_by="year, UNITID",
                output_path=qc_dir / "qc_discrete_conflicts.csv",
                limit=failure_sample_rows,
            )
            if multi_count:
                raise SystemExit(f"one-hot multi-active gate failed: groups={multi_count}")
        if semantic == "one_hot" and bool(family["drop_components_bool"]):
            expected_components = int(
                discrete_df.loc[
                    (discrete_df["source_file"] == family["source_file"])
                    & (discrete_df["family_id"] == family["family_id"]),
                    "component_varname",
                ].nunique()
            )
            reversibility_query = f"""
                SELECT UNITID, year,
                       {source} AS source_file,
                       {family_id} AS family_id,
                       COUNT(DISTINCT varname) AS observed_components,
                       COUNT(*) FILTER (WHERE token_class = 'missing') AS missing_components
                FROM release_discrete_observed
                WHERE UPPER(source_file) = {source}
                  AND family_id = {family_id}
                GROUP BY UNITID, year
                HAVING COUNT(DISTINCT varname) <> {expected_components}
                    OR COUNT(*) FILTER (WHERE token_class = 'missing') > 0
            """
            reversibility_count = _bounded_failure_sample(
                con,
                count_query=reversibility_query,
                sample_order_by="year, UNITID",
                output_path=qc_dir / "qc_irreversible_discrete_derivations.csv",
                limit=failure_sample_rows,
            )
            if reversibility_count:
                raise SystemExit(
                    "discrete component drop reversibility gate failed: "
                    f"groups={reversibility_count}"
                )
        con.execute(
            f"""
            INSERT INTO release_derived_values
            SELECT
                UNITID,
                year,
                {sql_quote(output)} AS analysis_column,
                CASE
                    WHEN n_active = 0 THEN {zero_value_sql}
                    ELSE active_codes
                END AS normalized_value,
                CASE WHEN n_active = 0 AND {zero_value_sql} IS NULL THEN 'missing' ELSE 'reported' END AS value_status,
                {sql_quote('discrete:' + str(family['family_id']))} AS transformation
            FROM ({active_summary}) q
            INNER JOIN stage.analysis_contract c
              ON c.analysis_column = {sql_quote(output)}
             AND q.year BETWEEN c.first_year_int AND c.last_year_int
            """
        )

    # Some reviewed contracts legitimately have no collapsible one-hot family.
    # Publish the two conditional gate ledgers anyway so a successful release
    # proves that their absence of rows is intentional rather than a missing
    # execution artifact.
    conditional_ledgers = {
        "qc_discrete_conflicts.csv": [
            "UNITID",
            "year",
            "source_file",
            "family_id",
            "n_active",
            "active_codes",
        ],
        "qc_irreversible_discrete_derivations.csv": [
            "UNITID",
            "year",
            "source_file",
            "family_id",
            "observed_components",
            "missing_components",
        ],
    }
    for name, columns in conditional_ledgers.items():
        path = qc_dir / name
        if not path.exists():
            _write_release_csv(path, pd.DataFrame(columns=columns))


def _run_release_bundle_member(args, runtime: WideBuildRuntime) -> None:
    """Build the canonical wide artifact only from reviewed v2 scalar input."""
    if args.lane_split:
        raise SystemExit("release mode rejects source-prefix lane inference; consume the v2 scalar artifact directly")
    if args.drop_empty_cols or args.drop_globally_null_post:
        raise SystemExit("release mode forbids dynamic null-column dropping from the frozen analysis schema")
    if args.legacy_analysis_schema:
        raise SystemExit("legacy compatibility columns require a separate development artifact")
    if args.exclude_vars:
        raise SystemExit("release mode forbids CLI column exclusions; govern them in analysis_schema.csv")
    if args.drop_disc_components:
        raise SystemExit("release mode rejects CLI discrete component drops; use the reviewed semantic contract")

    try:
        governed_analysis_df = load_analysis_schema_contract(
            args.analysis_schema_contract
        )
        analysis_df = governed_analysis_df[
            governed_analysis_df["status"].isin(["approved", "active"])
        ].copy()
        if analysis_df.empty:
            raise WideContractError(
                "analysis schema contract has no included release columns"
            )
        discrete_df = load_discrete_family_contract(args.discrete_family_contract)
        _validate_release_schema_links(analysis_df, discrete_df)
    except WideContractError as exc:
        raise SystemExit(str(exc)) from exc

    scalar_path = Path(args.input)
    if not scalar_path.is_file():
        raise SystemExit(f"release scalar-long artifact is missing: {scalar_path}")
    coverage_files = _validate_release_inventory_schemas(args, runtime)

    qc_dir = Path(args.qc_dir) if args.qc_dir else runtime.repo_root / "Checks" / "v2" / "wide_qc"
    qc_dir.mkdir(parents=True, exist_ok=True)
    lineage_path = Path(
        args.value_lineage_out
        or args.column_lineage_out
        or qc_dir / "qc_value_lineage.parquet"
    )
    if lineage_path.suffix.lower() != ".parquet":
        raise SystemExit("release value lineage must be written as parquet")
    candidate_path = Path(args.analysis_candidates_out or qc_dir / "qc_analysis_schema_candidates.csv")
    lane_path = Path(args.lane_coverage_out or qc_dir / "qc_lane_coverage.csv")
    cast_path = Path(args.cast_report_out or qc_dir / "qc_cast_diagnostics.csv")
    work_dir = Path(getattr(args, "release_work_dir", args.duckdb_temp_dir))

    con, effective_db_path = open_build_connection(
        args.duckdb_path,
        args.duckdb_temp_dir,
        args.persist_duckdb,
        memory_limit=args.duckdb_memory_limit,
        threads=args.duckdb_threads,
        preserve_insertion_order=False,
    )
    bootstrap_build_db(con)
    print(f"[info] DuckDB release build state: {effective_db_path}", flush=True)
    _register_release_contracts(con, governed_analysis_df, discrete_df)
    log_phase("release parquet schema validation start")
    _bind_and_validate_release_parquet(
        con,
        relation="release_scalar_raw",
        path=scalar_path,
        required=RELEASE_REQUIRED_SCALAR_COLUMNS,
        error_prefix="release scalar input is missing v2 columns",
    )
    _bind_and_validate_release_parquet(
        con,
        relation="release_dictionary_raw",
        path=args.dictionary,
        required={
            "year",
            "variable_id",
            "source_varnumber",
            "varname",
            "source_file",
            "access_table_name",
            "DataType",
            "format",
            "metadata_source",
        },
        error_prefix=(
            "release dictionary/discovery inventory lacks reviewed identity fields"
        ),
    )
    _bind_and_validate_release_parquet(
        con,
        relation="release_dimensioned_raw",
        path=args.dimensioned_input,
        required=RELEASE_REQUIRED_SCALAR_COLUMNS
        | {"dimension_key", "dimension_json"},
        error_prefix="release dimensioned input is missing v2 columns",
    )
    log_phase("release parquet schema validation complete")
    years_sql = ", ".join(str(year) for year in runtime.years)
    coverage_sql = ", ".join(sql_quote(str(path)) for path in coverage_files)
    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW release_dictionary AS
        SELECT
            TRY_CAST(year AS INTEGER) AS year,
            TRIM(CAST(variable_id AS VARCHAR)) AS variable_id,
            TRIM(CAST(source_varnumber AS VARCHAR)) AS source_varnumber,
            UPPER(TRIM(CAST(varname AS VARCHAR))) AS varname,
            UPPER(TRIM(CAST(source_file AS VARCHAR))) AS source_file,
            TRIM(CAST(access_table_name AS VARCHAR)) AS access_table_name,
            LOWER(TRIM(CAST(DataType AS VARCHAR))) AS data_type,
            LOWER(TRIM(CAST(format AS VARCHAR))) AS data_format,
            TRIM(CAST(metadata_source AS VARCHAR)) AS metadata_source
        FROM release_dictionary_raw
        WHERE TRY_CAST(year AS INTEGER) IN ({years_sql});

        CREATE OR REPLACE TEMP VIEW release_dimensioned AS
        SELECT
            TRY_CAST(UNITID AS BIGINT) AS UNITID,
            TRY_CAST(year AS INTEGER) AS year,
            TRIM(CAST(contract_id AS VARCHAR)) AS contract_id,
            TRIM(CAST(variable_id AS VARCHAR)) AS variable_id,
            TRIM(CAST(source_varnumber AS VARCHAR)) AS source_varnumber,
            UPPER(TRIM(CAST(varname AS VARCHAR))) AS varname,
            UPPER(TRIM(CAST(source_file AS VARCHAR))) AS source_file,
            TRIM(CAST(access_table_name AS VARCHAR)) AS access_table_name,
            LOWER(TRIM(CAST(lane AS VARCHAR))) AS lane,
            TRIM(CAST(source_row_id AS VARCHAR)) AS source_row_id,
            TRIM(CAST(source_row_hash AS VARCHAR)) AS source_row_hash,
            TRIM(CAST(dimension_key AS VARCHAR)) AS dimension_key,
            TRIM(CAST(dimension_json AS VARCHAR)) AS dimension_json
        FROM release_dimensioned_raw
        WHERE TRY_CAST(year AS INTEGER) IN ({years_sql});

        CREATE OR REPLACE TEMP TABLE release_source_coverage AS
        SELECT
            TRY_CAST(year AS INTEGER) AS year,
            UPPER(TRIM(CAST(source_file AS VARCHAR))) AS source_file,
            TRIM(CAST(access_table_name AS VARCHAR)) AS access_table_name,
            UPPER(TRIM(CAST(column_name AS VARCHAR))) AS column_name,
            LOWER(TRIM(CAST(role AS VARCHAR))) AS role,
            LOWER(TRIM(CAST(reviewed AS VARCHAR))) AS reviewed,
            TRY_CAST(nonempty_tokens AS BIGINT) AS nonempty_tokens,
            LOWER(TRIM(CAST(resolution AS VARCHAR))) AS resolution
        FROM read_csv_auto([{coverage_sql}], header=TRUE, union_by_name=TRUE, all_varchar=TRUE)
        WHERE TRY_CAST(year AS INTEGER) IN ({years_sql});
        """
    )
    null_status_sql = ", ".join(sql_quote(status) for status in sorted(RELEASE_NULL_STATUSES))
    con.execute(
        f"""
        CREATE OR REPLACE TEMP VIEW release_scalar AS
        SELECT
            TRY_CAST(UNITID AS BIGINT) AS UNITID,
            TRY_CAST(year AS INTEGER) AS year,
            TRIM(CAST(contract_id AS VARCHAR)) AS contract_id,
            TRIM(CAST(variable_id AS VARCHAR)) AS variable_id,
            TRIM(CAST(source_varnumber AS VARCHAR)) AS source_varnumber,
            UPPER(TRIM(CAST(varname AS VARCHAR))) AS varname,
            CAST(value AS VARCHAR) AS value,
            CAST(raw_value AS VARCHAR) AS raw_value,
            REPLACE(REPLACE(REPLACE(LOWER(TRIM(CAST(value_status AS VARCHAR))), ' ', '_'), '-', '_'), '/', '_') AS value_status,
            UPPER(TRIM(CAST(source_file AS VARCHAR))) AS source_file,
            TRIM(CAST(access_table_name AS VARCHAR)) AS access_table_name,
            LOWER(TRIM(CAST(lane AS VARCHAR))) AS lane,
            TRIM(CAST(source_row_id AS VARCHAR)) AS source_row_id,
            TRIM(CAST(source_row_hash AS VARCHAR)) AS source_row_hash,
            CASE
                WHEN REPLACE(REPLACE(REPLACE(LOWER(TRIM(CAST(value_status AS VARCHAR))), ' ', '_'), '-', '_'), '/', '_') IN ({null_status_sql}) THEN NULL
                WHEN value IS NULL THEN NULL
                WHEN TRIM(CAST(value AS VARCHAR)) = '' THEN NULL
                ELSE TRIM(CAST(value AS VARCHAR))
            END AS normalized_value
        FROM release_scalar_raw
        WHERE TRY_CAST(year AS INTEGER) IN ({years_sql})
        """
    )
    row_count = scalar_int(con, "SELECT COUNT(*) FROM release_scalar")
    if row_count == 0:
        raise SystemExit("release scalar input has no rows in the requested years")
    if scalar_int(con, "SELECT COUNT(*) FROM release_scalar WHERE UNITID IS NULL OR year IS NULL"):
        raise SystemExit("release scalar input contains invalid UNITID or year tokens")
    if scalar_int(con, f"SELECT COUNT(*) FROM release_scalar WHERE contract_id IS DISTINCT FROM {sql_quote(PANEL_CONTRACT_ID)}"):
        raise SystemExit("release scalar input contract_id does not match panel v2")
    if scalar_int(con, "SELECT COUNT(*) FROM release_scalar WHERE lane IS DISTINCT FROM 'scalar'"):
        raise SystemExit("release scalar input contains non-scalar lanes")
    if scalar_int(
        con,
        """
        SELECT COUNT(*) FROM release_scalar
        WHERE COALESCE(source_row_id, '') = ''
           OR COALESCE(source_row_hash, '') = ''
           OR COALESCE(variable_id, '') = ''
           OR COALESCE(source_varnumber, '') = ''
           OR COALESCE(varname, '') = ''
           OR COALESCE(source_file, '') = ''
           OR COALESCE(access_table_name, '') = ''
        """,
    ):
        raise SystemExit("release scalar input has blank scientific lineage identifiers")
    dimensioned_invalid = scalar_int(
        con,
        f"""
        SELECT COUNT(*) FROM release_dimensioned
        WHERE UNITID IS NULL OR year IS NULL
           OR contract_id IS DISTINCT FROM {sql_quote(PANEL_CONTRACT_ID)}
           OR lane IS DISTINCT FROM 'dimensioned'
           OR COALESCE(variable_id, '') = ''
           OR COALESCE(source_varnumber, '') = ''
           OR COALESCE(varname, '') = ''
           OR COALESCE(source_file, '') = ''
           OR COALESCE(access_table_name, '') = ''
           OR COALESCE(source_row_id, '') = ''
           OR COALESCE(source_row_hash, '') = ''
           OR COALESCE(dimension_key, '') = ''
           OR COALESCE(dimension_json, '') = ''
        """,
    )
    if dimensioned_invalid:
        raise SystemExit(
            f"release dimensioned input identity/lane gate failed: rows={dimensioned_invalid}"
        )
    inventory_problem_query = """
        SELECT year, source_file, access_table_name, column_name, role, reviewed,
               nonempty_tokens, resolution
        FROM release_source_coverage
        WHERE year IS NULL
           OR source_file = ''
           OR access_table_name = ''
           OR column_name = ''
           OR role = ''
           OR reviewed NOT IN ('true', '1', 'yes')
           OR resolution <> 'classified'
           OR nonempty_tokens IS NULL
           OR nonempty_tokens < 0
    """
    inventory_problem_count = _bounded_failure_sample(
        con,
        count_query=inventory_problem_query,
        sample_order_by="year, source_file, access_table_name, column_name",
        output_path=qc_dir / "qc_unreviewed_source_column_inventory.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if inventory_problem_count:
        raise SystemExit(
            "release source-column coverage is not a fully reviewed classification ledger: "
            f"rows={inventory_problem_count}"
        )
    coverage_years = {
        int(row[0])
        for row in con.execute(
            "SELECT DISTINCT year FROM release_source_coverage WHERE year IS NOT NULL"
        ).fetchall()
    }
    if coverage_years != set(runtime.years):
        raise SystemExit(
            "release source-column coverage year set does not match the requested build: "
            f"expected={runtime.years} actual={sorted(coverage_years)}"
        )
    duplicate_coverage_query = """
        SELECT year, source_file, access_table_name, column_name, COUNT(*) AS rows
        FROM release_source_coverage
        GROUP BY 1, 2, 3, 4
        HAVING COUNT(*) > 1
    """
    duplicate_coverage_count = _bounded_failure_sample(
        con,
        count_query=duplicate_coverage_query,
        sample_order_by="year, source_file, access_table_name, column_name",
        output_path=qc_dir / "qc_duplicate_source_column_inventory.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if duplicate_coverage_count:
        raise SystemExit(
            f"release source-column coverage repeats classification keys: rows={duplicate_coverage_count}"
        )
    missing_dictionary_query = build_missing_dictionary_query()
    missing_dictionary_count = _bounded_failure_sample(
        con,
        count_query=missing_dictionary_query,
        sample_order_by=MISSING_DICTIONARY_SAMPLE_ORDER_BY,
        output_path=qc_dir / "qc_missing_dictionary_inventory.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if missing_dictionary_count:
        raise SystemExit(
            "release dictionary/discovery inventory does not cover all Stage 05 cells: "
            f"identities={missing_dictionary_count}"
        )
    contradictory_discovery_query = """
        SELECT year, variable_id, source_file, varname,
               COUNT(DISTINCT (
                   data_type LIKE '%disc%'
                   OR data_type IN ('categorical', 'category')
                   OR data_format LIKE '%disc%'
                   OR data_format IN ('categorical', 'category')
               )) AS discovery_classes
        FROM release_dictionary
        GROUP BY 1, 2, 3, 4
        HAVING COUNT(DISTINCT (
                   data_type LIKE '%disc%'
                   OR data_type IN ('categorical', 'category')
                   OR data_format LIKE '%disc%'
                   OR data_format IN ('categorical', 'category')
               )) > 1
    """
    contradictory_discovery_count = _bounded_failure_sample(
        con,
        count_query=contradictory_discovery_query,
        sample_order_by="year, source_file, varname, variable_id",
        output_path=qc_dir / "qc_contradictory_dictionary_discovery.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if contradictory_discovery_count:
        raise SystemExit(
            "release dictionary has contradictory discovery classifications: "
            f"identities={contradictory_discovery_count}"
        )
    missing_coverage_query = """
        WITH cells AS (
            SELECT DISTINCT year, source_file, access_table_name, varname, 'scalar' AS lane
            FROM release_scalar
            UNION ALL
            SELECT DISTINCT year, source_file, access_table_name, varname, 'dimensioned' AS lane
            FROM release_dimensioned
        )
        SELECT c.*
        FROM cells c
        WHERE NOT EXISTS (
            SELECT 1 FROM release_source_coverage l
            WHERE l.year = c.year
              AND l.source_file = c.source_file
              AND l.access_table_name = c.access_table_name
              AND l.column_name = c.varname
              AND l.role = 'measure'
              AND l.reviewed IN ('true', '1', 'yes')
              AND l.resolution = 'classified'
        )
    """
    missing_coverage_count = _bounded_failure_sample(
        con,
        count_query=missing_coverage_query,
        sample_order_by="year, lane, source_file, access_table_name, varname",
        output_path=qc_dir / "qc_missing_stage04_classification.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if missing_coverage_count:
        raise SystemExit(
            "Stage 05 cells lack reviewed Stage 04 source-column classification: "
            f"variables={missing_coverage_count}"
        )
    allowed_status_sql = ", ".join(sql_quote(status) for status in sorted(RELEASE_ALLOWED_STATUSES))
    bad_status_query = (
        "SELECT DISTINCT COALESCE(value_status, '') AS value_status FROM release_scalar "
        f"WHERE COALESCE(value_status, '') NOT IN ({allowed_status_sql})"
    )
    bad_status_count = _bounded_failure_sample(
        con,
        count_query=bad_status_query,
        sample_order_by="value_status",
        output_path=qc_dir / "qc_unknown_value_statuses.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if bad_status_count:
        raise SystemExit(f"unknown value_status gate failed: statuses={bad_status_count}")
    invalid_status_rows = scalar_int(con, "SELECT COUNT(*) FROM release_scalar WHERE value_status = 'invalid_unresolved'")
    if invalid_status_rows:
        raise SystemExit(f"unresolved input value-status gate failed: rows={invalid_status_rows}")
    scalar_key_dupe_query = """
        SELECT UNITID, year, variable_id, source_file, COUNT(*) AS rows
        FROM release_scalar
        GROUP BY 1, 2, 3, 4
        HAVING COUNT(*) > 1
    """
    scalar_key_dupe_count = _bounded_failure_sample(
        con,
        count_query=scalar_key_dupe_query,
        sample_order_by="year, UNITID, variable_id, source_file",
        output_path=qc_dir / "qc_scalar_input_key_duplicates.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if scalar_key_dupe_count:
        raise SystemExit(f"v2 scalar input key gate failed: duplicates={scalar_key_dupe_count}")

    log_phase(
        "release direct mapping materialization start",
        years=len(runtime.years),
    )
    _materialize_release_direct_mapped(
        con,
        years=runtime.years,
        temp_dir=work_dir,
    )
    log_phase("release direct mapping materialization complete")
    ambiguous_map_count = _bounded_ambiguous_analysis_mapping_sample(
        con,
        years=runtime.years,
        output_path=qc_dir / "qc_ambiguous_analysis_mappings.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if ambiguous_map_count:
        raise SystemExit(
            f"ambiguous analysis-schema mapping gate failed: rows={ambiguous_map_count}"
        )

    con.execute(
        f"""
        CREATE OR REPLACE TABLE stage.analysis_candidate_years AS
        WITH variable_sources AS (
            SELECT
                year,
                variable_id,
                varname,
                source_file,
                COUNT(*) AS source_rows,
                COUNT(*) FILTER (WHERE normalized_value IS NOT NULL) AS non_null_rows
            FROM release_scalar
            GROUP BY year, variable_id, varname, source_file
        )
        SELECT
            s.*,
            CASE
                WHEN EXISTS (
                    SELECT 1 FROM stage.analysis_source_map m WHERE {_release_match_sql('s', 'm')}
                ) THEN 'analysis_schema'
                WHEN EXISTS (
                    SELECT 1
                    FROM stage.analysis_exclusion_map e
                    WHERE {_release_match_sql('s', 'e')}
                      AND s.year BETWEEN e.first_year AND e.last_year
                ) THEN 'analysis_schema_excluded'
                WHEN EXISTS (
                    SELECT 1 FROM stage.discrete_contract d
                    WHERE d.source_file = s.source_file AND d.component_varname = s.varname
                ) THEN 'discrete_contract'
                ELSE 'unclassified'
            END AS row_status
        FROM variable_sources s
        """
    )
    con.execute(
        """
        CREATE OR REPLACE TABLE stage.analysis_candidates AS
        SELECT
            variable_id,
            varname,
            STRING_AGG(DISTINCT source_file, '|' ORDER BY source_file) AS source_files,
            SUM(source_rows) AS source_rows,
            SUM(non_null_rows) AS non_null_rows,
            CASE
                WHEN BOOL_OR(row_status = 'unclassified') THEN 'unclassified'
                WHEN BOOL_OR(row_status = 'analysis_schema') THEN 'analysis_schema'
                WHEN BOOL_OR(row_status = 'analysis_schema_excluded')
                    THEN 'analysis_schema_excluded'
                WHEN BOOL_OR(row_status = 'discrete_contract') THEN 'discrete_contract'
                ELSE 'unclassified'
            END AS analysis_schema_status
        FROM stage.analysis_candidate_years
        GROUP BY variable_id, varname
        """
    )
    atomic_copy_query_to_csv(
        con,
        "SELECT * FROM stage.analysis_candidates ORDER BY varname, variable_id",
        candidate_path,
    )
    runtime_year_values = ", ".join(
        f"({int(year)})" for year in sorted(runtime.years)
    )
    con.execute(
        f"""
        CREATE OR REPLACE TABLE stage.analysis_exclusion_evidence AS
        WITH runtime_years(year) AS (
            VALUES {runtime_year_values}
        )
        SELECT
            e.analysis_column,
            e.status,
            e.exclusion_reason,
            e.match_type,
            e.match_value,
            e.first_year,
            e.last_year,
            y.year,
            COALESCE(SUM(s.source_rows), 0) AS eligible_rows,
            COALESCE(SUM(s.non_null_rows), 0) AS non_null_rows
        FROM stage.analysis_exclusion_map e
        INNER JOIN runtime_years y
          ON y.year BETWEEN e.first_year AND e.last_year
        LEFT JOIN stage.analysis_candidate_years s
          ON s.year = y.year
         AND {_release_match_sql('s', 'e')}
        GROUP BY
            e.analysis_column,
            e.status,
            e.exclusion_reason,
            e.match_type,
            e.match_value,
            e.first_year,
            e.last_year,
            y.year
        """
    )
    atomic_copy_query_to_csv(
        con,
        """
        SELECT * FROM stage.analysis_exclusion_evidence
        ORDER BY analysis_column, year, match_type, match_value
        """,
        qc_dir / "qc_analysis_schema_exclusions.csv",
    )
    missing_exclusion_evidence_count = scalar_int(
        con,
        """
        SELECT COUNT(*) FROM stage.analysis_exclusion_evidence
        WHERE eligible_rows = 0
        """,
    )
    non_null_exclusion_evidence_count = scalar_int(
        con,
        """
        SELECT COUNT(*) FROM stage.analysis_exclusion_evidence
        WHERE non_null_rows > 0
        """,
    )
    if missing_exclusion_evidence_count or non_null_exclusion_evidence_count:
        raise SystemExit(
            "analysis-schema exclusion evidence gate failed: "
            f"missing_years={missing_exclusion_evidence_count} "
            f"non_null_years={non_null_exclusion_evidence_count}"
        )
    unclassified_count = scalar_int(
        con,
        """
        SELECT COUNT(*) FROM stage.analysis_candidate_years
        WHERE row_status = 'unclassified'
        """,
    )
    if unclassified_count:
        raise SystemExit(f"release mode found unclassified variables: count={unclassified_count}")
    unknown_family_query = """
        SELECT DISTINCT s.year, s.source_file, s.varname AS component_varname,
               s.variable_id, 'unreviewed_discrete_family' AS status
        FROM release_scalar s
        WHERE EXISTS (
            SELECT 1 FROM release_dictionary d
            WHERE d.year = s.year
              AND d.variable_id = s.variable_id
              AND d.source_file = s.source_file
              AND d.varname = s.varname
              AND (
                   d.data_type LIKE '%disc%'
                   OR d.data_type IN ('categorical', 'category')
                   OR d.data_format LIKE '%disc%'
                   OR d.data_format IN ('categorical', 'category')
              )
        )
          AND NOT EXISTS (
            SELECT 1 FROM stage.discrete_contract d
            WHERE d.source_file = s.source_file AND d.component_varname = s.varname
        )
    """
    unknown_family_count = _bounded_failure_sample(
        con,
        count_query=unknown_family_query,
        sample_order_by="year, source_file, component_varname, variable_id",
        output_path=qc_dir / "qc_unknown_discrete_families.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if unknown_family_count:
        raise SystemExit(
            f"unknown discrete family gate failed: components={unknown_family_count}"
        )
    out_of_range = scalar_int(
        con,
        "SELECT COUNT(*) FROM release_direct_mapped WHERE year < first_year OR year > last_year",
    )
    if out_of_range:
        raise SystemExit(f"analysis schema year-range gate failed: rows={out_of_range}")

    _build_release_discrete_values(
        con,
        discrete_df=discrete_df,
        qc_dir=qc_dir,
        failure_sample_rows=int(args.release_failure_sample_rows),
    )
    atomic_copy_query_to_csv(
        con,
        """
        WITH families AS (
            SELECT DISTINCT source_file, family_id, semantic_type, output_column,
                   output_type, multi_active_policy, drop_components_bool,
                   zero_active_policy, source_evidence
            FROM stage.discrete_contract
        ), observed AS (
            SELECT source_file, family_id,
                   COUNT(*) AS observed_component_rows,
                   COUNT(DISTINCT (UNITID, year)) AS observed_institution_years,
                   COUNT(*) FILTER (WHERE token_class = 'active') AS active_component_rows,
                   COUNT(*) FILTER (WHERE token_class = 'inactive') AS inactive_component_rows,
                   COUNT(*) FILTER (WHERE token_class = 'missing') AS missing_component_rows
            FROM release_discrete_observed
            GROUP BY 1, 2
        ), derived AS (
            SELECT transformation, COUNT(*) AS derived_output_rows,
                   COUNT(normalized_value) AS non_null_derived_output_rows
            FROM release_derived_values
            GROUP BY 1
        )
        SELECT
            f.*,
            COALESCE(o.observed_component_rows, 0) AS observed_component_rows,
            COALESCE(o.observed_institution_years, 0) AS observed_institution_years,
            COALESCE(o.active_component_rows, 0) AS active_component_rows,
            COALESCE(o.inactive_component_rows, 0) AS inactive_component_rows,
            COALESCE(o.missing_component_rows, 0) AS missing_component_rows,
            COALESCE(d.derived_output_rows, 0) AS derived_output_rows,
            COALESCE(d.non_null_derived_output_rows, 0) AS non_null_derived_output_rows
        FROM families f
        LEFT JOIN observed o USING (source_file, family_id)
        LEFT JOIN derived d
          ON d.transformation = 'discrete:' || f.family_id
        ORDER BY f.source_file, f.family_id
        """,
        Path(args.disc_qc_dir) / "semantic_discrete_family_summary.csv",
    )
    con.execute(
        """
        CREATE OR REPLACE TEMP VIEW release_all_values AS
        SELECT UNITID, year, analysis_column, normalized_value, value_status, transformation
        FROM release_direct_mapped
        UNION ALL
        SELECT UNITID, year, analysis_column, normalized_value, value_status, transformation
        FROM release_derived_values
        """
    )
    derived_out_of_range = scalar_int(
        con,
        """
        SELECT COUNT(*)
        FROM release_derived_values d
        INNER JOIN stage.analysis_contract c USING (analysis_column)
        WHERE d.year < c.first_year_int OR d.year > c.last_year_int
        """,
    )
    if derived_out_of_range:
        raise SystemExit(
            f"derived analysis-schema year-range gate failed: rows={derived_out_of_range}"
        )
    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE release_canonical_column_coverage AS
        SELECT
            c.analysis_column,
            c.transformation,
            c.first_year_int AS first_year,
            c.last_year_int AS last_year,
            COUNT(v.analysis_column) AS eligible_value_rows,
            COUNT(v.normalized_value) AS non_null_value_rows
        FROM stage.analysis_contract c
        LEFT JOIN release_all_values v
          ON v.analysis_column = c.analysis_column
         AND v.year BETWEEN c.first_year_int AND c.last_year_int
        GROUP BY 1, 2, 3, 4
        """
    )
    atomic_copy_query_to_csv(
        con,
        """
        SELECT * FROM release_canonical_column_coverage
        ORDER BY analysis_column
        """,
        qc_dir / "qc_canonical_column_coverage.csv",
    )
    no_eligible_columns = scalar_int(
        con,
        "SELECT COUNT(*) FROM release_canonical_column_coverage WHERE eligible_value_rows = 0",
    )
    all_null_columns = scalar_int(
        con,
        """
        SELECT COUNT(*) FROM release_canonical_column_coverage
        WHERE eligible_value_rows > 0 AND non_null_value_rows = 0
        """,
    )
    if no_eligible_columns or all_null_columns:
        raise SystemExit(
            "canonical analysis columns require eligible, non-null source evidence: "
            f"no_eligible={no_eligible_columns} all_null={all_null_columns}"
        )

    con.execute(
        """
        CREATE OR REPLACE TEMP TABLE release_lane_coverage AS
        WITH scalar_stats AS (
            SELECT year, source_file, access_table_name, varname, variable_id,
                   COUNT(*) AS scalar_rows
            FROM release_scalar
            GROUP BY 1, 2, 3, 4, 5
        ), dimensioned_stats AS (
            SELECT year, source_file, access_table_name, varname, variable_id,
                   COUNT(*) AS dimensioned_rows
            FROM release_dimensioned
            GROUP BY 1, 2, 3, 4, 5
        ), direct_stats AS (
            SELECT year, source_file, access_table_name, varname, variable_id,
                   COUNT(*) AS direct_output_rows
            FROM release_direct_mapped
            GROUP BY 1, 2, 3, 4, 5
        ), discrete_stats AS (
            SELECT year, source_file, access_table_name, varname, variable_id,
                   COUNT(*) AS discrete_component_rows
            FROM release_discrete_observed
            GROUP BY 1, 2, 3, 4, 5
        ), source_inventory AS (
            SELECT
                l.year,
                COALESCE(s.variable_id, d.variable_id, '') AS variable_id,
                l.column_name AS varname,
                l.source_file,
                l.access_table_name,
                l.role AS reviewed_role,
                l.reviewed,
                l.resolution,
                l.nonempty_tokens,
                COALESCE(e.status, '') AS analysis_exclusion_status,
                COALESCE(e.exclusion_reason, '') AS analysis_exclusion_reason,
                COALESCE(s.scalar_rows, 0) AS scalar_rows,
                COALESCE(d.dimensioned_rows, 0) AS dimensioned_rows,
                COALESCE(o.direct_output_rows, 0) AS direct_output_rows,
                COALESCE(x.discrete_component_rows, 0) AS discrete_component_rows
            FROM release_source_coverage l
            LEFT JOIN scalar_stats s
              ON s.year = l.year AND s.source_file = l.source_file
             AND s.access_table_name = l.access_table_name AND s.varname = l.column_name
            LEFT JOIN dimensioned_stats d
              ON d.year = l.year AND d.source_file = l.source_file
             AND d.access_table_name = l.access_table_name AND d.varname = l.column_name
            LEFT JOIN direct_stats o
              ON o.year = l.year AND o.source_file = l.source_file
             AND o.access_table_name = l.access_table_name AND o.varname = l.column_name
             AND o.variable_id = s.variable_id
            LEFT JOIN discrete_stats x
              ON x.year = l.year AND x.source_file = l.source_file
             AND x.access_table_name = l.access_table_name AND x.varname = l.column_name
             AND x.variable_id = s.variable_id
            LEFT JOIN stage.analysis_exclusion_map e
              ON l.year BETWEEN e.first_year AND e.last_year
             AND (
                    (e.match_type = 'variable_id'
                     AND COALESCE(s.variable_id, d.variable_id, '') = e.match_value)
                 OR (e.match_type = 'varname'
                     AND UPPER(l.column_name) = e.match_value_upper)
                 OR (e.match_type = 'auto' AND (
                        COALESCE(s.variable_id, d.variable_id, '') = e.match_value
                     OR UPPER(l.column_name) = e.match_value_upper
                 ))
             )
        )
        SELECT
            year, variable_id, varname, source_file, access_table_name,
            reviewed_role, reviewed, resolution, nonempty_tokens,
            scalar_rows, dimensioned_rows,
            CASE
                WHEN dimensioned_rows > 0 THEN dimensioned_rows
                WHEN direct_output_rows > 0 THEN direct_output_rows
                WHEN discrete_component_rows > 0 THEN discrete_component_rows
                ELSE 0
            END AS output_rows,
            CASE
                WHEN dimensioned_rows > 0 THEN 'dimensioned_long'
                WHEN direct_output_rows > 0 THEN 'analysis_wide'
                WHEN discrete_component_rows > 0 THEN 'semantic_discrete_processing'
                WHEN analysis_exclusion_status <> '' THEN 'excluded_by_analysis_schema'
                WHEN reviewed_role = 'dimension' THEN 'dimension_key_lineage'
                WHEN reviewed_role = 'identifier' THEN 'source_row_identity'
                WHEN reviewed_role IN ('excluded', 'metadata', 'imputation') THEN 'excluded_by_reviewed_role'
                ELSE 'no_output_cells'
            END AS output_destination,
            CASE
                WHEN reviewed_role IN ('excluded', 'metadata', 'imputation')
                    THEN 'reviewed_source_column_role:' || reviewed_role
                WHEN analysis_exclusion_status <> ''
                    THEN 'analysis_schema:' || analysis_exclusion_status || ':'
                         || analysis_exclusion_reason
                WHEN scalar_rows = 0 AND dimensioned_rows = 0 AND reviewed_role = 'measure'
                    THEN 'reviewed measure had no Stage 05 cells'
                ELSE ''
            END AS exclusion_reason
        FROM source_inventory
        UNION ALL
        SELECT
            d.year,
            'derived:' || d.transformation AS variable_id,
            d.analysis_column AS varname,
            '' AS source_file,
            '' AS access_table_name,
            'derived_output' AS reviewed_role,
            'true' AS reviewed,
            'classified' AS resolution,
            COUNT(d.normalized_value) AS nonempty_tokens,
            0 AS scalar_rows,
            0 AS dimensioned_rows,
            COUNT(*) AS output_rows,
            'analysis_wide_derived' AS output_destination,
            '' AS exclusion_reason
        FROM release_derived_values d
        GROUP BY 1, 2, 3
        """
    )
    atomic_copy_query_to_csv(
        con,
        """
        SELECT * FROM release_lane_coverage
        ORDER BY year, output_destination, source_file, access_table_name, varname, variable_id
        """,
        lane_path,
    )
    atomic_copy_query_to_csv(
        con,
        """
        SELECT output_destination,
               SUM(nonempty_tokens) AS reviewed_nonempty_source_tokens,
               SUM(scalar_rows) AS scalar_rows,
               SUM(dimensioned_rows) AS dimensioned_rows,
               SUM(output_rows) AS output_rows,
               COUNT(*) AS inventory_rows
        FROM release_lane_coverage
        GROUP BY output_destination
        ORDER BY output_destination
        """,
        qc_dir / "qc_lane_coverage_summary.csv",
    )
    conflict_key_count = _materialize_release_conflict_keys(
        con,
        years=runtime.years,
    )
    conflict_sample_query = """
            SELECT
                v.UNITID, v.year, v.analysis_column, v.normalized_value,
                v.value_status, v.transformation, v.variable_id, v.source_file,
                v.access_table_name, v.source_row_id, k.distinct_values
            FROM release_direct_mapped v
            INNER JOIN release_conflict_keys k USING (UNITID, year, analysis_column)
            UNION ALL
            SELECT
                v.UNITID, v.year, v.analysis_column, v.normalized_value,
                v.value_status, v.transformation, 'derived:' || v.transformation AS variable_id,
                '' AS source_file, '' AS access_table_name, '' AS source_row_id,
                k.distinct_values
            FROM release_derived_values v
            INNER JOIN release_conflict_keys k USING (UNITID, year, analysis_column)
            ORDER BY year, UNITID, analysis_column, normalized_value, source_file, source_row_id
            LIMIT {limit}
            """.format(limit=int(args.release_failure_sample_rows))
    atomic_copy_query_to_csv(
        con,
        conflict_sample_query,
        qc_dir / "qc_final_wide_conflicts.csv",
    )
    _write_release_csv(
        qc_dir / "qc_final_wide_conflicts_summary.csv",
        pd.DataFrame(
            [
                {
                    "total_conflict_keys": conflict_key_count,
                    "sample_row_limit": int(args.release_failure_sample_rows),
                }
            ]
        ),
    )
    if conflict_key_count:
        raise SystemExit(f"final wide uniqueness gate failed: keys={conflict_key_count}")

    _materialize_release_unique_values(
        con,
        years=runtime.years,
        temp_dir=work_dir,
    )
    con.execute(
        """
        CREATE OR REPLACE TEMP VIEW release_cast_inputs AS
        SELECT
            m.UNITID,
            m.year,
            m.analysis_column,
            m.variable_id,
            m.source_file,
            m.source_row_id,
            m.raw_value,
            m.value,
            m.value_status,
            m.logical_type,
            m.normalized_value
        FROM release_direct_mapped m
        UNION ALL
        SELECT
            d.UNITID,
            d.year,
            d.analysis_column,
            'derived:' || d.transformation AS variable_id,
            '' AS source_file,
            '' AS source_row_id,
            d.normalized_value AS raw_value,
            d.normalized_value AS value,
            d.value_status,
            c.logical_type,
            d.normalized_value
        FROM release_derived_values d
        INNER JOIN stage.analysis_contract c
          ON d.analysis_column = c.analysis_column
        """
    )
    invalid_casts = _materialize_release_cast_summary(con)
    atomic_copy_query_to_csv(
        con,
        """
        SELECT * FROM release_cast_diagnostics
        WHERE cast_status <> 'parsed'
        ORDER BY year, UNITID, analysis_column, source_file, source_row_id
        LIMIT {limit}
        """.format(limit=int(args.release_failure_sample_rows)),
        cast_path,
    )
    atomic_copy_query_to_csv(
        con,
        """
        SELECT * FROM release_cast_summary
        ORDER BY logical_type, value_status, cast_status, cast_reason
        """,
        qc_dir / "qc_cast_summary.csv",
    )
    if invalid_casts:
        raise SystemExit(f"type-safe cast gate failed: rows={invalid_casts}")

    _materialize_release_spine(con, years=runtime.years)
    analysis_register = analysis_df[
        ["analysis_column", "logical_type", "transformation", "first_year_int", "last_year_int", "nullable_bool"]
    ].copy()
    register_df_as_table(con, "stage.release_columns", analysis_register)
    missing_required_query = """
        SELECT s.UNITID, s.year, c.analysis_column
        FROM release_spine s
        CROSS JOIN stage.release_columns c
        LEFT JOIN release_unique_values v
          ON v.UNITID = s.UNITID AND v.year = s.year AND v.analysis_column = c.analysis_column
        WHERE NOT c.nullable_bool
          AND s.year BETWEEN c.first_year_int AND c.last_year_int
          AND v.normalized_value IS NULL
    """
    missing_required_count = _bounded_failure_sample(
        con,
        count_query=missing_required_query,
        sample_order_by="year, UNITID, analysis_column",
        output_path=qc_dir / "qc_nonnullable_missing.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if missing_required_count:
        raise SystemExit(
            f"nonnullable analysis column gate failed: cells={missing_required_count}"
        )

    family_output_df = discrete_df[discrete_df["output_column"] != ""][["source_file", "family_id", "output_column"]].drop_duplicates()
    register_df_as_table(con, "stage.discrete_outputs", family_output_df)
    lineage_query = """
        SELECT
            m.contract_id,
            m.UNITID,
            m.year,
            m.analysis_column,
            m.variable_id,
            m.source_varnumber,
            m.varname,
            m.source_row_id,
            m.source_row_hash,
            m.source_file,
            m.access_table_name,
            m.transformation AS transformation_id,
            m.raw_value,
            m.value_status,
            m.normalized_value,
            m.normalized_value AS output_normalized_value,
            'direct' AS lineage_role
        FROM release_direct_mapped m
        UNION ALL
        SELECT
            d.contract_id,
            d.UNITID,
            d.year,
            o.output_column AS analysis_column,
            d.variable_id,
            d.source_varnumber,
            d.varname,
            d.source_row_id,
            d.source_row_hash,
            d.source_file,
            d.access_table_name,
            'discrete:' || d.family_id AS transformation_id,
            d.raw_value,
            d.value_status,
            d.normalized_value,
            v.normalized_value AS output_normalized_value,
            'derived_component' AS lineage_role
        FROM release_discrete_observed d
        INNER JOIN stage.discrete_outputs o
          ON UPPER(d.source_file) = o.source_file AND d.family_id = o.family_id
        INNER JOIN release_derived_values v
          ON v.UNITID = d.UNITID
         AND v.year = d.year
         AND v.analysis_column = o.output_column
         AND v.transformation = 'discrete:' || d.family_id
    """
    duplicate_lineage_count = _bounded_duplicate_lineage_sample(
        con,
        lineage_query=lineage_query,
        years=runtime.years,
        output_path=qc_dir / "qc_duplicate_value_lineage.csv",
        limit=int(args.release_failure_sample_rows),
    )
    if duplicate_lineage_count:
        raise SystemExit(
            f"value lineage key gate failed: duplicates={duplicate_lineage_count}"
        )
    lineage_rows, _lineage_parts = _write_release_lineage_outputs(
        con,
        lineage_query=lineage_query,
        years=runtime.years,
        temp_dir=work_dir,
        combined_path=lineage_path,
        batch_rows=min(int(args.scan_batch_rows), 65_536),
    )

    if args.wide_analysis_out and not args.write_single:
        args.write_single = args.wide_analysis_out
    if not args.write_single:
        token = f"{runtime.years[0]}_{runtime.years[-1]}"
        args.write_single = str(runtime.repo_root / "Panels" / "v2" / f"panel_wide_analysis_{token}.parquet")
    _write_release_wide_outputs(
        con,
        years=runtime.years,
        analysis_df=analysis_df,
        out_dir=args.out_dir,
        combined_path=args.write_single,
        row_group_size=args.wide_parquet_row_group_size,
    )
    panel_rows = scalar_int(con, "SELECT COUNT(*) FROM release_spine")
    summary = pd.DataFrame(
        [
            {
                "contract_id": PANEL_CONTRACT_ID,
                "build_mode": "release",
                "input_rows": row_count,
                "panel_rows": panel_rows,
                "analysis_columns": len(analysis_df),
                "lineage_rows": lineage_rows,
                "unresolved_conflicts": 0,
                "unresolved_casts": 0,
                "schema_contract": getattr(
                    args,
                    "release_public_analysis_schema_path",
                    _portable_release_path(
                        args.analysis_schema_contract,
                        root=runtime.repo_root,
                    ),
                ),
                "discrete_contract": getattr(
                    args,
                    "release_public_discrete_contract_path",
                    _portable_release_path(
                        args.discrete_family_contract,
                        root=runtime.repo_root,
                    ),
                ),
                "output": getattr(
                    args,
                    "release_public_output_path",
                    _portable_release_path(args.write_single, root=runtime.repo_root),
                ),
            }
        ]
    )
    _write_release_csv(qc_dir / "wide_panel_qc_summary.csv", summary)
    con.close()
    print(f"[info] release wide build passed: {args.write_single}", flush=True)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _portable_release_path(value: str | Path, *, root: Path) -> str:
    """Serialize release paths without exposing a workstation-specific prefix."""
    path = Path(value).expanduser().resolve(strict=False)
    root_path = root.expanduser().resolve(strict=False)
    try:
        return path.relative_to(root_path).as_posix()
    except ValueError:
        if path.parent.name == "contracts":
            return f"contracts/{path.name}"
        return path.name


def _write_bundle_inventory(run_dir: Path) -> None:
    rows: list[dict[str, object]] = []
    for path in sorted(item for item in run_dir.rglob("*") if item.is_file()):
        if path.name == "bundle_manifest.csv":
            continue
        rows.append(
            {
                "relative_path": path.relative_to(run_dir).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": _sha256_file(path),
            }
        )
    _write_release_csv(run_dir / "bundle_manifest.csv", pd.DataFrame(rows))


def _verify_bundle_inventory(run_dir: Path) -> None:
    manifest_path = run_dir / "bundle_manifest.csv"
    manifest = pd.read_csv(manifest_path, dtype=str, keep_default_na=False)
    required = {"relative_path", "bytes", "sha256"}
    if set(manifest.columns) != required:
        raise SystemExit(f"wide release bundle manifest has invalid schema: {manifest_path}")
    if manifest["relative_path"].duplicated().any():
        raise SystemExit(f"wide release bundle manifest repeats paths: {manifest_path}")
    expected_paths = set(manifest["relative_path"])
    actual_paths = {
        path.relative_to(run_dir).as_posix()
        for path in run_dir.rglob("*")
        if path.is_file() and path != manifest_path
    }
    if actual_paths != expected_paths:
        raise SystemExit(
            "wide release bundle file inventory drifted: "
            f"missing={sorted(expected_paths - actual_paths)} extra={sorted(actual_paths - expected_paths)}"
        )
    for row in manifest.to_dict("records"):
        path = run_dir / str(row["relative_path"])
        if path.stat().st_size != int(str(row["bytes"])) or _sha256_file(path) != str(row["sha256"]):
            raise SystemExit(f"wide release bundle artifact drifted after sealing: {path}")


def _remove_release_work_tree(work_root: Path) -> None:
    """Remove only the unique, unpromoted work tree for one release run."""
    if work_root.is_symlink():
        raise RuntimeError(f"refusing to remove symlinked release work tree: {work_root}")
    if work_root.exists():
        shutil.rmtree(work_root)


def _seal_immutable_tree(path: Path) -> None:
    for item in sorted(path.rglob("*"), reverse=True):
        if item.is_symlink():
            continue
        item.chmod(0o555 if item.is_dir() else 0o444)
    path.chmod(0o555)


def _preflight_projection(alias: Path, expected_target: Path) -> None:
    if alias.is_symlink():
        actual = Path(os.readlink(alias))
        if not actual.is_absolute():
            actual = alias.parent / actual
        actual_normalized = Path(os.path.abspath(actual))
        expected_normalized = Path(os.path.abspath(expected_target))
        if actual_normalized != expected_normalized:
            raise SystemExit(
                "release projection must resolve through the single managed current pointer: "
                f"{alias} -> {actual_normalized} expected={expected_normalized}"
            )
        return
    if alias.exists():
        raise SystemExit(
            f"release projection must be a managed symlink, not a mutable file/directory: {alias}"
        )


def _install_projection(alias: Path, expected_target: Path) -> None:
    _preflight_projection(alias, expected_target)
    if alias.is_symlink():
        return
    alias.parent.mkdir(parents=True, exist_ok=True)
    pending = alias.with_name(f".{alias.name}.projection-{uuid.uuid4().hex}")
    pending.symlink_to(expected_target)
    os.replace(pending, alias)


def run_release(args, runtime: WideBuildRuntime) -> None:
    """Stage a complete immutable output+QC bundle and promote one pointer."""
    token = f"{runtime.years[0]}_{runtime.years[-1]}"
    bundle_root = Path(
        args.release_bundle_root
        or runtime.repo_root / "Panels" / "v2" / "wide_release"
    )
    run_id = (
        datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        + "-"
        + uuid.uuid4().hex
    )
    staging = bundle_root / ".staging" / run_id
    run_dir = bundle_root / "runs" / run_id
    failure_dir = bundle_root / "failed" / run_id
    current = bundle_root / "current"

    original_output = Path(
        args.write_single
        or args.wide_analysis_out
        or runtime.repo_root / "Panels" / "v2" / f"panel_wide_analysis_{token}.parquet"
    )
    original_raw_output = Path(
        args.raw_wide_out
        or original_output.with_name(
            original_output.name.replace("panel_wide_analysis_", "panel_wide_raw_")
        )
    )
    if original_raw_output == original_output:
        raise SystemExit("release raw-wide and analysis-wide aliases must be distinct")
    original_parts = Path(args.out_dir)
    original_qc = Path(
        args.qc_dir or runtime.repo_root / "Checks" / "v2" / "wide_qc"
    )
    original_disc_qc = Path(
        args.disc_qc_dir or runtime.repo_root / "Checks" / "v2" / "disc_qc"
    )
    explicit_qc_files = [
        args.value_lineage_out,
        args.column_lineage_out,
        args.analysis_candidates_out,
        args.lane_coverage_out,
        args.cast_report_out,
    ]
    for value in explicit_qc_files:
        if not value:
            continue
        path = Path(value).resolve(strict=False)
        qc_root = original_qc.resolve(strict=False)
        if path.parent != qc_root:
            raise SystemExit(
                "release QC file destinations must be direct children of the managed --qc-dir: "
                f"{path} not under {qc_root}"
            )

    projections = {
        original_output: bundle_root / "current" / "output" / original_output.name,
        original_raw_output: bundle_root / "current" / "output" / original_output.name,
        original_parts: bundle_root / "current" / "parts",
        original_qc: bundle_root / "current" / "qc" / "wide_qc",
        original_disc_qc: bundle_root / "current" / "qc" / "disc_qc",
    }
    if len(projections) != 5:
        raise SystemExit(
            "release raw/analysis outputs, parts, wide-QC, and discrete-QC projections "
            "must be distinct"
        )
    for alias, target in projections.items():
        _preflight_projection(alias, target)
    if current.exists() and not current.is_symlink():
        raise SystemExit(f"managed wide release pointer is not a symlink: {current}")
    if current.is_symlink():
        current_target = current.resolve(strict=False)
        runs_root = (bundle_root / "runs").resolve(strict=False)
        if runs_root not in current_target.parents:
            raise SystemExit(
                f"managed wide release pointer escapes its immutable runs root: {current_target}"
            )
        if not (current_target / "bundle_manifest.csv").is_file():
            raise SystemExit(
                f"managed wide release pointer targets an unsealed/incomplete run: {current_target}"
            )
        _verify_bundle_inventory(current_target)

    staging_args = copy.copy(args)
    staged_output = staging / "output" / original_output.name
    staged_qc = staging / "qc" / "wide_qc"
    staged_disc_qc = staging / "qc" / "disc_qc"
    staging_args.out_dir = str(staging / "parts")
    staging_args.write_single = str(staged_output)
    staging_args.wide_analysis_out = str(staged_output)
    staging_args.qc_dir = str(staged_qc)
    staging_args.disc_qc_dir = str(staged_disc_qc)
    work_root = staging / ".work"
    staging_args.release_work_dir = str(work_root)
    staging_args.duckdb_path = str(work_root / "release.duckdb")
    staging_args.duckdb_temp_dir = str(work_root / "duckdb_spill")
    staging_args.release_public_output_path = _portable_release_path(
        original_output,
        root=runtime.repo_root,
    )
    staging_args.release_public_analysis_schema_path = _portable_release_path(
        args.analysis_schema_contract,
        root=runtime.repo_root,
    )
    staging_args.release_public_discrete_contract_path = _portable_release_path(
        args.discrete_family_contract,
        root=runtime.repo_root,
    )
    staged_disc_qc.mkdir(parents=True, exist_ok=False)
    if args.value_lineage_out:
        staging_args.value_lineage_out = str(staged_qc / Path(args.value_lineage_out).name)
        staging_args.column_lineage_out = None
    elif args.column_lineage_out:
        staging_args.value_lineage_out = None
        staging_args.column_lineage_out = str(staged_qc / Path(args.column_lineage_out).name)
    else:
        staging_args.value_lineage_out = str(staged_qc / "qc_value_lineage.parquet")
        staging_args.column_lineage_out = None
    for attribute, default_name in [
        ("analysis_candidates_out", "qc_analysis_schema_candidates.csv"),
        ("lane_coverage_out", "qc_lane_coverage.csv"),
        ("cast_report_out", "qc_cast_diagnostics.csv"),
    ]:
        original = getattr(args, attribute)
        if original:
            setattr(staging_args, attribute, str(staged_qc / Path(original).name))
        else:
            setattr(staging_args, attribute, str(staged_qc / default_name))

    try:
        _run_release_bundle_member(staging_args, runtime)
        _remove_release_work_tree(work_root)
        metadata = {
            "contract_id": PANEL_CONTRACT_ID,
            "run_id": run_id,
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "years": runtime.years,
            "input": _portable_release_path(args.input, root=runtime.repo_root),
            "dimensioned_input": _portable_release_path(
                args.dimensioned_input,
                root=runtime.repo_root,
            ),
            "dictionary": _portable_release_path(args.dictionary, root=runtime.repo_root),
            "analysis_schema_contract": _portable_release_path(
                args.analysis_schema_contract,
                root=runtime.repo_root,
            ),
            "discrete_family_contract": _portable_release_path(
                args.discrete_family_contract,
                root=runtime.repo_root,
            ),
            "promotion_pointer": _portable_release_path(current, root=runtime.repo_root),
        }
        (staging / "bundle_metadata.json").write_text(
            json.dumps(metadata, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        _write_bundle_inventory(staging)
        run_dir.parent.mkdir(parents=True, exist_ok=True)
        os.replace(staging, run_dir)
        _seal_immutable_tree(run_dir)
        _verify_bundle_inventory(run_dir)
        for alias, target in projections.items():
            _install_projection(alias, target)
        bundle_root.mkdir(parents=True, exist_ok=True)
        pending_pointer = bundle_root / f".current-{uuid.uuid4().hex}"
        pending_pointer.symlink_to(Path("runs") / run_id)
        os.replace(pending_pointer, current)
    except BaseException as exc:
        cleanup_error = ""
        try:
            _remove_release_work_tree(work_root)
        except Exception as cleanup_exc:
            cleanup_error = f"{type(cleanup_exc).__name__}: {cleanup_exc}"
        if staging.exists():
            try:
                failure_payload = {
                    "run_id": run_id,
                    "failed_at_utc": datetime.now(timezone.utc).isoformat(),
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                }
                if cleanup_error:
                    failure_payload["cleanup_error"] = cleanup_error
                (staging / "failure.json").write_text(
                    json.dumps(failure_payload, indent=2, sort_keys=True)
                    + "\n",
                    encoding="utf-8",
                )
                failure_dir.parent.mkdir(parents=True, exist_ok=True)
                os.replace(staging, failure_dir)
            except OSError:
                pass
        raise
    print(f"[info] promoted immutable wide release bundle: {current} -> runs/{run_id}")


def run(args) -> None:
    runtime: WideBuildRuntime = prepare_runtime(args)
    if args.build_mode == "release":
        return run_release(args, runtime)
    if args.legacy_analysis_schema:
        if not args.compatibility_output:
            raise SystemExit("development legacy schema seeding requires --compatibility-output")
        args.write_single = args.compatibility_output
    years = runtime.years
    profile_dir = resolve_profile_dir(args, runtime)
    if max(years) >= 2024:
        print(
            "[warn] 2024 is treated as provisional/schema-transition; prefer 2004:2023 for analysis releases.",
            flush=True,
        )

    dataset = ds.dataset(args.input, format="parquet")
    schema = dataset.schema

    unitid_col = pick_col(schema, ["UNITID", "unitid"])
    year_col = pick_col(schema, ["year", "academicyear"])
    target_col = pick_col(schema, ["varname", "target_var", "concept", "target"])
    value_col = pick_col(schema, ["value", "val"])
    source_col = pick_optional_col(schema, ["source_file", "source"])
    varnumber_col = pick_optional_col(schema, ["varnumber", "var_num", "number"])
    if args.lane_split and (source_col is None or varnumber_col is None):
        raise SystemExit("lane-split requires source_file and varnumber columns in long input.")

    con, effective_db_path = open_build_connection(
        args.duckdb_path,
        args.duckdb_temp_dir,
        args.persist_duckdb,
        memory_limit=args.duckdb_memory_limit,
        threads=args.duckdb_threads,
        preserve_insertion_order=False,
    )
    bootstrap_build_db(con)
    print(f"[info] DuckDB build state: {effective_db_path}", flush=True)

    config = {
        "anti_garbage_ids": args.anti_garbage_ids,
        "collapse_disc": args.collapse_disc,
        "dim_prefixes": args.dim_prefixes,
        "dim_sources": args.dim_sources,
        "drop_anti_garbage_cols": args.drop_anti_garbage_cols,
        "drop_disc_components": args.drop_disc_components,
        "drop_empty_cols": args.drop_empty_cols,
        "drop_globally_null_post": args.drop_globally_null_post,
        "exclude_vars": args.exclude_vars,
        "fail_on_anti_garbage": args.fail_on_anti_garbage,
        "fail_on_scalar_conflicts": args.fail_on_scalar_conflicts,
        "lane_split": args.lane_split,
        "duckdb_memory_limit": args.duckdb_memory_limit,
        "duckdb_threads": args.duckdb_threads,
        "typed_output": args.typed_output,
        "scalar_conflict_buckets": args.scalar_conflict_buckets,
        "scalar_conflict_bucket_min_year": args.scalar_conflict_bucket_min_year,
    }
    record_build_run(
        con,
        input_path=args.input,
        dictionary_path=args.dictionary,
        years_spec=args.years,
        lane_split=args.lane_split,
        exclude_vars=args.exclude_vars,
        typed_output=args.typed_output,
        persist_duckdb=args.persist_duckdb,
        config=config,
    )

    if args.dictionary:
        con.execute(f"CREATE OR REPLACE TABLE meta.dictionary_lake AS SELECT * FROM read_parquet({sql_quote(args.dictionary)})")

    register_started = time.monotonic()
    register_db_before = file_size_bytes(effective_db_path)
    log_phase("register parquet input start", input=args.input, years=args.years)
    con.execute(
        build_stage_long_query(
            input_path=args.input,
            years=years,
            unitid_col=unitid_col,
            year_col=year_col,
            target_col=target_col,
            value_col=value_col,
            source_col=source_col,
            varnumber_col=varnumber_col,
        )
    )
    register_elapsed = time.monotonic() - register_started
    register_db_after = file_size_bytes(effective_db_path)
    register_db_growth = register_db_after - register_db_before
    log_phase(
        "register parquet input end",
        elapsed_seconds=f"{register_elapsed:.3f}",
        stage_cols=7,
        db_growth_bytes=register_db_growth,
        registered_object="view",
    )
    if args.persist_duckdb and register_elapsed > 30 and register_db_growth > 64 * 1024 * 1024:
        raise SystemExit("registration is materializing the input parquet instead of registering it lazily")
    log_phase("spine materialization start")
    con.execute("CREATE OR REPLACE TABLE stage.spine AS SELECT DISTINCT year, UNITID FROM stage.long_selected ORDER BY year, UNITID")
    log_phase("spine materialization end", spine_rows=scalar_int(con, "SELECT COUNT(*) FROM stage.spine"))

    dedupe_partition = ["UNITID", "year", "varname", "value_norm"]
    if args.lane_split:
        dedupe_partition.extend(["varnumber", "source_file"])
    partition_sql = ", ".join(dedupe_partition)
    where_sql = f"WHERE varname NOT IN ({sql_upper_in(runtime.exclude_vars)})" if runtime.exclude_vars else ""
    dedupe_order_sql = ", ".join(
        [
            "year",
            "UNITID",
            "varname",
            "source_file",
            "varnumber",
            "COALESCE(value_norm, '')",
            "COALESCE(value, '')",
        ]
    )
    log_phase("analysis base build start")
    con.execute(
        f"""
        CREATE OR REPLACE VIEW core.analysis_long_base AS
        WITH deduped AS (
            SELECT
                UNITID,
                year,
                varname,
                value,
                value_norm,
                source_file,
                varnumber
            FROM (
                SELECT
                    *,
                    ROW_NUMBER() OVER (
                        PARTITION BY {partition_sql}
                        ORDER BY {dedupe_order_sql}
                    ) AS _rn
                FROM stage.long_selected
                {where_sql}
            )
            WHERE _rn = 1
        )
        SELECT
            ROW_NUMBER() OVER (ORDER BY {dedupe_order_sql}) AS row_id,
            UNITID,
            year,
            varname,
            value,
            value_norm,
            source_file,
            varnumber
        FROM deduped
        """
    )
    log_phase("analysis base build end", materialized_object="view")

    exclude_clause = f"varname NOT IN ({sql_upper_in(runtime.exclude_vars)})" if runtime.exclude_vars else ""
    year_base_clauses = [exclude_clause] if exclude_clause else []
    dimension_expr = None
    if args.lane_split:
        log_phase(
            "lane split planning start",
            dim_sources=len(runtime.dim_sources),
            dim_prefixes=len(runtime.dim_prefixes),
        )
        dimension_expr = build_dimension_expr(runtime.dim_sources, runtime.dim_prefixes)
        log_phase(
            "lane split planning end",
            strategy="year_scoped",
            scalar_export=bool(args.scalar_long_out),
            dim_export=bool(args.dim_long_out),
        )

    create_empty_conflicts(con)
    create_empty_cast_report(con)
    create_empty_disc_conflicts(con)

    log_phase("discover targets start")
    stage_target_df = con.execute(
        """
        SELECT
            varname,
            COUNT(*) AS stage_rows,
            COUNT(*) FILTER (WHERE value_norm IS NOT NULL) AS stage_non_empty_rows
        FROM stage.long_selected
        GROUP BY 1
        ORDER BY 1
        """
    ).fetchdf()
    log_phase("non-empty scan start")
    target_scan_clauses = list(year_base_clauses)
    if args.lane_split and dimension_expr:
        target_scan_clauses.append(f"NOT ({dimension_expr})")
    target_df = con.execute(
        f"""
        SELECT
            varname,
            COUNT(*) AS scalar_rows,
            COUNT(*) FILTER (WHERE value_norm IS NOT NULL) AS non_empty_rows
        FROM stage.long_selected
        {build_where_sql(target_scan_clauses)}
        GROUP BY 1
        ORDER BY 1
        """
    ).fetchdf()
    column_source_df = con.execute(
        f"""
        SELECT
            varname,
            source_file,
            varnumber,
            COUNT(*) AS source_rows,
            COUNT(*) FILTER (WHERE value_norm IS NOT NULL) AS source_non_empty_rows
        FROM stage.long_selected
        {build_where_sql(target_scan_clauses)}
        GROUP BY 1, 2, 3
        ORDER BY 1, 2, 3
        """
    ).fetchdf()
    targets = target_df["varname"].tolist()
    discovered_targets = len(targets)
    targets_with_data = set(target_df.loc[target_df["non_empty_rows"] > 0, "varname"].tolist())
    legacy_seed_plan_df = pd.DataFrame(columns=["column_name", "seed_reason", "dtype", "source_contract", "present_in_target_universe", "seeded_for_compatibility"])
    seeded_legacy_df = legacy_seed_plan_df.copy()
    legacy_seed_columns: set[str] = set()
    seeded_legacy_names: set[str] = set()
    if args.lane_split and runtime.legacy_analysis_schema:
        legacy_manifest_df = load_legacy_schema_seed_manifest(runtime.legacy_schema_seed_manifest)
        legacy_seed_plan_df, seeded_legacy_df = plan_legacy_schema_seeds(legacy_manifest_df, targets)
        legacy_seed_columns = set(legacy_seed_plan_df["column_name"].tolist())
        seeded_legacy_names = set(seeded_legacy_df["column_name"].tolist())
        if seeded_legacy_names:
            targets.extend(sorted(seeded_legacy_names))
    log_phase("non-empty scan end", non_empty_targets=len(targets_with_data))
    all_targets = order_targets(targets)
    log_phase("discover targets end", discovered_targets=discovered_targets, ordered_targets=len(all_targets))

    if args.drop_empty_cols:
        before = len(all_targets)
        all_targets = [t for t in all_targets if t in targets_with_data or t in legacy_seed_columns]
        dropped = before - len(all_targets)
        if dropped > 0:
            print(
                f"[info] dropped {dropped} globally-empty variables (no non-empty values in selected years)",
                flush=True,
            )
    register_df_as_table(con, "qa.seeded_legacy_columns", seeded_legacy_df)
    if runtime.seeded_legacy_out:
        Path(runtime.seeded_legacy_out).parent.mkdir(parents=True, exist_ok=True)
        seeded_legacy_df.to_csv(runtime.seeded_legacy_out, index=False)
    if not seeded_legacy_df.empty:
        print(f"[info] seeded {len(seeded_legacy_df)} legacy compatibility columns into wide targets", flush=True)

    numeric_targets = set()
    if args.typed_output:
        log_phase("numeric target build start")
        numeric_targets = build_numeric_targets(args.dictionary, all_targets)
        log_phase("numeric target build end", numeric_targets=len(numeric_targets))
        print(
            f"[info] typed output enabled: numeric vars={len(numeric_targets)} string vars={len(all_targets) - len(numeric_targets)}",
            flush=True,
        )

    var_to_group, group_to_vars = ({}, {})
    if args.collapse_disc:
        var_to_group, group_to_vars = build_disc_groups(args.dictionary)
        if args.disc_exclude:
            excludes = {x.strip().upper() for x in args.disc_exclude.split(",") if x.strip()}
            if excludes:
                group_to_vars = {k: v for k, v in group_to_vars.items() if k.upper() not in excludes}
                var_to_group = {v: grp for v, grp in var_to_group.items() if grp[0].upper() not in excludes}
    disc_name_map = {}
    component_vars: set[str] = set()
    if args.collapse_disc and group_to_vars:
        disc_name_map = resolve_disc_names(group_to_vars, set(all_targets), suffix=args.disc_suffix)
        for base, new_name in disc_name_map.items():
            if new_name not in all_targets:
                all_targets.append(new_name)
        component_vars = {v for vs in group_to_vars.values() for v in vs}
        if args.drop_disc_components:
            all_targets = [t for t in all_targets if t not in component_vars]

    anti_hits_initial = find_anti_garbage_hits(all_targets, runtime.anti_garbage_ids)
    anti_hits = list(anti_hits_initial)
    anti_df = pd.DataFrame({"blocked_identifier_column": anti_hits_initial})
    register_df_as_table(con, "qa.anti_garbage_hits", anti_df)
    if anti_hits_initial and runtime.anti_garbage_out:
        anti_df.to_csv(runtime.anti_garbage_out, index=False)
        print(
            f"[warn] anti-garbage hits written: {runtime.anti_garbage_out} (count={len(anti_hits_initial)})",
            flush=True,
        )
    if anti_hits and args.drop_anti_garbage_cols:
        all_targets = [t for t in all_targets if t not in set(anti_hits)]
        print(f"[info] dropped {len(anti_hits)} anti-garbage identifier columns from wide targets", flush=True)
        anti_hits = find_anti_garbage_hits(all_targets, runtime.anti_garbage_ids)
        anti_df = pd.DataFrame({"blocked_identifier_column": anti_hits})
        register_df_as_table(con, "qa.anti_garbage_hits", anti_df)
    if anti_hits and args.fail_on_anti_garbage:
        raise SystemExit(f"anti-garbage gate failed: {len(anti_hits)} blocked dimension identifiers present in wide targets")

    print(f"[info] years: {years[0]}–{years[-1]} ({len(years)} total)", flush=True)
    print(f"[info] wide columns (varname): {len(all_targets)}", flush=True)

    log_phase("target lineage build start")
    scalar_lineage_df = target_df.rename(columns={"non_empty_rows": "scalar_non_empty_rows"})
    lineage_df = build_target_lineage_df(
        stage_df=stage_target_df,
        scalar_df=scalar_lineage_df,
        legacy_seed_plan_df=legacy_seed_plan_df,
        seeded_legacy_names=seeded_legacy_names,
        exclude_vars=runtime.exclude_vars,
        targets_with_data=targets_with_data,
        component_vars=component_vars,
        var_to_group=var_to_group,
        disc_name_map=disc_name_map,
        anti_hits_initial=anti_hits_initial,
        anti_hits_final=anti_hits,
        final_targets=all_targets,
        drop_empty_cols=args.drop_empty_cols,
        drop_disc_components=args.drop_disc_components,
        drop_anti_garbage_cols=args.drop_anti_garbage_cols,
    )
    register_df_as_table(con, "qa.target_lineage", lineage_df)
    if runtime.target_lineage_out:
        Path(runtime.target_lineage_out).parent.mkdir(parents=True, exist_ok=True)
        lineage_df.to_csv(runtime.target_lineage_out, index=False)
    log_phase("target lineage build end", rows=len(lineage_df), output=runtime.target_lineage_out or "")

    log_phase("column lineage build start")
    column_lineage_df = build_column_lineage_df(
        source_df=column_source_df,
        legacy_seed_plan_df=legacy_seed_plan_df,
        seeded_legacy_names=seeded_legacy_names,
        final_targets=all_targets,
        var_to_group=var_to_group,
        disc_name_map=disc_name_map,
    )
    register_df_as_table(con, "qa.column_lineage", column_lineage_df)
    write_dataframe(runtime.column_lineage_out, column_lineage_df)
    log_phase("column lineage build end", rows=len(column_lineage_df), output=runtime.column_lineage_out or "")
    if args.lineage_only:
        log_phase("lineage-only exit")
        return

    if args.collapse_disc and group_to_vars:
        disc_rows = [
            {"varname": varname, "base": base, "suffix": suffix, "output_varname": disc_name_map.get(base, base)}
            for varname, (base, suffix) in var_to_group.items()
        ]
        disc_map_df = pd.DataFrame(disc_rows)
        register_df_as_table(con, "stage.disc_map", disc_map_df)
        register_df_as_table(con, "stage.disc_output_names", disc_map_df[["base", "output_varname"]].drop_duplicates())

    year_part_paths: list[str] = []
    qc_rows: list[dict] = []
    cast_report_frames: list[pd.DataFrame] = []
    scalar_conflict_frames: list[pd.DataFrame] = []
    disc_conflict_summary_frames: list[pd.DataFrame] = []
    scalar_conflict_rows_written = 0
    scalar_part_paths: list[str] = []
    dim_part_paths: list[str] = []
    scalar_parts_dir = f"{args.scalar_long_out}.parts" if args.scalar_long_out else None
    dim_parts_dir = f"{args.dim_long_out}.parts" if args.dim_long_out else None

    for year in years:
        log_phase(f"year {year} start")
        con.execute(f"CREATE OR REPLACE TEMP VIEW year_spine AS SELECT year, UNITID FROM stage.spine WHERE year = {int(year)}")
        spine_rows = scalar_int(con, "SELECT COUNT(*) FROM year_spine")
        log_phase(f"year {year} spine done", rows=spine_rows)

        log_phase(f"year {year} base query start")
        year_base_query = build_year_base_query(
            year=year,
            extra_clauses=year_base_clauses,
            partition_sql=partition_sql,
            dedupe_order_sql=dedupe_order_sql,
        )
        if args.profile_year == year:
            write_explain_artifact(
                con,
                profile_dir=profile_dir,
                year=year,
                label="year_long_base",
                query=year_base_query,
                analyze=args.profile_analyze,
            )
        con.execute(f"CREATE OR REPLACE TEMP VIEW year_long_base AS {year_base_query}")
        log_phase(f"year {year} base query end", materialized_object="view")

        year_source_table = "year_long_base"
        dim_export_clauses: list[str] | None = None
        if args.lane_split and dimension_expr:
            scalar_lane_query = build_year_base_query(
                year=year,
                extra_clauses=year_base_clauses + [f"NOT ({dimension_expr})"],
                partition_sql=partition_sql,
                dedupe_order_sql=dedupe_order_sql,
            )
            if args.profile_year == year:
                write_explain_artifact(
                    con,
                    profile_dir=profile_dir,
                    year=year,
                    label="scalar_lane_materialization",
                    query=scalar_lane_query,
                    analyze=args.profile_analyze,
                )
            log_phase(f"year {year} scalar lane materialization start")
            con.execute(
                f"""
                CREATE OR REPLACE TEMP TABLE year_scalar_long_raw AS
                {scalar_lane_query}
                """
            )
            scalar_raw_rows = scalar_int(con, "SELECT COUNT(*) FROM year_scalar_long_raw")
            log_phase(f"year {year} scalar lane materialization end", rows=scalar_raw_rows)

            if args.dim_long_out:
                dim_export_clauses = [f"year = {int(year)}", *year_base_clauses, f"({dimension_expr})"]

            use_bucketed_conflicts = int(args.scalar_conflict_buckets) > 1 and int(year) >= int(args.scalar_conflict_bucket_min_year)
            log_phase(
                f"year {year} scalar conflict scan start",
                strategy="bucketed" if use_bucketed_conflicts else "monolithic",
                buckets=int(args.scalar_conflict_buckets) if use_bucketed_conflicts else 1,
            )
            if use_bucketed_conflicts:
                conflict_key_count = compute_year_scalar_conflict_keys_bucketed(
                    con,
                    year=year,
                    source_table="year_scalar_long_raw",
                    bucket_count=int(args.scalar_conflict_buckets),
                    log_phase_fn=log_phase,
                    profile_dir=profile_dir if args.profile_year == year else None,
                    profile_analyze=bool(args.profile_analyze),
                )
            else:
                monolithic_conflict_sql = """
                    SELECT
                        UNITID,
                        year,
                        varnumber,
                        source_file,
                        CAST(COUNT(DISTINCT value_norm) AS BIGINT) AS distinct_values
                    FROM year_scalar_long_raw
                    GROUP BY 1, 2, 3, 4
                    HAVING COUNT(DISTINCT value_norm) > 1
                """
                if args.profile_year == year:
                    write_explain_artifact(
                        con,
                        profile_dir=profile_dir,
                        year=year,
                        label="scalar_conflict_monolithic",
                        query=monolithic_conflict_sql,
                        analyze=args.profile_analyze,
                    )
                create_empty_year_scalar_conflict_keys(con)
                con.execute(f"INSERT INTO year_scalar_conflict_keys {monolithic_conflict_sql}")
                conflict_key_count = scalar_int(con, "SELECT COUNT(*) FROM year_scalar_conflict_keys")
            conflict_key_count = scalar_int(con, "SELECT COUNT(*) FROM year_scalar_conflict_keys")
            log_phase(f"year {year} scalar conflict scan end", conflict_keys=conflict_key_count)
            if conflict_key_count:
                remaining = max(int(args.scalar_conflicts_max_rows) - scalar_conflict_rows_written, 0)
                if remaining > 0:
                    conflict_df = con.execute(
                        f"""
                        SELECT
                            s.UNITID,
                            s.year,
                            s.varname,
                            s.value,
                            s.varnumber,
                            s.source_file,
                            k.distinct_values
                        FROM year_scalar_long_raw s
                        INNER JOIN year_scalar_conflict_keys k
                          ON s.UNITID = k.UNITID
                         AND s.year = k.year
                         AND s.varnumber = k.varnumber
                         AND s.source_file = k.source_file
                        ORDER BY s.year, s.UNITID, s.varnumber, s.source_file, s.row_id
                        LIMIT {remaining}
                        """
                    ).fetchdf()
                    if not conflict_df.empty:
                        scalar_conflict_frames.append(conflict_df)
                        scalar_conflict_rows_written += len(conflict_df)
            con.execute(
                """
                CREATE OR REPLACE TEMP TABLE year_scalar_long_clean AS
                SELECT
                    s.row_id,
                    s.UNITID,
                    s.year,
                    s.varname,
                    s.value,
                    s.value_norm,
                    s.source_file,
                    s.varnumber
                FROM year_scalar_long_raw s
                LEFT JOIN year_scalar_conflict_keys k
                  ON s.UNITID = k.UNITID
                 AND s.year = k.year
                 AND s.varnumber = k.varnumber
                 AND s.source_file = k.source_file
                WHERE k.UNITID IS NULL
                """
            )
            con.execute(
                """
                CREATE OR REPLACE TEMP TABLE year_analysis_source AS
                SELECT row_id, UNITID, year, varname, value, value_norm, source_file, varnumber
                FROM year_scalar_long_clean
                """
            )
            if args.scalar_long_out:
                scalar_year_path = os.path.join(str(scalar_parts_dir), f"year={year}", "part.parquet")
                _, _, wrote_scalar = append_rowid_windowed_parquet(
                    con,
                    source_table="year_scalar_long_clean",
                    select_columns=["UNITID", "year", "varname", "value", "varnumber", "source_file"],
                    out_path=scalar_year_path,
                    writer=None,
                    schema=None,
                    rows_per_batch=int(args.scan_batch_rows),
                )
                if wrote_scalar:
                    scalar_part_paths.append(scalar_year_path)
            if conflict_key_count and args.fail_on_scalar_conflicts:
                if runtime.scalar_conflicts_out and scalar_conflict_frames:
                    out_df = pd.concat(scalar_conflict_frames, ignore_index=True)
                    Path(runtime.scalar_conflicts_out).parent.mkdir(parents=True, exist_ok=True)
                    out_df.to_csv(runtime.scalar_conflicts_out, index=False)
                    register_df_as_table(con, "qa.scalar_conflicts", out_df)
                raise SystemExit(f"scalar conflict gate failed for year={year}: conflict_keys={conflict_key_count}")
            year_source_table = "year_analysis_source"
        else:
            con.execute(
                """
                CREATE OR REPLACE TEMP TABLE year_analysis_source AS
                SELECT row_id, UNITID, year, varname, value, value_norm, source_file, varnumber
                FROM year_long_base
                """
            )
            year_source_table = "year_analysis_source"

        if args.collapse_disc and group_to_vars:
            con.execute(
                f"""
                CREATE OR REPLACE TEMP TABLE year_disc_active AS
                SELECT
                    row_id,
                    UNITID,
                    year,
                    varname,
                    value,
                    value_norm,
                    source_file,
                    varnumber,
                    base,
                    suffix,
                    is_active
                FROM (
                    SELECT
                        a.row_id,
                        a.UNITID,
                        a.year,
                        a.varname,
                        a.value,
                        a.value_norm,
                        a.source_file,
                        a.varnumber,
                        m.base,
                        m.suffix,
                        CASE
                            WHEN a.value_norm IS NULL THEN FALSE
                            WHEN TRY_CAST(a.value_norm AS DOUBLE) IS NOT NULL THEN TRY_CAST(a.value_norm AS DOUBLE) <> 0
                            WHEN lower(a.value_norm) IN ('y', 'yes', 't', 'true') THEN TRUE
                            WHEN lower(a.value_norm) IN ('n', 'no', 'f', 'false') THEN FALSE
                            ELSE TRUE
                        END AS is_active,
                        ROW_NUMBER() OVER (
                            PARTITION BY a.UNITID, a.year, m.base, m.suffix
                            ORDER BY a.row_id
                        ) AS _rn
                    FROM {year_source_table} a
                    INNER JOIN stage.disc_map m
                      ON a.varname = m.varname
                    WHERE a.value_norm IS NOT NULL
                )
                WHERE is_active
                  AND _rn = 1
                """
            )
            con.execute(
                """
                CREATE OR REPLACE TEMP TABLE year_disc_choice AS
                SELECT
                    UNITID,
                    year,
                    base,
                    COUNT(DISTINCT suffix) AS n_active,
                    MIN(suffix) AS chosen_suffix
                FROM year_disc_active
                GROUP BY 1, 2, 3
                """
            )
            if args.disc_qc_dir and scalar_int(con, "SELECT COUNT(*) FROM year_disc_choice WHERE n_active > 1") > 0:
                detail_total_rows = scalar_int(
                    con,
                    """
                    SELECT COUNT(*)
                    FROM year_disc_active a
                    INNER JOIN year_disc_choice c
                      ON a.UNITID = c.UNITID
                     AND a.year = c.year
                     AND a.base = c.base
                    WHERE c.n_active > 1
                    """,
                )
                summary_df = con.execute(
                    f"""
                    SELECT
                        CAST({int(year)} AS INTEGER) AS year,
                        a.source_file,
                        a.base AS variable_family,
                        'multiple_active_suffixes' AS conflict_type,
                        COUNT(*) AS row_count,
                        COUNT(DISTINCT CAST(a.UNITID AS VARCHAR) || '|' || CAST(a.year AS VARCHAR)) AS institution_year_rows,
                        MIN(c.n_active) AS min_n_active,
                        MAX(c.n_active) AS max_n_active,
                        COUNT(DISTINCT a.suffix) AS distinct_suffixes_observed,
                        CAST({int(detail_total_rows)} AS BIGINT) AS detail_rows_total,
                        CAST(LEAST({int(detail_total_rows)}, {int(args.disc_qc_detail_max_rows)}) AS BIGINT) AS detail_rows_written,
                        CAST({str(int(detail_total_rows > int(args.disc_qc_detail_max_rows))).upper()} AS BOOLEAN) AS detail_truncated
                    FROM year_disc_active a
                    INNER JOIN year_disc_choice c
                      ON a.UNITID = c.UNITID
                     AND a.year = c.year
                     AND a.base = c.base
                    WHERE c.n_active > 1
                    GROUP BY 1, 2, 3, 4
                    ORDER BY row_count DESC, source_file, variable_family
                    """
                ).fetchdf()
                if not summary_df.empty:
                    summary_df["expected_pattern"] = summary_df.apply(
                        lambda row: is_expected_disc_conflict(row["source_file"], row["variable_family"]),
                        axis=1,
                    )
                    summary_df["signal_level"] = summary_df.apply(
                        lambda row: (
                            "expected"
                            if bool(row["expected_pattern"])
                            else (
                                "high"
                                if int(row["row_count"]) >= int(args.disc_qc_high_signal_min_rows)
                                else "low"
                            )
                        ),
                        axis=1,
                    )
                    summary_df["high_signal"] = summary_df["signal_level"].eq("high")
                disc_conflict_summary_frames.append(summary_df)
                summary_path = os.path.join(args.disc_qc_dir, f"disc_conflicts_summary_{year}.csv")
                summary_df.to_csv(summary_path, index=False)
                write_query_csv(
                    con,
                    f"""
                    SELECT
                        a.UNITID,
                        a.year,
                        a.varname,
                        a.value,
                        a.source_file,
                        a.varnumber,
                        a.base,
                        a.suffix,
                        a.is_active,
                        c.n_active
                    FROM year_disc_active a
                    INNER JOIN year_disc_choice c
                      ON a.UNITID = c.UNITID
                     AND a.year = c.year
                     AND a.base = c.base
                    WHERE c.n_active > 1
                    ORDER BY a.row_id
                    LIMIT {int(args.disc_qc_detail_max_rows)}
                    """,
                    os.path.join(args.disc_qc_dir, f"disc_conflicts_{year}.csv"),
                )
            offset = scalar_int(con, f"SELECT COALESCE(MAX(row_id), 0) FROM {year_source_table}")
            con.execute(
                f"""
                CREATE OR REPLACE TEMP TABLE year_disc_collapsed AS
                SELECT
                    {offset} + ROW_NUMBER() OVER (ORDER BY c.year, c.UNITID, c.base) AS row_id,
                    c.UNITID,
                    c.year,
                    n.output_varname AS varname,
                    c.chosen_suffix AS value,
                    c.chosen_suffix AS value_norm,
                    '' AS source_file,
                    '' AS varnumber
                FROM year_disc_choice c
                INNER JOIN stage.disc_output_names n
                  ON c.base = n.base
                WHERE c.n_active = 1
                """
            )
            component_filter = ""
            if args.drop_disc_components and component_vars:
                component_filter = f"WHERE varname NOT IN ({sql_upper_in(component_vars)})"
            con.execute(
                f"""
                CREATE OR REPLACE TEMP VIEW year_analysis_pre_dedup AS
                SELECT * FROM {year_source_table}
                {component_filter}
                UNION ALL
                SELECT * FROM year_disc_collapsed
                """
            )
        else:
            con.execute(f"CREATE OR REPLACE TEMP VIEW year_analysis_pre_dedup AS SELECT * FROM {year_source_table}")

        con.execute(
            """
            CREATE OR REPLACE TEMP TABLE year_dup_groups AS
            SELECT
                year,
                UNITID,
                varname,
                COUNT(*) AS dup_rows
            FROM year_analysis_pre_dedup
            GROUP BY 1, 2, 3
            HAVING COUNT(*) > 1
            """
        )
        dup_count = scalar_int(con, "SELECT COALESCE(SUM(dup_rows), 0) FROM year_dup_groups")
        if args.dups_qc_dir and args.dups_max_rows > 0 and dup_count > 0:
            Path(args.dups_qc_dir).mkdir(parents=True, exist_ok=True)
            ext = ".csv.gz" if args.dups_qc_gzip else ".csv"
            compression = "gzip" if args.dups_qc_gzip else None
            dup_df = con.execute(
                f"""
                SELECT
                    p.UNITID,
                    p.year,
                    p.varname,
                    p.value,
                    p.varnumber,
                    p.source_file
                FROM year_analysis_pre_dedup p
                INNER JOIN year_dup_groups g
                  ON p.year = g.year
                 AND p.UNITID = g.UNITID
                 AND p.varname = g.varname
                ORDER BY p.row_id
                LIMIT {int(args.dups_max_rows)}
                """
            ).fetchdf()
            dup_df.to_csv(os.path.join(args.dups_qc_dir, f"dups_{year}{ext}"), index=False, compression=compression)

        con.execute(
            """
            CREATE OR REPLACE TEMP TABLE year_analysis_final AS
            SELECT row_id, UNITID, year, varname, value, value_norm, source_file, varnumber
            FROM (
                SELECT
                    *,
                    ROW_NUMBER() OVER (
                        PARTITION BY UNITID, year, varname
                        ORDER BY row_id
                    ) AS _rn
                FROM year_analysis_pre_dedup
            )
            WHERE _rn = 1
            """
        )
        concept_rows = scalar_int(con, "SELECT COUNT(*) FROM year_analysis_final")
        log_phase(f"year {year} concept done", rows=concept_rows)

        log_phase(f"year {year} pivot start")
        con.execute(f"CREATE OR REPLACE TEMP TABLE year_wide_raw AS {build_wide_query(all_targets, 'year_analysis_final', 'year_spine')}")
        if args.typed_output:
            con.execute(f"CREATE OR REPLACE TEMP TABLE year_wide AS {build_typed_wide_query(all_targets, numeric_targets, 'year_wide_raw')}")
        else:
            con.execute("CREATE OR REPLACE TEMP TABLE year_wide AS SELECT * FROM year_wide_raw ORDER BY year, UNITID")
        wide_rows = scalar_int(con, "SELECT COUNT(*) FROM year_wide")
        log_phase(f"year {year} pivot end", rows=wide_rows)

        out_path = os.path.join(args.out_dir, f"year={year}", "part.parquet")
        copy_query_to_parquet(con, "SELECT * FROM year_wide ORDER BY UNITID", out_path)
        year_part_paths.append(out_path)
        print(f"[info] wrote {out_path}", flush=True)
        log_phase(f"year {year} write complete", path=out_path, rows=wide_rows)

        if args.dim_long_out and dim_export_clauses:
            dim_bucket_count = int(args.scalar_conflict_buckets) if int(args.scalar_conflict_buckets) > 1 and int(year) >= int(args.scalar_conflict_bucket_min_year) else 1
            log_phase(
                f"year {year} dim export start",
                strategy="bucketed" if dim_bucket_count > 1 else "monolithic",
                buckets=dim_bucket_count,
            )
            dim_year_path = os.path.join(str(dim_parts_dir), f"year={year}", "part.parquet")
            dim_writer = None
            dim_schema = None
            wrote_dim = False
            try:
                if dim_bucket_count > 1:
                    dim_bucket_expr = build_hash_bucket_expr(tuple(dedupe_partition), dim_bucket_count)
                    for bucket_id in range(dim_bucket_count):
                        bucket_query = f"""
                            SELECT UNITID, year, varname, value, varnumber, source_file
                            FROM (
                                SELECT DISTINCT
                                    UNITID,
                                    year,
                                    varname,
                                    value,
                                    value_norm,
                                    varnumber,
                                    source_file
                                FROM stage.long_selected
                                {build_where_sql(dim_export_clauses + [f"({dim_bucket_expr}) = {bucket_id}"])}
                            ) q
                        """
                        dim_writer, dim_schema, wrote_bucket = append_query_to_parquet(
                            con,
                            bucket_query,
                            dim_year_path,
                            writer=dim_writer,
                            schema=dim_schema,
                            rows_per_batch=int(args.scan_batch_rows),
                        )
                        wrote_dim = wrote_dim or wrote_bucket
                else:
                    dim_query = f"""
                        SELECT UNITID, year, varname, value, varnumber, source_file
                        FROM (
                            SELECT DISTINCT
                                UNITID,
                                year,
                                varname,
                                value,
                                value_norm,
                                varnumber,
                                source_file
                            FROM stage.long_selected
                            {build_where_sql(dim_export_clauses)}
                        ) q
                    """
                    dim_writer, dim_schema, wrote_dim = append_query_to_parquet(
                        con,
                        dim_query,
                        dim_year_path,
                        writer=None,
                        schema=None,
                        rows_per_batch=int(args.scan_batch_rows),
                    )
            finally:
                if dim_writer is not None:
                    dim_writer.close()
            if wrote_dim:
                dim_part_paths.append(dim_year_path)
            log_phase(f"year {year} dim export end", wrote_part=bool(wrote_dim), path=dim_year_path if wrote_dim else "")

        if args.typed_output:
            numeric_target_list = [t for t in all_targets if t in numeric_targets]
            for start_idx in range(0, len(numeric_target_list), 250):
                cast_query = build_cast_report_query(
                    numeric_target_list[start_idx : start_idx + 250],
                    source_table="year_wide_raw",
                )
                if not cast_query:
                    continue
                year_cast_df = con.execute(cast_query).fetchdf()
                if not year_cast_df.empty:
                    cast_report_frames.append(year_cast_df)

        non_empty_values = scalar_int(con, "SELECT COUNT(*) FROM year_analysis_final WHERE value_norm IS NOT NULL")
        possible = spine_rows * len(all_targets) if spine_rows and all_targets else 0
        fill_rate = (non_empty_values / possible) if possible else 0.0
        qc_rows.append(
            {
                "year": int(year),
                "rows": int(spine_rows),
                "vars": int(len(all_targets)),
                "non_empty_values": int(non_empty_values),
                "fill_rate": float(fill_rate),
                "dup_rows": int(dup_count),
            }
        )

    if scalar_part_paths and args.scalar_long_out:
        stitch_parquet_files(scalar_part_paths, args.scalar_long_out)
        print(f"[info] wrote scalar long lane: {args.scalar_long_out}", flush=True)
    if dim_part_paths and args.dim_long_out:
        stitch_parquet_files(dim_part_paths, args.dim_long_out)
        print(f"[info] wrote dimensioned long lane: {args.dim_long_out}", flush=True)

    if scalar_conflict_frames:
        scalar_conflicts_df = pd.concat(scalar_conflict_frames, ignore_index=True)
        if runtime.scalar_conflicts_out:
            Path(runtime.scalar_conflicts_out).parent.mkdir(parents=True, exist_ok=True)
            scalar_conflicts_df.to_csv(runtime.scalar_conflicts_out, index=False)
            print(f"[info] wrote scalar conflict QC: {runtime.scalar_conflicts_out}", flush=True)
        register_df_as_table(con, "qa.scalar_conflicts", scalar_conflicts_df)

    if cast_report_frames:
        cast_report_df = pd.concat(cast_report_frames, ignore_index=True)
        register_df_as_table(con, "qa.cast_report", cast_report_df)
        if runtime.cast_report_out:
            Path(runtime.cast_report_out).parent.mkdir(parents=True, exist_ok=True)
            cast_report_df.to_csv(runtime.cast_report_out, index=False)
            print(f"[info] wrote cast report QC: {runtime.cast_report_out}", flush=True)

    if disc_conflict_summary_frames and args.disc_qc_dir:
        disc_summary_df = pd.concat(disc_conflict_summary_frames, ignore_index=True)
        disc_summary_path = Path(args.disc_qc_dir) / "disc_conflicts_summary_all_years.csv"
        disc_summary_df.to_csv(disc_summary_path, index=False)
        register_df_as_table(con, "qa.disc_conflicts_summary", disc_summary_df)
        print(f"[info] wrote disc conflict summary QC: {disc_summary_path}", flush=True)

    if qc_rows:
        qc_df = pd.DataFrame(qc_rows)
        register_df_as_table(con, "qa.wide_year_summary", qc_df)

    if args.write_single:
        Path(args.write_single).parent.mkdir(parents=True, exist_ok=True)
        drop_post_cols: set[str] = set()
        if args.drop_globally_null_post and all_targets:
            non_null_counts = {name: 0 for name in all_targets}
            for part_path in year_part_paths:
                pf = pq.ParquetFile(part_path)
                for batch in pf.iter_batches():
                    schema_names = batch.schema.names
                    for name in non_null_counts:
                        if name not in schema_names:
                            continue
                        arr = batch.column(schema_names.index(name))
                        non_null_counts[name] += int(len(arr) - arr.null_count)
            drop_post_cols = {name for name, cnt in non_null_counts.items() if cnt == 0}
            if drop_post_cols and args.qc_dir:
                qc_globally_null = Path(args.qc_dir) / "qc_globally_null_columns_dropped.csv"
                pd.DataFrame({"column": sorted(drop_post_cols)}).to_csv(qc_globally_null, index=False)
                print(f"[info] wrote globally-null drop QC: {qc_globally_null}", flush=True)
        keep_cols = ["year", "UNITID"] + [t for t in all_targets if t not in drop_post_cols]
        log_phase("stitched write start", output=args.write_single, columns=len(keep_cols))
        writer = None
        for part_path in year_part_paths:
            table = pq.ParquetFile(part_path).read()
            if drop_post_cols:
                table = table.select([c for c in table.schema.names if c not in drop_post_cols])
            if writer is None:
                writer = pq.ParquetWriter(args.write_single, table.schema, compression="snappy")
            writer.write_table(table)
        if writer is not None:
            writer.close()
        if drop_post_cols:
            print(f"[info] dropping {len(drop_post_cols)} globally-null columns in stitched output", flush=True)
        log_phase("stitched write end", output=args.write_single)

    if args.qc_dir and qc_rows:
        qc_df.to_csv(os.path.join(args.qc_dir, "wide_panel_qc_summary.csv"), index=False)
        log_phase("qc write end", qc_dir=args.qc_dir)
