#!/usr/bin/env python3
"""
Stage 01: download annual IPEDS Access database packages from NCES.

Reads:
- `contracts/source_releases.csv` in release-strict mode
- the NCES Access-database release page in development discovery mode

Writes:
- `Raw_Access_Databases/<year>/downloads/*`
- `Raw_Access_Databases/<year>/manifest.csv`
- `Checks/download_qc/*`

Release-strict builds resolve URLs and expected bytes from the reviewed source
lock. Development discovery may inspect the live NCES page, but its observed
hashes are not release approval.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import tempfile
import tomllib
from urllib.parse import urljoin, urlparse
import zipfile

import requests
from bs4 import BeautifulSoup

from access_build_utils import (
    academic_year_to_start_year,
    compute_file_metadata,
    ensure_data_layout,
    parse_years,
    repo_root,
    validate_file_integrity,
)


BASE_URL = "https://nces.ed.gov"
ACCESS_PAGE_URL = "https://nces.ed.gov/ipeds/use-the-data/download-access-database"
USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
)
DEFAULT_SOURCE_LOCK = repo_root() / "contracts" / "source_releases.csv"
LOCK_IDENTITY_FIELDS = (
    "academic_year_label",
    "release_type",
    "release_date_text",
    "access_url",
    "access_filename",
    "doc_url",
    "doc_filename",
)
SOURCE_LOCK_REQUIRED_COLUMNS = {
    "contract_id",
    "year",
    "academic_year_label",
    "release_type",
    "release_date_text",
    "access_url",
    "access_filename",
    "expected_access_sha256",
    "access_size_bytes",
    "documentation_url",
    "documentation_filename",
    "expected_documentation_sha256",
    "documentation_size_bytes",
    "lock_status",
    "source",
    "approved_at",
    "review_note",
}


def current_contract_id() -> str:
    contract_path = repo_root() / "contracts" / "panel_spec.toml"
    with contract_path.open("rb") as fh:
        return str(tomllib.load(fh).get("contract_id", "")).strip()


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=None, help="External IPEDSDB_ROOT")
    ap.add_argument("--years", default=None, help='Year span, default is discovered "2004:latest_final"')
    ap.add_argument("--skip-existing", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--timeout", type=int, default=120)
    ap.add_argument("--final-only", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--source-lock", default=str(DEFAULT_SOURCE_LOCK))
    ap.add_argument(
        "--release-strict",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Require an approved source-lock row with exact hashes and sizes for every requested year.",
    )
    return ap.parse_args()


def fetch_page(session: requests.Session, timeout: int) -> str:
    response = session.get(ACCESS_PAGE_URL, timeout=timeout)
    response.raise_for_status()
    return response.text


def basename_from_url(url: str) -> str:
    return Path(urlparse(url).path).name


def parse_access_release_table(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    out: list[dict] = []
    for row in soup.select("table tr"):
        cells = row.find_all("td")
        if len(cells) < 4:
            continue
        access_link = cells[0].find("a", href=True)
        doc_link = cells[1].find("a", href=True)
        if access_link is None or doc_link is None:
            continue
        academic_year_label = access_link.get_text(" ", strip=True).replace(" Access", "").strip()
        release_type = cells[2].get_text(" ", strip=True)
        release_date_text = cells[3].get_text(" ", strip=True)
        access_url = urljoin(BASE_URL, access_link["href"])
        doc_url = urljoin(BASE_URL, doc_link["href"])
        out.append(
            {
                "year": academic_year_to_start_year(academic_year_label),
                "academic_year_label": academic_year_label,
                "release_type": release_type,
                "release_date_text": release_date_text,
                "access_url": access_url,
                "access_filename": basename_from_url(access_url),
                "doc_url": doc_url,
                "doc_filename": basename_from_url(doc_url),
            }
        )
    return sorted(out, key=lambda row: (int(row["year"]), row["release_type"], row["academic_year_label"]))


def write_rows(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".part", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def validate_archive_container(path: Path, *, artifact_name: str | None = None) -> None:
    suffix = Path(artifact_name or path.name).suffix.lower()
    if suffix not in {".zip", ".xlsx"}:
        return
    try:
        with zipfile.ZipFile(path, "r") as archive:
            if not archive.infolist():
                raise ValueError("archive contains no members")
            bad_member = archive.testzip()
            if bad_member is not None:
                raise ValueError(f"CRC failure in {bad_member!r}")
    except (OSError, ValueError, zipfile.BadZipFile) as exc:
        raise ValueError(f"Downloaded artifact is not a valid ZIP container for {path}: {exc}") from exc


def download_file(
    session: requests.Session,
    url: str,
    destination: Path,
    timeout: int,
    *,
    expected_size: str | int | None = None,
    expected_sha256: str | None = None,
) -> tuple[str, str]:
    """Stream to a sibling temporary file, validate it, then atomically replace."""
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.name}.", suffix=".part", dir=destination.parent
    )
    temporary = Path(temporary_name)
    try:
        received_bytes = 0
        response_content_length: int | None = None
        with os.fdopen(fd, "wb") as fh:
            with session.get(url, stream=True, timeout=timeout) as response:
                response.raise_for_status()
                headers = getattr(response, "headers", {}) or {}
                content_encoding = str(headers.get("Content-Encoding", "")).strip()
                content_length_text = str(headers.get("Content-Length", "")).strip()
                if content_length_text and not content_encoding:
                    try:
                        response_content_length = int(content_length_text)
                    except ValueError as exc:
                        raise ValueError(
                            f"Invalid HTTP Content-Length for {url}: {content_length_text!r}"
                        ) from exc
                for chunk in response.iter_content(chunk_size=65536):
                    if chunk:
                        fh.write(chunk)
                        received_bytes += len(chunk)
            fh.flush()
            os.fsync(fh.fileno())
        if response_content_length is not None and received_bytes != response_content_length:
            raise ValueError(
                f"HTTP Content-Length mismatch for {url}: expected {response_content_length}, "
                f"received {received_bytes}"
            )
        observed = validate_file_integrity(
            temporary,
            expected_size=expected_size,
            expected_sha256=expected_sha256,
        )
        validate_archive_container(temporary, artifact_name=destination.name)
        os.replace(temporary, destination)
        return observed
    finally:
        temporary.unlink(missing_ok=True)


def load_source_lock(path: str | Path) -> dict[int, dict[str, str]]:
    fp = Path(path).expanduser()
    if not fp.is_file():
        return {}
    with fp.open(newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        header = set(reader.fieldnames or [])
        missing = sorted(SOURCE_LOCK_REQUIRED_COLUMNS - header)
        if missing:
            raise ValueError(f"Source lock is missing required columns: {', '.join(missing)}")
        rows = [{str(key): str(value or "").strip() for key, value in row.items()} for row in reader]
    by_year: dict[int, dict[str, str]] = {}
    for row in rows:
        row["access_sha256"] = row.get("expected_access_sha256", "")
        row["doc_url"] = row.get("documentation_url", "")
        row["doc_filename"] = row.get("documentation_filename", "")
        row["doc_sha256"] = row.get("expected_documentation_sha256", "")
        row["doc_size_bytes"] = row.get("documentation_size_bytes", "")
        year_text = row.get("year", "")
        if not year_text:
            continue
        year = int(year_text)
        if year in by_year:
            raise ValueError(f"Duplicate source-lock row for year {year}: {fp}")
        by_year[year] = row
    return by_year


def validate_locked_release(
    discovered: dict,
    locked: dict[str, str],
    *,
    release_strict: bool,
) -> None:
    """Validate source identity and the independent integrity expectations."""
    year = int(discovered["year"])
    locked_year = str(locked.get("year", year)).strip()
    if locked_year and int(locked_year) != year:
        raise ValueError(f"Source-lock year mismatch: discovered {year}, locked {locked_year}")
    for field in LOCK_IDENTITY_FIELDS:
        observed = str(discovered.get(field, "")).strip()
        expected = str(locked.get(field, "")).strip()
        if expected and observed != expected:
            raise ValueError(
                f"Source-lock {field} mismatch for year {year}: expected {expected!r}, discovered {observed!r}"
            )
        if release_strict and not expected:
            raise ValueError(f"Source-lock field {field} is required for release year {year}")
    if release_strict:
        expected_contract_id = current_contract_id()
        if str(locked.get("contract_id", "")).strip() != expected_contract_id:
            raise ValueError(
                f"Source-lock contract_id must match {expected_contract_id!r} for year {year}"
            )
        if str(locked.get("lock_status", "")).strip().lower() != "approved":
            raise ValueError(f"Source-lock lock_status must be approved for year {year}")
        for field in ("source", "approved_at", "review_note"):
            if not str(locked.get(field, "")).strip():
                raise ValueError(f"Source-lock field {field} is required for release year {year}")
        for artifact in ("access", "doc"):
            url = str(locked.get(f"{artifact}_url", "")).strip()
            filename = str(locked.get(f"{artifact}_filename", "")).strip()
            parsed_url = urlparse(url)
            if parsed_url.scheme.lower() != "https" or not parsed_url.hostname:
                raise ValueError(f"Source-lock {artifact}_url must be an HTTPS URL for year {year}: {url!r}")
            if Path(filename).name != filename or basename_from_url(url) != filename:
                raise ValueError(
                    f"Source-lock {artifact}_filename must be a safe URL basename for year {year}: {filename!r}"
                )

    integrity_fields = (
        ("access_size_bytes", "access_sha256"),
        ("doc_size_bytes", "doc_sha256"),
    )
    for size_field, sha_field in integrity_fields:
        size_text = str(locked.get(size_field, "")).strip()
        sha_text = str(locked.get(sha_field, "")).strip().lower()
        if bool(size_text) != bool(sha_text):
            raise ValueError(
                f"Source-lock {size_field} and {sha_field} must be provided together for year {year}"
            )
        if release_strict and (not size_text or not sha_text):
            raise ValueError(f"Source lock must contain complete SHA-256 and size expectations for year {year}")
        if size_text:
            try:
                if int(size_text) <= 0:
                    raise ValueError
            except ValueError as exc:
                raise ValueError(f"Invalid source-lock {size_field} for year {year}: {size_text!r}") from exc
        if sha_text and not re.fullmatch(r"[0-9a-f]{64}", sha_text):
            raise ValueError(f"Invalid source-lock {sha_field} for year {year}: {sha_text!r}")


def read_single_manifest(path: Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    with path.open(newline="", encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    if len(rows) != 1:
        return {}
    return {str(key): str(value or "").strip() for key, value in rows[0].items()}


def cached_download_is_verified(
    path: Path,
    *,
    discovered: dict,
    previous_manifest: dict[str, str],
    locked: dict[str, str] | None,
    artifact: str,
) -> bool:
    if not path.is_file():
        return False
    if artifact == "access":
        manifest_size_field = "access_zip_filesize_bytes"
        manifest_sha_field = "access_zip_sha256"
    elif artifact == "doc":
        manifest_size_field = "doc_filesize_bytes"
        manifest_sha_field = "doc_sha256"
    else:
        raise ValueError(f"Unsupported artifact kind: {artifact}")

    expected_size = str((locked or {}).get(f"{artifact}_size_bytes", "")).strip()
    expected_sha = str((locked or {}).get(f"{artifact}_sha256", "")).strip()
    if not expected_size or not expected_sha:
        if previous_manifest.get(f"{artifact}_url", "") != str(discovered[f"{artifact}_url"]):
            return False
        if previous_manifest.get(f"{artifact}_filename", "") != str(discovered[f"{artifact}_filename"]):
            return False
        expected_size = previous_manifest.get(manifest_size_field, "")
        expected_sha = previous_manifest.get(manifest_sha_field, "")
    if not expected_size or not expected_sha:
        return False
    try:
        validate_file_integrity(path, expected_size=expected_size, expected_sha256=expected_sha)
        validate_archive_container(path)
    except (FileNotFoundError, ValueError):
        return False
    return True


def main() -> None:
    args = parse_args()
    if not args.final_only:
        raise SystemExit("v1 only supports --final-only")

    layout = ensure_data_layout(args.root)
    qc_dir = layout.checks / "download_qc"
    qc_dir.mkdir(parents=True, exist_ok=True)

    source_lock_path = Path(args.source_lock).expanduser()
    source_lock = load_source_lock(source_lock_path)
    source_lock_size = ""
    source_lock_sha = ""
    if source_lock_path.is_file():
        source_lock_size, source_lock_sha = validate_file_integrity(source_lock_path)
    contract_id = current_contract_id()
    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT})

    if args.release_strict:
        if not source_lock:
            raise SystemExit(f"Release-strict acquisition requires a populated source lock: {source_lock_path}")
        requested_years = parse_years(args.years) if args.years else sorted(source_lock)
        missing_lock_years = [year for year in requested_years if year not in source_lock]
        if missing_lock_years:
            raise SystemExit(
                f"Release-strict acquisition is missing source-lock rows for years: {missing_lock_years}"
            )
        all_entries = []
        for year in requested_years:
            row: dict[str, object] = dict(source_lock[year])
            row["year"] = year
            row.setdefault("release_date_text", "")
            validate_locked_release(row, source_lock[year], release_strict=True)
            if str(row.get("release_type", "")).strip().lower() != "final":
                raise SystemExit(f"Release-strict source-lock row is not Final for year {year}")
            all_entries.append(row)
    else:
        html = fetch_page(session, args.timeout)
        all_entries = parse_access_release_table(html)
        if not all_entries:
            raise SystemExit(f"No Access releases parsed from {ACCESS_PAGE_URL}")

    inventory_fields = [
        "year",
        "academic_year_label",
        "release_type",
        "release_date_text",
        "access_url",
        "access_filename",
        "doc_url",
        "doc_filename",
    ]
    write_rows(qc_dir / "release_inventory.csv", all_entries, inventory_fields)

    final_entries = [row for row in all_entries if str(row["release_type"]).strip().lower() == "final"]
    if not final_entries:
        raise SystemExit("No Final Access releases are available from the configured source")
    latest_final = max(int(row["year"]) for row in final_entries)
    if not args.release_strict:
        requested_years = parse_years(args.years) if args.years else list(range(2004, latest_final + 1))

    final_by_year: dict[int, list[dict]] = {}
    for row in final_entries:
        final_by_year.setdefault(int(row["year"]), []).append(row)

    duplicate_rows = []
    for year, rows in sorted(final_by_year.items()):
        if len(rows) > 1:
            duplicate_rows.extend(rows)
    if duplicate_rows:
        write_rows(qc_dir / "duplicate_final_entries.csv", duplicate_rows, inventory_fields)
        raise SystemExit("Duplicate final Access entries detected on the NCES page.")

    missing_years = [year for year in requested_years if year not in final_by_year]
    write_rows(qc_dir / "missing_years.csv", [{"year": year} for year in missing_years], ["year"])
    if missing_years:
        raise SystemExit(f"Missing requested final Access releases for years: {missing_years}")

    for year in requested_years:
        locked = source_lock.get(year)
        if args.release_strict and locked is None:
            raise SystemExit(
                f"Release-strict acquisition requires an approved source-lock row for year {year}: "
                f"{source_lock_path}"
            )
        if locked is not None:
            try:
                validate_locked_release(final_by_year[year][0], locked, release_strict=args.release_strict)
            except ValueError as exc:
                raise SystemExit(str(exc)) from exc

    manifest_fields = [
        "contract_id",
        "year",
        "academic_year_label",
        "release_type",
        "release_date_text",
        "access_url",
        "access_filename",
        "access_zip_filesize_bytes",
        "access_zip_sha256",
        "doc_url",
        "doc_filename",
        "doc_filesize_bytes",
        "doc_sha256",
        "source_lock_path",
        "source_lock_filesize_bytes",
        "source_lock_sha256",
        "source_lock_status",
        "access_expected_filesize_bytes",
        "access_expected_sha256",
        "doc_expected_filesize_bytes",
        "doc_expected_sha256",
        "download_status",
        "downloaded_at",
    ]

    failures: list[dict] = []
    for year in requested_years:
        row = dict(final_by_year[year][0])
        year_dir = layout.raw_access / str(year)
        downloads_dir = year_dir / "downloads"
        downloads_dir.mkdir(parents=True, exist_ok=True)

        access_path = downloads_dir / row["access_filename"]
        doc_path = downloads_dir / row["doc_filename"]
        manifest_path = year_dir / "manifest.csv"
        previous_manifest = read_single_manifest(manifest_path)
        locked = source_lock.get(year)
        access_expected_size = str((locked or {}).get("access_size_bytes", "")).strip()
        access_expected_sha = str((locked or {}).get("access_sha256", "")).strip()
        doc_expected_size = str((locked or {}).get("doc_size_bytes", "")).strip()
        doc_expected_sha = str((locked or {}).get("doc_sha256", "")).strip()
        lock_is_release_complete = bool(
            locked
            and access_expected_size
            and access_expected_sha
            and doc_expected_size
            and doc_expected_sha
            and str(locked.get("source", "")).strip()
            and str(locked.get("approved_at", "")).strip()
        )
        statuses: list[str] = []
        try:
            access_cached = args.skip_existing and cached_download_is_verified(
                access_path,
                discovered=row,
                previous_manifest=previous_manifest,
                locked=locked,
                artifact="access",
            )
            if access_cached:
                statuses.append("access_existing_verified")
            else:
                download_file(
                    session,
                    row["access_url"],
                    access_path,
                    args.timeout,
                    expected_size=access_expected_size,
                    expected_sha256=access_expected_sha,
                )
                statuses.append("access_downloaded_verified" if access_expected_sha else "access_downloaded_observed")

            doc_cached = args.skip_existing and cached_download_is_verified(
                doc_path,
                discovered=row,
                previous_manifest=previous_manifest,
                locked=locked,
                artifact="doc",
            )
            if doc_cached:
                statuses.append("doc_existing_verified")
            else:
                download_file(
                    session,
                    row["doc_url"],
                    doc_path,
                    args.timeout,
                    expected_size=doc_expected_size,
                    expected_sha256=doc_expected_sha,
                )
                statuses.append("doc_downloaded_verified" if doc_expected_sha else "doc_downloaded_observed")
            status = ";".join(statuses)
        except Exception as exc:  # noqa: BLE001
            status = "failed"
            failures.append({"year": year, "error": str(exc)})

        access_size, access_sha = compute_file_metadata(access_path)
        doc_size, doc_sha = compute_file_metadata(doc_path)
        manifest_row = {
            "contract_id": contract_id,
            "year": year,
            "academic_year_label": row["academic_year_label"],
            "release_type": row["release_type"],
            "release_date_text": row["release_date_text"],
            "access_url": row["access_url"],
            "access_filename": row["access_filename"],
            "access_zip_filesize_bytes": access_size,
            "access_zip_sha256": access_sha,
            "doc_url": row["doc_url"],
            "doc_filename": row["doc_filename"],
            "doc_filesize_bytes": doc_size,
            "doc_sha256": doc_sha,
            "source_lock_path": str(source_lock_path),
            "source_lock_filesize_bytes": source_lock_size,
            "source_lock_sha256": source_lock_sha,
            "source_lock_status": (
                "verified" if lock_is_release_complete else "not_release_approved_development_only"
            ),
            "access_expected_filesize_bytes": access_expected_size,
            "access_expected_sha256": access_expected_sha,
            "doc_expected_filesize_bytes": doc_expected_size,
            "doc_expected_sha256": doc_expected_sha,
            "download_status": status,
            "downloaded_at": datetime.now(timezone.utc).isoformat(),
        }
        write_rows(manifest_path, [manifest_row], manifest_fields)
        print(f"[year {year}] {status}: {access_path.name}, {doc_path.name}")

    write_rows(qc_dir / "download_failures.csv", failures, ["year", "error"])
    if failures:
        raise SystemExit(f"Download failures encountered for years: {[row['year'] for row in failures]}")

    print(f"Wrote release inventory to {qc_dir / 'release_inventory.csv'}")
    print(f"Resolved latest final year: {latest_final}")


if __name__ == "__main__":
    main()
