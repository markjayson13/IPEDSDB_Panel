#!/usr/bin/env python3
"""Stage 05: stitch v2 scalar, dimensioned, and source-row artifacts.

Stage 04 has already assigned every reviewed table to one lane.  This stage
does not reinterpret grain.  It concatenates each lane independently, proves
row-count equality, validates lane keys, and verifies that every long cell
still references its durable source-row record.
"""
from __future__ import annotations

import argparse
import atexit
from dataclasses import dataclass
import gc
import hashlib
import json
from pathlib import Path
import re
import stat
import uuid

import duckdb
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

from access_build_utils import ensure_data_layout, parse_years
from panel_v2_schema import (
    ALLOWED_SOURCE_LANES,
    ALLOWED_VALUE_STATUSES,
    DIMENSIONED_CELL_KEY,
    LONG_PANEL_SCHEMA,
    PANEL_CONTRACT_ID,
    SCALAR_CELL_KEY,
    SOURCE_ROW_KEY,
    SOURCE_ROW_SCHEMA,
)


CELL_REQUIRED_FIELDS = [
    "contract_id",
    "year",
    "UNITID",
    "variable_id",
    "source_file",
    "access_table_name",
    "source_row_id",
    "source_row_hash",
    "source_csv_sha256",
    "value_status",
]

DEFAULT_STITCH_BATCH_ROWS = 65_536
DEFAULT_KEY_VALIDATION_BATCH_ROWS = 200_000
DEFAULT_LINEAGE_VALIDATION_BATCH_ROWS = 100_000


@dataclass(frozen=True)
class DuckDBSettings:
    """Optional per-connection resource limits for bounded Stage 05 checks."""

    memory_limit: str | None = None
    threads: int | None = None
    temp_dir: Path | None = None


@dataclass(frozen=True)
class FileIdentity:
    """Filesystem identity used to detect mutation of recovered pending files."""

    device: int
    inode: int
    size: int
    mtime_ns: int
    sha256: str


def positive_int(value: str) -> int:
    parsed = int(value)
    if parsed < 1:
        raise argparse.ArgumentTypeError("must be at least 1")
    return parsed


def pending_run_id(value: str) -> str:
    if not re.fullmatch(r"[0-9a-f]{32}", value):
        raise argparse.ArgumentTypeError("must be exactly 32 lowercase hexadecimal characters")
    return value


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=None, help="External IPEDSDB_ROOT")
    ap.add_argument("--years", default="2004:2023")
    ap.add_argument("--cross-sections-dir", default=None)
    ap.add_argument("--output", default=None, help="Stitched scalar output (defaults to Panels/v2).")
    ap.add_argument("--dimensioned-output", default=None)
    ap.add_argument("--source-rows-output", default=None)
    ap.add_argument(
        "--duckdb-memory-limit",
        default=None,
        help="Optional DuckDB memory_limit for Stage 05 validation queries.",
    )
    ap.add_argument(
        "--duckdb-threads",
        type=positive_int,
        default=None,
        help="Optional DuckDB worker-thread limit; use 1 for minimum-memory execution.",
    )
    ap.add_argument(
        "--duckdb-temp-dir",
        default=None,
        help="External directory used for DuckDB spill files.",
    )
    ap.add_argument(
        "--batch-rows",
        type=positive_int,
        default=None,
        help=(
            "Override validation batch rows and, unless --stitch-batch-rows is "
            "set, parquet stitch batch rows. When omitted, the historical "
            "per-operation defaults are retained."
        ),
    )
    ap.add_argument(
        "--stitch-batch-rows",
        type=positive_int,
        default=None,
        help=(
            "Override only parquet stitch batch/row-group rows. This permits "
            "small validation batches without fragmenting compressed output."
        ),
    )
    ap.add_argument(
        "--resume-pending-run-id",
        type=pending_run_id,
        default=None,
        help=(
            "Recover one exact, complete Stage 05 pending artifact group after "
            "an interrupted post-write validation. Annual inputs and every "
            "post-write check are rerun; stitching alone is skipped."
        ),
    )
    return ap.parse_args()


def sql_quote(value: object) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def open_duckdb_connection(
    settings: DuckDBSettings | None = None,
) -> duckdb.DuckDBPyConnection:
    """Open a validation connection with identical bounded-resource settings."""
    settings = settings or DuckDBSettings()
    con = duckdb.connect()
    try:
        if settings.memory_limit:
            con.execute(f"SET memory_limit={sql_quote(settings.memory_limit)}")
        if settings.threads is not None:
            con.execute(f"SET threads={int(settings.threads)}")
        if settings.temp_dir is not None:
            settings.temp_dir.mkdir(parents=True, exist_ok=True)
            con.execute(f"SET temp_directory={sql_quote(settings.temp_dir)}")
    except BaseException:
        con.close()
        raise
    return con


def companion_output(output: Path, old_token: str, new_token: str) -> Path:
    if old_token in output.name:
        return output.with_name(output.name.replace(old_token, new_token, 1))
    return output.with_name(f"{output.stem}_{new_token}{output.suffix}")


def pending_artifact_path(target: Path, run_id: str) -> Path:
    target.parent.mkdir(parents=True, exist_ok=True)
    pending = target.with_name(f".{target.name}.pending-{run_id}")
    pending.unlink(missing_ok=True)
    atexit.register(pending.unlink, missing_ok=True)
    return pending


def pending_path_for(target: Path, run_id: str) -> Path:
    return target.with_name(f".{target.name}.pending-{run_id}")


def regular_file_identity(path: Path) -> FileIdentity:
    if path.is_symlink():
        raise SystemExit(f"Stage 05 pending artifact must not be a symlink: {path}")
    try:
        details = path.lstat()
    except FileNotFoundError as exc:
        raise SystemExit(f"Missing Stage 05 pending artifact: {path}") from exc
    if not stat.S_ISREG(details.st_mode):
        raise SystemExit(f"Stage 05 pending artifact must be a regular file: {path}")
    before = (
        int(details.st_dev),
        int(details.st_ino),
        int(details.st_size),
        int(details.st_mtime_ns),
    )
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    after_details = path.lstat()
    after = (
        int(after_details.st_dev),
        int(after_details.st_ino),
        int(after_details.st_size),
        int(after_details.st_mtime_ns),
    )
    if after != before:
        raise SystemExit(f"Stage 05 pending artifact changed while hashing: {path}")
    return FileIdentity(
        device=before[0],
        inode=before[1],
        size=before[2],
        mtime_ns=before[3],
        sha256=digest.hexdigest(),
    )


def resume_pending_artifact_group(
    outputs: dict[str, Path],
    run_id: str,
) -> tuple[dict[str, Path], dict[str, FileIdentity]]:
    pending = {
        label: pending_path_for(target, run_id)
        for label, target in outputs.items()
    }
    missing = [str(path) for path in pending.values() if not path.exists()]
    if missing:
        raise SystemExit(f"Cannot resume incomplete Stage 05 artifact set: {missing}")
    existing_finals = [str(target) for target in outputs.values() if target.exists()]
    if existing_finals:
        raise SystemExit(
            "Cannot resume Stage 05 over existing final artifacts: "
            f"{existing_finals}"
        )
    rollback_paths = [
        target.with_name(f".{target.name}.rollback-{run_id}")
        for target in outputs.values()
    ]
    existing_rollbacks = [str(path) for path in rollback_paths if path.exists()]
    if existing_rollbacks:
        raise SystemExit(
            "Cannot resume Stage 05 with stale rollback artifacts: "
            f"{existing_rollbacks}"
        )
    expected_paths = set(pending.values())
    actual_paths: set[Path] = set()
    for parent in {target.parent for target in outputs.values()}:
        actual_paths.update(parent.glob(f".*.pending-{run_id}"))
    extras = sorted(str(path) for path in actual_paths - expected_paths)
    if extras:
        raise SystemExit(
            "Cannot resume Stage 05 with unexpected pending artifacts: "
            f"{extras}"
        )
    identities: dict[str, FileIdentity] = {}
    for label, path in pending.items():
        print(f"Stage 05 recovery binding: hashing {label} pending artifact", flush=True)
        identity = regular_file_identity(path)
        identities[label] = identity
        print(
            f"Stage 05 recovery binding: {label} bytes={identity.size} "
            f"sha256={identity.sha256}",
            flush=True,
        )
    return pending, identities


def release_arrow_memory() -> None:
    """Return completed Arrow scan/writer pages before the next large phase."""
    gc.collect()
    pa.default_memory_pool().release_unused()


def promote_artifact_group(artifacts: list[tuple[Path, Path]], run_id: str) -> None:
    missing = [str(pending) for pending, _target in artifacts if not pending.exists()]
    if missing:
        raise SystemExit(f"Cannot promote incomplete Stage 05 artifact set: {missing}")
    backups: dict[Path, Path] = {}
    promoted: list[Path] = []
    try:
        for _pending, target in artifacts:
            backup = target.with_name(f".{target.name}.rollback-{run_id}")
            backup.unlink(missing_ok=True)
            if target.exists():
                target.replace(backup)
                backups[target] = backup
        for pending, target in artifacts:
            pending.replace(target)
            promoted.append(target)
    except BaseException:
        for target in reversed(promoted):
            target.unlink(missing_ok=True)
        for target, backup in backups.items():
            if backup.exists():
                backup.replace(target)
        raise
    else:
        for backup in backups.values():
            backup.unlink(missing_ok=True)


def validate_exact_schema(path: Path, expected: pa.Schema, label: str) -> None:
    actual = pq.ParquetFile(path).schema_arrow.remove_metadata()
    expected_clean = expected.remove_metadata()
    if not actual.equals(expected_clean, check_metadata=False):
        raise SystemExit(
            f"Per-year {label} schema does not match panel v2 contract: "
            f"path={path} expected={expected_clean} actual={actual}"
        )


def null_blank_counts(
    path: Path,
    columns: list[str],
    *,
    batch_rows: int | None = None,
) -> dict[str, int]:
    parquet = pq.ParquetFile(path)
    missing = [column for column in columns if column not in parquet.schema_arrow.names]
    if missing:
        raise SystemExit(f"Stitched artifact {path} is missing key columns: {', '.join(missing)}")
    counts = {column: 0 for column in columns}
    effective_batch_rows = batch_rows or DEFAULT_KEY_VALIDATION_BATCH_ROWS
    for batch in parquet.iter_batches(
        columns=columns,
        batch_size=effective_batch_rows,
        use_threads=False,
    ):
        names = list(batch.schema.names)
        for column in columns:
            array = batch.column(names.index(column))
            counts[column] += array.null_count
            if pa.types.is_string(array.type) or pa.types.is_large_string(array.type):
                counts[column] += int(pc.sum(pc.equal(pc.utf8_trim_whitespace(array), "")).as_py() or 0)
    return counts


def distinct_values(
    path: Path,
    column: str,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> list[object]:
    schema = pq.ParquetFile(path).schema_arrow
    if column not in schema.names:
        raise SystemExit(f"Stitched artifact {path} is missing column: {column}")
    quoted_column = '"' + column.replace('"', '""') + '"'
    con = open_duckdb_connection(duckdb_settings)
    try:
        rows = con.execute(
            f"SELECT DISTINCT {quoted_column} FROM read_parquet({sql_quote(path)}) "
            f"WHERE {quoted_column} IS NOT NULL"
        ).fetchall()
    finally:
        con.close()
    return [row[0] for row in rows]


def validate_stitched_panel(
    path: Path,
    expected_years: list[int],
    *,
    lane: str = "scalar",
    require_all_years: bool = True,
    duckdb_settings: DuckDBSettings | None = None,
    batch_rows: int | None = None,
) -> list[int]:
    years_seen = sorted(
        int(value)
        for value in distinct_values(path, "year", duckdb_settings=duckdb_settings)
    )
    if require_all_years and years_seen != expected_years:
        raise SystemExit(f"Stitched {lane} panel year coverage mismatch. expected={expected_years} actual={years_seen}")
    unexpected_years = sorted(set(years_seen) - set(expected_years))
    if unexpected_years:
        raise SystemExit(f"Stitched {lane} panel contains unexpected years: {unexpected_years}")
    required = CELL_REQUIRED_FIELDS + (["dimension_key", "dimension_json"] if lane == "dimensioned" else [])
    null_counts = null_blank_counts(path, required, batch_rows=batch_rows)
    if any(null_counts.values()):
        raise SystemExit(f"Stitched {lane} panel contains null/blank key fields: {null_counts}")
    lane_values = sorted(
        str(value)
        for value in distinct_values(path, "lane", duckdb_settings=duckdb_settings)
    )
    if lane_values and lane_values != [lane]:
        raise SystemExit(f"Stitched {lane} artifact contains wrong lane values: {lane_values}")
    contract_values = sorted(
        str(value)
        for value in distinct_values(path, "contract_id", duckdb_settings=duckdb_settings)
    )
    if contract_values and contract_values != [PANEL_CONTRACT_ID]:
        raise SystemExit(f"Stitched {lane} artifact has wrong contract_id values: {contract_values}")
    statuses = set(
        str(value)
        for value in distinct_values(path, "value_status", duckdb_settings=duckdb_settings)
    )
    if not statuses.issubset(ALLOWED_VALUE_STATUSES):
        raise SystemExit(f"Stitched {lane} artifact has unsupported value statuses: {sorted(statuses)}")
    return years_seen


def validate_source_rows(
    path: Path,
    expected_years: list[int],
    *,
    duckdb_settings: DuckDBSettings | None = None,
    batch_rows: int | None = None,
) -> list[int]:
    years_seen = sorted(
        int(value)
        for value in distinct_values(path, "year", duckdb_settings=duckdb_settings)
    )
    if years_seen != expected_years:
        raise SystemExit(f"Stitched source-row year coverage mismatch. expected={expected_years} actual={years_seen}")
    null_counts = null_blank_counts(
        path,
        SOURCE_ROW_KEY + ["UNITID", "lane", "source_csv_sha256", "source_row_hash", "source_row_json"],
        batch_rows=batch_rows,
    )
    if any(null_counts.values()):
        raise SystemExit(f"Stitched source-row panel contains null/blank key fields: {null_counts}")
    lane_values = sorted(
        str(value)
        for value in distinct_values(path, "lane", duckdb_settings=duckdb_settings)
    )
    if not set(lane_values).issubset(ALLOWED_SOURCE_LANES):
        raise SystemExit(f"Stitched source-row artifact contains unsupported lanes: {lane_values}")
    contract_values = sorted(
        str(value)
        for value in distinct_values(path, "contract_id", duckdb_settings=duckdb_settings)
    )
    if contract_values != [PANEL_CONTRACT_ID]:
        raise SystemExit(f"Stitched source-row artifact has wrong contract_id values: {contract_values}")
    return years_seen


def validate_part(
    path: Path,
    year: int,
    label: str,
    expected_schema: pa.Schema,
    expected_lane: str | None = None,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> int:
    if not path.exists():
        raise SystemExit(f"Missing per-year {label} parquet: {path}")
    validate_exact_schema(path, expected_schema, label)
    rows = int(pq.ParquetFile(path).metadata.num_rows)
    if rows == 0:
        return 0
    years = sorted(
        int(value)
        for value in distinct_values(path, "year", duckdb_settings=duckdb_settings)
    )
    if years != [year]:
        raise SystemExit(f"Per-year {label} parquet has wrong year values: path={path} values={years}")
    if expected_lane is not None:
        lanes = sorted(
            str(value)
            for value in distinct_values(path, "lane", duckdb_settings=duckdb_settings)
        )
        if lanes != [expected_lane]:
            raise SystemExit(f"Per-year {label} parquet has wrong lane values: path={path} values={lanes}")
    return rows


def stitch_parts(
    parts: list[Path],
    tmp_output: Path,
    *,
    batch_rows: int | None = None,
) -> tuple[int, pa.Schema]:
    if tmp_output.exists():
        tmp_output.unlink()
    expected_schema: pa.Schema | None = None
    writer: pq.ParquetWriter | None = None
    input_rows = 0
    try:
        for part in parts:
            parquet = pq.ParquetFile(part)
            schema = parquet.schema_arrow.remove_metadata()
            if expected_schema is None:
                expected_schema = schema
                writer = pq.ParquetWriter(tmp_output, schema, compression="snappy")
            elif not schema.equals(expected_schema):
                raise SystemExit(f"Per-year parquet schema mismatch: {part}")
            input_rows += int(parquet.metadata.num_rows)
            assert writer is not None
            effective_batch_rows = batch_rows or DEFAULT_STITCH_BATCH_ROWS
            for batch in parquet.iter_batches(batch_size=effective_batch_rows):
                writer.write_batch(batch)
    finally:
        if writer is not None:
            writer.close()
    if expected_schema is None or not tmp_output.exists():
        raise SystemExit("No per-year parquet files were stitched.")
    output_rows = int(pq.ParquetFile(tmp_output).metadata.num_rows)
    if output_rows != input_rows:
        raise SystemExit(f"Stitch row-count reconciliation failed: input={input_rows} output={output_rows}")
    return input_rows, expected_schema


def validate_uniqueness(
    path: Path,
    lane: str,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> None:
    if int(pq.ParquetFile(path).metadata.num_rows) == 0:
        return
    key_columns = SCALAR_CELL_KEY if lane == "scalar" else DIMENSIONED_CELL_KEY
    key = ", ".join(key_columns)
    con = open_duckdb_connection(duckdb_settings)
    try:
        duplicate = con.execute(
            f"""
            SELECT {key}, COUNT(*) AS rows
            FROM read_parquet({sql_quote(path)})
            GROUP BY {key}
            HAVING COUNT(*) > 1
            LIMIT 1
            """
        ).fetchone()
    finally:
        con.close()
    if duplicate is not None:
        raise SystemExit(f"Stitched {lane} panel contains duplicate scientific keys: {duplicate}")


def validate_source_references(
    cell_paths: list[Path],
    source_rows_path: Path,
    *,
    duckdb_settings: DuckDBSettings | None = None,
    expected_years: list[int] | None = None,
) -> None:
    con = open_duckdb_connection(duckdb_settings)
    try:
        years = (
            sorted({int(year) for year in expected_years})
            if expected_years is not None
            else [
                int(row[0])
                for row in con.execute(
                    f"SELECT DISTINCT year FROM read_parquet({sql_quote(source_rows_path)}) "
                    "ORDER BY year"
                ).fetchall()
            ]
        )
        for year in years:
            # The source key includes year, so annual proofs compose exactly
            # without constructing one 62-million-row aggregate state.
            duplicate_source_id = con.execute(
                f"""
                SELECT {', '.join(SOURCE_ROW_KEY)}, COUNT(*)
                FROM read_parquet({sql_quote(source_rows_path)})
                WHERE year = {int(year)}
                GROUP BY {', '.join(SOURCE_ROW_KEY)}
                HAVING COUNT(*) > 1
                LIMIT 1
                """
            ).fetchone()
            if duplicate_source_id is not None:
                raise SystemExit(
                    "Stitched source rows contain duplicate source_row_id: "
                    f"{duplicate_source_id}"
                )
        active_paths = [
            (index, cell_path)
            for index, cell_path in enumerate(cell_paths)
            if int(pq.ParquetFile(cell_path).metadata.num_rows) > 0
        ]
        counts = {index: [0, 0] for index, _path in active_paths}
        projected_columns = """
            contract_id, source_row_id, year, UNITID, source_file,
            access_table_name, lane, source_csv_sha256, source_row_hash,
            source_row_ordinal, dimension_json, dimension_key
        """
        for year in years:
            # Build the source side once per year and probe both long lanes in
            # one UNION. Year is part of every join key, so this is equivalent
            # to the former all-years joins while bounding hash state.
            annual_cells = " UNION ALL ".join(
                f"""
                SELECT {int(index)} AS _path_index, {projected_columns}
                FROM read_parquet({sql_quote(cell_path)}) AS cells
                WHERE cells.year = {int(year)}
                """
                for index, cell_path in active_paths
            )
            if not annual_cells:
                continue
            results = con.execute(
                f"""
                SELECT
                    cells._path_index,
                    COUNT(*) FILTER (
                        WHERE rows.source_row_id IS NULL
                    ) AS missing_count,
                    COUNT(*) FILTER (
                        WHERE rows.source_row_id IS NOT NULL
                          AND (
                              cells.source_csv_sha256 <> rows.source_csv_sha256
                           OR cells.source_row_hash <> rows.source_row_hash
                           OR cells.source_row_ordinal <> rows.source_row_ordinal
                           OR cells.dimension_json <> rows.dimension_json
                           OR cells.dimension_key <> rows.dimension_key
                          )
                    ) AS mismatch_count
                FROM ({annual_cells}) AS cells
                LEFT JOIN (
                    SELECT {projected_columns}
                    FROM read_parquet({sql_quote(source_rows_path)}) AS rows
                    WHERE rows.year = {int(year)}
                ) AS rows
                  ON cells.contract_id = rows.contract_id
                 AND cells.source_row_id = rows.source_row_id
                 AND cells.year = rows.year
                 AND cells.UNITID = rows.UNITID
                 AND cells.source_file = rows.source_file
                 AND cells.access_table_name = rows.access_table_name
                 AND cells.lane = rows.lane
                GROUP BY cells._path_index
                ORDER BY cells._path_index
                """
            ).fetchall()
            for path_index, annual_missing, annual_mismatch in results:
                counts[int(path_index)][0] += int(annual_missing or 0)
                counts[int(path_index)][1] += int(annual_mismatch or 0)
        for index, cell_path in active_paths:
            missing, mismatch = counts[index]
            if missing:
                raise SystemExit(
                    f"{missing} stitched cells lack a stitched source-row record: {cell_path}"
                )
            if mismatch:
                raise SystemExit(
                    f"{mismatch} stitched cells disagree with source-row lineage metadata: {cell_path}"
                )
    finally:
        con.close()


def validate_aggregated_lineage(
    path: Path,
    *,
    source_rows: bool,
    batch_rows: int | None = None,
) -> None:
    """Validate duplicate-lineage JSON with bounded-memory parquet batches."""
    columns = [
        "source_row_id",
        "source_row_ordinal",
        "source_duplicate_count",
        "source_row_ids_json",
        "source_row_ordinals_json",
    ]
    parquet = pq.ParquetFile(path)
    hex_id = re.compile(r"^[0-9a-f]{64}$")
    row_offset = 0
    effective_batch_rows = batch_rows or DEFAULT_LINEAGE_VALIDATION_BATCH_ROWS
    for batch in parquet.iter_batches(
        columns=columns,
        batch_size=effective_batch_rows,
        use_threads=False,
    ):
        row_ids = batch.column("source_row_id")
        row_ordinals = batch.column("source_row_ordinal")
        expected_ids_json = pc.binary_join_element_wise(
            pa.scalar('["'),
            row_ids,
            pa.scalar('"]'),
            pa.scalar(""),
        )
        expected_ordinals_json = pc.binary_join_element_wise(
            pa.scalar("["),
            pc.cast(row_ordinals, pa.string()),
            pa.scalar("]"),
            pa.scalar(""),
        )
        canonical_singleton = pc.equal(
            batch.column("source_duplicate_count"),
            pa.scalar(1, type=batch.column("source_duplicate_count").type),
        )
        for condition in (
            pc.match_substring_regex(row_ids, r"^[0-9a-f]{64}$"),
            pc.greater_equal(
                row_ordinals,
                pa.scalar(1, type=row_ordinals.type),
            ),
            pc.equal(batch.column("source_row_ids_json"), expected_ids_json),
            pc.equal(
                batch.column("source_row_ordinals_json"),
                expected_ordinals_json,
            ),
        ):
            canonical_singleton = pc.and_kleene(canonical_singleton, condition)
        canonical_singleton = pc.fill_null(canonical_singleton, False)
        # Stage 04 writes this canonical singleton representation for ordinary
        # rows. Keep those checks in Arrow; retain the full legacy parser below
        # for duplicate or noncanonical-but-valid arrays and all failures.
        if pc.all(canonical_singleton).as_py():
            row_offset += len(batch)
            continue
        fallback_positions = pc.indices_nonzero(pc.invert(canonical_singleton))
        fallback_records = batch.take(fallback_positions).to_pylist()
        for position, record in zip(
            fallback_positions.to_pylist(),
            fallback_records,
            strict=True,
        ):
            index = row_offset + int(position)
            try:
                ids = json.loads(record["source_row_ids_json"])
                ordinals = json.loads(record["source_row_ordinals_json"])
            except (TypeError, json.JSONDecodeError) as exc:
                raise SystemExit(f"Invalid duplicate-lineage JSON in {path} at row {index}: {exc}") from exc
            count = int(record["source_duplicate_count"])
            if (
                count < 1
                or not isinstance(ids, list)
                or not isinstance(ordinals, list)
                or len(ids) != count
                or len(ordinals) != count
                or len(set(ids)) != count
                or len(set(ordinals)) != count
                or ordinals != sorted(ordinals)
                or any(not isinstance(value, str) or not hex_id.fullmatch(value) for value in ids)
                or any(not isinstance(value, int) or value < 1 for value in ordinals)
            ):
                raise SystemExit(
                    f"Duplicate-lineage arrays disagree with source_duplicate_count in {path} at row {index}"
                )
            row_id = str(record["source_row_id"])
            row_ordinal = int(record["source_row_ordinal"])
            if row_id not in ids or row_ordinal not in ordinals:
                raise SystemExit(f"Duplicate-lineage arrays omit their physical source row in {path} at row {index}")
            if not source_rows and (ids[0] != row_id or ordinals[0] != row_ordinal):
                raise SystemExit(
                    f"Collapsed cell does not reference the canonical first duplicate in {path} at row {index}"
                )
        row_offset += len(batch)


def main() -> None:
    args = parse_args()
    layout = ensure_data_layout(args.root)
    years = parse_years(args.years)
    duckdb_settings = DuckDBSettings(
        memory_limit=args.duckdb_memory_limit,
        threads=args.duckdb_threads,
        temp_dir=Path(args.duckdb_temp_dir) if args.duckdb_temp_dir else None,
    )
    cross_sections = Path(args.cross_sections_dir) if args.cross_sections_dir else layout.cross_sections / "v2"
    year_token = f"{years[0]}_{years[-1]}"
    scalar_output = (
        Path(args.output)
        if args.output
        else layout.panels / "v2" / f"panel_long_scalar_{year_token}.parquet"
    )
    dimensioned_output = (
        Path(args.dimensioned_output)
        if args.dimensioned_output
        else companion_output(scalar_output, "panel_long_scalar", "panel_long_dimensioned")
    )
    source_rows_output = (
        Path(args.source_rows_output)
        if args.source_rows_output
        else companion_output(scalar_output, "panel_long_scalar", "panel_source_rows")
    )
    outputs = {
        "scalar": scalar_output,
        "dimensioned": dimensioned_output,
        "source_rows": source_rows_output,
    }
    summary_path = layout.checks / "v2" / "harmonize_qc" / "stitch_summary.csv"
    run_id = args.resume_pending_run_id or uuid.uuid4().hex
    resume_identities: dict[str, FileIdentity] | None = None
    if args.resume_pending_run_id:
        tmp_outputs, resume_identities = resume_pending_artifact_group(outputs, run_id)
        summary_pending = pending_path_for(summary_path, run_id)
        if summary_pending.exists() or summary_pending.is_symlink():
            raise SystemExit(
                "Cannot resume Stage 05 with a stale summary pending artifact: "
                f"{summary_pending}"
            )
    parts = {
        "scalar": [cross_sections / f"panel_long_scalar_{year}.parquet" for year in years],
        "dimensioned": [cross_sections / f"panel_long_dimensioned_{year}.parquet" for year in years],
        "source_rows": [cross_sections / f"panel_source_rows_{year}.parquet" for year in years],
    }

    input_counts: dict[str, int] = {}
    for label, lane_parts in parts.items():
        expected_lane = label if label in {"scalar", "dimensioned"} else None
        expected_schema = LONG_PANEL_SCHEMA if label in {"scalar", "dimensioned"} else SOURCE_ROW_SCHEMA
        validated_rows = 0
        for year, path in zip(years, lane_parts, strict=True):
            print(f"Stage 05 input validation: {label} year={year}", flush=True)
            validated_rows += validate_part(
                path,
                year,
                label.replace("_", "-"),
                expected_schema,
                expected_lane,
                duckdb_settings=duckdb_settings,
            )
            if expected_lane is not None:
                # Both scientific keys include year. Proving each annual part
                # unique therefore proves the concatenation unique, without a
                # 1.6-billion-group all-years aggregate.
                validate_uniqueness(
                    path,
                    expected_lane,
                    duckdb_settings=duckdb_settings,
                )
        input_counts[label] = validated_rows

    stitch_batch_rows = (
        args.stitch_batch_rows
        if args.stitch_batch_rows is not None
        else args.batch_rows
    )
    if not args.resume_pending_run_id:
        tmp_outputs = {}
        for label, output in outputs.items():
            tmp = pending_artifact_path(output, run_id)
            tmp_outputs[label] = tmp
            stitched_rows, _schema = stitch_parts(
                parts[label],
                tmp,
                batch_rows=stitch_batch_rows,
            )
            if stitched_rows != input_counts[label]:
                raise SystemExit(
                    f"Stitch {label} input reconciliation failed: validated={input_counts[label]} stitched={stitched_rows}"
                )
            release_arrow_memory()
    else:
        expected_schemas = {
            "scalar": LONG_PANEL_SCHEMA,
            "dimensioned": LONG_PANEL_SCHEMA,
            "source_rows": SOURCE_ROW_SCHEMA,
        }
        for label, path in tmp_outputs.items():
            validate_exact_schema(path, expected_schemas[label], f"pending {label}")
            pending_rows = int(pq.ParquetFile(path).metadata.num_rows)
            if pending_rows != input_counts[label]:
                raise SystemExit(
                    f"Cannot resume Stage 05 {label} row-count mismatch: "
                    f"validated_inputs={input_counts[label]} pending={pending_rows}"
                )

    release_arrow_memory()

    print("Stage 05 post-write validation: scalar panel", flush=True)
    validate_stitched_panel(
        tmp_outputs["scalar"],
        years,
        lane="scalar",
        require_all_years=False,
        duckdb_settings=duckdb_settings,
        batch_rows=args.batch_rows,
    )
    release_arrow_memory()
    print("Stage 05 post-write validation: dimensioned panel", flush=True)
    validate_stitched_panel(
        tmp_outputs["dimensioned"],
        years,
        lane="dimensioned",
        require_all_years=False,
        duckdb_settings=duckdb_settings,
        batch_rows=args.batch_rows,
    )
    release_arrow_memory()
    print("Stage 05 post-write validation: source rows", flush=True)
    years_seen = validate_source_rows(
        tmp_outputs["source_rows"],
        years,
        duckdb_settings=duckdb_settings,
        batch_rows=args.batch_rows,
    )
    release_arrow_memory()
    print("Stage 05 post-write validation: scalar lineage", flush=True)
    validate_aggregated_lineage(
        tmp_outputs["scalar"],
        source_rows=False,
        batch_rows=args.batch_rows,
    )
    release_arrow_memory()
    print("Stage 05 post-write validation: dimensioned lineage", flush=True)
    validate_aggregated_lineage(
        tmp_outputs["dimensioned"],
        source_rows=False,
        batch_rows=args.batch_rows,
    )
    release_arrow_memory()
    print("Stage 05 post-write validation: source-row lineage", flush=True)
    validate_aggregated_lineage(
        tmp_outputs["source_rows"],
        source_rows=True,
        batch_rows=args.batch_rows,
    )
    release_arrow_memory()
    print("Stage 05 post-write validation: source references", flush=True)
    validate_source_references(
        [tmp_outputs["scalar"], tmp_outputs["dimensioned"]],
        tmp_outputs["source_rows"],
        duckdb_settings=duckdb_settings,
        expected_years=years,
    )
    release_arrow_memory()

    if resume_identities is not None:
        changed: list[str] = []
        for label, identity in resume_identities.items():
            print(f"Stage 05 recovery verification: rehashing {label}", flush=True)
            if regular_file_identity(tmp_outputs[label]) != identity:
                changed.append(str(tmp_outputs[label]))
        if changed:
            raise SystemExit(
                "Cannot promote Stage 05 pending artifacts changed during recovery: "
                f"{changed}"
            )
    summary_pending = pending_artifact_path(summary_path, run_id)
    with summary_pending.open("w", encoding="utf-8", newline="") as fh:
        fh.write("lane,years_min,years_max,years_count,input_rows,output_rows,output\n")
        for label, output in outputs.items():
            output_rows = int(pq.ParquetFile(tmp_outputs[label]).metadata.num_rows)
            fh.write(
                f"{label},{years_seen[0]},{years_seen[-1]},{len(years_seen)},"
                f"{input_counts[label]},{output_rows},{output}\n"
            )
    promote_artifact_group(
        [(tmp_outputs[label], output) for label, output in outputs.items()]
        + [(summary_pending, summary_path)],
        run_id,
    )
    print(
        f"Wrote stitched scalar={scalar_output} dimensioned={dimensioned_output} "
        f"source_rows={source_rows_output}"
    )


if __name__ == "__main__":
    main()
