#!/usr/bin/env python3
"""
Stage 03: build stitched metadata dictionaries from extracted Access metadata.

Reads:
- yearly `metadata/table_inventory.csv`
- exported metadata CSV tables under `Raw_Access_Databases/<year>/tables_csv/`

Writes:
- `Dictionary/dictionary_lake.parquet` and `.csv`
- `Dictionary/dictionary_codes.parquet` and `.csv`
- `Checks/dictionary_qc/*`

Open this file when you want to see how raw Access metadata becomes the repo's stitched dictionary rather than a year-by-year pile of table documentation.

Method context:
- `METHODS_PANEL_CONSTRUCTION.md` explains why the repo is metadata-first
- this script is where that design becomes durable dictionary artifacts
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import tomllib

import pandas as pd

from access_build_utils import (
    DATA_TABLE_CANDIDATES,
    IMPUTATION_CANDIDATES,
    LONG_DESC_CANDIDATES,
    VALUE_LABEL_CANDIDATES,
    VAR_NAME_CANDIDATES,
    VAR_NUMBER_CANDIDATES,
    VAR_TITLE_CANDIDATES,
    CODE_VALUE_CANDIDATES,
    canonical_source_file,
    canonicalize_nces_source_variable_id,
    clean_source_label,
    can_serve_metadata_role_from_capabilities,
    ensure_data_layout,
    normalize_text_key,
    normalize_varnumber,
    parse_years,
    pick_column,
)


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=None, help="External IPEDSDB_ROOT")
    ap.add_argument("--years", default="2004:2023")
    ap.add_argument(
        "--metadata-backfill-approvals",
        default=str(Path(__file__).resolve().parents[1] / "contracts" / "metadata_backfill_approvals.csv"),
        help="Reviewed variable-level metadata backfill approvals.",
    )
    return ap.parse_args()


BACKFILL_APPROVAL_COLUMNS = [
    "approval_id",
    "contract_id",
    "target_year",
    "source_file",
    "access_table_name",
    "donor_year",
    "variable_id",
    "target_varname",
    "expected_data_type",
    "expected_title",
    "fields_backfilled",
    "compatibility_status",
    "compatibility_evidence",
    "approval_status",
    "reviewer",
    "review_date",
    "justification",
]
APPROVED_BACKFILL_COMPATIBILITY_STATUS = "exact_adjacent_donor_semantics_match"

METADATA_KEY_COLUMNS = ["year", "source_file", "varnumber", "varname"]
METADATA_SEMANTIC_COLUMNS = [
    "access_table_name",
    "metadata_file_number",
    "varTitle",
    "longDescription",
    "DataType",
    "format",
    "Fieldwidth",
    "imputationvar",
]


def source_variable_id(source_file: object, source_varnumber: object, varname: object) -> str:
    """Return a stable, visibly source-backed variable identifier."""
    source = str(source_file or "").strip().upper()
    number = normalize_varnumber(source_varnumber)
    name = str(varname or "").strip().upper()
    if not source or not number or not name:
        return ""
    return f"nces:{source}:{number}:{name}"


def ensure_dictionary_identity_columns(lake: pd.DataFrame) -> pd.DataFrame:
    """Add v2 identities while retaining ``varnumber`` as a compatibility field.

    Source metadata keeps its exact normalized source number. Synthetic records
    use a namespaced ``variable_id`` and have no ``source_varnumber``.
    """
    df = lake.copy()
    for col in ("varnumber", "varname", "source_file", "metadata_source"):
        if col not in df.columns:
            df[col] = ""
    df["varname"] = df["varname"].fillna("").astype(str).str.upper().str.strip()
    df["source_file"] = df["source_file"].fillna("").astype(str).str.upper().str.strip()
    metadata_source = df["metadata_source"].fillna("").astype(str)
    synthetic = metadata_source.str.startswith("synthetic_") & ~metadata_source.str.startswith("synthetic_backfill_")

    if "source_varnumber" not in df.columns:
        df["source_varnumber"] = df["varnumber"]
    df.loc[~synthetic, "source_varnumber"] = df.loc[~synthetic, "source_varnumber"].map(normalize_varnumber)
    df.loc[synthetic, "source_varnumber"] = pd.NA
    df.loc[~synthetic, "varnumber"] = df.loc[~synthetic, "source_varnumber"]

    if "variable_id" not in df.columns:
        df["variable_id"] = ""
    missing_id = df["variable_id"].fillna("").astype(str).str.strip() == ""
    source_rows = (~synthetic) & missing_id
    df.loc[source_rows, "variable_id"] = df.loc[source_rows].apply(
        lambda row: source_variable_id(row["source_file"], row["source_varnumber"], row["varname"]), axis=1
    )
    backfill = metadata_source.str.startswith("synthetic_backfill_")
    df["variable_origin"] = "nces"
    df.loc[metadata_source.str.startswith("synthetic_imputation"), "variable_origin"] = "synthetic_imputation"
    df.loc[metadata_source.str.startswith("synthetic_unitid"), "variable_origin"] = "synthetic_unitid"
    df.loc[backfill, "variable_origin"] = "backfill"
    df["is_synthetic"] = metadata_source.str.startswith("synthetic_")
    source_year = pd.to_numeric(df.get("year", pd.Series(index=df.index, dtype=object)), errors="coerce").astype("Int64")
    if "source_metadata_year" not in df.columns:
        df["source_metadata_year"] = source_year
    df["source_metadata_year"] = pd.to_numeric(df["source_metadata_year"], errors="coerce").astype("Int64")
    if "backfill_donor_year" in df.columns:
        donor_year = pd.to_numeric(df["backfill_donor_year"], errors="coerce").astype("Int64")
        df.loc[backfill, "source_metadata_year"] = donor_year.loc[backfill]
    df.loc[synthetic & ~backfill, "source_metadata_year"] = pd.NA
    if "varTitle" not in df.columns:
        df["varTitle"] = ""
    if "longDescription" not in df.columns:
        df["longDescription"] = ""
    df["title"] = df["varTitle"]
    df["description"] = df["longDescription"]
    return df


def resolve_metadata_records(
    records: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Resolve only semantically concordant metadata records.

    Raw candidate records are always returned. A logical key with any
    disagreement in a semantic field is omitted from the resolved output and
    represented in the conflict table instead of being selected by order.
    """
    conflict_columns = METADATA_KEY_COLUMNS + [
        "field",
        "n_distinct_values",
        "candidate_values",
        "metadata_tables",
        "metadata_record_count",
    ]
    if records.empty:
        return records.copy(), records.copy(), pd.DataFrame(columns=conflict_columns)
    raw = records.copy().reset_index(drop=True)
    raw["metadata_record_ordinal"] = raw.index + 1
    for column in METADATA_KEY_COLUMNS + METADATA_SEMANTIC_COLUMNS + ["metadata_table_name"]:
        if column not in raw.columns:
            raw[column] = ""
    raw["year"] = pd.to_numeric(raw["year"], errors="coerce").astype("Int64")
    raw["source_file"] = raw["source_file"].fillna("").astype(str).str.upper().str.strip()
    raw["varnumber"] = raw["varnumber"].map(normalize_varnumber)
    raw["varname"] = raw["varname"].fillna("").astype(str).str.upper().str.strip()
    for column in METADATA_SEMANTIC_COLUMNS + ["metadata_table_name"]:
        raw[column] = raw[column].fillna("").astype(str).str.strip()

    conflicts: list[dict[str, object]] = []
    resolved_rows: list[dict[str, object]] = []
    for key, group in raw.groupby(METADATA_KEY_COLUMNS, dropna=False, sort=True):
        group_conflicts = False
        for field in METADATA_SEMANTIC_COLUMNS:
            values = sorted({value for value in group[field].astype(str) if value})
            if len(values) <= 1:
                continue
            group_conflicts = True
            conflicts.append(
                {
                    **dict(zip(METADATA_KEY_COLUMNS, key, strict=True)),
                    "field": field,
                    "n_distinct_values": len(values),
                    "candidate_values": "|".join(values),
                    "metadata_tables": "|".join(sorted(set(group["metadata_table_name"]))),
                    "metadata_record_count": len(group),
                }
            )
        if group_conflicts:
            continue
        resolved: dict[str, object] = dict(zip(METADATA_KEY_COLUMNS, key, strict=True))
        for column in raw.columns:
            if column in METADATA_KEY_COLUMNS or column == "metadata_record_ordinal":
                continue
            values = sorted({value for value in group[column].astype(str) if value})
            resolved[column] = values[0] if len(values) == 1 else ("|".join(values) if values else "")
        resolved["metadata_record_count"] = len(group)
        resolved["metadata_table_names"] = "|".join(sorted(set(group["metadata_table_name"])))
        resolved_rows.append(resolved)
    resolved_frame = pd.DataFrame(resolved_rows)
    conflict_frame = pd.DataFrame(conflicts, columns=conflict_columns)
    return resolved_frame, raw, conflict_frame


def load_backfill_approvals(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise SystemExit(f"Missing metadata backfill approval contract: {path}")
    approvals = pd.read_csv(path, dtype=str).fillna("")
    missing = [col for col in BACKFILL_APPROVAL_COLUMNS if col not in approvals.columns]
    if missing:
        raise SystemExit(f"Metadata backfill approval contract missing columns: {', '.join(missing)}")
    return approvals


def current_contract_id() -> str:
    with (Path(__file__).resolve().parents[1] / "contracts" / "panel_spec.toml").open("rb") as fh:
        return str(tomllib.load(fh).get("contract_id", "")).strip()


def load_manifest_year_info(year_dir: Path) -> dict[str, str]:
    manifest = pd.read_csv(year_dir / "manifest.csv", dtype=str).fillna("")
    if manifest.empty:
        raise SystemExit(f"Empty manifest: {year_dir / 'manifest.csv'}")
    return manifest.iloc[0].to_dict()


def choose_candidates(inventory: pd.DataFrame, role: str) -> pd.DataFrame:
    def row_capabilities(row: pd.Series) -> dict[str, bool]:
        return {
            "has_varnumber": str(row.get("has_varnumber", "")).lower() in {"true", "1"},
            "has_varname": str(row.get("has_varname", "")).lower() in {"true", "1"},
            "has_vartitle": str(row.get("has_vartitle", "")).lower() in {"true", "1"},
            "has_longdesc": str(row.get("has_longdesc", "")).lower() in {"true", "1"},
            "has_code": str(row.get("has_codevalue", "")).lower() in {"true", "1"},
            "has_label": str(row.get("has_valuelabel", "")).lower() in {"true", "1"},
            "has_imputation": str(row.get("has_imputation_markers", "")).lower() in {"true", "1"},
        }

    capability_mask = inventory.apply(lambda row: can_serve_metadata_role_from_capabilities(role, row_capabilities(row)), axis=1)
    subset = inventory[capability_mask | (inventory["table_role"] == role)].copy()
    if subset.empty:
        return subset

    def score_row(row: pd.Series) -> tuple[int, int, str]:
        name = normalize_text_key(row["table_name"])
        score = 0
        if row.get("table_role") == role:
            score += 100
        if role == "metadata_varlist" and any(tok in name for tok in ("varlist", "layout", "variable")):
            score += 20
        if role == "metadata_description" and any(tok in name for tok in ("descript", "vartable", "layout")):
            score += 20
        if role == "metadata_codes" and any(tok in name for tok in ("valueset", "frequenc", "code", "label")):
            score += 20
        if role == "metadata_imputation" and "imput" in name:
            score += 20
        return (score, int(row.get("row_count_csv", 0) or 0), str(row["table_name"]))

    scored = sorted(subset.to_dict("records"), key=score_row, reverse=True)
    return pd.DataFrame(scored)


def normalize_access_table_name(raw_value: str, metadata_table_name: str) -> str:
    value = str(raw_value or "").strip()
    if value:
        return value
    return metadata_table_name


def append_synthetic_imputation_rows(lake: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    if lake.empty:
        return lake, 0
    df = ensure_dictionary_identity_columns(lake)
    df["varname"] = df["varname"].fillna("").astype(str).str.upper().str.strip()
    df["imputationvar"] = df["imputationvar"].fillna("").astype(str).str.upper().str.strip()
    df.loc[df["imputationvar"].isin({"", "NAN", "NONE", "<NA>", "NAT"}), "imputationvar"] = ""
    ref = df[df["imputationvar"] != ""].copy()
    if ref.empty:
        return df, 0

    existing = set(
        zip(
            pd.to_numeric(df["year"], errors="coerce").fillna(-1).astype(int),
            df["source_file"].fillna("").astype(str),
            df["varname"].fillna("").astype(str).str.upper(),
        )
    )
    rows = []
    grouped = (
        ref.groupby(["year", "source_file", "imputationvar"], as_index=False)
        .agg(
            access_table_name=("access_table_name", "first"),
            academic_year_label=("academic_year_label", "first"),
            release_type=("release_type", "first"),
        )
    )
    for rec in grouped.to_dict("records"):
        key = (int(rec["year"]), str(rec["source_file"]), str(rec["imputationvar"]).upper())
        if key in existing:
            continue
        variable_id = f"synthetic:imputation:{str(rec['source_file']).upper()}:{str(rec['imputationvar']).upper()}"
        rows.append(
            {
                "year": int(rec["year"]),
                "variable_id": variable_id,
                "source_varnumber": pd.NA,
                "varnumber": variable_id,
                "varname": str(rec["imputationvar"]).upper(),
                "varTitle": f"Imputation flag for {rec['imputationvar']}",
                "longDescription": "Synthetic dictionary row generated from imputationvar mapping.",
                "DataType": "",
                "format": "",
                "Fieldwidth": "",
                "imputationvar": "",
                "source_file": rec["source_file"],
                "source_file_label": rec["source_file"],
                "access_table_name": rec["access_table_name"],
                "metadata_table_name": "",
                "academic_year_label": rec["academic_year_label"],
                "release_type": rec["release_type"],
                "metadata_source": "synthetic_imputation",
            }
        )

    if not rows:
        return df, 0
    out = pd.concat([df, pd.DataFrame(rows)], ignore_index=True)
    out = out.drop_duplicates(subset=["year", "source_file", "variable_id", "varname"]).reset_index(drop=True)
    return ensure_dictionary_identity_columns(out), len(rows)


def append_unitid_metadata_rows(lake: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    if lake.empty:
        return lake, 0
    df = ensure_dictionary_identity_columns(lake)
    years = sorted(pd.to_numeric(df["year"], errors="coerce").dropna().astype(int).unique().tolist())
    existing = set(
        zip(
            pd.to_numeric(df["year"], errors="coerce").fillna(-1).astype(int),
            df["source_file"].fillna("").astype(str),
            df["varname"].fillna("").astype(str).str.upper(),
        )
    )
    rows = []
    for year in years:
        key = (year, "KEYS", "UNITID")
        if key in existing:
            continue
        academic_year_label = f"{year}-{(year + 1) % 100:02d}"
        rows.append(
            {
                "year": year,
                "variable_id": "synthetic:panel-key:UNITID",
                "source_varnumber": pd.NA,
                "varnumber": "synthetic:panel-key:UNITID",
                "varname": "UNITID",
                "varTitle": "Institution identifier (panel key)",
                "longDescription": "IPEDS institution identifier used as the panel key. This row is metadata-only.",
                "DataType": "integer",
                "format": "",
                "Fieldwidth": "",
                "imputationvar": "",
                "source_file": "KEYS",
                "source_file_label": "Panel key metadata",
                "access_table_name": "KEYS",
                "metadata_table_name": "KEYS",
                "academic_year_label": academic_year_label,
                "release_type": "Final",
                "metadata_source": "synthetic_unitid",
            }
        )
    if not rows:
        return df, 0
    out = pd.concat([df, pd.DataFrame(rows)], ignore_index=True)
    out = out.drop_duplicates(subset=["year", "source_file", "variable_id", "varname"]).reset_index(drop=True)
    return ensure_dictionary_identity_columns(out), len(rows)


def append_nearest_year_source_backfill_rows(
    lake: pd.DataFrame,
    *,
    layout,
    years: list[int],
    source_file: str,
    metadata_source: str,
    approvals: pd.DataFrame,
) -> tuple[pd.DataFrame, int]:
    if lake.empty:
        return lake, 0

    df = ensure_dictionary_identity_columns(lake)
    source_norm = str(source_file or "").strip().upper()
    donor_pool = df[
        (df["source_file"].fillna("").astype(str).str.upper() == source_norm)
        & (~df["metadata_source"].fillna("").astype(str).str.startswith("synthetic_"))
    ].copy()
    if donor_pool.empty:
        return df, 0

    donor_years = sorted(pd.to_numeric(donor_pool["year"], errors="coerce").dropna().astype(int).unique().tolist())
    if not donor_years:
        return df, 0

    rows: list[pd.DataFrame] = []
    total_rows = 0
    for year in years:
        has_source_rows = not df[
            (pd.to_numeric(df["year"], errors="coerce") == year)
            & (df["source_file"].fillna("").astype(str).str.upper() == source_norm)
        ].empty
        if has_source_rows:
            continue

        year_dir = layout.raw_access / str(year)
        inventory_path = year_dir / "metadata" / "table_inventory.csv"
        manifest_path = year_dir / "manifest.csv"
        if not inventory_path.exists() or not manifest_path.exists():
            continue

        inventory = pd.read_csv(inventory_path, dtype=str).fillna("")
        data_match = inventory[
            (inventory["table_role"].astype(str).str.lower() == "data")
            & (inventory["normalized_table_name"].fillna("").astype(str).str.upper() == source_norm)
        ].copy()
        if data_match.empty:
            continue
        data_match["row_count_csv_num"] = pd.to_numeric(data_match["row_count_csv"], errors="coerce").fillna(0).astype(int)
        data_match = data_match[data_match["row_count_csv_num"] > 0].copy()
        if data_match.empty:
            continue

        approved = approvals.copy()
        if approved.empty:
            raise SystemExit(
                f"[fatal] no reviewed metadata backfill approval for target_year={year} "
                f"source_file={source_norm}"
            )
        missing_approval_columns = [col for col in BACKFILL_APPROVAL_COLUMNS if col not in approved.columns]
        if missing_approval_columns:
            raise SystemExit(
                "[fatal] metadata backfill approvals missing columns: " + ", ".join(missing_approval_columns)
            )
        approved["target_year"] = pd.to_numeric(approved["target_year"], errors="coerce").astype("Int64")
        approved["donor_year"] = pd.to_numeric(approved["donor_year"], errors="coerce").astype("Int64")
        approved["source_file"] = approved["source_file"].fillna("").astype(str).str.upper().str.strip()
        approved["approval_status"] = approved["approval_status"].fillna("").astype(str).str.lower().str.strip()
        approved = approved[
            (approved["target_year"] == year)
            & (approved["source_file"] == source_norm)
            & (approved["approval_status"] == "approved")
        ].copy()
        if approved.empty:
            raise SystemExit(
                f"[fatal] no reviewed metadata backfill approval for target_year={year} "
                f"source_file={source_norm}"
            )
        approved_donor_years = sorted(approved["donor_year"].dropna().astype(int).unique().tolist())
        if len(approved_donor_years) != 1:
            raise SystemExit(
                f"[fatal] metadata backfill approvals must select exactly one donor year for "
                f"target_year={year} source_file={source_norm}: {approved_donor_years}"
            )
        donor_year = approved_donor_years[0]
        if donor_year not in donor_years:
            raise SystemExit(
                f"[fatal] approved donor year {donor_year} has no metadata for source_file={source_norm}"
            )
        donor_rows = donor_pool[pd.to_numeric(donor_pool["year"], errors="coerce") == donor_year].copy()
        if donor_rows.empty:
            continue
        invalid_approval = approved[
            approved[BACKFILL_APPROVAL_COLUMNS].apply(
                lambda row: any(not str(value).strip() for value in row), axis=1
            )
        ]
        if not invalid_approval.empty:
            raise SystemExit(
                f"[fatal] incomplete metadata backfill approval for target_year={year} source_file={source_norm}"
            )
        duplicate_approvals = approved.groupby("variable_id", dropna=False).size()
        duplicate_approvals = duplicate_approvals[duplicate_approvals > 1]
        if not duplicate_approvals.empty:
            raise SystemExit(
                f"[fatal] multiple metadata backfill approvals for target_year={year} "
                f"source_file={source_norm}: {', '.join(map(str, duplicate_approvals.index.tolist()))}"
            )

        canonical_approval_ids: list[str] = []
        for approval in approved.to_dict("records"):
            signed_variable_id = str(approval.get("variable_id", "")).strip()
            try:
                canonical_variable_id = canonicalize_nces_source_variable_id(
                    signed_variable_id
                )
            except ValueError as exc:
                raise SystemExit(f"[fatal] {exc}") from exc
            _, id_source_file, _, id_varname = canonical_variable_id.split(":", 3)
            if (
                id_source_file
                != str(approval.get("source_file", "")).strip().upper()
                or id_varname
                != str(approval.get("target_varname", "")).strip().upper()
            ):
                raise SystemExit(
                    "[fatal] metadata backfill approval variable_id does not match "
                    "source_file and target_varname: " + signed_variable_id
                )
            canonical_approval_ids.append(canonical_variable_id)
        approved["_canonical_variable_id"] = canonical_approval_ids
        normalized_collisions = approved.groupby(
            "_canonical_variable_id", dropna=False
        ).size()
        normalized_collisions = normalized_collisions[normalized_collisions > 1]
        if not normalized_collisions.empty:
            raise SystemExit(
                "[fatal] metadata backfill approval IDs collide after NCES "
                "variable_id normalization: "
                + ", ".join(map(str, normalized_collisions.index.tolist()))
            )

        selected_data_row = data_match.sort_values(
            ["row_count_csv_num", "table_name"], ascending=[False, True]
        ).iloc[0]
        selected_access_table = str(selected_data_row["table_name"]).strip()
        wrong_table = approved[
            approved["access_table_name"].fillna("").astype(str).str.strip() != selected_access_table
        ]
        if not wrong_table.empty:
            raise SystemExit(
                f"[fatal] metadata backfill approval access_table_name does not match target table "
                f"{selected_access_table} for target_year={year}"
            )
        wrong_contract = approved[
            approved["contract_id"].fillna("").astype(str).str.strip() != current_contract_id()
        ]
        if not wrong_contract.empty:
            raise SystemExit(f"[fatal] metadata backfill approval contract_id mismatch for target_year={year}")
        invalid_compatibility = approved[
            approved["compatibility_status"].fillna("").astype(str)
            != APPROVED_BACKFILL_COMPATIBILITY_STATUS
        ]
        if not invalid_compatibility.empty:
            raise SystemExit(f"[fatal] metadata backfill compatibility is not approved for target_year={year}")
        csv_rel = str(selected_data_row.get("csv_path", "")).strip()
        if not csv_rel:
            raise SystemExit(
                f"[fatal] target data table inventory lacks csv_path for target_year={year} source_file={source_norm}"
            )
        target_csv = year_dir / csv_rel
        if not target_csv.exists():
            raise SystemExit(f"[fatal] target data table CSV is missing: {target_csv}")
        target_columns = {
            str(column).strip().upper() for column in pd.read_csv(target_csv, dtype=str, nrows=0).columns
        }

        try:
            donor_rows["_canonical_variable_id"] = donor_rows["variable_id"].map(
                canonicalize_nces_source_variable_id
            )
        except ValueError as exc:
            raise SystemExit(f"[fatal] donor metadata contains {exc}") from exc
        donor_identity_keys = set(donor_rows["_canonical_variable_id"])
        approved_without_donor = approved[
            ~approved["_canonical_variable_id"].isin(donor_identity_keys)
        ]
        if not approved_without_donor.empty:
            raise SystemExit(
                f"[fatal] approved metadata backfill variables are absent from donor year {donor_year}: "
                + ", ".join(sorted(approved_without_donor["variable_id"].astype(str)))
            )
        donor_rows = donor_rows.merge(
            approved[
                [
                    "_canonical_variable_id",
                    "approval_id",
                    "target_varname",
                    "expected_data_type",
                    "expected_title",
                    "fields_backfilled",
                    "compatibility_status",
                    "compatibility_evidence",
                    "reviewer",
                    "review_date",
                    "justification",
                ]
            ],
            on="_canonical_variable_id",
            how="inner",
            validate="1:1",
        )
        if donor_rows.empty:
            raise SystemExit(
                f"[fatal] no donor rows selected by metadata backfill approvals for target_year={year} "
                f"source_file={source_norm}"
            )
        wrong_varname = donor_rows[
            donor_rows["varname"].fillna("").astype(str).str.upper().str.strip()
            != donor_rows["target_varname"].fillna("").astype(str).str.upper().str.strip()
        ]
        if not wrong_varname.empty:
            raise SystemExit(f"[fatal] metadata backfill target variable identity mismatch for target_year={year}")
        wrong_type = donor_rows[
            donor_rows["DataType"].fillna("").astype(str).str.lower().str.strip()
            != donor_rows["expected_data_type"].fillna("").astype(str).str.lower().str.strip()
        ]
        if not wrong_type.empty:
            raise SystemExit(f"[fatal] metadata backfill type compatibility failed for target_year={year}")
        wrong_title = donor_rows[
            donor_rows["varTitle"].fillna("").astype(str).str.strip()
            != donor_rows["expected_title"].fillna("").astype(str).str.strip()
        ]
        if not wrong_title.empty:
            raise SystemExit(f"[fatal] metadata backfill title compatibility failed for target_year={year}")
        absent_target_vars = sorted(
            varname for varname in donor_rows["varname"].fillna("").astype(str).str.upper() if varname not in target_columns
        )
        if absent_target_vars:
            raise SystemExit(
                f"[fatal] approved metadata backfill variables not present in target table {target_csv.name}: "
                + ", ".join(absent_target_vars)
            )

        manifest_info = load_manifest_year_info(year_dir)
        access_table_name = str(selected_data_row["table_name"])
        donor_rows["year"] = year
        donor_rows["source_file_label"] = clean_source_label(access_table_name)
        donor_rows["access_table_name"] = access_table_name
        donor_rows["metadata_table_name"] = metadata_source
        donor_rows["academic_year_label"] = manifest_info["academic_year_label"]
        donor_rows["release_type"] = manifest_info["release_type"]
        donor_rows["metadata_source"] = metadata_source
        donor_rows["backfill_donor_year"] = donor_year
        donor_rows["backfill_approval_id"] = donor_rows.pop("approval_id")
        donor_rows["backfill_justification"] = donor_rows.pop("justification")
        donor_rows["backfill_fields"] = donor_rows.pop("fields_backfilled")
        donor_rows["backfill_compatibility_status"] = donor_rows.pop("compatibility_status")
        donor_rows["backfill_compatibility_evidence"] = donor_rows.pop("compatibility_evidence")
        donor_rows["backfill_reviewer"] = donor_rows.pop("reviewer")
        donor_rows["backfill_review_date"] = donor_rows.pop("review_date")
        donor_rows = donor_rows.drop(columns=["_canonical_variable_id"])
        rows.append(donor_rows)
        total_rows += len(donor_rows)

    if not rows:
        return df, 0
    out = pd.concat([df] + rows, ignore_index=True)
    out = out.drop_duplicates(subset=["year", "source_file", "variable_id", "varname"], keep="first").reset_index(drop=True)
    return ensure_dictionary_identity_columns(out), total_rows


def build_description_maps(
    desc_candidates: pd.DataFrame,
    year_dir: Path,
    *,
    year: int,
) -> tuple[dict[tuple[str, str], str], pd.DataFrame, pd.DataFrame]:
    """Collect all descriptions and resolve only unambiguous lookup keys."""
    records: list[dict[str, object]] = []
    for rec in desc_candidates.to_dict("records"):
        csv_path = year_dir / rec["csv_path"]
        if not csv_path.exists():
            continue
        df = pd.read_csv(csv_path, dtype=str).fillna("")
        varnum_col = pick_column(df.columns, VAR_NUMBER_CANDIDATES)
        varname_col = pick_column(df.columns, VAR_NAME_CANDIDATES)
        access_table_col = pick_column(df.columns, DATA_TABLE_CANDIDATES)
        long_col = pick_column(df.columns, LONG_DESC_CANDIDATES)
        if long_col is None:
            continue
        for row in df.to_dict("records"):
            table_name = normalize_access_table_name(row.get(access_table_col, ""), rec["table_name"])
            value = str(row.get(long_col, "")).strip()
            if not value:
                continue
            varnumber = normalize_varnumber(row.get(varnum_col, "")) if varnum_col else ""
            varname = str(row.get(varname_col, "")).strip().upper() if varname_col else ""
            records.append(
                {
                    "year": year,
                    "metadata_table_name": rec["table_name"],
                    "metadata_csv_path": rec["csv_path"],
                    "access_table_name": table_name,
                    "access_table_key": normalize_text_key(table_name),
                    "varnumber": varnumber,
                    "varname": varname,
                    "longDescription": value,
                }
            )

    record_columns = [
        "year",
        "metadata_table_name",
        "metadata_csv_path",
        "access_table_name",
        "access_table_key",
        "varnumber",
        "varname",
        "longDescription",
    ]
    raw = pd.DataFrame(records, columns=record_columns)
    conflict_columns = [
        "year",
        "access_table_key",
        "lookup_kind",
        "lookup_value",
        "n_distinct_values",
        "candidate_values",
        "metadata_tables",
    ]
    if raw.empty:
        return {}, raw, pd.DataFrame(columns=conflict_columns)

    identity_rows: list[dict[str, object]] = []
    for row in raw.to_dict("records"):
        for lookup_kind, lookup_value in (("varnumber", row["varnumber"]), ("varname", row["varname"])):
            if not str(lookup_value).strip():
                continue
            identity_rows.append(
                {
                    **row,
                    "lookup_kind": lookup_kind,
                    "lookup_value": lookup_value,
                }
            )
    identity = pd.DataFrame(identity_rows)
    conflicts: list[dict[str, object]] = []
    for key, group in identity[identity["lookup_value"] != ""].groupby(
        ["year", "access_table_key", "lookup_kind", "lookup_value"], dropna=False, sort=True
    ):
        values = sorted(set(group["longDescription"].astype(str)))
        if len(values) > 1:
            conflicts.append(
                {
                    "year": key[0],
                    "access_table_key": key[1],
                    "lookup_kind": key[2],
                    "lookup_value": key[3],
                    "n_distinct_values": len(values),
                    "candidate_values": "|".join(values),
                    "metadata_tables": "|".join(sorted(set(group["metadata_table_name"].astype(str)))),
                }
            )
    conflict_df = pd.DataFrame(conflicts, columns=conflict_columns)

    conflicted_exact_keys: set[tuple[str, str, str]] = set()
    for conflict in conflict_df.itertuples(index=False):
        affected = identity[
            (identity["access_table_key"] == conflict.access_table_key)
            & (identity["lookup_kind"] == conflict.lookup_kind)
            & (identity["lookup_value"] == conflict.lookup_value)
        ]
        for affected_row in affected.itertuples(index=False):
            if affected_row.varnumber:
                conflicted_exact_keys.add((affected_row.access_table_key, "varnumber", affected_row.varnumber))
            if affected_row.varname:
                conflicted_exact_keys.add((affected_row.access_table_key, "varname", affected_row.varname))
    desc_map: dict[tuple[str, str], str] = {}
    for row in raw.itertuples(index=False):
        for kind, lookup in (("varnumber", row.varnumber), ("varname", row.varname)):
            if not lookup or (row.access_table_key, kind, lookup) in conflicted_exact_keys:
                continue
            desc_map[(row.access_table_key, lookup)] = row.longDescription

    # Global fallbacks are safe only when every source table agrees.
    for lookup_col in ("varnumber", "varname"):
        for lookup, group in raw[raw[lookup_col] != ""].groupby(lookup_col, sort=True):
            values = sorted(set(group["longDescription"].astype(str)))
            if len(values) == 1:
                desc_map[("", str(lookup))] = values[0]
    return desc_map, raw, conflict_df


def code_observation_key(row: pd.Series | object) -> tuple[int, str, str, str, str]:
    get = row.get if isinstance(row, pd.Series) else lambda name, default="": getattr(row, name, default)
    return (
        int(get("year", 0) or 0),
        str(get("source_file", "") or "").strip().upper(),
        normalize_text_key(str(get("access_table_name", "") or "")),
        str(get("varname", "") or "").strip().upper(),
        str(get("codevalue", "") or "").strip(),
    )


def find_code_label_conflicts(
    codes: pd.DataFrame,
    *,
    observed_keys: set[tuple[int, str, str, str, str]] | None = None,
) -> pd.DataFrame:
    """Return code identities that have more than one nonempty label."""
    key_cols = [
        "year",
        "source_file",
        "access_table_name",
        "varnumber",
        "varname",
        "codevalue",
        "label_scope",
    ]
    output_cols = key_cols + ["n_distinct_labels", "candidate_labels", "metadata_tables"]
    if codes.empty:
        return pd.DataFrame(columns=output_cols)
    df = codes.copy()
    for col in key_cols + ["valuelabel", "metadata_table_name"]:
        if col not in df.columns:
            df[col] = ""
    df["source_file"] = df["source_file"].fillna("").astype(str).str.upper().str.strip()
    df["access_table_name"] = df["access_table_name"].fillna("").astype(str).str.strip()
    df["varnumber"] = df["varnumber"].map(normalize_varnumber)
    df["varname"] = df["varname"].fillna("").astype(str).str.upper().str.strip()
    df["codevalue"] = df["codevalue"].fillna("").astype(str).str.strip()
    df["valuelabel"] = df["valuelabel"].fillna("").astype(str).str.strip()
    rows: list[dict[str, object]] = []
    for key, group in df.groupby(key_cols, dropna=False, sort=True):
        labels = sorted(set(label for label in group["valuelabel"] if label))
        if len(labels) <= 1:
            continue
        if observed_keys is not None and code_observation_key(group.iloc[0]) not in observed_keys:
            continue
        row = dict(zip(key_cols, key, strict=True))
        row.update(
            {
                "n_distinct_labels": len(labels),
                "candidate_labels": "|".join(labels),
                "metadata_tables": "|".join(sorted(set(group["metadata_table_name"].astype(str)))),
            }
        )
        rows.append(row)
    return pd.DataFrame(rows, columns=output_cols)


def collect_observed_code_keys(codes: pd.DataFrame, layout) -> set[tuple[int, str, str, str, str]]:
    """Return conflicting code identities that are emitted by source data."""
    conflicts = find_code_label_conflicts(codes)
    if conflicts.empty:
        return set()
    observed: set[tuple[int, str, str, str, str]] = set()
    value_cache: dict[tuple[str, str], set[str]] = {}
    inventory_cache: dict[int, pd.DataFrame] = {}
    for conflict in conflicts.itertuples(index=False):
        codevalue = str(conflict.codevalue).strip()
        varname = str(conflict.varname).strip().upper()
        if not codevalue or not varname:
            continue
        year = int(conflict.year)
        if year not in inventory_cache:
            inventory_path = layout.raw_access / str(year) / "metadata" / "table_inventory.csv"
            inventory_cache[year] = (
                pd.read_csv(inventory_path, dtype=str).fillna("")
                if inventory_path.exists()
                else pd.DataFrame()
            )
        inventory = inventory_cache[year]
        if inventory.empty:
            continue
        candidates = inventory[inventory["table_role"].astype(str).str.lower() == "data"].copy()
        exact = candidates[
            candidates["table_name"].map(normalize_text_key)
            == normalize_text_key(str(conflict.access_table_name))
        ]
        if exact.empty and "normalized_table_name" in candidates.columns:
            exact = candidates[
                candidates["normalized_table_name"].fillna("").astype(str).str.upper()
                == str(conflict.source_file).strip().upper()
            ]
        for candidate in exact.to_dict("records"):
            csv_rel = str(candidate.get("csv_path", "")).strip()
            if not csv_rel:
                continue
            csv_path = layout.raw_access / str(year) / csv_rel
            if not csv_path.exists():
                continue
            header = pd.read_csv(csv_path, dtype=str, nrows=0).columns
            actual_column = next((column for column in header if str(column).strip().upper() == varname), None)
            if actual_column is None:
                continue
            cache_key = (str(csv_path), str(actual_column))
            if cache_key not in value_cache:
                series = pd.read_csv(
                    csv_path,
                    dtype=str,
                    keep_default_na=False,
                    usecols=[actual_column],
                )[actual_column]
                value_cache[cache_key] = {str(value).strip() for value in series}
            if codevalue in value_cache[cache_key]:
                observed.add(code_observation_key(pd.Series(conflict._asdict())))
                break
    return observed


def main() -> None:
    args = parse_args()
    layout = ensure_data_layout(args.root)
    dictionary_qc_dir = layout.checks / "dictionary_qc"
    dictionary_qc_dir.mkdir(parents=True, exist_ok=True)
    years = parse_years(args.years)
    backfill_approvals = load_backfill_approvals(Path(args.metadata_backfill_approvals))
    candidate_rows: list[dict] = []
    lake_rows: list[dict] = []
    code_rows: list[dict] = []
    description_record_frames: list[pd.DataFrame] = []
    description_conflict_frames: list[pd.DataFrame] = []

    for year in years:
        year_dir = layout.raw_access / str(year)
        inventory_path = year_dir / "metadata" / "table_inventory.csv"
        if not inventory_path.exists():
            raise SystemExit(f"Missing table inventory for year {year}: {inventory_path}")
        manifest_info = load_manifest_year_info(year_dir)
        inventory = pd.read_csv(inventory_path, dtype=str).fillna("")
        varlist_candidates = choose_candidates(inventory, "metadata_varlist")
        desc_candidates = choose_candidates(inventory, "metadata_description")
        code_candidates = choose_candidates(inventory, "metadata_codes")
        imputation_candidates = choose_candidates(inventory, "metadata_imputation")

        for role_name, frame in (
            ("metadata_varlist", varlist_candidates),
            ("metadata_description", desc_candidates),
            ("metadata_codes", code_candidates),
            ("metadata_imputation", imputation_candidates),
        ):
            for order, row in enumerate(frame.to_dict("records"), start=1):
                candidate_rows.append(
                    {
                        "year": year,
                        "role": role_name,
                        "candidate_rank": order,
                        "table_name": row["table_name"],
                        "csv_path": row["csv_path"],
                    }
                )

        desc_map, description_records, description_conflicts = build_description_maps(
            desc_candidates, year_dir, year=year
        )
        description_record_frames.append(description_records)
        description_conflict_frames.append(description_conflicts)

        for rec in varlist_candidates.to_dict("records"):
            csv_path = year_dir / rec["csv_path"]
            if not csv_path.exists():
                continue
            df = pd.read_csv(csv_path, dtype=str).fillna("")
            varnum_col = pick_column(df.columns, VAR_NUMBER_CANDIDATES)
            varname_col = pick_column(df.columns, VAR_NAME_CANDIDATES)
            vartitle_col = pick_column(df.columns, VAR_TITLE_CANDIDATES)
            data_type_col = pick_column(df.columns, {"datatype", "data type", "data_type"})
            format_col = pick_column(df.columns, {"format"})
            fieldwidth_col = pick_column(df.columns, {"fieldwidth", "field width", "field_width", "width"})
            imp_col = pick_column(df.columns, IMPUTATION_CANDIDATES)
            access_table_col = pick_column(df.columns, DATA_TABLE_CANDIDATES)
            file_number_col = pick_column(
                df.columns,
                {"filenumber", "file number", "file_number"},
            )
            if varname_col is None:
                continue
            for row in df.to_dict("records"):
                varname = str(row.get(varname_col, "")).strip().upper()
                if not varname or varname in {"NAN", "NONE", "<NA>", "NAT", "UNITID"}:
                    continue
                varnumber = normalize_varnumber(row.get(varnum_col, "")) if varnum_col else ""
                if varnumber in {"", "00000000"}:
                    continue
                access_table_name = normalize_access_table_name(row.get(access_table_col, ""), rec["table_name"])
                source_file = canonical_source_file(access_table_name)
                long_desc = (
                    desc_map.get((normalize_text_key(access_table_name), varnumber), "")
                    or desc_map.get((normalize_text_key(access_table_name), varname), "")
                    or desc_map.get(("", varnumber), "")
                    or desc_map.get(("", varname), "")
                )
                lake_rows.append(
                    {
                        "year": year,
                        "varnumber": varnumber,
                        "varname": varname,
                        "varTitle": str(row.get(vartitle_col, "")).strip() if vartitle_col else "",
                        "longDescription": long_desc,
                        "DataType": str(row.get(data_type_col, "")).strip() if data_type_col else "",
                        "format": str(row.get(format_col, "")).strip() if format_col else "",
                        "Fieldwidth": str(row.get(fieldwidth_col, "")).strip() if fieldwidth_col else "",
                        "imputationvar": str(row.get(imp_col, "")).strip().upper() if imp_col else "",
                        "source_file": source_file,
                        "source_file_label": clean_source_label(access_table_name),
                        "access_table_name": access_table_name,
                        "metadata_file_number": (
                            str(row.get(file_number_col, "")).strip()
                            if file_number_col
                            else ""
                        ),
                        "metadata_table_name": rec["table_name"],
                        "academic_year_label": manifest_info["academic_year_label"],
                        "release_type": manifest_info["release_type"],
                        "metadata_source": "access_varlist",
                    }
                )

        for rec in code_candidates.to_dict("records"):
            csv_path = year_dir / rec["csv_path"]
            if not csv_path.exists():
                continue
            df = pd.read_csv(csv_path, dtype=str).fillna("")
            varnum_col = pick_column(df.columns, VAR_NUMBER_CANDIDATES)
            varname_col = pick_column(df.columns, VAR_NAME_CANDIDATES)
            code_col = pick_column(df.columns, CODE_VALUE_CANDIDATES)
            label_col = pick_column(df.columns, VALUE_LABEL_CANDIDATES)
            title_col = pick_column(df.columns, VAR_TITLE_CANDIDATES)
            access_table_col = pick_column(df.columns, DATA_TABLE_CANDIDATES)
            if code_col is None or label_col is None:
                continue
            for row in df.to_dict("records"):
                access_table_name = normalize_access_table_name(row.get(access_table_col, ""), rec["table_name"])
                code_rows.append(
                    {
                        "year": year,
                        "varnumber": normalize_varnumber(row.get(varnum_col, "")) if varnum_col else "",
                        "varname": str(row.get(varname_col, "")).strip().upper() if varname_col else "",
                        "codevalue": str(row.get(code_col, "")).strip(),
                        "valuelabel": str(row.get(label_col, "")).strip(),
                        "varTitle": str(row.get(title_col, "")).strip() if title_col else "",
                        "source_file": canonical_source_file(access_table_name),
                        "source_file_label": clean_source_label(access_table_name),
                        "access_table_name": access_table_name,
                        "metadata_table_name": rec["table_name"],
                        "academic_year_label": manifest_info["academic_year_label"],
                        "release_type": manifest_info["release_type"],
                        "source": "access_codes",
                        "is_imputation_label": False,
                        "label_scope": "regular",
                    }
                )

        for rec in imputation_candidates.to_dict("records"):
            csv_path = year_dir / rec["csv_path"]
            if not csv_path.exists():
                continue
            df = pd.read_csv(csv_path, dtype=str).fillna("")
            code_col = pick_column(df.columns, CODE_VALUE_CANDIDATES)
            label_col = pick_column(df.columns, VALUE_LABEL_CANDIDATES)
            access_table_col = pick_column(df.columns, DATA_TABLE_CANDIDATES)
            if code_col is None or label_col is None:
                continue
            for row in df.to_dict("records"):
                access_table_name = normalize_access_table_name(row.get(access_table_col, ""), rec["table_name"])
                code_rows.append(
                    {
                        "year": year,
                        "varnumber": "",
                        "varname": "",
                        "codevalue": str(row.get(code_col, "")).strip(),
                        "valuelabel": str(row.get(label_col, "")).strip(),
                        "varTitle": "",
                        "source_file": canonical_source_file(access_table_name),
                        "source_file_label": clean_source_label(access_table_name),
                        "access_table_name": access_table_name,
                        "metadata_table_name": rec["table_name"],
                        "academic_year_label": manifest_info["academic_year_label"],
                        "release_type": manifest_info["release_type"],
                        "source": "access_imputation",
                        "is_imputation_label": True,
                        "label_scope": "imputation_variable",
                    }
                )

    candidate_df = pd.DataFrame(candidate_rows)
    candidate_df.to_csv(dictionary_qc_dir / "dictionary_metadata_candidates.csv", index=False)

    description_records = pd.concat(description_record_frames, ignore_index=True) if description_record_frames else pd.DataFrame()
    description_conflicts = (
        pd.concat(description_conflict_frames, ignore_index=True) if description_conflict_frames else pd.DataFrame()
    )
    description_records.to_csv(dictionary_qc_dir / "metadata_description_records.csv", index=False)
    description_conflicts.to_csv(dictionary_qc_dir / "metadata_description_conflicts.csv", index=False)

    codes = pd.DataFrame(code_rows)
    if codes.empty:
        codes = pd.DataFrame(
            columns=[
                "year",
                "varnumber",
                "varname",
                "codevalue",
                "valuelabel",
                "varTitle",
                "source_file",
                "source_file_label",
                "access_table_name",
                "metadata_table_name",
                "academic_year_label",
                "release_type",
                "source",
                "is_imputation_label",
                "label_scope",
            ]
        )
    code_label_conflicts = find_code_label_conflicts(codes)
    observed_code_keys = collect_observed_code_keys(codes, layout)
    release_code_label_conflicts = find_code_label_conflicts(codes, observed_keys=observed_code_keys)
    if not code_label_conflicts.empty:
        code_label_conflicts["observed_in_source_data"] = code_label_conflicts.apply(
            lambda row: code_observation_key(row) in observed_code_keys,
            axis=1,
        )
    codes.to_csv(dictionary_qc_dir / "metadata_code_records.csv", index=False)
    code_label_conflicts.to_csv(dictionary_qc_dir / "metadata_code_label_conflicts.csv", index=False)
    release_code_label_conflicts.to_csv(
        dictionary_qc_dir / "metadata_code_label_conflicts_release.csv", index=False
    )

    lake_candidates = pd.DataFrame(lake_rows)
    resolved_lake, raw_lake, varlist_conflicts = resolve_metadata_records(lake_candidates)
    raw_lake.to_csv(dictionary_qc_dir / "metadata_varlist_records.csv", index=False)
    varlist_conflicts.to_csv(dictionary_qc_dir / "metadata_varlist_conflicts.csv", index=False)
    if not description_conflicts.empty or not release_code_label_conflicts.empty or not varlist_conflicts.empty:
        raise SystemExit(
            "[fatal] unresolved dictionary metadata conflicts: "
            f"varlist={len(varlist_conflicts)} descriptions={len(description_conflicts)} "
            f"observed_code_labels={len(release_code_label_conflicts)}; "
            f"see {dictionary_qc_dir}"
        )

    lake = resolved_lake
    if lake.empty:
        raise SystemExit("Dictionary ingest produced no rows.")
    lake["varname"] = lake["varname"].fillna("").astype(str).str.upper().str.strip()
    lake["imputationvar"] = lake["imputationvar"].fillna("").astype(str).str.upper().str.strip()
    lake.loc[lake["imputationvar"].isin({"NAN", "NONE", "<NA>", "NAT"}), "imputationvar"] = ""
    lake = ensure_dictionary_identity_columns(lake)
    lake, lt9_backfill_count = append_nearest_year_source_backfill_rows(
        lake,
        layout=layout,
        years=years,
        source_file="SAL_A_LT",
        metadata_source="synthetic_backfill_salary_lt9",
        approvals=backfill_approvals,
    )
    backfill_report_columns = [
        "year",
        "source_metadata_year",
        "source_file",
        "access_table_name",
        "varname",
        "source_varnumber",
        "variable_id",
        "backfill_fields",
        "backfill_compatibility_status",
        "backfill_approval_id",
        "backfill_compatibility_evidence",
        "backfill_reviewer",
        "backfill_review_date",
    ]
    for column in backfill_report_columns:
        if column not in lake.columns:
            lake[column] = ""
    backfill_report = lake[
        lake["metadata_source"].fillna("").astype(str).str.startswith("synthetic_backfill_")
    ][backfill_report_columns].copy()
    backfill_report = backfill_report.rename(
        columns={
            "year": "target_year",
            "source_metadata_year": "donor_year",
            "backfill_fields": "fields_backfilled",
            "backfill_compatibility_status": "compatibility_status",
            "backfill_approval_id": "approval_id",
        }
    )
    backfill_report.to_csv(dictionary_qc_dir / "metadata_backfill_report.csv", index=False)
    lake, synth_imp_count = append_synthetic_imputation_rows(lake)
    lake, unitid_count = append_unitid_metadata_rows(lake)
    contract_id = current_contract_id()
    if not contract_id:
        raise SystemExit("[fatal] panel contract_id is blank")
    if "contract_id" in lake.columns:
        observed_contracts = {
            str(value).strip()
            for value in lake["contract_id"].dropna().tolist()
            if str(value).strip()
        }
        if observed_contracts and observed_contracts != {contract_id}:
            raise SystemExit("[fatal] dictionary rows are bound to another panel contract")
    lake["contract_id"] = contract_id
    lake = lake[["contract_id", *[column for column in lake.columns if column != "contract_id"]]]
    v2_dictionary_dir = layout.dictionary / "v2"
    v2_dictionary_dir.mkdir(parents=True, exist_ok=True)
    lake.to_parquet(v2_dictionary_dir / "dictionary_lake.parquet", index=False)
    lake.to_csv(v2_dictionary_dir / "dictionary_lake.csv", index=False)
    # Development-only aliases keep pre-v2 scripts inspectable while the
    # migration is in progress. Release contracts point exclusively to v2.
    lake.to_parquet(layout.dictionary / "dictionary_lake.parquet", index=False)
    lake.to_csv(layout.dictionary / "dictionary_lake.csv", index=False)

    codes = codes.drop_duplicates().reset_index(drop=True)
    codes["contract_id"] = contract_id
    codes = codes[["contract_id", *[column for column in codes.columns if column != "contract_id"]]]
    codes.to_parquet(v2_dictionary_dir / "dictionary_codes.parquet", index=False)
    codes.to_csv(v2_dictionary_dir / "dictionary_codes.csv", index=False)
    codes.to_parquet(layout.dictionary / "dictionary_codes.parquet", index=False)
    codes.to_csv(layout.dictionary / "dictionary_codes.csv", index=False)

    with (dictionary_qc_dir / "synthetic_rows_summary.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(
            fh,
            fieldnames=[
                "synthetic_salary_lt9_backfill_rows",
                "synthetic_imputation_rows",
                "synthetic_unitid_rows",
            ],
        )
        writer.writeheader()
        writer.writerow(
            {
                "synthetic_salary_lt9_backfill_rows": lt9_backfill_count,
                "synthetic_imputation_rows": synth_imp_count,
                "synthetic_unitid_rows": unitid_count,
            }
        )

    print(f"Wrote dictionary lake rows={len(lake):,}")
    print(f"Wrote dictionary codes rows={len(codes):,}")


if __name__ == "__main__":
    main()
