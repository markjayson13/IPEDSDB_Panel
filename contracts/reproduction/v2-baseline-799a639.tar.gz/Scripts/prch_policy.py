"""
Shared PRCH parent/child cleaning policy used by cleaning and QA scripts.

Reads:
- local IPEDS metadata labels when callers compare policy to dictionary artifacts

Writes:
- no files directly; this module centralizes policy for other scripts

The in-module mapping is retained only as a labelled development compatibility
policy. Release cleaning must use ``contracts/prch_policy.csv`` (or another
explicit contract) whose annual, code-level rules have been scientifically
reviewed. The checked-in release contract is intentionally empty until that
review is complete.
"""
from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping


POLICY_CONTRACT_COLUMNS = {
    "rule_id",
    "year_start",
    "year_end",
    "flag",
    "code",
    "action",
    "target_columns",
    "row_predicate",
    "accounting_standard",
    "form",
    "part",
    "review_status",
    "source_reference",
    "rationale",
}
RELEASE_ACTIONS = {"null", "retain"}


class PrchPolicyError(ValueError):
    """Raised when a PRCH policy contract is incomplete or ambiguous."""


def _split_selector(value: object) -> tuple[str, ...]:
    text = str(value or "").strip()
    if not text:
        return ()
    normalized = text.replace(",", "|")
    return tuple(dict.fromkeys(part.strip() for part in normalized.split("|") if part.strip()))


@dataclass(frozen=True)
class PrchPolicyRule:
    """One reviewed year/code cleaning decision.

    Release rules name exact output columns and use a small JSON equality
    predicate for row scope. Source-file or prefix expansion is intentionally
    unavailable because a source table can mix parent- and child-reported
    fields.
    """

    rule_id: str
    year_start: int
    year_end: int
    flag: str
    code: int
    action: str
    target_columns: tuple[str, ...]
    row_predicate: tuple[tuple[str, object], ...]
    accounting_standard: str
    form: str
    part: str
    review_status: str
    source_reference: str
    rationale: str

    def applies_to(self, year: int, flag: str, code: int) -> bool:
        return (
            self.year_start <= int(year) <= self.year_end
            and self.flag == normalize_flag(flag)
            and self.code == int(code)
        )

    @property
    def row_predicate_json(self) -> str:
        return json.dumps(dict(self.row_predicate), sort_keys=True, separators=(",", ":"))

    @property
    def predicate_columns(self) -> tuple[str, ...]:
        return tuple(column for column, _value in self.row_predicate)

    def matches_mapping(self, row: Mapping[str, object]) -> bool:
        lookup = {str(key).strip().upper(): value for key, value in row.items()}
        return all(
            column in lookup and _predicate_values_equal(lookup[column], expected)
            for column, expected in self.row_predicate
        )

    def select_target_columns(
        self,
        panel_columns: Iterable[str],
    ) -> list[str]:
        if self.action != "null":
            return []
        panel_names = {str(column) for column in panel_columns}
        return [name for name in self.target_columns if name in panel_names]


@dataclass(frozen=True)
class PrchPolicyContract:
    path: Path
    rules: tuple[PrchPolicyRule, ...]

    def matching_rules(self, year: int, flag: str, code: int) -> list[PrchPolicyRule]:
        return [rule for rule in self.rules if rule.applies_to(year, flag, code)]

    def resolve(
        self,
        year: int,
        flag: str,
        code: int,
        row: Mapping[str, object] | None = None,
    ) -> PrchPolicyRule | None:
        matches = self.matching_rules(year, flag, code)
        if row is not None:
            matches = [rule for rule in matches if rule.matches_mapping(row)]
        if len(matches) > 1:  # Defensive: loader already rejects overlaps.
            ids = ", ".join(rule.rule_id for rule in matches)
            raise PrchPolicyError(
                f"Multiple PRCH rules match year={year} flag={normalize_flag(flag)} code={code}: {ids}"
            )
        return matches[0] if matches else None


def _predicate_value_key(value: object) -> tuple[str, object]:
    if value is None:
        return ("null", "")
    if isinstance(value, bool):
        return ("bool", value)
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return ("number", float(value))
    text = str(value).strip().upper()
    if text in {"TRUE", "FALSE"}:
        return ("bool", text == "TRUE")
    try:
        return ("number", float(text))
    except ValueError:
        return ("string", text)


def _predicate_values_equal(actual: object, expected: object) -> bool:
    try:
        if bool(actual != actual):  # NaN/NA without importing pandas.
            actual = None
    except (TypeError, ValueError):
        pass
    return _predicate_value_key(actual) == _predicate_value_key(expected)


def _parse_row_predicate(value: object, *, row_number: int, release_mode: bool) -> tuple[tuple[str, object], ...]:
    text = str(value or "").strip()
    if release_mode and not text:
        raise PrchPolicyError(f"PRCH policy row {row_number}: row_predicate must contain an explicit JSON object")
    if not text:
        text = "{}"
    def reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
        out: dict[str, object] = {}
        for key, item in pairs:
            if key in out:
                raise PrchPolicyError(
                    f"PRCH policy row {row_number}: row_predicate repeats JSON key {key!r}"
                )
            out[key] = item
        return out
    try:
        parsed = json.loads(text, object_pairs_hook=reject_duplicate_keys)
    except json.JSONDecodeError as exc:
        raise PrchPolicyError(f"PRCH policy row {row_number}: row_predicate is not valid JSON: {exc.msg}") from exc
    if not isinstance(parsed, dict):
        raise PrchPolicyError(f"PRCH policy row {row_number}: row_predicate must be a JSON object")
    normalized: dict[str, object] = {}
    for raw_column, expected in parsed.items():
        column = str(raw_column).strip().upper()
        if not column:
            raise PrchPolicyError(f"PRCH policy row {row_number}: row_predicate contains a blank column")
        if column in {"YEAR", "UNITID"} or column.startswith("PRCH"):
            raise PrchPolicyError(
                f"PRCH policy row {row_number}: row_predicate cannot select protected column {column}"
            )
        if column in normalized:
            raise PrchPolicyError(
                f"PRCH policy row {row_number}: row_predicate repeats normalized column {column}"
            )
        if isinstance(expected, (list, dict)):
            raise PrchPolicyError(
                f"PRCH policy row {row_number}: predicate value for {column} must be a JSON scalar"
            )
        normalized[column] = expected
    if release_mode and not normalized:
        raise PrchPolicyError(
            f"PRCH policy row {row_number}: row_predicate must contain at least one explicit row condition"
        )
    return tuple(sorted(normalized.items()))


def _predicates_may_overlap(left: PrchPolicyRule, right: PrchPolicyRule) -> bool:
    left_values = dict(left.row_predicate)
    right_values = dict(right.row_predicate)
    for column in set(left_values) & set(right_values):
        if not _predicate_values_equal(left_values[column], right_values[column]):
            return False
    return True


def _parse_int(value: object, *, field: str, row_number: int) -> int:
    text = str(value or "").strip()
    try:
        return int(text)
    except ValueError as exc:
        raise PrchPolicyError(f"PRCH policy row {row_number}: {field} must be an integer, got {text!r}") from exc


def _validate_rule(rule: PrchPolicyRule, *, row_number: int, release_mode: bool) -> None:
    prefix = f"PRCH policy row {row_number} ({rule.rule_id or 'missing rule_id'})"
    if not rule.rule_id:
        raise PrchPolicyError(f"{prefix}: rule_id is required")
    if rule.year_start > rule.year_end:
        raise PrchPolicyError(f"{prefix}: year_start must not exceed year_end")
    if not rule.flag.startswith("PRCH"):
        raise PrchPolicyError(f"{prefix}: flag must be a PRCH field, got {rule.flag!r}")
    if rule.action not in RELEASE_ACTIONS:
        raise PrchPolicyError(f"{prefix}: action must be one of {sorted(RELEASE_ACTIONS)}, got {rule.action!r}")
    if release_mode and rule.review_status != "approved":
        raise PrchPolicyError(f"{prefix}: review_status must be 'approved' in release mode")
    if release_mode and not rule.source_reference:
        raise PrchPolicyError(f"{prefix}: source_reference is required in release mode")
    if release_mode and not rule.rationale:
        raise PrchPolicyError(f"{prefix}: rationale is required in release mode")
    if release_mode and not rule.accounting_standard:
        raise PrchPolicyError(f"{prefix}: accounting_standard is required in release mode")
    if release_mode and not rule.form:
        raise PrchPolicyError(f"{prefix}: form is required in release mode")
    if release_mode and not rule.part:
        raise PrchPolicyError(f"{prefix}: part is required in release mode")
    if rule.action == "null" and not rule.target_columns:
        raise PrchPolicyError(f"{prefix}: null action requires exact target_columns")
    if rule.action == "retain" and rule.target_columns:
        raise PrchPolicyError(f"{prefix}: retain action must not define target_columns")


def load_policy_contract(path: Path | str, *, release_mode: bool = True) -> PrchPolicyContract:
    """Load and validate an annual PRCH cleaning contract.

    Release mode rejects empty, unreviewed, ambiguous, or undocumented rules.
    It deliberately does not fall back to the broad development mapping.
    """

    contract_path = Path(path)
    if not contract_path.exists():
        raise PrchPolicyError(f"PRCH policy contract does not exist: {contract_path}")
    with contract_path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        fieldnames = reader.fieldnames or []
        if len(fieldnames) != len(set(fieldnames)):
            raise PrchPolicyError(f"PRCH policy contract {contract_path} contains duplicate header columns")
        header = set(fieldnames)
        missing = POLICY_CONTRACT_COLUMNS - header
        if missing:
            raise PrchPolicyError(
                f"PRCH policy contract {contract_path} is missing columns: {', '.join(sorted(missing))}"
            )
        unsupported = header - POLICY_CONTRACT_COLUMNS
        if unsupported:
            raise PrchPolicyError(
                f"PRCH policy contract {contract_path} has unsupported columns: "
                f"{', '.join(sorted(unsupported))}. Release rules must use exact target_columns only."
            )
        raw_rows = list(reader)

    rules: list[PrchPolicyRule] = []
    seen_ids: set[str] = set()
    for row_number, row in enumerate(raw_rows, start=2):
        rule = PrchPolicyRule(
            rule_id=str(row.get("rule_id") or "").strip(),
            year_start=_parse_int(row.get("year_start"), field="year_start", row_number=row_number),
            year_end=_parse_int(row.get("year_end"), field="year_end", row_number=row_number),
            flag=normalize_flag(str(row.get("flag") or "")),
            code=_parse_int(row.get("code"), field="code", row_number=row_number),
            action=str(row.get("action") or "").strip().lower(),
            target_columns=_split_selector(row.get("target_columns")),
            row_predicate=_parse_row_predicate(
                row.get("row_predicate"),
                row_number=row_number,
                release_mode=release_mode,
            ),
            accounting_standard=str(row.get("accounting_standard") or "").strip(),
            form=str(row.get("form") or "").strip(),
            part=str(row.get("part") or "").strip(),
            review_status=str(row.get("review_status") or "").strip().lower(),
            source_reference=str(row.get("source_reference") or "").strip(),
            rationale=str(row.get("rationale") or "").strip(),
        )
        _validate_rule(rule, row_number=row_number, release_mode=release_mode)
        if rule.rule_id in seen_ids:
            raise PrchPolicyError(f"PRCH policy contract has duplicate rule_id: {rule.rule_id}")
        seen_ids.add(rule.rule_id)
        rules.append(rule)

    if release_mode and not rules:
        raise PrchPolicyError(
            f"PRCH policy contract {contract_path} contains no approved rules. "
            "Populate annual, code-level mappings from reviewed NCES instructions before release cleaning."
        )

    for idx, left in enumerate(rules):
        for right in rules[idx + 1 :]:
            same_key = left.flag == right.flag and left.code == right.code
            years_overlap = left.year_start <= right.year_end and right.year_start <= left.year_end
            predicates_overlap = _predicates_may_overlap(left, right)
            if same_key and years_overlap and predicates_overlap:
                raise PrchPolicyError(
                    f"PRCH policy rule {left.rule_id} overlaps {right.rule_id} for "
                    f"flag={left.flag} code={left.code}; their year ranges and row predicates can match the same row"
                )
    return PrchPolicyContract(path=contract_path, rules=tuple(rules))


@dataclass(frozen=True)
class PrchFlagPolicy:
    flag: str
    cleaned_child_codes: tuple[int, ...]
    review_only_codes: tuple[int, ...] = ()
    target_source_files: tuple[str, ...] = ()
    target_source_prefixes: tuple[str, ...] = ()
    rationale: str = ""


DEFAULT_POLICY = PrchFlagPolicy(
    flag="*",
    cleaned_child_codes=(2,),
    review_only_codes=(),
    target_source_files=(),
    target_source_prefixes=(),
    rationale="Most IPEDS PRCH flags use code 2 for child rows whose data are reported with the parent institution.",
)


POLICY_BY_FLAG: dict[str, PrchFlagPolicy] = {
    "PRCHTP_F": PrchFlagPolicy(
        flag="PRCHTP_F",
        cleaned_child_codes=(2,),
        target_source_files=(),
        rationale=(
            "Finance system-type flag from FLAGS. Track its codes in QA coverage, but do not null panel values "
            "directly from this flag because it describes system structure rather than a component-family payload."
        ),
    ),
    "PRCH_ADM": PrchFlagPolicy(flag="PRCH_ADM", cleaned_child_codes=(2,), target_source_files=("ADM",)),
    "PRCH_AL": PrchFlagPolicy(flag="PRCH_AL", cleaned_child_codes=(2,), target_source_files=("AL",)),
    "PRCH_C": PrchFlagPolicy(
        flag="PRCH_C",
        cleaned_child_codes=(2,),
        target_source_files=("C_A", "C_B", "C_C", "CDEP", "DRVC"),
        rationale=(
            "Completions child rows should not retain either direct completions tables or derived completions totals. "
            "This includes DRVC variables because they are derived from the same completions reporting relationship."
        ),
    ),
    "PRCH_COS": PrchFlagPolicy(flag="PRCH_COS", cleaned_child_codes=(2,), target_source_files=("COST",)),
    "PRCH_E12": PrchFlagPolicy(flag="PRCH_E12", cleaned_child_codes=(2,), target_source_files=("E12",)),
    "PRCH_EAP": PrchFlagPolicy(flag="PRCH_EAP", cleaned_child_codes=(2,), target_source_files=("EAP",)),
    "PRCH_EF": PrchFlagPolicy(
        flag="PRCH_EF",
        cleaned_child_codes=(2,),
        target_source_files=("EFA", "EFA_DIST", "EFB", "EFC", "EFCP", "EFFY", "EFFY_DIST", "EFIA"),
        target_source_prefixes=("EF", "EFFY"),
    ),
    "PRCH_F": PrchFlagPolicy(
        flag="PRCH_F",
        cleaned_child_codes=(2, 3, 4, 5),
        review_only_codes=(6,),
        target_source_files=("F_F", "F_FA", "F_FA_F", "F_FA_G"),
        rationale=(
            "Finance uses more than one child code. Codes 2, 3, 4, and 5 indicate child or partial-child rows "
            "whose finance values are reported elsewhere and should therefore be nulled in the child row. "
            "Code 6 is a partial parent/child case: the child row reports some revenues/expenses while "
            "assets/liabilities remain with the parent, so blanket nulling would remove valid reported data."
        ),
    ),
    "PRCH_GR": PrchFlagPolicy(flag="PRCH_GR", cleaned_child_codes=(2,), target_source_files=("GR", "GR_PELL_SSL")),
    "PRCH_GR2": PrchFlagPolicy(flag="PRCH_GR2", cleaned_child_codes=(2,), target_source_files=("GR200",)),
    "PRCH_HR": PrchFlagPolicy(
        flag="PRCH_HR",
        cleaned_child_codes=(2,),
        target_source_files=("EAP", "SAL_A", "SAL_A_LT", "SAL_B", "SAL_FACULTY", "SAL_IS"),
    ),
    "PRCH_OM": PrchFlagPolicy(flag="PRCH_OM", cleaned_child_codes=(2,), target_source_files=("OM",)),
    "PRCH_S": PrchFlagPolicy(
        flag="PRCH_S",
        cleaned_child_codes=(2,),
        target_source_files=("S_ABD", "S_CN", "S_F", "S_G", "S_IS", "S_NH", "S_OC", "S_SIS"),
        target_source_prefixes=("S_",),
    ),
    "PRCH_SA": PrchFlagPolicy(flag="PRCH_SA", cleaned_child_codes=(2,), target_source_files=("SFA", "SFA_P", "SFAV")),
    "PRCH_SFA": PrchFlagPolicy(flag="PRCH_SFA", cleaned_child_codes=(2,), target_source_files=("SFA", "SFA_P", "SFAV")),
}


def normalize_flag(flag: str) -> str:
    return (flag or "").strip().upper()


def get_policy(flag: str) -> PrchFlagPolicy:
    return POLICY_BY_FLAG.get(normalize_flag(flag), DEFAULT_POLICY)


def cleaned_child_codes(flag: str) -> set[int]:
    return set(get_policy(flag).cleaned_child_codes)


def review_only_codes(flag: str) -> set[int]:
    return set(get_policy(flag).review_only_codes)


def target_source_files(flag: str) -> tuple[str, ...]:
    return tuple(get_policy(flag).target_source_files)


def target_source_prefixes(flag: str) -> tuple[str, ...]:
    return tuple(get_policy(flag).target_source_prefixes)


def targets_source_file(flag: str, source_file: str) -> bool:
    source_norm = (source_file or "").strip().upper()
    if not source_norm:
        return False
    policy = get_policy(flag)
    if source_norm in policy.target_source_files:
        return True
    return any(source_norm.startswith(prefix) for prefix in policy.target_source_prefixes)


def classify_flag_code(flag: str, code: int | float | str | None) -> str:
    if code is None:
        return "missing"
    try:
        code_int = int(code)
    except (TypeError, ValueError):
        return "other"
    policy = get_policy(flag)
    if code_int in policy.cleaned_child_codes:
        return "child_apply"
    if code_int in policy.review_only_codes:
        return "review_only"
    return "other"


def policy_rows(flags: Iterable[str]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for flag in sorted({normalize_flag(flag) for flag in flags if str(flag).strip()}):
        policy = get_policy(flag)
        rows.append(
            {
                "flag": flag,
                "child_codes_applied": ",".join(str(x) for x in policy.cleaned_child_codes),
                "review_only_codes": ",".join(str(x) for x in policy.review_only_codes),
                "target_source_files": ",".join(policy.target_source_files),
                "target_source_prefixes": ",".join(policy.target_source_prefixes),
                "rationale": policy.rationale,
            }
        )
    return rows
