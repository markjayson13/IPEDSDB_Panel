#!/usr/bin/env python3
"""
Stage 04: convert exported yearly data tables into harmonized long parquet.

Reads:
- yearly exported data CSV tables
- `Dictionary/dictionary_lake.parquet`
- yearly `manifest.csv` and `metadata/table_inventory.csv`
- reviewed `contracts/table_grain.csv` and `contracts/source_columns.csv`

Writes:
- `Cross_sections/panel_long_scalar_<year>.parquet`
- `Cross_sections/panel_long_dimensioned_<year>.parquet`
- `Cross_sections/panel_source_rows_<year>.parquet`
- optional scalar compatibility alias `panel_long_varnum_<year>.parquet`
- optional `Cross_sections/parts_<year>/part_*.parquet`
- `Checks/harmonize_qc/*`
- `Checks/release_qc/*`

Open this file when you want to understand how exported yearly CSV tables become the harmonized long panel and why a table was selected or excluded.
"""
from __future__ import annotations

import argparse
import atexit
import csv
from dataclasses import dataclass
import fnmatch
import hashlib
import json
import pathlib
import shutil
import sys
import uuid
from typing import Iterable

import duckdb
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from access_build_utils import ensure_data_layout, normalize_varnumber, parse_years, repo_root
from panel_v2_schema import (
    LONG_PANEL_COLUMNS,
    LONG_PANEL_SCHEMA,
    PANEL_CONTRACT_ID,
    SOURCE_ROW_COLUMNS,
    SOURCE_ROW_SCHEMA,
)


HARMONIZE_SUMMARY_COLUMNS = [
    "year",
    "table_name",
    "source_file",
    "selected",
    "exclude_reason",
    "matched_cols",
    "output_rows",
    "dictionary_rows",
    "source_match_rows",
    "access_table_match_rows",
    "lane",
    "source_rows_read",
    "source_rows_written",
    "exact_duplicate_rows_collapsed",
]

TABLE_GRAIN_CONTRACT_COLUMNS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "grain_class",
    "unit_key_columns",
    "dimension_columns",
    "measure_selection_rule",
    "expected_rows_per_unit",
    "aggregation_policy",
    "source_evidence",
    "review_note",
    "reviewed",
]

SOURCE_COLUMN_CONTRACT_COLUMNS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "column_name",
    "role",
    "canonical_dimension",
    "exclusion_reason",
    "source_evidence",
    "review_note",
    "reviewed",
]

ALLOWED_GRAIN_CLASSES = {"scalar", "dimensioned", "metadata", "excluded", "unknown"}
ALLOWED_SOURCE_COLUMN_ROLES = {
    "identifier",
    "dimension",
    "measure",
    "imputation",
    "metadata",
    "excluded",
    "unknown",
}


@dataclass(frozen=True)
class DuckDBSettings:
    """Optional per-connection resource limits for bounded Stage 04 work."""

    memory_limit: str | None = None
    threads: int | None = None
    temp_dir: pathlib.Path | None = None
    max_temp_gib: int | None = None


SOURCE_DUPLICATE_KEY_COLUMNS = [
    "contract_id",
    "year",
    "source_csv_sha256",
    "source_file",
    "access_table_name",
    "source_row_hash",
]

SOURCE_COLUMN_COVERAGE_COLUMNS = [
    "year",
    "source_file",
    "access_table_name",
    "column_name",
    "role",
    "canonical_dimension",
    "reviewed",
    "nonempty_tokens",
    "resolution",
]

AMBIGUITY_OVERRIDE_COLUMNS = [
    "contract_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_name",
    "varname",
    "selected_source_varnumber",
    "selected_metadata_source",
    "selected_metadata_table_name",
    "evidence",
    "justification",
    "review_status",
    "reviewer",
    "review_date",
]

SOURCE_METADATA_ALIAS_COLUMNS = [
    "contract_id",
    "decision_id",
    "year",
    "source_file",
    "source_access_table_name",
    "source_varname",
    "selected_access_table_name",
    "selected_file_number",
    "selected_source_varnumber",
    "selected_varname",
    "selected_metadata_source",
    "selected_metadata_table_name",
    "evidence",
    "justification",
    "review_status",
    "reviewer",
    "review_date",
]

REVIEWED_ALIAS_REQUIRED_SCOPES = {
    (2023, "SFA_P", "SFA2223_P1"),
    (2023, "SFA_P", "SFA2223_P2"),
}

MISSING_UNITID_COLUMNS = [
    "year",
    "file",
    "stage",
    "dropped_rows_missing_UNITID",
    "rows_before",
    "rows_after",
]

def setup_logging(log_path: str | None) -> None:
    if not log_path:
        return
    log_file = pathlib.Path(log_path)
    log_file.parent.mkdir(parents=True, exist_ok=True)
    f = log_file.open("a", buffering=1)

    class Tee:
        def __init__(self, *streams):
            self.streams = streams

        def write(self, data):
            for s in self.streams:
                s.write(data)

        def flush(self):
            for s in self.streams:
                s.flush()

    sys.stdout = Tee(sys.stdout, f)
    sys.stderr = Tee(sys.stderr, f)


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--root", default=None, help="External IPEDSDB_ROOT")
    ap.add_argument("--years", default="2004:2023")
    ap.add_argument("--output-dir", default=None)
    ap.add_argument("--parts-dir-base", default=None)
    ap.add_argument("--chunksize", type=int, default=50_000)
    ap.add_argument("--value-cols-per-chunk", type=int, default=250)
    ap.add_argument("--dedupe", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--final-dedupe", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument("--dedupe-priority", default="HD,IC,IC_AY,IC_PY,ADM,AL,C_A,C_B,C_C,CDEP,COST,EAP,EFA,EFA_DIST,EFB,EFC,EFCP,EFFY,EFFY_DIST,EFIA,F_F,F_FA,F_FA_F,F_FA_G,GR,GR200,GR_PELL_SSL,OM,SAL_A,SAL_A_LT,SAL_B,SAL_FACULTY,SAL_IS,S_ABD,S_CN,S_F,S_G,S_IS,S_NH,S_OC,S_SIS,SFA,SFAV")
    ap.add_argument("--dedupe-temp-dir", default=None, help="Optional temp directory for DuckDB dedupe spill files")
    ap.add_argument("--dedupe-max-temp-gib", type=int, default=None, help="Optional DuckDB max temp directory size in GiB")
    ap.add_argument("--dedupe-threads", type=int, default=1, help="DuckDB threads to use during final dedupe")
    ap.add_argument(
        "--duckdb-memory-limit",
        default=None,
        help="Optional DuckDB memory_limit applied to every Stage 04 connection.",
    )
    ap.add_argument("--release-strict", action=argparse.BooleanOptionalAction, default=True)
    ap.add_argument(
        "--contract-id",
        default=PANEL_CONTRACT_ID,
        help="Panel contract identifier that every reviewed grain row must bind.",
    )
    ap.add_argument(
        "--dictionary",
        default=None,
        help="Canonical dictionary lake (defaults to Dictionary/v2/dictionary_lake.parquet).",
    )
    ap.add_argument(
        "--table-grain-contract",
        default=str(repo_root() / "contracts" / "table_grain.csv"),
        help="Reviewed CSV assigning each source table to an explicit grain class.",
    )
    ap.add_argument(
        "--source-column-contract",
        default=str(repo_root() / "contracts" / "source_columns.csv"),
        help="Reviewed CSV classifying every source column.",
    )
    ap.add_argument(
        "--write-legacy-scalar-alias",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Development-only scalar compatibility alias; never part of the v2 release.",
    )
    ap.add_argument(
        "--dictionary-ambiguity-overrides",
        default=str(repo_root() / "contracts" / "dictionary_ambiguity_overrides.csv"),
        help="CSV of documented dictionary ambiguity overrides",
    )
    ap.add_argument(
        "--source-metadata-aliases",
        default=str(repo_root() / "contracts" / "source_metadata_aliases.csv"),
        help="CSV of exact reviewed cross-table metadata aliases.",
    )
    ap.add_argument("--log-file", default=None)
    return ap.parse_args()


def read_table_iter(fp: pathlib.Path, chunksize: int = 50_000):
    """Yield source rows without lossy parser fallbacks.

    Stage 02 emits verified UTF-8 exports.  Invalid encoding or malformed CSV
    structure is fatal.  In particular, this function never uses
    ``on_bad_lines='skip'`` and never converts source missing tokens to NaN.
    """
    if chunksize <= 0:
        raise ValueError("chunksize must be positive")
    try:
        with fp.open("r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.reader(fh, strict=True)
            header = next(reader, None)
            if header is None:
                raise ValueError("CSV is empty and has no header")
            expected_fields = len(header)
            if expected_fields == 0:
                raise ValueError("CSV header has no fields")
            records: list[list[str]] = []
            yielded = False
            for record in reader:
                if len(record) != expected_fields:
                    raise ValueError(
                        f"logical row ending at physical line {reader.line_num} has {len(record)} fields; "
                        f"header has {expected_fields}"
                    )
                records.append(record)
                if len(records) >= chunksize:
                    yield pd.DataFrame.from_records(records, columns=header)
                    yielded = True
                    records = []
            if records:
                yield pd.DataFrame.from_records(records, columns=header)
                yielded = True
            if not yielded:
                # Preserve and validate the schema of a legitimate header-only table.
                yield pd.DataFrame(columns=header)
    except Exception as exc:  # noqa: BLE001
        raise SystemExit(f"[fatal] strict CSV parse failed for {fp}: {exc}") from exc


def chunk_cols(cols: list[str], size: int) -> Iterable[list[str]]:
    for i in range(0, len(cols), size):
        yield cols[i : i + size]


def normalize_key(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip().upper()


def sha256_file(path: pathlib.Path, block_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while block := fh.read(block_size):
            digest.update(block)
    return digest.hexdigest()


def stable_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def pending_artifact_path(target: pathlib.Path, run_id: str) -> pathlib.Path:
    """Return a same-filesystem path that is removed on normal process exit."""
    target.parent.mkdir(parents=True, exist_ok=True)
    pending = target.with_name(f".{target.name}.pending-{run_id}")
    pending.unlink(missing_ok=True)
    atexit.register(pending.unlink, missing_ok=True)
    return pending


def promote_artifact_group(artifacts: list[tuple[pathlib.Path, pathlib.Path]], run_id: str) -> None:
    """Publish a validated artifact set with process-level rollback on error."""
    missing = [str(pending) for pending, _target in artifacts if not pending.exists()]
    if missing:
        raise SystemExit(f"[fatal] cannot promote incomplete Stage 04 artifact set: {missing}")
    backups: dict[pathlib.Path, pathlib.Path] = {}
    promoted: list[pathlib.Path] = []
    try:
        for _pending, target in artifacts:
            backup = target.with_name(f".{target.name}.rollback-{run_id}")
            backup.unlink(missing_ok=True)
            if target.exists():
                target.replace(backup)
                backups[target] = backup
        for pending, target in artifacts:
            pending.replace(target)
            promoted.append(target)
    except BaseException:
        for target in reversed(promoted):
            target.unlink(missing_ok=True)
        for target, backup in backups.items():
            if backup.exists():
                backup.replace(target)
        raise
    else:
        for backup in backups.values():
            backup.unlink(missing_ok=True)


def reviewed_value(value: object) -> bool:
    return str(value or "").strip().lower() in {"1", "true", "yes", "approved"}


def load_contract(
    path: pathlib.Path,
    columns: list[str],
    label: str,
    *,
    contract_id: str,
) -> pd.DataFrame:
    if not path.exists():
        raise SystemExit(f"[fatal] missing {label} contract: {path}")
    contract = pd.read_csv(path, dtype=str, keep_default_na=False).fillna("")
    missing = [column for column in columns if column not in contract.columns]
    if missing:
        raise SystemExit(f"[fatal] {label} contract missing columns: {', '.join(missing)}")
    contract = contract[columns].copy()
    for column in contract.columns:
        contract[column] = contract[column].fillna("").astype(str).str.strip()
    contract["source_file"] = contract["source_file"].str.upper()
    contract["access_table_pattern"] = contract["access_table_pattern"].str.upper()
    if "column_name" in contract:
        contract["column_name"] = contract["column_name"].str.upper()
        contract["role"] = contract["role"].str.lower()
    if "grain_class" in contract:
        contract["grain_class"] = contract["grain_class"].str.lower()
    wrong_contract = contract[
        contract["contract_id"].ne(contract_id)
    ]
    if not wrong_contract.empty:
        values = sorted(set(wrong_contract["contract_id"].tolist()))
        raise SystemExit(
            f"[fatal] {label} contract contains rows for the wrong contract_id: "
            f"expected={contract_id!r} actual={values}"
        )
    for row_number, row in contract.iterrows():
        start = str(row["year_start"]).strip()
        end = str(row["year_end"]).strip()
        if not start.isdigit() or not end.isdigit() or int(start) > int(end):
            raise SystemExit(
                f"[fatal] {label} contract row {row_number + 2} has an invalid year range: "
                f"year_start={start!r} year_end={end!r}"
            )
        if normalize_key(row["source_file"]) == "":
            raise SystemExit(f"[fatal] {label} contract row {row_number + 2} has blank source_file")
        if normalize_key(row["access_table_pattern"]) == "":
            raise SystemExit(
                f"[fatal] {label} contract row {row_number + 2} has blank access_table_pattern"
            )
    return contract


def contract_row_matches(row: pd.Series, *, year: int, source_file: str, access_table_name: str) -> bool:
    year_match = int(row["year_start"]) <= int(year) <= int(row["year_end"])
    source_token = normalize_key(row.get("source_file", ""))
    table_pattern = normalize_key(row.get("access_table_pattern", ""))
    source_match = source_token == "*" or source_token == normalize_key(source_file)
    table_match = fnmatch.fnmatchcase(normalize_key(access_table_name), table_pattern)
    return year_match and source_match and table_match


def matching_contract_rows(
    contract: pd.DataFrame,
    *,
    year: int,
    source_file: str,
    access_table_name: str,
) -> pd.DataFrame:
    if contract.empty:
        return contract
    mask = contract.apply(
        contract_row_matches,
        axis=1,
        year=year,
        source_file=source_file,
        access_table_name=access_table_name,
    )
    matches = contract[mask].copy()
    return matches


def resolve_table_grain(
    contract: pd.DataFrame,
    *,
    year: int,
    source_file: str,
    access_table_name: str,
) -> pd.Series:
    matches = matching_contract_rows(
        contract,
        year=year,
        source_file=source_file,
        access_table_name=access_table_name,
    )
    reviewed = matches[matches["reviewed"].map(reviewed_value)] if not matches.empty else matches
    if reviewed.empty:
        raise SystemExit(
            "[fatal] no reviewed table-grain contract for "
            f"year={year} source_file={source_file} access_table_name={access_table_name}"
        )
    if len(reviewed) != 1:
        raise SystemExit(
            "[fatal] ambiguous reviewed table-grain contract for "
            f"year={year} source_file={source_file} access_table_name={access_table_name}"
        )
    row = reviewed.iloc[0]
    grain_class = str(row["grain_class"])
    if grain_class not in ALLOWED_GRAIN_CLASSES:
        raise SystemExit(f"[fatal] unsupported grain_class {grain_class!r} for {access_table_name}")
    if grain_class == "unknown":
        raise SystemExit(f"[fatal] unknown table grain is not permitted for {access_table_name}")
    for field in ("unit_key_columns", "measure_selection_rule", "expected_rows_per_unit", "aggregation_policy", "source_evidence", "review_note"):
        if not str(row[field]).strip():
            raise SystemExit(
                f"[fatal] reviewed table-grain contract lacks {field} for {access_table_name}"
            )
    unit_keys = split_contract_columns(row["unit_key_columns"])
    if "UNITID" not in unit_keys:
        raise SystemExit(f"[fatal] table-grain contract must include UNITID in unit_key_columns for {access_table_name}")
    dimensions = split_contract_columns(row["dimension_columns"])
    expected_unit_keys = {"UNITID", *dimensions}
    if grain_class == "scalar" and set(unit_keys) != {"UNITID"}:
        raise SystemExit(
            f"[fatal] scalar table {access_table_name} must use exactly UNITID as unit_key_columns"
        )
    if grain_class == "dimensioned" and (not dimensions or set(unit_keys) != expected_unit_keys):
        raise SystemExit(
            f"[fatal] dimensioned table {access_table_name} must key UNITID plus every dimension column"
        )
    selection_rule = str(row["measure_selection_rule"]).strip().lower()
    if grain_class in {"scalar", "dimensioned"} and selection_rule != "source_columns_contract":
        raise SystemExit(
            f"[fatal] unsupported measure_selection_rule {selection_rule!r} for {access_table_name}"
        )
    expected_rows = str(row["expected_rows_per_unit"]).strip().lower()
    if grain_class == "scalar" and expected_rows != "1":
        raise SystemExit(f"[fatal] scalar table {access_table_name} must declare expected_rows_per_unit=1")
    if grain_class == "dimensioned" and expected_rows not in {"many", "one_or_more"}:
        raise SystemExit(
            f"[fatal] dimensioned table {access_table_name} must declare expected_rows_per_unit=many or one_or_more"
        )
    if grain_class in {"metadata", "excluded"} and selection_rule != "none":
        raise SystemExit(
            f"[fatal] {grain_class} table {access_table_name} must declare measure_selection_rule=none"
        )
    if row["aggregation_policy"] not in {"none", "exact_duplicate_only"}:
        raise SystemExit(
            f"[fatal] unsupported aggregation_policy {row['aggregation_policy']!r} for {access_table_name}"
        )
    if grain_class in {"scalar", "dimensioned"} and row["aggregation_policy"] != "exact_duplicate_only":
        raise SystemExit(
            f"[fatal] {grain_class} table {access_table_name} must use exact_duplicate_only aggregation"
        )
    if grain_class in {"metadata", "excluded"} and row["aggregation_policy"] != "none":
        raise SystemExit(
            f"[fatal] {grain_class} table {access_table_name} must use aggregation_policy=none"
        )
    return row


def resolve_source_column_contract(
    contract: pd.DataFrame,
    *,
    year: int,
    source_file: str,
    access_table_name: str,
    column_name: str,
) -> pd.Series | None:
    matches = matching_contract_rows(
        contract[contract["column_name"] == normalize_key(column_name)].copy(),
        year=year,
        source_file=source_file,
        access_table_name=access_table_name,
    )
    matches = matches[matches["reviewed"].map(reviewed_value)]
    if matches.empty:
        return None
    if len(matches) != 1:
        raise SystemExit(
            "[fatal] ambiguous reviewed source-column contract for "
            f"year={year} source_file={source_file} table={access_table_name} column={column_name}"
        )
    row = matches.iloc[0]
    if row["role"] not in ALLOWED_SOURCE_COLUMN_ROLES:
        raise SystemExit(f"[fatal] unsupported source-column role {row['role']!r} for {access_table_name}.{column_name}")
    if row["role"] == "unknown":
        raise SystemExit(f"[fatal] unknown source-column role for {access_table_name}.{column_name}")
    for field in ("source_evidence", "review_note"):
        if not str(row[field]).strip():
            raise SystemExit(
                f"[fatal] reviewed source-column contract lacks {field} for {access_table_name}.{column_name}"
            )
    if row["role"] == "dimension" and not str(row["canonical_dimension"]).strip():
        raise SystemExit(f"[fatal] dimension column lacks canonical_dimension: {access_table_name}.{column_name}")
    if row["role"] == "excluded" and not str(row["exclusion_reason"]).strip():
        raise SystemExit(f"[fatal] excluded column lacks exclusion_reason: {access_table_name}.{column_name}")
    return row


def split_contract_columns(value: object) -> list[str]:
    return [normalize_key(part) for part in str(value or "").split("|") if normalize_key(part)]


def ensure_dict_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for col in [
        "year",
        "source_file",
        "access_table_name",
        "varname",
        "varnumber",
        "source_varnumber",
        "variable_id",
        "metadata_source",
        "metadata_table_name",
        "metadata_table_names",
        "metadata_file_number",
    ]:
        if col not in out.columns:
            out[col] = ""
    return out


def empty_ambiguity_overrides() -> pd.DataFrame:
    return pd.DataFrame(columns=AMBIGUITY_OVERRIDE_COLUMNS)


def empty_source_metadata_aliases() -> pd.DataFrame:
    return pd.DataFrame(columns=SOURCE_METADATA_ALIAS_COLUMNS)


def exact_casefolded_token_match(values: pd.Series, expected: object) -> pd.Series:
    """Match one exact identifier in a literal pipe-delimited provenance set."""
    expected_token = str(expected or "").strip().casefold()
    if not expected_token:
        return pd.Series(False, index=values.index, dtype=bool)
    return values.fillna("").astype(str).map(
        lambda value: expected_token
        in {
            token.strip().casefold()
            for token in value.split("|")
            if token.strip()
        }
    )


def load_source_metadata_aliases(
    path: pathlib.Path | None,
    *,
    release_strict: bool,
    contract_id: str = PANEL_CONTRACT_ID,
) -> pd.DataFrame:
    if path is None:
        return empty_source_metadata_aliases()
    if not path.exists():
        raise SystemExit(f"[fatal] missing source metadata alias contract: {path}")
    aliases = pd.read_csv(path, dtype=str, keep_default_na=False).fillna("")
    missing = [
        column
        for column in SOURCE_METADATA_ALIAS_COLUMNS
        if column not in aliases.columns
    ]
    if missing:
        raise SystemExit(
            "[fatal] source metadata alias contract missing columns: "
            + ", ".join(missing)
        )
    aliases = aliases[SOURCE_METADATA_ALIAS_COLUMNS].copy()
    for column in aliases.columns:
        aliases[column] = aliases[column].fillna("").astype(str).str.strip()
    if aliases.empty and release_strict:
        raise SystemExit(
            "[fatal] release-strict source metadata alias contract cannot be empty"
        )
    if aliases.empty:
        return aliases

    for column in (
        "source_file",
        "source_access_table_name",
        "source_varname",
        "selected_access_table_name",
        "selected_varname",
    ):
        aliases[column] = aliases[column].str.upper()
    aliases["selected_source_varnumber"] = aliases["selected_source_varnumber"].map(
        normalize_varnumber
    )

    required_values = [
        "contract_id",
        "decision_id",
        "year",
        "source_file",
        "source_access_table_name",
        "source_varname",
        "selected_access_table_name",
        "selected_file_number",
        "selected_source_varnumber",
        "selected_varname",
        "selected_metadata_source",
        "selected_metadata_table_name",
        "evidence",
        "justification",
        "review_status",
    ]
    for column in required_values:
        bad = aliases[column].eq("")
        if bad.any():
            rows = ", ".join(str(index + 2) for index in aliases.index[bad])
            raise SystemExit(
                f"[fatal] source metadata alias contract has blank {column} at rows {rows}"
            )
    if aliases["contract_id"].ne(contract_id).any():
        raise SystemExit(
            "[fatal] source metadata aliases must bind the current contract_id"
        )
    if (~aliases["year"].str.fullmatch(r"\d{4}")).any():
        raise SystemExit(
            "[fatal] source metadata aliases require an exact four-digit year"
        )
    wildcard = aliases[
        ["source_file", "source_access_table_name", "source_varname"]
    ].apply(lambda column: column.str.contains(r"[*?\[\]]", regex=True))
    if wildcard.any(axis=None):
        raise SystemExit(
            "[fatal] source metadata aliases require exact source identities"
        )
    if aliases["source_varname"].ne(aliases["selected_varname"]).any():
        raise SystemExit(
            "[fatal] source metadata alias source_varname must equal "
            "selected_varname; metadata aliases cannot redirect source values"
        )
    approved = aliases["review_status"].str.lower().eq("approved")
    invalid_status = ~aliases["review_status"].str.lower().isin(
        {"pending", "approved"}
    )
    if invalid_status.any():
        raise SystemExit(
            "[fatal] source metadata aliases must have review_status pending or approved"
        )
    review_dates = pd.to_datetime(
        aliases["review_date"],
        format="%Y-%m-%d",
        errors="coerce",
    )
    if (approved & (aliases["reviewer"].eq("") | review_dates.isna())).any():
        raise SystemExit(
            "[fatal] approved source metadata aliases require reviewer "
            "and ISO review_date"
        )
    if release_strict and (~approved).any():
        raise SystemExit(
            "[fatal] release-strict source metadata aliases must all be approved"
        )

    source_key = [
        "year",
        "source_file",
        "source_access_table_name",
        "source_varname",
    ]
    if aliases.duplicated(source_key, keep=False).any():
        raise SystemExit(
            "[fatal] source metadata alias source identities must be unique"
        )
    target_key = [
        "year",
        "selected_access_table_name",
        "selected_file_number",
        "selected_source_varnumber",
        "selected_varname",
        "selected_metadata_source",
        "selected_metadata_table_name",
    ]
    if aliases.duplicated(target_key, keep=False).any():
        raise SystemExit(
            "[fatal] source metadata alias selected identities must be unique"
        )
    return aliases.sort_values(source_key, kind="mergesort").reset_index(drop=True)


def load_dictionary_ambiguity_overrides(
    path: pathlib.Path | None,
    *,
    contract_id: str = PANEL_CONTRACT_ID,
    release_strict: bool = True,
) -> pd.DataFrame:
    if path is None or not path.exists():
        return empty_ambiguity_overrides()
    overrides = pd.read_csv(path, dtype=str).fillna("")
    missing = set(AMBIGUITY_OVERRIDE_COLUMNS) - set(overrides.columns)
    if missing:
        raise SystemExit(f"Dictionary ambiguity override file is missing columns: {', '.join(sorted(missing))}")
    overrides = overrides[AMBIGUITY_OVERRIDE_COLUMNS].copy()
    for column in AMBIGUITY_OVERRIDE_COLUMNS:
        overrides[column] = overrides[column].fillna("").astype(str).str.strip()
    overrides["source_file"] = overrides["source_file"].map(normalize_key)
    overrides["access_table_name"] = overrides["access_table_name"].map(normalize_key)
    overrides["varname"] = overrides["varname"].map(normalize_key)
    overrides["selected_source_varnumber"] = overrides["selected_source_varnumber"].map(normalize_varnumber)

    nonempty = overrides[overrides["varname"] != ""]
    bad_years = nonempty[
        ~nonempty["year_start"].str.fullmatch(r"\d{4}")
        | ~nonempty["year_end"].str.fullmatch(r"\d{4}")
        | (pd.to_numeric(nonempty["year_start"], errors="coerce") > pd.to_numeric(nonempty["year_end"], errors="coerce"))
    ]
    if not bad_years.empty:
        raise SystemExit("Dictionary ambiguity overrides require a valid inclusive year_start/year_end range.")
    bad_rows = nonempty[
        (nonempty["contract_id"] != contract_id)
        | ((nonempty["source_file"] == "") & (nonempty["access_table_name"] == ""))
        | (nonempty["selected_source_varnumber"] == "")
        | (nonempty["evidence"] == "")
        | (nonempty["justification"] == "")
    ]
    if not bad_rows.empty:
        raise SystemExit(
            "Dictionary ambiguity overrides must bind the current contract and include source/table scope, "
            "a selected source_varnumber, evidence, and justification."
        )
    review_dates = pd.to_datetime(nonempty["review_date"], format="%Y-%m-%d", errors="coerce")
    invalid_review_state = nonempty[
        ~nonempty["review_status"].str.lower().isin({"approved", "pending"})
        | (
            (nonempty["review_status"].str.lower() == "approved")
            & ((nonempty["reviewer"] == "") | review_dates.isna())
        )
    ]
    if not invalid_review_state.empty:
        raise SystemExit(
            "Dictionary ambiguity overrides must be pending or approved; approved rows require reviewer and ISO review_date."
        )
    if release_strict:
        release_invalid = nonempty[
            (nonempty["review_status"].str.lower() != "approved")
        ]
        if not release_invalid.empty:
            raise SystemExit(
                "Release-strict dictionary ambiguity overrides must be approved with reviewer and ISO review_date."
            )
    scoped = nonempty.reset_index(drop=True)
    for left_index in range(len(scoped)):
        left = scoped.iloc[left_index]
        for right_index in range(left_index + 1, len(scoped)):
            right = scoped.iloc[right_index]
            if left["contract_id"] != right["contract_id"] or left["varname"] != right["varname"]:
                continue
            years_overlap = int(left["year_start"]) <= int(right["year_end"]) and int(
                right["year_start"]
            ) <= int(left["year_end"])
            sources_overlap = (
                left["source_file"] == ""
                or right["source_file"] == ""
                or left["source_file"] == right["source_file"]
            )
            tables_overlap = (
                left["access_table_name"] == ""
                or right["access_table_name"] == ""
                or left["access_table_name"] == right["access_table_name"]
            )
            if years_overlap and sources_overlap and tables_overlap:
                raise SystemExit(
                    "Dictionary ambiguity override scopes must be unique and non-overlapping; "
                    f"rows {left_index + 2} and {right_index + 2} can match the same source variable."
                )
    return overrides


def matching_override_rows(
    overrides: pd.DataFrame,
    *,
    year: int | None,
    source_norm: str,
    access_norm: str,
    varname: str,
) -> pd.DataFrame:
    if overrides.empty:
        return overrides
    rows = overrides[overrides["varname"] == varname].copy()
    if year is not None:
        rows = rows[
            (pd.to_numeric(rows["year_start"], errors="coerce") <= int(year))
            & (pd.to_numeric(rows["year_end"], errors="coerce") >= int(year))
        ]
    if source_norm:
        rows = rows[(rows["source_file"] == "") | (rows["source_file"] == source_norm)]
    else:
        rows = rows[rows["source_file"] == ""]
    if access_norm:
        rows = rows[(rows["access_table_name"] == "") | (rows["access_table_name"] == access_norm)]
    else:
        rows = rows[rows["access_table_name"] == ""]
    return rows


def apply_dictionary_override(group: pd.DataFrame, override: pd.Series) -> pd.DataFrame:
    candidates = group.copy()
    if str(override.get("selected_source_varnumber", "")).strip():
        candidates = candidates[
            candidates["source_varnumber"].map(normalize_varnumber)
            == str(override["selected_source_varnumber"])
        ]
    if str(override.get("selected_metadata_source", "")).strip():
        candidates = candidates[candidates["metadata_source"].fillna("").astype(str) == str(override["selected_metadata_source"])]
    if str(override.get("selected_metadata_table_name", "")).strip():
        candidates = candidates[candidates["metadata_table_name"].fillna("").astype(str) == str(override["selected_metadata_table_name"])]
    if len(candidates) != 1:
        varname = str(group["varname"].iloc[0])
        raise SystemExit(
            f"[fatal] dictionary ambiguity override for varname={varname} matched {len(candidates)} rows; expected exactly 1"
        )
    return candidates


def describe_dictionary_ambiguity(group: pd.DataFrame) -> str:
    cols = ["year", "source_file", "access_table_name", "varname", "varnumber", "metadata_source", "metadata_table_name"]
    present = [col for col in cols if col in group.columns]
    rows = group[present].drop_duplicates().head(10).to_dict("records")
    return "; ".join(str(row) for row in rows)


def enforce_unambiguous_dict_source(
    subset: pd.DataFrame,
    *,
    source_norm: str,
    access_norm: str,
    overrides: pd.DataFrame,
) -> pd.DataFrame:
    if subset.empty:
        return subset
    subset = ensure_dict_columns(subset)
    subset["metadata_source"] = subset["metadata_source"].fillna("").astype(str)
    subset["metadata_table_name"] = subset["metadata_table_name"].fillna("").astype(str)
    subset = subset.sort_values(["varname", "metadata_source", "metadata_table_name", "varnumber"])
    year_value = pd.to_numeric(subset["year"], errors="coerce").dropna()
    year = int(year_value.iloc[0]) if not year_value.empty else None

    selected_groups: list[pd.DataFrame] = []
    for varname, group in subset.groupby("varname", sort=True, dropna=False):
        unique_group = group.drop_duplicates(
            ["year", "source_file", "access_table_name", "varname", "varnumber", "metadata_source", "metadata_table_name"]
        )
        if len(unique_group) <= 1:
            selected_groups.append(group.head(1))
            continue
        override_rows = matching_override_rows(
            overrides,
            year=year,
            source_norm=source_norm,
            access_norm=access_norm,
            varname=str(varname),
        )
        if override_rows.empty:
            raise SystemExit(
                "[fatal] ambiguous dictionary mapping for "
                f"year={year or ''} source_file={source_norm} access_table_name={access_norm} varname={varname}. "
                "Add a documented row to contracts/dictionary_ambiguity_overrides.csv. "
                f"Candidates: {describe_dictionary_ambiguity(unique_group)}"
            )
        if len(override_rows) > 1:
            raise SystemExit(
                "[fatal] multiple dictionary ambiguity overrides match "
                f"year={year or ''} source_file={source_norm} access_table_name={access_norm} varname={varname}"
            )
        selected_groups.append(apply_dictionary_override(unique_group, override_rows.iloc[0]))
    if not selected_groups:
        return subset.iloc[0:0].copy()
    return pd.concat(selected_groups, ignore_index=True)


def matching_source_metadata_aliases(
    aliases: pd.DataFrame,
    *,
    year: int | None,
    source_norm: str,
    access_norm: str,
    varname: str | None = None,
) -> pd.DataFrame:
    if aliases.empty or year is None:
        return aliases.iloc[0:0].copy()
    rows = aliases[
        (pd.to_numeric(aliases["year"], errors="coerce") == int(year))
        & (aliases["source_file"] == source_norm)
        & (aliases["source_access_table_name"] == access_norm)
    ].copy()
    if varname is not None:
        rows = rows[rows["source_varname"] == normalize_key(varname)]
    return rows


def apply_source_metadata_aliases(
    subset: pd.DataFrame,
    *,
    aliases: pd.DataFrame,
    year: int | None,
    source_norm: str,
    access_norm: str,
) -> pd.DataFrame:
    scoped = matching_source_metadata_aliases(
        aliases,
        year=year,
        source_norm=source_norm,
        access_norm=access_norm,
    )
    if scoped.empty:
        if (year, source_norm, access_norm) in REVIEWED_ALIAS_REQUIRED_SCOPES:
            return subset[
                subset["access_table_name"]
                .fillna("")
                .astype(str)
                .str.upper()
                .eq(access_norm)
            ].copy()
        return subset

    selected: list[pd.DataFrame] = []
    varnames = sorted(
        set(subset["varname"].fillna("").astype(str))
        | set(scoped["source_varname"].astype(str))
    )
    for varname in varnames:
        group = subset[subset["varname"] == varname].copy()
        exact = group[
            group["access_table_name"].fillna("").astype(str).str.upper()
            == access_norm
        ]
        if not exact.empty:
            selected.append(exact)
            continue

        alias_rows = scoped[scoped["source_varname"] == varname]
        if alias_rows.empty:
            # Alias-governed tables may not use an implicit cross-table fallback.
            continue
        if len(alias_rows) != 1:
            raise SystemExit(
                "[fatal] multiple source metadata aliases match "
                f"year={year} source_file={source_norm} "
                f"access_table_name={access_norm} varname={varname}"
            )
        alias = alias_rows.iloc[0]
        metadata_table_names = group["metadata_table_names"].fillna("").astype(str)
        metadata_table_names = metadata_table_names.where(
            metadata_table_names.str.strip().ne(""),
            group["metadata_table_name"].fillna("").astype(str),
        )
        candidates = group[
            (
                group["access_table_name"].fillna("").astype(str).str.upper()
                == alias["selected_access_table_name"]
            )
            & (
                group["metadata_file_number"].fillna("").astype(str).str.strip()
                == alias["selected_file_number"]
            )
            & (
                group["source_varnumber"].map(normalize_varnumber)
                == alias["selected_source_varnumber"]
            )
            & (
                group["varname"].fillna("").astype(str).str.upper()
                == alias["selected_varname"]
            )
            & (
                group["metadata_source"]
                .fillna("")
                .astype(str)
                .str.strip()
                .str.casefold()
                == str(alias["selected_metadata_source"]).strip().casefold()
            )
            & exact_casefolded_token_match(
                metadata_table_names,
                alias["selected_metadata_table_name"],
            )
        ]
        if len(candidates) != 1:
            raise SystemExit(
                "[fatal] reviewed source metadata alias for "
                f"year={year} source_file={source_norm} "
                f"access_table_name={access_norm} varname={varname} "
                f"matched {len(candidates)} dictionary rows; expected exactly 1"
            )
        selected.append(candidates)
    if not selected:
        return subset.iloc[0:0].copy()
    out = pd.concat(selected, ignore_index=True)
    order = [
        "varname",
        "access_table_name",
        "metadata_file_number",
        "source_varnumber",
        "metadata_source",
        "metadata_table_name",
    ]
    return out.sort_values(order, kind="mergesort").reset_index(drop=True)


def select_dict_source(
    dict_year: pd.DataFrame,
    source_file: str,
    access_table_name: str,
    overrides: pd.DataFrame | None = None,
    *,
    aliases: pd.DataFrame | None = None,
) -> pd.DataFrame:
    source_norm = str(source_file or "").strip().upper()
    access_norm = str(access_table_name or "").strip().upper()
    dict_year = ensure_dict_columns(dict_year)
    subset = dict_year[
        (dict_year["source_file"].fillna("").astype(str).str.upper() == source_norm)
        | (dict_year["access_table_name"].fillna("").astype(str).str.upper() == access_norm)
    ].copy()
    if subset.empty and source_norm:
        subset = dict_year[dict_year["source_file"].fillna("").astype(str).str.upper() == source_norm].copy()
    if subset.empty:
        return subset
    year_value = pd.to_numeric(subset["year"], errors="coerce").dropna()
    year = int(year_value.iloc[0]) if not year_value.empty else None
    subset = apply_source_metadata_aliases(
        subset,
        aliases=aliases if aliases is not None else empty_source_metadata_aliases(),
        year=year,
        source_norm=source_norm,
        access_norm=access_norm,
    )
    return enforce_unambiguous_dict_source(
        subset,
        source_norm=source_norm,
        access_norm=access_norm,
        overrides=overrides if overrides is not None else empty_ambiguity_overrides(),
    )


def frame_to_schema_table(frame: pd.DataFrame, schema: pa.Schema) -> pa.Table:
    out = frame.copy()
    for field in schema:
        if field.name not in out.columns:
            out[field.name] = pd.NA if pa.types.is_integer(field.type) else ""
        if pa.types.is_integer(field.type):
            out[field.name] = pd.to_numeric(out[field.name], errors="raise").astype("Int64")
        else:
            out[field.name] = out[field.name].fillna("").astype(str)
    return pa.Table.from_pandas(out[schema.names], schema=schema, preserve_index=False, safe=True)


class ParquetPartSink:
    """Write schema-stable parts and atomically assemble a final parquet."""

    def __init__(self, out_path: pathlib.Path, parts_dir: pathlib.Path, schema: pa.Schema):
        self.out_path = out_path
        self.parts_dir = parts_dir
        self.schema = schema
        self.count = 0
        if self.parts_dir.exists():
            shutil.rmtree(self.parts_dir)
        self.parts_dir.mkdir(parents=True, exist_ok=True)

    def write(self, frame: pd.DataFrame) -> None:
        if frame.empty:
            return
        part = self.parts_dir / f"part_{self.count:06d}.parquet"
        pq.write_table(frame_to_schema_table(frame, self.schema), part, compression="snappy")
        self.count += 1

    def finalize(self) -> None:
        self.out_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.out_path.with_suffix(self.out_path.suffix + ".tmp")
        if tmp.exists():
            tmp.unlink()
        writer = pq.ParquetWriter(tmp, self.schema, compression="snappy")
        try:
            for part in sorted(self.parts_dir.glob("part_*.parquet")):
                pf = pq.ParquetFile(part)
                for batch in pf.iter_batches():
                    writer.write_batch(batch)
        finally:
            writer.close()
        tmp.replace(self.out_path)


def normalize_source_headers(frame: pd.DataFrame, table_name: str) -> pd.DataFrame:
    headers = [normalize_key(column) for column in frame.columns]
    duplicates = sorted({header for header in headers if headers.count(header) > 1})
    if duplicates:
        raise SystemExit(f"[fatal] duplicate normalized source columns in {table_name}: {', '.join(duplicates)}")
    out = frame.copy()
    out.columns = headers
    return out


def attach_source_row_identity(
    frame: pd.DataFrame,
    *,
    year: int,
    source_file: str,
    access_table_name: str,
    source_csv_sha256: str,
    first_ordinal: int,
    lane: str,
    dimension_specs: list[tuple[str, str]],
    contract_id: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Attach deterministic source-row identity and return the row sidecar."""
    raw_columns = list(frame.columns)
    source_unitid = frame["UNITID"].fillna("").astype(str)
    parsed_unitid = pd.to_numeric(source_unitid.str.strip(), errors="coerce")
    if parsed_unitid.isna().any():
        bad = source_unitid[parsed_unitid.isna()].head(10).tolist()
        raise SystemExit(f"[fatal] invalid or missing UNITID tokens in {access_table_name}: {bad}")
    nonintegral = (parsed_unitid % 1 != 0)
    if nonintegral.any():
        bad = source_unitid[nonintegral].head(10).tolist()
        raise SystemExit(f"[fatal] non-integral UNITID tokens in {access_table_name}: {bad}")

    row_json = frame[raw_columns].apply(
        lambda row: stable_json({column: str(row[column]) for column in raw_columns}),
        axis=1,
    )
    out = frame.copy()
    out["UNITID"] = parsed_unitid.astype("int64")
    out["source_unitid_token"] = source_unitid
    ordinals = pd.Series(range(first_ordinal, first_ordinal + len(out)), index=out.index, dtype="int64")
    row_hashes = row_json.map(sha256_text)
    row_ids = [
        sha256_text(
            f"{contract_id}\0{year}\0{source_csv_sha256}\0{normalize_key(source_file)}\0"
            f"{normalize_key(access_table_name)}\0{int(ordinal)}\0{row_hash}"
        )
        for ordinal, row_hash in zip(ordinals, row_hashes, strict=True)
    ]

    def dimensions_for_row(row: pd.Series) -> str:
        return stable_json({canonical: str(row[source_column]) for source_column, canonical in dimension_specs})

    for source_column, canonical in dimension_specs:
        blank = frame[source_column].fillna("").astype(str).str.strip().eq("")
        if blank.any():
            ordinals = (blank[blank].index[:10] + first_ordinal).tolist()
            raise SystemExit(
                f"[fatal] blank dimension {canonical} ({source_column}) in {access_table_name}; "
                f"source row ordinals={ordinals}"
            )

    dimensions = out.apply(dimensions_for_row, axis=1) if dimension_specs else pd.Series("{}", index=out.index)
    out["_source_row_ordinal"] = ordinals
    out["_source_row_hash"] = row_hashes
    out["_source_row_id"] = row_ids
    out["_dimensions_json"] = dimensions
    out["_dimension_key_hash"] = dimensions.map(sha256_text)
    out["_source_row_json"] = row_json

    source_rows = pd.DataFrame(
        {
            "year": year,
            "UNITID": out["UNITID"],
            "contract_id": contract_id,
            "source_unitid_token": source_unitid,
            "source_file": normalize_key(source_file),
            "access_table_name": access_table_name,
            "lane": lane,
            "source_csv_sha256": source_csv_sha256,
            "source_row_ordinal": ordinals,
            "source_row_hash": row_hashes,
            "source_row_id": row_ids,
            "source_duplicate_count": 1,
            "source_row_ids_json": [stable_json([value]) for value in row_ids],
            "source_row_ordinals_json": [stable_json([int(value)]) for value in ordinals],
            "dimension_json": dimensions,
            "dimension_key": dimensions.map(sha256_text),
            "source_row_json": row_json,
        }
    )
    return out, source_rows


def build_long_cells(
    frame: pd.DataFrame,
    *,
    year: int,
    source_file: str,
    access_table_name: str,
    lane: str,
    source_csv_sha256: str,
    contract_id: str,
    dict_source: pd.DataFrame,
    value_columns: list[str],
    value_cols_per_chunk: int,
) -> Iterable[pd.DataFrame]:
    identity_columns = [
        "UNITID",
        "_source_row_ordinal",
        "_source_row_hash",
        "_source_row_id",
        "_dimensions_json",
        "_dimension_key_hash",
    ]
    for value_chunk in chunk_cols(value_columns, value_cols_per_chunk):
        long = frame.melt(
            id_vars=identity_columns,
            value_vars=value_chunk,
            var_name="varname",
            value_name="raw_value",
        )
        before_merge = len(long)
        merged = long.merge(dict_source, on="varname", how="left", validate="m:1")
        if len(merged) != before_merge:
            raise SystemExit(f"[fatal] dictionary merge expanded rows for table {access_table_name}")
        if merged["variable_id"].fillna("").astype(str).str.strip().eq("").any():
            raise SystemExit(f"[fatal] missing variable_id after dictionary merge for table {access_table_name}")

        merged["imputation_value"] = ""
        for imputation_column in sorted(
            {
                normalize_key(value)
                for value in merged["imputationvar"].fillna("").astype(str)
                if normalize_key(value) in frame.columns
            }
        ):
            lookup = frame.set_index("_source_row_id")[imputation_column]
            mask = merged["imputationvar"].fillna("").astype(str).str.upper().str.strip() == imputation_column
            merged.loc[mask, "imputation_value"] = merged.loc[mask, "_source_row_id"].map(lookup).fillna("")

        merged["year"] = year
        merged["contract_id"] = contract_id
        merged["value"] = merged["raw_value"]
        merged["value_status"] = merged["raw_value"].fillna("").astype(str).str.strip().map(
            lambda token: "missing" if token == "" else "reported"
        )
        merged["source_file"] = normalize_key(source_file)
        merged["access_table_name"] = access_table_name
        merged["lane"] = lane
        merged["source_csv_sha256"] = source_csv_sha256
        merged["source_row_ordinal"] = merged["_source_row_ordinal"]
        merged["source_row_hash"] = merged["_source_row_hash"]
        merged["source_row_id"] = merged["_source_row_id"]
        merged["source_duplicate_count"] = 1
        merged["source_row_ids_json"] = merged["source_row_id"].map(lambda value: stable_json([value]))
        merged["source_row_ordinals_json"] = merged["source_row_ordinal"].map(lambda value: stable_json([int(value)]))
        merged["dimension_json"] = merged["_dimensions_json"]
        merged["dimension_key"] = merged["_dimension_key_hash"]
        yield merged[LONG_PANEL_COLUMNS]


def validate_injective_value_mapping(
    dict_source: pd.DataFrame,
    value_columns: list[str],
    *,
    access_table_name: str,
) -> None:
    """Prove that each selected source column has its own cell identity."""
    selected = dict_source[
        dict_source["varname"].fillna("").astype(str).isin(value_columns)
    ][["varname", "variable_id"]].copy()
    selected["varname"] = selected["varname"].fillna("").astype(str)
    selected["variable_id"] = selected["variable_id"].fillna("").astype(str)
    selected = selected.drop_duplicates()
    collisions = selected[
        selected["variable_id"].duplicated(keep=False)
    ].sort_values(["variable_id", "varname"], kind="mergesort")
    if not collisions.empty:
        raise SystemExit(
            "[fatal] multiple source columns map to one variable_id in "
            f"{access_table_name}: {collisions.to_dict('records')}"
        )


def write_parquet_parts(out_path: pathlib.Path, frames: Iterable[pd.DataFrame], parts_dir: pathlib.Path) -> None:
    if parts_dir.exists():
        shutil.rmtree(parts_dir)
    parts_dir.mkdir(parents=True, exist_ok=True)
    idx = 0
    for chunk in frames:
        if chunk.empty:
            continue
        pq.write_table(pa.Table.from_pandas(chunk, preserve_index=False), parts_dir / f"part_{idx:05d}.parquet", compression="snappy")
        idx += 1
    if idx == 0:
        return
    tmp_out = out_path.with_suffix(out_path.suffix + ".tmp")
    if tmp_out.exists():
        tmp_out.unlink()
    writer = None
    for part in sorted(parts_dir.glob("part_*.parquet")):
        pf = pq.ParquetFile(part)
        for batch in pf.iter_batches():
            if writer is None:
                writer = pq.ParquetWriter(tmp_out, batch.schema, compression="snappy")
            writer.write_batch(batch)
    if writer:
        writer.close()
        tmp_out.replace(out_path)


def sql_quote(text: str) -> str:
    return "'" + str(text).replace("'", "''") + "'"


def open_duckdb_connection(
    settings: DuckDBSettings | None = None,
) -> duckdb.DuckDBPyConnection:
    """Open a DuckDB connection with consistent bounded-resource settings."""
    settings = settings or DuckDBSettings()
    con = duckdb.connect()
    try:
        if settings.memory_limit:
            con.execute(f"SET memory_limit={sql_quote(settings.memory_limit)}")
        if settings.temp_dir is not None:
            settings.temp_dir.mkdir(parents=True, exist_ok=True)
            con.execute(f"SET temp_directory={sql_quote(str(settings.temp_dir))}")
        if settings.threads is not None:
            con.execute(f"SET threads={max(int(settings.threads), 1)}")
        con.execute("SET preserve_insertion_order=false")
        if settings.max_temp_gib is not None:
            if int(settings.max_temp_gib) <= 0:
                raise ValueError("max_temp_gib must be positive")
            con.execute(f"SET max_temp_directory_size='{int(settings.max_temp_gib)}GiB'")
    except BaseException:
        con.close()
        raise
    return con


def all_blank_long_row_sql() -> str:
    return " AND ".join(
        f"({col} IS NULL OR NULLIF(TRIM(CAST({col} AS VARCHAR)), '') IS NULL)"
        for col in LONG_PANEL_COLUMNS
    )


def long_key_null_counts_sql(
    path: pathlib.Path,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> dict[str, int]:
    con = open_duckdb_connection(duckdb_settings)
    try:
        row = con.execute(
            f"""
            SELECT
                SUM(CASE WHEN year IS NULL THEN 1 ELSE 0 END) AS year,
                SUM(CASE WHEN UNITID IS NULL THEN 1 ELSE 0 END) AS UNITID,
                SUM(CASE WHEN variable_id IS NULL OR TRIM(CAST(variable_id AS VARCHAR)) = '' THEN 1 ELSE 0 END) AS variable_id,
                SUM(CASE WHEN source_file IS NULL OR TRIM(CAST(source_file AS VARCHAR)) = '' THEN 1 ELSE 0 END) AS source_file,
                SUM(CASE WHEN source_row_id IS NULL OR TRIM(CAST(source_row_id AS VARCHAR)) = '' THEN 1 ELSE 0 END) AS source_row_id
            FROM read_parquet({sql_quote(str(path))})
            """
        ).fetchone()
    finally:
        con.close()
    key_columns = ["year", "UNITID", "variable_id", "source_file", "source_row_id"]
    return {col: int(row[idx] or 0) for idx, col in enumerate(key_columns)}


def empty_missing_unitid_frame(rows: list[dict] | None = None) -> pd.DataFrame:
    return pd.DataFrame(rows or [], columns=MISSING_UNITID_COLUMNS)


def empty_harmonize_summary_frame(rows: list[dict] | None = None) -> pd.DataFrame:
    return pd.DataFrame(rows or [], columns=HARMONIZE_SUMMARY_COLUMNS)


def dictionary_match_counts(dict_year: pd.DataFrame, source_file: str, access_table_name: str) -> tuple[int, int]:
    source_norm = str(source_file or "").strip().upper()
    access_norm = str(access_table_name or "").strip().upper()
    source_match_rows = 0
    access_match_rows = 0
    if source_norm:
        source_match_rows = int(
            (
                dict_year["source_file"].fillna("").astype(str).str.upper() == source_norm
            ).sum()
        )
    if access_norm:
        access_match_rows = int(
            (
                dict_year["access_table_name"].fillna("").astype(str).str.upper() == access_norm
            ).sum()
        )
    return source_match_rows, access_match_rows


def classify_exclude_reason(
    dict_source: pd.DataFrame,
    source_match_rows: int,
    access_match_rows: int,
    *,
    source_row_count: int = 0,
) -> str:
    if int(source_row_count) == 0:
        return "source_table_has_zero_rows"
    if not dict_source.empty:
        return "dictionary_rows_found_no_column_overlap"
    if access_match_rows > 0:
        return "dictionary_rows_found_for_access_table_but_source_selection_failed"
    if source_match_rows > 0:
        return "dictionary_rows_found_for_source_file_but_access_table_missing"
    if source_match_rows == 0:
        return "missing_dictionary_rows_for_source_file"
    return "no_dictionary_source_match"


def parquet_row_count(path: pathlib.Path) -> int:
    return int(pq.ParquetFile(path).metadata.num_rows)


def build_source_duplicate_map(
    source_rows_path: pathlib.Path,
    output_path: pathlib.Path,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> int:
    """Materialize lineage only for genuinely duplicated physical rows.

    Duplicate discovery is a source-row operation.  The first aggregation is
    deliberately count-only so DuckDB can spill it; ordered LIST state is
    created only for the much smaller set of groups that actually duplicate.
    """
    if not source_rows_path.exists():
        raise SystemExit(f"[fatal] missing source-row artifact: {source_rows_path}")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    duplicate_keys_path = output_path.with_name(f".{output_path.name}.keys.tmp")
    pending_path = output_path.with_name(f".{output_path.name}.pending")
    duplicate_keys_path.unlink(missing_ok=True)
    pending_path.unlink(missing_ok=True)
    key_sql = ", ".join(SOURCE_DUPLICATE_KEY_COLUMNS)
    source_sql = sql_quote(str(source_rows_path))
    settings = duckdb_settings or DuckDBSettings(temp_dir=output_path.parent)
    con = open_duckdb_connection(settings)
    try:
        con.execute(
            f"""
            COPY (
                SELECT {key_sql}, COUNT(*) AS duplicate_count
                FROM read_parquet({source_sql})
                GROUP BY {key_sql}
                HAVING COUNT(*) > 1
                ORDER BY {key_sql}
            ) TO {sql_quote(str(duplicate_keys_path))}
              (FORMAT PARQUET, COMPRESSION SNAPPY)
            """
        )
        con.execute(
            f"""
            COPY (
                SELECT {key_sql},
                       FIRST(raw.source_row_id ORDER BY raw.source_row_ordinal, raw.source_row_id)
                           AS representative_source_row_id,
                       CAST(keys.duplicate_count AS BIGINT) AS duplicate_count,
                       CAST(TO_JSON(LIST(
                           raw.source_row_id ORDER BY raw.source_row_ordinal, raw.source_row_id
                       )) AS VARCHAR) AS source_row_ids_json,
                       CAST(TO_JSON(LIST(
                           raw.source_row_ordinal ORDER BY raw.source_row_ordinal, raw.source_row_id
                       )) AS VARCHAR) AS source_row_ordinals_json
                FROM read_parquet({source_sql}) AS raw
                JOIN read_parquet({sql_quote(str(duplicate_keys_path))}) AS keys
                USING ({key_sql})
                GROUP BY {key_sql}, keys.duplicate_count
                ORDER BY {key_sql}
            ) TO {sql_quote(str(pending_path))}
              (FORMAT PARQUET, COMPRESSION SNAPPY)
            """
        )
    finally:
        con.close()
        duplicate_keys_path.unlink(missing_ok=True)
    duplicate_groups = parquet_row_count(pending_path)
    pending_path.replace(output_path)
    return duplicate_groups


def collapse_exact_source_rows(
    path: pathlib.Path,
    *,
    temp_dir: pathlib.Path,
    threads: int = 1,
    max_temp_gib: int | None = None,
    duckdb_settings: DuckDBSettings | None = None,
    duplicate_map_path: pathlib.Path | None = None,
) -> tuple[int, int]:
    """Collapse only byte-semantic duplicate cells.

    The source-row hash covers every normalized source column and token.  The
    representative keeps the lowest source ordinal while the complete set of
    deterministic row IDs/ordinals remains in JSON lineage columns.
    """
    columns = LONG_PANEL_COLUMNS
    partition = [
        "contract_id",
        "year",
        "source_csv_sha256",
        "source_file",
        "access_table_name",
        "source_row_hash",
        "variable_id",
        "varname",
    ]
    partition_sql = ", ".join(partition)
    final_order = "year, source_file, access_table_name, source_row_ordinal, variable_id"
    mapped_final_order = (
        "raw.year, raw.source_file, raw.access_table_name, "
        "raw.source_row_ordinal, raw.variable_id"
    )
    select_columns: list[str] = []
    for column in columns:
        if column == "source_duplicate_count":
            select_columns.append("CAST(_duplicate_count AS BIGINT) AS source_duplicate_count")
        elif column == "source_row_ids_json":
            select_columns.append("CAST(_source_row_ids_json AS VARCHAR) AS source_row_ids_json")
        elif column == "source_row_ordinals_json":
            select_columns.append("CAST(_source_row_ordinals_json AS VARCHAR) AS source_row_ordinals_json")
        else:
            select_columns.append(f'"{column}"')

    settings = duckdb_settings or DuckDBSettings(
        threads=threads,
        temp_dir=temp_dir,
        max_temp_gib=max_temp_gib,
    )
    temp_dir.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".exact.tmp")
    if tmp.exists():
        tmp.unlink()
    before = parquet_row_count(path)
    if duplicate_map_path is not None:
        if not duplicate_map_path.exists():
            raise SystemExit(
                f"[fatal] missing source duplicate map: {duplicate_map_path}"
            )
        if parquet_row_count(duplicate_map_path) == 0:
            return before, before
    con = open_duckdb_connection(settings)
    try:
        if duplicate_map_path is not None:
            map_sql = sql_quote(str(duplicate_map_path))
            join_sql = " AND ".join(
                f'raw."{column}" = duplicate_map."{column}"'
                for column in SOURCE_DUPLICATE_KEY_COLUMNS
            )
            coverage_errors = int(
                con.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM (
                        SELECT {', '.join(f'raw."{column}"' for column in SOURCE_DUPLICATE_KEY_COLUMNS)},
                               raw.variable_id,
                               raw.varname,
                               duplicate_map.duplicate_count,
                               COUNT(*) AS cell_rows,
                               COUNT(DISTINCT raw.source_row_id) AS physical_source_rows,
                               SUM(
                                   CASE WHEN raw.source_row_id = duplicate_map.representative_source_row_id
                                        THEN 1 ELSE 0 END
                               ) AS representative_rows
                        FROM read_parquet({sql_quote(str(path))}) AS raw
                        JOIN read_parquet({map_sql}) AS duplicate_map
                          ON {join_sql}
                        GROUP BY {', '.join(f'raw."{column}"' for column in SOURCE_DUPLICATE_KEY_COLUMNS)},
                                 raw.variable_id,
                                 raw.varname,
                                 duplicate_map.duplicate_count,
                                 duplicate_map.representative_source_row_id
                        HAVING COUNT(*) <> duplicate_map.duplicate_count
                            OR COUNT(DISTINCT raw.source_row_id) <> duplicate_map.duplicate_count
                            OR SUM(
                                CASE WHEN raw.source_row_id = duplicate_map.representative_source_row_id
                                     THEN 1 ELSE 0 END
                            ) <> 1
                    )
                    """
                ).fetchone()[0]
                or 0
            )
            if coverage_errors:
                raise SystemExit(
                    "[fatal] duplicate source-row cell coverage is incomplete or multiplied: "
                    f"groups={coverage_errors} path={path}"
                )
            mapped_select_columns: list[str] = []
            for column in columns:
                if column == "source_duplicate_count":
                    mapped_select_columns.append(
                        "CAST(COALESCE(duplicate_map.duplicate_count, "
                        "raw.source_duplicate_count) AS BIGINT) AS source_duplicate_count"
                    )
                elif column == "source_row_ids_json":
                    mapped_select_columns.append(
                        "CAST(COALESCE(duplicate_map.source_row_ids_json, "
                        "raw.source_row_ids_json) AS VARCHAR) AS source_row_ids_json"
                    )
                elif column == "source_row_ordinals_json":
                    mapped_select_columns.append(
                        "CAST(COALESCE(duplicate_map.source_row_ordinals_json, "
                        "raw.source_row_ordinals_json) AS VARCHAR) AS source_row_ordinals_json"
                    )
                else:
                    mapped_select_columns.append(f'raw."{column}"')
            con.execute(
                f"""
                COPY (
                    SELECT {', '.join(mapped_select_columns)}
                    FROM read_parquet({sql_quote(str(path))}) AS raw
                    LEFT JOIN read_parquet({map_sql}) AS duplicate_map
                      ON {join_sql}
                    WHERE duplicate_map.representative_source_row_id IS NULL
                       OR raw.source_row_id = duplicate_map.representative_source_row_id
                    ORDER BY {mapped_final_order}
                ) TO {sql_quote(str(tmp))}
                  (FORMAT PARQUET, COMPRESSION SNAPPY)
                """
            )
        else:
            con.execute(
                f"""
                COPY (
                    WITH grouped AS (
                        SELECT {partition_sql},
                               COUNT(*) AS _duplicate_count,
                               TO_JSON(LIST(source_row_id ORDER BY source_row_ordinal, source_row_id))
                                   AS _source_row_ids_json,
                               TO_JSON(LIST(source_row_ordinal ORDER BY source_row_ordinal, source_row_id))
                                   AS _source_row_ordinals_json
                        FROM read_parquet({sql_quote(str(path))})
                        GROUP BY {partition_sql}
                    ), ranked AS (
                        SELECT raw.*, grouped._duplicate_count,
                               grouped._source_row_ids_json,
                               grouped._source_row_ordinals_json,
                               ROW_NUMBER() OVER (
                                   PARTITION BY {partition_sql}
                                   ORDER BY source_row_ordinal, source_row_id
                               ) AS _row_number
                        FROM read_parquet({sql_quote(str(path))}) AS raw
                        JOIN grouped USING ({partition_sql})
                    )
                    SELECT {', '.join(select_columns)}
                    FROM ranked
                    WHERE _row_number = 1
                    ORDER BY {final_order}
                ) TO {sql_quote(str(tmp))} (FORMAT PARQUET, COMPRESSION SNAPPY)
                """
            )
    finally:
        con.close()
    after = parquet_row_count(tmp)
    tmp.replace(path)
    return before, after


def annotate_exact_source_rows(
    path: pathlib.Path,
    *,
    temp_dir: pathlib.Path,
    threads: int = 1,
    max_temp_gib: int | None = None,
    duckdb_settings: DuckDBSettings | None = None,
    duplicate_map_path: pathlib.Path | None = None,
) -> tuple[int, int]:
    """Classify exact duplicates while retaining every physical source row."""
    partition = ["contract_id", "year", "source_csv_sha256", "source_file", "access_table_name", "source_row_hash"]
    partition_sql = ", ".join(partition)
    select_columns: list[str] = []
    for column in SOURCE_ROW_COLUMNS:
        if column == "source_duplicate_count":
            select_columns.append("CAST(_duplicate_count AS BIGINT) AS source_duplicate_count")
        elif column == "source_row_ids_json":
            select_columns.append("CAST(_source_row_ids_json AS VARCHAR) AS source_row_ids_json")
        elif column == "source_row_ordinals_json":
            select_columns.append("CAST(_source_row_ordinals_json AS VARCHAR) AS source_row_ordinals_json")
        else:
            select_columns.append(f'"{column}"')

    settings = duckdb_settings or DuckDBSettings(
        threads=threads,
        temp_dir=temp_dir,
        max_temp_gib=max_temp_gib,
    )
    temp_dir.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".annotated.tmp")
    if tmp.exists():
        tmp.unlink()
    before = parquet_row_count(path)
    if duplicate_map_path is not None:
        if not duplicate_map_path.exists():
            raise SystemExit(
                f"[fatal] missing source duplicate map: {duplicate_map_path}"
            )
        if parquet_row_count(duplicate_map_path) == 0:
            return before, before
    con = open_duckdb_connection(settings)
    try:
        if duplicate_map_path is not None:
            join_sql = " AND ".join(
                f'raw."{column}" = duplicate_map."{column}"'
                for column in SOURCE_DUPLICATE_KEY_COLUMNS
            )
            mapped_select_columns: list[str] = []
            for column in SOURCE_ROW_COLUMNS:
                if column == "source_duplicate_count":
                    mapped_select_columns.append(
                        "CAST(COALESCE(duplicate_map.duplicate_count, "
                        "raw.source_duplicate_count) AS BIGINT) AS source_duplicate_count"
                    )
                elif column == "source_row_ids_json":
                    mapped_select_columns.append(
                        "CAST(COALESCE(duplicate_map.source_row_ids_json, "
                        "raw.source_row_ids_json) AS VARCHAR) AS source_row_ids_json"
                    )
                elif column == "source_row_ordinals_json":
                    mapped_select_columns.append(
                        "CAST(COALESCE(duplicate_map.source_row_ordinals_json, "
                        "raw.source_row_ordinals_json) AS VARCHAR) AS source_row_ordinals_json"
                    )
                else:
                    mapped_select_columns.append(f'raw."{column}"')
            con.execute(
                f"""
                COPY (
                    SELECT {', '.join(mapped_select_columns)}
                    FROM read_parquet({sql_quote(str(path))}) AS raw
                    LEFT JOIN read_parquet({sql_quote(str(duplicate_map_path))}) AS duplicate_map
                      ON {join_sql}
                    ORDER BY raw.year, raw.source_file, raw.access_table_name,
                             raw.source_row_ordinal, raw.source_row_id
                ) TO {sql_quote(str(tmp))} (FORMAT PARQUET, COMPRESSION SNAPPY)
                """
            )
        else:
            con.execute(
                f"""
                COPY (
                    WITH grouped AS (
                        SELECT {partition_sql},
                               COUNT(*) AS _duplicate_count,
                               TO_JSON(LIST(source_row_id ORDER BY source_row_ordinal, source_row_id))
                                   AS _source_row_ids_json,
                               TO_JSON(LIST(source_row_ordinal ORDER BY source_row_ordinal, source_row_id))
                                   AS _source_row_ordinals_json
                        FROM read_parquet({sql_quote(str(path))})
                        GROUP BY {partition_sql}
                    )
                    SELECT {', '.join(select_columns)}
                    FROM read_parquet({sql_quote(str(path))}) AS raw
                    JOIN grouped USING ({partition_sql})
                    ORDER BY year, source_file, access_table_name, source_row_ordinal
                ) TO {sql_quote(str(tmp))} (FORMAT PARQUET, COMPRESSION SNAPPY)
                """
            )
    finally:
        con.close()
    after = parquet_row_count(tmp)
    if after != before:
        tmp.unlink(missing_ok=True)
        raise SystemExit(
            f"[fatal] source-row duplicate annotation changed row count: before={before} after={after}"
        )
    tmp.replace(path)
    return before, after


def validate_lane_conflicts(
    path: pathlib.Path,
    lane: str,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> None:
    if parquet_row_count(path) == 0:
        return
    if lane == "scalar":
        key = "year, UNITID, variable_id, source_file"
        label = "scalar"
    elif lane == "dimensioned":
        key = "year, UNITID, source_file, access_table_name, dimension_key, variable_id"
        label = "dimension"
    else:
        raise ValueError(f"unsupported lane: {lane}")
    con = open_duckdb_connection(duckdb_settings)
    try:
        conflicts = con.execute(
            f"""
            SELECT {key}, COUNT(*) AS rows, COUNT(DISTINCT raw_value) AS distinct_tokens
            FROM read_parquet({sql_quote(str(path))})
            GROUP BY {key}
            HAVING COUNT(*) > 1
            ORDER BY rows DESC, {key}
            LIMIT 10
            """
        ).fetchdf()
    finally:
        con.close()
    if not conflicts.empty:
        raise SystemExit(
            f"[fatal] conflicting {label} cells remain after exact-source-row collapse; "
            f"only exact duplicate source rows may auto-collapse. Samples: {conflicts.to_dict('records')}"
        )


def validate_cell_source_references(
    cell_paths: list[pathlib.Path],
    source_rows_path: pathlib.Path,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> None:
    con = open_duckdb_connection(duckdb_settings)
    try:
        source_sql = sql_quote(str(source_rows_path))
        for cell_path in cell_paths:
            if parquet_row_count(cell_path) == 0:
                continue
            missing = con.execute(
                f"""
                SELECT COUNT(*)
                FROM read_parquet({sql_quote(str(cell_path))}) AS cells
                LEFT JOIN read_parquet({source_sql}) AS rows USING (source_row_id)
                WHERE rows.source_row_id IS NULL
                """
            ).fetchone()[0]
            if int(missing or 0) > 0:
                raise SystemExit(f"[fatal] {missing} cells lack source-row lineage in {cell_path}")
    finally:
        con.close()


def validate_source_row_grain(
    source_rows_path: pathlib.Path,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> None:
    """Prove reviewed scalar and dimensioned functional dependencies."""
    con = open_duckdb_connection(duckdb_settings)
    try:
        scalar_conflict = con.execute(
            f"""
            SELECT year, UNITID, source_file, access_table_name,
                   COUNT(DISTINCT source_row_hash) AS distinct_rows
            FROM read_parquet({sql_quote(str(source_rows_path))})
            WHERE lane = 'scalar'
            GROUP BY year, UNITID, source_file, access_table_name
            HAVING COUNT(DISTINCT source_row_hash) > 1
            LIMIT 10
            """
        ).fetchdf()
        if not scalar_conflict.empty:
            raise SystemExit(
                "[fatal] scalar table violates one reviewed source row per UNITID after exact-duplicate "
                f"classification: {scalar_conflict.to_dict('records')}"
            )
        dimension_conflict = con.execute(
            f"""
            SELECT year, UNITID, source_file, access_table_name, dimension_key,
                   COUNT(DISTINCT source_row_hash) AS distinct_rows
            FROM read_parquet({sql_quote(str(source_rows_path))})
            WHERE lane = 'dimensioned'
            GROUP BY year, UNITID, source_file, access_table_name, dimension_key
            HAVING COUNT(DISTINCT source_row_hash) > 1
            LIMIT 10
            """
        ).fetchdf()
        if not dimension_conflict.empty:
            raise SystemExit(
                "[fatal] dimensioned table violates its reviewed UNITID-plus-dimensions key after "
                f"exact-duplicate classification: {dimension_conflict.to_dict('records')}"
            )
    finally:
        con.close()


def source_row_duplicate_counts(
    source_rows_path: pathlib.Path,
    *,
    duckdb_settings: DuckDBSettings | None = None,
) -> pd.DataFrame:
    """Return per-table source-row and exact-duplicate counts."""
    con = open_duckdb_connection(duckdb_settings)
    try:
        return con.execute(
            f"""
            SELECT access_table_name,
                   COUNT(*) AS physical_rows,
                   COUNT(*) - COUNT(DISTINCT source_row_hash) AS exact_duplicate_rows
            FROM read_parquet({sql_quote(str(source_rows_path))})
            GROUP BY access_table_name
            """
        ).fetchdf()
    finally:
        con.close()


def dedupe_long_panel(
    out_path: pathlib.Path,
    priority_list: list[str],
    *,
    temp_dir: pathlib.Path,
    max_temp_gib: int | None = None,
    threads: int = 1,
    duckdb_settings: DuckDBSettings | None = None,
) -> None:
    """Compatibility wrapper for the v2 exact-source-row collapse.

    ``priority_list`` and ``max_temp_gib`` are intentionally ignored: source
    priority is not a scientific deduplication rule.
    """
    del priority_list
    settings = duckdb_settings or DuckDBSettings(
        threads=threads,
        temp_dir=temp_dir,
        max_temp_gib=max_temp_gib,
    )
    collapse_exact_source_rows(
        out_path,
        temp_dir=temp_dir,
        threads=threads,
        max_temp_gib=max_temp_gib,
        duckdb_settings=settings,
    )
    lane_values = pd.read_parquet(out_path, columns=["lane"])["lane"].dropna().unique().tolist()
    for lane in lane_values:
        validate_lane_conflicts(out_path, str(lane), duckdb_settings=settings)


def main() -> None:
    args = parse_args()
    setup_logging(args.log_file)
    layout = ensure_data_layout(args.root)
    years = parse_years(args.years)
    output_dir = pathlib.Path(args.output_dir) if args.output_dir else layout.cross_sections / "v2"
    parts_dir_base = pathlib.Path(args.parts_dir_base) if args.parts_dir_base else layout.build / "v2" / "harmonize_parts"
    output_dir.mkdir(parents=True, exist_ok=True)
    checks_v2 = layout.checks / "v2"
    (checks_v2 / "harmonize_qc").mkdir(parents=True, exist_ok=True)
    (checks_v2 / "release_qc").mkdir(parents=True, exist_ok=True)

    table_grain_contract = load_contract(
        pathlib.Path(args.table_grain_contract),
        TABLE_GRAIN_CONTRACT_COLUMNS,
        "table-grain",
        contract_id=args.contract_id,
    )
    source_column_contract = load_contract(
        pathlib.Path(args.source_column_contract),
        SOURCE_COLUMN_CONTRACT_COLUMNS,
        "source-column",
        contract_id=args.contract_id,
    )

    dict_path = pathlib.Path(args.dictionary) if args.dictionary else layout.dictionary / "v2" / "dictionary_lake.parquet"
    if not dict_path.exists():
        raise SystemExit(f"Missing dictionary lake: {dict_path}")
    raw_dictionary = pd.read_parquet(dict_path)
    required_dictionary_identity = {"variable_id", "source_varnumber", "variable_origin", "is_synthetic"}
    missing_dictionary_identity = sorted(required_dictionary_identity - set(raw_dictionary.columns))
    if missing_dictionary_identity:
        raise SystemExit(
            "[fatal] canonical v2 dictionary lacks identity columns: "
            + ", ".join(missing_dictionary_identity)
        )
    dict_df = ensure_dict_columns(raw_dictionary)
    if dict_df["variable_id"].fillna("").astype(str).str.strip().eq("").any():
        raise SystemExit("[fatal] canonical v2 dictionary contains blank variable_id values")
    synthetic = dict_df["is_synthetic"].fillna(False).astype(str).str.lower().isin({"1", "true", "yes"})
    variable_origin = dict_df["variable_origin"].fillna("").astype(str).str.lower()
    source_derived = variable_origin.isin({"nces", "backfill"})
    generated_synthetic = variable_origin.isin({"synthetic_unitid", "synthetic_imputation"})
    blank_source_number = dict_df["source_varnumber"].fillna("").astype(str).str.strip().eq("")
    if (source_derived & blank_source_number).any():
        raise SystemExit("[fatal] source-derived dictionary variables must retain source_varnumber")
    if (generated_synthetic & (~blank_source_number)).any():
        raise SystemExit("[fatal] generated synthetic dictionary variables cannot claim source_varnumber")
    valid_identity = ((~synthetic) & variable_origin.eq("nces")) | (
        synthetic & (variable_origin.eq("backfill") | generated_synthetic)
    )
    if (~valid_identity).any():
        raise SystemExit("[fatal] dictionary variable_origin and is_synthetic are inconsistent")
    dict_df["varnumber"] = dict_df["varnumber"].map(normalize_varnumber)
    dict_df["source_varnumber"] = dict_df["source_varnumber"].fillna("").astype(str)
    dict_df["variable_id"] = dict_df["variable_id"].fillna("").astype(str)
    dict_df["varname"] = dict_df["varname"].fillna("").astype(str).str.upper().str.strip()
    dict_df["imputationvar"] = dict_df["imputationvar"].fillna("").astype(str).str.upper().str.strip()
    dict_df.loc[dict_df["imputationvar"].isin({"NAN", "NONE", "<NA>", "NAT"}), "imputationvar"] = ""
    ambiguity_overrides = load_dictionary_ambiguity_overrides(
        pathlib.Path(args.dictionary_ambiguity_overrides) if args.dictionary_ambiguity_overrides else None,
        contract_id=args.contract_id,
        release_strict=args.release_strict,
    )
    source_metadata_aliases = load_source_metadata_aliases(
        pathlib.Path(args.source_metadata_aliases)
        if args.source_metadata_aliases
        else None,
        contract_id=args.contract_id,
        release_strict=args.release_strict,
    )

    run_id = uuid.uuid4().hex
    artifact_pairs: list[tuple[pathlib.Path, pathlib.Path]] = []
    completed_year_targets: list[tuple[int, pathlib.Path, pathlib.Path, pathlib.Path]] = []

    for year in years:
        year_dir = layout.raw_access / str(year)
        manifest_path = year_dir / "manifest.csv"
        inventory_path = year_dir / "metadata" / "table_inventory.csv"
        if not manifest_path.exists() or not inventory_path.exists():
            raise SystemExit(f"Missing manifest or table inventory for year {year}")
        manifest = pd.read_csv(manifest_path, dtype=str).fillna("")
        release_type = manifest.iloc[0]["release_type"].strip().lower()
        release_summary = pd.DataFrame([{"year": year, "release_type": release_type, "allowed": release_type == "final"}])
        release_summary_target = checks_v2 / "release_qc" / f"release_summary_{year}.csv"
        release_summary_pending = pending_artifact_path(release_summary_target, run_id)
        release_summary.to_csv(release_summary_pending, index=False)
        artifact_pairs.append((release_summary_pending, release_summary_target))
        if args.release_strict and release_type != "final":
            raise SystemExit(f"Unexpected non-final release for year {year}: {release_type}")

        inventory = pd.read_csv(inventory_path, dtype=str).fillna("")
        data_tables = inventory[
            (inventory["table_role"] == "data")
            & (inventory["has_unitid"].astype(str).str.lower().isin({"true", "1"}))
        ].copy()
        if data_tables.empty:
            raise SystemExit(f"No data tables with UNITID found for year {year}")
        dict_year = dict_df[pd.to_numeric(dict_df["year"], errors="coerce") == year].copy()
        if dict_year.empty:
            raise SystemExit(f"No dictionary rows found for year {year}")

        year_summary_rows: list[dict] = []
        na_drop_rows: list[dict] = []
        coverage_rows: list[dict] = []
        unresolved_nonempty: list[str] = []

        scalar_target = output_dir / f"panel_long_scalar_{year}.parquet"
        dimensioned_target = output_dir / f"panel_long_dimensioned_{year}.parquet"
        source_rows_target = output_dir / f"panel_source_rows_{year}.parquet"
        scalar_path = pending_artifact_path(scalar_target, run_id)
        dimensioned_path = pending_artifact_path(dimensioned_target, run_id)
        source_rows_path = pending_artifact_path(source_rows_target, run_id)
        artifact_pairs.extend(
            [
                (scalar_path, scalar_target),
                (dimensioned_path, dimensioned_target),
                (source_rows_path, source_rows_target),
            ]
        )
        parts_root = parts_dir_base / f"parts_{year}"
        scalar_sink = ParquetPartSink(scalar_path, parts_root / "scalar", LONG_PANEL_SCHEMA)
        dimensioned_sink = ParquetPartSink(dimensioned_path, parts_root / "dimensioned", LONG_PANEL_SCHEMA)
        source_rows_sink = ParquetPartSink(source_rows_path, parts_root / "source_rows", SOURCE_ROW_SCHEMA)

        for rec in data_tables.to_dict("records"):
            table_path = year_dir / rec["csv_path"]
            if not table_path.exists():
                raise SystemExit(f"[fatal] missing source table CSV: {table_path}")
            access_table_name = str(rec["table_name"])
            source_file = normalize_key(rec.get("normalized_table_name", ""))
            expected_source_rows = int(
                pd.to_numeric(pd.Series([rec.get("row_count_csv", "0")]), errors="coerce").fillna(0).iloc[0]
            )
            source_match_rows, access_match_rows = dictionary_match_counts(dict_year, source_file, access_table_name)
            dict_source = select_dict_source(
                dict_year,
                source_file,
                access_table_name,
                ambiguity_overrides,
                aliases=source_metadata_aliases,
            )
            dict_source = ensure_dict_columns(dict_source)

            try:
                grain = resolve_table_grain(
                    table_grain_contract,
                    year=year,
                    source_file=source_file,
                    access_table_name=access_table_name,
                )
            except SystemExit as exc:
                if args.release_strict:
                    raise
                print(f"[non-release warning] {exc}")
                year_summary_rows.append(
                    {
                        "year": year,
                        "table_name": access_table_name,
                        "source_file": source_file,
                        "selected": False,
                        "exclude_reason": "missing_reviewed_table_grain_contract_nonrelease",
                        "matched_cols": 0,
                        "output_rows": 0,
                        "dictionary_rows": int(len(dict_source)),
                        "source_match_rows": source_match_rows,
                        "access_table_match_rows": access_match_rows,
                        "lane": "",
                        "source_rows_read": 0,
                        "source_rows_written": 0,
                        "exact_duplicate_rows_collapsed": 0,
                    }
                )
                continue

            lane = str(grain["grain_class"])
            contract_dimension_columns = split_contract_columns(grain["dimension_columns"])
            source_sha256 = sha256_file(table_path)
            first_ordinal = 1
            source_rows_read = 0
            table_output_rows = 0
            value_columns: list[str] | None = None
            dimension_specs: list[tuple[str, str]] | None = None
            expected_headers: list[str] | None = None
            coverage_by_column: dict[str, dict] = {}

            for raw_frame in read_table_iter(table_path, chunksize=args.chunksize):
                frame = normalize_source_headers(raw_frame, access_table_name)
                if expected_headers is None:
                    expected_headers = list(frame.columns)
                    if "UNITID" not in expected_headers:
                        raise SystemExit(f"[fatal] missing UNITID column in data table {access_table_name}")
                    applicable_mask = source_column_contract.apply(
                        contract_row_matches,
                        axis=1,
                        year=year,
                        source_file=source_file,
                        access_table_name=access_table_name,
                    )
                    applicable_source_contract = source_column_contract[applicable_mask].copy()
                    applicable_source_contract = applicable_source_contract[
                        applicable_source_contract["reviewed"].map(reviewed_value)
                    ]
                    # A wildcard projection classifies a column when that exact
                    # table-column identity exists; it does not declare that the
                    # column must occur in every physical table in the source
                    # family.  Literal table declarations remain required.
                    exact_table_contract = applicable_source_contract[
                        applicable_source_contract["access_table_pattern"].map(normalize_key)
                        == normalize_key(access_table_name)
                    ]
                    declared_columns = set(exact_table_contract["column_name"])
                    missing_declared_columns = sorted(declared_columns - set(expected_headers))
                    if missing_declared_columns:
                        raise SystemExit(
                            f"[fatal] reviewed source-column contract columns are absent from {access_table_name}: "
                            + ", ".join(missing_declared_columns)
                        )
                    resolved_columns: dict[str, pd.Series | None] = {}
                    for column in expected_headers:
                        resolved_columns[column] = resolve_source_column_contract(
                            source_column_contract,
                            year=year,
                            source_file=source_file,
                            access_table_name=access_table_name,
                            column_name=column,
                        )
                        contract_row = resolved_columns[column]
                        coverage_by_column[column] = {
                            "year": year,
                            "source_file": source_file,
                            "access_table_name": access_table_name,
                            "column_name": column,
                            "role": "" if contract_row is None else str(contract_row["role"]),
                            "canonical_dimension": "" if contract_row is None else str(contract_row["canonical_dimension"]),
                            "reviewed": False if contract_row is None else True,
                            "nonempty_tokens": 0,
                            "resolution": "unclassified" if contract_row is None else "classified",
                        }

                    unitid_contract = resolved_columns.get("UNITID")
                    if unitid_contract is None or str(unitid_contract["role"]) != "identifier":
                        raise SystemExit(f"[fatal] UNITID must have reviewed identifier role for {access_table_name}")
                    dimension_specs = [
                        (column, str(contract_row["canonical_dimension"]))
                        for column, contract_row in resolved_columns.items()
                        if contract_row is not None and str(contract_row["role"]) == "dimension"
                    ]
                    dimension_columns = [column for column, _canonical in dimension_specs]
                    canonical_dimensions = [canonical for _column, canonical in dimension_specs]
                    if len(canonical_dimensions) != len(set(canonical_dimensions)):
                        raise SystemExit(f"[fatal] duplicate canonical dimensions in contract for {access_table_name}")
                    if set(dimension_columns) != set(contract_dimension_columns):
                        raise SystemExit(
                            f"[fatal] table/source-column dimension contract mismatch for {access_table_name}: "
                            f"table={contract_dimension_columns} columns={dimension_columns}"
                        )
                    if lane == "scalar" and dimension_columns:
                        raise SystemExit(f"[fatal] scalar table {access_table_name} declares dimensions")
                    if lane == "dimensioned" and not dimension_columns:
                        raise SystemExit(f"[fatal] dimensioned table {access_table_name} lacks dimensions")
                    if lane in {"metadata", "excluded"} and dimension_columns:
                        raise SystemExit(f"[fatal] {lane} table {access_table_name} may not declare output dimensions")

                    contracted_values = [
                        column
                        for column, contract_row in resolved_columns.items()
                        if contract_row is not None and str(contract_row["role"]) == "measure"
                    ]
                    dictionary_values = set(dict_source["varname"].fillna("").astype(str))
                    value_columns = [column for column in contracted_values if column in dictionary_values]
                    validate_injective_value_mapping(
                        dict_source,
                        value_columns,
                        access_table_name=access_table_name,
                    )
                    if lane in {"scalar", "dimensioned"} and not contracted_values:
                        raise SystemExit(
                            f"[fatal] {lane} table {access_table_name} has no reviewed measure columns"
                        )
                    if lane in {"scalar", "dimensioned"} and not value_columns:
                        raise SystemExit(
                            f"[fatal] {lane} table {access_table_name} has no dictionary-backed measure columns"
                        )
                    for column in contracted_values:
                        if column not in dictionary_values:
                            coverage_by_column[column]["resolution"] = "missing_dictionary_mapping"
                elif list(frame.columns) != expected_headers:
                    raise SystemExit(
                        f"[fatal] source CSV schema changed between chunks for {access_table_name}: "
                        f"expected={expected_headers} actual={list(frame.columns)}"
                    )

                assert value_columns is not None
                assert dimension_specs is not None
                for column in frame.columns:
                    coverage_by_column[column]["nonempty_tokens"] += int(
                        frame[column].fillna("").astype(str).str.strip().ne("").sum()
                    )
                source_rows_read += len(frame)
                identified, source_rows = attach_source_row_identity(
                    frame,
                    year=year,
                    source_file=source_file,
                    access_table_name=access_table_name,
                    source_csv_sha256=source_sha256,
                    first_ordinal=first_ordinal,
                    lane=lane,
                    dimension_specs=dimension_specs,
                    contract_id=args.contract_id,
                )
                source_rows_sink.write(source_rows)
                if lane in {"scalar", "dimensioned"}:
                    for cells in build_long_cells(
                        identified,
                        year=year,
                        source_file=source_file,
                        access_table_name=access_table_name,
                        lane=lane,
                        source_csv_sha256=source_sha256,
                        contract_id=args.contract_id,
                        dict_source=dict_source,
                        value_columns=value_columns,
                        value_cols_per_chunk=args.value_cols_per_chunk,
                    ):
                        (scalar_sink if lane == "scalar" else dimensioned_sink).write(cells)
                        table_output_rows += len(cells)
                first_ordinal += len(frame)

            if source_rows_read != expected_source_rows:
                message = (
                    f"[fatal] source row-count reconciliation failed for {access_table_name}: "
                    f"inventory={expected_source_rows} parsed={source_rows_read}"
                )
                if args.release_strict:
                    raise SystemExit(message)
                print(f"[non-release warning] {message}")
            final_source_sha256 = sha256_file(table_path)
            if final_source_sha256 != source_sha256:
                raise SystemExit(
                    f"[fatal] source CSV changed while Stage 04 was reading {access_table_name}: "
                    f"before={source_sha256} after={final_source_sha256}"
                )

            for coverage in coverage_by_column.values():
                coverage_rows.append(coverage)
                if coverage["resolution"] in {
                    "unclassified",
                    "missing_dictionary_mapping",
                }:
                    unresolved_nonempty.append(
                        f"{access_table_name}.{coverage['column_name']}({coverage['resolution']},"
                        f"nonempty={coverage['nonempty_tokens']})"
                    )

            year_summary_rows.append(
                {
                    "year": year,
                    "table_name": access_table_name,
                    "source_file": source_file,
                    "selected": table_output_rows > 0,
                    "exclude_reason": (
                        ""
                        if table_output_rows > 0
                        else f"reviewed_{lane}_table"
                        if lane in {"metadata", "excluded"}
                        else "no_contracted_dictionary_value_cells"
                    ),
                    "matched_cols": len(value_columns or []),
                    "output_rows": table_output_rows,
                    "dictionary_rows": int(len(dict_source)),
                    "source_match_rows": source_match_rows,
                    "access_table_match_rows": access_match_rows,
                    "lane": lane,
                    "source_rows_read": source_rows_read,
                    "source_rows_written": source_rows_read,
                    "exact_duplicate_rows_collapsed": 0,
                }
            )

        coverage_target = checks_v2 / "harmonize_qc" / f"source_column_coverage_{year}.csv"
        coverage_pending = pending_artifact_path(coverage_target, run_id)
        pd.DataFrame(coverage_rows, columns=SOURCE_COLUMN_COVERAGE_COLUMNS).to_csv(coverage_pending, index=False)
        artifact_pairs.append((coverage_pending, coverage_target))
        if args.release_strict and unresolved_nonempty:
            raise SystemExit(
                "[fatal] unresolved source columns: " + "; ".join(sorted(unresolved_nonempty))
            )

        scalar_sink.finalize()
        dimensioned_sink.finalize()
        source_rows_sink.finalize()
        dedupe_tmp_dir = (
            pathlib.Path(args.dedupe_temp_dir)
            if args.dedupe_temp_dir
            else layout.build / "harmonize_exact_duplicate_tmp" / str(year)
        )
        scalar_duckdb_settings = DuckDBSettings(
            memory_limit=args.duckdb_memory_limit,
            threads=args.dedupe_threads,
            temp_dir=dedupe_tmp_dir / "scalar",
            max_temp_gib=args.dedupe_max_temp_gib,
        )
        dimensioned_duckdb_settings = DuckDBSettings(
            memory_limit=args.duckdb_memory_limit,
            threads=args.dedupe_threads,
            temp_dir=dedupe_tmp_dir / "dimensioned",
            max_temp_gib=args.dedupe_max_temp_gib,
        )
        source_rows_duckdb_settings = DuckDBSettings(
            memory_limit=args.duckdb_memory_limit,
            threads=args.dedupe_threads,
            temp_dir=dedupe_tmp_dir / "source_rows",
            max_temp_gib=args.dedupe_max_temp_gib,
        )
        validation_duckdb_settings = DuckDBSettings(
            memory_limit=args.duckdb_memory_limit,
            threads=args.dedupe_threads,
            temp_dir=dedupe_tmp_dir / "validation",
            max_temp_gib=args.dedupe_max_temp_gib,
        )
        validate_cell_source_references(
            [scalar_path, dimensioned_path],
            source_rows_path,
            duckdb_settings=validation_duckdb_settings,
        )
        duplicate_map_path = dedupe_tmp_dir / "source_duplicate_map.parquet"
        build_source_duplicate_map(
            source_rows_path,
            duplicate_map_path,
            duckdb_settings=source_rows_duckdb_settings,
        )
        collapse_exact_source_rows(
            scalar_path,
            temp_dir=dedupe_tmp_dir / "scalar",
            threads=args.dedupe_threads,
            max_temp_gib=args.dedupe_max_temp_gib,
            duckdb_settings=scalar_duckdb_settings,
            duplicate_map_path=duplicate_map_path,
        )
        collapse_exact_source_rows(
            dimensioned_path,
            temp_dir=dedupe_tmp_dir / "dimensioned",
            threads=args.dedupe_threads,
            max_temp_gib=args.dedupe_max_temp_gib,
            duckdb_settings=dimensioned_duckdb_settings,
            duplicate_map_path=duplicate_map_path,
        )
        annotate_exact_source_rows(
            source_rows_path,
            temp_dir=dedupe_tmp_dir / "source_rows",
            threads=args.dedupe_threads,
            max_temp_gib=args.dedupe_max_temp_gib,
            duckdb_settings=source_rows_duckdb_settings,
            duplicate_map_path=duplicate_map_path,
        )
        validate_source_row_grain(
            source_rows_path,
            duckdb_settings=validation_duckdb_settings,
        )
        validate_lane_conflicts(
            scalar_path,
            "scalar",
            duckdb_settings=validation_duckdb_settings,
        )
        # The dimensioned cell key adds only ``variable_id`` to the proven
        # source-row key. ``build_long_cells`` melts each unique source column
        # once, enforces an m:1 dictionary merge, and proves the selected
        # column-to-variable mapping is injective. Therefore the physical-row
        # grain proof above is the complete dimensioned conflict proof. Re-grouping
        # every measure cell repeats that proof across tens of millions of
        # rows and is not bounded by DuckDB's external-spill controls.
        validate_cell_source_references(
            [scalar_path, dimensioned_path],
            source_rows_path,
            duckdb_settings=validation_duckdb_settings,
        )
        source_row_counts = source_row_duplicate_counts(
            source_rows_path,
            duckdb_settings=validation_duckdb_settings,
        )
        written_by_table = dict(
            zip(source_row_counts["access_table_name"], source_row_counts["physical_rows"], strict=True)
        )
        duplicate_by_table = dict(
            zip(source_row_counts["access_table_name"], source_row_counts["exact_duplicate_rows"], strict=True)
        )
        duplicate_map_path.unlink(missing_ok=True)
        for summary in year_summary_rows:
            written = int(written_by_table.get(summary["table_name"], 0))
            summary["source_rows_written"] = written
            summary["exact_duplicate_rows_collapsed"] = int(duplicate_by_table.get(summary["table_name"], 0))

        if args.write_legacy_scalar_alias:
            legacy_target = output_dir / f"panel_long_varnum_{year}.parquet"
            legacy_pending = pending_artifact_path(legacy_target, run_id)
            shutil.copyfile(scalar_path, legacy_pending)
            artifact_pairs.append((legacy_pending, legacy_target))

        summary_target = checks_v2 / "harmonize_qc" / f"harmonize_summary_{year}.csv"
        summary_pending = pending_artifact_path(summary_target, run_id)
        empty_harmonize_summary_frame(year_summary_rows).to_csv(summary_pending, index=False)
        artifact_pairs.append((summary_pending, summary_target))
        missing_target = checks_v2 / "harmonize_qc" / f"dropped_missing_unitid_{year}.csv"
        missing_pending = pending_artifact_path(missing_target, run_id)
        empty_missing_unitid_frame(na_drop_rows).to_csv(missing_pending, index=False)
        artifact_pairs.append((missing_pending, missing_target))

        completed_year_targets.append((year, scalar_target, dimensioned_target, source_rows_target))
        shutil.rmtree(parts_root)

    promote_artifact_group(artifact_pairs, run_id)
    for year, scalar_target, dimensioned_target, source_rows_target in completed_year_targets:
        print(
            f"[year {year}] wrote scalar={scalar_target} dimensioned={dimensioned_target} "
            f"source_rows={source_rows_target}"
        )


if __name__ == "__main__":
    main()
