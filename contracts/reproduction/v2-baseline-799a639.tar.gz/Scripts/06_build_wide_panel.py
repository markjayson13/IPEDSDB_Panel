#!/usr/bin/env python3
"""
Stage 06: build the wide institution-year analysis panel from proven scalar long data.

Reads:
- v2 scalar long parquet from Stage 05 (release mode)
- `contracts/analysis_schema.csv`
- `contracts/discrete_families.csv`
- optional v2 dictionary metadata for discovery audits

Writes:
- an immutable `Panels/v2/wide_release/runs/<run-id>/` output+QC bundle
- one atomic `Panels/v2/wide_release/current` release pointer
- stable canonical output/QC symlinks that resolve only through that pointer
- isolated `Panels/development/v2/` and `Checks/development/v2/` artifacts in development mode

Release mode is contract-driven and fails on unclassified variables, final-key
conflicts, unknown discrete semantics/tokens, unsafe casts, or incomplete
lineage. The historical discovery/prefix behavior remains available only via
explicit development mode.

Open this file when you want to understand how the long panel becomes the one-row-per-`UNITID-year` analysis dataset used by the cleaner and the release QA.

Method context:
- `METHODS_PANEL_CONSTRUCTION.md` explains the high-level panel design
- this script is the mechanical wide-build step, not the place where the unit of analysis is philosophically decided
"""
from __future__ import annotations

from pathlib import Path

from wide_build_common import (
    build_arg_parser,
    setup_logging,
    validate_development_output_namespace,
)
from wide_build_duckdb import run


def main() -> None:
    parser = build_arg_parser()
    args = parser.parse_args()
    if not args.log_file:
        mode_path = ("v2",) if args.build_mode == "release" else ("development", "v2")
        args.log_file = str(
            Path(args.root)
            / "build"
            / Path(*mode_path)
            / "logs"
            / "06_build_wide_panel.log"
        )
    validate_development_output_namespace(args)
    setup_logging(args.log_file)
    run(args)


if __name__ == "__main__":
    main()
