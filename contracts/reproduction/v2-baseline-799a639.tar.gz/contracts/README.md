# Panel contracts

`panel_spec.toml` declares the canonical `IPEDSDB_Panel` research object outside
the stage scripts. It is a compact, versioned statement of the release window,
input source, wide-build transformation rules, PRCH cleaning policy, expected
outputs, and QA evidence.

The contract is intentionally declarative. It does not replace the stage
scripts; it gives reviewers and maintainers one place to inspect the data object
being built.

## Current contract

- `schema_version`: `2.0`
- `contract_id`: `ipedsdb-panel-2004-2023-access-v2`
- status: `release-candidate`
- release ready: `false`
- release window: `2004:2023`
- source: NCES IPEDS Access databases
- release policy: final-only
- unit of analysis: `UNITID-year`
- canonical output: `Panels/v2/panel_clean_prch_2004_2023.parquet`
- scalar long key: `UNITID, year, variable_id, source_file`
- dimensioned long key: `UNITID, year, source_file,
  access_table_name, source_row_id, dimension_key, variable_id`
- v1 support: archive-only
- value lineage: `Checks/v2/wide_qc/qc_value_lineage.parquet`
- PRCH cell actions: `Checks/v2/prch_qc/prch_cell_actions.parquet`
- release manifest: `Checks/v2/release_manifest/release_manifest.csv`
- release bundle manifest: `Releases/ipedsdb-panel-v2/current/bundle_manifest.csv`
- release comparison: `Checks/v2/release_compare/release_comparison.csv`
- data package: `Checks/v2/release_metadata/datapackage.json`
- build provenance: `Checks/v2/release_metadata/build_provenance.json`
- environment report: `Checks/v2/release_metadata/environment_report.json`
- entity continuity: `Checks/v2/entity_continuity/entity_continuity_crosswalk.csv`
- external benchmarks: `Checks/v2/external_benchmarks/external_benchmark_reconciliation.csv`

## Validation

Run:

```bash
python3 Scripts/QA_QC/11_validate_panel_contract.py
```

The validator checks the v2 contract identity, canonical artifact definitions,
keys, required columns, policy references, release requirements, and cleaning
invariants. Missing keys or policy references fail validation.

The policy CSVs may be intentionally header-only while scientific review is
pending. A header-only source, PRCH, or benchmark contract is a release blocker;
it is never permission to infer or invent values.

## What belongs here

Add or revise a contract when the empirical object changes, including:

- release years or provisional/final policy
- unit of analysis or panel key
- table-grain classifications and source-column dispositions
- dictionary ambiguity overrides
- discrete-family semantics
- anti-garbage identifiers
- scalar conflict gates
- year- and column-specific PRCH cleaning policy
- output artifact names
- release-manifest, verification, bundle, and baseline-comparison evidence
- runtime environment report and dependency lock
- transformation ledger rows
- external benchmark definitions
- entity-continuity and join-risk outputs
- known limitations or release-diff overrides

Generated data and QA files still belong under `IPEDSDB_ROOT`, not in this
directory.

## Dictionary ambiguity overrides

`dictionary_ambiguity_overrides.csv` is intentionally empty unless Stage 04 has
a known, reviewed metadata ambiguity. Stage 04 fails when more than one
dictionary row can describe the same `(year, source_file/access_table_name,
varname)` mapping. To permit an exception, add one row with:

- the relevant `year`, `source_file` or `access_table_name`, and `varname`
- one or more `selected_*` fields that identify exactly one dictionary row
- a concrete `justification`

Do not add broad or undocumented overrides. An override is part of the research
contract.
