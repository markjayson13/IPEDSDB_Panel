#!/usr/bin/env python3
"""Build a deterministic, non-approving B05/B06 scientific review package.

This generator consumes exact B03/B04 evidence plus archived codebook and
legacy discrete-QC diagnostics. It never writes canonical contracts, never
turns legacy outputs into approval evidence, and never infers discrete-family
membership from variable names.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable, Mapping, Sequence


PANEL_CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"

SOURCE_REQUIRED = (
    "contract_id",
    "year",
    "access_table_name",
    "normalized_table_name",
    "source_csv_sha256",
    "column_name",
    "column_metadata_match_status",
    "matched_varnumber",
    "matched_varname",
    "matched_metadata_source",
    "candidate_table_grain",
    "candidate_role",
    "role_decision_id",
    "role_decision_source",
    "data_type",
    "format",
    "var_title",
    "nonempty_count",
    "null_count",
    "distinct_nonempty_count",
    "example_nonempty_tokens",
)

TABLE_REQUIRED = (
    "contract_id",
    "year",
    "access_table_name",
    "normalized_table_name",
    "source_csv_sha256",
    "candidate_key_test_status",
    "candidate_grain",
    "review_status",
)

CODE_REQUIRED = (
    "year",
    "varnumber",
    "varname",
    "codevalue",
    "valuelabel",
    "varTitle",
    "source_file",
    "source_file_label",
    "access_table_name",
    "metadata_table_name",
    "academic_year_label",
    "release_type",
    "source",
    "is_imputation_label",
    "label_scope",
)

LEGACY_QC_REQUIRED = (
    "year",
    "source_file",
    "variable_family",
    "conflict_type",
    "row_count",
    "institution_year_rows",
    "min_n_active",
    "max_n_active",
    "distinct_suffixes_observed",
    "detail_rows_total",
    "detail_rows_written",
    "detail_truncated",
    "expected_pattern",
    "signal_level",
    "high_signal",
)

B05_FIELDS = (
    "decision_id",
    "contract_id",
    "variable_id",
    "source_variables",
    "source_file",
    "source_varnumber",
    "source_varname",
    "years_present",
    "observed_first_year",
    "observed_last_year",
    "annual_evidence_rows",
    "max_source_columns_per_year",
    "duplicate_identity_years",
    "access_table_names",
    "source_column_names",
    "source_csv_sha256s",
    "metadata_sources",
    "metadata_statuses",
    "candidate_key_statuses",
    "b03_review_statuses",
    "b03_dependency_status",
    "b04_role_decision_ids",
    "b04_dependency_status",
    "data_type_evidence",
    "format_evidence",
    "var_titles",
    "nonempty_count_total",
    "null_count_total",
    "distinct_nonempty_count_max",
    "source_name_collision",
    "analysis_column_decision",
    "logical_type_decision",
    "transformation_decision",
    "inclusion_decision",
    "contract_first_year_decision",
    "contract_last_year_decision",
    "nullable_decision",
    "decision_status",
    "decision_reason",
    "evidence_basis",
)

B05_COLLISION_FIELDS = (
    "source_varname",
    "variable_id_count",
    "variable_ids",
    "source_files",
    "source_varnumbers",
    "years_present",
    "resolution_status",
    "review_note",
)

B05_EXCEPTION_FIELDS = (
    "exception_id",
    "contract_id",
    "year",
    "access_table_name",
    "source_file",
    "source_column_name",
    "candidate_role",
    "metadata_status",
    "candidate_table_grain",
    "table_key_status",
    "table_review_status",
    "source_csv_sha256",
    "matched_varnumber",
    "matched_varname",
    "nonempty_count",
    "exception_reason",
    "review_status",
)

B06_FIELDS = (
    "decision_id",
    "contract_id",
    "variable_id",
    "source_file",
    "source_varnumber",
    "source_varname",
    "source_variables",
    "years_present",
    "access_table_names",
    "source_column_names",
    "source_format_evidence",
    "observed_example_tokens",
    "exact_codebook_years",
    "missing_codebook_years",
    "exact_codebook_mapping_count",
    "distinct_code_values",
    "code_label_conflict_count",
    "b03_dependency_status",
    "b04_dependency_status",
    "family_id_decision",
    "component_code_decision",
    "semantic_type_decision",
    "active_tokens_decision",
    "inactive_tokens_decision",
    "missing_tokens_decision",
    "output_column_decision",
    "output_type_decision",
    "multi_active_policy_decision",
    "drop_components_decision",
    "decision_status",
    "decision_reason",
    "evidence_basis",
)

B06_CODE_FIELDS = (
    "contract_id",
    "year",
    "access_table_name",
    "source_file",
    "source_column_name",
    "variable_id",
    "source_varnumber",
    "source_varname",
    "codevalue",
    "valuelabel",
    "codebook_var_title",
    "metadata_table_name",
    "academic_year_label",
    "release_type",
    "codebook_source",
    "label_scope",
    "authority",
)

B06_LEGACY_FIELDS = (
    *LEGACY_QC_REQUIRED,
    "authority",
    "eligible_as_family_evidence",
    "review_note",
)

INPUT_MANIFEST_FIELDS = (
    "input_id",
    "role",
    "path_label",
    "byte_size",
    "sha256",
    "authority",
)

ARTIFACT_MANIFEST_FIELDS = (
    "path",
    "byte_size",
    "sha256",
    "generator_sha256",
    "input_manifest_sha256",
)

CANONICAL_COMPARISON_FIELDS = (
    "path",
    "pre_sha256",
    "post_sha256",
    "unchanged",
)

APPROVED_REVIEW_TOKENS = {"1", "true", "yes", "approved", "reviewed"}


class ReviewEvidenceError(ValueError):
    """Raised when review evidence is absent, ambiguous, stale, or unsafe."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_id(prefix: str, value: str) -> str:
    token = hashlib.sha256(value.encode("utf-8")).hexdigest()[:12].upper()
    return f"{prefix}-{token}"


def normalize_token(value: object) -> str:
    return str(value or "").strip().upper()


def normalize_varnumber(value: object) -> str:
    token = "".join(str(value or "").split())
    if token.lower() in {"", "nan", "none", "<na>", "na", "nat"}:
        return ""
    return token.zfill(8) if token.isdigit() else token


def parse_year(value: object, *, label: str) -> int:
    token = str(value or "").strip()
    if not token.isdigit():
        raise ReviewEvidenceError(f"{label} has invalid year: {value!r}")
    return int(token)


def parse_count(value: object, *, label: str) -> int:
    token = str(value or "").strip()
    if token == "":
        return 0
    try:
        number = int(float(token))
    except ValueError as exc:
        raise ReviewEvidenceError(f"{label} has invalid count: {value!r}") from exc
    if number < 0:
        raise ReviewEvidenceError(f"{label} has negative count: {value!r}")
    return number


def sorted_pipe(values: Iterable[object]) -> str:
    return "|".join(sorted({str(value).strip() for value in values if str(value).strip()}))


def sorted_years(values: Iterable[object]) -> list[int]:
    return sorted({parse_year(value, label="evidence row") for value in values})


def read_csv_rows(path: Path, required: Sequence[str], label: str) -> list[dict[str, str]]:
    if not path.is_file():
        raise ReviewEvidenceError(f"{label} does not exist: {path}")
    try:
        with path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            fields = reader.fieldnames or []
            if len(fields) != len(set(fields)):
                raise ReviewEvidenceError(f"{label} repeats CSV headers")
            missing = [field for field in required if field not in fields]
            if missing:
                raise ReviewEvidenceError(f"{label} missing required columns: {missing}")
            return [
                {key: str(value or "") for key, value in row.items()}
                for row in reader
            ]
    except UnicodeDecodeError as exc:
        raise ReviewEvidenceError(f"{label} is not strict UTF-8: {path}") from exc


def write_csv_rows(
    path: Path,
    fields: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fields),
            extrasaction="ignore",
            lineterminator="\n",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def portable_label(path: Path, repo_root: Path) -> str:
    resolved = path.resolve()
    try:
        return resolved.relative_to(repo_root.resolve()).as_posix()
    except ValueError:
        return resolved.name


def contract_snapshot(repo_root: Path) -> dict[str, str]:
    contract_root = repo_root.resolve() / "contracts"
    if not contract_root.is_dir():
        raise ReviewEvidenceError(f"canonical contracts directory is missing: {contract_root}")
    return {
        path.relative_to(repo_root.resolve()).as_posix(): sha256_file(path)
        for path in sorted(contract_root.rglob("*"))
        if path.is_file()
    }


def validate_output_path(repo_root: Path, out_dir: Path) -> None:
    repo = repo_root.resolve()
    contracts = repo / "contracts"
    candidate = out_dir.absolute()
    if candidate == contracts or contracts in candidate.parents:
        raise ReviewEvidenceError(
            f"review output must not be written inside canonical contracts: {candidate}"
        )
    if candidate.exists():
        raise ReviewEvidenceError(f"refusing to overwrite existing review output: {candidate}")


def _manifest_path_candidates(
    raw_path: str,
    *,
    repo_root: Path,
    manifest_path: Path,
) -> set[Path]:
    value = Path(raw_path)
    if value.is_absolute():
        return {value.resolve()}
    return {
        (repo_root / value).resolve(),
        (manifest_path.parent / value).resolve(),
    }


def verify_evidence_binding(
    evidence_path: Path,
    *,
    artifact_manifest_path: Path,
    artifact_manifest_rows: Sequence[Mapping[str, str]],
    repo_root: Path,
) -> None:
    resolved = evidence_path.resolve()
    matches = [
        row
        for row in artifact_manifest_rows
        if resolved
        in _manifest_path_candidates(
            row.get("path", ""),
            repo_root=repo_root,
            manifest_path=artifact_manifest_path,
        )
    ]
    if len(matches) != 1:
        raise ReviewEvidenceError(
            f"{evidence_path.name} must have exactly one exact path binding in "
            f"{artifact_manifest_path.name}; found={len(matches)}"
        )
    row = matches[0]
    observed_size = evidence_path.stat().st_size
    try:
        expected_size = int(str(row.get("byte_size", "")).strip())
    except ValueError as exc:
        raise ReviewEvidenceError(
            f"{artifact_manifest_path.name} has invalid byte_size for {evidence_path.name}"
        ) from exc
    if observed_size != expected_size:
        raise ReviewEvidenceError(
            f"{evidence_path.name} size mismatch: expected={expected_size} "
            f"observed={observed_size}"
        )
    observed_hash = sha256_file(evidence_path)
    expected_hash = str(row.get("sha256", "")).strip().lower()
    if observed_hash != expected_hash:
        raise ReviewEvidenceError(
            f"{evidence_path.name} hash mismatch: expected={expected_hash} "
            f"observed={observed_hash}"
        )


def validate_contract_ids(
    rows: Sequence[Mapping[str, str]],
    *,
    contract_id: str,
    label: str,
) -> None:
    observed = sorted({str(row.get("contract_id", "")).strip() for row in rows})
    if observed != [contract_id]:
        raise ReviewEvidenceError(
            f"{label} contract_id mismatch: expected={contract_id!r} observed={observed}"
        )


def table_identity(row: Mapping[str, str]) -> tuple[int, str, str, str]:
    return (
        parse_year(row.get("year", ""), label="table evidence"),
        normalize_token(row.get("normalized_table_name", "")),
        normalize_token(row.get("access_table_name", "")),
        str(row.get("source_csv_sha256", "")).strip().lower(),
    )


def source_identity(row: Mapping[str, str]) -> tuple[int, str, str, str]:
    return (
        parse_year(row.get("year", ""), label="source-column evidence"),
        normalize_token(row.get("normalized_table_name", "")),
        normalize_token(row.get("access_table_name", "")),
        str(row.get("source_csv_sha256", "")).strip().lower(),
    )


def source_variable_id(row: Mapping[str, str]) -> str:
    source_file = normalize_token(row.get("normalized_table_name", ""))
    varnumber = normalize_varnumber(row.get("matched_varnumber", ""))
    varname = normalize_token(row.get("matched_varname", ""))
    if not source_file or not varnumber or not varname:
        return ""
    return f"nces:{source_file}:{varnumber}:{varname}"


def exact_code_identity(row: Mapping[str, str]) -> tuple[int, str, str, str, str]:
    return (
        parse_year(row.get("year", ""), label="dictionary code row"),
        normalize_token(row.get("source_file", "")),
        normalize_token(row.get("access_table_name", "")),
        normalize_varnumber(row.get("varnumber", "")),
        normalize_token(row.get("varname", "")),
    )


def exact_source_code_identity(row: Mapping[str, str]) -> tuple[int, str, str, str, str]:
    return (
        parse_year(row.get("year", ""), label="source-column evidence"),
        normalize_token(row.get("normalized_table_name", "")),
        normalize_token(row.get("access_table_name", "")),
        normalize_varnumber(row.get("matched_varnumber", "")),
        normalize_token(row.get("matched_varname", "")),
    )


def is_reviewed(value: object) -> bool:
    return str(value or "").strip().lower() in APPROVED_REVIEW_TOKENS


def build_table_index(
    rows: Sequence[Mapping[str, str]],
) -> dict[tuple[int, str, str, str], Mapping[str, str]]:
    index: dict[tuple[int, str, str, str], Mapping[str, str]] = {}
    for row in rows:
        key = table_identity(row)
        if key in index:
            raise ReviewEvidenceError(
                "table-grain evidence repeats exact annual table identity: "
                f"{key[0]}:{key[2]}:{key[3]}"
            )
        index[key] = row
    return index


def b03_dependency(rows: Sequence[Mapping[str, object]]) -> str:
    reviews = [str(row.get("_table_review_status", "")) for row in rows]
    if reviews and all(is_reviewed(value) for value in reviews):
        return "reviewed_scalar"
    return "unreviewed_scalar_evidence"


def b04_dependency(rows: Sequence[Mapping[str, object]]) -> str:
    decisions = [str(row.get("role_decision_id", "")).strip() for row in rows]
    reviewed = sum(bool(value) for value in decisions)
    if reviewed == len(decisions) and decisions:
        return "reviewed_measure_role"
    if reviewed:
        return "partially_reviewed_measure_role"
    return "metadata_candidate_role_only"


def _format_evidence(values: Iterable[object]) -> str:
    normalized = {
        normalize_token(value) or "<BLANK>"
        for value in values
    }
    return "|".join(sorted(normalized))


def build_b05_rows(
    source_rows: Sequence[Mapping[str, str]],
    table_index: Mapping[tuple[int, str, str, str], Mapping[str, str]],
) -> tuple[list[dict[str, object]], list[dict[str, object]], list[dict[str, object]], list[dict[str, object]]]:
    eligible: list[dict[str, object]] = []
    exceptions: list[dict[str, object]] = []
    enriched_measure_rows: list[dict[str, object]] = []

    seen_source_rows: set[tuple[int, str, str, str]] = set()
    for source in source_rows:
        annual_column_key = (
            parse_year(source.get("year", ""), label="source-column evidence"),
            normalize_token(source.get("access_table_name", "")),
            normalize_token(source.get("column_name", "")),
            str(source.get("source_csv_sha256", "")).strip().lower(),
        )
        if annual_column_key in seen_source_rows:
            raise ReviewEvidenceError(
                "source-column evidence repeats exact annual source column: "
                f"{annual_column_key[0]}:{annual_column_key[1]}.{annual_column_key[2]}"
            )
        seen_source_rows.add(annual_column_key)

        candidate_role = str(source.get("candidate_role", "")).strip().lower()
        nonempty_count = parse_count(
            source.get("nonempty_count", ""),
            label=f"{annual_column_key[1]}.{annual_column_key[2]} nonempty_count",
        )
        if candidate_role not in {"measure_candidate", "unresolved"}:
            continue
        table = table_index.get(source_identity(source))
        table_grain = "" if table is None else str(table.get("candidate_grain", "")).strip().lower()
        table_key_status = "" if table is None else str(table.get("candidate_key_test_status", "")).strip()
        table_review_status = "" if table is None else str(table.get("review_status", "")).strip()
        source_grain = str(source.get("candidate_table_grain", "")).strip().lower()
        metadata_status = str(source.get("column_metadata_match_status", "")).strip().lower()
        variable_id = source_variable_id(source)

        reason = ""
        if table is None:
            reason = "exact_table_evidence_missing"
        elif source_grain and table_grain and source_grain != table_grain:
            reason = "table_grain_evidence_disagreement"
        elif candidate_role == "unresolved":
            reason = "upstream_source_role_unresolved"
        elif metadata_status != "exact":
            reason = "source_metadata_identity_not_exact"
        elif table_grain == "dimensioned":
            reason = "dimensioned_source_requires_separate_aggregation_contract"
        elif table_grain != "scalar":
            reason = "source_table_not_proven_scalar_candidate"
        elif not variable_id:
            reason = "exact_source_variable_identity_incomplete"

        enriched = dict(source)
        enriched.update(
            {
                "_variable_id": variable_id,
                "_table_candidate_grain": table_grain,
                "_table_key_status": table_key_status,
                "_table_review_status": table_review_status,
            }
        )
        if reason:
            if candidate_role == "measure_candidate" or nonempty_count:
                exception_basis = "|".join(
                    [
                        str(source.get("year", "")),
                        str(source.get("access_table_name", "")),
                        str(source.get("column_name", "")),
                        reason,
                    ]
                )
                exceptions.append(
                    {
                        "exception_id": stable_id("B05-EX", exception_basis),
                        "contract_id": source.get("contract_id", ""),
                        "year": source.get("year", ""),
                        "access_table_name": source.get("access_table_name", ""),
                        "source_file": normalize_token(source.get("normalized_table_name", "")),
                        "source_column_name": normalize_token(source.get("column_name", "")),
                        "candidate_role": candidate_role,
                        "metadata_status": metadata_status,
                        "candidate_table_grain": table_grain or source_grain,
                        "table_key_status": table_key_status,
                        "table_review_status": table_review_status,
                        "source_csv_sha256": source.get("source_csv_sha256", ""),
                        "matched_varnumber": normalize_varnumber(source.get("matched_varnumber", "")),
                        "matched_varname": normalize_token(source.get("matched_varname", "")),
                        "nonempty_count": nonempty_count,
                        "exception_reason": reason,
                        "review_status": "blocked_upstream",
                    }
                )
            continue
        enriched_measure_rows.append(enriched)

    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in enriched_measure_rows:
        grouped[str(row["_variable_id"])].append(row)

    for variable_id, rows in sorted(grouped.items()):
        years = sorted_years(row.get("year", "") for row in rows)
        per_year = Counter(parse_year(row.get("year", ""), label="B05 row") for row in rows)
        duplicate_years = [year for year, count in per_year.items() if count > 1]
        source_file = normalize_token(rows[0].get("normalized_table_name", ""))
        varnumber = normalize_varnumber(rows[0].get("matched_varnumber", ""))
        varname = normalize_token(rows[0].get("matched_varname", ""))
        candidate = {
            "decision_id": stable_id("B05", variable_id),
            "contract_id": rows[0].get("contract_id", ""),
            "variable_id": variable_id,
            "source_variables": f"variable_id:{variable_id}",
            "source_file": source_file,
            "source_varnumber": varnumber,
            "source_varname": varname,
            "years_present": "|".join(str(year) for year in years),
            "observed_first_year": years[0],
            "observed_last_year": years[-1],
            "annual_evidence_rows": len(rows),
            "max_source_columns_per_year": max(per_year.values()),
            "duplicate_identity_years": "|".join(str(year) for year in sorted(duplicate_years)),
            "access_table_names": sorted_pipe(
                normalize_token(row.get("access_table_name", "")) for row in rows
            ),
            "source_column_names": sorted_pipe(
                normalize_token(row.get("column_name", "")) for row in rows
            ),
            "source_csv_sha256s": sorted_pipe(row.get("source_csv_sha256", "") for row in rows),
            "metadata_sources": sorted_pipe(
                normalize_token(row.get("matched_metadata_source", "")) for row in rows
            ),
            "metadata_statuses": sorted_pipe(
                str(row.get("column_metadata_match_status", "")).strip().lower()
                for row in rows
            ),
            "candidate_key_statuses": sorted_pipe(
                row.get("_table_key_status", "") for row in rows
            ),
            "b03_review_statuses": sorted_pipe(
                row.get("_table_review_status", "") for row in rows
            ),
            "b03_dependency_status": b03_dependency(rows),
            "b04_role_decision_ids": sorted_pipe(
                row.get("role_decision_id", "") for row in rows
            ),
            "b04_dependency_status": b04_dependency(rows),
            "data_type_evidence": _format_evidence(row.get("data_type", "") for row in rows),
            "format_evidence": _format_evidence(row.get("format", "") for row in rows),
            "var_titles": sorted_pipe(row.get("var_title", "") for row in rows),
            "nonempty_count_total": sum(
                parse_count(row.get("nonempty_count", ""), label=f"{variable_id} nonempty_count")
                for row in rows
            ),
            "null_count_total": sum(
                parse_count(row.get("null_count", ""), label=f"{variable_id} null_count")
                for row in rows
            ),
            "distinct_nonempty_count_max": max(
                parse_count(
                    row.get("distinct_nonempty_count", ""),
                    label=f"{variable_id} distinct_nonempty_count",
                )
                for row in rows
            ),
            "source_name_collision": "false",
            "analysis_column_decision": "",
            "logical_type_decision": "",
            "transformation_decision": "",
            "inclusion_decision": "",
            "contract_first_year_decision": "",
            "contract_last_year_decision": "",
            "nullable_decision": "",
            "decision_status": "pending_scientific_review",
            "decision_reason": (
                "Exact source identity and observed coverage are mechanical evidence only; "
                "analysis name, type, transformation, inclusion window, and nullability "
                "require explicit review."
            ),
            "evidence_basis": (
                "exact B04 metadata identity plus exact B03 annual table evidence and "
                "source CSV hashes"
            ),
        }
        eligible.append(candidate)

    by_name: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in eligible:
        by_name[str(row["source_varname"])].append(row)
    collisions: list[dict[str, object]] = []
    for name, rows in sorted(by_name.items()):
        ids = sorted({str(row["variable_id"]) for row in rows})
        if len(ids) <= 1:
            continue
        for row in rows:
            row["source_name_collision"] = "true"
        collisions.append(
            {
                "source_varname": name,
                "variable_id_count": len(ids),
                "variable_ids": "|".join(ids),
                "source_files": sorted_pipe(row["source_file"] for row in rows),
                "source_varnumbers": sorted_pipe(row["source_varnumber"] for row in rows),
                "years_present": sorted_pipe(
                    year
                    for row in rows
                    for year in str(row["years_present"]).split("|")
                ),
                "resolution_status": "requires_explicit_mapping",
                "review_note": (
                    "A literal NCES VarName labels multiple exact variable identities; "
                    "no output name or winning identity was selected."
                ),
            }
        )

    eligible.sort(key=lambda row: (str(row["source_varname"]), str(row["variable_id"])))
    collisions.sort(key=lambda row: str(row["source_varname"]))
    exceptions.sort(
        key=lambda row: (
            int(str(row["year"])),
            str(row["access_table_name"]),
            str(row["source_column_name"]),
        )
    )
    enriched_measure_rows.sort(
        key=lambda row: (
            int(str(row["year"])),
            normalize_token(row.get("access_table_name", "")),
            normalize_token(row.get("column_name", "")),
        )
    )
    return eligible, collisions, exceptions, enriched_measure_rows


def build_code_index(
    code_rows: Sequence[Mapping[str, str]],
) -> dict[tuple[int, str, str, str, str], list[Mapping[str, str]]]:
    index: dict[tuple[int, str, str, str, str], list[Mapping[str, str]]] = defaultdict(list)
    seen: set[tuple[object, ...]] = set()
    for row in code_rows:
        key = exact_code_identity(row)
        mapping = (
            *key,
            str(row.get("codevalue", "")).strip(),
            str(row.get("valuelabel", "")).strip(),
            str(row.get("metadata_table_name", "")).strip(),
            str(row.get("source", "")).strip(),
            str(row.get("label_scope", "")).strip(),
        )
        if mapping in seen:
            continue
        seen.add(mapping)
        index[key].append(row)
    for rows in index.values():
        rows.sort(
            key=lambda row: (
                str(row.get("codevalue", "")),
                str(row.get("valuelabel", "")),
                str(row.get("metadata_table_name", "")),
            )
        )
    return index


def build_b06_rows(
    eligible_source_rows: Sequence[Mapping[str, object]],
    code_index: Mapping[
        tuple[int, str, str, str, str],
        Sequence[Mapping[str, str]],
    ],
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    discrete_variable_ids = {
        str(row["_variable_id"])
        for row in eligible_source_rows
        if normalize_token(row.get("format", "")) == "DISC"
    }
    discrete_rows = [
        row
        for row in eligible_source_rows
        if str(row["_variable_id"]) in discrete_variable_ids
    ]
    grouped: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    for row in discrete_rows:
        grouped[str(row["_variable_id"])].append(row)

    decisions: list[dict[str, object]] = []
    code_evidence: list[dict[str, object]] = []
    for variable_id, rows in sorted(grouped.items()):
        years = sorted_years(row.get("year", "") for row in rows)
        years_with_codes: set[int] = set()
        code_values: set[str] = set()
        labels_by_year_code: dict[tuple[int, str], set[str]] = defaultdict(set)
        mapping_count = 0
        for row in rows:
            key = exact_source_code_identity(row)
            mappings = list(code_index.get(key, ()))
            if mappings:
                years_with_codes.add(key[0])
            for code in mappings:
                codevalue = str(code.get("codevalue", "")).strip()
                valuelabel = str(code.get("valuelabel", "")).strip()
                code_values.add(codevalue)
                labels_by_year_code[(key[0], codevalue)].add(valuelabel)
                mapping_count += 1
                code_evidence.append(
                    {
                        "contract_id": row.get("contract_id", ""),
                        "year": key[0],
                        "access_table_name": normalize_token(
                            row.get("access_table_name", "")
                        ),
                        "source_file": normalize_token(
                            row.get("normalized_table_name", "")
                        ),
                        "source_column_name": normalize_token(
                            row.get("column_name", "")
                        ),
                        "variable_id": variable_id,
                        "source_varnumber": normalize_varnumber(
                            row.get("matched_varnumber", "")
                        ),
                        "source_varname": normalize_token(
                            row.get("matched_varname", "")
                        ),
                        "codevalue": codevalue,
                        "valuelabel": valuelabel,
                        "codebook_var_title": code.get("varTitle", ""),
                        "metadata_table_name": code.get("metadata_table_name", ""),
                        "academic_year_label": code.get("academic_year_label", ""),
                        "release_type": code.get("release_type", ""),
                        "codebook_source": code.get("source", ""),
                        "label_scope": code.get("label_scope", ""),
                        "authority": "exact_code_label_diagnostic_not_family_approval",
                    }
                )
        conflict_count = sum(len(labels) > 1 for labels in labels_by_year_code.values())
        missing_years = sorted(set(years) - years_with_codes)
        format_evidence = _format_evidence(row.get("format", "") for row in rows)
        format_drift = "|" in format_evidence
        example_tokens: set[str] = set()
        for row in rows:
            example_tokens.update(
                token.strip()
                for token in str(row.get("example_nonempty_tokens", "")).split("|")
                if token.strip()
            )
        decisions.append(
            {
                "decision_id": stable_id("B06-COMP", variable_id),
                "contract_id": rows[0].get("contract_id", ""),
                "variable_id": variable_id,
                "source_file": normalize_token(
                    rows[0].get("normalized_table_name", "")
                ),
                "source_varnumber": normalize_varnumber(
                    rows[0].get("matched_varnumber", "")
                ),
                "source_varname": normalize_token(
                    rows[0].get("matched_varname", "")
                ),
                "source_variables": f"variable_id:{variable_id}",
                "years_present": "|".join(str(year) for year in years),
                "access_table_names": sorted_pipe(
                    normalize_token(row.get("access_table_name", "")) for row in rows
                ),
                "source_column_names": sorted_pipe(
                    normalize_token(row.get("column_name", "")) for row in rows
                ),
                "source_format_evidence": format_evidence,
                "observed_example_tokens": "|".join(sorted(example_tokens)),
                "exact_codebook_years": "|".join(
                    str(year) for year in sorted(years_with_codes)
                ),
                "missing_codebook_years": "|".join(
                    str(year) for year in missing_years
                ),
                "exact_codebook_mapping_count": mapping_count,
                "distinct_code_values": "|".join(sorted(code_values)),
                "code_label_conflict_count": conflict_count,
                "b03_dependency_status": b03_dependency(rows),
                "b04_dependency_status": b04_dependency(rows),
                "family_id_decision": "",
                "component_code_decision": "",
                "semantic_type_decision": "",
                "active_tokens_decision": "",
                "inactive_tokens_decision": "",
                "missing_tokens_decision": "",
                "output_column_decision": "",
                "output_type_decision": "",
                "multi_active_policy_decision": "",
                "drop_components_decision": "",
                "decision_status": "requires_source_semantic_review",
                "decision_reason": (
                    "NCES format and code labels identify a discrete-valued source "
                    "field, but do not establish family membership, active/inactive "
                    "tokens, zero-active meaning, collapse policy, or output semantics."
                    + (
                        " Cross-year source format drift also requires explicit review."
                        if format_drift
                        else ""
                    )
                ),
                "evidence_basis": (
                    "exact B04 metadata format plus exact year/source/table/"
                    "varnumber/varname codebook join"
                    if mapping_count
                    else "exact B04 metadata format; exact codebook join missing"
                ),
            }
        )
    decisions.sort(key=lambda row: (str(row["source_file"]), str(row["source_varname"])))
    code_evidence.sort(
        key=lambda row: (
            int(str(row["year"])),
            str(row["source_file"]),
            str(row["source_varname"]),
            str(row["codevalue"]),
            str(row["valuelabel"]),
        )
    )
    return decisions, code_evidence


def build_legacy_diagnostics(
    rows: Sequence[Mapping[str, str]],
) -> list[dict[str, object]]:
    output = [
        {
            **row,
            "authority": "legacy_name_pattern_diagnostic_only",
            "eligible_as_family_evidence": "false",
            "review_note": (
                "Archived QC is retained to prioritize review only; its regex/name "
                "family assignment and expected-pattern labels are not semantic authority."
            ),
        }
        for row in rows
    ]
    output.sort(
        key=lambda row: (
            parse_year(row.get("year", ""), label="legacy discrete QC"),
            normalize_token(row.get("source_file", "")),
            normalize_token(row.get("variable_family", "")),
            str(row.get("conflict_type", "")),
        )
    )
    return output


def build_input_manifest(
    *,
    repo_root: Path,
    source_column_evidence: Path,
    table_grain_evidence: Path,
    evidence_artifact_manifest: Path,
    dictionary_codes: Path,
    legacy_discrete_qc: Path,
) -> list[dict[str, object]]:
    inputs = [
        (
            "b04_source_column_evidence",
            source_column_evidence,
            "review_evidence",
            "verified B03/B04 artifact",
        ),
        (
            "b03_table_grain_evidence",
            table_grain_evidence,
            "review_evidence",
            "verified B03/B04 artifact",
        ),
        (
            "b03_b04_artifact_manifest",
            evidence_artifact_manifest,
            "provenance_binding",
            "review manifest; not scientific approval",
        ),
        (
            "archived_dictionary_codes",
            dictionary_codes,
            "exact_codebook_diagnostic",
            "archived source metadata; exact labels only, not family approval",
        ),
        (
            "legacy_discrete_qc",
            legacy_discrete_qc,
            "priority_diagnostic",
            "legacy/name-derived diagnostic only; never approval authority",
        ),
    ]
    return [
        {
            "input_id": input_id,
            "role": role,
            "path_label": portable_label(path, repo_root),
            "byte_size": path.stat().st_size,
            "sha256": sha256_file(path),
            "authority": authority,
        }
        for input_id, path, role, authority in inputs
    ]


def build_result_markdown(summary: Mapping[str, int]) -> str:
    return (
        "# B05/B06 review-evidence result\n\n"
        "B05_DECISION_PACKAGE_GENERATED\n"
        "B05_CONTRACT_UNCHANGED\n"
        "B05_SCIENTIFIC_REVIEW_REQUIRED\n\n"
        "B06_COMPONENT_EVIDENCE_GENERATED\n"
        "B06_FAMILY_GROUPING_NOT_INFERRED\n"
        "B06_CONTRACT_UNCHANGED\n\n"
        "## Counts\n\n"
        f"- Source-column evidence rows: {summary['source_column_rows']}.\n"
        f"- Table-grain evidence rows: {summary['table_grain_rows']}.\n"
        f"- B05 exact scalar source-variable decisions: {summary['b05_decisions']}.\n"
        f"- B05 literal source-name collisions: {summary['b05_name_collisions']}.\n"
        f"- B05 upstream/direct-schema exceptions: {summary['b05_exceptions']}.\n"
        f"- B06 discrete-valued component decisions: {summary['b06_component_decisions']}.\n"
        f"- B06 exact code-label mappings: {summary['b06_codebook_rows']}.\n"
        f"- B06 components lacking some exact codebook years: {summary['b06_components_with_codebook_gaps']}.\n"
        f"- Legacy discrete-QC priority rows retained as diagnostic-only: {summary['legacy_qc_rows']}.\n\n"
        "No analysis-column name, logical type, inclusion decision, transformation, "
        "discrete family, token class, zero-active meaning, or collapse policy was "
        "approved or inferred. Legacy outputs are review-priority diagnostics only.\n\n"
        "FULL_BUILD_NOT_RUN\n"
        "RELEASE_STILL_BLOCKED\n"
    )


def build_package(
    *,
    repo_root: Path,
    source_column_evidence: Path,
    table_grain_evidence: Path,
    evidence_artifact_manifest: Path,
    dictionary_codes: Path,
    legacy_discrete_qc: Path,
    out_dir: Path,
    contract_id: str = PANEL_CONTRACT_ID,
) -> dict[str, int]:
    repo_root = Path(repo_root).resolve()
    source_column_evidence = Path(source_column_evidence).resolve()
    table_grain_evidence = Path(table_grain_evidence).resolve()
    evidence_artifact_manifest = Path(evidence_artifact_manifest).resolve()
    dictionary_codes = Path(dictionary_codes).resolve()
    legacy_discrete_qc = Path(legacy_discrete_qc).resolve()
    out_dir = Path(out_dir).absolute()
    validate_output_path(repo_root, out_dir)

    canonical_before = contract_snapshot(repo_root)
    manifest_rows = read_csv_rows(
        evidence_artifact_manifest,
        ("path", "byte_size", "sha256"),
        "B03/B04 artifact manifest",
    )
    verify_evidence_binding(
        source_column_evidence,
        artifact_manifest_path=evidence_artifact_manifest,
        artifact_manifest_rows=manifest_rows,
        repo_root=repo_root,
    )
    verify_evidence_binding(
        table_grain_evidence,
        artifact_manifest_path=evidence_artifact_manifest,
        artifact_manifest_rows=manifest_rows,
        repo_root=repo_root,
    )

    source_rows = read_csv_rows(
        source_column_evidence,
        SOURCE_REQUIRED,
        "B04 source-column evidence",
    )
    table_rows = read_csv_rows(
        table_grain_evidence,
        TABLE_REQUIRED,
        "B03 table-grain evidence",
    )
    code_rows = read_csv_rows(
        dictionary_codes,
        CODE_REQUIRED,
        "archived dictionary codes",
    )
    legacy_rows = read_csv_rows(
        legacy_discrete_qc,
        LEGACY_QC_REQUIRED,
        "legacy discrete QC",
    )
    if not source_rows or not table_rows:
        raise ReviewEvidenceError("B03/B04 evidence must be nonempty")
    validate_contract_ids(
        source_rows,
        contract_id=contract_id,
        label="B04 source-column evidence",
    )
    validate_contract_ids(
        table_rows,
        contract_id=contract_id,
        label="B03 table-grain evidence",
    )

    table_index = build_table_index(table_rows)
    b05_rows, collision_rows, exception_rows, eligible_source_rows = build_b05_rows(
        source_rows,
        table_index,
    )
    b06_rows, code_evidence_rows = build_b06_rows(
        eligible_source_rows,
        build_code_index(code_rows),
    )
    legacy_diagnostic_rows = build_legacy_diagnostics(legacy_rows)
    summary = {
        "source_column_rows": len(source_rows),
        "table_grain_rows": len(table_rows),
        "b05_decisions": len(b05_rows),
        "b05_name_collisions": len(collision_rows),
        "b05_exceptions": len(exception_rows),
        "b06_component_decisions": len(b06_rows),
        "b06_codebook_rows": len(code_evidence_rows),
        "b06_components_with_codebook_gaps": sum(
            bool(str(row["missing_codebook_years"])) for row in b06_rows
        ),
        "legacy_qc_rows": len(legacy_diagnostic_rows),
    }

    out_dir.parent.mkdir(parents=True, exist_ok=True)
    temp_dir = Path(
        tempfile.mkdtemp(prefix=f".{out_dir.name}.staging-", dir=out_dir.parent)
    )
    try:
        input_rows = build_input_manifest(
            repo_root=repo_root,
            source_column_evidence=source_column_evidence,
            table_grain_evidence=table_grain_evidence,
            evidence_artifact_manifest=evidence_artifact_manifest,
            dictionary_codes=dictionary_codes,
            legacy_discrete_qc=legacy_discrete_qc,
        )
        write_csv_rows(
            temp_dir / "B05_B06_INPUT_MANIFEST.csv",
            INPUT_MANIFEST_FIELDS,
            input_rows,
        )
        write_csv_rows(
            temp_dir / "B05_SOURCE_VARIABLE_DECISIONS.csv",
            B05_FIELDS,
            b05_rows,
        )
        write_csv_rows(
            temp_dir / "B05_NAME_COLLISIONS.csv",
            B05_COLLISION_FIELDS,
            collision_rows,
        )
        write_csv_rows(
            temp_dir / "B05_EXCEPTIONS.csv",
            B05_EXCEPTION_FIELDS,
            exception_rows,
        )
        write_csv_rows(
            temp_dir / "B06_COMPONENT_DECISIONS.csv",
            B06_FIELDS,
            b06_rows,
        )
        write_csv_rows(
            temp_dir / "B06_CODEBOOK_EVIDENCE.csv",
            B06_CODE_FIELDS,
            code_evidence_rows,
        )
        write_csv_rows(
            temp_dir / "B06_LEGACY_PATTERN_DIAGNOSTICS.csv",
            B06_LEGACY_FIELDS,
            legacy_diagnostic_rows,
        )
        (temp_dir / "B05_B06_RESULT.md").write_text(
            build_result_markdown(summary),
            encoding="utf-8",
        )

        canonical_after = contract_snapshot(repo_root)
        all_contract_paths = sorted(set(canonical_before) | set(canonical_after))
        comparison_rows = [
            {
                "path": path,
                "pre_sha256": canonical_before.get(path, ""),
                "post_sha256": canonical_after.get(path, ""),
                "unchanged": (
                    "true"
                    if canonical_before.get(path) == canonical_after.get(path)
                    else "false"
                ),
            }
            for path in all_contract_paths
        ]
        if any(row["unchanged"] != "true" for row in comparison_rows):
            raise ReviewEvidenceError(
                "canonical contracts changed while B05/B06 evidence was generated"
            )
        write_csv_rows(
            temp_dir / "B05_B06_CANONICAL_HASH_COMPARISON.csv",
            CANONICAL_COMPARISON_FIELDS,
            comparison_rows,
        )

        input_manifest_hash = sha256_file(temp_dir / "B05_B06_INPUT_MANIFEST.csv")
        generator_hash = sha256_file(Path(__file__).resolve())
        artifact_rows = [
            {
                "path": path.name,
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
                "generator_sha256": generator_hash,
                "input_manifest_sha256": input_manifest_hash,
            }
            for path in sorted(temp_dir.iterdir())
            if path.is_file() and path.name != "B05_B06_ARTIFACT_MANIFEST.csv"
        ]
        write_csv_rows(
            temp_dir / "B05_B06_ARTIFACT_MANIFEST.csv",
            ARTIFACT_MANIFEST_FIELDS,
            artifact_rows,
        )
        os.replace(temp_dir, out_dir)
    finally:
        if temp_dir.exists():
            shutil.rmtree(temp_dir)
    return summary


def verify_package(out_dir: Path) -> dict[str, int]:
    """Reverify package hashes and the non-approval boundary."""
    out_dir = Path(out_dir).resolve()
    if not out_dir.is_dir():
        raise ReviewEvidenceError(f"B05/B06 review package does not exist: {out_dir}")
    manifest_path = out_dir / "B05_B06_ARTIFACT_MANIFEST.csv"
    rows = read_csv_rows(
        manifest_path,
        ARTIFACT_MANIFEST_FIELDS,
        "B05/B06 artifact manifest",
    )
    names = [str(row["path"]).strip() for row in rows]
    if len(names) != len(set(names)):
        raise ReviewEvidenceError("B05/B06 artifact manifest repeats paths")
    if any(not name or Path(name).name != name for name in names):
        raise ReviewEvidenceError("B05/B06 artifact manifest contains an unsafe path")
    actual_names = sorted(
        path.name
        for path in out_dir.iterdir()
        if path.is_file() and path.name != manifest_path.name
    )
    if sorted(names) != actual_names:
        raise ReviewEvidenceError(
            "B05/B06 artifact inventory mismatch: "
            f"manifest={sorted(names)} actual={actual_names}"
        )

    input_manifest = out_dir / "B05_B06_INPUT_MANIFEST.csv"
    input_hash = sha256_file(input_manifest)
    generator_hash = sha256_file(Path(__file__).resolve())
    for row in rows:
        path = out_dir / str(row["path"])
        try:
            expected_size = int(str(row["byte_size"]).strip())
        except ValueError as exc:
            raise ReviewEvidenceError(
                f"B05/B06 artifact manifest has invalid byte_size for {path.name}"
            ) from exc
        if path.stat().st_size != expected_size:
            raise ReviewEvidenceError(
                f"artifact size mismatch for {path.name}: "
                f"expected={expected_size} observed={path.stat().st_size}"
            )
        observed_hash = sha256_file(path)
        if observed_hash != str(row["sha256"]).strip().lower():
            raise ReviewEvidenceError(
                f"artifact hash mismatch for {path.name}: "
                f"expected={row['sha256']} observed={observed_hash}"
            )
        if str(row["generator_sha256"]).strip().lower() != generator_hash:
            raise ReviewEvidenceError(
                f"artifact generator binding is stale for {path.name}"
            )
        if str(row["input_manifest_sha256"]).strip().lower() != input_hash:
            raise ReviewEvidenceError(
                f"artifact input-manifest binding is stale for {path.name}"
            )

    comparison = read_csv_rows(
        out_dir / "B05_B06_CANONICAL_HASH_COMPARISON.csv",
        CANONICAL_COMPARISON_FIELDS,
        "B05/B06 canonical hash comparison",
    )
    if not comparison or any(
        str(row["unchanged"]).strip().lower() != "true"
        or row["pre_sha256"] != row["post_sha256"]
        for row in comparison
    ):
        raise ReviewEvidenceError(
            "B05/B06 package does not prove canonical contracts unchanged"
        )

    b05 = read_csv_rows(
        out_dir / "B05_SOURCE_VARIABLE_DECISIONS.csv",
        B05_FIELDS,
        "B05 source-variable decisions",
    )
    b05_semantic_fields = (
        "analysis_column_decision",
        "logical_type_decision",
        "transformation_decision",
        "inclusion_decision",
        "contract_first_year_decision",
        "contract_last_year_decision",
        "nullable_decision",
    )
    if any(
        str(row[field]).strip()
        for row in b05
        for field in b05_semantic_fields
    ):
        raise ReviewEvidenceError(
            "B05 review package contains an unauthorized semantic decision"
        )
    if any(row["decision_status"] != "pending_scientific_review" for row in b05):
        raise ReviewEvidenceError("B05 review package contains a non-pending status")

    b06 = read_csv_rows(
        out_dir / "B06_COMPONENT_DECISIONS.csv",
        B06_FIELDS,
        "B06 component decisions",
    )
    b06_semantic_fields = (
        "family_id_decision",
        "component_code_decision",
        "semantic_type_decision",
        "active_tokens_decision",
        "inactive_tokens_decision",
        "missing_tokens_decision",
        "output_column_decision",
        "output_type_decision",
        "multi_active_policy_decision",
        "drop_components_decision",
    )
    if any(
        str(row[field]).strip()
        for row in b06
        for field in b06_semantic_fields
    ):
        raise ReviewEvidenceError(
            "B06 review package contains an unauthorized family decision"
        )
    if any(
        row["decision_status"] != "requires_source_semantic_review"
        for row in b06
    ):
        raise ReviewEvidenceError("B06 review package contains a resolved status")

    code_rows = read_csv_rows(
        out_dir / "B06_CODEBOOK_EVIDENCE.csv",
        B06_CODE_FIELDS,
        "B06 codebook evidence",
    )
    if any(
        row["authority"] != "exact_code_label_diagnostic_not_family_approval"
        for row in code_rows
    ):
        raise ReviewEvidenceError("B06 codebook evidence overstates its authority")
    legacy_rows = read_csv_rows(
        out_dir / "B06_LEGACY_PATTERN_DIAGNOSTICS.csv",
        B06_LEGACY_FIELDS,
        "B06 legacy diagnostics",
    )
    if any(
        row["authority"] != "legacy_name_pattern_diagnostic_only"
        or row["eligible_as_family_evidence"] != "false"
        for row in legacy_rows
    ):
        raise ReviewEvidenceError("legacy discrete diagnostics overstate their authority")

    result_text = (out_dir / "B05_B06_RESULT.md").read_text(encoding="utf-8")
    required_markers = (
        "B05_SCIENTIFIC_REVIEW_REQUIRED",
        "B06_FAMILY_GROUPING_NOT_INFERRED",
        "FULL_BUILD_NOT_RUN",
        "RELEASE_STILL_BLOCKED",
    )
    missing_markers = [marker for marker in required_markers if marker not in result_text]
    if missing_markers:
        raise ReviewEvidenceError(
            f"B05/B06 result is missing blocked-status markers: {missing_markers}"
        )
    return {
        "artifacts": len(rows),
        "b05_decisions": len(b05),
        "b06_component_decisions": len(b06),
        "b06_codebook_rows": len(code_rows),
        "legacy_qc_rows": len(legacy_rows),
    }


def parse_args() -> argparse.Namespace:
    repo = Path(__file__).resolve().parents[1]
    evidence = (
        repo
        / "Artifacts"
        / "review_v2"
        / "b03_b04_package_rebaseline_2026-07-24"
    )
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=repo)
    parser.add_argument(
        "--source-column-evidence",
        type=Path,
        default=evidence / "source_column_enriched.csv",
    )
    parser.add_argument(
        "--table-grain-evidence",
        type=Path,
        default=evidence / "table_grain_enriched.csv",
    )
    parser.add_argument(
        "--evidence-artifact-manifest",
        type=Path,
        default=evidence / "B03_B04_artifact_manifest.csv",
    )
    parser.add_argument("--dictionary-codes", type=Path)
    parser.add_argument("--legacy-discrete-qc", type=Path)
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=repo / "Artifacts" / "review_v2" / "b05_b06_review",
    )
    parser.add_argument("--contract-id", default=PANEL_CONTRACT_ID)
    parser.add_argument(
        "--verify-only",
        action="store_true",
        help="Reverify an existing package without reading source evidence.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.verify_only:
        print(json.dumps(verify_package(args.out_dir), indent=2, sort_keys=True))
        return
    if args.dictionary_codes is None or args.legacy_discrete_qc is None:
        raise SystemExit(
            "--dictionary-codes and --legacy-discrete-qc are required when building"
        )
    summary = build_package(
        repo_root=args.repo_root,
        source_column_evidence=args.source_column_evidence,
        table_grain_evidence=args.table_grain_evidence,
        evidence_artifact_manifest=args.evidence_artifact_manifest,
        dictionary_codes=args.dictionary_codes,
        legacy_discrete_qc=args.legacy_discrete_qc,
        out_dir=args.out_dir,
        contract_id=args.contract_id,
    )
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
