#!/usr/bin/env python3
"""Build deterministic, review-only conservative B05/B06 contract candidates.

The package is deliberately non-approving:

* B05 governs every exact scalar source identity from the completed evidence;
  identities with no observed non-null values are explicit all-null exclusions.
* Literal names are joined only for identical source VarNumbers over disjoint
  observed years with one stable exact official VarTitle; title drift and all
  other name collisions are split without choosing a preferred source.
* B06 retains every exact discrete component as its own ``not_collapsible``
  family. It does not infer one-hot or multi-select semantics.
* Canonical contracts are snapshotted and must remain byte-identical.

Candidate analysis rows use ``status=active`` only for executable rows and
``status=excluded_all_null`` for evidence-proven empty identities. The separate
decision register remains authoritative for review state.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import json
import shutil
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable, Mapping, Sequence


PANEL_CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"

B05_REQUIRED = (
    "decision_id",
    "contract_id",
    "variable_id",
    "source_variables",
    "source_file",
    "source_varnumber",
    "source_varname",
    "years_present",
    "observed_first_year",
    "observed_last_year",
    "annual_evidence_rows",
    "max_source_columns_per_year",
    "duplicate_identity_years",
    "metadata_statuses",
    "candidate_key_statuses",
    "b03_dependency_status",
    "b04_dependency_status",
    "data_type_evidence",
    "format_evidence",
    "var_titles",
    "nonempty_count_total",
    "null_count_total",
    "distinct_nonempty_count_max",
    "decision_status",
)

B06_REQUIRED = (
    "decision_id",
    "contract_id",
    "variable_id",
    "source_file",
    "source_varnumber",
    "source_varname",
    "source_variables",
    "years_present",
    "source_format_evidence",
    "exact_codebook_years",
    "missing_codebook_years",
    "exact_codebook_mapping_count",
    "code_label_conflict_count",
    "b03_dependency_status",
    "b04_dependency_status",
    "family_id_decision",
    "component_code_decision",
    "semantic_type_decision",
    "active_tokens_decision",
    "inactive_tokens_decision",
    "missing_tokens_decision",
    "output_column_decision",
    "output_type_decision",
    "multi_active_policy_decision",
    "drop_components_decision",
    "decision_status",
    "evidence_basis",
)

ANALYSIS_FIELDS = (
    "contract_id",
    "analysis_column",
    "logical_type",
    "source_variables",
    "transformation",
    "inclusion_reason",
    "first_year",
    "last_year",
    "nullable",
    "status",
)

DISCRETE_FIELDS = (
    "contract_id",
    "source_file",
    "family_id",
    "component_varname",
    "component_code",
    "semantic_type",
    "active_tokens",
    "inactive_tokens",
    "missing_tokens",
    "output_column",
    "output_type",
    "multi_active_policy",
    "drop_components",
    "source_evidence",
    "review_note",
)

IDENTITY_MAPPING_FIELDS = (
    "variable_id",
    "input_decision_id",
    "source_file",
    "source_varnumber",
    "source_varname",
    "years_present",
    "analysis_column",
    "candidate_decision_id",
    "grouping_policy",
    "normalized_var_titles",
    "semantic_title_status",
    "logical_type",
    "source_variables",
)

TITLE_DRIFT_FIELDS = (
    "title_drift_group_id",
    "contract_id",
    "source_varname",
    "source_varnumber",
    "variable_id",
    "source_file",
    "years_present",
    "normalized_var_titles",
    "normalized_var_title_count",
    "candidate_decision_id",
    "candidate_analysis_column",
    "semantic_title_status",
    "review_status",
    "review_reason",
)

PARTIAL_CODEBOOK_FIELDS = (
    "decision_id",
    "contract_id",
    "variable_id",
    "source_file",
    "source_varnumber",
    "source_varname",
    "years_present",
    "exact_codebook_years",
    "missing_codebook_years",
    "candidate_family_id",
    "candidate_semantic_type",
    "review_status",
    "review_note",
)

DECISION_REGISTER_FIELDS = (
    "phase",
    "decision_id",
    "contract_id",
    "candidate_key",
    "exact_source_identities",
    "source_identity_count",
    "source_varname",
    "source_varnumber",
    "years_present",
    "proposed_action",
    "proposed_logical_type",
    "grouping_policy",
    "normalized_var_titles",
    "semantic_title_status",
    "proposal_basis",
    "review_status",
    "reviewer_decision",
    "reviewer",
    "review_date",
)

INPUT_MANIFEST_FIELDS = (
    "input_id",
    "path",
    "byte_size",
    "sha256",
    "authority",
)

ARTIFACT_MANIFEST_FIELDS = (
    "path",
    "byte_size",
    "sha256",
    "generator_sha256",
    "input_manifest_sha256",
)

CANONICAL_COMPARISON_FIELDS = (
    "path",
    "pre_sha256",
    "post_sha256",
    "unchanged",
)

PREDECIDED_B05_FIELDS = (
    "analysis_column_decision",
    "logical_type_decision",
    "transformation_decision",
    "inclusion_decision",
    "contract_first_year_decision",
    "contract_last_year_decision",
    "nullable_decision",
)

PREDECIDED_B06_FIELDS = (
    "family_id_decision",
    "component_code_decision",
    "semantic_type_decision",
    "active_tokens_decision",
    "inactive_tokens_decision",
    "missing_tokens_decision",
    "output_column_decision",
    "output_type_decision",
    "multi_active_policy_decision",
    "drop_components_decision",
)


class CandidateEvidenceError(ValueError):
    """Raised when evidence cannot safely support the conservative projection."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_id(prefix: str, value: str, length: int = 12) -> str:
    token = hashlib.sha256(value.encode("utf-8")).hexdigest()[:length].upper()
    return f"{prefix}-{token}"


def write_csv(
    path: Path,
    fields: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fields),
            extrasaction="ignore",
            lineterminator="\n",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_csv(
    path: Path,
    required: Sequence[str],
    *,
    label: str,
) -> list[dict[str, str]]:
    if not path.is_file():
        raise CandidateEvidenceError(f"{label} does not exist: {path}")
    try:
        with path.open(newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            fields = reader.fieldnames or []
            if len(fields) != len(set(fields)):
                raise CandidateEvidenceError(f"{label} repeats CSV headers")
            missing = [field for field in required if field not in fields]
            if missing:
                raise CandidateEvidenceError(
                    f"{label} is missing required columns: {missing}"
                )
            rows: list[dict[str, str]] = []
            for number, row in enumerate(reader, start=2):
                if None in row:
                    raise CandidateEvidenceError(
                        f"{label} row {number} has more values than headers"
                    )
                rows.append({key: str(value or "") for key, value in row.items()})
            return rows
    except UnicodeDecodeError as exc:
        raise CandidateEvidenceError(f"{label} is not strict UTF-8") from exc


def normalize_upper(value: object) -> str:
    return str(value or "").strip().upper()


def normalize_varnumber(value: object) -> str:
    token = "".join(str(value or "").split())
    if token.lower() in {"", "nan", "none", "<na>", "na", "nat"}:
        return ""
    return token.zfill(8) if token.isdigit() else token


def split_tokens(value: object) -> tuple[str, ...]:
    return tuple(
        token.strip()
        for token in str(value or "").split("|")
        if token.strip()
    )


def parse_years(value: object, *, label: str) -> tuple[int, ...]:
    raw = split_tokens(value)
    if not raw:
        raise CandidateEvidenceError(f"{label} has no observed years")
    if any(not token.isdigit() for token in raw):
        raise CandidateEvidenceError(f"{label} has invalid years: {value!r}")
    years = tuple(int(token) for token in raw)
    if years != tuple(sorted(set(years))):
        raise CandidateEvidenceError(
            f"{label} years must be unique and ascending: {value!r}"
        )
    return years


def parse_nonnegative_int(value: object, *, label: str) -> int:
    token = str(value or "").strip()
    try:
        number = int(token)
    except ValueError as exc:
        raise CandidateEvidenceError(f"{label} is not an integer: {value!r}") from exc
    if number < 0:
        raise CandidateEvidenceError(f"{label} is negative: {value!r}")
    return number


def expected_variable_id(row: Mapping[str, str]) -> str:
    source_file = normalize_upper(row.get("source_file", ""))
    varnumber = normalize_varnumber(row.get("source_varnumber", ""))
    varname = normalize_upper(row.get("source_varname", ""))
    if not source_file or not varnumber or not varname:
        return ""
    return f"nces:{source_file}:{varnumber}:{varname}"


def canonical_snapshot(repo_root: Path) -> dict[str, str]:
    contracts = repo_root.resolve() / "contracts"
    if not contracts.is_dir():
        raise CandidateEvidenceError(
            f"canonical contracts directory is missing: {contracts}"
        )
    return {
        path.relative_to(repo_root.resolve()).as_posix(): sha256_file(path)
        for path in sorted(contracts.rglob("*"))
        if path.is_file()
    }


def validate_output_path(repo_root: Path, out_dir: Path) -> None:
    contracts = repo_root.resolve() / "contracts"
    candidate = out_dir.resolve()
    if candidate == contracts or contracts in candidate.parents:
        raise CandidateEvidenceError(
            f"review output cannot be written inside canonical contracts: {candidate}"
        )
    if candidate.exists():
        raise CandidateEvidenceError(
            f"refusing to overwrite existing review output: {candidate}"
        )


def verify_manifest_binding(
    evidence_path: Path,
    *,
    manifest_rows: Sequence[Mapping[str, str]],
    label: str,
) -> None:
    matches = [
        row
        for row in manifest_rows
        if Path(str(row.get("path", ""))).name == evidence_path.name
    ]
    if len(matches) != 1:
        raise CandidateEvidenceError(
            f"{label} must have exactly one filename binding in the evidence "
            f"manifest; found={len(matches)}"
        )
    match = matches[0]
    expected_size = parse_nonnegative_int(
        match.get("byte_size", ""),
        label=f"{label} manifest byte_size",
    )
    if evidence_path.stat().st_size != expected_size:
        raise CandidateEvidenceError(
            f"{label} size does not match the completed evidence manifest"
        )
    expected_hash = str(match.get("sha256", "")).strip().lower()
    observed_hash = sha256_file(evidence_path)
    if expected_hash != observed_hash:
        raise CandidateEvidenceError(
            f"{label} SHA-256 does not match the completed evidence manifest"
        )


def validate_b05_rows(
    rows: Sequence[Mapping[str, str]],
    *,
    contract_id: str,
) -> dict[str, tuple[int, ...]]:
    if not rows:
        raise CandidateEvidenceError("B05 exact scalar evidence is empty")
    identities: dict[str, tuple[int, ...]] = {}
    for number, row in enumerate(rows, start=2):
        label = f"B05 row {number}"
        if str(row.get("contract_id", "")).strip() != contract_id:
            raise CandidateEvidenceError(f"{label} has the wrong contract_id")
        variable_id = str(row.get("variable_id", "")).strip()
        expected_id = expected_variable_id(row)
        if not expected_id or variable_id != expected_id:
            raise CandidateEvidenceError(
                f"{label} does not carry its exact NCES source identity"
            )
        if variable_id in identities:
            raise CandidateEvidenceError(
                f"B05 repeats exact source identity: {variable_id}"
            )
        if str(row.get("source_variables", "")).strip() != f"variable_id:{variable_id}":
            raise CandidateEvidenceError(
                f"{label} does not bind source_variables to variable_id"
            )
        years = parse_years(row.get("years_present", ""), label=label)
        if str(min(years)) != str(row.get("observed_first_year", "")).strip():
            raise CandidateEvidenceError(f"{label} has a stale observed_first_year")
        if str(max(years)) != str(row.get("observed_last_year", "")).strip():
            raise CandidateEvidenceError(f"{label} has a stale observed_last_year")
        annual_rows = parse_nonnegative_int(
            row.get("annual_evidence_rows", ""),
            label=f"{label} annual_evidence_rows",
        )
        if annual_rows != len(years):
            raise CandidateEvidenceError(
                f"{label} annual evidence does not cover every observed year"
            )
        max_columns = parse_nonnegative_int(
            row.get("max_source_columns_per_year", ""),
            label=f"{label} max_source_columns_per_year",
        )
        if max_columns != 1 or str(row.get("duplicate_identity_years", "")).strip():
            raise CandidateEvidenceError(
                f"{label} is not a one-column-per-year exact scalar identity"
            )
        if split_tokens(row.get("metadata_statuses", "")) != ("exact",):
            raise CandidateEvidenceError(f"{label} metadata identity is not exact")
        if split_tokens(row.get("candidate_key_statuses", "")) != (
            "proven_complete",
        ):
            raise CandidateEvidenceError(f"{label} scalar key is not proven complete")
        if "scalar" not in str(row.get("b03_dependency_status", "")).lower():
            raise CandidateEvidenceError(f"{label} is not scalar evidence")
        if str(row.get("decision_status", "")).strip() != "pending_scientific_review":
            raise CandidateEvidenceError(
                f"{label} is not in the expected pending evidence state"
            )
        predecided = [
            field
            for field in PREDECIDED_B05_FIELDS
            if str(row.get(field, "")).strip()
        ]
        if predecided:
            raise CandidateEvidenceError(
                f"{label} unexpectedly contains prior B05 decisions: {predecided}"
            )
        logical_type_for_rows([row])
        nonempty_count = parse_nonnegative_int(
            row.get("nonempty_count_total", ""),
            label=f"{label} nonempty_count_total",
        )
        null_count = parse_nonnegative_int(
            row.get("null_count_total", ""),
            label=f"{label} null_count_total",
        )
        distinct_nonempty_count = parse_nonnegative_int(
            row.get("distinct_nonempty_count_max", ""),
            label=f"{label} distinct_nonempty_count_max",
        )
        if (
            (nonempty_count == 0 and distinct_nonempty_count != 0)
            or (
                nonempty_count > 0
                and not 1 <= distinct_nonempty_count <= nonempty_count
            )
        ):
            raise CandidateEvidenceError(
                f"{label} distinct_nonempty_count_max is inconsistent with "
                "nonempty_count_total"
            )
        if nonempty_count + null_count == 0:
            raise CandidateEvidenceError(
                f"{label} has no observed source cells"
            )
        identities[variable_id] = years
    return identities


def validate_b06_rows(
    rows: Sequence[Mapping[str, str]],
    *,
    contract_id: str,
    b05_by_id: Mapping[str, Mapping[str, str]],
    b05_years: Mapping[str, tuple[int, ...]],
) -> None:
    if not rows:
        raise CandidateEvidenceError("B06 component evidence is empty")
    seen: set[str] = set()
    for number, row in enumerate(rows, start=2):
        label = f"B06 row {number}"
        if str(row.get("contract_id", "")).strip() != contract_id:
            raise CandidateEvidenceError(f"{label} has the wrong contract_id")
        variable_id = str(row.get("variable_id", "")).strip()
        if variable_id in seen:
            raise CandidateEvidenceError(
                f"B06 repeats exact discrete identity: {variable_id}"
            )
        seen.add(variable_id)
        if variable_id != expected_variable_id(row):
            raise CandidateEvidenceError(
                f"{label} does not carry its exact NCES source identity"
            )
        if str(row.get("source_variables", "")).strip() != f"variable_id:{variable_id}":
            raise CandidateEvidenceError(
                f"{label} does not bind source_variables to variable_id"
            )
        b05 = b05_by_id.get(variable_id)
        if b05 is None:
            raise CandidateEvidenceError(
                f"{label} has no matching exact scalar B05 identity"
            )
        for field in ("source_file", "source_varnumber", "source_varname"):
            if normalize_upper(row.get(field, "")) != normalize_upper(b05.get(field, "")):
                raise CandidateEvidenceError(
                    f"{label} disagrees with B05 exact identity field {field}"
                )
        formats = {normalize_upper(token) for token in split_tokens(
            b05.get("format_evidence", "")
        )}
        if "DISC" not in formats:
            raise CandidateEvidenceError(
                f"{label} is not metadata-supported as a discrete component"
            )
        years = parse_years(row.get("years_present", ""), label=label)
        if years != b05_years[variable_id]:
            raise CandidateEvidenceError(
                f"{label} observed years disagree with B05 evidence"
            )
        exact = set(
            parse_years(row.get("exact_codebook_years", ""), label=f"{label} exact")
        )
        missing_raw = split_tokens(row.get("missing_codebook_years", ""))
        missing = (
            set(
                parse_years(
                    row.get("missing_codebook_years", ""),
                    label=f"{label} missing",
                )
            )
            if missing_raw
            else set()
        )
        if exact & missing or exact | missing != set(years):
            raise CandidateEvidenceError(
                f"{label} codebook-year evidence does not partition observed years"
            )
        if parse_nonnegative_int(
            row.get("exact_codebook_mapping_count", ""),
            label=f"{label} exact_codebook_mapping_count",
        ) <= 0:
            raise CandidateEvidenceError(
                f"{label} has no exact codebook mapping evidence"
            )
        if parse_nonnegative_int(
            row.get("code_label_conflict_count", ""),
            label=f"{label} code_label_conflict_count",
        ):
            raise CandidateEvidenceError(
                f"{label} has unresolved exact code-label conflicts"
            )
        if "DISC" not in {
            normalize_upper(token)
            for token in split_tokens(row.get("source_format_evidence", ""))
        }:
            raise CandidateEvidenceError(
                f"{label} lacks DISC source-format evidence"
            )
        if str(row.get("decision_status", "")).strip() != (
            "requires_source_semantic_review"
        ):
            raise CandidateEvidenceError(
                f"{label} is not in the expected pending evidence state"
            )
        predecided = [
            field
            for field in PREDECIDED_B06_FIELDS
            if str(row.get(field, "")).strip()
        ]
        if predecided:
            raise CandidateEvidenceError(
                f"{label} unexpectedly contains prior B06 decisions: {predecided}"
            )


def pairwise_disjoint(year_sets: Sequence[set[int]]) -> bool:
    return all(
        year_sets[left].isdisjoint(year_sets[right])
        for left in range(len(year_sets))
        for right in range(left + 1, len(year_sets))
    )


def normalized_title_signature(row: Mapping[str, str]) -> tuple[str, ...]:
    return tuple(
        sorted(
            {
                normalize_upper(token)
                for token in split_tokens(row.get("var_titles", ""))
                if normalize_upper(token) not in {"", "<BLANK>"}
            }
        )
    )


def logical_type_for_rows(rows: Sequence[Mapping[str, str]]) -> str:
    data_types = {
        normalize_upper(token)
        for row in rows
        for token in split_tokens(row.get("data_type_evidence", ""))
        if normalize_upper(token) not in {"", "<BLANK>"}
    }
    formats = {
        normalize_upper(token)
        for row in rows
        for token in split_tokens(row.get("format_evidence", ""))
        if normalize_upper(token) not in {"", "<BLANK>"}
    }
    if "DISC" in formats:
        return "categorical string"
    if "A" in data_types or "ALPHA" in formats:
        return "free text"
    if data_types == {"N"} and formats == {"CONT"}:
        return "float"
    raise CandidateEvidenceError(
        "no conservative metadata-supported logical type for "
        f"data_type={sorted(data_types)} format={sorted(formats)}"
    )


def conflict_analysis_column(row: Mapping[str, str]) -> str:
    variable_id = str(row["variable_id"])
    source_file = normalize_upper(row["source_file"])
    varnumber = normalize_varnumber(row["source_varnumber"])
    varname = normalize_upper(row["source_varname"])
    suffix = hashlib.sha256(variable_id.encode("utf-8")).hexdigest()[:12].upper()
    return f"{varname}__{source_file}__{varnumber}__{suffix}"


def build_b05_candidates(
    rows: Sequence[Mapping[str, str]],
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
    dict[str, int],
]:
    by_name: dict[str, list[Mapping[str, str]]] = defaultdict(list)
    for row in rows:
        by_name[normalize_upper(row["source_varname"])].append(row)

    candidate_groups: list[
        tuple[str, str, list[Mapping[str, str]]]
    ] = []
    grouped_candidate_count = 0
    grouped_identity_count = 0
    disambiguated_identity_count = 0
    title_drift_group_count = 0
    title_drift_identity_count = 0
    active_identity_count = 0
    excluded_all_null_identity_count = 0
    title_drift_groups: dict[str, str] = {}
    for varname, name_rows in sorted(by_name.items()):
        ordered = sorted(name_rows, key=lambda row: str(row["variable_id"]))
        if len(ordered) == 1:
            candidate_groups.append((varname, "literal_single_identity", ordered))
            continue
        numbers = {
            normalize_varnumber(row.get("source_varnumber", "")) for row in ordered
        }
        year_sets = [
            set(parse_years(row["years_present"], label=str(row["variable_id"])))
            for row in ordered
        ]
        if len(numbers) == 1 and pairwise_disjoint(year_sets):
            title_signatures = [
                normalized_title_signature(row) for row in ordered
            ]
            title_stable = (
                all(len(signature) == 1 for signature in title_signatures)
                and len(set(title_signatures)) == 1
            )
            if title_stable:
                observation_states = {
                    parse_nonnegative_int(
                        row.get("nonempty_count_total", ""),
                        label=f"{row['variable_id']} nonempty_count_total",
                    )
                    > 0
                    for row in ordered
                }
                if len(observation_states) == 1:
                    candidate_groups.append(
                        (
                            varname,
                            "literal_same_varnumber_disjoint_years",
                            ordered,
                        )
                    )
                    grouped_candidate_count += 1
                    grouped_identity_count += len(ordered)
                else:
                    for row in ordered:
                        candidate_groups.append(
                            (
                                conflict_analysis_column(row),
                                "deterministic_observation_state_split",
                                [row],
                            )
                        )
                        disambiguated_identity_count += 1
            else:
                drift_group_id = stable_id(
                    "B05-TITLE",
                    "|".join(str(row["variable_id"]) for row in ordered),
                )
                title_drift_group_count += 1
                title_drift_identity_count += len(ordered)
                for row in ordered:
                    variable_id = str(row["variable_id"])
                    title_drift_groups[variable_id] = drift_group_id
                    candidate_groups.append(
                        (
                            conflict_analysis_column(row),
                            "deterministic_title_drift_split",
                            [row],
                        )
                    )
        else:
            for row in ordered:
                candidate_groups.append(
                    (
                        conflict_analysis_column(row),
                        "deterministic_conflict_disambiguation",
                        [row],
                    )
                )
                disambiguated_identity_count += 1

    proposed_names = [name for name, _, _ in candidate_groups]
    duplicates = sorted(
        name for name, count in Counter(proposed_names).items() if count > 1
    )
    if duplicates:
        raise CandidateEvidenceError(
            f"deterministic analysis-column allocation collided: {duplicates}"
        )

    schema_rows: list[dict[str, object]] = []
    mapping_rows: list[dict[str, object]] = []
    decision_rows: list[dict[str, object]] = []
    title_drift_rows: list[dict[str, object]] = []
    for analysis_column, grouping_policy, group in candidate_groups:
        variable_ids = sorted(str(row["variable_id"]) for row in group)
        source_variables = "|".join(f"variable_id:{value}" for value in variable_ids)
        years = sorted(
            {
                year
                for row in group
                for year in parse_years(
                    row["years_present"],
                    label=str(row["variable_id"]),
                )
            }
        )
        logical_type = logical_type_for_rows(group)
        decision_id = stable_id("B05-CAND", "|".join(variable_ids))
        title_signatures = [
            normalized_title_signature(row) for row in group
        ]
        normalized_titles = sorted(
            {
                title
                for signature in title_signatures
                for title in signature
            }
        )
        if grouping_policy == "deterministic_title_drift_split":
            semantic_title_status = "cross_identity_title_drift_split"
            reason = (
                "Exact scalar identities share a literal VarName and source "
                "VarNumber over disjoint years, but official VarTitle evidence "
                "changes within or across identities. Each identity is retained "
                "separately; no semantic equivalence is assumed."
            )
        elif not normalized_titles:
            semantic_title_status = "missing_official_title"
            reason = (
                "Exact scalar identity has no populated official VarTitle "
                "evidence; identity mapping remains pending author semantic review."
            )
        elif any(len(signature) != 1 for signature in title_signatures):
            semantic_title_status = "within_identity_title_drift"
            reason = (
                "Exact scalar identity has multiple official VarTitle values "
                "across observed years; the literal identity is retained without "
                "assuming that the wording change is semantically immaterial."
            )
        else:
            semantic_title_status = "stable_exact_title"
        if grouping_policy == "literal_same_varnumber_disjoint_years":
            reason = (
                "Exact scalar identities share the literal VarName and exact "
                "source VarNumber, one stable exact official VarTitle, and "
                "pairwise-disjoint observed years; conservative identity mapping "
                "pending author review."
            )
        elif grouping_policy == "literal_single_identity":
            if semantic_title_status == "stable_exact_title":
                reason = (
                    "One exact scalar identity uses this literal VarName with one "
                    "stable exact official VarTitle; conservative identity mapping "
                    "pending author review."
                )
        elif grouping_policy == "deterministic_conflict_disambiguation":
            reason = (
                "Literal VarName conflicts across incompatible exact identities; "
                "all identities are retained under deterministic evidence-derived "
                "names with no source priority."
            )
            if semantic_title_status != "stable_exact_title":
                reason += (
                    " Official VarTitle evidence is also missing or changes across "
                    "the identity's observed years, so author semantic review is "
                    "still required."
                )
        elif grouping_policy == "deterministic_observation_state_split":
            reason = (
                "Exact identities otherwise qualify for conservative disjoint-year "
                "grouping, but their observed-value states differ. They remain "
                "separate so an all-null identity cannot inherit active status from "
                "an observed identity."
            )
        group_nonempty_count = sum(
            parse_nonnegative_int(
                row.get("nonempty_count_total", ""),
                label=f"{row['variable_id']} nonempty_count_total",
            )
            for row in group
        )
        if group_nonempty_count == 0:
            status = "excluded_all_null"
            proposed_action = "excluded_all_null"
            reason = "no_observed_values"
            excluded_all_null_identity_count += len(group)
        else:
            status = "active"
            proposed_action = "include_direct_identity"
            active_identity_count += len(group)
        schema_rows.append(
            {
                "contract_id": str(group[0]["contract_id"]).strip(),
                "analysis_column": analysis_column,
                "logical_type": logical_type,
                "source_variables": source_variables,
                "transformation": "identity",
                "inclusion_reason": reason,
                "first_year": min(years),
                "last_year": max(years),
                "nullable": "true",
                "status": status,
            }
        )
        source_varnumbers = sorted(
            {normalize_varnumber(row["source_varnumber"]) for row in group}
        )
        decision_rows.append(
            {
                "phase": "B05",
                "decision_id": decision_id,
                "contract_id": str(group[0]["contract_id"]).strip(),
                "candidate_key": analysis_column,
                "exact_source_identities": "|".join(variable_ids),
                "source_identity_count": len(variable_ids),
                "source_varname": normalize_upper(group[0]["source_varname"]),
                "source_varnumber": "|".join(source_varnumbers),
                "years_present": "|".join(str(year) for year in years),
                "proposed_action": proposed_action,
                "proposed_logical_type": logical_type,
                "grouping_policy": grouping_policy,
                "normalized_var_titles": "|".join(normalized_titles),
                "semantic_title_status": semantic_title_status,
                "proposal_basis": reason,
                "review_status": (
                    "pending_author_review"
                    if semantic_title_status == "stable_exact_title"
                    else "pending_author_semantic_review"
                ),
                "reviewer_decision": "",
                "reviewer": "",
                "review_date": "",
            }
        )
        for row in group:
            mapping_rows.append(
                {
                    "variable_id": row["variable_id"],
                    "input_decision_id": row["decision_id"],
                    "source_file": normalize_upper(row["source_file"]),
                    "source_varnumber": normalize_varnumber(row["source_varnumber"]),
                    "source_varname": normalize_upper(row["source_varname"]),
                    "years_present": row["years_present"],
                    "analysis_column": analysis_column,
                    "candidate_decision_id": decision_id,
                    "grouping_policy": grouping_policy,
                    "normalized_var_titles": "|".join(
                        normalized_title_signature(row)
                    ),
                    "semantic_title_status": semantic_title_status,
                    "logical_type": logical_type,
                    "source_variables": source_variables,
                }
            )
            title_signature = normalized_title_signature(row)
            variable_id = str(row["variable_id"])
            if len(title_signature) != 1 or variable_id in title_drift_groups:
                title_drift_rows.append(
                    {
                        "title_drift_group_id": title_drift_groups.get(
                            variable_id,
                            stable_id("B05-TITLE", variable_id),
                        ),
                        "contract_id": str(row["contract_id"]).strip(),
                        "source_varname": normalize_upper(row["source_varname"]),
                        "source_varnumber": normalize_varnumber(
                            row["source_varnumber"]
                        ),
                        "variable_id": variable_id,
                        "source_file": normalize_upper(row["source_file"]),
                        "years_present": row["years_present"],
                        "normalized_var_titles": "|".join(title_signature),
                        "normalized_var_title_count": len(title_signature),
                        "candidate_decision_id": decision_id,
                        "candidate_analysis_column": analysis_column,
                        "semantic_title_status": semantic_title_status,
                        "review_status": "pending_author_semantic_review",
                        "review_reason": reason,
                    }
                )

    schema_rows.sort(key=lambda row: str(row["analysis_column"]))
    mapping_rows.sort(key=lambda row: str(row["variable_id"]))
    decision_rows.sort(key=lambda row: (str(row["candidate_key"]), str(row["decision_id"])))
    title_drift_rows.sort(
        key=lambda row: (
            str(row["title_drift_group_id"]),
            str(row["variable_id"]),
        )
    )

    expected_ids = {str(row["variable_id"]) for row in rows}
    mapped_counts = Counter(str(row["variable_id"]) for row in mapping_rows)
    if set(mapped_counts) != expected_ids or any(count != 1 for count in mapped_counts.values()):
        raise CandidateEvidenceError(
            "B05 identity mapping does not cover every exact source identity once"
        )
    contract_source_counts: Counter[str] = Counter()
    for row in schema_rows:
        for token in split_tokens(row["source_variables"]):
            if not token.startswith("variable_id:"):
                raise CandidateEvidenceError(
                    "B05 candidate contains a non-variable_id source binding"
                )
            contract_source_counts[token.removeprefix("variable_id:")] += 1
    if (
        set(contract_source_counts) != expected_ids
        or any(count != 1 for count in contract_source_counts.values())
    ):
        raise CandidateEvidenceError(
            "B05 contract projection maps a source identity zero or multiple times"
        )

    counts = {
        "b05_source_identity_count": len(rows),
        "b05_candidate_row_count": len(schema_rows),
        "b05_grouped_candidate_count": grouped_candidate_count,
        "b05_grouped_identity_count": grouped_identity_count,
        "b05_disambiguated_identity_count": disambiguated_identity_count,
        "b05_title_drift_group_count": title_drift_group_count,
        "b05_title_drift_identity_count": title_drift_identity_count,
        "b05_semantic_title_exception_count": len(title_drift_rows),
        "b05_active_identity_count": active_identity_count,
        "b05_excluded_all_null_identity_count": excluded_all_null_identity_count,
    }
    return schema_rows, mapping_rows, decision_rows, title_drift_rows, counts


def build_b06_candidates(
    rows: Sequence[Mapping[str, str]],
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
    dict[str, int],
]:
    candidate_rows: list[dict[str, object]] = []
    partial_rows: list[dict[str, object]] = []
    decision_rows: list[dict[str, object]] = []
    for row in sorted(
        rows,
        key=lambda value: (
            normalize_upper(value["source_file"]),
            normalize_upper(value["source_varname"]),
            normalize_varnumber(value["source_varnumber"]),
            str(value["variable_id"]),
        ),
    ):
        variable_id = str(row["variable_id"]).strip()
        family_id = (
            f"IDENTITY_{normalize_upper(row['source_varname'])}_"
            f"{hashlib.sha256(variable_id.encode('utf-8')).hexdigest()[:12].upper()}"
        )
        decision_id = stable_id("B06-CAND", variable_id)
        missing_years = str(row.get("missing_codebook_years", "")).strip()
        partial_note = (
            f" Partial codebook coverage: missing exact years={missing_years};"
            if missing_years
            else ""
        )
        review_note = (
            "Pending author review. Conservative proposal keeps this exact "
            "evidence-bound component not_collapsible, retains the component, "
            "and infers no active/inactive tokens, derived output, one-hot family, "
            f"or multi-select family.{partial_note}"
        )
        source_evidence = (
            f"{row['decision_id']}; variable_id:{variable_id}; "
            f"exact_codebook_years={row['exact_codebook_years']}; "
            f"missing_codebook_years={missing_years or '<none>'}; "
            f"{row['evidence_basis']}"
        )
        candidate_rows.append(
            {
                "contract_id": row["contract_id"],
                "source_file": normalize_upper(row["source_file"]),
                "family_id": family_id,
                "component_varname": normalize_upper(row["source_varname"]),
                "component_code": normalize_varnumber(row["source_varnumber"]),
                "semantic_type": "not_collapsible",
                "active_tokens": "",
                "inactive_tokens": "",
                "missing_tokens": "",
                "output_column": "",
                "output_type": "",
                "multi_active_policy": "",
                "drop_components": "false",
                "source_evidence": source_evidence,
                "review_note": review_note,
            }
        )
        decision_rows.append(
            {
                "phase": "B06",
                "decision_id": decision_id,
                "contract_id": row["contract_id"],
                "candidate_key": (
                    f"{normalize_upper(row['source_file'])}:{family_id}:"
                    f"{normalize_upper(row['source_varname'])}"
                ),
                "exact_source_identities": variable_id,
                "source_identity_count": 1,
                "source_varname": normalize_upper(row["source_varname"]),
                "source_varnumber": normalize_varnumber(row["source_varnumber"]),
                "years_present": row["years_present"],
                "proposed_action": "retain_not_collapsible",
                "proposed_logical_type": "categorical string",
                "proposal_basis": review_note,
                "review_status": "pending_author_review",
                "reviewer_decision": "",
                "reviewer": "",
                "review_date": "",
            }
        )
        if missing_years:
            partial_rows.append(
                {
                    "decision_id": decision_id,
                    "contract_id": row["contract_id"],
                    "variable_id": variable_id,
                    "source_file": normalize_upper(row["source_file"]),
                    "source_varnumber": normalize_varnumber(row["source_varnumber"]),
                    "source_varname": normalize_upper(row["source_varname"]),
                    "years_present": row["years_present"],
                    "exact_codebook_years": row["exact_codebook_years"],
                    "missing_codebook_years": missing_years,
                    "candidate_family_id": family_id,
                    "candidate_semantic_type": "not_collapsible",
                    "review_status": "pending_author_review",
                    "review_note": review_note,
                }
            )

    keys = [
        (
            str(row["source_file"]),
            str(row["family_id"]),
            str(row["component_varname"]),
        )
        for row in candidate_rows
    ]
    if len(keys) != len(set(keys)):
        raise CandidateEvidenceError(
            "B06 conservative candidate repeats an exact family component"
        )
    family_ids = [str(row["family_id"]) for row in candidate_rows]
    if len(family_ids) != len(set(family_ids)):
        raise CandidateEvidenceError(
            "B06 conservative candidate family IDs are not one-per-identity"
        )
    candidate_rows.sort(
        key=lambda row: (
            str(row["source_file"]),
            str(row["family_id"]),
            str(row["component_varname"]),
        )
    )
    partial_rows.sort(key=lambda row: str(row["variable_id"]))
    decision_rows.sort(key=lambda row: (str(row["candidate_key"]), str(row["decision_id"])))
    return (
        candidate_rows,
        partial_rows,
        decision_rows,
        {
            "b06_component_count": len(candidate_rows),
            "b06_partial_codebook_count": len(partial_rows),
        },
    )


def validate_runtime_candidates(
    *,
    repo_root: Path,
    analysis_path: Path,
    discrete_path: Path,
    contract_id: str,
) -> tuple[int, int]:
    scripts = repo_root.resolve() / "Scripts"
    if not (scripts / "wide_build_common.py").is_file():
        # Fixture builds use the generator repository's production loader.
        scripts = Path(__file__).resolve().parents[1] / "Scripts"
    sys.path.insert(0, str(scripts))
    try:
        runtime = importlib.import_module("wide_build_common")
        analysis = runtime.load_analysis_schema_contract(
            analysis_path,
            contract_id=contract_id,
        )
        discrete = runtime.load_discrete_family_contract(
            discrete_path,
            contract_id=contract_id,
        )
    except Exception as exc:
        raise CandidateEvidenceError(
            f"runtime contract loader rejected conservative candidates: {exc}"
        ) from exc
    finally:
        sys.path.remove(str(scripts))
    return len(analysis), len(discrete)


def build_package(
    *,
    repo_root: Path,
    review_dir: Path,
    out_dir: Path,
    contract_id: str = PANEL_CONTRACT_ID,
) -> dict[str, int]:
    repo_root = repo_root.resolve()
    review_dir = review_dir.resolve()
    out_dir = out_dir.absolute()
    validate_output_path(repo_root, out_dir)

    b05_path = review_dir / "B05_SOURCE_VARIABLE_DECISIONS.csv"
    b06_path = review_dir / "B06_COMPONENT_DECISIONS.csv"
    evidence_manifest_path = review_dir / "B05_B06_ARTIFACT_MANIFEST.csv"
    b05_rows = read_csv(b05_path, B05_REQUIRED, label="B05 source decisions")
    b06_rows = read_csv(b06_path, B06_REQUIRED, label="B06 component decisions")
    evidence_manifest = read_csv(
        evidence_manifest_path,
        ("path", "byte_size", "sha256"),
        label="B05/B06 evidence artifact manifest",
    )
    verify_manifest_binding(
        b05_path,
        manifest_rows=evidence_manifest,
        label="B05 source decisions",
    )
    verify_manifest_binding(
        b06_path,
        manifest_rows=evidence_manifest,
        label="B06 component decisions",
    )

    b05_years = validate_b05_rows(b05_rows, contract_id=contract_id)
    b05_by_id = {str(row["variable_id"]): row for row in b05_rows}
    validate_b06_rows(
        b06_rows,
        contract_id=contract_id,
        b05_by_id=b05_by_id,
        b05_years=b05_years,
    )
    pre_contracts = canonical_snapshot(repo_root)
    (
        analysis_rows,
        mapping_rows,
        b05_decisions,
        title_drift_rows,
        b05_counts,
    ) = build_b05_candidates(b05_rows)
    (
        discrete_rows,
        partial_rows,
        b06_decisions,
        b06_counts,
    ) = build_b06_candidates(b06_rows)
    decision_rows = sorted(
        [*b05_decisions, *b06_decisions],
        key=lambda row: (
            str(row["phase"]),
            str(row["candidate_key"]),
            str(row["decision_id"]),
        ),
    )

    out_dir.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(
        tempfile.mkdtemp(
            prefix=f".{out_dir.name}.tmp-",
            dir=out_dir.parent,
        )
    )
    try:
        analysis_path = staging / "analysis_schema_candidate.csv"
        discrete_path = staging / "discrete_families_candidate.csv"
        write_csv(analysis_path, ANALYSIS_FIELDS, analysis_rows)
        write_csv(discrete_path, DISCRETE_FIELDS, discrete_rows)
        write_csv(
            staging / "B05_IDENTITY_MAPPING.csv",
            IDENTITY_MAPPING_FIELDS,
            mapping_rows,
        )
        write_csv(
            staging / "B05_TITLE_DRIFT_EXCEPTIONS.csv",
            TITLE_DRIFT_FIELDS,
            title_drift_rows,
        )
        write_csv(
            staging / "B06_PARTIAL_CODEBOOK_CASES.csv",
            PARTIAL_CODEBOOK_FIELDS,
            partial_rows,
        )
        write_csv(
            staging / "B05_B06_CONSERVATIVE_DECISION_REGISTER.csv",
            DECISION_REGISTER_FIELDS,
            decision_rows,
        )

        input_rows = [
            {
                "input_id": "b05_exact_scalar_identity_evidence",
                "path": b05_path.name,
                "byte_size": b05_path.stat().st_size,
                "sha256": sha256_file(b05_path),
                "authority": (
                    "completed exact-identity evidence; supports conservative "
                    "candidate only, not approval"
                ),
            },
            {
                "input_id": "b06_exact_discrete_component_evidence",
                "path": b06_path.name,
                "byte_size": b06_path.stat().st_size,
                "sha256": sha256_file(b06_path),
                "authority": (
                    "completed exact component/codebook evidence; supports "
                    "not_collapsible candidate only, not approval"
                ),
            },
            {
                "input_id": "b05_b06_evidence_artifact_manifest",
                "path": evidence_manifest_path.name,
                "byte_size": evidence_manifest_path.stat().st_size,
                "sha256": sha256_file(evidence_manifest_path),
                "authority": "provenance and integrity binding",
            },
        ]
        input_manifest_path = staging / "B05_B06_INPUT_MANIFEST.csv"
        write_csv(
            input_manifest_path,
            INPUT_MANIFEST_FIELDS,
            input_rows,
        )
        input_manifest_sha256 = sha256_file(input_manifest_path)

        runtime_analysis_rows, runtime_discrete_rows = validate_runtime_candidates(
            repo_root=repo_root,
            analysis_path=analysis_path,
            discrete_path=discrete_path,
            contract_id=contract_id,
        )
        if runtime_analysis_rows != len(analysis_rows):
            raise CandidateEvidenceError(
                "runtime analysis loader changed the candidate row count"
            )
        if runtime_discrete_rows != len(discrete_rows):
            raise CandidateEvidenceError(
                "runtime discrete loader changed the candidate row count"
            )

        post_contracts = canonical_snapshot(repo_root)
        if pre_contracts != post_contracts:
            changed = sorted(
                path
                for path in set(pre_contracts) | set(post_contracts)
                if pre_contracts.get(path) != post_contracts.get(path)
            )
            raise CandidateEvidenceError(
                f"canonical contracts changed during candidate generation: {changed}"
            )
        comparison_rows = [
            {
                "path": path,
                "pre_sha256": pre_contracts[path],
                "post_sha256": post_contracts[path],
                "unchanged": "true",
            }
            for path in sorted(pre_contracts)
        ]
        write_csv(
            staging / "B05_B06_CANONICAL_HASH_COMPARISON.csv",
            CANONICAL_COMPARISON_FIELDS,
            comparison_rows,
        )

        counts: dict[str, int] = {
            **b05_counts,
            **b06_counts,
            "decision_register_row_count": len(decision_rows),
            "runtime_analysis_loader_accepted": 1,
            "runtime_discrete_loader_accepted": 1,
            "canonical_contract_file_count": len(pre_contracts),
        }
        status = "\n".join(
            [
                "# B05/B06 conservative candidate status",
                "",
                "B05_CONSERVATIVE_CANDIDATES_GENERATED",
                "B05_PENDING_AUTHOR_REVIEW",
                "B05_CONTRACT_UNCHANGED",
                "",
                "B06_NOT_COLLAPSIBLE_CANDIDATES_GENERATED",
                "B06_PENDING_AUTHOR_REVIEW",
                "B06_CONTRACT_UNCHANGED",
                "",
                "## Counts",
                "",
                f"- B05 exact scalar source identities: {counts['b05_source_identity_count']}.",
                f"- B05 candidate analysis rows: {counts['b05_candidate_row_count']}.",
                f"- B05 active source identities: {counts['b05_active_identity_count']}.",
                f"- B05 all-null exclusions: {counts['b05_excluded_all_null_identity_count']}.",
                f"- B05 disjoint-year grouped candidates: {counts['b05_grouped_candidate_count']}.",
                f"- B05 identities in those groups: {counts['b05_grouped_identity_count']}.",
                f"- B05 former disjoint-year groups split for official-title drift: {counts['b05_title_drift_group_count']} ({counts['b05_title_drift_identity_count']} identities).",
                f"- B05 identity-level official-title exceptions requiring semantic review: {counts['b05_semantic_title_exception_count']}.",
                f"- B05 conflicting identities deterministically disambiguated: {counts['b05_disambiguated_identity_count']}.",
                f"- B06 exact discrete components retained: {counts['b06_component_count']}.",
                f"- B06 partial-codebook cases kept visible: {counts['b06_partial_codebook_count']}.",
                f"- Pending author decisions: {counts['decision_register_row_count']}.",
                "",
                "Both candidate CSVs were accepted by the production runtime loaders. "
                "Executable rows are active and evidence-proven empty identities are "
                "explicitly excluded_all_null; every scientific decision remains "
                "pending in the decision register.",
                "",
                f"Input manifest SHA-256: `{input_manifest_sha256}`.",
                "",
                "FULL_BUILD_NOT_RUN",
                "RELEASE_STILL_BLOCKED",
                "",
            ]
        )
        (staging / "B05_B06_STATUS.md").write_text(status, encoding="utf-8")

        generator_hash = sha256_file(Path(__file__).resolve())
        manifestable = sorted(
            path
            for path in staging.iterdir()
            if path.is_file() and path.name != "B05_B06_ARTIFACT_MANIFEST.csv"
        )
        artifact_rows = [
            {
                "path": path.name,
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
                "generator_sha256": generator_hash,
                "input_manifest_sha256": input_manifest_sha256,
            }
            for path in manifestable
        ]
        write_csv(
            staging / "B05_B06_ARTIFACT_MANIFEST.csv",
            ARTIFACT_MANIFEST_FIELDS,
            artifact_rows,
        )
        staging.replace(out_dir)
        return counts
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    default_repo = Path(__file__).resolve().parents[1]
    parser.add_argument("--repo-root", type=Path, default=default_repo)
    parser.add_argument(
        "--review-dir",
        type=Path,
        default=default_repo / "Artifacts" / "review_v2" / "b05_b06_review",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=(
            default_repo
            / "Artifacts"
            / "review_v2"
            / "b05_b06_conservative_candidates_2026-07-24"
        ),
    )
    parser.add_argument("--contract-id", default=PANEL_CONTRACT_ID)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    counts = build_package(
        repo_root=args.repo_root,
        review_dir=args.review_dir,
        out_dir=args.out_dir,
        contract_id=args.contract_id,
    )
    print(json.dumps(counts, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
