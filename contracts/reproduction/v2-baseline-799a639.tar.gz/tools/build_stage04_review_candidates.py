#!/usr/bin/env python3
"""Build complete, exact-identity Stage 04 contract candidates for review.

This tool is deliberately review-only.  It reads the completed B03/B04
enriched evidence, preserves already-countersigned canonical rows, emits
evidence-derived candidates for the remaining Stage 04 data inventory, and
keeps genuinely unresolved all-empty source columns visible as ``unknown``.
It has no code path that writes canonical contracts.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import os
import re
import subprocess
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence


REPO_ROOT = Path(__file__).resolve().parents[1]
CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"

TABLE_CANDIDATE_COLUMNS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "grain_class",
    "unit_key_columns",
    "dimension_columns",
    "measure_selection_rule",
    "expected_rows_per_unit",
    "aggregation_policy",
    "source_evidence",
    "review_note",
    "reviewed",
]

SOURCE_CANDIDATE_COLUMNS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "column_name",
    "role",
    "canonical_dimension",
    "exclusion_reason",
    "source_evidence",
    "review_note",
    "reviewed",
]

UNRESOLVED_DECISION_COLUMNS = [
    "decision_id",
    "year",
    "source_file",
    "access_table_name",
    "column_name",
    "nonempty_count",
    "metadata_match_status",
    "unresolved_reason",
    "candidate_role",
    "required_decision",
    "review_status",
    "review_note",
]

INPUT_MANIFEST_COLUMNS = ["input_role", "path", "byte_size", "sha256"]
CANONICAL_HASH_COLUMNS = ["path", "sha256_before", "sha256_after", "unchanged"]
ARTIFACT_MANIFEST_COLUMNS = [
    "path",
    "byte_size",
    "sha256",
    "row_count",
    "artifact_role",
]

REQUIRED_TABLE_EVIDENCE_COLUMNS = {
    "contract_id",
    "year",
    "access_table_name",
    "normalized_table_name",
    "table_role",
    "row_count",
    "has_unitid",
    "distinct_unitid",
    "duplicate_unitid_rows",
    "null_unitid_rows",
    "zero_row_table",
    "source_csv_sha256",
    "source_schema_sha256",
    "declared_key_columns",
    "candidate_dimension_columns",
    "candidate_minimal_key",
    "duplicate_rows_on_candidate_key",
    "null_rows_on_candidate_key",
    "candidate_key_test_status",
    "candidate_grain",
    "table_metadata_match_status",
    "matched_access_table_name",
    "matched_table_metadata_row_count",
}

REQUIRED_SOURCE_EVIDENCE_COLUMNS = {
    "contract_id",
    "year",
    "access_table_name",
    "normalized_table_name",
    "table_role",
    "candidate_table_grain",
    "ordinal_position",
    "column_name",
    "source_csv_sha256",
    "nonempty_count",
    "column_metadata_match_status",
    "matched_file_number",
    "matched_varnumber",
    "matched_varname",
    "matched_metadata_table_name",
    "matched_metadata_source",
    "matched_metadata_row_count",
    "metadata_join_reason",
    "candidate_role",
    "role_evidence",
    "role_decision_id",
    "role_decision_source",
    "role_decision_justification",
    "unresolved_reason",
}

ROLE_TRANSLATIONS = {
    "identifier": "identifier",
    "dimension": "dimension",
    "measure_candidate": "measure",
    "imputation_field": "imputation",
    "administrative_field": "metadata",
    "metadata_field": "metadata",
    "intentionally_excluded": "excluded",
    "unresolved": "unknown",
}

SAL2009_IDENTITY = (2009, "SAL_A_LT", "SAL2009_A_LT9")
SAL2009_KEY = ("UNITID", "ARANK")
WILDCARD_CHARACTERS = frozenset("*?[")
GIT_COMMIT_PATTERN = re.compile(r"^[0-9a-f]{40}$")
SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")


class CandidateBuildError(ValueError):
    """The evidence cannot safely produce complete Stage 04 candidates."""


class BuildResult:
    """Paths and inventory counts from one deterministic candidate build."""

    def __init__(
        self,
        *,
        table_candidate_path: Path,
        source_candidate_path: Path,
        unresolved_decision_path: Path,
        input_manifest_path: Path,
        canonical_hash_path: Path,
        summary_path: Path,
        manifest_path: Path,
        table_count: int,
        source_column_count: int,
        unresolved_count: int,
        reviewed_table_count: int,
        reviewed_source_column_count: int,
    ) -> None:
        self.table_candidate_path = table_candidate_path
        self.source_candidate_path = source_candidate_path
        self.unresolved_decision_path = unresolved_decision_path
        self.input_manifest_path = input_manifest_path
        self.canonical_hash_path = canonical_hash_path
        self.summary_path = summary_path
        self.manifest_path = manifest_path
        self.table_count = table_count
        self.source_column_count = source_column_count
        self.unresolved_count = unresolved_count
        self.reviewed_table_count = reviewed_table_count
        self.reviewed_source_column_count = reviewed_source_column_count
        self.release_ready = (
            unresolved_count == 0
            and reviewed_table_count == table_count
            and reviewed_source_column_count == source_column_count
        )


def fail(message: str) -> None:
    raise CandidateBuildError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv(
    path: Path,
    *,
    required_columns: Iterable[str] = (),
    label: str | None = None,
) -> tuple[list[str], list[dict[str, str]]]:
    if not path.is_file():
        fail(f"{label or path.name} does not exist: {path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fieldnames = list(reader.fieldnames or [])
        rows = [
            {key: str(value or "").strip() for key, value in row.items()}
            for row in reader
        ]
    missing = sorted(set(required_columns) - set(fieldnames))
    if missing:
        fail(f"{label or path.name} is missing columns: {', '.join(missing)}")
    return fieldnames, rows


def parse_nonnegative_int(value: str, *, label: str) -> int:
    try:
        parsed = int(str(value).strip())
    except ValueError:
        fail(f"{label} is not an integer: {value!r}")
    if parsed < 0:
        fail(f"{label} must be nonnegative")
    return parsed


def split_key(value: str) -> tuple[str, ...]:
    return tuple(
        part.strip().upper()
        for part in str(value or "").split("|")
        if part.strip()
    )


def bool_value(value: str) -> bool:
    return str(value or "").strip().casefold() in {"1", "true", "yes", "approved"}


def stable_decision_id(prefix: str, *identity_parts: object) -> str:
    identity = "|".join(str(part).strip().upper() for part in identity_parts)
    suffix = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:12].upper()
    return f"{prefix}-{suffix}"


def exact_identity_text(*parts: object) -> str:
    return ":".join(str(part).strip() for part in parts)


def ensure_exact_identity(value: str, *, label: str) -> None:
    if not value:
        fail(f"{label} is blank")
    wildcard = sorted(WILDCARD_CHARACTERS.intersection(value))
    if wildcard:
        fail(
            f"{label} contains fnmatch wildcard characters and is not exact: "
            + "".join(wildcard)
        )


def _write_csv_atomic(
    path: Path,
    fieldnames: Sequence[str],
    rows: Iterable[dict[str, object]],
) -> None:
    pending = path.with_name(path.name + ".tmp")
    with pending.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fieldnames),
            extrasaction="raise",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)
    os.replace(pending, path)


def _write_text_atomic(path: Path, value: str) -> None:
    pending = path.with_name(path.name + ".tmp")
    pending.write_text(value, encoding="utf-8")
    os.replace(pending, path)


@dataclass(frozen=True)
class CanonicalSelector:
    """One reviewed canonical selector resolved only against exact evidence."""

    row_number: int
    row: dict[str, str]
    year_start: int
    year_end: int
    source_file: str
    table_pattern: str
    column_name: str | None

    @property
    def decision_id(self) -> str:
        return self.row["decision_id"]

    def matches(self, identity: tuple[object, ...]) -> bool:
        year = int(identity[0])
        source_file = str(identity[1]).upper()
        table = str(identity[2]).upper()
        column = str(identity[3]).upper() if len(identity) == 4 else None
        return (
            self.year_start <= year <= self.year_end
            and source_file == self.source_file
            and self.table_pattern in {"*", table}
            and column == self.column_name
        )

    def overlaps(self, other: "CanonicalSelector") -> bool:
        years_overlap = not (
            self.year_end < other.year_start
            or other.year_end < self.year_start
        )
        tables_overlap = (
            self.table_pattern == "*"
            or other.table_pattern == "*"
            or self.table_pattern == other.table_pattern
        )
        return (
            years_overlap
            and self.source_file == other.source_file
            and self.column_name == other.column_name
            and tables_overlap
        )

    def expand(self, identity: tuple[object, ...]) -> dict[str, str]:
        """Return the reviewed semantics scoped to one exact evidence row."""

        year = str(int(identity[0]))
        expanded = dict(self.row)
        expanded["year_start"] = year
        expanded["year_end"] = year
        expanded["source_file"] = str(identity[1]).upper()
        expanded["access_table_pattern"] = str(identity[2]).upper()
        if self.column_name is not None:
            expanded["column_name"] = str(identity[3]).upper()
        return expanded


class CanonicalIndex:
    """Deterministic, fail-closed canonical selector matcher."""

    def __init__(
        self,
        *,
        label: str,
        selectors: Sequence[CanonicalSelector],
    ) -> None:
        self.label = label
        self.selectors = tuple(selectors)
        self._matched_row_numbers: set[int] = set()

    def resolve(
        self,
        identity: tuple[object, ...],
    ) -> dict[str, str] | None:
        matches = [
            selector
            for selector in self.selectors
            if selector.matches(identity)
        ]
        if len(matches) > 1:
            decisions = ", ".join(
                selector.decision_id for selector in matches
            )
            fail(
                f"{self.label} has overlapping reviewed selectors for exact "
                f"evidence identity {identity}: {decisions}"
            )
        if not matches:
            return None
        selected = matches[0]
        self._matched_row_numbers.add(selected.row_number)
        return selected.expand(identity)

    def unmatched(self) -> tuple[CanonicalSelector, ...]:
        return tuple(
            selector
            for selector in self.selectors
            if selector.row_number not in self._matched_row_numbers
        )


def _canonical_selector(
    row: dict[str, str],
    *,
    row_number: int,
    include_column: bool,
    label: str,
) -> CanonicalSelector:
    start = parse_nonnegative_int(row.get("year_start", ""), label=f"{label} year_start")
    end = parse_nonnegative_int(row.get("year_end", ""), label=f"{label} year_end")
    if start > end:
        fail(f"{label} has a descending year range: {start}:{end}")
    source_file = row.get("source_file", "").upper()
    table = row.get("access_table_pattern", "").upper()
    ensure_exact_identity(source_file, label=f"{label} source_file")
    if table != "*":
        ensure_exact_identity(table, label=f"{label} access_table_pattern")
    if not row.get("decision_id", ""):
        fail(f"{label} decision_id is blank")
    column: str | None = None
    if include_column:
        column = row.get("column_name", "").upper()
        ensure_exact_identity(column, label=f"{label} column_name")
    return CanonicalSelector(
        row_number=row_number,
        row=row,
        year_start=start,
        year_end=end,
        source_file=source_file,
        table_pattern=table,
        column_name=column,
    )


def load_canonical_rows(
    path: Path,
    *,
    fieldnames: Sequence[str],
    include_column: bool,
    label: str,
) -> tuple[list[dict[str, str]], CanonicalIndex]:
    observed_fields, rows = read_csv(path, required_columns=fieldnames, label=label)
    if observed_fields != list(fieldnames):
        fail(f"{label} column order differs from the Stage 04 runtime contract")
    selectors: list[CanonicalSelector] = []
    for row_number, row in enumerate(rows, start=2):
        if row["contract_id"] != CONTRACT_ID:
            fail(f"{label} row {row_number} has a different contract_id")
        if not bool_value(row["reviewed"]):
            fail(f"{label} row {row_number} is not reviewed")
        selector = _canonical_selector(
            row,
            row_number=row_number,
            include_column=include_column,
            label=f"{label} row {row_number}",
        )
        for previous in selectors:
            if selector.overlaps(previous):
                fail(
                    f"{label} has overlapping reviewed selectors "
                    f"{previous.decision_id} (row {previous.row_number}) and "
                    f"{selector.decision_id} (row {selector.row_number})"
                )
        selectors.append(selector)
    return rows, CanonicalIndex(label=label, selectors=selectors)


def verify_upstream_artifact_manifest(
    artifact_manifest_path: Path,
    input_paths: Sequence[Path],
) -> Path:
    _, manifest_rows = read_csv(
        artifact_manifest_path,
        required_columns={
            "path",
            "byte_size",
            "sha256",
            "generator_commit",
            "input_manifest_sha256",
        },
        label="upstream artifact manifest",
    )
    if not manifest_rows:
        fail("upstream artifact manifest is empty")
    generator_commits = {
        row["generator_commit"].strip().casefold() for row in manifest_rows
    }
    input_manifest_hashes = {
        row["input_manifest_sha256"].strip().casefold() for row in manifest_rows
    }
    if len(generator_commits) != 1 or not GIT_COMMIT_PATTERN.fullmatch(
        next(iter(generator_commits), "")
    ):
        fail(
            "upstream artifact manifest must carry one valid 40-hex "
            "generator_commit"
        )
    if len(input_manifest_hashes) != 1 or not SHA256_PATTERN.fullmatch(
        next(iter(input_manifest_hashes), "")
    ):
        fail(
            "upstream artifact manifest must carry one valid 64-hex "
            "input_manifest_sha256"
        )
    expected_input_manifest_hash = next(iter(input_manifest_hashes))
    upstream_input_manifest_path = (
        artifact_manifest_path.parent / "input_evidence_manifest.csv"
    )
    if (
        not upstream_input_manifest_path.is_file()
        or sha256_file(upstream_input_manifest_path)
        != expected_input_manifest_hash
    ):
        observed = (
            sha256_file(upstream_input_manifest_path)
            if upstream_input_manifest_path.is_file()
            else "<missing>"
        )
        fail(
            "upstream input manifest binding failed: "
            f"expected={expected_input_manifest_hash} observed={observed}"
        )
    generator_commit = next(iter(generator_commits))
    commit_check = subprocess.run(
        ["git", "cat-file", "-e", f"{generator_commit}^{{commit}}"],
        cwd=REPO_ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        check=False,
    )
    if commit_check.returncode != 0:
        fail(
            "upstream generator_commit is unavailable in this repository: "
            f"{generator_commit}"
        )
    _, upstream_input_rows = read_csv(
        upstream_input_manifest_path,
        required_columns={"source_scope", "path", "sha256"},
        label="upstream input manifest",
    )
    generator_rows = [
        row
        for row in upstream_input_rows
        if row["source_scope"].strip().casefold() == "generator"
    ]
    if not generator_rows:
        fail("upstream input manifest contains no generator provenance rows")
    for row in generator_rows:
        relative_path = Path(row["path"])
        expected_hash = row["sha256"].strip().casefold()
        if (
            relative_path.is_absolute()
            or ".." in relative_path.parts
            or not SHA256_PATTERN.fullmatch(expected_hash)
        ):
            fail(
                "upstream input manifest has an invalid generator provenance row: "
                f"{row['path']!r}"
            )
        blob = subprocess.run(
            ["git", "show", f"{generator_commit}:{relative_path.as_posix()}"],
            cwd=REPO_ROOT,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            check=False,
        )
        observed_hash = (
            hashlib.sha256(blob.stdout).hexdigest()
            if blob.returncode == 0
            else "<missing>"
        )
        if observed_hash != expected_hash:
            fail(
                "upstream generator commit binding failed for "
                f"{relative_path.as_posix()}: expected={expected_hash} "
                f"observed={observed_hash}"
            )
    by_name: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in manifest_rows:
        by_name[Path(row["path"]).name].append(row)
    for path in input_paths:
        matches = by_name.get(path.name, [])
        if len(matches) != 1:
            fail(
                "upstream artifact manifest must contain one row for "
                f"{path.name}; observed={len(matches)}"
            )
        match = matches[0]
        expected_size = parse_nonnegative_int(
            match["byte_size"], label=f"manifest byte_size for {path.name}"
        )
        observed_size = path.stat().st_size
        observed_hash = sha256_file(path)
        if expected_size != observed_size or match["sha256"].lower() != observed_hash:
            fail(
                f"upstream artifact binding failed for {path.name}: "
                f"size={observed_size}/{expected_size} "
                f"sha256={observed_hash}/{match['sha256'].lower()}"
            )
    return upstream_input_manifest_path


def validate_table_evidence(
    rows: list[dict[str, str]],
) -> tuple[list[dict[str, str]], dict[tuple[int, str], dict[str, str]]]:
    data_rows = [row for row in rows if row["table_role"].casefold() == "data"]
    if not data_rows:
        fail("table evidence contains no Stage 04 data tables")
    output: list[dict[str, str]] = []
    by_identity: dict[tuple[int, str], dict[str, str]] = {}
    for row in data_rows:
        year = parse_nonnegative_int(
            row["year"],
            label=f"table evidence year for {row.get('access_table_name') or '<blank>'}",
        )
        table = row["access_table_name"].upper()
        source_file = row["normalized_table_name"].upper()
        identity_label = exact_identity_text(year, table)
        ensure_exact_identity(table, label=f"{identity_label} access_table_name")
        ensure_exact_identity(source_file, label=f"{identity_label} normalized_table_name")
        identity = (year, table)
        if identity in by_identity:
            fail(f"duplicate table evidence identity: {identity_label}")
        if row["contract_id"] != CONTRACT_ID:
            fail(f"{identity_label} has a different contract_id")
        if not bool_value(row["has_unitid"]):
            fail(f"{identity_label} is a data table without UNITID")
        if row["table_metadata_match_status"] != "exact":
            fail(f"{identity_label} lacks an exact table metadata identity")
        if row["matched_access_table_name"].upper() != table:
            fail(f"{identity_label} matched table identity is not exact")
        if parse_nonnegative_int(
            row["matched_table_metadata_row_count"],
            label=f"{identity_label} matched metadata row count",
        ) != 1:
            fail(f"{identity_label} does not have exactly one table metadata row")
        row_count = parse_nonnegative_int(
            row["row_count"], label=f"{identity_label} row_count"
        )
        zero_row = bool_value(row["zero_row_table"])
        if zero_row != (row_count == 0):
            fail(f"{identity_label} zero-row flag conflicts with row_count")
        if not row["source_csv_sha256"] or not row["source_schema_sha256"]:
            fail(f"{identity_label} lacks source CSV or schema hash")

        grain = row["candidate_grain"].casefold()
        key = split_key(row["candidate_minimal_key"])
        dimensions = split_key(row["candidate_dimension_columns"])
        if len(key) != len(set(key)) or len(dimensions) != len(set(dimensions)):
            fail(f"{identity_label} has duplicate key or dimension tokens")
        if row_count == 0:
            if (year, source_file, table) != SAL2009_IDENTITY:
                fail(f"unreviewed zero-row data table is not supported: {identity_label}")
            if (
                row["candidate_key_test_status"] != "zero_row_untestable"
                or key != SAL2009_KEY
                or dimensions != ("ARANK",)
            ):
                fail(f"{identity_label} does not match the countersigned intended schema")
        else:
            key_status = row["candidate_key_test_status"]
            observed_scalar = (
                grain == "scalar"
                and key_status == ""
                and parse_nonnegative_int(
                    row["distinct_unitid"],
                    label=f"{identity_label} distinct UNITID count",
                )
                == row_count
                and parse_nonnegative_int(
                    row["duplicate_unitid_rows"],
                    label=f"{identity_label} duplicate UNITID rows",
                )
                == 0
                and parse_nonnegative_int(
                    row["null_unitid_rows"],
                    label=f"{identity_label} null UNITID rows",
                )
                == 0
            )
            if key_status != "proven_complete" and not observed_scalar:
                fail(f"{identity_label} lacks a proven complete key")
            if key_status == "proven_complete":
                if parse_nonnegative_int(
                    row["duplicate_rows_on_candidate_key"],
                    label=f"{identity_label} duplicate candidate-key rows",
                ) != 0:
                    fail(f"{identity_label} candidate key has duplicate rows")
                if parse_nonnegative_int(
                    row["null_rows_on_candidate_key"],
                    label=f"{identity_label} null candidate-key rows",
                ) != 0:
                    fail(f"{identity_label} candidate key has null or blank components")
            if grain == "scalar":
                if key_status == "proven_complete" and key != ("UNITID",):
                    fail(f"{identity_label} proven scalar key is not exactly UNITID")
                if key not in {(), ("UNITID",)} or dimensions:
                    fail(f"{identity_label} scalar key is not exactly UNITID")
            elif grain == "dimensioned":
                key_dimensions = tuple(part for part in key if part != "UNITID")
                if (
                    not dimensions
                    or key.count("UNITID") != 1
                    or len(key_dimensions) != len(set(key_dimensions))
                    or set(key_dimensions) != set(dimensions)
                ):
                    fail(f"{identity_label} dimensioned key is internally inconsistent")
            else:
                fail(f"{identity_label} has unsupported candidate grain {grain!r}")
        by_identity[identity] = row
        output.append(row)
    output.sort(key=lambda row: (int(row["year"]), row["access_table_name"].upper()))
    return output, by_identity


def _table_candidate_from_evidence(
    row: dict[str, str],
    *,
    reviewed_index: CanonicalIndex,
) -> dict[str, str]:
    year = int(row["year"])
    table = row["access_table_name"].upper()
    source_file = row["normalized_table_name"].upper()
    is_sal2009 = (year, source_file, table) == SAL2009_IDENTITY
    if is_sal2009:
        grain = "dimensioned"
        key_parts = SAL2009_KEY
        key_dimensions = ("ARANK",)
    else:
        grain = row["candidate_grain"].casefold()
        observed_key_parts = split_key(row["candidate_minimal_key"])
        key_dimensions = tuple(
            part for part in observed_key_parts if part != "UNITID"
        )
        key_parts = ("UNITID", *key_dimensions)
    key = "|".join(key_parts)
    dimensions = "|".join(key_dimensions)
    canonical = reviewed_index.resolve((year, source_file, table))
    if canonical is not None:
        semantics_match = (
            canonical["grain_class"].casefold() == grain
            and split_key(canonical["unit_key_columns"]) == key_parts
            and split_key(canonical["dimension_columns"]) == key_dimensions
            and canonical["measure_selection_rule"].casefold()
            == "source_columns_contract"
            and canonical["expected_rows_per_unit"].casefold()
            == ("1" if grain == "scalar" else "many")
            and canonical["aggregation_policy"].casefold()
            == "exact_duplicate_only"
            and bool(canonical["source_evidence"])
            and bool(canonical["review_note"])
        )
        if not semantics_match:
            fail(f"reviewed table contract conflicts with enriched evidence: {year}:{table}")
        return {field: canonical[field] for field in TABLE_CANDIDATE_COLUMNS}
    if is_sal2009:
        fail(
            "SAL2009_A_LT9 requires a countersigned exact-evidence "
            "table-grain contract row"
        )
    key_evidence = (
        "observed UNITID uniqueness with zero duplicate and zero null UNITID rows"
        if row["candidate_key_test_status"] == ""
        else f"candidate key {key} has zero duplicate rows and zero null/blank key rows"
    )
    evidence = (
        "Completed B03 enriched evidence; exact source identity "
        f"{year}:{table}; source CSV SHA-256 {row['source_csv_sha256']}; "
        f"source schema SHA-256 {row['source_schema_sha256']}; "
        f"{key_evidence}."
    )
    return {
        "contract_id": CONTRACT_ID,
        "decision_id": stable_decision_id("B03-CAND", year, source_file, table),
        "year_start": str(year),
        "year_end": str(year),
        "source_file": source_file,
        "access_table_pattern": table,
        "grain_class": grain,
        "unit_key_columns": key,
        "dimension_columns": dimensions,
        "measure_selection_rule": "source_columns_contract",
        "expected_rows_per_unit": "1" if grain == "scalar" else "many",
        "aggregation_policy": "exact_duplicate_only",
        "source_evidence": evidence,
        "review_note": (
            "Review-only evidence-derived exact-identity candidate; requires "
            "author review before canonical use."
        ),
        "reviewed": "false",
    }


def _source_evidence_text(row: dict[str, str]) -> str:
    year = row["year"]
    table = row["access_table_name"].upper()
    column = row["column_name"].upper()
    pieces = [
        "Completed B04 enriched evidence",
        f"exact source identity {year}:{table}:{column}",
        f"source CSV SHA-256 {row['source_csv_sha256']}",
        f"nonempty_count={row['nonempty_count']}",
        f"metadata_match_status={row['column_metadata_match_status']}",
    ]
    if row["matched_varnumber"]:
        pieces.append(f"matched VarNumber={row['matched_varnumber']}")
    if row["matched_varname"]:
        pieces.append(f"matched VarName={row['matched_varname']}")
    if row["matched_metadata_source"]:
        pieces.append(f"metadata source={row['matched_metadata_source']}")
    if row["role_evidence"]:
        pieces.append(f"role evidence={row['role_evidence']}")
    return "; ".join(pieces) + "."


def _sal2009_source_role(row: dict[str, str]) -> str:
    column = row["column_name"].upper()
    if column == "UNITID":
        return "identifier"
    if column == "ARANK":
        return "dimension"
    if (
        row["candidate_role"] == "unresolved"
        and row["unresolved_reason"] == "table_grain_unresolved"
        and row["column_metadata_match_status"] == "exact"
        and parse_nonnegative_int(
            row["matched_metadata_row_count"],
            label=f"SAL2009_A_LT9.{column} matched metadata row count",
        )
        == 1
    ):
        return "measure"
    fail(f"countersigned SAL2009 intended grain cannot classify {column}")
    raise AssertionError("unreachable")


def _source_candidate_from_evidence(
    row: dict[str, str],
    *,
    table_row: dict[str, str],
    reviewed_index: CanonicalIndex,
) -> tuple[dict[str, str], dict[str, str] | None]:
    year = int(row["year"])
    table = row["access_table_name"].upper()
    source_file = row["normalized_table_name"].upper()
    column = row["column_name"].upper()
    identity = (year, source_file, table, column)
    if (year, source_file, table) == SAL2009_IDENTITY:
        role = _sal2009_source_role(row)
    else:
        try:
            role = ROLE_TRANSLATIONS[row["candidate_role"]]
        except KeyError:
            fail(
                f"unsupported candidate source role {row['candidate_role']!r} "
                f"for {year}:{table}.{column}"
            )
    nonempty_count = parse_nonnegative_int(
        row["nonempty_count"], label=f"{year}:{table}.{column} nonempty_count"
    )
    canonical = reviewed_index.resolve(identity)
    if canonical is not None:
        canonical_role = canonical["role"].casefold()
        reviewed_all_empty_exclusion = (
            canonical_role == "excluded"
            and role == "unknown"
            and nonempty_count == 0
        )
        semantics_role_match = (
            canonical_role == role and role != "unknown"
        ) or reviewed_all_empty_exclusion
        semantics_match = (
            semantics_role_match
            and (
                canonical["canonical_dimension"].upper() == column
                if canonical_role == "dimension"
                else not canonical["canonical_dimension"]
            )
            and (
                bool(canonical["exclusion_reason"])
                if canonical_role == "excluded"
                else not canonical["exclusion_reason"]
            )
            and bool(canonical["source_evidence"])
            and bool(canonical["review_note"])
        )
        if not semantics_match:
            fail(
                "reviewed source-column contract conflicts with enriched evidence: "
                f"{year}:{table}.{column}"
            )
        return (
            {field: canonical[field] for field in SOURCE_CANDIDATE_COLUMNS},
            None,
        )
    unresolved: dict[str, str] | None = None
    decision_id = stable_decision_id("B04-CAND", year, source_file, table, column)
    review_note = (
        "Review-only evidence-derived exact-identity candidate; requires "
        "author review before canonical use."
    )
    if role == "unknown":
        if nonempty_count:
            fail(f"nonempty unresolved source column: {year}:{table}.{column}")
        decision_id = stable_decision_id(
            "B04-EMPTY", year, source_file, table, column
        )
        review_note = (
            "All source values are empty and exact source metadata is absent; "
            "no semantic role was inferred."
        )
        unresolved = {
            "decision_id": decision_id,
            "year": str(year),
            "source_file": source_file,
            "access_table_name": table,
            "column_name": column,
            "nonempty_count": str(nonempty_count),
            "metadata_match_status": row["column_metadata_match_status"],
            "unresolved_reason": row["unresolved_reason"],
            "candidate_role": "unknown",
            "required_decision": (
                "retain_unresolved|classify_metadata|classify_measure|"
                "intentionally_exclude"
            ),
            "review_status": "unresolved",
            "review_note": review_note,
        }
    if role in {"measure", "dimension"} and (
        row["column_metadata_match_status"] != "exact"
        or parse_nonnegative_int(
            row["matched_metadata_row_count"],
            label=f"{year}:{table}.{column} matched metadata row count",
        )
        != 1
    ):
        fail(
            f"unreviewed {role} candidate lacks one exact metadata row: "
            f"{year}:{table}.{column}"
        )
    if role == "identifier" and column != "UNITID":
        fail(f"non-UNITID identifier candidate: {year}:{table}.{column}")
    dimensions = set(split_key(table_row["candidate_dimension_columns"]))
    canonical_dimension = column if role == "dimension" else ""
    if role == "dimension" and column not in dimensions:
        fail(f"dimension candidate is absent from table key: {year}:{table}.{column}")
    exclusion_reason = ""
    if role == "excluded":
        exclusion_reason = row["role_decision_justification"]
        if not exclusion_reason:
            fail(f"excluded candidate lacks a reviewed reason: {year}:{table}.{column}")
    return (
        {
            "contract_id": CONTRACT_ID,
            "decision_id": decision_id,
            "year_start": str(year),
            "year_end": str(year),
            "source_file": source_file,
            "access_table_pattern": table,
            "column_name": column,
            "role": role,
            "canonical_dimension": canonical_dimension,
            "exclusion_reason": exclusion_reason,
            "source_evidence": _source_evidence_text(row),
            "review_note": review_note,
            "reviewed": "false",
        },
        unresolved,
    )


def validate_source_evidence_and_build(
    rows: list[dict[str, str]],
    *,
    table_by_identity: dict[tuple[int, str], dict[str, str]],
    reviewed_index: CanonicalIndex,
) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    data_rows = [row for row in rows if row["table_role"].casefold() == "data"]
    if not data_rows:
        fail("source-column evidence contains no Stage 04 data columns")
    data_rows.sort(
        key=lambda row: (
            int(row["year"]),
            row["access_table_name"].upper(),
            int(row["ordinal_position"]),
            row["column_name"].upper(),
        )
    )
    candidates: list[dict[str, str]] = []
    unresolved: list[dict[str, str]] = []
    observed: set[tuple[object, ...]] = set()
    ordinals: dict[tuple[int, str], set[int]] = defaultdict(set)
    roles_by_table: dict[tuple[int, str], dict[str, str]] = defaultdict(dict)
    for row in data_rows:
        year = parse_nonnegative_int(
            row["year"],
            label=f"source evidence year for {row.get('access_table_name') or '<blank>'}",
        )
        table = row["access_table_name"].upper()
        source_file = row["normalized_table_name"].upper()
        column = row["column_name"].upper()
        identity_label = exact_identity_text(year, table, column)
        ensure_exact_identity(table, label=f"{identity_label} access_table_name")
        ensure_exact_identity(source_file, label=f"{identity_label} normalized_table_name")
        ensure_exact_identity(column, label=f"{identity_label} column_name")
        identity = (year, source_file, table, column)
        if identity in observed:
            fail(f"duplicate source-column evidence identity: {identity_label}")
        observed.add(identity)
        if row["contract_id"] != CONTRACT_ID:
            fail(f"{identity_label} has a different contract_id")
        table_row = table_by_identity.get((year, table))
        if table_row is None:
            fail(f"{identity_label} has no matching Stage 04 table evidence")
        if table_row["normalized_table_name"].upper() != source_file:
            fail(f"{identity_label} normalized table identity conflicts with B03 evidence")
        if table_row["source_csv_sha256"] != row["source_csv_sha256"]:
            fail(f"{identity_label} source CSV hash conflicts with B03 evidence")
        b03_grain = table_row["candidate_grain"].casefold()
        source_grain = row["candidate_table_grain"].casefold()
        sal2009_identity = (year, source_file, table) == SAL2009_IDENTITY
        grain_agrees = source_grain == b03_grain
        if sal2009_identity and b03_grain == "unknown":
            grain_agrees = source_grain in {"unknown", "dimensioned"}
        if not grain_agrees:
            fail(
                f"{identity_label} source table grain conflicts with B03 evidence: "
                f"source={source_grain!r} b03={b03_grain!r}"
            )
        ordinal = parse_nonnegative_int(
            row["ordinal_position"], label=f"{identity_label} ordinal_position"
        )
        if ordinal == 0 or ordinal in ordinals[(year, table)]:
            fail(f"{identity_label} has a duplicate or zero ordinal position")
        ordinals[(year, table)].add(ordinal)
        candidate, decision = _source_candidate_from_evidence(
            row,
            table_row=table_row,
            reviewed_index=reviewed_index,
        )
        candidates.append(candidate)
        roles_by_table[(year, table)][column] = candidate["role"]
        if decision is not None:
            unresolved.append(decision)
    missing_tables = sorted(set(table_by_identity) - set(roles_by_table))
    if missing_tables:
        fail(f"Stage 04 tables lack source-column evidence: {missing_tables[:5]}")
    for (year, table), table_row in sorted(table_by_identity.items()):
        roles = roles_by_table[(year, table)]
        if roles.get("UNITID") != "identifier":
            fail(f"{year}:{table} does not have exactly one UNITID identifier")
        dimensions = set(split_key(table_row["candidate_dimension_columns"]))
        if (year, table) == (SAL2009_IDENTITY[0], SAL2009_IDENTITY[2]):
            dimensions = {"ARANK"}
        classified_dimensions = {
            column for column, role in roles.items() if role == "dimension"
        }
        if classified_dimensions != dimensions:
            fail(
                f"{year}:{table} table/source dimension mismatch: "
                f"table={sorted(dimensions)} columns={sorted(classified_dimensions)}"
            )
        if not any(role == "measure" for role in roles.values()):
            fail(f"{year}:{table} has no evidence-backed measure candidate")
    unresolved.sort(
        key=lambda row: (
            int(row["year"]),
            row["access_table_name"],
            row["column_name"],
        )
    )
    return candidates, unresolved


def _artifact_row_count(path: Path) -> int:
    if path.suffix.casefold() != ".csv":
        return 0
    with path.open(newline="", encoding="utf-8") as handle:
        return max(sum(1 for _ in csv.reader(handle)) - 1, 0)


def _format_counts(values: Iterable[str]) -> str:
    counts = Counter(values)
    return ", ".join(f"{key}={counts[key]}" for key in sorted(counts))


def build_candidates(
    *,
    table_evidence_path: Path,
    source_evidence_path: Path,
    output_dir: Path,
    canonical_table_path: Path | None = None,
    canonical_source_path: Path | None = None,
    artifact_manifest_path: Path | None = None,
    expected_table_count: int | None = None,
    expected_source_column_count: int | None = None,
    expected_years: set[int] | None = None,
    require_all_canonical_rows: bool = False,
) -> BuildResult:
    """Build candidates without mutating either canonical contract."""
    table_evidence_path = Path(table_evidence_path)
    source_evidence_path = Path(source_evidence_path)
    output_dir = Path(output_dir)
    canonical_table_path = Path(
        canonical_table_path or REPO_ROOT / "contracts" / "table_grain.csv"
    )
    canonical_source_path = Path(
        canonical_source_path or REPO_ROOT / "contracts" / "source_columns.csv"
    )
    if output_dir.resolve() == (REPO_ROOT / "contracts").resolve():
        fail("review candidates may not be written into the canonical contracts directory")

    input_paths = [
        table_evidence_path,
        source_evidence_path,
        canonical_table_path,
        canonical_source_path,
    ]
    for path in input_paths:
        if not path.is_file():
            fail(f"required input does not exist: {path}")
    if artifact_manifest_path is None:
        sibling = table_evidence_path.parent / "B03_B04_artifact_manifest.csv"
        artifact_manifest_path = sibling if sibling.is_file() else None
    upstream_input_manifest_path: Path | None = None
    if artifact_manifest_path is not None:
        artifact_manifest_path = Path(artifact_manifest_path)
        upstream_input_manifest_path = verify_upstream_artifact_manifest(
            artifact_manifest_path, [table_evidence_path, source_evidence_path]
        )
        input_paths.append(artifact_manifest_path)
        input_paths.append(upstream_input_manifest_path)

    canonical_before = {
        canonical_table_path: sha256_file(canonical_table_path),
        canonical_source_path: sha256_file(canonical_source_path),
    }
    _, reviewed_table_index = load_canonical_rows(
        canonical_table_path,
        fieldnames=TABLE_CANDIDATE_COLUMNS,
        include_column=False,
        label="canonical table-grain contract",
    )
    _, reviewed_source_index = load_canonical_rows(
        canonical_source_path,
        fieldnames=SOURCE_CANDIDATE_COLUMNS,
        include_column=True,
        label="canonical source-column contract",
    )
    _, table_rows = read_csv(
        table_evidence_path,
        required_columns=REQUIRED_TABLE_EVIDENCE_COLUMNS,
        label="B03 table evidence",
    )
    _, source_rows = read_csv(
        source_evidence_path,
        required_columns=REQUIRED_SOURCE_EVIDENCE_COLUMNS,
        label="B04 source-column evidence",
    )
    data_tables, table_by_identity = validate_table_evidence(table_rows)
    table_candidates = [
        _table_candidate_from_evidence(
            row, reviewed_index=reviewed_table_index
        )
        for row in data_tables
    ]
    source_candidates, unresolved = validate_source_evidence_and_build(
        source_rows,
        table_by_identity=table_by_identity,
        reviewed_index=reviewed_source_index,
    )

    if require_all_canonical_rows:
        missing_table_contracts = reviewed_table_index.unmatched()
        missing_source_contracts = reviewed_source_index.unmatched()
        if missing_table_contracts or missing_source_contracts:
            fail(
                "completed evidence does not cover all canonical B03/B04 rows: "
                f"table_missing={len(missing_table_contracts)} "
                f"source_missing={len(missing_source_contracts)}"
            )

    observed_years = {int(row["year"]) for row in data_tables}
    if expected_years is not None and observed_years != set(expected_years):
        fail(
            "Stage 04 evidence year coverage differs: "
            f"expected={sorted(expected_years)} observed={sorted(observed_years)}"
        )
    if expected_table_count is not None and len(table_candidates) != expected_table_count:
        fail(
            "Stage 04 table count differs: "
            f"expected={expected_table_count} observed={len(table_candidates)}"
        )
    if (
        expected_source_column_count is not None
        and len(source_candidates) != expected_source_column_count
    ):
        fail(
            "Stage 04 source-column count differs: "
            f"expected={expected_source_column_count} observed={len(source_candidates)}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    table_candidate_path = output_dir / "table_grain_stage04_candidate.csv"
    source_candidate_path = output_dir / "source_columns_stage04_candidate.csv"
    unresolved_decision_path = output_dir / "stage04_unresolved_decisions.csv"
    input_manifest_path = output_dir / "STAGE04_CANDIDATE_INPUT_MANIFEST.csv"
    canonical_hash_path = output_dir / "STAGE04_CANONICAL_HASH_COMPARISON.csv"
    summary_path = output_dir / "STAGE04_CANDIDATE_SUMMARY.md"
    manifest_path = output_dir / "STAGE04_CANDIDATE_ARTIFACT_MANIFEST.csv"

    _write_csv_atomic(
        table_candidate_path, TABLE_CANDIDATE_COLUMNS, table_candidates
    )
    _write_csv_atomic(
        source_candidate_path, SOURCE_CANDIDATE_COLUMNS, source_candidates
    )
    _write_csv_atomic(
        unresolved_decision_path, UNRESOLVED_DECISION_COLUMNS, unresolved
    )
    input_manifest_rows = [
        {
            "input_role": role,
            "path": path.name,
            "byte_size": str(path.stat().st_size),
            "sha256": sha256_file(path),
        }
        for role, path in [
            ("b03_table_evidence", table_evidence_path),
            ("b04_source_column_evidence", source_evidence_path),
            ("canonical_table_grain_read_only", canonical_table_path),
            ("canonical_source_columns_read_only", canonical_source_path),
            *(
                [("upstream_artifact_manifest", artifact_manifest_path)]
                if artifact_manifest_path is not None
                else []
            ),
            *(
                [("upstream_input_manifest", upstream_input_manifest_path)]
                if upstream_input_manifest_path is not None
                else []
            ),
            ("generator", Path(__file__).resolve()),
        ]
    ]
    _write_csv_atomic(
        input_manifest_path, INPUT_MANIFEST_COLUMNS, input_manifest_rows
    )

    canonical_after = {
        path: sha256_file(path) for path in canonical_before
    }
    if canonical_after != canonical_before:
        fail("canonical contract changed during review-only candidate generation")
    canonical_rows = [
        {
            "path": path.name,
            "sha256_before": canonical_before[path],
            "sha256_after": canonical_after[path],
            "unchanged": "true",
        }
        for path in (canonical_table_path, canonical_source_path)
    ]
    _write_csv_atomic(
        canonical_hash_path, CANONICAL_HASH_COLUMNS, canonical_rows
    )

    table_grain_counts = _format_counts(
        row["grain_class"] for row in table_candidates
    )
    source_role_counts = _format_counts(row["role"] for row in source_candidates)
    reviewed_table_count = sum(bool_value(row["reviewed"]) for row in table_candidates)
    reviewed_source_count = sum(
        bool_value(row["reviewed"]) for row in source_candidates
    )
    summary = "\n".join(
        [
            "# Stage 04 full candidate contract package",
            "",
            "STAGE04_CANDIDATE_INVENTORY_COMPLETE",
            "STAGE04_REVIEW_STILL_REQUIRED",
            "RELEASE_STILL_BLOCKED",
            "",
            f"- Exact-identity data-table candidates: {len(table_candidates)}.",
            f"- Table grain counts: {table_grain_counts}.",
            (
                "- Already countersigned table rows preserved as reviewed: "
                f"{reviewed_table_count}; new review candidates: "
                f"{len(table_candidates) - reviewed_table_count}."
            ),
            (
                "- Exact-identity data-source-column candidates: "
                f"{len(source_candidates)}."
            ),
            f"- Source-column role counts: {source_role_counts}.",
            (
                "- Already countersigned source-column rows preserved as reviewed: "
                f"{reviewed_source_count}; new review candidates: "
                f"{len(source_candidates) - reviewed_source_count}."
            ),
            (
                "- Genuinely unresolved all-empty source-column decisions: "
                f"{len(unresolved)}."
            ),
            (
                "- SAL2009_A_LT9 remains observationally zero-row/untestable; "
                "its candidate uses only the countersigned intended "
                "UNITID|ARANK schema and exact source metadata."
            ),
            "- Canonical table_grain.csv and source_columns.csv are byte-identical to their pre-run state.",
            "",
            "These are review candidates, not canonical contract edits or release approval.",
            "",
        ]
    )
    _write_text_atomic(summary_path, summary)

    artifact_specs = [
        (table_candidate_path, "complete_table_grain_candidate"),
        (source_candidate_path, "complete_source_column_candidate"),
        (unresolved_decision_path, "unresolved_empty_source_decisions"),
        (input_manifest_path, "input_provenance"),
        (canonical_hash_path, "canonical_immutability_proof"),
        (summary_path, "review_summary"),
    ]
    artifact_rows = [
        {
            "path": path.name,
            "byte_size": str(path.stat().st_size),
            "sha256": sha256_file(path),
            "row_count": str(_artifact_row_count(path)),
            "artifact_role": role,
        }
        for path, role in artifact_specs
    ]
    _write_csv_atomic(
        manifest_path, ARTIFACT_MANIFEST_COLUMNS, artifact_rows
    )

    return BuildResult(
        table_candidate_path=table_candidate_path,
        source_candidate_path=source_candidate_path,
        unresolved_decision_path=unresolved_decision_path,
        input_manifest_path=input_manifest_path,
        canonical_hash_path=canonical_hash_path,
        summary_path=summary_path,
        manifest_path=manifest_path,
        table_count=len(table_candidates),
        source_column_count=len(source_candidates),
        unresolved_count=len(unresolved),
        reviewed_table_count=reviewed_table_count,
        reviewed_source_column_count=reviewed_source_count,
    )


def parse_years(value: str) -> set[int]:
    result: set[int] = set()
    for token in value.split(","):
        token = token.strip()
        if not token:
            continue
        if ":" in token:
            start_text, end_text = token.split(":", 1)
            start, end = int(start_text), int(end_text)
            if start > end:
                fail(f"invalid descending year range: {token}")
            result.update(range(start, end + 1))
        else:
            result.add(int(token))
    if not result:
        fail("year specification is empty")
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    default_evidence = (
        REPO_ROOT
        / "Artifacts"
        / "review_v2"
        / "b03_b04_package_rebaseline_2026-07-24"
    )
    parser.add_argument(
        "--evidence-dir",
        type=Path,
        default=default_evidence,
        help="Completed B03/B04 evidence directory.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=(
            REPO_ROOT
            / "Artifacts"
            / "review_v2"
            / "stage04_full_candidates_2026-07-24"
        ),
    )
    parser.add_argument(
        "--canonical-table-grain",
        type=Path,
        default=REPO_ROOT / "contracts" / "table_grain.csv",
    )
    parser.add_argument(
        "--canonical-source-columns",
        type=Path,
        default=REPO_ROOT / "contracts" / "source_columns.csv",
    )
    parser.add_argument("--expected-table-count", type=int, default=883)
    parser.add_argument("--expected-source-column-count", type=int, default=41152)
    parser.add_argument("--years", default="2004:2023")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    table_evidence_path = args.evidence_dir / "table_grain_enriched.csv"
    source_evidence_path = args.evidence_dir / "source_column_enriched.csv"
    artifact_manifest_path = args.evidence_dir / "B03_B04_artifact_manifest.csv"
    result = build_candidates(
        table_evidence_path=table_evidence_path,
        source_evidence_path=source_evidence_path,
        output_dir=args.output_dir,
        canonical_table_path=args.canonical_table_grain,
        canonical_source_path=args.canonical_source_columns,
        artifact_manifest_path=artifact_manifest_path,
        expected_table_count=args.expected_table_count,
        expected_source_column_count=args.expected_source_column_count,
        expected_years=parse_years(args.years),
        require_all_canonical_rows=True,
    )
    print(f"table_candidates={result.table_count}")
    print(f"source_column_candidates={result.source_column_count}")
    print(f"unresolved_decisions={result.unresolved_count}")
    print(f"reviewed_table_rows={result.reviewed_table_count}")
    print(f"reviewed_source_column_rows={result.reviewed_source_column_count}")
    print(f"release_ready={str(result.release_ready).lower()}")
    print(f"output_dir={args.output_dir}")


if __name__ == "__main__":
    main()
