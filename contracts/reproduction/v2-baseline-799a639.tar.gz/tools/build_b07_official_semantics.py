#!/usr/bin/env python3
"""Build review-only B07 PRCH semantic evidence from official NCES sources.

This tool never edits ``contracts/prch_policy.csv``.  It binds the observed
FLAGS/valueSets evidence to official annual Finance packages and emits a
deterministic author-decision design.  Exact analysis-column expansion remains
downstream of the countersigned B05 schema.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
from typing import Iterable, Mapping, Sequence
import zipfile


CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
FINANCE_ARCHIVE_URL = (
    "https://nces.ed.gov/ipeds/use-the-data/download-survey-material/{year}/finance"
)
FINANCE_TIP_URL = (
    "https://nces.ed.gov/ipeds/report-your-data/"
    "data-tip-sheet-reporting-finance-data-multiple-institutions"
)
FINANCE_ARCHIVE_INDEX_URL = (
    "https://nces.ed.gov/ipeds/use-the-data/"
    "annual-survey-forms-packages-archived?section=Finance"
)

FORM_NAMES = {
    "4": "GASB",
    "2": "FASB",
    "3": "private_for_profit",
}
FORM_PREFIXES = {
    "4": "F1",
    "2": "F2",
    "3": "F3",
}
PREDICATE_COLUMNS = {
    "PRCH_ADM": "STAT_ADM",
    "PRCH_AL": "STAT_AL",
    "PRCH_C": "STAT_C",
    "PRCH_E12": "STAT_E12",
    "PRCH_EAP": "STAT_EAP",
    "PRCH_EF": "STAT_EF",
    "PRCH_F": "FORM_F",
    "PRCH_GR": "STAT_GR",
    "PRCH_GR2": "STAT_GR2",
    "PRCH_HR": "STAT_HR",
    "PRCH_OM": "STAT_OM",
    "PRCH_S": "STAT_S",
    "PRCH_SA": "STAT_SA",
    "PRCH_SFA": "STAT_SFA",
    "PRCHTP_F": "FORM_F",
}
DIAGNOSTIC_SOURCE_FAMILIES = {
    "PRCH_ADM": "ADM",
    "PRCH_AL": "AL",
    "PRCH_C": "C_A|C_B|C_C|CDEP|DRVC",
    "PRCH_E12": "E12",
    "PRCH_EAP": "EAP",
    "PRCH_EF": "EFA|EFA_DIST|EFB|EFC|EFCP|EFFY|EFFY_DIST|EFIA",
    "PRCH_F": "F_F|F_FA|DRVF",
    "PRCH_GR": "GR|GR_PELL_SSL",
    "PRCH_GR2": "GR200",
    "PRCH_HR": "EAP|SAL_A|SAL_A_LT|SAL_B|SAL_FACULTY|SAL_IS",
    "PRCH_OM": "OM",
    "PRCH_S": "S_ABD|S_CN|S_F|S_G|S_IS|S_NH|S_OC|S_SIS",
    "PRCH_SA": "SFA|SFA_P|SFAV",
    "PRCH_SFA": "SFA|SFA_P|SFAV",
    "PRCHTP_F": "",
}


class B07EvidenceError(RuntimeError):
    """Raised when the review evidence cannot be bound exactly."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def generator_commit(repo: Path, generator_path: Path) -> str:
    relative = generator_path.resolve().relative_to(repo.resolve()).as_posix()
    completed = subprocess.run(
        ["git", "log", "-1", "--format=%H", "--", relative],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    )
    commit = completed.stdout.strip()
    return commit or "UNCOMMITTED"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(
    path: Path,
    fieldnames: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            lineterminator="\n",
            extrasaction="raise",
        )
        writer.writeheader()
        writer.writerows(rows)


def classify_semantic_decision(
    flag: str,
    code: str,
    value_label: str,
) -> tuple[str, str]:
    """Return a review-only action and semantic class from exact label evidence."""

    flag = str(flag).strip().upper()
    code = str(code).strip()
    label = " ".join(str(value_label).split()).casefold()
    if flag == "PRCHTP_F":
        return "retain", "finance_system_topology"
    if code == "-2" and "not applicable" in label:
        return "retain", "not_applicable"
    if code == "1" and ("parent record" in label or "parent" in label):
        return "retain", "parent_includes_children"
    if code == "2" and "child" in label and (
        "reported" in label or "report" in label
    ):
        return "null", "full_child_reported_elsewhere"
    if flag == "PRCH_F" and code == "3" and "partial child" in label:
        return "null", "partial_child_parent_reported_parts"
    if flag == "PRCH_F" and code == "4" and "not a postsecondary" in label:
        return "null", "full_child_non_ipeds_reporting_entity"
    if flag == "PRCH_F" and code == "5" and "partial data" in label:
        return "null", "partial_child_non_ipeds_reporting_entity"
    if flag == "PRCH_F" and code == "6" and "partial parent/child" in label:
        return "null", "nested_partial_parent_parent_reported_parts"
    return "unresolved", "unsupported_label_or_code"


def finance_parent_reported_parts(year: int, form_code: str) -> tuple[str, ...]:
    """Parts not separately reported by a partial child in an annual form."""

    year = int(year)
    form_code = str(form_code)
    if not 2004 <= year <= 2023:
        raise B07EvidenceError(f"unsupported Finance year: {year}")
    if form_code == "4":
        if year <= 2009:
            return ("A", "D", "L")
        if year <= 2012:
            return ("A", "D")
        if year <= 2016:
            return ("A", "D", "L")
        if year <= 2019:
            return ("A", "D", "L", "M")
        return ("A", "D", "L", "M1", "M2", "N")
    if form_code == "2":
        return ("A", "B") if year <= 2019 else ("A", "B", "I")
    if form_code == "3":
        if year <= 2013:
            return ("A", "B")
        if year <= 2019:
            return ("A", "B", "F")
        return ("A", "B", "F", "G")
    raise B07EvidenceError(f"unsupported FORM_F value for part mapping: {form_code!r}")


def finance_source_reference(
    year: int,
    form_code: str,
) -> tuple[str, str, str]:
    """Return the exact annual member, evidence strength, and section locator."""

    year = int(year)
    form_code = str(form_code)
    if not 2004 <= year <= 2023:
        raise B07EvidenceError(f"unsupported Finance year: {year}")
    if form_code not in FORM_NAMES:
        raise B07EvidenceError(f"unsupported Finance form: {form_code!r}")
    if year <= 2006:
        names = {"4": "f1a_form.pdf", "2": "f2_form.pdf", "3": "f3_form.pdf"}
    elif year == 2007:
        names = {"4": "f1a_2007.pdf", "2": "f2_2007.pdf", "3": "f3_2007.pdf"}
    elif year == 2008:
        names = {
            "4": "F_GASB_Aligned_2008.pdf",
            "2": "F_FASB_Aligned_2008.pdf",
            "3": "F_FASB_Pvt%20For_profit_2008.pdf",
        }
    elif year == 2009:
        names = {
            "4": "f_gasb_aligned_2009.pdf",
            "2": "f_fasb_aligned_2009.pdf",
            "3": "f_for_profit_2009.pdf",
        }
    elif year <= 2012:
        names = {"4": "f_1", "2": "f_2", "3": "f_3"}
        return (
            f"{names[form_code]}_{year}.pdf",
            "exact_annual_instruction_table",
            (
                "Additional Instructions for Institutions Reporting Finance Data "
                "for Other Institutions > Parent Institution / Child Institution "
                "comparison table"
            ),
        )
    else:
        names = {
            "4": "package_5_68.pdf",
            "2": "package_5_67.pdf",
            "3": "package_5_12.pdf",
        }
    if year == 2020 and form_code == "3":
        return (
            "package_5_87.pdf",
            "official_2020_overview_and_adjacent_exact_tables",
            (
                "Overview > Changes to reporting for 2020-21 (new Part G); "
                "supplemental 2019/2021 degree-granting Parent Institution / "
                "Child Institution comparison tables"
            ),
        )
    if year <= 2009:
        form_section = {
            "4": "Public institutions using GASB 34/35 standards",
            "2": (
                "Private, not-for-profit institutions and public institutions "
                "using FASB standards"
            ),
            "3": "Private, for-profit institutions",
        }[form_code]
        return (
            names[form_code],
            "official_retrospective_tip_plus_archived_form",
            (
                "Annual form part headings; tip sheet > Partial parent/child "
                f"reporting relationships, by institution type > {form_section}"
            ),
        )
    return (
        names[form_code],
        "exact_annual_instruction_table",
        (
            "Additional Instructions for Institutions Reporting Finance Data "
            "for Other Institutions > Parent Institution / Child Institution "
            "comparison table"
        ),
    )


def partial_form_exception_action(
    *,
    nonempty_forms: Sequence[str],
    nonempty_value_count: int,
) -> tuple[str, str]:
    """Resolve FORM_F=-2 only when exact observed source evidence permits."""

    forms = tuple(sorted(set(nonempty_forms)))
    if not nonempty_value_count and not forms:
        return "retain", "no_observed_finance_values"
    if len(forms) == 1:
        return "null", forms[0]
    if len(forms) > 1:
        return "unresolved", "multiple_observed_finance_forms"
    return "unresolved", "nonempty_values_without_exact_form"


def prove_code6_topology(rows: Sequence[Mapping[str, str]]) -> list[dict[str, object]]:
    """Prove code 6 is a nested partial parent, not an arbitrary review-only row."""

    by_unitid = {str(row.get("UNITID", "")).strip(): row for row in rows}
    proof: list[dict[str, object]] = []
    for row in sorted(
        (item for item in rows if str(item.get("PRCH_F", "")).strip() == "6"),
        key=lambda item: str(item.get("UNITID", "")).strip(),
    ):
        unitid = str(row.get("UNITID", "")).strip()
        upstream_id = str(row.get("IDX_F", "")).strip()
        upstream = by_unitid.get(upstream_id)
        downstream = [
            item
            for item in rows
            if str(item.get("IDX_F", "")).strip() == unitid
            and str(item.get("PRCH_F", "")).strip() == "2"
        ]
        if upstream is None:
            status = "missing_upstream_parent"
            upstream_code = ""
        else:
            upstream_code = str(upstream.get("PRCH_F", "")).strip()
            status = (
                "exact_nested_partial_parent"
                if str(row.get("PRCHTP_F", "")).strip() == "3"
                and upstream_code == "1"
                else "topology_mismatch"
            )
        proof.append(
            {
                "unitid": unitid,
                "upstream_parent_unitid": upstream_id,
                "upstream_parent_code": upstream_code,
                "downstream_child_count": len(downstream),
                "topology_status": status,
            }
        )
    return proof


def casefold_csv(directory: Path, stem: str) -> Path:
    matches = [
        path
        for path in directory.glob("*.csv")
        if path.stem.casefold() == stem.casefold()
    ]
    if len(matches) != 1:
        raise B07EvidenceError(
            f"expected one CSV for {stem!r} in {directory}, found {len(matches)}"
        )
    return matches[0]


def official_source_manifest(official_root: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    html_sources = (
        (
            "finance_parent_child_tip_sheet",
            official_root / "finance_parent_child_tip_sheet.html",
            FINANCE_TIP_URL,
            "Retrospective source-semantic description, including the since-2004 boundary.",
        ),
        (
            "finance_archive_index",
            official_root / "finance_archive_index.html",
            FINANCE_ARCHIVE_INDEX_URL,
            "Official index that enumerates archived annual Finance packages.",
        ),
    )
    for source_id, path, url, use in html_sources:
        if not path.is_file():
            raise B07EvidenceError(f"missing official source: {path}")
        rows.append(
            {
                "source_id": source_id,
                "year": "",
                "source_kind": "official_html",
                "url": url,
                "relative_path": path.relative_to(official_root).as_posix(),
                "member_name": "",
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
                "container_sha256": "",
                "integrity_status": "exact",
                "semantic_use": use,
            }
        )

    package_root = official_root / "finance_packages"
    for year in range(2004, 2024):
        archive_path = package_root / f"{year}-finance.zip"
        if not archive_path.is_file():
            raise B07EvidenceError(f"missing official Finance archive: {archive_path}")
        archive_hash = sha256_file(archive_path)
        try:
            archive = zipfile.ZipFile(archive_path)
            bad_member = archive.testzip()
        except zipfile.BadZipFile as exc:
            raise B07EvidenceError(f"invalid official Finance archive: {archive_path}") from exc
        if bad_member:
            raise B07EvidenceError(
                f"corrupt member {bad_member!r} in official archive {archive_path}"
            )
        rows.append(
            {
                "source_id": f"finance_{year}_archive",
                "year": year,
                "source_kind": "official_zip",
                "url": FINANCE_ARCHIVE_URL.format(year=year),
                "relative_path": archive_path.relative_to(official_root).as_posix(),
                "member_name": "",
                "byte_size": archive_path.stat().st_size,
                "sha256": archive_hash,
                "container_sha256": "",
                "integrity_status": "exact",
                "semantic_use": "Official annual Finance survey forms and instructions.",
            }
        )
        for member in sorted(
            (item for item in archive.infolist() if not item.is_dir()),
            key=lambda item: item.filename.casefold(),
        ):
            payload = archive.read(member)
            rows.append(
                {
                    "source_id": f"finance_{year}_{Path(member.filename).stem}",
                    "year": year,
                    "source_kind": "official_zip_member",
                    "url": FINANCE_ARCHIVE_URL.format(year=year),
                    "relative_path": archive_path.relative_to(official_root).as_posix(),
                    "member_name": member.filename,
                    "byte_size": len(payload),
                    "sha256": hashlib.sha256(payload).hexdigest(),
                    "container_sha256": archive_hash,
                    "integrity_status": "exact",
                    "semantic_use": "Annual form/instruction identity.",
                }
            )
    return rows


def extract_pdf_text_pages(archive_path: Path, member_name: str) -> tuple[str, ...]:
    with zipfile.ZipFile(archive_path) as archive:
        payload = archive.read(member_name)
    try:
        completed = subprocess.run(
            ["pdftotext", "-layout", "-", "-"],
            input=payload,
            check=True,
            capture_output=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError) as exc:
        raise B07EvidenceError(
            f"cannot extract page-bound text from {archive_path.name}#{member_name}"
        ) from exc
    pages = completed.stdout.decode("utf-8", errors="replace").split("\f")
    while pages and not pages[-1].strip():
        pages.pop()
    if not pages:
        raise B07EvidenceError(
            f"official PDF has no extractable pages: {archive_path.name}#{member_name}"
        )
    return tuple(pages)


def finance_pdf_page_locator(
    *,
    year: int,
    form_code: str,
    parent_parts: Sequence[str],
    pages: Sequence[str],
) -> str:
    """Locate the exact PDF pages that support one annual form/part row."""

    year = int(year)
    form_code = str(form_code)
    if year <= 2009:
        locators: list[str] = []
        for part in parent_parts:
            pattern = re.compile(
                rf"(?im)^\s*(?:INSTRUCTIONS FOR )?PART\s+{re.escape(part)}\b"
            )
            hits = [
                str(page_number)
                for page_number, text in enumerate(pages, start=1)
                if pattern.search(text)
            ]
            if not hits:
                raise B07EvidenceError(
                    f"missing annual PDF Part {part} page for {year} form {form_code}"
                )
            locators.append(f"official_pdf_part_{part}_pages={'|'.join(hits)}")
        locators.append("tip_sheet_html_anchor=#partial-relationships-heading")
        return ";".join(locators)

    if year == 2020 and form_code == "3":
        hits = [
            str(page_number)
            for page_number, text in enumerate(pages, start=1)
            if "Changes to reporting for 2020-21" in text and "Part G" in text
        ]
        if not hits:
            raise B07EvidenceError(
                "missing 2020 for-profit Part G change-notice page"
            )
        return f"official_pdf_change_notice_pages={'|'.join(hits)}"

    hits = [
        str(page_number)
        for page_number, text in enumerate(pages, start=1)
        if "Parent Institution" in text and "Child Institution" in text
    ]
    if not hits:
        raise B07EvidenceError(
            f"missing Parent Institution / Child Institution comparison table "
            f"for {year} form {form_code}"
        )
    return f"official_pdf_comparison_table_pages={'|'.join(hits)}"


def validate_form_part_matrix_page_locators(
    rows: Sequence[Mapping[str, object]],
) -> None:
    expected = {
        (year, form_code)
        for year in range(2004, 2024)
        for form_code in ("4", "2", "3")
    }
    observed = {
        (int(row["year"]), str(row["form_f_code"]))
        for row in rows
    }
    if len(rows) != 60 or observed != expected:
        raise B07EvidenceError(
            "form-part matrix page locator validation requires all 60 year/form rows"
        )
    for row in rows:
        locator = str(row.get("page_locator", "")).strip()
        page_tokens = [
            token.split("=", 1)[1]
            for token in locator.split(";")
            if "=" in token and token.split("=", 1)[0].endswith("_pages")
        ]
        valid = bool(page_tokens) and all(
            value
            and all(piece.isdigit() and int(piece) > 0 for piece in value.split("|"))
            for value in page_tokens
        )
        if not valid:
            raise B07EvidenceError(
                "invalid or missing page locator for "
                f"{row.get('year')} form {row.get('form_f_code')}"
            )


def form_part_matrix(
    source_manifest: Sequence[Mapping[str, object]],
    official_root: Path,
) -> list[dict[str, object]]:
    archives = {
        int(row["year"]): row
        for row in source_manifest
        if row["source_kind"] == "official_zip"
    }
    members = {
        (int(row["year"]), str(row["member_name"]).casefold()): row
        for row in source_manifest
        if row["source_kind"] == "official_zip_member"
    }
    tip_sheet = next(
        (
            row
            for row in source_manifest
            if row["source_id"] == "finance_parent_child_tip_sheet"
        ),
        None,
    )
    if tip_sheet is None:
        raise B07EvidenceError("official tip-sheet identity is missing")

    rows: list[dict[str, object]] = []
    page_cache: dict[tuple[int, str], tuple[str, ...]] = {}
    for year in range(2004, 2024):
        for form_code in ("4", "2", "3"):
            member, strength, locator = finance_source_reference(year, form_code)
            parts = finance_parent_reported_parts(year, form_code)
            archive = archives.get(year)
            member_row = members.get((year, member.casefold()))
            if archive is None or member_row is None:
                raise B07EvidenceError(
                    f"cannot bind official Finance source for {year} form {form_code}: "
                    f"{member!r}"
                )
            page_key = (year, member)
            if page_key not in page_cache:
                page_cache[page_key] = extract_pdf_text_pages(
                    official_root / str(archive["relative_path"]),
                    member,
                )
            page_locator = finance_pdf_page_locator(
                year=year,
                form_code=form_code,
                parent_parts=parts,
                pages=page_cache[page_key],
            )
            supplemental: list[str] = []
            if year == 2020 and form_code == "3":
                for adjacent_year in (2019, 2021):
                    adjacent_archive = archives.get(adjacent_year)
                    adjacent_member = members.get(
                        (adjacent_year, "package_5_12.pdf")
                    )
                    if adjacent_archive is None or adjacent_member is None:
                        raise B07EvidenceError(
                            "cannot bind adjacent exact for-profit comparison table "
                            f"for {adjacent_year}"
                        )
                    supplemental.append(
                        (
                            f"{adjacent_year}:{adjacent_archive['url']}"
                            f"#package_5_12.pdf;"
                            f"zip_sha256={adjacent_archive['sha256']};"
                            f"member_sha256={adjacent_member['sha256']}"
                        )
                    )
                    adjacent_key = (adjacent_year, "package_5_12.pdf")
                    if adjacent_key not in page_cache:
                        page_cache[adjacent_key] = extract_pdf_text_pages(
                            official_root / str(adjacent_archive["relative_path"]),
                            "package_5_12.pdf",
                        )
                    adjacent_locator = finance_pdf_page_locator(
                        year=adjacent_year,
                        form_code="3",
                        parent_parts=finance_parent_reported_parts(
                            adjacent_year, "3"
                        ),
                        pages=page_cache[adjacent_key],
                    )
                    page_locator += (
                        f";supplemental_{adjacent_year}_"
                        + adjacent_locator
                    )
            rows.append(
                {
                    "contract_id": CONTRACT_ID,
                    "year": year,
                    "form_f_code": form_code,
                    "accounting_standard": FORM_NAMES[form_code],
                    "direct_variable_prefix": FORM_PREFIXES[form_code],
                    "parent_reported_child_omits_parts": "|".join(parts),
                    "partial_child_action": "null_exact_columns_in_listed_parts",
                    "other_parts_action": "retain",
                    "official_zip_url": archive["url"],
                    "official_zip_sha256": archive["sha256"],
                    "official_member_name": member_row["member_name"],
                    "official_member_sha256": member_row["sha256"],
                    "official_tip_sheet_url": FINANCE_TIP_URL,
                    "official_tip_sheet_sha256": tip_sheet["sha256"],
                    "section_locator": locator,
                    "page_locator": page_locator,
                    "supplemental_official_identities": "|".join(supplemental),
                    "evidence_strength": strength,
                    "source_binding_status": "exact",
                }
            )
    validate_form_part_matrix_page_locators(rows)
    return rows


def build_decision_register(source_rows: Sequence[Mapping[str, str]]) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for raw in source_rows:
        flag = str(raw["flag"]).strip().upper()
        code = str(raw["observed_code"]).strip()
        label = str(raw["value_label"])
        action, semantic_class = classify_semantic_decision(flag, code, label)
        if action == "unresolved":
            status = "request_more_evidence"
            target_scope = ""
        elif action == "retain":
            status = "supported_author_countersign_pending"
            target_scope = "none"
        elif flag == "PRCH_F" and code in {"3", "5", "6"}:
            status = "supported_b05_target_binding_and_author_countersign_pending"
            target_scope = (
                "Exact direct finance columns in B07_FORM_PART_MATRIX parts; "
                "plus exact DRVF equity-ratio identities; FORM_F=-2 exceptions "
                "follow B07_FORM_F_EXCEPTION_EVIDENCE."
            )
        elif flag == "PRCH_F":
            status = "supported_b05_target_binding_and_author_countersign_pending"
            target_scope = "All exact direct and derived Finance payload columns."
        else:
            status = "supported_b05_target_binding_and_author_countersign_pending"
            target_scope = (
                "All exact scalar-wide fields proven to belong to this component; "
                "never keys, PRCH fields, predicates, or dimensioned-lane fields."
            )
        output.append(
            {
                "decision_id": raw["decision_id"],
                "contract_id": CONTRACT_ID,
                "flag": flag,
                "observed_code": code,
                "value_label": label,
                "years_observed": raw["years_observed"],
                "year_signature_count": raw["year_signature_count"],
                "observed_row_count_total": raw["observed_row_count_total"],
                "candidate_action": action,
                "semantic_class": semantic_class,
                "target_semantic_scope": target_scope,
                "predicate_column": PREDICATE_COLUMNS[flag],
                "predicate_expansion": (
                    "Mechanically enumerate exact observed year/flag/code/"
                    f"{PREDICATE_COLUMNS[flag]} values; require one-rule coverage."
                ),
                "official_source_reference": (
                    FINANCE_TIP_URL
                    if flag in {"PRCH_F", "PRCHTP_F"}
                    else "Exact annual NCES Access valueSets label/hash in source register."
                ),
                "candidate_status": status,
                "author_decision": "",
                "author_name": "",
                "author_date": "",
            }
        )
    return output


def stage04_finance_tables(stage04_path: Path) -> dict[int, set[str]]:
    output: dict[int, set[str]] = {}
    for row in read_csv(stage04_path):
        if row.get("source_file") not in {"F_F", "F_FA", "DRVF"}:
            continue
        year = int(row["year_start"])
        if year != int(row["year_end"]):
            raise B07EvidenceError("Stage04 exact candidate unexpectedly spans years")
        output.setdefault(year, set()).add(row["access_table_pattern"])
    return output


def build_form_exceptions(
    *,
    legacy_root: Path,
    stage04_path: Path,
) -> list[dict[str, object]]:
    tables_by_year = stage04_finance_tables(stage04_path)
    output: list[dict[str, object]] = []
    for year in range(2004, 2024):
        tables_dir = legacy_root / "Raw_Access_Databases" / str(year) / "tables_csv"
        flags_path = casefold_csv(tables_dir, f"FLAGS{year}")
        flags_rows = read_csv(flags_path)
        candidates = [
            row
            for row in flags_rows
            if row.get("PRCH_F", "").strip() in {"3", "5"}
            and row.get("FORM_F", "").strip() == "-2"
        ]
        if not candidates:
            continue
        table_lookups: dict[str, dict[str, dict[str, str]]] = {}
        table_paths: dict[str, Path] = {}
        for table in sorted(tables_by_year.get(year, set())):
            path = casefold_csv(tables_dir, table)
            table_paths[table] = path
            lookup: dict[str, dict[str, str]] = {}
            for row in read_csv(path):
                unitid = row.get("UNITID", "").strip()
                if unitid:
                    lookup[unitid] = row
            table_lookups[table] = lookup
        for flag_row in sorted(candidates, key=lambda row: int(row["UNITID"])):
            unitid = flag_row["UNITID"].strip()
            nonempty_count = 0
            forms: set[str] = set()
            identities: list[str] = []
            csv_hashes: list[str] = []
            for table in sorted(table_lookups):
                data_row = table_lookups[table].get(unitid)
                if data_row is None:
                    continue
                nonempty = [
                    column
                    for column, value in data_row.items()
                    if column != "UNITID" and str(value or "").strip()
                ]
                if not nonempty:
                    continue
                nonempty_count += len(nonempty)
                identities.append(f"{table}:{len(nonempty)}")
                csv_hashes.append(sha256_file(table_paths[table]))
                match = re.search(r"(?:^|_)F([123])(?:$|[A-Z0-9_])", table.upper())
                if match:
                    forms.add(f"F{match.group(1)}")
            action, resolution = partial_form_exception_action(
                nonempty_forms=tuple(forms),
                nonempty_value_count=nonempty_count,
            )
            output.append(
                {
                    "contract_id": CONTRACT_ID,
                    "year": year,
                    "unitid": unitid,
                    "prch_f": flag_row["PRCH_F"].strip(),
                    "form_f": "-2",
                    "idx_f": flag_row.get("IDX_F", "").strip(),
                    "nonempty_finance_value_count": nonempty_count,
                    "exact_nonempty_table_identities": "|".join(identities),
                    "inferred_exact_form_from_table_identity": "|".join(sorted(forms)),
                    "candidate_action": action,
                    "resolution": resolution,
                    "source_csv_sha256s": "|".join(sorted(set(csv_hashes))),
                    "flags_csv_sha256": sha256_file(flags_path),
                    "candidate_status": (
                        "supported_author_countersign_pending"
                        if action != "unresolved"
                        else "request_more_evidence"
                    ),
                }
            )
    return output


def summarize_form_f_predicate_scopes(
    rows: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    """Prove FORM_F=-2 exception predicates never mix actions or exact forms."""

    grouped: dict[tuple[int, str, str], list[Mapping[str, object]]] = {}
    for row in rows:
        key = (
            int(row["year"]),
            str(row["prch_f"]),
            str(row["form_f"]),
        )
        grouped.setdefault(key, []).append(row)

    output: list[dict[str, object]] = []
    for (year, prch_f, form_f), scope_rows in sorted(grouped.items()):
        actions = sorted({str(row["candidate_action"]) for row in scope_rows})
        resolutions = sorted({str(row["resolution"]) for row in scope_rows})
        forms = sorted(
            {
                form
                for row in scope_rows
                for form in str(
                    row["inferred_exact_form_from_table_identity"]
                ).split("|")
                if form
            }
        )
        nonempty_row_count = sum(
            int(row["nonempty_finance_value_count"]) > 0 for row in scope_rows
        )
        nonempty_value_count = sum(
            int(row["nonempty_finance_value_count"]) for row in scope_rows
        )
        exact_null = (
            actions == ["null"]
            and len(forms) == 1
            and resolutions == forms
            and nonempty_row_count == len(scope_rows)
        )
        exact_retain = (
            actions == ["retain"]
            and not forms
            and resolutions == ["no_observed_finance_values"]
            and nonempty_value_count == 0
        )
        output.append(
            {
                "contract_id": str(scope_rows[0]["contract_id"]),
                "year": year,
                "prch_f": prch_f,
                "form_f": form_f,
                "row_count": len(scope_rows),
                "candidate_actions": "|".join(actions),
                "resolutions": "|".join(resolutions),
                "inferred_exact_forms": "|".join(forms),
                "nonempty_row_count": nonempty_row_count,
                "nonempty_finance_value_count": nonempty_value_count,
                "scope_status": (
                    "exact_single_action_single_form"
                    if exact_null
                    else (
                        "exact_single_action_no_observed_values"
                        if exact_retain
                        else "mixed_action_or_form"
                    )
                ),
            }
        )
    return output


def build_topology_proof(legacy_root: Path) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for year in range(2016, 2024):
        tables_dir = legacy_root / "Raw_Access_Databases" / str(year) / "tables_csv"
        flags_path = casefold_csv(tables_dir, f"FLAGS{year}")
        rows = read_csv(flags_path)
        by_unitid = {row["UNITID"].strip(): row for row in rows}
        for proof in prove_code6_topology(rows):
            source = by_unitid[str(proof["unitid"])]
            downstream_ids = sorted(
                row["UNITID"].strip()
                for row in rows
                if row.get("IDX_F", "").strip() == str(proof["unitid"])
                and row.get("PRCH_F", "").strip() == "2"
            )
            output.append(
                {
                    "contract_id": CONTRACT_ID,
                    "year": year,
                    **proof,
                    "pcf_f": source.get("PCF_F", "").strip(),
                    "form_f": source.get("FORM_F", "").strip(),
                    "downstream_child_unitids": "|".join(downstream_ids),
                    "flags_csv_sha256": sha256_file(flags_path),
                }
            )
    return output


def build_target_requirements(b05_path: Path) -> list[dict[str, object]]:
    b05_rows = read_csv(b05_path)
    source_files = {row["source_file"] for row in b05_rows}
    output: list[dict[str, object]] = []
    for flag in sorted(PREDICATE_COLUMNS):
        diagnostic = DIAGNOSTIC_SOURCE_FAMILIES[flag]
        missing = sorted(set(diagnostic.split("|")) - source_files) if diagnostic else []
        if flag == "PRCHTP_F":
            rule = "No target columns. Retain only; this is a system-topology descriptor."
        elif flag == "PRCH_F":
            rule = (
                "Join exact B05 identities to exact Stage04 source identities. Full-child codes "
                "target every F_F/F_FA/DRVF payload identity. Partial codes target direct F1/F2/F3 "
                "columns whose exact form-part identity is listed in B07_FORM_PART_MATRIX, plus "
                "the exact DRVF F1EQUITR/F2EQUITR/F3EQUITR identities. Do not infer parts from "
                "an analysis-column name alone."
            )
        else:
            rule = (
                "Review candidate source families against exact Access table metadata, then join "
                "only their countersigned B05 variable_id identities to analysis_column. Exclude "
                "UNITID, PRCH/status/control fields, dimensions, and every non-B05 identity."
            )
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "flag": flag,
                "predicate_column": PREDICATE_COLUMNS[flag],
                "diagnostic_candidate_source_files": diagnostic,
                "candidate_files_absent_from_b05": "|".join(missing),
                "binding_rule": rule,
                "dimensioned_lane_policy": (
                    "No action: panel_long_dimensioned_2004_2023 remains raw and "
                    "PRCH-unmodified. Every B07 target must resolve through the "
                    "countersigned scalar-wide B05 identity mapping."
                ),
                "empty_target_rule": (
                    "If exact B05 binding yields zero scalar-wide target columns, "
                    "emit no null rule and retain the row; never invent a target "
                    "or encode null with an empty target list."
                ),
                "b05_identity_mapping_sha256": sha256_file(b05_path),
                "binding_status": (
                    "no_targets_required"
                    if flag == "PRCHTP_F"
                    else "requires_countersigned_b05_and_exact_binding_proof"
                ),
            }
        )
    return output


def write_result(
    path: Path,
    *,
    decisions: Sequence[Mapping[str, object]],
    form_exceptions: Sequence[Mapping[str, object]],
    predicate_scopes: Sequence[Mapping[str, object]],
    topology: Sequence[Mapping[str, object]],
    source_manifest: Sequence[Mapping[str, object]],
    canonical_hash: str,
) -> None:
    supported = sum(row["candidate_action"] != "unresolved" for row in decisions)
    nulls = sum(row["candidate_action"] == "null" for row in decisions)
    retains = sum(row["candidate_action"] == "retain" for row in decisions)
    exception_supported = sum(
        row["candidate_action"] != "unresolved" for row in form_exceptions
    )
    exact_topology = sum(
        row["topology_status"] == "exact_nested_partial_parent" for row in topology
    )
    exact_scopes = sum(
        str(row["scope_status"]).startswith("exact_") for row in predicate_scopes
    )
    text = f"""# B07 official/source-semantic evidence result

Status: **B07_EXTERNAL_SEMANTIC_EVIDENCE_REPAIRED**.

The official evidence supports all {supported}/{len(decisions)} observed
flag/code/label signatures: {retains} retain semantics and {nulls} null
semantics.  This is not a populated or approved release contract.

## Independent source proof

- {len(source_manifest)} official source identities are hash-bound, including
  20 annual Finance ZIPs and their members.
- Every annual ZIP passed central-directory and member CRC validation.
- The annual form/part matrix has 60 year-by-form rows.
- All {len(topology)} observed code-6 rows were tested as nested partial-parent
  records; {exact_topology} have exact upstream-parent topology.
- All {len(form_exceptions)} partial rows with `FORM_F=-2` were inspected
  against exact Stage04 Finance tables; {exception_supported} are mechanically
  resolved and {len(form_exceptions) - exception_supported} remain unresolved.
- All {exact_scopes}/{len(predicate_scopes)} distinct
  `year + PRCH_F + FORM_F` exception-predicate scopes have one exact action and
  no mixed observed Finance form.

## Supported scientific semantics

- Non-Finance `-2` and parent code `1` rows are retained.
- Non-Finance child code `2` rows null only exact scalar-wide fields belonging
  to that component.
- Every `PRCHTP_F` code is retained because it describes system topology and is
  not itself a component payload.
- Finance `PRCH_F=-2/1` rows are retained.
- Finance full-child codes `2` and `4` null exact Finance payload fields.
- Finance partial codes `3`, `5`, and `6` null only annual form parts reported
  at the parent/reporting entity; their separately reported revenue, expense,
  scholarship, and other child parts remain unchanged.
- The private for-profit parent-only scope is Parts A and B for 2004-2013,
  adds separate Part F for 2014-2019, and adds Part G for 2020-2023.  The
  generator does not back-project the post-2013 Part F structure.

## Exact B05 target binding

- Bind only exact countersigned B05 `variable_id -> analysis_column`
  identities; do not infer target columns from names.
- Direct Finance columns require exact annual Access table, column, form, and
  part identity.
- For partial Finance codes, derived `DRVF` targeting is limited exactly to
  `F1EQUITR`, `F2EQUITR`, and `F3EQUITR` identities.  No other derived field
  is targeted without separate exact evidence.
- `Panels/v2/panel_long_dimensioned_2004_2023.parquet` remains raw and
  PRCH-unmodified.  No B07 rule may target the dimensioned lane.
- If exact B05 binding produces no scalar-wide target columns, the operational
  result is retain/no-op.  Never invent a target or emit a null action with an
  empty target list.

## Remaining release blockers

1. The author must countersign the exact decision-register hash.
2. Canonical B05 must first be countersigned so the semantic scopes can be
   expanded to exact analysis columns.
3. The expansion must prove one-to-one `variable_id -> analysis_column`
   binding, exact annual form/part membership, complete row-predicate coverage,
   no overlap, and no dimensioned-lane targets.
4. Direct Finance parts must be bound through exact Access metadata/table
   identity.  Derived `DRVF` fields are not classified by names alone; the
   partial target is limited to the exact equity-ratio identities documented
   in the binding requirements.

The canonical `contracts/prch_policy.csv` SHA-256 remained
`{canonical_hash}`.

Always return: **B07_CONTRACT_UNCHANGED**, **FULL_BUILD_NOT_RUN**,
**RELEASE_STILL_BLOCKED**.
"""
    path.write_text(text, encoding="utf-8", newline="\n")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, required=True)
    parser.add_argument("--legacy-root", type=Path, required=True)
    parser.add_argument("--official-root", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo = args.repo_root.resolve()
    legacy = args.legacy_root.resolve()
    official = args.official_root.resolve()
    out_dir = args.out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    decision_input = (
        repo
        / "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
        "B07_PRCH_DECISION_REGISTER.csv"
    )
    observed_input = (
        repo
        / "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
        "B07_PRCH_OBSERVED_CODE_EVIDENCE.csv"
    )
    stage04_input = (
        repo
        / "Artifacts/review_v2/stage04_full_candidates_2026-07-24/"
        "source_columns_stage04_candidate.csv"
    )
    b05_input = (
        repo
        / "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24/"
        "B05_IDENTITY_MAPPING.csv"
    )
    canonical = repo / "contracts/prch_policy.csv"
    generator_path = Path(__file__).resolve()
    for path in (decision_input, observed_input, stage04_input, b05_input, canonical):
        if not path.is_file():
            raise B07EvidenceError(f"missing required input: {path}")

    canonical_paths = sorted(
        (path for path in (repo / "contracts").iterdir() if path.is_file()),
        key=lambda path: path.name.casefold(),
    )
    canonical_pre_hashes = {
        path.relative_to(repo).as_posix(): sha256_file(path)
        for path in canonical_paths
    }
    source_manifest = official_source_manifest(official)
    matrix = form_part_matrix(source_manifest, official)
    decisions = build_decision_register(read_csv(decision_input))
    if len(decisions) != 55:
        raise B07EvidenceError(f"expected 55 B07 decision signatures, got {len(decisions)}")
    form_exceptions = build_form_exceptions(
        legacy_root=legacy,
        stage04_path=stage04_input,
    )
    predicate_scopes = summarize_form_f_predicate_scopes(form_exceptions)
    mixed_scopes = [
        row
        for row in predicate_scopes
        if not str(row["scope_status"]).startswith("exact_")
    ]
    if mixed_scopes:
        identities = [
            f"{row['year']}:{row['prch_f']}:{row['form_f']}"
            for row in mixed_scopes
        ]
        raise B07EvidenceError(
            "FORM_F=-2 predicate scope mixes actions/forms: "
            + "|".join(identities)
        )
    topology = build_topology_proof(legacy)
    target_requirements = build_target_requirements(b05_input)

    inputs: list[dict[str, object]] = [
        {
            "input_kind": "repository_evidence",
            "path": path.relative_to(repo).as_posix(),
            "byte_size": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in (
            decision_input,
            observed_input,
            stage04_input,
            b05_input,
            canonical,
        )
    ]
    inputs.extend(
        {
            "input_kind": str(row["source_kind"]),
            "path": f"official_sources/{row['relative_path']}",
            "byte_size": row["byte_size"],
            "sha256": row["sha256"],
        }
        for row in source_manifest
        if row["source_kind"] in {"official_html", "official_zip"}
    )
    inputs.sort(key=lambda row: (str(row["input_kind"]), str(row["path"]).casefold()))
    write_csv(
        out_dir / "B07_INPUT_MANIFEST.csv",
        ("input_kind", "path", "byte_size", "sha256"),
        inputs,
    )
    input_manifest_sha256 = sha256_file(out_dir / "B07_INPUT_MANIFEST.csv")
    write_csv(
        out_dir / "B07_OFFICIAL_SOURCE_MANIFEST.csv",
        (
            "source_id",
            "year",
            "source_kind",
            "url",
            "relative_path",
            "member_name",
            "byte_size",
            "sha256",
            "container_sha256",
            "integrity_status",
            "semantic_use",
        ),
        source_manifest,
    )
    write_csv(
        out_dir / "B07_FORM_PART_MATRIX.csv",
        tuple(matrix[0]),
        matrix,
    )
    write_csv(
        out_dir / "B07_SEMANTIC_DECISION_REGISTER.csv",
        tuple(decisions[0]),
        decisions,
    )
    write_csv(
        out_dir / "B07_FORM_F_EXCEPTION_EVIDENCE.csv",
        (
            "contract_id",
            "year",
            "unitid",
            "prch_f",
            "form_f",
            "idx_f",
            "nonempty_finance_value_count",
            "exact_nonempty_table_identities",
            "inferred_exact_form_from_table_identity",
            "candidate_action",
            "resolution",
            "source_csv_sha256s",
            "flags_csv_sha256",
            "candidate_status",
        ),
        form_exceptions,
    )
    write_csv(
        out_dir / "B07_FORM_F_PREDICATE_SCOPE_PROOF.csv",
        (
            "contract_id",
            "year",
            "prch_f",
            "form_f",
            "row_count",
            "candidate_actions",
            "resolutions",
            "inferred_exact_forms",
            "nonempty_row_count",
            "nonempty_finance_value_count",
            "scope_status",
        ),
        predicate_scopes,
    )
    write_csv(
        out_dir / "B07_FINANCE_TOPOLOGY_PROOF.csv",
        (
            "contract_id",
            "year",
            "unitid",
            "upstream_parent_unitid",
            "upstream_parent_code",
            "downstream_child_count",
            "topology_status",
            "pcf_f",
            "form_f",
            "downstream_child_unitids",
            "flags_csv_sha256",
        ),
        topology,
    )
    write_csv(
        out_dir / "B07_TARGET_BINDING_REQUIREMENTS.csv",
        tuple(target_requirements[0]),
        target_requirements,
    )
    canonical_post_hashes = {
        path.relative_to(repo).as_posix(): sha256_file(path)
        for path in canonical_paths
    }
    canonical_proof = [
        {
            "path": path,
            "pre_sha256": canonical_pre_hashes[path],
            "post_sha256": canonical_post_hashes[path],
            "unchanged": str(
                canonical_pre_hashes[path] == canonical_post_hashes[path]
            ).lower(),
        }
        for path in canonical_pre_hashes
    ]
    changed_contracts = [
        row["path"] for row in canonical_proof if row["unchanged"] != "true"
    ]
    if changed_contracts:
        raise B07EvidenceError(
            "B07 generator altered canonical contracts: "
            + "|".join(str(path) for path in changed_contracts)
        )
    write_csv(
        out_dir / "B07_CANONICAL_HASH_PROOF.csv",
        ("path", "pre_sha256", "post_sha256", "unchanged"),
        canonical_proof,
    )
    write_result(
        out_dir / "B07_RESULT.md",
        decisions=decisions,
        form_exceptions=form_exceptions,
        predicate_scopes=predicate_scopes,
        topology=topology,
        source_manifest=source_manifest,
        canonical_hash=canonical_post_hashes[
            canonical.relative_to(repo).as_posix()
        ],
    )

    summary = {
        "status": "B07_EXTERNAL_SEMANTIC_EVIDENCE_REPAIRED",
        "decision_signatures": len(decisions),
        "supported_decision_signatures": sum(
            row["candidate_action"] != "unresolved" for row in decisions
        ),
        "official_source_identities": len(source_manifest),
        "form_part_rows": len(matrix),
        "form_f_exceptions": len(form_exceptions),
        "unresolved_form_f_exceptions": sum(
            row["candidate_action"] == "unresolved" for row in form_exceptions
        ),
        "form_f_predicate_scopes": len(predicate_scopes),
        "form_f_predicate_scope_failures": len(mixed_scopes),
        "code6_topology_rows": len(topology),
        "code6_topology_failures": sum(
            row["topology_status"] != "exact_nested_partial_parent"
            for row in topology
        ),
        "canonical_prch_policy_sha256": canonical_post_hashes[
            canonical.relative_to(repo).as_posix()
        ],
        "canonical_contract_files_proven_unchanged": len(canonical_proof),
        "canonical_contract_changed": bool(changed_contracts),
        "input_manifest_sha256": input_manifest_sha256,
        "generator_sha256": sha256_file(generator_path),
        "release_status": "RELEASE_STILL_BLOCKED",
    }
    (out_dir / "B07_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    generator_sha256 = sha256_file(generator_path)
    generator_commit_id = generator_commit(repo, generator_path)
    artifact_rows = []
    for path in sorted(out_dir.iterdir(), key=lambda item: item.name.casefold()):
        if not path.is_file() or path.name == "B07_ARTIFACT_MANIFEST.csv":
            continue
        artifact_rows.append(
            {
                "path": path.name,
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
                "generator_commit": generator_commit_id,
                "generator_sha256": generator_sha256,
                "input_manifest_sha256": input_manifest_sha256,
            }
        )
    write_csv(
        out_dir / "B07_ARTIFACT_MANIFEST.csv",
        (
            "path",
            "byte_size",
            "sha256",
            "generator_commit",
            "generator_sha256",
            "input_manifest_sha256",
        ),
        artifact_rows,
    )
    final_canonical_hashes = {
        path.relative_to(repo).as_posix(): sha256_file(path)
        for path in canonical_paths
    }
    if final_canonical_hashes != canonical_pre_hashes:
        raise B07EvidenceError("canonical contract hashes changed during finalization")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
