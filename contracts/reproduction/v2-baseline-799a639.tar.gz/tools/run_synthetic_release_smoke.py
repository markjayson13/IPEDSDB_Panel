#!/usr/bin/env python3
"""Run a fresh 2004-2023 synthetic Access integration build.

This is intentionally a standalone integration runner, not release authority.
It creates an isolated Git repository and external data root, binds all
fixture contracts and archives in a synthetic-only scope receipt, runs the
shared Stage 01-through-QA01 implementation in its existing development
namespace, and invokes a dedicated synthetic verifier.  It never calls a
production contract validator, release gate, evidence receipt verifier, or
public bundle publisher.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[1]
CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
YEARS = list(range(2004, 2024))
YEAR_SPEC = "2004:2023"
ACCESS_FIXTURE = REPO_ROOT / "tests" / "fixtures" / "access_db" / "synthetic_ipeds.mdb"
ACCESS_FIXTURE_SHA256 = "0230aabb99cb9f1362c4634e8278cbe19367df2ab6bf68633f558ccac71c8c13"
SYNTHETIC_SCOPE_RECEIPT = Path("Artifacts/synthetic_release_smoke_scope.json")
PRODUCTION_BINDING_ENVIRONMENT = (
    "CONTAINER_IMAGE_DIGEST",
    "CONTAINER_IMAGE_REVISION",
    "CONTAINER_REQUIREMENTS_LOCK_SHA256",
    "CONTRACT_REVIEW_EVIDENCE_BUNDLE",
)
SYNTHETIC_CONTRACT_PATHS = (
    "contracts/panel_spec.toml",
    "contracts/source_releases.csv",
    "contracts/table_grain.csv",
    "contracts/source_columns.csv",
    "contracts/analysis_schema.csv",
    "contracts/discrete_families.csv",
    "contracts/prch_policy.csv",
    "contracts/metadata_backfill_approvals.csv",
    "contracts/dictionary_ambiguity_overrides.csv",
    "contracts/external_benchmarks.csv",
)


def safe_git_environment() -> dict[str, str]:
    """Return a minimal Git environment without caller-supplied indirection."""

    environment = {
        name: os.environ[name]
        for name in ("LANG", "LC_ALL", "PATH", "TEMP", "TMP", "TMPDIR")
        if name in os.environ
    }
    environment.update(
        {
            "GIT_ATTR_NOSYSTEM": "1",
            "GIT_CONFIG_COUNT": "0",
            "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_NO_REPLACE_OBJECTS": "1",
            "GIT_OPTIONAL_LOCKS": "0",
            "HOME": "/nonexistent",
        }
    )
    return environment


def run_git(repo: Path, *arguments: str) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=repo,
        env=safe_git_environment(),
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"git {' '.join(arguments)} failed: {completed.stderr.strip()}"
        )
    return completed.stdout.strip()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run(
    command: list[str],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
    timeout: int = 900,
) -> subprocess.CompletedProcess[str]:
    print("+", " ".join(command), flush=True)
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )
    print(completed.stdout, end="", flush=True)
    if completed.returncode != 0:
        raise RuntimeError(
            f"command failed with exit {completed.returncode}: {' '.join(command)}"
        )
    return completed


def deterministic_zip(path: Path, members: dict[str, bytes]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, payload in sorted(members.items()):
            info = zipfile.ZipInfo(name, date_time=(2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, payload)


def copy_repository(destination: Path) -> None:
    """Materialize exactly ``HEAD`` without ambient tracked or untracked dirt."""

    if destination.exists():
        raise RuntimeError(f"repository destination already exists: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    source = REPO_ROOT.expanduser().resolve(strict=True)
    commit = run_git(source, "rev-parse", "--verify", "HEAD^{commit}")
    tree = run_git(source, "rev-parse", "--verify", f"{commit}^{{tree}}")
    if len(commit) != 40 or len(tree) != 40:
        raise RuntimeError(f"repository HEAD is not a full commit id: {commit!r}")

    with tempfile.TemporaryDirectory(
        prefix="ipedsdb-smoke-source-",
        dir=destination.parent,
    ) as temporary:
        checkout = Path(temporary) / "checkout"
        checkout.mkdir()
        run_git(checkout, "init", "--quiet")
        run_git(
            checkout,
            "-c",
            "protocol.file.allow=always",
            "fetch",
            "--quiet",
            "--depth=1",
            "--no-tags",
            source.as_uri(),
            commit,
        )
        run_git(checkout, "checkout", "--detach", "--quiet", commit)
        if (
            run_git(checkout, "rev-parse", "--verify", "HEAD^{commit}") != commit
            or run_git(checkout, "rev-parse", "--verify", "HEAD^{tree}") != tree
        ):
            raise RuntimeError(
                "isolated synthetic source differs from the requested commit/tree"
            )
        shutil.rmtree(checkout / ".git")
        shutil.copytree(checkout, destination, symlinks=True)


def write_contracts(repo: Path, access_zip: Path, documentation_zip: Path) -> None:
    contracts = repo / "contracts"
    panel_spec = contracts / "panel_spec.toml"
    panel_text = panel_spec.read_text(encoding="utf-8")
    if 'status = "release-candidate"' not in panel_text or "release_ready = false" not in panel_text:
        raise RuntimeError(
            "synthetic integration requires the copied panel contract to remain "
            "release-candidate and not release-ready"
        )

    source_rows = []
    for year in YEARS:
        source_rows.append(
            {
                "contract_id": CONTRACT_ID,
                "year": year,
                "academic_year_label": f"{year}-{(year + 1) % 100:02d}",
                "release_type": "Final",
                "release_date_text": "Synthetic fixture",
                "access_url": "https://fixture.invalid/access.zip",
                "access_filename": "access.zip",
                "expected_access_sha256": sha256_file(access_zip),
                "access_size_bytes": access_zip.stat().st_size,
                "documentation_url": "https://fixture.invalid/documentation.zip",
                "documentation_filename": "documentation.zip",
                "expected_documentation_sha256": sha256_file(documentation_zip),
                "documentation_size_bytes": documentation_zip.stat().st_size,
                "lock_status": "approved",
                "source": "Repository-generated synthetic Access fixture",
                "approved_at": "2026-07-16",
                "review_note": "Synthetic integration evidence; never valid for a public data release.",
            }
        )
    pd.DataFrame(source_rows).to_csv(contracts / "source_releases.csv", index=False)

    grain_rows = [
        {
            "contract_id": CONTRACT_ID,
            "decision_id": "SYNTHETIC-GRAIN-HD",
            "year_start": 2004,
            "year_end": 2023,
            "source_file": "HD",
            "access_table_pattern": "HD",
            "grain_class": "scalar",
            "unit_key_columns": "UNITID",
            "dimension_columns": "",
            "measure_selection_rule": "source_columns_contract",
            "expected_rows_per_unit": "1",
            "aggregation_policy": "exact_duplicate_only",
            "source_evidence": "Synthetic fixture HD schema.",
            "review_note": "One institution row per year.",
            "reviewed": "true",
        },
        {
            "contract_id": CONTRACT_ID,
            "decision_id": "SYNTHETIC-GRAIN-C-A",
            "year_start": 2004,
            "year_end": 2023,
            "source_file": "C_A",
            "access_table_pattern": "C_A",
            "grain_class": "dimensioned",
            "unit_key_columns": "UNITID|CIPCODE",
            "dimension_columns": "CIPCODE",
            "measure_selection_rule": "source_columns_contract",
            "expected_rows_per_unit": "many",
            "aggregation_policy": "exact_duplicate_only",
            "source_evidence": "Synthetic fixture C_A schema.",
            "review_note": "Two CIP rows per institution and year.",
            "reviewed": "true",
        },
    ]
    pd.DataFrame(grain_rows).to_csv(contracts / "table_grain.csv", index=False)

    scalar_columns = [
        "UNITID",
        "INSTNM",
        "OPEID",
        "SECTOR",
        "CONTROL",
        "ICLEVEL",
        "PRCH_F",
        "ENROLLMENT",
        "COMPLETIONS",
        "STAFFING",
        "TUITION",
        "FINANCE_TOTAL",
        "FINANCE_RETAIN",
    ]
    source_column_rows = []
    for column in scalar_columns:
        source_column_rows.append(
            {
                "contract_id": CONTRACT_ID,
                "decision_id": f"FIXTURE-COLUMN-HD-{column}",
                "year_start": 2004,
                "year_end": 2023,
                "source_file": "HD",
                "access_table_pattern": "HD",
                "column_name": column,
                "role": "identifier" if column == "UNITID" else "measure",
                "canonical_dimension": "",
                "exclusion_reason": "",
                "source_evidence": "Synthetic fixture HD schema.",
                "review_note": "Explicit synthetic release-smoke classification.",
                "reviewed": "true",
            }
        )
    for column, role, dimension in (
        ("UNITID", "identifier", ""),
        ("CIPCODE", "dimension", "cip_code"),
        ("CTOTALT", "measure", ""),
    ):
        source_column_rows.append(
            {
                "contract_id": CONTRACT_ID,
                "decision_id": f"FIXTURE-COLUMN-C-A-{column}",
                "year_start": 2004,
                "year_end": 2023,
                "source_file": "C_A",
                "access_table_pattern": "C_A",
                "column_name": column,
                "role": role,
                "canonical_dimension": dimension,
                "exclusion_reason": "",
                "source_evidence": "Synthetic fixture C_A schema.",
                "review_note": "Explicit synthetic release-smoke classification.",
                "reviewed": "true",
            }
        )
    pd.DataFrame(source_column_rows).to_csv(contracts / "source_columns.csv", index=False)

    logical_types = {
        "INSTNM": "free text",
        "OPEID": "identifier string",
        "SECTOR": "categorical string",
        "CONTROL": "categorical string",
        "ICLEVEL": "categorical string",
        "PRCH_F": "categorical string",
        "ENROLLMENT": "integer",
        "COMPLETIONS": "integer",
        "STAFFING": "integer",
        "TUITION": "float",
        "FINANCE_TOTAL": "float",
        "FINANCE_RETAIN": "float",
    }
    analysis_rows = [
        {
            "contract_id": CONTRACT_ID,
            "analysis_column": variable,
            "logical_type": logical_type,
            "source_variables": variable,
            "transformation": "identity",
            "inclusion_reason": "Synthetic release-smoke governed variable.",
            "first_year": 2004,
            "last_year": 2023,
            "nullable": "true",
            "status": "approved",
        }
        for variable, logical_type in logical_types.items()
    ]
    pd.DataFrame(analysis_rows).to_csv(contracts / "analysis_schema.csv", index=False)

    discrete_rows = []
    for variable in ("INSTNM", "OPEID", "SECTOR", "CONTROL", "ICLEVEL", "PRCH_F"):
        discrete_rows.append(
            {
                "contract_id": CONTRACT_ID,
                "source_file": "HD",
                "family_id": f"DIRECT_{variable}",
                "component_varname": variable,
                "component_code": "direct",
                "semantic_type": "not_collapsible",
                "active_tokens": "1|yes|true",
                "inactive_tokens": "0|no|false",
                "missing_tokens": ".|<blank>",
                "output_column": "",
                "output_type": "categorical string",
                "multi_active_policy": "preserve",
                "drop_components": "false",
                "source_evidence": "Synthetic fixture dictionary.",
                "review_note": "Direct categorical value is intentionally preserved.",
            }
        )
    pd.DataFrame(discrete_rows).to_csv(contracts / "discrete_families.csv", index=False)

    pd.DataFrame(
        [
            {
                "rule_id": "synthetic-finance-child",
                "year_start": 2004,
                "year_end": 2023,
                "flag": "PRCH_F",
                "code": 4,
                "action": "null",
                "target_columns": "FINANCE_TOTAL",
                "row_predicate": json.dumps({"CONTROL": 1}, separators=(",", ":")),
                "accounting_standard": "Synthetic fixture",
                "form": "Synthetic HD",
                "part": "Finance",
                "review_status": "approved",
                "source_reference": "Synthetic Access CODES table and fixture generator.",
                "rationale": "Exercise predicate-specific parent-child nulling.",
            }
        ]
    ).to_csv(contracts / "prch_policy.csv", index=False)

    for path in (
        contracts / "metadata_backfill_approvals.csv",
        contracts / "dictionary_ambiguity_overrides.csv",
    ):
        header = path.read_text(encoding="utf-8").splitlines()[0]
        path.write_text(header + "\n", encoding="utf-8")

    evidence = repo / "Artifacts" / "synthetic_benchmark_evidence.csv"
    evidence.parent.mkdir(parents=True, exist_ok=True)
    evidence_rows = []
    benchmark_specs = [
        ("institution_counts", "distinct_unitid", "UNITID", 1),
        ("enrollment", "sum", "ENROLLMENT", 100),
        ("completions", "sum", "COMPLETIONS", 10),
        ("staffing", "sum", "STAFFING", 5),
        ("tuition_price", "mean", "TUITION", 10000),
        ("finance", "sum", "FINANCE_RETAIN", 200),
    ]
    for year in (2004, 2013, 2023):
        for family, metric, variable, expected in benchmark_specs:
            evidence_rows.append(
                {
                    "year": year,
                    "component_family": family,
                    "metric": metric,
                    "variable": variable,
                    "expected_value": expected,
                }
            )
    pd.DataFrame(evidence_rows).to_csv(evidence, index=False)
    evidence_sha = sha256_file(evidence)
    benchmark_rows = []
    for row in evidence_rows:
        benchmark_rows.append(
            {
                "benchmark_id": f"synthetic-{row['component_family']}-{row['year']}",
                "contract_id": CONTRACT_ID,
                "artifact": "Panels/v2/panel_clean_prch_2004_2023.parquet",
                "year": row["year"],
                "metric": row["metric"],
                "variable": row["variable"],
                "filters": "{}",
                "component_family": row["component_family"],
                "expected_value": row["expected_value"],
                "absolute_tolerance": 0,
                "relative_tolerance": 0,
                "tolerance_rationale": "Exact deterministic synthetic fixture value.",
                "official_source": "https://nces.ed.gov/ipeds/",
                "source_date_or_version": "synthetic-fixture-v1",
                "source_evidence_path": "Artifacts/synthetic_benchmark_evidence.csv",
                "source_evidence_sha256": evidence_sha,
                "review_status": "approved",
                "reviewer": "Synthetic release-smoke fixture",
                "review_date": "2026-07-16",
                "definition": "Deterministic value generated by the synthetic Access fixture.",
                "notes": "Integration evidence only; not an external-validity claim.",
            }
        )
    pd.DataFrame(benchmark_rows).to_csv(contracts / "external_benchmarks.csv", index=False)


def write_synthetic_scope_receipt(
    repo: Path,
    access_zip: Path,
    documentation_zip: Path,
) -> Path:
    receipt_path = repo / SYNTHETIC_SCOPE_RECEIPT
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 1,
        "scope_kind": "synthetic_integration_only",
        "pipeline_mode": "development",
        "production_authority": False,
        "public_promotion_authorized": False,
        "contract_id": CONTRACT_ID,
        "years": YEARS,
        "access_fixture_sha256": ACCESS_FIXTURE_SHA256,
        "contract_sha256": {
            relative: sha256_file(repo / relative)
            for relative in SYNTHETIC_CONTRACT_PATHS
        },
        "source_archives": {
            "access.zip": sha256_file(access_zip),
            "documentation.zip": sha256_file(documentation_zip),
        },
    }
    receipt_path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return receipt_path


def initialize_repository(repo: Path) -> None:
    run(["git", "init", "-q"], cwd=repo)
    run(["git", "config", "user.email", "synthetic-fixture@example.invalid"], cwd=repo)
    run(["git", "config", "user.name", "Synthetic Release Smoke"], cwd=repo)
    run(["git", "add", "."], cwd=repo)
    run(["git", "commit", "-q", "-m", "synthetic release fixture"], cwd=repo)


def prepare_cached_downloads(root: Path, access_zip: Path, documentation_zip: Path) -> None:
    for year in YEARS:
        downloads = root / "Raw_Access_Databases" / str(year) / "downloads"
        downloads.mkdir(parents=True, exist_ok=True)
        shutil.copy2(access_zip, downloads / "access.zip")
        shutil.copy2(documentation_zip, downloads / "documentation.zip")


def execute(workspace: Path) -> None:
    if sha256_file(ACCESS_FIXTURE) != ACCESS_FIXTURE_SHA256:
        raise RuntimeError("synthetic Access fixture hash does not match its reviewed generator record")

    repo = workspace / "repo"
    root = workspace / "IPEDSDB_ROOT"
    fixture_cache = workspace / "fixture-cache"
    copy_repository(repo)
    root.mkdir(parents=True)

    access_zip = fixture_cache / "access.zip"
    documentation_zip = fixture_cache / "documentation.zip"
    deterministic_zip(access_zip, {"synthetic_ipeds.mdb": ACCESS_FIXTURE.read_bytes()})
    deterministic_zip(
        documentation_zip,
        {"README.txt": b"Synthetic IPEDS metadata fixture. Not NCES data.\n"},
    )
    write_contracts(repo, access_zip, documentation_zip)
    scope_receipt = write_synthetic_scope_receipt(repo, access_zip, documentation_zip)
    initialize_repository(repo)
    prepare_cached_downloads(root / "development", access_zip, documentation_zip)

    environment = os.environ.copy()
    for variable in PRODUCTION_BINDING_ENVIRONMENT:
        environment.pop(variable, None)
    environment.update(
        {
            "IPEDSDB_ROOT": str(root),
            "PYTHON_BIN": sys.executable,
            "PYTEST_DISABLE_PLUGIN_AUTOLOAD": "1",
            "YEARS": YEAR_SPEC,
        }
    )
    run(
        [
            sys.executable,
            "Scripts/00_run_all.py",
            "--root",
            str(root),
            "--years",
            YEAR_SPEC,
            "--pipeline-mode",
            "development",
            "--run-cleaning",
            "--run-qaqc",
        ],
        cwd=repo,
        env=environment,
        timeout=900,
    )
    run(
        [
            sys.executable,
            "Scripts/QA_QC/26_validate_synthetic_release_smoke.py",
            "--repo",
            str(repo),
            "--root",
            str(root),
            "--years",
            YEAR_SPEC,
            "--scope-receipt",
            str(scope_receipt),
        ],
        cwd=repo,
        env=environment,
        timeout=900,
    )
    print(f"Synthetic integration smoke passed: root={root}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--workspace",
        default=None,
        help="Optional empty directory to keep for inspection; default uses a removed temporary directory.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.workspace:
        workspace = Path(args.workspace).expanduser().resolve()
        if workspace.exists() and any(workspace.iterdir()):
            raise SystemExit(f"Workspace must be absent or empty: {workspace}")
        workspace.mkdir(parents=True, exist_ok=True)
        execute(workspace)
        return
    with tempfile.TemporaryDirectory(prefix="ipedsdb-synthetic-release-") as temporary:
        execute(Path(temporary))


if __name__ == "__main__":
    main()
