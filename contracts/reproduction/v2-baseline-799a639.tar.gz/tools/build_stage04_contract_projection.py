#!/usr/bin/env python3
"""Build compact, losslessly auditable Stage 04 contract projections.

The exact Stage 04 candidate package contains one row per year/table identity.
That representation is intentionally verbose and exceeds the repository's
tracked-file size guard for ``source_columns.csv``.  This review-only tool
projects those exact candidates into non-overlapping contiguous year ranges.

The projection is conservative:

* ``source_file`` and ``column_name`` remain exact;
* candidate years are exact before they are combined into contiguous ranges;
* an Access-table wildcard is used only when every exact table identity in the
  same year/source/column scope has identical scientific semantics;
* every exact input identity is resolved back through the projection and must
  have exactly one match with no semantic drift;
* all-empty ``unknown`` identities remain visible as explicit, unreviewed
  ``intentionally_excluded`` proposals that require an author countersign; and
* canonical contracts are read only and rehashed after artifact generation.

The tool has no code path that writes canonical contracts.
"""
from __future__ import annotations

import argparse
import csv
import fnmatch
import hashlib
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Iterable, Sequence


REPO_ROOT = Path(__file__).resolve().parents[1]
CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
MAX_TRACKED_FILE_BYTES = 5 * 1024 * 1024
WILDCARD_CHARACTERS = frozenset("*?[")

TABLE_FIELDS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "grain_class",
    "unit_key_columns",
    "dimension_columns",
    "measure_selection_rule",
    "expected_rows_per_unit",
    "aggregation_policy",
    "source_evidence",
    "review_note",
    "reviewed",
]

SOURCE_FIELDS = [
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "column_name",
    "role",
    "canonical_dimension",
    "exclusion_reason",
    "source_evidence",
    "review_note",
    "reviewed",
]

UNRESOLVED_FIELDS = [
    "decision_id",
    "year",
    "source_file",
    "access_table_name",
    "column_name",
    "nonempty_count",
    "metadata_match_status",
    "unresolved_reason",
    "candidate_role",
    "required_decision",
    "review_status",
    "review_note",
]

TABLE_SEMANTIC_FIELDS = (
    "grain_class",
    "unit_key_columns",
    "dimension_columns",
    "measure_selection_rule",
    "expected_rows_per_unit",
    "aggregation_policy",
)

SOURCE_SEMANTIC_FIELDS = (
    "role",
    "canonical_dimension",
    "exclusion_reason",
)

ALLOWED_TABLE_GRAINS = {"scalar", "dimensioned"}
ALLOWED_SOURCE_ROLES = {
    "identifier",
    "dimension",
    "measure",
    "imputation",
    "metadata",
    "excluded",
    "unknown",
}

PROPOSED_EMPTY_EXCLUSION_REASON = (
    "All source values are empty and exact source metadata is absent; "
    "intentionally excluded from panel cells without inferring semantics."
)

INPUT_MANIFEST_FIELDS = [
    "input_role",
    "path",
    "byte_size",
    "sha256",
    "row_count",
]

PROPOSED_EXCLUSION_FIELDS = [
    "original_decision_id",
    "unresolved_decision_id",
    "year",
    "source_file",
    "access_table_name",
    "column_name",
    "nonempty_count",
    "metadata_match_status",
    "unresolved_reason",
    "original_role",
    "proposed_role",
    "proposed_exclusion_reason",
    "source_candidate_sha256",
    "required_author_action",
    "author_decision_status",
]

SCOPE_DIAGNOSTIC_FIELDS = [
    "projection_type",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "column_name",
    "access_table_pattern",
    "wildcard_used",
    "exact_identity_count",
    "exact_table_identities",
    "semantic_sha256",
    "wildcard_safety_status",
]

RESOLUTION_PROOF_FIELDS = [
    "projection_type",
    "year",
    "source_file",
    "access_table_name",
    "column_name",
    "input_decision_id",
    "matched_projection_decision_id",
    "match_count",
    "expected_semantics_sha256",
    "resolved_semantics_sha256",
    "resolution_status",
    "proposed_change",
]

CANONICAL_HASH_FIELDS = [
    "path",
    "sha256_before",
    "sha256_after",
    "unchanged",
]

ARTIFACT_MANIFEST_FIELDS = [
    "path",
    "byte_size",
    "sha256",
    "row_count",
    "artifact_role",
    "generator_sha256",
    "input_manifest_sha256",
    "canonical_table_grain_pre_sha256",
    "canonical_source_columns_pre_sha256",
]


class ProjectionBuildError(ValueError):
    """The exact Stage 04 candidates cannot be safely compacted."""


class ResolutionStats:
    """Exact-identity resolution counts."""

    def __init__(
        self,
        *,
        identity_count: int,
        missing: int,
        ambiguous: int,
        semantic_drift: int,
        proposed_changes: int,
    ) -> None:
        self.identity_count = identity_count
        self.missing = missing
        self.ambiguous = ambiguous
        self.semantic_drift = semantic_drift
        self.proposed_changes = proposed_changes


class BuildResult:
    """Paths and proof counts emitted by one projection build."""

    def __init__(
        self,
        *,
        table_projection_path: Path,
        source_projection_path: Path,
        proposed_exclusions_path: Path,
        scope_diagnostics_path: Path,
        resolution_proof_path: Path,
        input_manifest_path: Path,
        canonical_hash_path: Path,
        summary_path: Path,
        countersign_path: Path,
        artifact_manifest_path: Path,
        artifact_paths: Sequence[Path],
        table_exact_identity_count: int,
        table_projection_count: int,
        source_exact_identity_count: int,
        source_projection_count: int,
        proposed_exclusion_identity_count: int,
        table_stats: ResolutionStats,
        source_stats: ResolutionStats,
    ) -> None:
        self.table_projection_path = table_projection_path
        self.source_projection_path = source_projection_path
        self.proposed_exclusions_path = proposed_exclusions_path
        self.scope_diagnostics_path = scope_diagnostics_path
        self.resolution_proof_path = resolution_proof_path
        self.input_manifest_path = input_manifest_path
        self.canonical_hash_path = canonical_hash_path
        self.summary_path = summary_path
        self.countersign_path = countersign_path
        self.artifact_manifest_path = artifact_manifest_path
        self.artifact_paths = tuple(artifact_paths)
        self.table_exact_identity_count = table_exact_identity_count
        self.table_projection_count = table_projection_count
        self.source_exact_identity_count = source_exact_identity_count
        self.source_projection_count = source_projection_count
        self.proposed_exclusion_identity_count = proposed_exclusion_identity_count
        self.table_missing_count = table_stats.missing
        self.table_ambiguous_count = table_stats.ambiguous
        self.table_semantic_drift_count = table_stats.semantic_drift
        self.source_missing_count = source_stats.missing
        self.source_ambiguous_count = source_stats.ambiguous
        self.source_semantic_drift_count = source_stats.semantic_drift


def fail(message: str) -> None:
    raise ProjectionBuildError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def semantic_hash(values: Sequence[str]) -> str:
    return sha256_text("\x1f".join(values))


def stable_decision_id(prefix: str, *parts: object) -> str:
    token = "\x1f".join(str(part).strip().upper() for part in parts)
    return f"{prefix}-{sha256_text(token)[:12].upper()}"


def parse_nonnegative_int(value: object, *, label: str) -> int:
    token = str(value or "").strip()
    if not re.fullmatch(r"\d+", token):
        fail(f"{label} is not a nonnegative integer: {value!r}")
    return int(token)


def ensure_exact_token(value: object, *, label: str) -> str:
    token = str(value or "").strip().upper()
    if not token:
        fail(f"{label} is blank")
    wildcard = sorted(WILDCARD_CHARACTERS.intersection(token))
    if wildcard:
        fail(
            f"{label} contains wildcard characters and is not exact: "
            + "".join(wildcard)
        )
    return token


def _clean_row(row: dict[str, object]) -> dict[str, str]:
    return {str(key): str(value or "").strip() for key, value in row.items()}


def read_csv(
    path: Path,
    *,
    required_fields: Sequence[str],
    label: str,
    exact_fields: bool = True,
) -> tuple[list[str], list[dict[str, str]]]:
    if not path.is_file():
        fail(f"{label} does not exist: {path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fieldnames = list(reader.fieldnames or [])
        rows = [_clean_row(row) for row in reader]
    missing = [field for field in required_fields if field not in fieldnames]
    if missing:
        fail(f"{label} is missing columns: {', '.join(missing)}")
    if exact_fields and fieldnames != list(required_fields):
        fail(f"{label} field order differs from the Stage 04 candidate schema")
    return fieldnames, rows


def _write_csv_atomic(
    path: Path,
    fieldnames: Sequence[str],
    rows: Iterable[dict[str, object]],
) -> None:
    pending = path.with_name(path.name + ".tmp")
    with pending.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fieldnames),
            extrasaction="raise",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)
    os.replace(pending, path)


def _write_text_atomic(path: Path, value: str) -> None:
    pending = path.with_name(path.name + ".tmp")
    pending.write_text(value, encoding="utf-8")
    os.replace(pending, path)


def count_csv_rows(path: Path) -> int:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        next(reader, None)
        return sum(1 for _ in reader)


def _validate_exact_candidate_year(
    row: dict[str, str],
    *,
    label: str,
) -> int:
    start = parse_nonnegative_int(row["year_start"], label=f"{label} year_start")
    end = parse_nonnegative_int(row["year_end"], label=f"{label} year_end")
    if start != end:
        fail(f"{label} is not exact-year scoped: {start}..{end}")
    return start


def _normalize_table_semantics(row: dict[str, str]) -> tuple[str, ...]:
    return (
        row["grain_class"].casefold(),
        "|".join(
            token.strip().upper()
            for token in row["unit_key_columns"].split("|")
            if token.strip()
        ),
        "|".join(
            token.strip().upper()
            for token in row["dimension_columns"].split("|")
            if token.strip()
        ),
        row["measure_selection_rule"].casefold(),
        row["expected_rows_per_unit"].casefold(),
        row["aggregation_policy"].casefold(),
    )


def _normalize_source_semantics(
    row: dict[str, str],
    *,
    effective_unknown_exclusion: bool,
) -> tuple[str, str, str]:
    role = row["role"].casefold()
    if effective_unknown_exclusion and role == "unknown":
        return ("excluded", "", PROPOSED_EMPTY_EXCLUSION_REASON)
    return (
        role,
        row["canonical_dimension"].strip().upper(),
        row["exclusion_reason"].strip(),
    )


def validate_table_candidates(
    rows: Sequence[dict[str, str]],
) -> list[dict[str, str]]:
    if not rows:
        fail("table candidate is empty")
    output: list[dict[str, str]] = []
    identities: set[tuple[int, str, str]] = set()
    for row_number, raw in enumerate(rows, start=2):
        row = dict(raw)
        label = f"table candidate row {row_number}"
        if row["contract_id"] != CONTRACT_ID:
            fail(f"{label} has a different contract_id")
        year = _validate_exact_candidate_year(row, label=label)
        source_file = ensure_exact_token(row["source_file"], label=f"{label} source_file")
        table = ensure_exact_token(
            row["access_table_pattern"],
            label=f"{label} access_table_pattern",
        )
        identity = (year, source_file, table)
        if identity in identities:
            fail(
                "duplicate exact table candidate identity: "
                f"{year}:{source_file}:{table}"
            )
        identities.add(identity)
        semantics = _normalize_table_semantics(row)
        grain, keys, dimensions, selection, expected, aggregation = semantics
        if grain not in ALLOWED_TABLE_GRAINS:
            fail(f"{label} has unsupported grain_class {grain!r}")
        key_tokens = tuple(token for token in keys.split("|") if token)
        dimension_tokens = tuple(token for token in dimensions.split("|") if token)
        if len(key_tokens) != len(set(key_tokens)):
            fail(f"{label} repeats a unit-key token")
        if len(dimension_tokens) != len(set(dimension_tokens)):
            fail(f"{label} repeats a dimension token")
        if grain == "scalar" and (
            key_tokens != ("UNITID",)
            or dimension_tokens
            or expected != "1"
        ):
            fail(f"{label} has inconsistent scalar semantics")
        if grain == "dimensioned" and (
            key_tokens.count("UNITID") != 1
            or not dimension_tokens
            or set(key_tokens) != {"UNITID", *dimension_tokens}
            or expected not in {"many", "one_or_more"}
        ):
            fail(f"{label} has inconsistent dimensioned semantics")
        if selection != "source_columns_contract":
            fail(f"{label} has unsupported measure-selection semantics")
        if aggregation != "exact_duplicate_only":
            fail(f"{label} has unsupported aggregation semantics")
        if not row["source_evidence"] or not row["review_note"]:
            fail(f"{label} lacks evidence or review note")
        if row["reviewed"].casefold() not in {"true", "false"}:
            fail(f"{label} has an invalid reviewed value")
        row["year_start"] = row["year_end"] = str(year)
        row["source_file"] = source_file
        row["access_table_pattern"] = table
        for field, value in zip(TABLE_SEMANTIC_FIELDS, semantics):
            row[field] = value
        output.append(row)
    output.sort(
        key=lambda row: (
            int(row["year_start"]),
            row["source_file"],
            row["access_table_pattern"],
        )
    )
    return output


def validate_source_candidates(
    rows: Sequence[dict[str, str]],
    *,
    table_identities: set[tuple[int, str, str]],
) -> list[dict[str, str]]:
    if not rows:
        fail("source-column candidate is empty")
    output: list[dict[str, str]] = []
    identities: set[tuple[int, str, str, str]] = set()
    for row_number, raw in enumerate(rows, start=2):
        row = dict(raw)
        label = f"source candidate row {row_number}"
        if row["contract_id"] != CONTRACT_ID:
            fail(f"{label} has a different contract_id")
        year = _validate_exact_candidate_year(row, label=label)
        source_file = ensure_exact_token(row["source_file"], label=f"{label} source_file")
        table = ensure_exact_token(
            row["access_table_pattern"],
            label=f"{label} access_table_pattern",
        )
        column = ensure_exact_token(row["column_name"], label=f"{label} column_name")
        identity = (year, source_file, table, column)
        if identity in identities:
            fail(
                "duplicate exact source candidate identity: "
                f"{year}:{source_file}:{table}:{column}"
            )
        identities.add(identity)
        if (year, source_file, table) not in table_identities:
            fail(
                f"{label} has no exact table candidate identity: "
                f"{year}:{source_file}:{table}"
            )
        role, dimension, exclusion = _normalize_source_semantics(
            row,
            effective_unknown_exclusion=False,
        )
        if role not in ALLOWED_SOURCE_ROLES:
            fail(f"{label} has unsupported role {role!r}")
        if role == "dimension":
            if not dimension:
                fail(f"{label} dimension role lacks canonical_dimension")
        elif dimension:
            fail(f"{label} non-dimension role carries canonical_dimension")
        if role == "excluded":
            if not exclusion:
                fail(f"{label} excluded role lacks exclusion_reason")
        elif exclusion:
            fail(f"{label} non-excluded role carries exclusion_reason")
        if not row["source_evidence"] or not row["review_note"]:
            fail(f"{label} lacks evidence or review note")
        if row["reviewed"].casefold() not in {"true", "false"}:
            fail(f"{label} has an invalid reviewed value")
        row["year_start"] = row["year_end"] = str(year)
        row["source_file"] = source_file
        row["access_table_pattern"] = table
        row["column_name"] = column
        row["role"] = role
        row["canonical_dimension"] = dimension
        row["exclusion_reason"] = exclusion
        output.append(row)
    output.sort(
        key=lambda row: (
            int(row["year_start"]),
            row["source_file"],
            row["access_table_pattern"],
            row["column_name"],
        )
    )
    return output


def validate_unresolved_decisions(
    rows: Sequence[dict[str, str]],
) -> dict[tuple[int, str, str, str], dict[str, str]]:
    by_identity: dict[tuple[int, str, str, str], dict[str, str]] = {}
    for row_number, raw in enumerate(rows, start=2):
        row = dict(raw)
        label = f"unresolved decision row {row_number}"
        year = parse_nonnegative_int(row["year"], label=f"{label} year")
        source_file = ensure_exact_token(row["source_file"], label=f"{label} source_file")
        table = ensure_exact_token(
            row["access_table_name"],
            label=f"{label} access_table_name",
        )
        column = ensure_exact_token(row["column_name"], label=f"{label} column_name")
        identity = (year, source_file, table, column)
        if identity in by_identity:
            fail(
                "duplicate exact unresolved-decision identity: "
                f"{year}:{source_file}:{table}:{column}"
            )
        if parse_nonnegative_int(
            row["nonempty_count"],
            label=f"{label} nonempty_count",
        ) != 0:
            fail(f"{label} is not all-empty")
        if row["candidate_role"].casefold() != "unknown":
            fail(f"{label} is not an unknown candidate")
        if row["review_status"].casefold() != "unresolved":
            fail(f"{label} is not still unresolved")
        decisions = {
            token.strip().casefold()
            for token in row["required_decision"].split("|")
            if token.strip()
        }
        if "intentionally_exclude" not in decisions:
            fail(f"{label} does not offer an explicit intentionally_exclude decision")
        row["year"] = str(year)
        row["source_file"] = source_file
        row["access_table_name"] = table
        row["column_name"] = column
        by_identity[identity] = row
    return by_identity


def bind_unknown_candidates(
    source_rows: Sequence[dict[str, str]],
    unresolved_by_identity: dict[tuple[int, str, str, str], dict[str, str]],
    *,
    source_candidate_sha256: str,
) -> list[dict[str, str]]:
    unknown_by_identity: dict[
        tuple[int, str, str, str], dict[str, str]
    ] = {}
    for row in source_rows:
        if row["role"] != "unknown":
            continue
        identity = (
            int(row["year_start"]),
            row["source_file"],
            row["access_table_pattern"],
            row["column_name"],
        )
        unresolved = unresolved_by_identity.get(identity)
        if unresolved is None:
            fail(
                "unknown source candidate has no exact all-empty "
                "unresolved-decision row: "
                + ":".join(str(part) for part in identity)
            )
        unknown_by_identity[identity] = row
    extra_unresolved = sorted(set(unresolved_by_identity) - set(unknown_by_identity))
    if extra_unresolved:
        fail(
            "unresolved-decision row does not bind an exact unknown source "
            "candidate: "
            + ":".join(str(part) for part in extra_unresolved[0])
        )
    proposals: list[dict[str, str]] = []
    for identity in sorted(unknown_by_identity):
        year, source_file, table, column = identity
        candidate = unknown_by_identity[identity]
        unresolved = unresolved_by_identity[identity]
        proposals.append(
            {
                "original_decision_id": candidate["decision_id"],
                "unresolved_decision_id": unresolved["decision_id"],
                "year": str(year),
                "source_file": source_file,
                "access_table_name": table,
                "column_name": column,
                "nonempty_count": "0",
                "metadata_match_status": unresolved["metadata_match_status"],
                "unresolved_reason": unresolved["unresolved_reason"],
                "original_role": "unknown",
                "proposed_role": "excluded",
                "proposed_exclusion_reason": PROPOSED_EMPTY_EXCLUSION_REASON,
                "source_candidate_sha256": source_candidate_sha256,
                "required_author_action": (
                    "Countersign the exact projection and explicit exclusion "
                    "register hashes before canonical application."
                ),
                "author_decision_status": "pending",
            }
        )
    return proposals


def _contiguous_groups(
    scopes: Sequence[dict[str, object]],
    *,
    identity_fields: Sequence[str],
) -> list[dict[str, object]]:
    ordered = sorted(
        scopes,
        key=lambda scope: (
            *(str(scope[field]) for field in identity_fields),
            int(scope["year"]),
            str(scope["pattern"]),
            tuple(scope["semantics"]),
        ),
    )
    groups: list[dict[str, object]] = []
    current: dict[str, object] | None = None
    for scope in ordered:
        grouping_key = (
            *(str(scope[field]) for field in identity_fields),
            str(scope["pattern"]),
            tuple(scope["semantics"]),
        )
        if (
            current is not None
            and current["grouping_key"] == grouping_key
            and int(scope["year"]) == int(current["year_end"]) + 1
        ):
            current["year_end"] = int(scope["year"])
            current["exact_identities"] = [
                *list(current["exact_identities"]),
                *list(scope["exact_identities"]),
            ]
            continue
        current = {
            "grouping_key": grouping_key,
            "year_start": int(scope["year"]),
            "year_end": int(scope["year"]),
            "pattern": str(scope["pattern"]),
            "semantics": tuple(scope["semantics"]),
            "exact_identities": list(scope["exact_identities"]),
        }
        for field in identity_fields:
            current[field] = str(scope[field])
        groups.append(current)
    return groups


def _table_projection_groups(
    rows: Sequence[dict[str, str]],
) -> list[dict[str, object]]:
    by_scope: dict[tuple[str, int], list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_scope[(row["source_file"], int(row["year_start"]))].append(row)
    scopes: list[dict[str, object]] = []
    for (source_file, year), scoped_rows in sorted(by_scope.items()):
        by_semantics: dict[tuple[str, ...], list[dict[str, str]]] = defaultdict(list)
        for row in scoped_rows:
            by_semantics[_normalize_table_semantics(row)].append(row)
        if len(by_semantics) == 1:
            semantics = next(iter(by_semantics))
            scopes.append(
                {
                    "source_file": source_file,
                    "year": year,
                    "pattern": "*",
                    "semantics": semantics,
                    "exact_identities": [
                        (year, row["access_table_pattern"])
                        for row in sorted(
                            scoped_rows,
                            key=lambda item: item["access_table_pattern"],
                        )
                    ],
                }
            )
            continue
        for semantics, semantic_rows in sorted(by_semantics.items()):
            for row in sorted(
                semantic_rows,
                key=lambda item: item["access_table_pattern"],
            ):
                scopes.append(
                    {
                        "source_file": source_file,
                        "year": year,
                        "pattern": row["access_table_pattern"],
                        "semantics": semantics,
                        "exact_identities": [
                            (year, row["access_table_pattern"])
                        ],
                    }
                )
    return _contiguous_groups(scopes, identity_fields=("source_file",))


def _source_projection_groups(
    rows: Sequence[dict[str, str]],
) -> list[dict[str, object]]:
    by_scope: dict[
        tuple[str, str, int], list[dict[str, str]]
    ] = defaultdict(list)
    for row in rows:
        by_scope[
            (
                row["source_file"],
                row["column_name"],
                int(row["year_start"]),
            )
        ].append(row)
    scopes: list[dict[str, object]] = []
    for (source_file, column, year), scoped_rows in sorted(by_scope.items()):
        by_semantics: dict[
            tuple[str, str, str], list[dict[str, str]]
        ] = defaultdict(list)
        for row in scoped_rows:
            by_semantics[
                _normalize_source_semantics(
                    row,
                    effective_unknown_exclusion=True,
                )
            ].append(row)
        if len(by_semantics) == 1:
            semantics = next(iter(by_semantics))
            scopes.append(
                {
                    "source_file": source_file,
                    "column_name": column,
                    "year": year,
                    "pattern": "*",
                    "semantics": semantics,
                    "exact_identities": [
                        (year, row["access_table_pattern"], column)
                        for row in sorted(
                            scoped_rows,
                            key=lambda item: item["access_table_pattern"],
                        )
                    ],
                }
            )
            continue
        for semantics, semantic_rows in sorted(by_semantics.items()):
            for row in sorted(
                semantic_rows,
                key=lambda item: item["access_table_pattern"],
            ):
                scopes.append(
                    {
                        "source_file": source_file,
                        "column_name": column,
                        "year": year,
                        "pattern": row["access_table_pattern"],
                        "semantics": semantics,
                        "exact_identities": [
                            (year, row["access_table_pattern"], column)
                        ],
                    }
                )
    return _contiguous_groups(
        scopes,
        identity_fields=("source_file", "column_name"),
    )


def projection_source_row(
    *,
    year_start: int,
    year_end: int,
    source_file: str,
    table_pattern: str,
    column_name: str,
    role: str,
    canonical_dimension: str = "",
    exclusion_reason: str = "",
    decision_id: str | None = None,
    source_evidence: str = "Review-only exact-identity projection evidence.",
    review_note: str = "Requires author countersign before canonical use.",
) -> dict[str, str]:
    decision_id = decision_id or stable_decision_id(
        "B04-PROJ",
        year_start,
        year_end,
        source_file,
        table_pattern,
        column_name,
        role,
        canonical_dimension,
        exclusion_reason,
    )
    return {
        "contract_id": CONTRACT_ID,
        "decision_id": decision_id,
        "year_start": str(year_start),
        "year_end": str(year_end),
        "source_file": source_file.upper(),
        "access_table_pattern": table_pattern.upper(),
        "column_name": column_name.upper(),
        "role": role.casefold(),
        "canonical_dimension": canonical_dimension.upper(),
        "exclusion_reason": exclusion_reason,
        "source_evidence": source_evidence,
        "review_note": review_note,
        "reviewed": "false",
    }


def build_table_projection_rows(
    groups: Sequence[dict[str, object]],
    *,
    table_candidate_sha256: str,
) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    for group in groups:
        start = int(group["year_start"])
        end = int(group["year_end"])
        source_file = str(group["source_file"])
        pattern = str(group["pattern"])
        semantics = tuple(str(value) for value in group["semantics"])
        decision_id = stable_decision_id(
            "B03-PROJ",
            start,
            end,
            source_file,
            pattern,
            *semantics,
        )
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "decision_id": decision_id,
                "year_start": str(start),
                "year_end": str(end),
                "source_file": source_file,
                "access_table_pattern": pattern,
                **dict(zip(TABLE_SEMANTIC_FIELDS, semantics)),
                "source_evidence": (
                    "Exact Stage04 table candidate SHA-256 "
                    f"{table_candidate_sha256}; complete exact-identity "
                    "round-trip proof. Wildcards are used only after "
                    "same-year exact table semantics agree."
                ),
                "review_note": (
                    "Review-only compact projection; reviewed=false until the "
                    "author countersigns the exact projection hashes."
                ),
                "reviewed": "false",
            }
        )
    output.sort(
        key=lambda row: (
            row["source_file"],
            int(row["year_start"]),
            int(row["year_end"]),
            row["access_table_pattern"],
            row["decision_id"],
        )
    )
    return output


def build_source_projection_rows(
    groups: Sequence[dict[str, object]],
    *,
    source_candidate_sha256: str,
) -> list[dict[str, str]]:
    output: list[dict[str, str]] = []
    for group in groups:
        start = int(group["year_start"])
        end = int(group["year_end"])
        source_file = str(group["source_file"])
        column = str(group["column_name"])
        pattern = str(group["pattern"])
        role, dimension, exclusion = (
            str(value) for value in group["semantics"]
        )
        pending_exclusion = (
            role == "excluded"
            and exclusion == PROPOSED_EMPTY_EXCLUSION_REASON
        )
        note = (
            "PROPOSED ONLY: all-empty/source-metadata-absent intentional "
            "exclusion requires the exact author countersign; reviewed=false."
            if pending_exclusion
            else (
                "Review-only compact projection; reviewed=false until the "
                "author countersigns the exact projection hashes."
            )
        )
        output.append(
            projection_source_row(
                year_start=start,
                year_end=end,
                source_file=source_file,
                table_pattern=pattern,
                column_name=column,
                role=role,
                canonical_dimension=dimension,
                exclusion_reason=exclusion,
                source_evidence=(
                    "Exact Stage04 source-column candidate SHA-256 "
                    f"{source_candidate_sha256}; complete exact-identity "
                    "round-trip proof. Wildcards are used only after "
                    "same-year exact table semantics agree."
                ),
                review_note=note,
            )
        )
    output.sort(
        key=lambda row: (
            row["source_file"],
            row["column_name"],
            int(row["year_start"]),
            int(row["year_end"]),
            row["access_table_pattern"],
            row["decision_id"],
        )
    )
    return output


def _projection_matches(
    row: dict[str, str],
    *,
    year: int,
    source_file: str,
    table: str,
) -> bool:
    try:
        start = int(str(row["year_start"]).strip())
        end = int(str(row["year_end"]).strip())
    except ValueError:
        return False
    return (
        start <= year <= end
        and row["source_file"].strip().upper() == source_file
        and fnmatch.fnmatchcase(
            table,
            row["access_table_pattern"].strip().upper(),
        )
    )


def audit_table_projection(
    candidates: Sequence[dict[str, object]],
    projections: Sequence[dict[str, object]],
) -> tuple[list[dict[str, str]], ResolutionStats]:
    clean_candidates = [_clean_row(row) for row in candidates]
    clean_projections = [_clean_row(row) for row in projections]
    proof: list[dict[str, str]] = []
    missing = 0
    ambiguous = 0
    drift = 0
    for candidate in clean_candidates:
        year = int(candidate["year_start"])
        source_file = candidate["source_file"].upper()
        table = candidate["access_table_pattern"].upper()
        matches = [
            row
            for row in clean_projections
            if _projection_matches(
                row,
                year=year,
                source_file=source_file,
                table=table,
            )
        ]
        expected = _normalize_table_semantics(candidate)
        resolved: tuple[str, ...] = ()
        if not matches:
            status = "missing"
            missing += 1
        elif len(matches) > 1:
            status = "ambiguous"
            ambiguous += 1
        else:
            resolved = _normalize_table_semantics(matches[0])
            if resolved != expected:
                status = "semantic_drift"
                drift += 1
            else:
                status = "exact"
        proof.append(
            {
                "projection_type": "table_grain",
                "year": str(year),
                "source_file": source_file,
                "access_table_name": table,
                "column_name": "",
                "input_decision_id": candidate["decision_id"],
                "matched_projection_decision_id": (
                    matches[0]["decision_id"] if len(matches) == 1 else ""
                ),
                "match_count": str(len(matches)),
                "expected_semantics_sha256": semantic_hash(expected),
                "resolved_semantics_sha256": (
                    semantic_hash(resolved) if resolved else ""
                ),
                "resolution_status": status,
                "proposed_change": "",
            }
        )
    return proof, ResolutionStats(
        identity_count=len(clean_candidates),
        missing=missing,
        ambiguous=ambiguous,
        semantic_drift=drift,
        proposed_changes=0,
    )


def audit_source_projection(
    candidates: Sequence[dict[str, object]],
    projections: Sequence[dict[str, object]],
) -> tuple[list[dict[str, str]], ResolutionStats]:
    clean_candidates = [_clean_row(row) for row in candidates]
    clean_projections = [_clean_row(row) for row in projections]
    proof: list[dict[str, str]] = []
    missing = 0
    ambiguous = 0
    drift = 0
    proposed_changes = 0
    for candidate in clean_candidates:
        year = int(candidate["year_start"])
        source_file = candidate["source_file"].upper()
        table = candidate["access_table_pattern"].upper()
        column = candidate["column_name"].upper()
        matches = [
            row
            for row in clean_projections
            if row["column_name"].strip().upper() == column
            and _projection_matches(
                row,
                year=year,
                source_file=source_file,
                table=table,
            )
        ]
        expected = _normalize_source_semantics(
            candidate,
            effective_unknown_exclusion=True,
        )
        proposed_change = (
            "unknown_to_intentionally_excluded"
            if candidate["role"].casefold() == "unknown"
            else ""
        )
        if proposed_change:
            proposed_changes += 1
        resolved: tuple[str, ...] = ()
        if not matches:
            status = "missing"
            missing += 1
        elif len(matches) > 1:
            status = "ambiguous"
            ambiguous += 1
        else:
            resolved = _normalize_source_semantics(
                matches[0],
                effective_unknown_exclusion=False,
            )
            if resolved != expected:
                status = "semantic_drift"
                drift += 1
            else:
                status = "exact"
        proof.append(
            {
                "projection_type": "source_columns",
                "year": str(year),
                "source_file": source_file,
                "access_table_name": table,
                "column_name": column,
                "input_decision_id": candidate["decision_id"],
                "matched_projection_decision_id": (
                    matches[0]["decision_id"] if len(matches) == 1 else ""
                ),
                "match_count": str(len(matches)),
                "expected_semantics_sha256": semantic_hash(expected),
                "resolved_semantics_sha256": (
                    semantic_hash(resolved) if resolved else ""
                ),
                "resolution_status": status,
                "proposed_change": proposed_change,
            }
        )
    return proof, ResolutionStats(
        identity_count=len(clean_candidates),
        missing=missing,
        ambiguous=ambiguous,
        semantic_drift=drift,
        proposed_changes=proposed_changes,
    )


def build_scope_diagnostics(
    *,
    projection_type: str,
    groups: Sequence[dict[str, object]],
    projections: Sequence[dict[str, str]],
) -> list[dict[str, str]]:
    if len(groups) != len(projections):
        fail(f"{projection_type} group/projection count differs")
    output: list[dict[str, str]] = []
    for group, projection in zip(groups, projections):
        identities = list(group["exact_identities"])
        identity_tokens = [
            ":".join(str(value) for value in identity)
            for identity in identities
        ]
        pattern = projection["access_table_pattern"]
        output.append(
            {
                "projection_type": projection_type,
                "decision_id": projection["decision_id"],
                "year_start": projection["year_start"],
                "year_end": projection["year_end"],
                "source_file": projection["source_file"],
                "column_name": projection.get("column_name", ""),
                "access_table_pattern": pattern,
                "wildcard_used": str(
                    bool(WILDCARD_CHARACTERS.intersection(pattern))
                ).lower(),
                "exact_identity_count": str(len(identities)),
                "exact_table_identities": "|".join(identity_tokens),
                "semantic_sha256": semantic_hash(
                    tuple(str(value) for value in group["semantics"])
                ),
                "wildcard_safety_status": (
                    "uniform_exact_scope"
                    if WILDCARD_CHARACTERS.intersection(pattern)
                    else "exact_table_pattern"
                ),
            }
        )
    output.sort(
        key=lambda row: (
            row["projection_type"],
            row["source_file"],
            row["column_name"],
            int(row["year_start"]),
            row["access_table_pattern"],
        )
    )
    return output


def verify_candidate_artifact_manifest(
    path: Path,
    *,
    inputs: Sequence[Path],
) -> None:
    _, rows = read_csv(
        path,
        required_fields=("path", "byte_size", "sha256", "row_count"),
        label="Stage04 candidate artifact manifest",
        exact_fields=False,
    )
    by_name: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        by_name[Path(row["path"]).name].append(row)
    for input_path in inputs:
        matches = by_name.get(input_path.name, [])
        if len(matches) != 1:
            fail(
                "Stage04 candidate artifact manifest must bind exactly one "
                f"{input_path.name} row; observed={len(matches)}"
            )
        row = matches[0]
        expected_size = parse_nonnegative_int(
            row["byte_size"],
            label=f"manifest byte_size for {input_path.name}",
        )
        expected_rows = parse_nonnegative_int(
            row["row_count"],
            label=f"manifest row_count for {input_path.name}",
        )
        if expected_size != input_path.stat().st_size:
            fail(f"Stage04 manifest size mismatch for {input_path.name}")
        if row["sha256"].casefold() != sha256_file(input_path):
            fail(f"Stage04 manifest hash mismatch for {input_path.name}")
        if expected_rows != count_csv_rows(input_path):
            fail(f"Stage04 manifest row-count mismatch for {input_path.name}")


def _input_manifest_row(
    role: str,
    path: Path,
    *,
    row_count: int | None = None,
) -> dict[str, str]:
    return {
        "input_role": role,
        "path": path.name,
        "byte_size": str(path.stat().st_size),
        "sha256": sha256_file(path),
        "row_count": str(
            count_csv_rows(path)
            if row_count is None and path.suffix.casefold() == ".csv"
            else row_count or 0
        ),
    }


def _assert_projection_size(path: Path, *, max_bytes: int) -> None:
    if path.stat().st_size > max_bytes:
        fail(
            f"{path.name} exceeds tracked-file guard: "
            f"{path.stat().st_size}>{max_bytes}"
        )


def build_projection(
    *,
    table_candidate_path: Path,
    source_candidate_path: Path,
    unresolved_decisions_path: Path,
    canonical_table_path: Path,
    canonical_source_path: Path,
    output_dir: Path,
    decision_date: str,
    candidate_artifact_manifest_path: Path | None = None,
    candidate_input_manifest_path: Path | None = None,
    max_tracked_file_bytes: int = MAX_TRACKED_FILE_BYTES,
) -> BuildResult:
    table_candidate_path = Path(table_candidate_path).resolve()
    source_candidate_path = Path(source_candidate_path).resolve()
    unresolved_decisions_path = Path(unresolved_decisions_path).resolve()
    canonical_table_path = Path(canonical_table_path).resolve()
    canonical_source_path = Path(canonical_source_path).resolve()
    output_dir = Path(output_dir).resolve()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", decision_date):
        fail("decision_date must use YYYY-MM-DD")
    if max_tracked_file_bytes <= 0:
        fail("max_tracked_file_bytes must be positive")
    for path, label in (
        (canonical_table_path, "canonical table_grain"),
        (canonical_source_path, "canonical source_columns"),
    ):
        if not path.is_file():
            fail(f"{label} does not exist: {path}")

    canonical_table_before = sha256_file(canonical_table_path)
    canonical_source_before = sha256_file(canonical_source_path)
    table_candidate_sha = sha256_file(table_candidate_path)
    source_candidate_sha = sha256_file(source_candidate_path)
    unresolved_sha = sha256_file(unresolved_decisions_path)
    generator_path = Path(__file__).resolve()
    generator_sha = sha256_file(generator_path)

    _, raw_table_rows = read_csv(
        table_candidate_path,
        required_fields=TABLE_FIELDS,
        label="Stage04 table candidate",
    )
    _, raw_source_rows = read_csv(
        source_candidate_path,
        required_fields=SOURCE_FIELDS,
        label="Stage04 source-column candidate",
    )
    _, raw_unresolved_rows = read_csv(
        unresolved_decisions_path,
        required_fields=UNRESOLVED_FIELDS,
        label="Stage04 unresolved decisions",
    )
    table_rows = validate_table_candidates(raw_table_rows)
    table_identities = {
        (
            int(row["year_start"]),
            row["source_file"],
            row["access_table_pattern"],
        )
        for row in table_rows
    }
    source_rows = validate_source_candidates(
        raw_source_rows,
        table_identities=table_identities,
    )
    unresolved_by_identity = validate_unresolved_decisions(raw_unresolved_rows)
    proposed_exclusions = bind_unknown_candidates(
        source_rows,
        unresolved_by_identity,
        source_candidate_sha256=source_candidate_sha,
    )

    optional_inputs: list[tuple[str, Path]] = []
    if candidate_artifact_manifest_path is not None:
        candidate_artifact_manifest_path = Path(
            candidate_artifact_manifest_path
        ).resolve()
        verify_candidate_artifact_manifest(
            candidate_artifact_manifest_path,
            inputs=(
                table_candidate_path,
                source_candidate_path,
                unresolved_decisions_path,
            ),
        )
        optional_inputs.append(
            ("stage04_candidate_artifact_manifest", candidate_artifact_manifest_path)
        )
    if candidate_input_manifest_path is not None:
        candidate_input_manifest_path = Path(candidate_input_manifest_path).resolve()
        if not candidate_input_manifest_path.is_file():
            fail(
                "Stage04 candidate input manifest does not exist: "
                f"{candidate_input_manifest_path}"
            )
        optional_inputs.append(
            ("stage04_candidate_input_manifest", candidate_input_manifest_path)
        )

    table_groups = _table_projection_groups(table_rows)
    source_groups = _source_projection_groups(source_rows)
    table_projections = build_table_projection_rows(
        table_groups,
        table_candidate_sha256=table_candidate_sha,
    )
    source_projections = build_source_projection_rows(
        source_groups,
        source_candidate_sha256=source_candidate_sha,
    )
    table_proof, table_stats = audit_table_projection(
        table_rows,
        table_projections,
    )
    source_proof, source_stats = audit_source_projection(
        source_rows,
        source_projections,
    )
    for label, stats in (
        ("table-grain", table_stats),
        ("source-column", source_stats),
    ):
        if stats.missing or stats.ambiguous or stats.semantic_drift:
            fail(
                f"{label} projection is not lossless: "
                f"missing={stats.missing} ambiguous={stats.ambiguous} "
                f"semantic_drift={stats.semantic_drift}"
            )
    if source_stats.proposed_changes != len(proposed_exclusions):
        fail(
            "unknown/exclusion proposal count differs from exact source "
            "round-trip proof"
        )

    table_scope_diagnostics = build_scope_diagnostics(
        projection_type="table_grain",
        groups=table_groups,
        projections=table_projections,
    )
    source_scope_diagnostics = build_scope_diagnostics(
        projection_type="source_columns",
        groups=source_groups,
        projections=source_projections,
    )

    output_dir.mkdir(parents=True, exist_ok=True)
    table_projection_path = output_dir / "table_grain_contract_projection.csv"
    source_projection_path = output_dir / "source_columns_contract_projection.csv"
    proposed_exclusions_path = output_dir / "stage04_proposed_empty_exclusions.csv"
    scope_diagnostics_path = output_dir / "stage04_projection_scope_diagnostics.csv"
    resolution_proof_path = output_dir / "stage04_exact_identity_resolution_proof.csv"
    input_manifest_path = output_dir / "STAGE04_PROJECTION_INPUT_MANIFEST.csv"
    canonical_hash_path = (
        output_dir / "STAGE04_PROJECTION_CANONICAL_HASH_COMPARISON.csv"
    )
    summary_path = output_dir / "STAGE04_PROJECTION_SUMMARY.md"
    countersign_path = output_dir / "STAGE04_AUTHOR_COUNTERSIGN_REQUIRED.md"
    artifact_manifest_path = output_dir / "STAGE04_PROJECTION_ARTIFACT_MANIFEST.csv"

    input_manifest_rows = [
        _input_manifest_row("stage04_table_candidate", table_candidate_path),
        _input_manifest_row("stage04_source_candidate", source_candidate_path),
        _input_manifest_row("stage04_unresolved_decisions", unresolved_decisions_path),
        *[
            _input_manifest_row(role, path)
            for role, path in optional_inputs
        ],
        _input_manifest_row(
            "canonical_table_grain_read_only",
            canonical_table_path,
        ),
        _input_manifest_row(
            "canonical_source_columns_read_only",
            canonical_source_path,
        ),
        _input_manifest_row("generator", generator_path, row_count=0),
    ]
    _write_csv_atomic(
        input_manifest_path,
        INPUT_MANIFEST_FIELDS,
        input_manifest_rows,
    )
    input_manifest_sha = sha256_file(input_manifest_path)

    _write_csv_atomic(
        table_projection_path,
        TABLE_FIELDS,
        table_projections,
    )
    _write_csv_atomic(
        source_projection_path,
        SOURCE_FIELDS,
        source_projections,
    )
    _assert_projection_size(
        table_projection_path,
        max_bytes=max_tracked_file_bytes,
    )
    _assert_projection_size(
        source_projection_path,
        max_bytes=max_tracked_file_bytes,
    )
    _write_csv_atomic(
        proposed_exclusions_path,
        PROPOSED_EXCLUSION_FIELDS,
        proposed_exclusions,
    )
    _write_csv_atomic(
        scope_diagnostics_path,
        SCOPE_DIAGNOSTIC_FIELDS,
        [*table_scope_diagnostics, *source_scope_diagnostics],
    )
    all_proof = sorted(
        [*table_proof, *source_proof],
        key=lambda row: (
            row["projection_type"],
            int(row["year"]),
            row["source_file"],
            row["access_table_name"],
            row["column_name"],
        ),
    )
    _write_csv_atomic(
        resolution_proof_path,
        RESOLUTION_PROOF_FIELDS,
        all_proof,
    )

    canonical_table_after = sha256_file(canonical_table_path)
    canonical_source_after = sha256_file(canonical_source_path)
    if (
        canonical_table_after != canonical_table_before
        or canonical_source_after != canonical_source_before
    ):
        fail("canonical contracts changed during review-only projection generation")
    _write_csv_atomic(
        canonical_hash_path,
        CANONICAL_HASH_FIELDS,
        [
            {
                "path": "contracts/table_grain.csv",
                "sha256_before": canonical_table_before,
                "sha256_after": canonical_table_after,
                "unchanged": "true",
            },
            {
                "path": "contracts/source_columns.csv",
                "sha256_before": canonical_source_before,
                "sha256_after": canonical_source_after,
                "unchanged": "true",
            },
        ],
    )

    table_projection_sha = sha256_file(table_projection_path)
    source_projection_sha = sha256_file(source_projection_path)
    proposed_exclusions_sha = sha256_file(proposed_exclusions_path)
    summary = "\n".join(
        [
            "# Stage04 compact contract projection",
            "",
            "STAGE04_COMPACT_PROJECTION_LOSSLESS",
            "STAGE04_AUTHOR_COUNTERSIGN_REQUIRED",
            "CANONICAL_CONTRACTS_UNCHANGED",
            "RELEASE_STILL_BLOCKED",
            "",
            f"- Exact table identities: {len(table_rows)}.",
            f"- Compact table projection rows: {len(table_projections)}.",
            (
                "- Table resolution: "
                f"missing={table_stats.missing}; "
                f"ambiguous={table_stats.ambiguous}; "
                f"semantic_drift={table_stats.semantic_drift}."
            ),
            f"- Exact source-column identities: {len(source_rows)}.",
            f"- Compact source-column projection rows: {len(source_projections)}.",
            (
                "- Source resolution: "
                f"missing={source_stats.missing}; "
                f"ambiguous={source_stats.ambiguous}; "
                f"semantic_drift={source_stats.semantic_drift}."
            ),
            (
                "- Explicit pending all-empty intentional-exclusion identities: "
                f"{len(proposed_exclusions)}."
            ),
            (
                "- Table projection bytes / 5 MiB guard: "
                f"{table_projection_path.stat().st_size} / "
                f"{max_tracked_file_bytes}."
            ),
            (
                "- Source projection bytes / 5 MiB guard: "
                f"{source_projection_path.stat().st_size} / "
                f"{max_tracked_file_bytes}."
            ),
            f"- Exact table candidate SHA-256: `{table_candidate_sha}`.",
            f"- Exact source candidate SHA-256: `{source_candidate_sha}`.",
            f"- Unresolved-decision input SHA-256: `{unresolved_sha}`.",
            f"- Compact table projection SHA-256: `{table_projection_sha}`.",
            f"- Compact source projection SHA-256: `{source_projection_sha}`.",
            (
                "- Proposed-empty-exclusion register SHA-256: "
                f"`{proposed_exclusions_sha}`."
            ),
            f"- Generator SHA-256: `{generator_sha}`.",
            f"- Input manifest SHA-256: `{input_manifest_sha}`.",
            (
                "- Canonical table_grain.csv pre/post SHA-256: "
                f"`{canonical_table_before}`."
            ),
            (
                "- Canonical source_columns.csv pre/post SHA-256: "
                f"`{canonical_source_before}`."
            ),
            "",
            (
                "The production inventory's eight exclusions are proposals "
                "only. The projection remains reviewed=false and cannot be "
                "used by the pipeline until the author countersigns the exact "
                "hashes and a separate application step is verified."
            ),
            "",
        ]
    )
    _write_text_atomic(summary_path, summary)

    countersign = "\n".join(
        [
            "# Stage04 author countersign required",
            "",
            "No canonical contract has been changed.",
            "",
            "The remaining scientific authorization must bind all three hashes:",
            "",
            f"- table projection: `{table_projection_sha}`",
            f"- source projection: `{source_projection_sha}`",
            f"- explicit empty exclusions: `{proposed_exclusions_sha}`",
            "",
            "Required signature form:",
            "",
            (
                "> I, [AUTHOR NAME], countersign the Stage04 compact table "
                f"projection SHA-256 {table_projection_sha}, compact source "
                f"projection SHA-256 {source_projection_sha}, and explicit "
                "all-empty intentional-exclusion register SHA-256 "
                f"{proposed_exclusions_sha}, dated {decision_date}. I authorize "
                "Codex to apply exactly these reviewed projections and no "
                "other scientific-contract changes. I understand that the "
                "listed all-empty unknown identities are being intentionally "
                "excluded without inferred semantics."
            ),
            "",
            (
                "Until that exact hash-bound countersign is supplied, every "
                "projection row remains reviewed=false and release remains "
                "blocked."
            ),
            "",
        ]
    )
    _write_text_atomic(countersign_path, countersign)

    artifacts_with_roles = [
        (table_projection_path, "compact_table_grain_projection"),
        (source_projection_path, "compact_source_columns_projection"),
        (proposed_exclusions_path, "explicit_pending_empty_exclusions"),
        (scope_diagnostics_path, "wildcard_scope_safety_diagnostics"),
        (resolution_proof_path, "exact_identity_roundtrip_proof"),
        (input_manifest_path, "input_hash_binding"),
        (canonical_hash_path, "canonical_immutability_proof"),
        (summary_path, "review_summary"),
        (countersign_path, "remaining_author_signature"),
    ]
    manifest_rows = []
    for path, role in artifacts_with_roles:
        manifest_rows.append(
            {
                "path": path.name,
                "byte_size": str(path.stat().st_size),
                "sha256": sha256_file(path),
                "row_count": str(
                    count_csv_rows(path)
                    if path.suffix.casefold() == ".csv"
                    else 0
                ),
                "artifact_role": role,
                "generator_sha256": generator_sha,
                "input_manifest_sha256": input_manifest_sha,
                "canonical_table_grain_pre_sha256": canonical_table_before,
                "canonical_source_columns_pre_sha256": canonical_source_before,
            }
        )
    _write_csv_atomic(
        artifact_manifest_path,
        ARTIFACT_MANIFEST_FIELDS,
        manifest_rows,
    )
    artifact_paths = [
        *(path for path, _ in artifacts_with_roles),
        artifact_manifest_path,
    ]
    return BuildResult(
        table_projection_path=table_projection_path,
        source_projection_path=source_projection_path,
        proposed_exclusions_path=proposed_exclusions_path,
        scope_diagnostics_path=scope_diagnostics_path,
        resolution_proof_path=resolution_proof_path,
        input_manifest_path=input_manifest_path,
        canonical_hash_path=canonical_hash_path,
        summary_path=summary_path,
        countersign_path=countersign_path,
        artifact_manifest_path=artifact_manifest_path,
        artifact_paths=artifact_paths,
        table_exact_identity_count=len(table_rows),
        table_projection_count=len(table_projections),
        source_exact_identity_count=len(source_rows),
        source_projection_count=len(source_projections),
        proposed_exclusion_identity_count=len(proposed_exclusions),
        table_stats=table_stats,
        source_stats=source_stats,
    )


def parse_args() -> argparse.Namespace:
    candidate_dir = (
        REPO_ROOT
        / "Artifacts"
        / "review_v2"
        / "stage04_full_candidates_2026-07-24"
    )
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--candidate-dir",
        type=Path,
        default=candidate_dir,
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=(
            REPO_ROOT
            / "Artifacts"
            / "review_v2"
            / "stage04_contract_projection_2026-07-24"
        ),
    )
    parser.add_argument(
        "--canonical-table",
        type=Path,
        default=REPO_ROOT / "contracts" / "table_grain.csv",
    )
    parser.add_argument(
        "--canonical-source",
        type=Path,
        default=REPO_ROOT / "contracts" / "source_columns.csv",
    )
    parser.add_argument("--decision-date", default="2026-07-24")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    result = build_projection(
        table_candidate_path=(
            args.candidate_dir / "table_grain_stage04_candidate.csv"
        ),
        source_candidate_path=(
            args.candidate_dir / "source_columns_stage04_candidate.csv"
        ),
        unresolved_decisions_path=(
            args.candidate_dir / "stage04_unresolved_decisions.csv"
        ),
        candidate_artifact_manifest_path=(
            args.candidate_dir / "STAGE04_CANDIDATE_ARTIFACT_MANIFEST.csv"
        ),
        candidate_input_manifest_path=(
            args.candidate_dir / "STAGE04_CANDIDATE_INPUT_MANIFEST.csv"
        ),
        canonical_table_path=args.canonical_table,
        canonical_source_path=args.canonical_source,
        output_dir=args.output_dir,
        decision_date=args.decision_date,
    )
    print("STAGE04_COMPACT_PROJECTION_LOSSLESS")
    print("STAGE04_AUTHOR_COUNTERSIGN_REQUIRED")
    print("CANONICAL_CONTRACTS_UNCHANGED")
    print("RELEASE_STILL_BLOCKED")
    print(f"table_exact_identities={result.table_exact_identity_count}")
    print(f"table_projection_rows={result.table_projection_count}")
    print(f"source_exact_identities={result.source_exact_identity_count}")
    print(f"source_projection_rows={result.source_projection_count}")
    print(
        "pending_empty_exclusion_identities="
        f"{result.proposed_exclusion_identity_count}"
    )
    print(f"output_dir={result.summary_path.parent}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
