#!/usr/bin/env python3
"""Build and run the hash-bound IPEDSDB release container.

The wrapper accepts only a clean standalone Git checkout, builds that exact
checkout and its standalone Git metadata into an image, inspects the image
once, and launches the immutable image ID with an external data root mounted
read-write at ``/data``.  The image root containing ``/repo`` is read-only.
Caller-supplied image binding environment variables are ignored.
"""

from __future__ import annotations

import argparse
import contextlib
import fcntl
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterator, Mapping, Sequence


IMAGE_ID_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
RECEIPT_SCHEMA_VERSION = 1
SOURCE_URL = "https://github.com/markjayson13/IPEDSDB_Panel"
RELEASE_YEARS = "2004:2023"


class ReleaseContainerError(RuntimeError):
    """The requested container action is not a safe release operation."""


@dataclass(frozen=True)
class SourceBinding:
    source_root: Path
    commit: str
    tree: str


@dataclass(frozen=True)
class ImageBinding:
    image_id: str
    revision: str
    os: str
    architecture: str
    repo_digests: tuple[str, ...]
    source: str


Runner = Callable[..., subprocess.CompletedProcess[str]]


def _safe_git_environment() -> dict[str, str]:
    """Return a small Git environment with caller indirections removed."""

    environment = {
        name: os.environ[name]
        for name in (
            "LANG",
            "LC_ALL",
            "PATH",
            "TEMP",
            "TMP",
            "TMPDIR",
        )
        if name in os.environ
    }
    environment.update(
        {
            "GIT_ATTR_NOSYSTEM": "1",
            "GIT_CONFIG_COUNT": "0",
            "GIT_CONFIG_GLOBAL": "/dev/null",
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_INDEX_VERSION": "2",
            "GIT_NO_REPLACE_OBJECTS": "1",
            "GIT_OPTIONAL_LOCKS": "0",
            "HOME": "/nonexistent",
        }
    )
    return environment


def _run_git(
    repo: Path,
    *args: str,
    binary: bool = False,
) -> str | bytes:
    completed = subprocess.run(
        ["git", *args],
        cwd=repo,
        env=_safe_git_environment(),
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=not binary,
    )
    if completed.returncode != 0:
        stderr = (
            completed.stderr.strip()
            if isinstance(completed.stderr, str)
            else completed.stderr.decode("utf-8", errors="replace").strip()
        )
        raise ReleaseContainerError(
            f"Git command failed ({' '.join(args)}): {stderr}"
        )
    return completed.stdout


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _is_regular_non_symlink(path: Path) -> bool:
    try:
        mode = path.lstat().st_mode
    except OSError:
        return False
    return stat.S_ISREG(mode) and not path.is_symlink()


def inspect_standalone_source(source_root: Path) -> SourceBinding:
    """Return the exact clean commit/tree or reject the checkout."""

    raw_source_root = source_root.expanduser().absolute()
    if raw_source_root.is_symlink() or not raw_source_root.is_dir():
        raise ReleaseContainerError(
            f"Release source must be a real non-symlink directory: "
            f"{raw_source_root}"
        )
    source_root = raw_source_root.resolve()
    git_dir = source_root / ".git"
    if git_dir.is_symlink() or not git_dir.is_dir():
        raise ReleaseContainerError(
            "Release source must be a standalone checkout with a real .git "
            "directory."
        )
    top = Path(
        str(_run_git(source_root, "rev-parse", "--show-toplevel")).strip()
    ).resolve()
    actual_git_dir = Path(
        str(
            _run_git(
                source_root,
                "rev-parse",
                "--absolute-git-dir",
            )
        ).strip()
    ).resolve()
    common_git_dir = Path(
        str(
            _run_git(
                source_root,
                "rev-parse",
                "--path-format=absolute",
                "--git-common-dir",
            )
        ).strip()
    ).resolve()
    expected_git_dir = git_dir.resolve()
    if (
        top != source_root
        or actual_git_dir != expected_git_dir
        or common_git_dir != expected_git_dir
    ):
        raise ReleaseContainerError(
            "Release source Git metadata is not standalone and self-contained."
        )
    alternates = git_dir / "objects" / "info" / "alternates"
    if alternates.exists() or alternates.is_symlink():
        raise ReleaseContainerError(
            "Release source cannot use an alternate Git object store."
        )
    grafts = git_dir / "info" / "grafts"
    if grafts.exists() or grafts.is_symlink():
        raise ReleaseContainerError(
            "Release source cannot use Git grafts."
        )
    replace_refs = str(
        _run_git(
            source_root,
            "for-each-ref",
            "--format=%(refname)",
            "refs/replace",
        )
    ).strip()
    if replace_refs:
        raise ReleaseContainerError(
            "Release source cannot use Git replacement refs."
        )
    objects = git_dir / "objects"
    if any(path.is_symlink() for path in objects.rglob("*")):
        raise ReleaseContainerError(
            "Release source Git objects cannot contain symlinks."
        )
    commit = str(
        _run_git(source_root, "rev-parse", "--verify", "HEAD^{commit}")
    ).strip()
    tree = str(
        _run_git(source_root, "rev-parse", "--verify", "HEAD^{tree}")
    ).strip()
    if not COMMIT_RE.fullmatch(commit) or not COMMIT_RE.fullmatch(tree):
        raise ReleaseContainerError(
            "Release source HEAD/tree must be full Git object ids."
        )
    status = _run_git(
        source_root,
        "status",
        "--porcelain=v1",
        "-z",
        "--untracked-files=all",
        binary=True,
    )
    if status:
        raise ReleaseContainerError(
            "Release source must be status-clean, including untracked files."
        )
    index_records = bytes(
        _run_git(
            source_root,
            "ls-files",
            "-v",
            "-z",
            binary=True,
        )
    ).split(b"\0")
    nondefault_flags = [
        record[:1].decode("ascii", errors="replace")
        for record in index_records
        if record and record[:2] != b"H "
    ]
    if nondefault_flags:
        raise ReleaseContainerError(
            "Release source index contains assume-unchanged, skip-worktree, "
            "or other nondefault flags."
        )
    ignored = _run_git(
        source_root,
        "ls-files",
        "-z",
        "--others",
        "--ignored",
        "--exclude-standard",
        binary=True,
    )
    if ignored:
        raise ReleaseContainerError(
            "Release source cannot contain ignored workspace files; use a "
            "fresh standalone clone."
        )
    return SourceBinding(source_root=source_root, commit=commit, tree=tree)


@contextlib.contextmanager
def materialize_release_context(
    source: SourceBinding,
) -> Iterator[Path]:
    """Yield a sanitized standalone clone for the Docker build context.

    The caller's raw Git metadata is never sent to Docker.  A depth-one,
    no-tags fetch transfers only the exact detached commit and its tree through
    Git's file transport; configuration, reflogs, hooks, and refs are then
    removed before the commit/tree and every tracked worktree byte are
    reverified.
    """

    with tempfile.TemporaryDirectory(
        prefix="ipedsdb-release-context-"
    ) as temporary:
        context = Path(temporary) / "repo"
        context.mkdir()
        _run_git(context, "init", "--quiet")
        _run_git(
            context,
            "fetch",
            "--quiet",
            "--depth=1",
            "--no-tags",
            source.source_root.as_uri(),
            source.commit,
        )
        _run_git(context, "checkout", "--detach", "--quiet", source.commit)

        git_dir = context / ".git"
        for relative in (
            "hooks",
            "logs",
            "refs",
            "rr-cache",
            "svn",
        ):
            path = git_dir / relative
            if path.is_symlink():
                raise ReleaseContainerError(
                    f"Sanitized Git metadata unexpectedly contains a symlink: "
                    f"{path}"
                )
            if path.is_dir():
                shutil.rmtree(path)
        for relative in (
            "config.worktree",
            "FETCH_HEAD",
            "ORIG_HEAD",
            "packed-refs",
        ):
            path = git_dir / relative
            if path.is_symlink():
                raise ReleaseContainerError(
                    f"Sanitized Git metadata unexpectedly contains a symlink: "
                    f"{path}"
                )
            if path.exists():
                path.unlink()
        (git_dir / "refs" / "heads").mkdir(parents=True)
        (git_dir / "refs" / "tags").mkdir(parents=True)
        (git_dir / "config").write_text(
            "[core]\n"
            "\trepositoryformatversion = 0\n"
            "\tfilemode = true\n"
            "\tbare = false\n"
            "\tlogallrefupdates = false\n",
            encoding="utf-8",
        )

        sanitized = inspect_standalone_source(context)
        if (
            sanitized.commit != source.commit
            or sanitized.tree != source.tree
        ):
            raise ReleaseContainerError(
                "Sanitized release context differs from the authorized "
                "source commit/tree."
            )
        _verify_worktree_matches_snapshot(
            source_root=source.source_root,
            snapshot_root=context,
        )
        index_path = git_dir / "index"
        if index_path.exists():
            index_path.unlink()
        _run_git(
            context,
            "read-tree",
            "--reset",
            source.commit,
        )
        for path in sorted(
            context.rglob("*"),
            key=lambda item: item.as_posix(),
            reverse=True,
        ):
            try:
                os.utime(
                    path,
                    ns=(0, 0),
                    follow_symlinks=False,
                )
            except (NotImplementedError, OSError) as exc:
                raise ReleaseContainerError(
                    f"Could not canonicalize release-context timestamp: "
                    f"{path}"
                ) from exc
        os.utime(context, ns=(0, 0))
        final = inspect_standalone_source(context)
        if final.commit != source.commit or final.tree != source.tree:
            raise ReleaseContainerError(
                "Canonicalized release context differs from the authorized "
                "source commit/tree."
            )
        yield context


def _verify_worktree_matches_snapshot(
    *,
    source_root: Path,
    snapshot_root: Path,
) -> None:
    """Byte-compare every tracked path, ignoring index concealment flags."""

    raw_paths = bytes(
        _run_git(
            snapshot_root,
            "ls-files",
            "-z",
            binary=True,
        )
    ).split(b"\0")
    for raw_relative in raw_paths:
        if not raw_relative:
            continue
        try:
            relative = Path(raw_relative.decode("utf-8"))
        except UnicodeDecodeError as exc:
            raise ReleaseContainerError(
                "Release source contains a non-UTF-8 tracked path."
            ) from exc
        if relative.is_absolute() or ".." in relative.parts:
            raise ReleaseContainerError(
                f"Release source contains an unsafe tracked path: {relative}"
            )
        source_path = source_root / relative
        snapshot_path = snapshot_root / relative
        try:
            source_stat = source_path.lstat()
            snapshot_stat = snapshot_path.lstat()
        except OSError as exc:
            raise ReleaseContainerError(
                f"Release source tracked path is missing: {relative}"
            ) from exc
        if stat.S_ISLNK(source_stat.st_mode) or stat.S_ISLNK(
            snapshot_stat.st_mode
        ):
            if not (
                stat.S_ISLNK(source_stat.st_mode)
                and stat.S_ISLNK(snapshot_stat.st_mode)
                and os.readlink(source_path) == os.readlink(snapshot_path)
            ):
                raise ReleaseContainerError(
                    f"Release source symlink differs from HEAD: {relative}"
                )
            continue
        if not (
            stat.S_ISREG(source_stat.st_mode)
            and stat.S_ISREG(snapshot_stat.st_mode)
        ):
            raise ReleaseContainerError(
                f"Release source tracked path is not regular: {relative}"
            )
        if (
            source_stat.st_size != snapshot_stat.st_size
            or _sha256_file(source_path) != _sha256_file(snapshot_path)
            or bool(source_stat.st_mode & stat.S_IXUSR)
            != bool(snapshot_stat.st_mode & stat.S_IXUSR)
        ):
            raise ReleaseContainerError(
                f"Release source tracked bytes/mode differ from HEAD: "
                f"{relative}"
            )


def inspect_local_image(
    reference: str,
    *,
    run: Runner = subprocess.run,
) -> ImageBinding:
    """Inspect one local reference and return its immutable binding."""

    if not isinstance(reference, str) or not reference.strip():
        raise ReleaseContainerError("Docker image reference cannot be blank.")
    completed = run(
        ["docker", "image", "inspect", reference],
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if completed.returncode != 0:
        raise ReleaseContainerError(
            f"docker image inspect failed for {reference}: "
            f"{completed.stderr.strip()}"
        )
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise ReleaseContainerError(
            "docker image inspect returned malformed JSON"
        ) from exc
    if not isinstance(payload, list) or len(payload) != 1 or not isinstance(
        payload[0],
        dict,
    ):
        raise ReleaseContainerError(
            "docker image inspect must return exactly one image object"
        )
    row = payload[0]
    image_id = str(row.get("Id", "")).strip()
    if not IMAGE_ID_RE.fullmatch(image_id):
        raise ReleaseContainerError(
            "Inspected Docker image Id must match sha256:<64 lowercase hex>."
        )
    if IMAGE_ID_RE.fullmatch(reference) and image_id != reference:
        raise ReleaseContainerError(
            "Docker inspection did not return the requested immutable image "
            "Id."
        )
    config = row.get("Config", {})
    labels = config.get("Labels", {}) if isinstance(config, dict) else {}
    labels = labels if isinstance(labels, dict) else {}
    revision = str(
        labels.get("org.opencontainers.image.revision", "")
    ).strip()
    if not COMMIT_RE.fullmatch(revision):
        raise ReleaseContainerError(
            "Inspected Docker image has no full OCI source revision."
        )
    source = str(labels.get("org.opencontainers.image.source", "")).strip()
    return ImageBinding(
        image_id=image_id,
        revision=revision,
        os=str(row.get("Os", "")).strip(),
        architecture=str(row.get("Architecture", "")).strip(),
        repo_digests=tuple(
            str(value)
            for value in row.get("RepoDigests", [])
            if isinstance(value, str)
        ),
        source=source,
    )


def validate_source_image_binding(
    source: SourceBinding,
    image: ImageBinding,
) -> None:
    if image.revision != source.commit:
        raise ReleaseContainerError(
            "Docker image OCI revision does not match the clean source "
            "revision."
        )
    if image.os != "linux":
        raise ReleaseContainerError(
            f"Release image must target Linux, got {image.os!r}."
        )
    if image.architecture != "arm64":
        raise ReleaseContainerError(
            "Release image must use the hash-locked Linux ARM64 platform, "
            f"got {image.architecture!r}."
        )
    if image.source != SOURCE_URL:
        raise ReleaseContainerError(
            "Docker image OCI source label does not match the governed "
            "repository."
        )


def build_docker_build_command(
    *,
    source: SourceBinding,
    tag: str,
    context_root: Path,
    iidfile: Path,
) -> list[str]:
    if not isinstance(tag, str) or not tag.strip():
        raise ReleaseContainerError("Docker build tag cannot be blank.")
    iidfile = iidfile.expanduser().absolute()
    if iidfile.exists() or iidfile.is_symlink():
        raise ReleaseContainerError(
            f"Docker iidfile target must be a new path: {iidfile}"
        )
    return [
        "docker",
        "build",
        "--pull",
        "--platform",
        "linux/arm64",
        "--iidfile",
        str(iidfile),
        "--build-arg",
        f"SOURCE_COMMIT={source.commit}",
        "--label",
        f"org.opencontainers.image.revision={source.commit}",
        "--label",
        f"org.opencontainers.image.source={SOURCE_URL}",
        "--tag",
        tag,
        str(context_root.expanduser().resolve()),
    ]


def _read_built_image_id(iidfile: Path) -> str:
    """Read one exact immutable image ID from a Docker-owned iidfile."""

    if not _is_regular_non_symlink(iidfile):
        raise ReleaseContainerError(
            f"Docker build did not create a regular iidfile: {iidfile}"
        )
    try:
        payload = iidfile.read_text(encoding="ascii")
    except (OSError, UnicodeError) as exc:
        raise ReleaseContainerError(
            f"Docker iidfile could not be read: {iidfile}"
        ) from exc
    image_id = payload.rstrip("\n")
    if payload not in {image_id, image_id + "\n"} or not IMAGE_ID_RE.fullmatch(
        image_id
    ):
        raise ReleaseContainerError(
            "Docker iidfile must contain exactly one immutable "
            "sha256:<64 lowercase hex> image ID."
        )
    return image_id


def _roots_overlap(left: Path, right: Path) -> bool:
    return (
        left == right
        or left in right.parents
        or right in left.parents
    )


def validate_data_root(
    *,
    source_root: Path,
    data_root: Path,
    require_empty: bool,
) -> Path:
    source = source_root.expanduser().resolve()
    raw_data = data_root.expanduser().absolute()
    if raw_data.is_symlink():
        raise ReleaseContainerError(
            f"Release data root cannot be a symlink: {raw_data}"
        )
    candidate = raw_data.resolve()
    if _roots_overlap(source, candidate):
        raise ReleaseContainerError(
            "Release source and data roots cannot overlap."
        )
    if not raw_data.is_dir():
        raise ReleaseContainerError(
            f"Release data root must already exist as a directory: {raw_data}"
        )
    data = candidate
    if require_empty and any(data.iterdir()):
        raise ReleaseContainerError(
            f"Release pipeline requires an empty data root: {data}"
        )
    return data


def _source_lock_sha256(source: SourceBinding) -> str:
    try:
        payload = bytes(
            _run_git(
                source.source_root,
                "show",
                f"{source.commit}:requirements-lock.txt",
                binary=True,
            )
        )
    except ReleaseContainerError as exc:
        raise ReleaseContainerError(
            "Release commit does not contain requirements-lock.txt."
        ) from exc
    return hashlib.sha256(payload).hexdigest()


def build_docker_run_command(
    *,
    source: SourceBinding,
    image: ImageBinding,
    data_root: Path,
    mode: str,
    years: str,
    evidence_bundle: Path | None = None,
    memory_profile: str = "standard",
) -> list[str]:
    """Build one immutable-ID Docker invocation for preflight/pipeline/gate."""

    validate_source_image_binding(source, image)
    data = validate_data_root(
        source_root=source.source_root,
        data_root=data_root,
        require_empty=False,
    )
    if mode not in {"preflight", "pipeline", "gate"}:
        raise ReleaseContainerError(
            f"Unsupported release container mode: {mode!r}"
        )
    if mode == "gate" and evidence_bundle is None:
        raise ReleaseContainerError(
            "Release gate requires an exact external evidence bundle."
        )
    if years != RELEASE_YEARS:
        raise ReleaseContainerError(
            "Release container year span must equal the canonical contract "
            f"{RELEASE_YEARS}, got {years!r}."
        )
    if memory_profile not in {"standard", "low"}:
        raise ReleaseContainerError(
            f"Unsupported pipeline memory profile: {memory_profile!r}"
        )
    lock_sha256 = _source_lock_sha256(source)
    command = [
        "docker",
        "run",
        "--rm",
        "--init",
        "--read-only",
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges",
        "--tmpfs",
        "/tmp:rw,nosuid,nodev,exec,mode=1777",
        "--mount",
        f"type=bind,src={data},dst=/data",
        "--workdir",
        "/repo",
        "--env",
        "IPEDSDB_ROOT=/data",
        "--env",
        f"YEARS={years}",
        "--env",
        f"CONTAINER_IMAGE_DIGEST={image.image_id}",
        "--env",
        f"CONTAINER_IMAGE_REVISION={source.commit}",
        "--env",
        f"CONTAINER_REQUIREMENTS_LOCK_SHA256={lock_sha256}",
        "--env",
        "GIT_OPTIONAL_LOCKS=0",
    ]
    if memory_profile == "low":
        for setting in (
            "OPENBLAS_NUM_THREADS=1",
            "OMP_NUM_THREADS=1",
            "MKL_NUM_THREADS=1",
            "NUMEXPR_NUM_THREADS=1",
            "ARROW_NUM_THREADS=1",
            "MALLOC_ARENA_MAX=2",
        ):
            command.extend(["--env", setting])
    if mode == "gate":
        command.extend(["--network", "none"])
    if evidence_bundle is not None:
        bundle = evidence_bundle.expanduser().absolute()
        if not _is_regular_non_symlink(bundle):
            raise ReleaseContainerError(
                f"Evidence bundle must be a regular non-symlink file: {bundle}"
            )
        command.extend(
            [
                "--mount",
                f"type=bind,src={bundle},dst=/evidence/review.zip,readonly",
                "--env",
                "CONTRACT_REVIEW_EVIDENCE_BUNDLE=/evidence/review.zip",
            ]
        )
    command.append(image.image_id)
    if mode == "preflight":
        command.extend(["python", "-m", "pip", "check"])
    elif mode == "pipeline":
        command.extend(
            [
                "python",
                "Scripts/00_run_all.py",
                "--root",
                "/data",
                "--years",
                years,
                "--pipeline-mode",
                "release",
                "--run-cleaning",
                "--run-qaqc",
                "--memory-profile",
                memory_profile,
            ]
        )
    else:
        command.extend(["bash", "Scripts/QA_QC/release_gate.sh"])
    return command


def _run_checked(command: Sequence[str], *, label: str) -> None:
    completed = subprocess.run(list(command), check=False)
    if completed.returncode != 0:
        raise ReleaseContainerError(
            f"{label} failed with exit {completed.returncode}"
        )


def _receipt_payload(
    source: SourceBinding,
    image: ImageBinding,
    tag: str,
) -> dict[str, object]:
    return {
        "schema_version": RECEIPT_SCHEMA_VERSION,
        "generated_at_utc": datetime.now(timezone.utc)
        .replace(microsecond=0)
        .isoformat(),
        "source_root": str(source.source_root),
        "source_commit": source.commit,
        "source_tree": source.tree,
        "requirements_lock_sha256": _source_lock_sha256(source),
        "image_tag": tag,
        "image_id": image.image_id,
        "image_revision": image.revision,
        "image_os": image.os,
        "image_architecture": image.architecture,
        "image_repo_digests": list(image.repo_digests),
        "image_source": image.source,
    }


def _write_json_atomic(path: Path, payload: Mapping[str, object]) -> None:
    path = path.expanduser().absolute()
    if path.is_symlink() or path.exists():
        raise ReleaseContainerError(
            f"Receipt target must be a new non-symlink path: {path}"
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _load_receipt(path: Path) -> dict[str, object]:
    if not _is_regular_non_symlink(path):
        raise ReleaseContainerError(
            f"Container build receipt must be a regular file: {path}"
        )
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ReleaseContainerError(
            f"Container build receipt is invalid: {exc}"
        ) from exc
    if not isinstance(payload, dict) or payload.get(
        "schema_version"
    ) != RECEIPT_SCHEMA_VERSION:
        raise ReleaseContainerError(
            "Container build receipt has an unsupported schema."
        )
    return payload


def _validate_receipt(
    receipt: Mapping[str, object],
    source: SourceBinding,
    image: ImageBinding,
) -> None:
    expected = {
        "source_commit": source.commit,
        "source_tree": source.tree,
        "requirements_lock_sha256": _source_lock_sha256(source),
        "image_id": image.image_id,
        "image_revision": image.revision,
        "image_os": image.os,
        "image_architecture": image.architecture,
        "image_source": image.source,
    }
    differences = [
        name
        for name, value in expected.items()
        if receipt.get(name) != value
    ]
    if differences:
        raise ReleaseContainerError(
            "Container build receipt differs from current bindings: "
            + ", ".join(differences)
        )


@contextlib.contextmanager
def _data_root_lock(data_root: Path) -> Iterator[None]:
    lock_path = data_root.parent / f".{data_root.name}.ipedsdb-release.lock"
    descriptor = os.open(
        lock_path,
        os.O_CREAT | os.O_RDWR,
        0o600,
    )
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ReleaseContainerError(
                f"Another release container action holds {lock_path}"
            ) from exc
        yield
    finally:
        fcntl.flock(descriptor, fcntl.LOCK_UN)
        os.close(descriptor)


def _build(args: argparse.Namespace) -> None:
    source = inspect_standalone_source(args.source)
    with tempfile.TemporaryDirectory(
        prefix="ipedsdb-image-id-"
    ) as iid_directory:
        iidfile = Path(iid_directory) / "image.id"
        with materialize_release_context(source) as context:
            command = build_docker_build_command(
                source=source,
                tag=args.tag,
                context_root=context,
                iidfile=iidfile,
            )
            _run_checked(command, label="Docker build")
        image_id = _read_built_image_id(iidfile)
    after = inspect_standalone_source(args.source)
    if after != source:
        raise ReleaseContainerError(
            "Release source changed while the image was being built."
        )
    image = inspect_local_image(image_id)
    validate_source_image_binding(source, image)
    _write_json_atomic(
        args.receipt,
        _receipt_payload(source, image, args.tag),
    )
    print(
        f"BUILT image={image.image_id} revision={image.revision} "
        f"receipt={args.receipt}"
    )


def _run_mode(args: argparse.Namespace) -> None:
    source = inspect_standalone_source(args.source)
    receipt = _load_receipt(args.receipt)
    reference = str(receipt.get("image_id", ""))
    image = inspect_local_image(reference)
    validate_source_image_binding(source, image)
    _validate_receipt(receipt, source, image)
    require_empty = args.command == "pipeline"
    data_root = validate_data_root(
        source_root=source.source_root,
        data_root=args.data_root,
        require_empty=require_empty,
    )
    evidence_bundle = getattr(args, "evidence_bundle", None)
    if args.command == "gate" and evidence_bundle is None:
        raise ReleaseContainerError(
            "Release gate requires --evidence-bundle."
        )
    command = build_docker_run_command(
        source=source,
        image=image,
        data_root=data_root,
        mode=args.command,
        years=args.years,
        evidence_bundle=evidence_bundle,
        memory_profile=getattr(args, "memory_profile", "standard"),
    )
    with _data_root_lock(data_root):
        _run_checked(command, label=f"Container {args.command}")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    build = subparsers.add_parser("build", help="build and receipt an image")
    build.add_argument("--source", required=True, type=Path)
    build.add_argument("--tag", required=True)
    build.add_argument("--receipt", required=True, type=Path)

    for name in ("preflight", "pipeline", "gate"):
        action = subparsers.add_parser(name)
        action.add_argument("--source", required=True, type=Path)
        action.add_argument("--data-root", required=True, type=Path)
        action.add_argument("--receipt", required=True, type=Path)
        action.add_argument("--years", default=RELEASE_YEARS)
        if name == "pipeline":
            action.add_argument(
                "--memory-profile",
                choices=("standard", "low"),
                default="standard",
                help="Forward the bounded resource profile to Stage 00.",
            )
        if name == "gate":
            action.add_argument("--evidence-bundle", required=True, type=Path)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "build":
            _build(args)
        else:
            _run_mode(args)
    except ReleaseContainerError as exc:
        print(f"RELEASE_CONTAINER_FAILED: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
