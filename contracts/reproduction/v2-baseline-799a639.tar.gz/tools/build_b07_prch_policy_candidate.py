#!/usr/bin/env python3
"""Expand repaired B07 semantics through the unsigned B05 analysis candidate.

The output is review-only.  This tool never edits ``contracts/prch_policy.csv``
or any other canonical contract.  Every null target is joined through exact
B05, Stage04, and enriched source identities; every observed PRCH row scope is
proved to match exactly one annual candidate rule.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
from itertools import combinations
import json
from pathlib import Path
import re
import subprocess
from typing import Iterable, Mapping, Sequence


CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
POLICY_COLUMNS = (
    "rule_id",
    "year_start",
    "year_end",
    "flag",
    "code",
    "action",
    "target_columns",
    "row_predicate",
    "accounting_standard",
    "form",
    "part",
    "review_status",
    "source_reference",
    "rationale",
)
PREDICATE_COLUMNS = {
    "PRCH_ADM": "STAT_ADM",
    "PRCH_AL": "STAT_AL",
    "PRCH_C": "STAT_C",
    "PRCH_E12": "STAT_E12",
    "PRCH_EAP": "STAT_EAP",
    "PRCH_EF": "STAT_EF",
    "PRCH_F": "FORM_F",
    "PRCH_GR": "STAT_GR",
    "PRCH_GR2": "STAT_GR2",
    "PRCH_HR": "STAT_HR",
    "PRCH_OM": "STAT_OM",
    "PRCH_S": "STAT_S",
    "PRCH_SA": "STAT_SA",
    "PRCH_SFA": "STAT_SFA",
    "PRCHTP_F": "FORM_F",
}
FORM_TO_SOURCE_FORM = {"4": "1", "2": "2", "3": "3"}
FORM_NAMES = {"4": "GASB", "2": "FASB", "3": "private_for_profit"}
FINANCE_SOURCE_FILES = {"F_F", "F_FA", "DRVF"}
PARTIAL_SEMANTICS = {
    "partial_child_parent_reported_parts",
    "partial_child_non_ipeds_reporting_entity",
    "nested_partial_parent_parent_reported_parts",
}
PROTECTED_TARGET_PREFIXES = (
    "PRCH",
    "STAT_",
    "REV_",
    "LOCK_",
    "IDX_",
    "PCF_",
)
EXACT_SOURCE_COMPONENTS = {
    "ADM": "PRCH_ADM",
    "DRVADM": "PRCH_ADM",
    "AL": "PRCH_AL",
    "DRVAL": "PRCH_AL",
    "C_B": "PRCH_C",
    "DRVC": "PRCH_C",
    "EFFY_HS": "PRCH_E12",
    "EFIA": "PRCH_E12",
    "EFD": "PRCH_EF",
    "EFDS": "PRCH_EF",
    "EFF": "PRCH_EF",
    "DRVGR": "PRCH_GR",
    "GR_GENDER": "PRCH_GR",
    "GR_L": "PRCH_GR",
    "GR200": "PRCH_GR2",
    "DRVHR": "PRCH_HR",
    "SAL_NIS": "PRCH_HR",
    "DRVOM": "PRCH_OM",
    "SFA": "PRCH_SFA",
    "SFA_P": "PRCH_SFA",
    "SFAV": "PRCH_SFA",
}
FINANCE_2010_F1_METADATA_EXCEPTIONS = {
    (2010, "F0910_F1A", varname, varnumber): {
        "corrected_part": corrected_part,
        "observed_part": observed_part,
        "official_pdf_page": official_pdf_page,
    }
    for varname, varnumber, corrected_part, observed_part, official_pdf_page in (
        ("F1D01", 62281, "D", "M", "9"),
        ("F1D02", 62286, "D", "M", "9"),
        ("F1D03", 62291, "D", "M", "9"),
        ("F1D04", 62296, "D", "M", "9"),
        ("F1D05", 62301, "D", "M", "9"),
        ("F1D06", 62306, "D", "M", "9"),
        ("F1H01", 62311, "H", "E", "11"),
        ("F1H02", 62316, "H", "E", "11"),
        ("F1E01", 62321, "E", "D", "10"),
        ("F1E02", 62326, "E", "D", "10"),
        ("F1E03", 62331, "E", "D", "10"),
        ("F1E04", 62336, "E", "D", "10"),
        ("F1E05", 62341, "E", "D", "10"),
        ("F1E06", 62346, "E", "D", "10"),
        ("F1E07", 62351, "E", "D", "10"),
        ("F1E08", 62356, "E", "D", "10"),
        ("F1E09", 62361, "E", "D", "10"),
        ("F1E10", 62366, "E", "D", "10"),
        ("F1E11", 62371, "E", "D", "10"),
        ("F1FHA", 62376, "H", "E", "2"),
    )
}
FINANCE_2010_F1_OFFICIAL_MEMBER = "f_1_2010.pdf"
FINANCE_2010_F1_OFFICIAL_MEMBER_SHA256 = (
    "cc78eca3dd67fee2ec216551449c3783f438bd327f4c0f573e5a338d8ee46f98"
)
DRVEF_2006_COMPONENT_EXCEPTIONS = {
    (2006, "DRVEF2006", varname, varnumber): {
        "operational_component_flag": "PRCH_EF",
        "metadata_component_flag": "PRCH_E12",
    }
    for varname, varnumber in (
        ("UNDUP", 23360),
        ("UNDUPUG", 23362),
        ("FTE12MN", 23365),
    )
}


class CandidateEvidenceError(RuntimeError):
    """Raised when exact review-only expansion cannot be proven."""


def component_binding(
    *,
    source_file: str,
    access_table_name: str,
) -> tuple[str, str]:
    source_file = str(source_file)
    table = str(access_table_name).upper()
    if not table:
        return "", "missing_exact_access_table_identity"
    if source_file in FINANCE_SOURCE_FILES:
        valid = (
            (
                source_file == "F_F"
                and re.fullmatch(r"F\d{4}_F[123]", table)
            )
            or (
                source_file == "F_FA"
                and re.fullmatch(r"F\d{4}_F1A", table)
            )
            or (
                source_file == "DRVF"
                and re.fullmatch(r"DRVF\d{4}", table)
            )
        )
        if not valid:
            return "", "unresolved_finance_access_table_identity"
        return "PRCH_F", "exact_finance_access_table_component"
    if source_file == "DRVEF":
        if re.fullmatch(r"DRVEF12\d{4}", table):
            return "PRCH_E12", "proposed_exact_table_variable_component"
        if re.fullmatch(r"DRVEF\d{4}", table):
            return "PRCH_EF", "proposed_exact_table_variable_component"
        return "", "unresolved_mixed_component_table"
    if source_file == "DFR":
        return "", "unresolved_mixed_component_table"
    if source_file in EXACT_SOURCE_COMPONENTS:
        return (
            EXACT_SOURCE_COMPONENTS[source_file],
            "proposed_exact_table_variable_component",
        )
    return "", "not_prch_component"


def propose_dfr_component(
    *,
    year: int,
    section_title: str,
) -> tuple[str, str]:
    title = " ".join(str(section_title).casefold().split())
    if title.startswith("frequently used enrollment variables: fall"):
        flag = "PRCH_EF"
    elif title.startswith("frequently used enrollment variables: academic year"):
        flag = "PRCH_E12"
    elif title == "total awards/degrees by award level":
        flag = "PRCH_C"
    elif title == "salaries of full-time instructional faculty, by academic rank":
        flag = "PRCH_SA" if int(year) == 2004 else "PRCH_HR"
    elif title.startswith("frequently used financial indicators"):
        flag = "PRCH_F"
    elif title == "frequently used graduation rates":
        flag = "PRCH_GR"
    elif title == "percent of fte professional staff by assigned position":
        flag = "PRCH_EAP"
    elif title.startswith("full-time equivalent staff by assigned position"):
        flag = "PRCH_HR"
    elif title in {
        "directory information, response status and frequently used variables",
        "tuition and fees",
    }:
        return "", "not_prch_component"
    else:
        return "", "unresolved_mixed_component_table"
    return flag, "proposed_exact_section_component"


def _drvef_metadata_component(section_title: str) -> str:
    title = " ".join(str(section_title).casefold().split())
    if "fall" in title:
        return "PRCH_EF"
    if "academic year" in title:
        return "PRCH_E12"
    if re.fullmatch(
        r"frequently used enrollment variables: \d{4}-\d{2}",
        title,
    ):
        return "PRCH_E12"
    return ""


def resolve_component_binding(
    *,
    year: int,
    source_file: str,
    access_table_name: str,
    source_varnumber: object,
    source_varname: str,
    source_var_title: str,
    source_section_title: str,
) -> tuple[str, str, str]:
    table_flag, table_status = component_binding(
        source_file=source_file,
        access_table_name=access_table_name,
    )
    if source_file == "DFR":
        flag, status = propose_dfr_component(
            year=year,
            section_title=source_section_title,
        )
        return flag, status, ""
    if source_file != "DRVEF":
        return table_flag, table_status, ""

    metadata_flag = _drvef_metadata_component(source_section_title)
    if not metadata_flag:
        raise CandidateEvidenceError(
            "DRVEF identity lacks exact component metadata: "
            f"{year}:{access_table_name}:{source_varname}"
        )
    if table_flag == metadata_flag:
        return table_flag, table_status, ""
    key = (
        int(year),
        str(access_table_name).upper(),
        str(source_varname).upper(),
        _normalized_number(source_varnumber),
    )
    exception = DRVEF_2006_COMPONENT_EXCEPTIONS.get(key)
    if (
        exception is None
        or exception["operational_component_flag"] != table_flag
        or exception["metadata_component_flag"] != metadata_flag
        or "12-month" not in str(source_var_title).casefold()
    ):
        raise CandidateEvidenceError(
            "unregistered DRVEF component contradiction: "
            f"{year}:{access_table_name}:{source_varname}:"
            f"table={table_flag}:metadata={metadata_flag}"
        )
    exception_id = (
        "B07-COMPMETA-"
        f"{year}-{access_table_name}-{source_varname.upper()}-"
        f"{_normalized_number(source_varnumber)}"
    )
    return (
        table_flag,
        "proposed_transitional_operational_exception",
        exception_id,
    )


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_output_directory(*, repo: Path, out: Path) -> None:
    contracts = (repo / "contracts").resolve()
    resolved = out.resolve()
    if resolved == contracts or contracts in resolved.parents:
        raise CandidateEvidenceError(
            "review output directory cannot be inside canonical contracts"
        )
    if resolved.exists() and any(resolved.iterdir()):
        raise CandidateEvidenceError(
            f"review output directory must be empty: {resolved}"
        )


def canonical_contract_snapshot(repo: Path) -> dict[str, str]:
    root = repo / "contracts"
    return {
        path.relative_to(repo).as_posix(): sha256_file(path)
        for path in sorted(
            (candidate for candidate in root.rglob("*") if candidate.is_file()),
            key=lambda candidate: candidate.relative_to(root).as_posix().casefold(),
        )
    }


def validate_artifact_manifest(*, manifest_path: Path, artifact_root: Path) -> None:
    rows = read_csv(manifest_path)
    seen: set[str] = set()
    for row in rows:
        relative = row["path"]
        if relative in seen:
            raise CandidateEvidenceError(
                f"artifact manifest contains duplicate path: {relative}"
            )
        seen.add(relative)
        path = artifact_root / relative
        if not path.is_file():
            raise CandidateEvidenceError(
                f"artifact manifest path is missing: {relative}"
            )
        if int(row["byte_size"]) != path.stat().st_size:
            raise CandidateEvidenceError(
                f"artifact manifest byte size mismatch: {relative}"
            )
        if row["sha256"] != sha256_file(path):
            raise CandidateEvidenceError(
                f"artifact manifest SHA-256 mismatch: {relative}"
            )


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(
    path: Path,
    fieldnames: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=fieldnames,
            extrasaction="raise",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(rows)


def expand_year_signature(value: str) -> tuple[int, ...]:
    years: list[int] = []
    for token in str(value).split("|"):
        token = token.strip()
        if not token:
            raise CandidateEvidenceError("blank token in year signature")
        if ":" in token:
            left, right = token.split(":", 1)
            start, end = int(left), int(right)
            if start > end:
                raise CandidateEvidenceError(f"descending year range: {token}")
            years.extend(range(start, end + 1))
        else:
            years.append(int(token))
    if len(years) != len(set(years)):
        raise CandidateEvidenceError(f"overlapping year signature: {value}")
    if any(year < 2004 or year > 2023 for year in years):
        raise CandidateEvidenceError(f"out-of-scope year signature: {value}")
    return tuple(years)


def _normalized_number(value: object) -> int:
    try:
        return int(str(value).strip())
    except ValueError as exc:
        raise CandidateEvidenceError(f"invalid NCES VarNumber: {value!r}") from exc


def _source_form_part(
    source_file: str,
    source_varname: str,
    access_table_name: str,
) -> tuple[str, str]:
    if source_file not in FINANCE_SOURCE_FILES:
        return "", ""
    match = re.fullmatch(r"F([123])([A-Z]).*", source_varname, flags=re.IGNORECASE)
    if not match:
        raise CandidateEvidenceError(
            f"Finance source identity lacks exact form/part token: {source_varname}"
        )
    source_form, source_part = match.group(1), match.group(2).upper()
    table = access_table_name.upper()
    if source_file == "F_FA" and (
        source_form != "1" or not table.endswith("_F1A")
    ):
        raise CandidateEvidenceError(
            f"F_FA form identity conflicts with Access table: {access_table_name}"
        )
    if source_file == "F_F" and not table.endswith(f"_F{source_form}"):
        raise CandidateEvidenceError(
            f"F_F form identity conflicts with Access table: {access_table_name}"
        )
    if source_file == "DRVF":
        if not table.startswith("DRVF"):
            raise CandidateEvidenceError(
                f"DRVF identity conflicts with Access table: {access_table_name}"
            )
        source_part = "derived"
    return source_form, source_part


def _direct_finance_part_from_section(
    source_form: str,
    section_title: str,
) -> str:
    title = " ".join(section_title.casefold().split())
    if title in {"statement of financial position", "statement of net assets",
                 "plant, property, and equipment", "balance sheet information"}:
        return "A"
    if title in {
        "summary of changes in net assets",
        "summary of changes in net position",
        "summary of changes in equity",
    }:
        return "D" if source_form == "1" else "B"
    if title in {"revenues and other additions", "revenues and investment return"}:
        return "B" if source_form == "1" else "D"
    if title in {
        "expenses and other deductions",
        "expenses by functional and natural classification",
        "expenses by function",
    }:
        return "C" if source_form == "1" else "E"
    if title in {
        "scholarships and fellowships",
        "scholarships and fellowships/discounts and allowances",
        "student grants",
        "student grants, discounts and allowances",
    }:
        return "E" if source_form == "1" else "C"
    if title == "details on endowment assets":
        return "H"
    if title in {
        "pension information",
        "pension and postemployment benefits other than pension (opeb)",
    }:
        return "M"
    if title == "income tax expenses" and source_form == "3":
        return "F"
    if title == "financial health":
        return {"1": "N", "2": "I", "3": "G"}[source_form]
    raise CandidateEvidenceError(
        f"unmapped exact Finance SectionTitle for form F{source_form}: "
        f"{section_title!r}"
    )


def _resolve_direct_finance_part(
    *,
    year: int,
    access_table_name: str,
    source_form: str,
    source_varname: str,
    source_varnumber: object,
    section_title: str,
) -> tuple[str, str, str, str]:
    observed_part = _direct_finance_part_from_section(
        source_form,
        section_title,
    )
    key = (
        int(year),
        str(access_table_name).upper(),
        source_varname.upper(),
        _normalized_number(source_varnumber),
    )
    exception = FINANCE_2010_F1_METADATA_EXCEPTIONS.get(key)
    if exception is not None:
        if exception["observed_part"] != observed_part:
            raise CandidateEvidenceError(
                "registered Finance exception no longer matches observed "
                f"section metadata: {key}"
            )
        exception_id = (
            "B07-FINMETA-"
            f"{year}-{access_table_name.replace('_', '-')}-"
            f"{source_varname.upper()}-{_normalized_number(source_varnumber)}"
        )
        return (
            exception["corrected_part"],
            observed_part,
            exception_id,
            exception["official_pdf_page"],
        )
    match = re.fullmatch(
        r"F([123])([A-Z])\d+",
        source_varname,
        flags=re.IGNORECASE,
    )
    if not match:
        return observed_part, observed_part, "", ""
    identity_part = match.group(2).upper()
    if identity_part == observed_part:
        return observed_part, observed_part, "", ""
    raise CandidateEvidenceError(
        "unregistered Finance part contradiction: "
        f"{year}:{access_table_name}:{source_varname}:"
        f"section={observed_part}:identity={identity_part}"
    )


def bind_one_b05_identity(
    *,
    year: int,
    b05: Mapping[str, str],
    stage_candidates: Sequence[Mapping[str, str]],
    enriched_candidates: Sequence[Mapping[str, str]],
    vartable_candidates: Sequence[Mapping[str, str]],
) -> dict[str, object]:
    if len(stage_candidates) != 1:
        raise CandidateEvidenceError(
            f"expected one exact Stage04 identity for {year}:"
            f"{b05['source_file']}:{b05['source_varname']}; "
            f"found {len(stage_candidates)}"
        )
    stage = stage_candidates[0]
    if (
        int(stage["year_start"]) != year
        or int(stage["year_end"]) != year
        or stage["source_file"] != b05["source_file"]
        or stage["column_name"].casefold() != b05["source_varname"].casefold()
        or stage["role"] != "measure"
    ):
        raise CandidateEvidenceError("Stage04 source identity is not exact scalar measure")
    if len(enriched_candidates) != 1:
        raise CandidateEvidenceError(
            f"expected one exact enriched identity for {year}:"
            f"{stage['access_table_pattern']}:{stage['column_name']}; "
            f"found {len(enriched_candidates)}"
        )
    enriched = enriched_candidates[0]
    if (
        enriched["column_metadata_match_status"] != "exact"
        or enriched["candidate_role"] not in {"measure", "measure_candidate"}
        or enriched["matched_varname"].casefold()
        != b05["source_varname"].casefold()
        or _normalized_number(enriched["matched_varnumber"])
        != _normalized_number(b05["source_varnumber"])
    ):
        raise CandidateEvidenceError(
            f"enriched metadata identity is not exact for {b05['variable_id']}"
        )
    if len(vartable_candidates) != 1:
        raise CandidateEvidenceError(
            f"expected one exact annual VARTABLE identity for {year}:"
            f"{stage['access_table_pattern']}:{stage['column_name']}; "
            f"found {len(vartable_candidates)}"
        )
    vartable = vartable_candidates[0]
    if (
        vartable["varname"].casefold() != b05["source_varname"].casefold()
        or _normalized_number(vartable["varnumber"])
        != _normalized_number(b05["source_varnumber"])
    ):
        raise CandidateEvidenceError(
            f"annual VARTABLE identity conflicts with {b05['variable_id']}"
        )
    if (
        b05["source_file"] in {"F_F", "F_FA", "DRVF"}
        and vartable["tablename"].casefold()
        != stage["access_table_pattern"].casefold()
    ):
        raise CandidateEvidenceError(
            f"Finance VARTABLE table identity conflicts with {b05['variable_id']}"
        )
    metadata_alias_decision_id = ""
    if (
        b05["source_file"] not in {"F_F", "F_FA", "DRVF"}
        and vartable["tablename"].casefold()
        != stage["access_table_pattern"].casefold()
    ):
        exact_candidate_identity = (
            f"{vartable['tablename']}:"
            f"{enriched.get('matched_file_number', '')}:"
            f"{_normalized_number(vartable['varnumber'])}:"
            f"{vartable['varname']}"
        )
        candidate_identities = enriched.get(
            "metadata_candidate_identities", ""
        ).split("|")
        if (
            year != 2023
            or b05["source_file"] != "SFA_P"
            or {
                stage["access_table_pattern"].upper(),
                vartable["tablename"].upper(),
            }
            != {"SFA2223_P1", "SFA2223_P2"}
            or enriched.get("metadata_join_reason", "")
            != "approved B04 exact cross-table metadata alias"
            or enriched.get("metadata_decision_source", "")
            != "reviewed B04 alias"
            or enriched.get("metadata_decision_justification", "")
            != (
                "Author-countersigned B04-ALIAS-001; exact same-table "
                "metadata retains precedence."
            )
            or exact_candidate_identity not in candidate_identities
        ):
            raise CandidateEvidenceError(
                "unreviewed non-Finance cross-table metadata alias: "
                f"{year}:{stage['access_table_pattern']}:"
                f"{vartable['tablename']}:{b05['source_varname']}"
            )
        metadata_alias_decision_id = "B04-ALIAS-001"
    source_form, source_part = _source_form_part(
        b05["source_file"],
        b05["source_varname"],
        stage["access_table_pattern"],
    )
    if b05["source_file"] in {"F_F", "F_FA"} and (
        not vartable.get("sectionnumber", "").strip()
        or not vartable.get("sectiontitle", "").strip()
    ):
        raise CandidateEvidenceError(
            f"direct Finance identity lacks Access section metadata: "
            f"{year}:{b05['source_varname']}"
        )
    observed_source_part = source_part
    finance_metadata_exception_id = ""
    finance_official_part_page = ""
    if b05["source_file"] in {"F_F", "F_FA"}:
        (
            source_part,
            observed_source_part,
            finance_metadata_exception_id,
            finance_official_part_page,
        ) = _resolve_direct_finance_part(
            year=year,
            access_table_name=stage["access_table_pattern"],
            source_form=source_form,
            source_varname=b05["source_varname"],
            source_varnumber=b05["source_varnumber"],
            section_title=vartable["sectiontitle"],
        )
    (
        component_flag,
        component_status,
        component_metadata_exception_id,
    ) = resolve_component_binding(
        year=year,
        source_file=b05["source_file"],
        access_table_name=stage["access_table_pattern"],
        source_varnumber=b05["source_varnumber"],
        source_varname=b05["source_varname"],
        source_var_title=vartable.get("vartitle", ""),
        source_section_title=vartable.get("sectiontitle", ""),
    )
    return {
        "contract_id": CONTRACT_ID,
        "year": year,
        "variable_id": b05["variable_id"],
        "candidate_decision_id": b05.get("candidate_decision_id", ""),
        "analysis_column": b05["analysis_column"],
        "source_file": b05["source_file"],
        "source_varnumber": b05["source_varnumber"],
        "source_varname": b05["source_varname"],
        "access_table_name": stage["access_table_pattern"],
        "source_column_name": stage["column_name"],
        "source_form": source_form,
        "source_part": source_part,
        "source_part_observed_from_section": observed_source_part,
        "finance_metadata_exception_id": finance_metadata_exception_id,
        "finance_official_part_page": finance_official_part_page,
        "source_section_number": vartable.get("sectionnumber", "").strip(),
        "source_section_title": vartable.get("sectiontitle", "").strip(),
        "metadata_access_table_name": vartable.get("tablename", "").strip(),
        "metadata_alias_decision_id": metadata_alias_decision_id,
        "metadata_join_reason": enriched.get("metadata_join_reason", ""),
        "metadata_decision_source": enriched.get(
            "metadata_decision_source", ""
        ),
        "metadata_decision_justification": enriched.get(
            "metadata_decision_justification", ""
        ),
        "source_var_title": vartable.get("vartitle", "").strip(),
        "source_long_description_sha256": hashlib.sha256(
            vartable.get("longdescription", "").encode()
        ).hexdigest(),
        "component_flag": component_flag,
        "component_binding_status": component_status,
        "component_metadata_exception_id": component_metadata_exception_id,
        "metadata_source": enriched.get("matched_metadata_source", ""),
        "source_csv_sha256": enriched.get("source_csv_sha256", ""),
        "binding_status": "exact",
    }


def _is_protected_target(column: str) -> bool:
    normalized = column.upper()
    return (
        normalized in {"UNITID", "YEAR", "FORM_F"}
        or normalized.startswith(PROTECTED_TARGET_PREFIXES)
    )


def _part_matches(source_part: str, parent_parts: Sequence[str]) -> bool:
    if source_part == "M":
        return any(part == "M" or part.startswith("M") for part in parent_parts)
    return source_part in set(parent_parts)


def select_null_target_bindings(
    *,
    flag: str,
    year: int,
    form_code: str,
    semantic_class: str,
    parent_parts: Sequence[str],
    bindings: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    eligible = [
        dict(row)
        for row in bindings
        if int(row["year"]) == int(year)
        and row["binding_status"] == "exact"
        and not _is_protected_target(str(row["analysis_column"]))
    ]
    if flag != "PRCH_F":
        selected = [
            row
            for row in eligible
            if row.get("component_flag") == flag
            and row.get("component_binding_status")
            in {
                "proposed_exact_table_variable_component",
                "proposed_exact_section_component",
                "proposed_transitional_operational_exception",
            }
        ]
    else:
        source_form = FORM_TO_SOURCE_FORM.get(str(form_code), "")
        finance = [
            row
            for row in eligible
            if row["source_file"] in FINANCE_SOURCE_FILES
            or (
                row.get("component_flag") == "PRCH_F"
                and row.get("component_binding_status")
                == "proposed_exact_section_component"
            )
        ]
        if semantic_class in PARTIAL_SEMANTICS:
            if not source_form:
                raise CandidateEvidenceError(
                    f"partial Finance scope lacks exact form: {year}:{form_code}"
                )
            selected = [
                row
                for row in finance
                if str(row["source_form"]) == source_form
                and (
                    (
                        row["source_file"] in {"F_F", "F_FA"}
                        and _part_matches(str(row["source_part"]), parent_parts)
                    )
                    or (
                        row["source_file"] == "DRVF"
                        and row["source_varname"] == f"F{source_form}EQUITR"
                    )
                )
            ]
        elif source_form:
            selected = [
                row
                for row in finance
                if str(row["source_form"]) == source_form
                or row["source_file"] == "DFR"
            ]
        elif str(form_code) == "-2":
            selected = finance
        else:
            raise CandidateEvidenceError(
                f"full Finance scope has unsupported form: {year}:{form_code}"
            )
    selected.sort(
        key=lambda row: (
            str(row["analysis_column"]).casefold(),
            str(row.get("variable_id", "")),
        )
    )
    columns = [str(row["analysis_column"]) for row in selected]
    if len(columns) != len(set(columns)):
        raise CandidateEvidenceError(
            f"multiple exact B05 identities target one analysis column in {year}:{flag}"
        )
    return selected


def operational_action(
    *,
    semantic_action: str,
    selected_targets: Sequence[object],
) -> tuple[str, str]:
    if semantic_action == "retain":
        return "retain", "semantic_retain"
    if semantic_action != "null":
        raise CandidateEvidenceError(f"unsupported semantic action: {semantic_action}")
    if not selected_targets:
        return "retain", "semantic_null_but_zero_exact_scalar_b05_targets"
    return "null", "semantic_null_with_exact_scalar_b05_targets"


def stable_rule_id(
    *,
    year: int,
    flag: str,
    code: int,
    predicate_column: str,
    predicate_value: int,
    action: str,
    target_columns: Sequence[str],
) -> str:
    identity = json.dumps(
        {
            "action": action,
            "code": int(code),
            "flag": flag,
            "predicate": {predicate_column: int(predicate_value)},
            "targets": sorted(set(target_columns), key=str.casefold),
            "year": int(year),
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return "B07-POL-" + hashlib.sha256(identity.encode()).hexdigest()[:12].upper()


def build_coverage_proof(
    scopes: Sequence[Mapping[str, object]],
    rules: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    matched_rule_ids: list[str] = []
    for scope in scopes:
        expected_predicate = {
            str(scope["predicate_column"]): int(scope["predicate_value"])
        }
        matching = [
            rule
            for rule in rules
            if int(rule["year_start"]) <= int(scope["year"]) <= int(rule["year_end"])
            and str(rule["flag"]) == str(scope["flag"])
            and int(rule["code"]) == int(scope["code"])
            and json.loads(str(rule["row_predicate"])) == expected_predicate
        ]
        status = "exact" if len(matching) == 1 else "missing_or_multiple"
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "year": scope["year"],
                "flag": scope["flag"],
                "code": scope["code"],
                "predicate_column": scope["predicate_column"],
                "predicate_value": scope["predicate_value"],
                "observed_row_count": scope["observed_row_count"],
                "matching_rule_count": len(matching),
                "matching_rule_ids": "|".join(
                    sorted(str(rule["rule_id"]) for rule in matching)
                ),
                "coverage_status": status,
            }
        )
        matched_rule_ids.extend(str(rule["rule_id"]) for rule in matching)
    if any(row["coverage_status"] != "exact" for row in output):
        raise CandidateEvidenceError("predicate coverage is missing or overlapping")
    if set(matched_rule_ids) != {str(rule["rule_id"]) for rule in rules}:
        raise CandidateEvidenceError("candidate contains a rule outside observed coverage")
    return output


def build_cross_flag_collision_proof(
    *,
    rows_by_year: Mapping[int, Sequence[Mapping[str, str]]],
    rules: Sequence[Mapping[str, object]],
    required_pairs: Sequence[tuple[int, str, str]] = (),
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    """Enumerate exact UNITID-year target-cell collisions across PRCH flags.

    A structural rule-overlap check cannot prove that two different flag
    families never act on the same analysis cell for the same institution.
    This function therefore resolves every populated annual flag cell through
    its exact code and row predicate, then intersects the resolved target sets.
    """

    rule_index: dict[
        tuple[int, str, int, str, int], Mapping[str, object]
    ] = {}
    flags_by_year: dict[int, set[str]] = {}
    for rule in rules:
        start = int(rule["year_start"])
        end = int(rule["year_end"])
        if start != end:
            raise CandidateEvidenceError(
                "row-level collision proof requires annual candidate rules"
            )
        predicate = json.loads(str(rule["row_predicate"]))
        if not isinstance(predicate, dict) or len(predicate) != 1:
            raise CandidateEvidenceError(
                f"rule has non-exact row predicate: {rule['rule_id']}"
            )
        predicate_column, predicate_value = next(iter(predicate.items()))
        key = (
            start,
            str(rule["flag"]),
            int(rule["code"]),
            str(predicate_column),
            int(predicate_value),
        )
        if key in rule_index:
            raise CandidateEvidenceError(
                f"multiple rules resolve the same row-level scope: {key}"
            )
        rule_index[key] = rule
        flags_by_year.setdefault(start, set()).add(str(rule["flag"]))

    pair_stats: dict[tuple[int, str, str], dict[str, object]] = {}

    def ensure_pair(year: int, left: str, right: str) -> dict[str, object]:
        left, right = sorted((left, right))
        key = (int(year), left, right)
        if key not in pair_stats:
            pair_stats[key] = {
                "contract_id": CONTRACT_ID,
                "year": int(year),
                "left_flag": left,
                "right_flag": right,
                "coactive_row_count": 0,
                "both_null_row_count": 0,
                "_collision_cell_count": 0,
                "_unitids": set(),
                "_targets": set(),
                "_classes": set(),
            }
        return pair_stats[key]

    for year, left, right in required_pairs:
        ensure_pair(year, left, right)

    collisions: list[dict[str, object]] = []
    conflicting: list[dict[str, object]] = []
    for year in sorted(rows_by_year):
        seen_unitids: set[str] = set()
        expected_flags = flags_by_year.get(int(year), set())
        for raw in rows_by_year[year]:
            unitid = str(raw.get("UNITID", "")).strip()
            if not unitid:
                raise CandidateEvidenceError(
                    f"{year} FLAGS row lacks UNITID during collision proof"
                )
            if unitid in seen_unitids:
                raise CandidateEvidenceError(
                    f"{year} FLAGS contains duplicate UNITID {unitid}"
                )
            seen_unitids.add(unitid)
            active: dict[str, Mapping[str, object]] = {}
            for flag in sorted(expected_flags):
                code_text = str(raw.get(flag, "")).strip()
                if not code_text:
                    continue
                predicate_column = PREDICATE_COLUMNS.get(flag)
                if not predicate_column:
                    raise CandidateEvidenceError(
                        f"no exact predicate column declared for {year}:{flag}"
                    )
                predicate_text = str(raw.get(predicate_column, "")).strip()
                if not predicate_text:
                    raise CandidateEvidenceError(
                        f"{year}:{unitid}:{flag} lacks {predicate_column}"
                    )
                key = (
                    int(year),
                    flag,
                    int(code_text),
                    predicate_column,
                    int(predicate_text),
                )
                rule = rule_index.get(key)
                if rule is None:
                    raise CandidateEvidenceError(
                        f"row-level flag cell lacks exactly resolved rule: "
                        f"{year}:{unitid}:{flag}:{code_text}:{predicate_text}"
                    )
                active[flag] = rule

            active_flags = sorted(active)
            for left, right in combinations(active_flags, 2):
                stats = ensure_pair(year, left, right)
                stats["coactive_row_count"] = (
                    int(stats["coactive_row_count"]) + 1
                )
                if {
                    str(active[left]["action"]),
                    str(active[right]["action"]),
                } == {"null"}:
                    stats["both_null_row_count"] = (
                        int(stats["both_null_row_count"]) + 1
                    )

            owners_by_target: dict[
                str, list[Mapping[str, object]]
            ] = {}
            for rule in active.values():
                targets = [
                    token
                    for token in str(rule["target_columns"]).split("|")
                    if token
                ]
                for target in targets:
                    owners_by_target.setdefault(target, []).append(rule)
            for target, owners in sorted(
                owners_by_target.items(), key=lambda item: item[0].casefold()
            ):
                owner_flags = sorted({str(rule["flag"]) for rule in owners})
                if len(owner_flags) < 2:
                    continue
                actions = sorted({str(rule["action"]) for rule in owners})
                contexts = sorted(
                    {
                        "|".join(
                            (
                                str(rule.get("accounting_standard", "")),
                                str(rule.get("form", "")),
                                str(rule.get("part", "")),
                            )
                        )
                        for rule in owners
                    }
                )
                collision_class = (
                    "idempotent_null_null"
                    if actions == ["null"]
                    else "conflicting_actions_or_semantics"
                )
                collision = {
                    "contract_id": CONTRACT_ID,
                    "year": int(year),
                    "unitid": unitid,
                    "analysis_column": target,
                    "rule_ids": "|".join(
                        sorted(str(rule["rule_id"]) for rule in owners)
                    ),
                    "flags": "|".join(owner_flags),
                    "codes": "|".join(
                        sorted(
                            f"{rule['flag']}={rule['code']}" for rule in owners
                        )
                    ),
                    "actions": "|".join(actions),
                    "semantic_contexts": "||".join(contexts),
                    "collision_class": collision_class,
                    "approval_status": (
                        "pending_author_approval"
                        if collision_class == "idempotent_null_null"
                        else "fatal"
                    ),
                }
                collisions.append(collision)
                if collision_class != "idempotent_null_null":
                    conflicting.append(collision)
                for left, right in combinations(owner_flags, 2):
                    stats = ensure_pair(year, left, right)
                    stats["_collision_cell_count"] = (
                        int(stats["_collision_cell_count"]) + 1
                    )
                    stats["_unitids"].add(unitid)
                    stats["_targets"].add(target)
                    stats["_classes"].add(collision_class)

    collisions.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["unitid"]),
            str(row["analysis_column"]).casefold(),
            str(row["flags"]),
        )
    )
    pair_rows: list[dict[str, object]] = []
    for key in sorted(pair_stats):
        stats = pair_stats[key]
        targets = sorted(
            stats["_targets"], key=lambda value: str(value).casefold()
        )
        classes = sorted(stats["_classes"])
        if "conflicting_actions_or_semantics" in classes:
            collision_class = "conflicting_actions_or_semantics"
            approval_status = "fatal"
        elif "idempotent_null_null" in classes:
            collision_class = "idempotent_null_null"
            approval_status = "pending_author_approval"
        else:
            collision_class = "none"
            approval_status = "no_collision"
        target_text = "|".join(str(value) for value in targets)
        pair_rows.append(
            {
                "contract_id": CONTRACT_ID,
                "year": stats["year"],
                "left_flag": stats["left_flag"],
                "right_flag": stats["right_flag"],
                "coactive_row_count": stats["coactive_row_count"],
                "both_null_row_count": stats["both_null_row_count"],
                "row_level_collision_count": stats["_collision_cell_count"],
                "affected_unitid_count": len(stats["_unitids"]),
                "distinct_shared_target_count": len(targets),
                "shared_targets": target_text,
                "shared_targets_sha256": (
                    hashlib.sha256(target_text.encode()).hexdigest()
                    if target_text
                    else ""
                ),
                "collision_class": collision_class,
                "approval_status": approval_status,
            }
        )
    if conflicting:
        first = conflicting[0]
        raise CandidateEvidenceError(
            "conflicting cross-flag target-cell collision: "
            f"{first['year']}:{first['unitid']}:{first['analysis_column']}:"
            f"{first['flags']}"
        )
    return collisions, pair_rows


def _casefold_csv(directory: Path, stem: str) -> Path:
    matches = [
        path for path in directory.glob("*.csv") if path.stem.casefold() == stem.casefold()
    ]
    if len(matches) != 1:
        raise CandidateEvidenceError(
            f"expected one {stem} CSV in {directory}; found {len(matches)}"
        )
    return matches[0]


def build_prch_source_registry(
    *,
    legacy_root: Path,
    observed_rows: Sequence[Mapping[str, str]],
    years: Sequence[int] = tuple(range(2004, 2024)),
) -> dict[int, list[dict[str, object]]]:
    """Bind each observed year/flag to one exact, hash-verified source table."""

    selected_years = {int(year) for year in years}
    identities: dict[tuple[int, str], tuple[str, str]] = {}
    flags_by_table: dict[tuple[int, str, str], set[str]] = {}
    for row in observed_rows:
        year = int(row["year"])
        if year not in selected_years:
            continue
        flag = str(row["flag"]).upper()
        if flag not in PREDICATE_COLUMNS:
            raise CandidateEvidenceError(
                f"no exact predicate declared for observed flag: {year}:{flag}"
            )
        table_name = str(row.get("access_table_name", "")).strip()
        source_hash = str(row.get("source_csv_sha256", "")).strip().lower()
        if not table_name or not re.fullmatch(r"[0-9a-f]{64}", source_hash):
            raise CandidateEvidenceError(
                f"observed PRCH identity lacks exact table/hash binding: {year}:{flag}"
            )
        key = (year, flag)
        identity = (table_name, source_hash)
        prior = identities.get(key)
        if prior is not None and prior != identity:
            raise CandidateEvidenceError(
                f"{year}:{flag} occurs in multiple source tables: "
                f"{prior[0]}|{table_name}"
            )
        identities[key] = identity
        flags_by_table.setdefault(
            (year, table_name.casefold(), source_hash),
            set(),
        ).add(flag)

    registry: dict[int, list[dict[str, object]]] = {
        year: [] for year in sorted(selected_years)
    }
    for (year, table_key, source_hash), flags in sorted(flags_by_table.items()):
        table_names = {
            table_name
            for (identity_year, flag), (table_name, identity_hash) in identities.items()
            if identity_year == year
            and table_name.casefold() == table_key
            and identity_hash == source_hash
            and flag in flags
        }
        if len(table_names) != 1:
            raise CandidateEvidenceError(
                f"{year}:{table_key} has inconsistent exact table spelling"
            )
        table_name = next(iter(table_names))
        directory = (
            legacy_root
            / "Raw_Access_Databases"
            / str(year)
            / "tables_csv"
        )
        path = _casefold_csv(directory, table_name)
        if sha256_file(path) != source_hash:
            raise CandidateEvidenceError(
                f"observed PRCH source hash mismatch: {year}:{table_name}"
            )
        rows = read_csv(path)
        if not rows:
            raise CandidateEvidenceError(
                f"observed PRCH source table is empty: {year}:{table_name}"
            )
        header = {str(field).upper() for field in rows[0]}
        required = {"UNITID"}
        for flag in flags:
            required.add(flag)
            required.add(PREDICATE_COLUMNS[flag])
        missing = sorted(required - header)
        if missing:
            raise CandidateEvidenceError(
                f"{year}:{table_name} lacks exact PRCH source fields: "
                + "|".join(missing)
            )
        unitids = [str(row.get("UNITID", "")).strip() for row in rows]
        if any(not unitid for unitid in unitids) or len(set(unitids)) != len(unitids):
            raise CandidateEvidenceError(
                f"{year}:{table_name} has blank or duplicate UNITID"
            )
        registry[year].append(
            {
                "path": path,
                "table_name": table_name,
                "source_csv_sha256": source_hash,
                "flags": tuple(sorted(flags)),
                "rows": rows,
            }
        )
    for year in registry:
        registry[year].sort(key=lambda row: str(row["table_name"]).casefold())
    return registry


def _semantic_index(
    rows: Sequence[Mapping[str, str]],
) -> dict[tuple[int, str, int], Mapping[str, str]]:
    output: dict[tuple[int, str, int], Mapping[str, str]] = {}
    for row in rows:
        if (
            row["contract_id"] != CONTRACT_ID
            or row["candidate_status"]
            not in {
                "supported_author_countersign_pending",
                "supported_b05_target_binding_and_author_countersign_pending",
            }
            or row["author_decision"].strip()
            or row["author_name"].strip()
            or row["author_date"].strip()
        ):
            raise CandidateEvidenceError(
                f"B07 semantic decision is not unsigned supported evidence: "
                f"{row['decision_id']}"
            )
        if row["candidate_action"] not in {"retain", "null"}:
            raise CandidateEvidenceError(
                f"unresolved B07 semantic decision: {row['decision_id']}"
            )
        for year in expand_year_signature(row["years_observed"]):
            key = (year, row["flag"], int(row["observed_code"]))
            if key in output:
                raise CandidateEvidenceError(f"overlapping B07 semantic identity: {key}")
            output[key] = row
    return output


def build_observed_predicate_scopes(
    *,
    legacy_root: Path,
    observed_rows: Sequence[Mapping[str, str]],
    semantic_rows: Sequence[Mapping[str, str]],
    years: Sequence[int] = tuple(range(2004, 2024)),
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    semantics = _semantic_index(semantic_rows)
    selected_years = {int(year) for year in years}
    filtered_observed = [
        row for row in observed_rows if int(row["year"]) in selected_years
    ]
    observed_index = {
        (int(row["year"]), row["flag"], int(row["observed_code"])): row
        for row in filtered_observed
    }
    if len(observed_index) != len(filtered_observed):
        raise CandidateEvidenceError("duplicate observed B07 year/flag/code identity")
    scopes: list[dict[str, object]] = []
    flag_inputs: list[dict[str, object]] = []
    actual_keys: set[tuple[int, str, int]] = set()
    registry = build_prch_source_registry(
        legacy_root=legacy_root,
        observed_rows=observed_rows,
        years=years,
    )
    for year in sorted(registry):
        for source in registry[year]:
            path = source["path"]
            rows = source["rows"]
            for flag in source["flags"]:
                predicate_column = PREDICATE_COLUMNS[str(flag)]
                grouped: dict[tuple[int, int], int] = {}
                for row in rows:
                    normalized = {
                        str(key).upper(): value for key, value in row.items()
                    }
                    code_text = str(normalized.get(flag, "")).strip()
                    if not code_text:
                        continue
                    predicate_text = str(
                        normalized.get(predicate_column, "")
                    ).strip()
                    if not predicate_text:
                        raise CandidateEvidenceError(
                            f"{year}:{flag}:{code_text} has blank "
                            f"{predicate_column}"
                        )
                    key = (int(code_text), int(predicate_text))
                    grouped[key] = grouped.get(key, 0) + 1
                for (code, predicate_value), count in sorted(grouped.items()):
                    identity = (year, str(flag), code)
                    actual_keys.add(identity)
                    observed = observed_index.get(identity)
                    semantic = semantics.get(identity)
                    if observed is None or semantic is None:
                        raise CandidateEvidenceError(
                            f"actual PRCH source scope lacks B07 evidence: "
                            f"{identity}"
                        )
                    scopes.append(
                        {
                            "contract_id": CONTRACT_ID,
                            "year": year,
                            "flag": flag,
                            "code": code,
                            "predicate_column": predicate_column,
                            "predicate_value": predicate_value,
                            "observed_row_count": count,
                            "semantic_decision_id": semantic["decision_id"],
                            "semantic_action": semantic["candidate_action"],
                            "semantic_class": semantic["semantic_class"],
                            "value_label": semantic["value_label"],
                            "access_table_name": source["table_name"],
                            "source_csv_sha256": source[
                                "source_csv_sha256"
                            ],
                        }
                    )
            flag_inputs.append(
                {
                    "input_kind": "annual_prch_source",
                    "path": path.relative_to(legacy_root).as_posix(),
                    "byte_size": path.stat().st_size,
                    "sha256": source["source_csv_sha256"],
                }
            )
    if actual_keys != set(observed_index):
        missing = sorted(set(observed_index) - actual_keys)
        raise CandidateEvidenceError(
            f"B07 observed evidence not reproduced in exact PRCH sources: "
            f"{missing[:10]}"
        )
    actual_counts: dict[tuple[int, str, int], int] = {}
    for scope in scopes:
        key = (int(scope["year"]), str(scope["flag"]), int(scope["code"]))
        actual_counts[key] = actual_counts.get(key, 0) + int(
            scope["observed_row_count"]
        )
    for key, observed in observed_index.items():
        if (
            actual_counts[key] != int(observed["observed_row_count"])
            or int(observed["metadata_frequency"])
            != int(observed["observed_row_count"])
            or observed["metadata_frequency_match"].strip().lower() != "true"
        ):
            raise CandidateEvidenceError(
                f"PRCH source count/hash evidence mismatch: {key}"
            )
    scopes.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["flag"]),
            int(row["code"]),
            int(row["predicate_value"]),
        )
    )
    flag_inputs.sort(key=lambda row: str(row["path"]))
    return scopes, flag_inputs


def load_annual_prch_rows(
    legacy_root: Path,
    *,
    observed_rows: Sequence[Mapping[str, str]],
    years: Sequence[int] = tuple(range(2004, 2024)),
) -> dict[int, list[dict[str, str]]]:
    registry = build_prch_source_registry(
        legacy_root=legacy_root,
        observed_rows=observed_rows,
        years=years,
    )
    output: dict[int, list[dict[str, str]]] = {}
    for year in sorted(registry):
        by_unitid: dict[str, dict[str, str]] = {}
        for source in registry[year]:
            fields = {
                field
                for flag in source["flags"]
                for field in (str(flag), PREDICATE_COLUMNS[str(flag)])
            }
            for raw in source["rows"]:
                normalized = {
                    str(key).upper(): str(value).strip()
                    for key, value in raw.items()
                }
                unitid = normalized["UNITID"]
                merged = by_unitid.setdefault(unitid, {"UNITID": unitid})
                for field in sorted(fields):
                    value = normalized.get(field, "")
                    if not value:
                        continue
                    prior = merged.get(field)
                    if prior is not None and prior != value:
                        raise CandidateEvidenceError(
                            f"{year}:{unitid}:{field} conflicts across exact PRCH sources"
                        )
                    merged[field] = value
        output[year] = [by_unitid[key] for key in sorted(by_unitid)]
    return output


def load_annual_flags_rows(
    legacy_root: Path,
    *,
    years: Sequence[int] = tuple(range(2004, 2024)),
) -> dict[int, list[dict[str, str]]]:
    """Load the exact consolidated FLAGS tables for FLAGS-specific proofs."""

    output: dict[int, list[dict[str, str]]] = {}
    for year in sorted({int(value) for value in years}):
        directory = (
            legacy_root
            / "Raw_Access_Databases"
            / str(year)
            / "tables_csv"
        )
        output[year] = read_csv(_casefold_csv(directory, f"FLAGS{year}"))
    return output


def load_annual_vartable_index(
    legacy_root: Path,
) -> tuple[
    dict[tuple[int, str, int], list[dict[str, str]]],
    list[dict[str, object]],
]:
    index: dict[tuple[int, str, int], list[dict[str, str]]] = {}
    inputs: list[dict[str, object]] = []
    for year in range(2004, 2024):
        directory = legacy_root / "Raw_Access_Databases" / str(year) / "tables_csv"
        path = _casefold_csv(directory, f"vartable{str(year)[-2:]}")
        inputs.append(
            {
                "input_kind": "annual_vartable",
                "path": path.relative_to(legacy_root).as_posix(),
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
        for raw in read_csv(path):
            row = {key.casefold(): value for key, value in raw.items()}
            key = (
                year,
                row.get("varname", "").casefold(),
                _normalized_number(row.get("varnumber", "")),
            )
            index.setdefault(key, []).append(row)
    inputs.sort(key=lambda row: str(row["path"]))
    return index, inputs


def _load_exact_bindings(
    *,
    b05_rows: Sequence[Mapping[str, str]],
    stage_rows: Sequence[Mapping[str, str]],
    enriched_rows: Sequence[Mapping[str, str]],
    vartable_index: Mapping[
        tuple[int, str, int], Sequence[Mapping[str, str]]
    ],
    schema_rows: Sequence[Mapping[str, str]],
    decision_rows: Sequence[Mapping[str, str]],
) -> tuple[list[dict[str, object]], str]:
    b05_decision_rows = [
        row for row in decision_rows if row["phase"] == "B05"
    ]
    if len({row["decision_id"] for row in b05_decision_rows}) != len(
        b05_decision_rows
    ):
        raise CandidateEvidenceError("duplicate B05 decision id")
    b05_decisions = {
        row["decision_id"]: row for row in b05_decision_rows
    }
    if not b05_decisions or any(
        row["review_status"]
        not in {"pending_author_review", "pending_author_semantic_review"}
        or row["reviewer_decision"].strip()
        for row in b05_decisions.values()
    ):
        raise CandidateEvidenceError(
            "current B05 input is not uniformly unsigned/pending-author-review"
        )
    if len({row["analysis_column"] for row in schema_rows}) != len(schema_rows):
        raise CandidateEvidenceError("duplicate analysis-schema column")
    if len({row["variable_id"] for row in b05_rows}) != len(b05_rows):
        raise CandidateEvidenceError("duplicate B05 variable identity")
    schema = {row["analysis_column"]: row for row in schema_rows}
    stage_index: dict[tuple[int, str, str], list[Mapping[str, str]]] = {}
    for row in stage_rows:
        key = (
            int(row["year_start"]),
            row["source_file"],
            row["column_name"].casefold(),
        )
        stage_index.setdefault(key, []).append(row)
    enriched_index: dict[tuple[int, str, str], list[Mapping[str, str]]] = {}
    for row in enriched_rows:
        key = (
            int(row["year"]),
            row["access_table_name"].casefold(),
            row["column_name"].casefold(),
        )
        enriched_index.setdefault(key, []).append(row)

    output: list[dict[str, object]] = []
    seen_year_columns: set[tuple[int, str]] = set()
    for b05 in sorted(b05_rows, key=lambda row: row["variable_id"]):
        decision = b05_decisions.get(b05["candidate_decision_id"])
        if decision is None:
            raise CandidateEvidenceError(
                f"B05 identity lacks unsigned decision row: {b05['variable_id']}"
            )
        if (
            decision["contract_id"] != CONTRACT_ID
            or decision["candidate_key"] != b05["analysis_column"]
            or b05["variable_id"]
            not in decision["exact_source_identities"].split("|")
            or decision["source_varname"].casefold()
            != b05["source_varname"].casefold()
            or _normalized_number(decision["source_varnumber"])
            != _normalized_number(b05["source_varnumber"])
            or not set(expand_year_signature(b05["years_present"])).issubset(
                expand_year_signature(decision["years_present"])
            )
        ):
            raise CandidateEvidenceError(
                f"B05 decision identity conflicts with mapping: "
                f"{b05['variable_id']}"
            )
        schema_row = schema.get(b05["analysis_column"])
        if schema_row is None or f"variable_id:{b05['variable_id']}" not in schema_row[
            "source_variables"
        ].split("|"):
            raise CandidateEvidenceError(
                f"B05 identity lacks exact analysis-schema lineage: {b05['variable_id']}"
            )
        for year in expand_year_signature(b05["years_present"]):
            stages = stage_index.get(
                (year, b05["source_file"], b05["source_varname"].casefold()),
                [],
            )
            enriched = []
            if len(stages) == 1:
                enriched = enriched_index.get(
                    (
                        year,
                        stages[0]["access_table_pattern"].casefold(),
                        b05["source_varname"].casefold(),
                    ),
                    [],
                )
            vartable = (
                list(
                    vartable_index.get(
                        (
                            year,
                            b05["source_varname"].casefold(),
                            _normalized_number(b05["source_varnumber"]),
                        ),
                        (),
                    )
                )
                if len(stages) == 1
                else []
            )
            binding = bind_one_b05_identity(
                year=year,
                b05=b05,
                stage_candidates=stages,
                enriched_candidates=enriched,
                vartable_candidates=vartable,
            )
            column_key = (year, str(binding["analysis_column"]))
            if column_key in seen_year_columns:
                raise CandidateEvidenceError(
                    f"multiple B05 identities bind {year}:{binding['analysis_column']}"
                )
            seen_year_columns.add(column_key)
            output.append(binding)
    output.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["analysis_column"]).casefold(),
            str(row["variable_id"]),
        )
    )
    return output, "unsigned_pending_author_review_and_semantic_review"


def build_component_binding_register(
    bindings: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    by_analysis: dict[str, list[Mapping[str, object]]] = {}
    for row in bindings:
        by_analysis.setdefault(str(row["analysis_column"]), []).append(row)
    output: list[dict[str, object]] = []
    for row in bindings:
        if row["source_file"] in FINANCE_SOURCE_FILES:
            continue
        identity = (
            f"{row['year']}|{row['access_table_name']}|{row['variable_id']}|"
            f"{row['component_flag']}|{row['component_binding_status']}"
        )
        decision_id = (
            "B07-COMP-"
            + hashlib.sha256(identity.encode()).hexdigest()[:12].upper()
        )
        row["component_decision_id"] = decision_id
        status = str(row["component_binding_status"])
        if status == "unresolved_mixed_component_table":
            review_status = "request_more_evidence"
            proposed_action = "unresolved"
        elif status == "not_prch_component":
            review_status = "pending_author_review"
            proposed_action = "intentionally_exclude_from_prch"
        else:
            review_status = "pending_author_review"
            proposed_action = "bind_component_flag"
        cross_year = sorted(
            by_analysis[str(row["analysis_column"])],
            key=lambda item: (int(item["year"]), str(item["variable_id"])),
        )
        output.append(
            {
                "decision_id": decision_id,
                "contract_id": CONTRACT_ID,
                "year": row["year"],
                "access_table_name": row["access_table_name"],
                "metadata_access_table_name": row["metadata_access_table_name"],
                "metadata_alias_decision_id": row.get(
                    "metadata_alias_decision_id", ""
                ),
                "variable_id": row["variable_id"],
                "source_file": row["source_file"],
                "source_varnumber": row["source_varnumber"],
                "source_varname": row["source_varname"],
                "source_var_title": row["source_var_title"],
                "source_section_number": row["source_section_number"],
                "source_section_title": row["source_section_title"],
                "analysis_column": row["analysis_column"],
                "cross_year_same_analysis_identities": "|".join(
                    f"{item['year']}:{item['variable_id']}:{item['access_table_name']}"
                    for item in cross_year
                ),
                "proposed_component_flag": row["component_flag"],
                "component_metadata_exception_id": row.get(
                    "component_metadata_exception_id", ""
                ),
                "proposed_action": proposed_action,
                "proposal_basis": status,
                "source_long_description_sha256": row[
                    "source_long_description_sha256"
                ],
                "review_status": review_status,
                "author_decision": "",
                "author_name": "",
                "author_date": "",
            }
        )
    output.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["access_table_name"]).casefold(),
            str(row["source_varnumber"]),
            str(row["source_varname"]).casefold(),
        )
    )
    if len({str(row["decision_id"]) for row in output}) != len(output):
        raise CandidateEvidenceError("component binding decision id collision")
    return output


def build_b04_alias_lineage(
    bindings: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    output = [
        {
            "contract_id": CONTRACT_ID,
            "alias_decision_id": row["metadata_alias_decision_id"],
            "year": row["year"],
            "source_file": row["source_file"],
            "access_table_name": row["access_table_name"],
            "metadata_access_table_name": row["metadata_access_table_name"],
            "variable_id": row["variable_id"],
            "source_varnumber": row["source_varnumber"],
            "source_varname": row["source_varname"],
            "analysis_column": row["analysis_column"],
            "metadata_join_reason": row["metadata_join_reason"],
            "metadata_decision_source": row["metadata_decision_source"],
            "metadata_decision_justification": row[
                "metadata_decision_justification"
            ],
            "binding_status": "exact_countersigned_B04_alias",
        }
        for row in bindings
        if row["metadata_alias_decision_id"]
    ]
    if len(output) != 343:
        raise CandidateEvidenceError(
            f"expected 343 exact B04 alias bindings; found {len(output)}"
        )
    output.sort(
        key=lambda row: (
            str(row["access_table_name"]).casefold(),
            _normalized_number(row["source_varnumber"]),
            str(row["source_varname"]).casefold(),
        )
    )
    return output


def build_finance_source_part_bindings(
    bindings: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for row in bindings:
        if row["source_file"] not in FINANCE_SOURCE_FILES:
            continue
        identity = (
            f"{row['year']}|{row['access_table_name']}|{row['variable_id']}|"
            f"{row['source_form']}|{row['source_part']}"
        )
        binding_id = (
            "B07-FIN-"
            + hashlib.sha256(identity.encode()).hexdigest()[:12].upper()
        )
        row["finance_binding_id"] = binding_id
        is_direct = row["source_file"] in {"F_F", "F_FA"}
        if is_direct and (
            "source_part_observed_from_section" not in row
            or "finance_metadata_exception_id" not in row
            or "finance_official_part_page" not in row
        ):
            raise CandidateEvidenceError(
                f"direct Finance binding lacks part diagnostics: "
                f"{row['variable_id']}"
            )
        output.append(
            {
                "finance_binding_id": binding_id,
                "contract_id": CONTRACT_ID,
                "year": row["year"],
                "access_table_name": row["access_table_name"],
                "metadata_access_table_name": row["metadata_access_table_name"],
                "variable_id": row["variable_id"],
                "source_file": row["source_file"],
                "source_varnumber": row["source_varnumber"],
                "source_varname": row["source_varname"],
                "source_var_title": row["source_var_title"],
                "source_section_number": row["source_section_number"],
                "source_section_title": row["source_section_title"],
                "source_form": row["source_form"],
                "source_part": row["source_part"],
                "source_part_observed_from_section": row.get(
                    "source_part_observed_from_section",
                    row["source_part"],
                ),
                "finance_metadata_exception_id": row.get(
                    "finance_metadata_exception_id", ""
                ),
                "finance_official_part_page": row.get(
                    "finance_official_part_page", ""
                ),
                "analysis_column": row["analysis_column"],
                "partial_rule_eligibility": (
                    "exact_direct_form_part"
                    if is_direct
                    else (
                        "exact_equity_ratio_only"
                        if row["source_varname"]
                        == f"F{row['source_form']}EQUITR"
                        else "excluded_from_partial_rules"
                    )
                ),
                "binding_basis": (
                    "exact_annual_vartable_section_and_access_table"
                    if is_direct
                    else "exact_derived_varname_and_access_table"
                ),
                "source_long_description_sha256": row[
                    "source_long_description_sha256"
                ],
                "review_status": "pending_author_review",
                "author_decision": "",
                "author_name": "",
                "author_date": "",
            }
        )
    output.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["access_table_name"]).casefold(),
            str(row["source_varnumber"]),
            str(row["source_varname"]).casefold(),
        )
    )
    if len({str(row["finance_binding_id"]) for row in output}) != len(output):
        raise CandidateEvidenceError("Finance source-part binding id collision")
    return output


def build_finance_metadata_exception_register(
    *,
    bindings: Sequence[Mapping[str, object]],
    official_source_rows: Sequence[Mapping[str, str]],
) -> list[dict[str, object]]:
    official = [
        row
        for row in official_source_rows
        if row["year"] == "2010"
        and row["member_name"] == FINANCE_2010_F1_OFFICIAL_MEMBER
        and row["sha256"] == FINANCE_2010_F1_OFFICIAL_MEMBER_SHA256
        and row["integrity_status"] == "exact"
    ]
    if len(official) != 1:
        raise CandidateEvidenceError(
            "2010 GASB official source identity is missing or ambiguous"
        )
    source = official[0]
    exception_bindings = [
        row for row in bindings if row["finance_metadata_exception_id"]
    ]
    actual_keys = {
        (
            int(row["year"]),
            str(row["access_table_name"]).upper(),
            str(row["source_varname"]).upper(),
            _normalized_number(row["source_varnumber"]),
        )
        for row in exception_bindings
    }
    if actual_keys != set(FINANCE_2010_F1_METADATA_EXCEPTIONS):
        missing = sorted(set(FINANCE_2010_F1_METADATA_EXCEPTIONS) - actual_keys)
        extra = sorted(actual_keys - set(FINANCE_2010_F1_METADATA_EXCEPTIONS))
        raise CandidateEvidenceError(
            "2010 Finance metadata exception coverage mismatch: "
            f"missing={missing[:3]}; extra={extra[:3]}"
        )
    output: list[dict[str, object]] = []
    for row in exception_bindings:
        output.append(
            {
                "decision_id": row["finance_metadata_exception_id"],
                "contract_id": CONTRACT_ID,
                "year": row["year"],
                "access_table_name": row["access_table_name"],
                "variable_id": row["variable_id"],
                "source_varnumber": row["source_varnumber"],
                "source_varname": row["source_varname"],
                "source_var_title": row["source_var_title"],
                "source_section_number": row["source_section_number"],
                "source_section_title": row["source_section_title"],
                "source_part_observed_from_section": row[
                    "source_part_observed_from_section"
                ],
                "source_part_from_exact_variable_identity": row["source_part"],
                "candidate_resolution": (
                    "use_exact_variable_part_identity_for_conditional_targeting"
                ),
                "exception_reason": (
                    "2010_F0910_F1A_VARTABLE_section_metadata_shift"
                ),
                "official_source_url": source["url"],
                "official_pdf_member": source["member_name"],
                "official_pdf_sha256": source["sha256"],
                "official_pdf_part_page": row[
                    "finance_official_part_page"
                ],
                "official_parent_child_comparison_page": "32",
                "evidence_note": (
                    "Exact 2010 GASB form labels the variable-identity part on "
                    "the cited page; page 32 proves parent-reported Parts A|D. "
                    "Annual VARTABLE SectionTitle is shifted for this exact row."
                ),
                "review_status": "pending_author_review",
                "author_decision": "",
                "author_name": "",
                "author_date": "",
            }
        )
    output.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["access_table_name"]),
            _normalized_number(row["source_varnumber"]),
        )
    )
    return output


def build_component_metadata_exception_register(
    *,
    bindings: Sequence[Mapping[str, object]],
    rows_by_year: Mapping[int, Sequence[Mapping[str, str]]],
    legacy_root: Path,
) -> list[dict[str, object]]:
    exception_bindings = [
        row for row in bindings if row["component_metadata_exception_id"]
    ]
    actual_keys = {
        (
            int(row["year"]),
            str(row["access_table_name"]).upper(),
            str(row["source_varname"]).upper(),
            _normalized_number(row["source_varnumber"]),
        )
        for row in exception_bindings
    }
    if actual_keys != set(DRVEF_2006_COMPONENT_EXCEPTIONS):
        missing = sorted(set(DRVEF_2006_COMPONENT_EXCEPTIONS) - actual_keys)
        extra = sorted(actual_keys - set(DRVEF_2006_COMPONENT_EXCEPTIONS))
        raise CandidateEvidenceError(
            "2006 DRVEF exception coverage mismatch: "
            f"missing={missing}; extra={extra}"
        )
    flags = list(rows_by_year.get(2006, ()))
    if not flags:
        raise CandidateEvidenceError("2006 FLAGS rows unavailable")
    header = set(flags[0])
    if (
        "PRCH_EF" not in header
        or "STAT_EF" not in header
        or "PRCH_E12" in header
        or "STAT_E12" in header
    ):
        raise CandidateEvidenceError(
            "2006 FLAGS operational EF/E12 topology changed"
        )
    scoped_unitids = {
        row["UNITID"].strip()
        for row in flags
        if row["PRCH_EF"].strip() == "2"
        and row["STAT_EF"].strip() == "1"
    }
    if not scoped_unitids:
        raise CandidateEvidenceError(
            "2006 transitional PRCH_EF child scope is empty"
        )
    table_path = _casefold_csv(
        legacy_root / "Raw_Access_Databases/2006/tables_csv",
        "DRVEF2006",
    )
    table_rows = read_csv(table_path)
    by_unitid = {row["UNITID"].strip(): row for row in table_rows}
    if len(by_unitid) != len(table_rows):
        raise CandidateEvidenceError("DRVEF2006 UNITID is not unique")
    if not scoped_unitids.issubset(by_unitid):
        raise CandidateEvidenceError(
            "2006 PRCH_EF child scope does not bind DRVEF2006"
        )
    output: list[dict[str, object]] = []
    for row in exception_bindings:
        source_varname = str(row["source_varname"])
        nonempty_count = sum(
            bool(by_unitid[unitid][source_varname].strip())
            for unitid in scoped_unitids
        )
        if nonempty_count != len(scoped_unitids):
            raise CandidateEvidenceError(
                "2006 DRVEF transitional value proof is incomplete: "
                f"{source_varname}:{nonempty_count}/{len(scoped_unitids)}"
            )
        if (
            row["source_csv_sha256"]
            and row["source_csv_sha256"] != sha256_file(table_path)
        ):
            raise CandidateEvidenceError(
                f"DRVEF2006 source CSV hash mismatch: {source_varname}"
            )
        output.append(
            {
                "decision_id": row["component_metadata_exception_id"],
                "contract_id": CONTRACT_ID,
                "year": row["year"],
                "access_table_name": row["access_table_name"],
                "variable_id": row["variable_id"],
                "source_varnumber": row["source_varnumber"],
                "source_varname": source_varname,
                "source_var_title": row["source_var_title"],
                "source_section_number": row["source_section_number"],
                "source_section_title": row["source_section_title"],
                "table_component_flag": "PRCH_EF",
                "metadata_semantic_component_flag": "PRCH_E12",
                "candidate_operational_component_flag": row["component_flag"],
                "flags_has_prch_ef": "true",
                "flags_has_stat_ef": "true",
                "flags_has_prch_e12": "false",
                "flags_has_stat_e12": "false",
                "prch_ef_2_stat_ef_1_unitid_count": len(scoped_unitids),
                "nonempty_value_count_in_scoped_rows": nonempty_count,
                "source_csv_sha256": sha256_file(table_path),
                "candidate_resolution": (
                    "retain_transitional_PRCH_EF_operational_binding"
                ),
                "exception_reason": (
                    "2006_combined_DRVEF_table_precedes_separate_DRVEF12_table"
                ),
                "review_status": "pending_author_review",
                "author_decision": "",
                "author_name": "",
                "author_date": "",
            }
        )
    output.sort(
        key=lambda row: _normalized_number(row["source_varnumber"])
    )
    return output


def build_semantic_conflict_diagnostic(
    bindings: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for row in bindings:
        source_file = str(row["source_file"])
        table_flag, _ = component_binding(
            source_file=source_file,
            access_table_name=str(row["access_table_name"]),
        )
        metadata_flag = ""
        if source_file == "DRVEF":
            metadata_flag = _drvef_metadata_component(
                str(row["source_section_title"])
            )
        elif source_file == "DFR":
            metadata_flag, _ = propose_dfr_component(
                year=int(row["year"]),
                section_title=str(row["source_section_title"]),
            )
        finance_part_conflict = (
            source_file in {"F_F", "F_FA"}
            and row["source_part"]
            != row["source_part_observed_from_section"]
        )
        component_conflict = bool(
            table_flag
            and metadata_flag
            and table_flag != metadata_flag
        )
        exception_id = str(
            row["finance_metadata_exception_id"]
            or row["component_metadata_exception_id"]
        )
        if (finance_part_conflict or component_conflict) and not exception_id:
            raise CandidateEvidenceError(
                "unresolved exact semantic conflict: "
                f"{row['year']}:{row['access_table_name']}:"
                f"{row['source_varname']}"
            )
        if finance_part_conflict:
            status = "resolved_by_official_finance_metadata_exception"
        elif component_conflict:
            status = "resolved_by_transitional_operational_exception"
        elif source_file == "DFR":
            status = (
                "exact_section_component_proposal"
                if metadata_flag
                else "exact_section_noncomponent_proposal"
            )
        elif source_file == "DRVEF":
            status = "table_and_section_component_consistent"
        elif source_file in {"F_F", "F_FA"}:
            status = "variable_identity_and_section_part_consistent"
        else:
            status = "no_second_component_classifier_available"
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "year": row["year"],
                "access_table_name": row["access_table_name"],
                "variable_id": row["variable_id"],
                "source_file": source_file,
                "source_varnumber": row["source_varnumber"],
                "source_varname": row["source_varname"],
                "source_var_title": row["source_var_title"],
                "source_section_number": row["source_section_number"],
                "source_section_title": row["source_section_title"],
                "table_component_proposal": table_flag,
                "metadata_component_proposal": metadata_flag,
                "candidate_component_flag": row["component_flag"],
                "finance_part_from_variable_identity": row["source_part"],
                "finance_part_from_section": row[
                    "source_part_observed_from_section"
                ],
                "component_conflict_detected": str(component_conflict).lower(),
                "finance_part_conflict_detected": str(
                    finance_part_conflict
                ).lower(),
                "exception_decision_id": exception_id,
                "resolution_status": status,
                "unresolved_conflict": "false",
            }
        )
    output.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["access_table_name"]).casefold(),
            _normalized_number(row["source_varnumber"]),
            str(row["source_varname"]).casefold(),
        )
    )
    return output


def build_component_binding_summary(
    rows: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    grouped: dict[
        tuple[str, str, str], list[Mapping[str, object]]
    ] = {}
    for row in rows:
        key = (
            str(row["proposed_action"]),
            str(row["proposed_component_flag"]) or "<blank_noncomponent>",
            str(row["proposal_basis"]),
        )
        grouped.setdefault(key, []).append(row)
    output: list[dict[str, object]] = []
    for key in sorted(grouped):
        members = grouped[key]
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "proposed_action": key[0],
                "proposed_component_flag": key[1],
                "proposal_basis": key[2],
                "annual_identity_count": len(members),
                "distinct_variable_identity_count": len(
                    {str(row["variable_id"]) for row in members}
                ),
                "distinct_access_table_count": len(
                    {
                        (int(row["year"]), str(row["access_table_name"]))
                        for row in members
                    }
                ),
                "years_present": "|".join(
                    str(year) for year in sorted({int(row["year"]) for row in members})
                ),
                "review_status": "pending_collective_author_countersign",
            }
        )
    return output


def build_finance_binding_summary(
    rows: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    grouped: dict[
        tuple[str, str, str, str, str], list[Mapping[str, object]]
    ] = {}
    for row in rows:
        key = (
            str(row["source_file"]),
            str(row["source_form"]),
            str(row["source_part"]),
            str(row["partial_rule_eligibility"]),
            (
                "official_exception_pending"
                if row["finance_metadata_exception_id"]
                else "no_exception"
            ),
        )
        grouped.setdefault(key, []).append(row)
    output: list[dict[str, object]] = []
    for key in sorted(grouped):
        members = grouped[key]
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "source_file": key[0],
                "source_form": key[1],
                "source_part": key[2],
                "partial_rule_eligibility": key[3],
                "metadata_exception_status": key[4],
                "annual_identity_count": len(members),
                "distinct_variable_identity_count": len(
                    {str(row["variable_id"]) for row in members}
                ),
                "years_present": "|".join(
                    str(year) for year in sorted({int(row["year"]) for row in members})
                ),
                "review_status": "pending_collective_author_countersign",
            }
        )
    return output


def _form_context(
    *,
    flag: str,
    predicate_value: int,
    inferred_form: str,
    parent_parts: Sequence[str],
    action: str,
    semantic_class: str,
) -> tuple[str, str, str]:
    if flag not in {"PRCH_F", "PRCHTP_F"}:
        return (
            "not_applicable",
            flag.removeprefix("PRCH_").removeprefix("PRCH"),
            "component_scalar_payload" if action == "null" else "none",
        )
    form_code = inferred_form or str(predicate_value)
    if form_code in FORM_NAMES:
        accounting = FORM_NAMES[form_code]
        form = f"F{FORM_TO_SOURCE_FORM[form_code]}"
    elif form_code == "-2":
        accounting, form = "all_finance_forms", "ALL"
    else:
        accounting, form = "not_observed", "not_observed"
    if flag == "PRCHTP_F":
        part = "topology"
    elif action != "null":
        part = "none"
    elif semantic_class in PARTIAL_SEMANTICS:
        part = "|".join(parent_parts)
    else:
        part = "all_finance_payload"
    return accounting, form, part


def _build_rules(
    *,
    scopes: Sequence[Mapping[str, object]],
    bindings: Sequence[Mapping[str, object]],
    form_matrix: Sequence[Mapping[str, str]],
    exception_scopes: Sequence[Mapping[str, str]],
    source_reference: str,
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
]:
    matrix_index = {
        (int(row["year"]), row["form_f_code"]): row for row in form_matrix
    }
    exception_index = {
        (int(row["year"]), row["prch_f"], row["form_f"]): row
        for row in exception_scopes
    }
    by_year: dict[int, list[Mapping[str, object]]] = {}
    for row in bindings:
        by_year.setdefault(int(row["year"]), []).append(row)
    rules: list[dict[str, object]] = []
    lineage: list[dict[str, object]] = []
    zero_targets: list[dict[str, object]] = []
    for scope in scopes:
        year = int(scope["year"])
        flag = str(scope["flag"])
        code = int(scope["code"])
        predicate_value = int(scope["predicate_value"])
        semantic_action = str(scope["semantic_action"])
        semantic_class = str(scope["semantic_class"])
        inferred_form = ""
        parent_parts: tuple[str, ...] = ()
        if (
            flag == "PRCH_F"
            and semantic_class in PARTIAL_SEMANTICS
            and predicate_value == -2
        ):
            exception = exception_index.get((year, str(code), "-2"))
            if exception is None:
                raise CandidateEvidenceError(
                    f"partial FORM_F=-2 scope lacks repaired proof: {year}:{code}"
                )
            if exception["candidate_actions"] == "retain":
                semantic_action = "retain"
            elif exception["candidate_actions"] == "null":
                forms = exception["inferred_exact_forms"]
                if forms not in {"F1", "F2", "F3"}:
                    raise CandidateEvidenceError(
                        f"FORM_F=-2 scope has no single inferred form: {year}:{code}"
                    )
                inferred_form = {"F1": "4", "F2": "2", "F3": "3"}[forms]
            else:
                raise CandidateEvidenceError(
                    f"FORM_F=-2 scope is unresolved: {year}:{code}"
                )
        form_code = inferred_form or str(predicate_value)
        if flag == "PRCH_F" and semantic_class in PARTIAL_SEMANTICS:
            matrix = matrix_index.get((year, form_code))
            if semantic_action == "null" and matrix is None:
                raise CandidateEvidenceError(
                    f"partial Finance scope lacks exact annual form matrix: {year}:{form_code}"
                )
            if matrix is not None:
                if (
                    matrix["source_binding_status"] != "exact"
                    or not matrix["page_locator"].strip()
                ):
                    raise CandidateEvidenceError(
                        f"annual Finance matrix is not source/page bound: {year}:{form_code}"
                    )
                parent_parts = tuple(
                    part
                    for part in matrix["parent_reported_child_omits_parts"].split("|")
                    if part
                )
        selected: list[dict[str, object]] = []
        if semantic_action == "null":
            selected = select_null_target_bindings(
                flag=flag,
                year=year,
                form_code=form_code,
                semantic_class=semantic_class,
                parent_parts=parent_parts,
                bindings=by_year.get(year, []),
            )
        action, action_reason = operational_action(
            semantic_action=semantic_action,
            selected_targets=selected,
        )
        targets = tuple(str(row["analysis_column"]) for row in selected)
        accounting, form, part = _form_context(
            flag=flag,
            predicate_value=predicate_value,
            inferred_form=inferred_form,
            parent_parts=parent_parts,
            action=action,
            semantic_class=semantic_class,
        )
        rule_id = stable_rule_id(
            year=year,
            flag=flag,
            code=code,
            predicate_column=str(scope["predicate_column"]),
            predicate_value=predicate_value,
            action=action,
            target_columns=targets,
        )
        rule = {
            "rule_id": rule_id,
            "year_start": year,
            "year_end": year,
            "flag": flag,
            "code": code,
            "action": action,
            "target_columns": "|".join(targets),
            "row_predicate": json.dumps(
                {str(scope["predicate_column"]): predicate_value},
                sort_keys=True,
                separators=(",", ":"),
            ),
            "accounting_standard": accounting,
            "form": form,
            "part": part,
            "review_status": (
                "conditional_pending_b05_component_and_policy_countersign"
            ),
            "source_reference": source_reference,
            "rationale": (
                f"{scope['semantic_decision_id']}; {action_reason}; "
                "exact annual source-table predicate and exact "
                "B05/Stage04/enriched "
                "target lineage; dimensioned lane excluded."
            ),
        }
        rules.append(rule)
        for binding in selected:
            target_reason = (
                "partial_exact_equity_ratio"
                if binding["source_file"] == "DRVF"
                and semantic_class in PARTIAL_SEMANTICS
                else (
                    "partial_exact_direct_form_part"
                    if semantic_class in PARTIAL_SEMANTICS
                    else "full_or_component_exact_payload"
                )
            )
            lineage.append(
                {
                    "contract_id": CONTRACT_ID,
                    "rule_id": rule_id,
                    "year": year,
                    "flag": flag,
                    "code": code,
                    "predicate_column": scope["predicate_column"],
                    "predicate_value": predicate_value,
                    "analysis_column": binding["analysis_column"],
                    "variable_id": binding["variable_id"],
                    "b05_candidate_decision_id": binding["candidate_decision_id"],
                    "component_decision_id": binding.get(
                        "component_decision_id", ""
                    ),
                    "component_metadata_exception_id": binding[
                        "component_metadata_exception_id"
                    ],
                    "metadata_alias_decision_id": binding[
                        "metadata_alias_decision_id"
                    ],
                    "finance_binding_id": binding.get("finance_binding_id", ""),
                    "finance_metadata_exception_id": binding[
                        "finance_metadata_exception_id"
                    ],
                    "component_binding_status": binding[
                        "component_binding_status"
                    ],
                    "source_file": binding["source_file"],
                    "source_varnumber": binding["source_varnumber"],
                    "source_varname": binding["source_varname"],
                    "access_table_name": binding["access_table_name"],
                    "source_column_name": binding["source_column_name"],
                    "source_form": binding["source_form"],
                    "source_part": binding["source_part"],
                    "source_part_observed_from_section": binding[
                        "source_part_observed_from_section"
                    ],
                    "source_section_number": binding["source_section_number"],
                    "source_section_title": binding["source_section_title"],
                    "metadata_access_table_name": binding[
                        "metadata_access_table_name"
                    ],
                    "target_reason": target_reason,
                    "binding_status": (
                        "exact_identity_pending_author_binding_and_b05_review"
                    ),
                }
            )
        if str(scope["semantic_action"]) == "null" and not selected:
            diagnostic_class = (
                "source_repaired_semantic_retain_exception"
                if semantic_action == "retain"
                else "semantic_null_zero_exact_target_noop"
            )
            available_bindings = [
                row
                for row in by_year.get(year, [])
                if (
                    (
                        flag == "PRCH_F"
                        and (
                            row["source_file"] in FINANCE_SOURCE_FILES
                            or row.get("component_flag") == flag
                        )
                    )
                    or (
                        flag != "PRCH_F"
                        and row.get("component_flag") == flag
                    )
                )
            ]
            available_bindings.sort(
                key=lambda row: (
                    str(row["access_table_name"]).casefold(),
                    str(row["source_varnumber"]),
                    str(row["source_varname"]).casefold(),
                )
            )
            zero_targets.append(
                {
                    "contract_id": CONTRACT_ID,
                    "rule_id": rule_id,
                    "year": year,
                    "flag": flag,
                    "code": code,
                    "predicate_column": scope["predicate_column"],
                    "predicate_value": predicate_value,
                    "observed_row_count": scope["observed_row_count"],
                    "semantic_action": scope["semantic_action"],
                    "operational_action": action,
                    "exact_target_count": 0,
                    "available_binding_count": len(available_bindings),
                    "diagnostic_class": diagnostic_class,
                    "reason": action_reason,
                    "available_source_files": "|".join(
                        sorted(
                            {
                                str(row["source_file"])
                                for row in available_bindings
                            },
                            key=str.casefold,
                        )
                    ),
                    "available_binding_decision_ids": "|".join(
                        str(
                            row.get("component_decision_id")
                            or row.get("finance_binding_id")
                            or ""
                        )
                        for row in available_bindings
                    ),
                    "available_exact_source_identities": "|".join(
                        (
                            f"{row['access_table_name']}:"
                            f"{row['source_varnumber']}:{row['source_varname']}"
                        )
                        for row in available_bindings
                    ),
                    "status": (
                        "conditional_semantic_retain_pending_author_countersign"
                        if diagnostic_class
                        == "source_repaired_semantic_retain_exception"
                        else (
                            "conditional_zero_target_noop_pending_author_"
                            "countersign"
                        )
                    ),
                }
            )
    rules.sort(
        key=lambda row: (
            int(row["year_start"]),
            str(row["flag"]),
            int(row["code"]),
            str(row["row_predicate"]),
        )
    )
    lineage.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["rule_id"]),
            str(row["analysis_column"]).casefold(),
        )
    )
    zero_targets.sort(
        key=lambda row: (
            int(row["year"]),
            str(row["flag"]),
            int(row["code"]),
            int(row["predicate_value"]),
        )
    )
    if len({str(row["rule_id"]) for row in rules}) != len(rules):
        raise CandidateEvidenceError("stable rule id collision")
    return rules, lineage, zero_targets


def _overlap_proof(
    rules: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    output: list[dict[str, object]] = []
    for rule in rules:
        predicate = json.loads(str(rule["row_predicate"]))
        overlaps = [
            other
            for other in rules
            if other is not rule
            and int(other["year_start"]) == int(rule["year_start"])
            and other["flag"] == rule["flag"]
            and int(other["code"]) == int(rule["code"])
            and json.loads(str(other["row_predicate"])) == predicate
        ]
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "rule_id": rule["rule_id"],
                "year": rule["year_start"],
                "flag": rule["flag"],
                "code": rule["code"],
                "row_predicate": rule["row_predicate"],
                "overlapping_rule_count": len(overlaps),
                "overlapping_rule_ids": "|".join(
                    sorted(str(row["rule_id"]) for row in overlaps)
                ),
                "overlap_status": "none" if not overlaps else "fatal_overlap",
            }
        )
    if any(row["overlap_status"] != "none" for row in output):
        raise CandidateEvidenceError("candidate rule predicates overlap")
    return output


def build_2010_finance_correction_proof(
    *,
    rules: Sequence[Mapping[str, object]],
    lineage: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    expected_included = {f"F1D{number:02d}" for number in range(1, 7)}
    expected_excluded = {f"F1E{number:02d}" for number in range(1, 12)}
    relevant = [
        rule
        for rule in rules
        if int(rule["year_start"]) == 2010
        and rule["flag"] == "PRCH_F"
        and rule["action"] == "null"
        and rule["part"] == "A|D"
        and json.loads(str(rule["row_predicate"])) == {"FORM_F": 4}
    ]
    if len(relevant) != 2:
        raise CandidateEvidenceError(
            f"expected two corrected 2010 GASB partial rules; found {len(relevant)}"
        )
    output: list[dict[str, object]] = []
    for rule in relevant:
        direct = [
            row
            for row in lineage
            if row["rule_id"] == rule["rule_id"]
            and row["access_table_name"] == "F0910_F1A"
        ]
        included_names = {str(row["source_varname"]) for row in direct}
        included_d = included_names & expected_included
        included_e = included_names & expected_excluded
        if included_d != expected_included or included_e:
            raise CandidateEvidenceError(
                "2010 Finance correction proof failed: "
                f"{rule['rule_id']}:included_D={sorted(included_d)}:"
                f"included_E={sorted(included_e)}"
            )
        exception_ids = sorted(
            {
                str(row["finance_metadata_exception_id"])
                for row in direct
                if row["source_varname"] in expected_included
            }
        )
        if len(exception_ids) != 6:
            raise CandidateEvidenceError(
                f"2010 Finance correction lacks six D exceptions: "
                f"{rule['rule_id']}"
            )
        output.append(
            {
                "contract_id": CONTRACT_ID,
                "year": 2010,
                "rule_id": rule["rule_id"],
                "flag": rule["flag"],
                "code": rule["code"],
                "row_predicate": rule["row_predicate"],
                "parent_reported_parts": rule["part"],
                "corrected_included_varnames": "|".join(
                    sorted(expected_included)
                ),
                "corrected_included_count": len(expected_included),
                "rejected_shifted_varnames": "|".join(
                    sorted(expected_excluded)
                ),
                "rejected_shifted_count": len(expected_excluded),
                "finance_exception_decision_ids": "|".join(exception_ids),
                "official_pdf_member": FINANCE_2010_F1_OFFICIAL_MEMBER,
                "official_pdf_sha256": FINANCE_2010_F1_OFFICIAL_MEMBER_SHA256,
                "official_part_pages": "9|10",
                "official_parent_child_comparison_page": "32",
                "proof_status": "exact_corrected_inclusion_and_exclusion",
            }
        )
    output.sort(key=lambda row: (int(row["code"]), str(row["rule_id"])))
    return output


def _generator_commit(repo: Path, generator_path: Path) -> str:
    relative = generator_path.relative_to(repo).as_posix()
    status = subprocess.run(
        ["git", "status", "--porcelain", "--", relative],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    if status:
        return "UNCOMMITTED"
    completed = subprocess.run(
        ["git", "log", "-1", "--format=%H", "--", relative],
        cwd=repo,
        check=True,
        capture_output=True,
        text=True,
    )
    commit = completed.stdout.strip()
    if not commit:
        return "UNCOMMITTED"
    committed = subprocess.run(
        ["git", "show", f"{commit}:{relative}"],
        cwd=repo,
        check=True,
        capture_output=True,
    ).stdout
    if committed != generator_path.read_bytes():
        return "UNCOMMITTED"
    return commit


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--legacy-root", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument(
        "--development-allow-uncommitted-generator",
        action="store_true",
        help="Allow explicitly labeled UNCOMMITTED development probes only.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo = args.repo_root.resolve()
    legacy = args.legacy_root.resolve()
    out = args.out_dir.resolve()
    validate_output_directory(repo=repo, out=out)
    generator_path = Path(__file__).resolve()
    test_path = repo / "tests/test_b07_prch_policy_candidate.py"
    generator_commit = _generator_commit(repo, generator_path)
    test_commit = _generator_commit(repo, test_path)
    if (
        generator_commit == "UNCOMMITTED"
        or test_commit == "UNCOMMITTED"
        or generator_commit != test_commit
    ) and not args.development_allow_uncommitted_generator:
        raise CandidateEvidenceError(
            "final candidate generation requires committed, byte-identical "
            "generator and focused-test sources from one commit"
        )
    generator_hash = sha256_file(generator_path)
    test_hash = sha256_file(test_path)
    out.mkdir(parents=True, exist_ok=True)

    b07_dir = repo / "Artifacts/review_v2/b07_official_semantics_2026-07-24"
    b05_dir = (
        repo
        / "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24"
    )
    stage_dir = repo / "Artifacts/review_v2/stage04_full_candidates_2026-07-24"
    paths = {
        "b07_decisions": b07_dir / "B07_SEMANTIC_DECISION_REGISTER.csv",
        "b07_observed": (
            repo
            / "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
            "B07_PRCH_OBSERVED_CODE_EVIDENCE.csv"
        ),
        "b07_matrix": b07_dir / "B07_FORM_PART_MATRIX.csv",
        "b07_exceptions": b07_dir / "B07_FORM_F_PREDICATE_SCOPE_PROOF.csv",
        "b07_manifest": b07_dir / "B07_ARTIFACT_MANIFEST.csv",
        "b07_source_manifest": b07_dir / "B07_OFFICIAL_SOURCE_MANIFEST.csv",
        "b05_mapping": b05_dir / "B05_IDENTITY_MAPPING.csv",
        "b05_decisions": b05_dir / "B05_B06_CONSERVATIVE_DECISION_REGISTER.csv",
        "analysis_schema": b05_dir / "analysis_schema_candidate.csv",
        "stage04": stage_dir / "source_columns_stage04_candidate.csv",
        "enriched": (
            repo
            / "Artifacts/review_v2/b03_b04_package_rebaseline_2026-07-24/"
            "source_column_enriched.csv"
        ),
    }
    for name, path in paths.items():
        if not path.is_file():
            raise CandidateEvidenceError(f"missing required {name}: {path}")

    canonical_pre = canonical_contract_snapshot(repo)
    validate_artifact_manifest(
        manifest_path=paths["b07_manifest"],
        artifact_root=b07_dir,
    )
    observed_prch_rows = read_csv(paths["b07_observed"])
    scopes, flag_inputs = build_observed_predicate_scopes(
        legacy_root=legacy,
        observed_rows=observed_prch_rows,
        semantic_rows=read_csv(paths["b07_decisions"]),
    )
    vartable_index, vartable_inputs = load_annual_vartable_index(legacy)
    bindings, b05_review_state = _load_exact_bindings(
        b05_rows=read_csv(paths["b05_mapping"]),
        stage_rows=read_csv(paths["stage04"]),
        enriched_rows=read_csv(paths["enriched"]),
        vartable_index=vartable_index,
        schema_rows=read_csv(paths["analysis_schema"]),
        decision_rows=read_csv(paths["b05_decisions"]),
    )
    input_hashes = {name: sha256_file(path) for name, path in paths.items()}
    input_rows: list[dict[str, object]] = [
        {
            "input_kind": "repository_evidence",
            "path": path.relative_to(repo).as_posix(),
            "byte_size": path.stat().st_size,
            "sha256": input_hashes[name],
        }
        for name, path in sorted(paths.items())
    ]
    input_rows.extend(
        {
            "input_kind": "canonical_guard",
            "path": relative,
            "byte_size": (repo / relative).stat().st_size,
            "sha256": digest,
        }
        for relative, digest in sorted(canonical_pre.items())
    )
    drvef2006_path = _casefold_csv(
        legacy / "Raw_Access_Databases/2006/tables_csv",
        "DRVEF2006",
    )
    input_rows.append(
        {
            "input_kind": "exception_source_table",
            "path": drvef2006_path.relative_to(legacy).as_posix(),
            "byte_size": drvef2006_path.stat().st_size,
            "sha256": sha256_file(drvef2006_path),
        }
    )
    input_rows.extend(
        (
            {
                "input_kind": "generator_source",
                "path": generator_path.relative_to(repo).as_posix(),
                "byte_size": generator_path.stat().st_size,
                "sha256": generator_hash,
            },
            {
                "input_kind": "focused_test_source",
                "path": test_path.relative_to(repo).as_posix(),
                "byte_size": test_path.stat().st_size,
                "sha256": test_hash,
            },
        )
    )
    input_rows.extend(flag_inputs)
    input_rows.extend(vartable_inputs)
    input_rows.sort(key=lambda row: (str(row["input_kind"]), str(row["path"])))
    if len(
        {
            (str(row["input_kind"]), str(row["path"]))
            for row in input_rows
        }
    ) != len(input_rows):
        raise CandidateEvidenceError("duplicate input-manifest identity")
    write_csv(
        out / "B07_PRCH_POLICY_INPUT_MANIFEST.csv",
        ("input_kind", "path", "byte_size", "sha256"),
        input_rows,
    )
    input_manifest_hash = sha256_file(
        out / "B07_PRCH_POLICY_INPUT_MANIFEST.csv"
    )

    component_register = build_component_binding_register(bindings)
    b04_alias_lineage = build_b04_alias_lineage(bindings)
    finance_bindings = build_finance_source_part_bindings(bindings)
    prch_rows_by_year = load_annual_prch_rows(
        legacy,
        observed_rows=observed_prch_rows,
    )
    flags_by_year = load_annual_flags_rows(legacy)
    finance_metadata_exceptions = build_finance_metadata_exception_register(
        bindings=bindings,
        official_source_rows=read_csv(paths["b07_source_manifest"]),
    )
    component_metadata_exceptions = (
        build_component_metadata_exception_register(
            bindings=bindings,
            rows_by_year=flags_by_year,
            legacy_root=legacy,
        )
    )
    semantic_conflicts = build_semantic_conflict_diagnostic(bindings)
    component_summary = build_component_binding_summary(component_register)
    finance_summary = build_finance_binding_summary(finance_bindings)
    unresolved_components = [
        row
        for row in component_register
        if row["review_status"] == "request_more_evidence"
    ]
    if unresolved_components:
        first = unresolved_components[0]
        raise CandidateEvidenceError(
            "component binding register contains unresolved evidence: "
            f"{len(unresolved_components)} rows; first={first['decision_id']}"
        )
    write_csv(
        out / "B07_COMPONENT_BINDING_REGISTER.csv",
        tuple(component_register[0]),
        component_register,
    )
    write_csv(
        out / "B07_B04_ALIAS_LINEAGE.csv",
        tuple(b04_alias_lineage[0]),
        b04_alias_lineage,
    )
    write_csv(
        out / "B07_FINANCE_SOURCE_PART_BINDINGS.csv",
        tuple(finance_bindings[0]),
        finance_bindings,
    )
    write_csv(
        out / "B07_FINANCE_METADATA_EXCEPTION_REGISTER.csv",
        tuple(finance_metadata_exceptions[0]),
        finance_metadata_exceptions,
    )
    write_csv(
        out / "B07_COMPONENT_METADATA_EXCEPTION_REGISTER.csv",
        tuple(component_metadata_exceptions[0]),
        component_metadata_exceptions,
    )
    write_csv(
        out / "B07_SEMANTIC_CONFLICT_DIAGNOSTIC.csv",
        tuple(semantic_conflicts[0]),
        semantic_conflicts,
    )
    write_csv(
        out / "B07_COMPONENT_BINDING_SUMMARY.csv",
        tuple(component_summary[0]),
        component_summary,
    )
    write_csv(
        out / "B07_FINANCE_BINDING_SUMMARY.csv",
        tuple(finance_summary[0]),
        finance_summary,
    )
    component_register_hash = sha256_file(
        out / "B07_COMPONENT_BINDING_REGISTER.csv"
    )
    b04_alias_lineage_hash = sha256_file(
        out / "B07_B04_ALIAS_LINEAGE.csv"
    )
    finance_bindings_hash = sha256_file(
        out / "B07_FINANCE_SOURCE_PART_BINDINGS.csv"
    )
    finance_exception_hash = sha256_file(
        out / "B07_FINANCE_METADATA_EXCEPTION_REGISTER.csv"
    )
    component_exception_hash = sha256_file(
        out / "B07_COMPONENT_METADATA_EXCEPTION_REGISTER.csv"
    )
    semantic_conflict_hash = sha256_file(
        out / "B07_SEMANTIC_CONFLICT_DIAGNOSTIC.csv"
    )
    base_source_reference = (
        f"B07_PRCH_POLICY_INPUT_MANIFEST.csv@{input_manifest_hash};"
        f"B07_COMPONENT_BINDING_REGISTER.csv@{component_register_hash};"
        f"B07_B04_ALIAS_LINEAGE.csv@{b04_alias_lineage_hash};"
        f"B07_FINANCE_SOURCE_PART_BINDINGS.csv@{finance_bindings_hash};"
        f"B07_FINANCE_METADATA_EXCEPTION_REGISTER.csv@"
        f"{finance_exception_hash};"
        f"B07_COMPONENT_METADATA_EXCEPTION_REGISTER.csv@"
        f"{component_exception_hash};"
        f"B07_SEMANTIC_CONFLICT_DIAGNOSTIC.csv@"
        f"{semantic_conflict_hash}"
    )
    rules, lineage, zero_targets = _build_rules(
        scopes=scopes,
        bindings=bindings,
        form_matrix=read_csv(paths["b07_matrix"]),
        exception_scopes=read_csv(paths["b07_exceptions"]),
        source_reference=base_source_reference,
    )
    coverage = build_coverage_proof(scopes, rules)
    overlaps = _overlap_proof(rules)
    finance_correction_proof = build_2010_finance_correction_proof(
        rules=rules,
        lineage=lineage,
    )
    collisions, pair_rows = build_cross_flag_collision_proof(
        rows_by_year=prch_rows_by_year,
        rules=rules,
        required_pairs=((2004, "PRCH_SA", "PRCH_SFA"),),
    )

    write_csv(
        out / "B07_PRCH_POLICY_TARGET_LINEAGE.csv",
        tuple(lineage[0]) if lineage else (
            "contract_id",
            "rule_id",
            "year",
            "flag",
            "code",
            "predicate_column",
            "predicate_value",
            "analysis_column",
            "variable_id",
            "b05_candidate_decision_id",
            "component_decision_id",
            "component_metadata_exception_id",
            "metadata_alias_decision_id",
            "finance_binding_id",
            "finance_metadata_exception_id",
            "component_binding_status",
            "source_file",
            "source_varnumber",
            "source_varname",
            "access_table_name",
            "source_column_name",
            "source_form",
            "source_part",
            "source_part_observed_from_section",
            "source_section_number",
            "source_section_title",
            "metadata_access_table_name",
            "target_reason",
            "binding_status",
        ),
        lineage,
    )
    write_csv(
        out / "B07_CROSS_FLAG_TARGET_CELL_COLLISIONS.csv",
        tuple(collisions[0]) if collisions else (
            "contract_id",
            "year",
            "unitid",
            "analysis_column",
            "rule_ids",
            "flags",
            "codes",
            "actions",
            "semantic_contexts",
            "collision_class",
            "approval_status",
        ),
        collisions,
    )
    write_csv(
        out / "B07_CROSS_FLAG_PAIR_SUMMARY.csv",
        tuple(pair_rows[0]),
        pair_rows,
    )
    write_csv(
        out / "B07_2010_FINANCE_CORRECTION_PROOF.csv",
        tuple(finance_correction_proof[0]),
        finance_correction_proof,
    )
    lineage_hash = sha256_file(out / "B07_PRCH_POLICY_TARGET_LINEAGE.csv")
    collisions_hash = sha256_file(
        out / "B07_CROSS_FLAG_TARGET_CELL_COLLISIONS.csv"
    )
    pair_summary_hash = sha256_file(out / "B07_CROSS_FLAG_PAIR_SUMMARY.csv")
    finance_correction_proof_hash = sha256_file(
        out / "B07_2010_FINANCE_CORRECTION_PROOF.csv"
    )
    final_source_reference = (
        f"{base_source_reference};"
        f"B07_PRCH_POLICY_TARGET_LINEAGE.csv@{lineage_hash};"
        f"B07_CROSS_FLAG_TARGET_CELL_COLLISIONS.csv@{collisions_hash};"
        f"B07_CROSS_FLAG_PAIR_SUMMARY.csv@{pair_summary_hash};"
        f"B07_2010_FINANCE_CORRECTION_PROOF.csv@"
        f"{finance_correction_proof_hash}"
    )
    for rule in rules:
        rule["source_reference"] = final_source_reference

    write_csv(out / "B07_PRCH_POLICY_CANDIDATE.csv", POLICY_COLUMNS, rules)
    write_csv(
        out / "B07_PRCH_POLICY_PREDICATE_COVERAGE.csv",
        tuple(coverage[0]),
        coverage,
    )
    write_csv(
        out / "B07_PRCH_POLICY_OVERLAP_PROOF.csv",
        tuple(overlaps[0]),
        overlaps,
    )
    write_csv(
        out / "B07_PRCH_POLICY_ZERO_TARGET_DIAGNOSTICS.csv",
        tuple(zero_targets[0]) if zero_targets else (
            "contract_id",
            "rule_id",
            "year",
            "flag",
            "code",
            "predicate_column",
            "predicate_value",
            "observed_row_count",
            "semantic_action",
            "operational_action",
            "exact_target_count",
            "available_binding_count",
            "diagnostic_class",
            "reason",
            "available_source_files",
            "available_binding_decision_ids",
            "available_exact_source_identities",
            "status",
        ),
        zero_targets,
    )
    canonical_post = canonical_contract_snapshot(repo)
    if canonical_post != canonical_pre:
        raise CandidateEvidenceError("candidate generator altered canonical contracts")
    canonical_proof = [
        {
            "path": path,
            "pre_sha256": canonical_pre[path],
            "post_sha256": canonical_post[path],
            "unchanged": "true",
        }
        for path in canonical_pre
    ]
    write_csv(
        out / "B07_PRCH_POLICY_CANONICAL_HASH_PROOF.csv",
        ("path", "pre_sha256", "post_sha256", "unchanged"),
        canonical_proof,
    )
    candidate_hash = sha256_file(out / "B07_PRCH_POLICY_CANDIDATE.csv")
    review_target_members = {
        name: sha256_file(out / name)
        for name in (
            "B07_2010_FINANCE_CORRECTION_PROOF.csv",
            "B07_B04_ALIAS_LINEAGE.csv",
            "B07_COMPONENT_BINDING_REGISTER.csv",
            "B07_COMPONENT_BINDING_SUMMARY.csv",
            "B07_COMPONENT_METADATA_EXCEPTION_REGISTER.csv",
            "B07_FINANCE_BINDING_SUMMARY.csv",
            "B07_FINANCE_METADATA_EXCEPTION_REGISTER.csv",
            "B07_FINANCE_SOURCE_PART_BINDINGS.csv",
            "B07_SEMANTIC_CONFLICT_DIAGNOSTIC.csv",
            "B07_PRCH_POLICY_INPUT_MANIFEST.csv",
            "B07_PRCH_POLICY_CANDIDATE.csv",
            "B07_PRCH_POLICY_CANONICAL_HASH_PROOF.csv",
            "B07_PRCH_POLICY_TARGET_LINEAGE.csv",
            "B07_PRCH_POLICY_PREDICATE_COVERAGE.csv",
            "B07_PRCH_POLICY_OVERLAP_PROOF.csv",
            "B07_PRCH_POLICY_ZERO_TARGET_DIAGNOSTICS.csv",
            "B07_CROSS_FLAG_TARGET_CELL_COLLISIONS.csv",
            "B07_CROSS_FLAG_PAIR_SUMMARY.csv",
        )
    }
    review_target_package_hash = hashlib.sha256(
        json.dumps(
            review_target_members,
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    (out / "B07_PRCH_POLICY_REVIEW_TARGET_DIGEST.json").write_text(
        json.dumps(
            {
                "contract_id": CONTRACT_ID,
                "members": review_target_members,
                "review_target_package_sha256": review_target_package_hash,
                "status": "conditional_pending_author_countersign",
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
        newline="\n",
    )
    write_csv(
        out / "B07_PRCH_POLICY_AUTHOR_COUNTERSIGN.csv",
        (
            "contract_id",
            "candidate_path",
            "candidate_sha256",
            "candidate_rule_count",
            "component_binding_register_path",
            "component_binding_register_sha256",
            "component_binding_row_count",
            "component_metadata_exception_register_sha256",
            "component_metadata_exception_row_count",
            "b04_alias_lineage_sha256",
            "b04_alias_lineage_row_count",
            "finance_source_part_bindings_path",
            "finance_source_part_bindings_sha256",
            "finance_source_part_binding_row_count",
            "finance_metadata_exception_register_sha256",
            "finance_metadata_exception_row_count",
            "finance_2010_correction_proof_sha256",
            "finance_2010_correction_rule_count",
            "semantic_conflict_diagnostic_sha256",
            "semantic_conflict_diagnostic_row_count",
            "target_lineage_sha256",
            "cross_flag_collision_sha256",
            "cross_flag_collision_row_count",
            "review_target_package_sha256",
            "input_manifest_sha256",
            "b05_input_review_state",
            "b07_input_review_state",
            "required_decision",
            "author_decision",
            "author_name",
            "author_date",
        ),
        [
            {
                "contract_id": CONTRACT_ID,
                "candidate_path": "B07_PRCH_POLICY_CANDIDATE.csv",
                "candidate_sha256": candidate_hash,
                "candidate_rule_count": len(rules),
                "component_binding_register_path": (
                    "B07_COMPONENT_BINDING_REGISTER.csv"
                ),
                "component_binding_register_sha256": component_register_hash,
                "component_binding_row_count": len(component_register),
                "component_metadata_exception_register_sha256": (
                    component_exception_hash
                ),
                "component_metadata_exception_row_count": len(
                    component_metadata_exceptions
                ),
                "b04_alias_lineage_sha256": b04_alias_lineage_hash,
                "b04_alias_lineage_row_count": len(b04_alias_lineage),
                "finance_source_part_bindings_path": (
                    "B07_FINANCE_SOURCE_PART_BINDINGS.csv"
                ),
                "finance_source_part_bindings_sha256": finance_bindings_hash,
                "finance_source_part_binding_row_count": len(finance_bindings),
                "finance_metadata_exception_register_sha256": (
                    finance_exception_hash
                ),
                "finance_metadata_exception_row_count": len(
                    finance_metadata_exceptions
                ),
                "finance_2010_correction_proof_sha256": (
                    finance_correction_proof_hash
                ),
                "finance_2010_correction_rule_count": len(
                    finance_correction_proof
                ),
                "semantic_conflict_diagnostic_sha256": semantic_conflict_hash,
                "semantic_conflict_diagnostic_row_count": len(
                    semantic_conflicts
                ),
                "target_lineage_sha256": lineage_hash,
                "cross_flag_collision_sha256": collisions_hash,
                "cross_flag_collision_row_count": len(collisions),
                "review_target_package_sha256": review_target_package_hash,
                "input_manifest_sha256": input_manifest_hash,
                "b05_input_review_state": b05_review_state,
                "b07_input_review_state": (
                    "unsigned_supported_author_countersign_pending"
                ),
                "required_decision": (
                    "Countersign both the exact component-binding-register "
                    "SHA-256 and exact conditional review-target-package "
                    f"SHA-256. The package digest covers {len(rules)} policy "
                    f"rules, {len(component_register)} component decisions, "
                    f"{len(finance_bindings)} Finance bindings, "
                    f"{len(finance_metadata_exceptions)} Finance metadata "
                    f"exceptions, {len(component_metadata_exceptions)} "
                    f"transitional component exceptions, "
                    f"{len(b04_alias_lineage)} exact B04 aliases, "
                    f"{len(semantic_conflicts)} semantic-conflict diagnostics, "
                    "target lineage, zero-target classes, row-level collision "
                    "proofs, canonical hash proof, and the exact input "
                    "manifest. Review unsigned B05/B07 evidence before signing."
                ),
                "author_decision": "",
                "author_name": "",
                "author_date": "",
            }
        ],
    )
    summary = {
        "status": "B07_PRCH_POLICY_CONDITIONAL_REVIEW_CANDIDATE_GENERATED",
        "b05_input_review_state": b05_review_state,
        "b07_input_review_state": (
            "unsigned_supported_author_countersign_pending"
        ),
        "candidate_rule_count": len(rules),
        "candidate_null_rule_count": sum(row["action"] == "null" for row in rules),
        "candidate_retain_rule_count": sum(
            row["action"] == "retain" for row in rules
        ),
        "target_lineage_row_count": len(lineage),
        "predicate_scope_count": len(scopes),
        "predicate_coverage_failures": 0,
        "predicate_overlap_failures": 0,
        "zero_target_diagnostic_row_count": len(zero_targets),
        "semantic_null_zero_exact_target_noop_count": sum(
            row["diagnostic_class"]
            == "semantic_null_zero_exact_target_noop"
            for row in zero_targets
        ),
        "source_repaired_semantic_retain_exception_count": sum(
            row["diagnostic_class"]
            == "source_repaired_semantic_retain_exception"
            for row in zero_targets
        ),
        "exact_b05_year_identity_bindings": len(bindings),
        "pending_component_binding_rows": len(component_register),
        "proposed_nonfinance_component_binding_rows": sum(
            row["proposed_action"] == "bind_component_flag"
            for row in component_register
        ),
        "proposed_noncomponent_exclusion_rows": sum(
            row["proposed_action"] == "intentionally_exclude_from_prch"
            for row in component_register
        ),
        "pending_finance_source_part_binding_rows": len(finance_bindings),
        "pending_finance_metadata_exception_rows": len(
            finance_metadata_exceptions
        ),
        "pending_component_metadata_exception_rows": len(
            component_metadata_exceptions
        ),
        "b04_alias_lineage_row_count": len(b04_alias_lineage),
        "semantic_conflict_diagnostic_row_count": len(semantic_conflicts),
        "unresolved_semantic_conflict_count": 0,
        "row_level_cross_flag_collision_count": len(collisions),
        "pending_idempotent_collision_count": sum(
            row["approval_status"] == "pending_author_approval"
            for row in collisions
        ),
        "fatal_cross_flag_collision_count": 0,
        "dimensioned_lane_target_count": 0,
        "candidate_sha256": candidate_hash,
        "component_binding_register_sha256": component_register_hash,
        "component_metadata_exception_register_sha256": (
            component_exception_hash
        ),
        "b04_alias_lineage_sha256": b04_alias_lineage_hash,
        "finance_source_part_bindings_sha256": finance_bindings_hash,
        "finance_metadata_exception_register_sha256": finance_exception_hash,
        "finance_2010_correction_proof_sha256": (
            finance_correction_proof_hash
        ),
        "finance_2010_correction_rule_count": len(finance_correction_proof),
        "semantic_conflict_diagnostic_sha256": semantic_conflict_hash,
        "target_lineage_sha256": lineage_hash,
        "cross_flag_collision_sha256": collisions_hash,
        "cross_flag_pair_summary_sha256": pair_summary_hash,
        "review_target_package_sha256": review_target_package_hash,
        "input_manifest_sha256": input_manifest_hash,
        "generator_commit": generator_commit,
        "generator_sha256": generator_hash,
        "focused_test_path": test_path.relative_to(repo).as_posix(),
        "focused_test_commit": test_commit,
        "focused_test_sha256": test_hash,
        "canonical_contract_changed": False,
        "release_status": "RELEASE_STILL_BLOCKED",
    }
    (out / "B07_PRCH_POLICY_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    result = f"""# B07 expanded PRCH policy candidate

Status: **B07_PRCH_POLICY_CONDITIONAL_REVIEW_CANDIDATE_GENERATED**.

- {len(rules)} annual, code, and exact-predicate candidate rules cover all
  {len(scopes)} observed scopes exactly once.
- {len(lineage)} null-target lineage rows bind through exact B05, Stage04,
  enriched Access metadata, and the scalar analysis candidate.
- {sum(row["diagnostic_class"] == "semantic_null_zero_exact_target_noop" for row in zero_targets)} semantic-null scopes have zero exact scalar B05 targets and are explicit
  conditional retain/no-op candidates.
- {sum(row["diagnostic_class"] == "source_repaired_semantic_retain_exception" for row in zero_targets)} separate `FORM_F=-2` scopes are source-repaired semantic-retain exceptions;
  they are not missing-target cases.
- The B05 input is **{b05_review_state}**. This candidate is not approved.
- {len(component_register)} annual non-Finance identities have proposed
  decisions pending collective author countersign:
  {sum(row["proposed_action"] == "bind_component_flag" for row in component_register)} component bindings and
  {sum(row["proposed_action"] == "intentionally_exclude_from_prch" for row in component_register)} explicit noncomponent exclusions.
- {len(finance_bindings)} annual Finance identities have form/part bindings
  pending collective author countersign.
- {len(finance_metadata_exceptions)} exact 2010 `F0910_F1A` identities use
  official-page-bound corrections for shifted VARTABLE SectionTitle metadata.
- {len(component_metadata_exceptions)} exact 2006 `DRVEF2006` identities
  preserve the only operational `PRCH_EF` flag despite 12-month titles; the
  evidence register proves `PRCH_E12` is absent and scoped values are nonempty.
- {len(b04_alias_lineage)} exact 2023 SFA P1/P2 cross-table metadata bindings
  are explicitly tied to countersigned `B04-ALIAS-001`.
- {len(collisions)} exact UNITID-year target-cell collisions are enumerated;
  only idempotent null/null collisions may remain pending approval.
- The dimensioned lane remains raw and PRCH-unmodified.
- Partial Finance derived targeting is limited to exact `F1EQUITR`,
  `F2EQUITR`, and `F3EQUITR` identities.
- Candidate SHA-256: `{candidate_hash}`.
- Component binding register SHA-256: `{component_register_hash}`.
- Conditional review-target package SHA-256:
  `{review_target_package_hash}`.

The package digest covers all {len(rules)} policy rules,
{len(component_register)} component decisions, {len(finance_bindings)} Finance
bindings, {len(finance_metadata_exceptions)} Finance exceptions,
{len(component_metadata_exceptions)} transitional component exceptions,
{len(b04_alias_lineage)} B04 aliases, {len(semantic_conflicts)} semantic
diagnostics, target lineage, zero-target classes, exact row-level collision
proofs, canonical hash proof, and the input manifest. The author must
countersign both exact hashes named in the countersign register before any
canonical contract edit.
Always return: **B07_CONTRACT_UNCHANGED**, **FULL_BUILD_NOT_RUN**,
**RELEASE_STILL_BLOCKED**.
"""
    (out / "B07_PRCH_POLICY_RESULT.md").write_text(
        result, encoding="utf-8", newline="\n"
    )

    artifact_rows = []
    for path in sorted(out.iterdir(), key=lambda item: item.name.casefold()):
        if not path.is_file() or path.name == "B07_PRCH_POLICY_ARTIFACT_MANIFEST.csv":
            continue
        artifact_rows.append(
            {
                "path": path.name,
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
                "generator_commit": generator_commit,
                "generator_sha256": generator_hash,
                "focused_test_path": test_path.relative_to(repo).as_posix(),
                "focused_test_commit": test_commit,
                "focused_test_sha256": test_hash,
                "input_manifest_sha256": input_manifest_hash,
            }
        )
    write_csv(
        out / "B07_PRCH_POLICY_ARTIFACT_MANIFEST.csv",
        (
            "path",
            "byte_size",
            "sha256",
            "generator_commit",
            "generator_sha256",
            "focused_test_path",
            "focused_test_commit",
            "focused_test_sha256",
            "input_manifest_sha256",
        ),
        artifact_rows,
    )
    if canonical_contract_snapshot(repo) != canonical_pre:
        raise CandidateEvidenceError("canonical contracts changed during finalization")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
