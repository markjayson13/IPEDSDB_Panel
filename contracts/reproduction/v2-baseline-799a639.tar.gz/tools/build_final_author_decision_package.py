#!/usr/bin/env python3
"""Build an immutable, author-ready B03-B09 canonical application package.

This tool is deliberately separated from canonical application.  It reads
review-only candidates, produces exact proposed canonical bytes in an external
review directory, and binds them through:

* a seven-row canonical application scope;
* one immutable, pending author-decision row;
* a transitive review-target digest;
* a complete pre-application canonical file-set/hash proof; and
* a deterministic ZIP bundle.

It never writes under ``contracts/`` and it never treats the package as
authorization.  The exact countersign described in the generated receipt is a
separate human action.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import tempfile
from typing import Iterable, Mapping, Sequence
import zipfile


CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
DEFAULT_AUTHOR = "Mark Jayson Martinez Farol"
DEFAULT_REVIEW_DATE = "2026-07-24"
AUTHORIZATION_ID = "AUTH-B03-B09-20260724"

TARGETS = (
    ("B03", "contracts/table_grain.csv", "table_grain.csv"),
    ("B04", "contracts/source_columns.csv", "source_columns.csv"),
    ("B05", "contracts/analysis_schema.csv", "analysis_schema.csv"),
    ("B06", "contracts/discrete_families.csv", "discrete_families.csv"),
    ("B07", "contracts/prch_policy.csv", "prch_policy.csv"),
    ("B08", "contracts/external_benchmarks.csv", "external_benchmarks.csv"),
    (
        "B09",
        "contracts/metadata_backfill_approvals.csv",
        "metadata_backfill_approvals.csv",
    ),
)

SCOPE_FIELDS = (
    "scope_id",
    "contract_id",
    "block_id",
    "canonical_path",
    "canonical_pre_sha256",
    "final_candidate_path",
    "final_candidate_sha256",
    "expected_post_sha256",
    "row_count",
    "application_mode",
    "child_decision_scope",
    "child_decision_register_path",
    "child_decision_register_sha256",
    "evidence_manifest_path",
    "evidence_manifest_sha256",
    "input_manifest_path",
    "input_manifest_sha256",
    "readiness_status",
)

AUTHOR_REGISTER_FIELDS = (
    "authorization_id",
    "contract_id",
    "scope_manifest_path",
    "scope_manifest_sha256",
    "scope_row_count",
    "transitive_review_target_digest_path",
    "transitive_review_target_digest_sha256",
    "transitive_review_target_sha256",
    "requested_action",
    "allowed_decisions",
    "decision_status",
    "author_name",
    "author_date",
    "release_boundary",
)

TABLE_FIELDS = (
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "grain_class",
    "unit_key_columns",
    "dimension_columns",
    "measure_selection_rule",
    "expected_rows_per_unit",
    "aggregation_policy",
    "source_evidence",
    "review_note",
    "reviewed",
)

SOURCE_FIELDS = (
    "contract_id",
    "decision_id",
    "year_start",
    "year_end",
    "source_file",
    "access_table_pattern",
    "column_name",
    "role",
    "canonical_dimension",
    "exclusion_reason",
    "source_evidence",
    "review_note",
    "reviewed",
)

ANALYSIS_FIELDS = (
    "contract_id",
    "analysis_column",
    "logical_type",
    "source_variables",
    "transformation",
    "inclusion_reason",
    "first_year",
    "last_year",
    "nullable",
    "status",
)

DISCRETE_FIELDS = (
    "contract_id",
    "source_file",
    "family_id",
    "component_varname",
    "component_code",
    "semantic_type",
    "active_tokens",
    "inactive_tokens",
    "missing_tokens",
    "output_column",
    "output_type",
    "multi_active_policy",
    "drop_components",
    "source_evidence",
    "review_note",
)

PRCH_FIELDS = (
    "rule_id",
    "year_start",
    "year_end",
    "flag",
    "code",
    "action",
    "target_columns",
    "row_predicate",
    "accounting_standard",
    "form",
    "part",
    "review_status",
    "source_reference",
    "rationale",
)

BENCHMARK_FIELDS = (
    "benchmark_id",
    "contract_id",
    "artifact",
    "year",
    "metric",
    "variable",
    "filters",
    "component_family",
    "expected_value",
    "absolute_tolerance",
    "relative_tolerance",
    "tolerance_rationale",
    "official_source",
    "source_date_or_version",
    "source_evidence_path",
    "source_evidence_sha256",
    "review_status",
    "reviewer",
    "review_date",
    "definition",
    "notes",
)

BACKFILL_FIELDS = (
    "approval_id",
    "contract_id",
    "target_year",
    "source_file",
    "access_table_name",
    "donor_year",
    "variable_id",
    "target_varname",
    "expected_data_type",
    "expected_title",
    "fields_backfilled",
    "compatibility_status",
    "compatibility_evidence",
    "approval_status",
    "reviewer",
    "review_date",
    "justification",
)

B07_REVIEW_TARGET_FILES = (
    "B07_2010_FINANCE_CORRECTION_PROOF.csv",
    "B07_B04_ALIAS_LINEAGE.csv",
    "B07_COMPONENT_BINDING_REGISTER.csv",
    "B07_COMPONENT_BINDING_SUMMARY.csv",
    "B07_COMPONENT_METADATA_EXCEPTION_REGISTER.csv",
    "B07_CROSS_FLAG_PAIR_SUMMARY.csv",
    "B07_CROSS_FLAG_TARGET_CELL_COLLISIONS.csv",
    "B07_FINANCE_BINDING_SUMMARY.csv",
    "B07_FINANCE_METADATA_EXCEPTION_REGISTER.csv",
    "B07_FINANCE_SOURCE_PART_BINDINGS.csv",
    "B07_PRCH_POLICY_CANDIDATE.csv",
    "B07_PRCH_POLICY_CANONICAL_HASH_PROOF.csv",
    "B07_PRCH_POLICY_INPUT_MANIFEST.csv",
    "B07_PRCH_POLICY_OVERLAP_PROOF.csv",
    "B07_PRCH_POLICY_PREDICATE_COVERAGE.csv",
    "B07_PRCH_POLICY_TARGET_LINEAGE.csv",
    "B07_PRCH_POLICY_ZERO_TARGET_DIAGNOSTICS.csv",
    "B07_SEMANTIC_CONFLICT_DIAGNOSTIC.csv",
)

B07_REQUIRED_FILES = (
    *B07_REVIEW_TARGET_FILES,
    "B07_PRCH_POLICY_AUTHOR_COUNTERSIGN.csv",
    "B07_PRCH_POLICY_REVIEW_TARGET_DIGEST.json",
    "B07_PRCH_POLICY_ARTIFACT_MANIFEST.csv",
    "B07_PRCH_POLICY_SUMMARY.json",
)

B07_EXPECTED_FINANCE_METADATA_EXCEPTIONS = 20
B07_EXPECTED_B04_ALIAS_ROWS = 343


class FinalDecisionPackageError(RuntimeError):
    """Raised when an exact final authorization package cannot be proven."""


def code_provenance(
    repo_root: Path,
    *,
    test_mode: bool,
) -> dict[str, str]:
    """Bind production output to the exact clean HEAD copies of tool and test."""
    generator = Path(__file__).resolve()
    focused_test = (
        generator.parents[1] / "tests/test_final_author_decision_package.py"
    ).resolve()
    hashes = {
        "generator_sha256": sha256_file(generator),
        "focused_test_sha256": sha256_file(focused_test),
    }
    if test_mode:
        return {
            **hashes,
            "generator_commit": "TEST_MODE_UNCOMMITTED",
        }
    repo = repo_root.resolve()
    paths = (generator, focused_test)
    relatives: list[str] = []
    for path in paths:
        try:
            relative = path.relative_to(repo).as_posix()
        except ValueError as exc:
            raise FinalDecisionPackageError(
                f"production code provenance path is outside repo: {path}"
            ) from exc
        relatives.append(relative)
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", "--", relative],
            cwd=repo,
            capture_output=True,
            text=True,
            check=False,
        )
        if tracked.returncode != 0:
            raise FinalDecisionPackageError(
                f"production builder/test is untracked: {relative}"
            )
        status = subprocess.run(
            [
                "git",
                "status",
                "--porcelain",
                "--untracked-files=all",
                "--",
                relative,
            ],
            cwd=repo,
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        if status:
            raise FinalDecisionPackageError(
                f"production builder/test has dirty or uncommitted bytes: "
                f"{relative}"
            )
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        capture_output=True,
        text=True,
        check=True,
    ).stdout.strip()
    for path, relative in zip(paths, relatives):
        committed = subprocess.run(
            ["git", "show", f"{head}:{relative}"],
            cwd=repo,
            capture_output=True,
            check=True,
        ).stdout
        if hashlib.sha256(committed).hexdigest() != sha256_file(path):
            raise FinalDecisionPackageError(
                "production generator_commit does not identify exact bytes: "
                f"{relative}"
            )
    return {
        **hashes,
        "generator_commit": head,
    }


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_sha256(value: object) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def read_csv(
    path: Path,
    *,
    required_fields: Sequence[str] | None = None,
    exact_fields: Sequence[str] | None = None,
    label: str | None = None,
) -> list[dict[str, str]]:
    label = label or path.name
    if not path.is_file():
        raise FinalDecisionPackageError(f"{label} missing: {path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = list(reader.fieldnames or [])
        if len(fields) != len(set(fields)):
            raise FinalDecisionPackageError(
                f"{label} contains duplicate columns"
            )
        if exact_fields is not None and fields != list(exact_fields):
            raise FinalDecisionPackageError(
                f"{label} columns differ from canonical schema: "
                f"expected={list(exact_fields)} actual={fields}"
            )
        missing = [
            field for field in (required_fields or ()) if field not in fields
        ]
        if missing:
            raise FinalDecisionPackageError(
                f"{label} missing columns: {', '.join(missing)}"
            )
        return [
            {
                str(key): str(value or "").strip()
                for key, value in raw.items()
                if key is not None
            }
            for raw in reader
            if any(str(value or "").strip() for value in raw.values())
        ]


def write_csv(
    path: Path,
    fields: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fields),
            lineterminator="\n",
            extrasaction="ignore",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def _safe_relative_path(value: str, *, label: str) -> PurePosixPath:
    raw = str(value).strip().replace("\\", "/")
    path = PurePosixPath(raw)
    if (
        not raw
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise FinalDecisionPackageError(
            f"{label} is not a safe repo-relative path: {value!r}"
        )
    return path


def _path_within(base: Path, relative: str, *, label: str) -> Path:
    rel = _safe_relative_path(relative, label=label)
    resolved_base = base.resolve()
    resolved = (resolved_base / Path(*rel.parts)).resolve()
    if resolved_base != resolved and resolved_base not in resolved.parents:
        raise FinalDecisionPackageError(
            f"{label} escapes its declared root: {relative!r}"
        )
    return resolved


def _repo_relative(repo: Path, path: Path, *, label: str) -> str:
    try:
        return path.resolve().relative_to(repo.resolve()).as_posix()
    except ValueError as exc:
        raise FinalDecisionPackageError(
            f"{label} must be inside the repository: {path}"
        ) from exc


def canonical_snapshot(repo_root: Path) -> dict[str, str]:
    repo = repo_root.resolve()
    contracts = repo / "contracts"
    if not contracts.is_dir():
        raise FinalDecisionPackageError(
            f"canonical contracts directory missing: {contracts}"
        )
    return {
        path.relative_to(repo).as_posix(): sha256_file(path)
        for path in sorted(
            (candidate for candidate in contracts.rglob("*") if candidate.is_file()),
            key=lambda candidate: candidate.relative_to(repo).as_posix(),
        )
    }


def assert_canonical_snapshot(
    repo_root: Path,
    expected: Mapping[str, str],
) -> None:
    observed = canonical_snapshot(repo_root)
    if dict(observed) != dict(expected):
        missing = sorted(set(expected) - set(observed))
        added = sorted(set(observed) - set(expected))
        changed = sorted(
            path
            for path in set(expected) & set(observed)
            if expected[path] != observed[path]
        )
        raise FinalDecisionPackageError(
            "canonical contract set or hash changed: "
            f"missing={missing} added={added} changed={changed}"
        )


def validate_output_directory(repo: Path, output: Path) -> None:
    contracts = (repo.resolve() / "contracts").resolve()
    resolved = output.resolve()
    if resolved == contracts or contracts in resolved.parents:
        raise FinalDecisionPackageError(
            "final decision package output must remain outside contracts/"
        )
    if output.exists() and any(output.iterdir()):
        raise FinalDecisionPackageError(
            f"output directory already exists and is nonempty: {output}"
        )


def validate_artifact_manifest(
    base: Path,
    manifest_name: str,
    *,
    required_members: Sequence[str],
) -> dict[str, str]:
    manifest = base / manifest_name
    rows = read_csv(
        manifest,
        required_fields=("byte_size", "sha256"),
        label=manifest_name,
    )
    members: dict[str, str] = {}
    for row in rows:
        relative = row.get("path") or row.get("relative_path") or ""
        if not relative:
            raise FinalDecisionPackageError(
                f"{manifest_name} row lacks path/relative_path"
            )
        if relative in members:
            raise FinalDecisionPackageError(
                f"{manifest_name} repeats member {relative}"
            )
        path = _path_within(
            base,
            relative,
            label=f"{manifest_name} member",
        )
        if not path.is_file():
            raise FinalDecisionPackageError(
                f"{manifest_name} member missing: {relative}"
            )
        observed_size = path.stat().st_size
        observed_hash = sha256_file(path)
        if (
            str(observed_size) != row["byte_size"]
            or observed_hash != row["sha256"]
        ):
            raise FinalDecisionPackageError(
                f"{manifest_name} member integrity mismatch: {relative}"
            )
        members[relative] = observed_hash
    absent = sorted(set(required_members) - set(members))
    if absent:
        raise FinalDecisionPackageError(
            f"{manifest_name} does not bind required members: {absent}"
        )
    return members


def validate_contract_id(
    rows: Sequence[Mapping[str, str]],
    *,
    label: str,
) -> None:
    if not rows:
        raise FinalDecisionPackageError(f"{label} is empty")
    wrong = sorted(
        {
            row.get("contract_id", "")
            for row in rows
            if row.get("contract_id", "") != CONTRACT_ID
        }
    )
    if wrong:
        raise FinalDecisionPackageError(
            f"{label} contains wrong contract_id values: {wrong}"
        )


def _truth(value: object) -> bool:
    return str(value or "").strip().lower() in {
        "1",
        "true",
        "yes",
        "approved",
    }


def _author_attribution(author: str, review_date: str) -> str:
    return (
        f"Author-reviewed by {author} on {review_date} under hash-bound "
        f"authorization {AUTHORIZATION_ID}; exact-byte application only."
    )


def finalize_review_text(
    value: object,
    *,
    author: str,
    review_date: str,
) -> str:
    text = " ".join(str(value or "").split())
    sentences = re.split(r"(?<=[.!?])\s+", text) if text else []
    retained = []
    for sentence in sentences:
        lower = sentence.casefold()
        if (
            lower.startswith("review-only compact projection")
            or lower.startswith("proposed only:")
        ):
            continue
        retained.append(sentence)
    text = " ".join(retained)
    substitutions = (
        (
            r"\bpending author semantic review\b",
            "author-reviewed exact semantic decision",
        ),
        (r"\bpending author review\b", "author-reviewed exact decision"),
        (
            r"\bpending collective author countersign\b",
            "covered by the hash-bound author decision",
        ),
        (
            r"\brequires (?:the )?exact author countersign\b",
            "is governed by the exact hash-bound author decision",
        ),
        (r"\bconservative proposal\b", "conservative approved decision"),
    )
    for pattern, replacement in substitutions:
        text = re.sub(pattern, replacement, text, flags=re.IGNORECASE)
    attribution = _author_attribution(author, review_date)
    if attribution not in text:
        text = f"{text.rstrip()} {attribution}".strip()
    return text


def finalize_benchmark_tolerance_rationale(row: Mapping[str, object]) -> str:
    """Describe the selected B08 tolerance without retaining proposal language."""
    absolute = str(row.get("absolute_tolerance", "")).strip()
    relative = str(row.get("relative_tolerance", "")).strip()
    metric = str(row.get("metric", "")).strip()
    return (
        "The author-approved NCES cross-release tolerance is "
        f"absolute={absolute} and relative={relative} for metric class {metric}; "
        "it was not estimated from Access diagnostic deltas. Access diagnostics "
        "are post-hoc comparison context only."
    )


def _validate_unique(
    rows: Sequence[Mapping[str, str]],
    fields: Sequence[str],
    *,
    label: str,
) -> None:
    identities = [tuple(row.get(field, "") for field in fields) for row in rows]
    if len(identities) != len(set(identities)):
        raise FinalDecisionPackageError(
            f"{label} contains duplicate identities for {list(fields)}"
        )


def build_b03_b04(
    stage04: Path,
    *,
    author: str,
    review_date: str,
) -> tuple[
    list[dict[str, str]],
    list[dict[str, str]],
    dict[str, object],
]:
    manifest_name = "STAGE04_PROJECTION_ARTIFACT_MANIFEST.csv"
    input_name = "STAGE04_PROJECTION_INPUT_MANIFEST.csv"
    manifest_members = validate_artifact_manifest(
        stage04,
        manifest_name,
        required_members=(
            "table_grain_contract_projection.csv",
            "source_columns_contract_projection.csv",
            "stage04_proposed_empty_exclusions.csv",
            input_name,
        ),
    )
    table = read_csv(
        stage04 / "table_grain_contract_projection.csv",
        exact_fields=TABLE_FIELDS,
        label="B03 table projection",
    )
    source = read_csv(
        stage04 / "source_columns_contract_projection.csv",
        exact_fields=SOURCE_FIELDS,
        label="B04 source projection",
    )
    exclusions = read_csv(
        stage04 / "stage04_proposed_empty_exclusions.csv",
        required_fields=(
            "original_decision_id",
            "nonempty_count",
            "original_role",
            "proposed_role",
            "author_decision_status",
        ),
        label="B04 empty-exclusion register",
    )
    validate_contract_id(table, label="B03 table projection")
    validate_contract_id(source, label="B04 source projection")
    if any(_truth(row["reviewed"]) for row in table + source):
        raise FinalDecisionPackageError(
            "B03/B04 source projection is not uniformly unsigned"
        )
    if any(row["grain_class"] not in {"scalar", "dimensioned"} for row in table):
        raise FinalDecisionPackageError(
            "B03 source contains unready or unsupported grain"
        )
    if any(row["role"] == "unknown" for row in source):
        raise FinalDecisionPackageError(
            "B04 source still contains an unknown role"
        )
    bad_exclusions = [
        row
        for row in exclusions
        if row["nonempty_count"] != "0"
        or row["original_role"] != "unknown"
        or row["proposed_role"] != "excluded"
        or row["author_decision_status"] != "pending"
    ]
    if bad_exclusions:
        raise FinalDecisionPackageError(
            "B04 empty-exclusion source is pending/unready or nonempty"
        )
    _validate_unique(table, ("decision_id",), label="B03 projection")
    _validate_unique(source, ("decision_id",), label="B04 projection")
    final_table = []
    for raw in table:
        row = dict(raw)
        row["reviewed"] = "true"
        row["review_note"] = finalize_review_text(
            row["review_note"],
            author=author,
            review_date=review_date,
        )
        final_table.append(row)
    final_source = []
    for raw in source:
        row = dict(raw)
        row["reviewed"] = "true"
        row["review_note"] = finalize_review_text(
            row["review_note"],
            author=author,
            review_date=review_date,
        )
        final_source.append(row)
    return final_table, final_source, {
        "manifest_path": stage04 / manifest_name,
        "manifest_members": manifest_members,
        "input_path": stage04 / input_name,
        "b03_child_path": stage04 / "table_grain_contract_projection.csv",
        "b04_child_path": (
            stage04 / "stage04_proposed_empty_exclusions.csv"
        ),
    }


def build_b05_b06(
    base: Path,
    *,
    author: str,
    review_date: str,
) -> tuple[
    list[dict[str, str]],
    list[dict[str, str]],
    dict[str, object],
]:
    manifest_name = "B05_B06_ARTIFACT_MANIFEST.csv"
    input_name = "B05_B06_INPUT_MANIFEST.csv"
    register_name = "B05_B06_CONSERVATIVE_DECISION_REGISTER.csv"
    manifest_members = validate_artifact_manifest(
        base,
        manifest_name,
        required_members=(
            "analysis_schema_candidate.csv",
            "discrete_families_candidate.csv",
            register_name,
            input_name,
        ),
    )
    analysis = read_csv(
        base / "analysis_schema_candidate.csv",
        exact_fields=ANALYSIS_FIELDS,
        label="B05 analysis candidate",
    )
    discrete = read_csv(
        base / "discrete_families_candidate.csv",
        exact_fields=DISCRETE_FIELDS,
        label="B06 discrete candidate",
    )
    register = read_csv(
        base / register_name,
        required_fields=(
            "phase",
            "decision_id",
            "contract_id",
            "candidate_key",
            "proposed_action",
            "review_status",
            "reviewer_decision",
        ),
        label="B05/B06 child decision register",
    )
    validate_contract_id(analysis, label="B05 analysis candidate")
    validate_contract_id(discrete, label="B06 discrete candidate")
    validate_contract_id(register, label="B05/B06 child decision register")
    allowed_pending = {
        "pending_author_review",
        "pending_author_semantic_review",
    }
    unready = [
        row
        for row in register
        if row["phase"] not in {"B05", "B06"}
        or row["review_status"] not in allowed_pending
        or row["reviewer_decision"]
        or row.get("reviewer", "")
        or row.get("review_date", "")
    ]
    if unready:
        phase = unready[0].get("phase", "B05/B06")
        raise FinalDecisionPackageError(
            f"{phase} child source contains an unready decision"
        )
    b05 = [row for row in register if row["phase"] == "B05"]
    b06 = [row for row in register if row["phase"] == "B06"]
    if len(b05) != len(analysis) or len(b06) != len(discrete):
        raise FinalDecisionPackageError(
            "B05/B06 candidate and child-decision row counts differ"
        )
    if any(row["proposed_action"] != "include_direct_identity" for row in b05):
        raise FinalDecisionPackageError("B05 source action is unready")
    if any(row["proposed_action"] != "retain_not_collapsible" for row in b06):
        raise FinalDecisionPackageError("B06 source action is unready")
    analysis_keys = {row["analysis_column"] for row in analysis}
    if analysis_keys != {row["candidate_key"] for row in b05}:
        raise FinalDecisionPackageError(
            "B05 child decisions do not exactly cover analysis candidates"
        )
    discrete_keys = {
        f"{row['source_file']}:{row['family_id']}:{row['component_varname']}"
        for row in discrete
    }
    if discrete_keys != {row["candidate_key"] for row in b06}:
        raise FinalDecisionPackageError(
            "B06 child decisions do not exactly cover discrete candidates"
        )
    _validate_unique(
        analysis,
        ("analysis_column",),
        label="B05 analysis candidate",
    )
    _validate_unique(
        discrete,
        ("source_file", "family_id", "component_varname"),
        label="B06 discrete candidate",
    )
    final_analysis = []
    for raw in analysis:
        row = dict(raw)
        if row["status"] != "active":
            raise FinalDecisionPackageError(
                "B05 source contains a non-active candidate"
            )
        row["inclusion_reason"] = finalize_review_text(
            row["inclusion_reason"],
            author=author,
            review_date=review_date,
        )
        final_analysis.append(row)
    final_discrete = []
    for raw in discrete:
        row = dict(raw)
        if row["semantic_type"] != "not_collapsible":
            raise FinalDecisionPackageError(
                "B06 source contains an inferred collapsible family"
            )
        row["review_note"] = finalize_review_text(
            row["review_note"],
            author=author,
            review_date=review_date,
        )
        final_discrete.append(row)
    return final_analysis, final_discrete, {
        "manifest_path": base / manifest_name,
        "manifest_members": manifest_members,
        "input_path": base / input_name,
        "register_path": base / register_name,
    }


def validate_b07_review_digest(base: Path) -> tuple[dict[str, str], str]:
    path = base / "B07_PRCH_POLICY_REVIEW_TARGET_DIGEST.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise FinalDecisionPackageError(
            f"B07 review-target digest missing or invalid: {path}"
        ) from exc
    members = payload.get("members")
    if not isinstance(members, dict) or not members:
        raise FinalDecisionPackageError(
            "B07 review-target digest has no member map"
        )
    if payload.get("contract_id") != CONTRACT_ID:
        raise FinalDecisionPackageError(
            "B07 review-target digest has the wrong contract_id"
        )
    expected_members = set(B07_REVIEW_TARGET_FILES)
    actual_members = {str(member) for member in members}
    if actual_members != expected_members:
        raise FinalDecisionPackageError(
            "B07 review-target digest member set is incomplete or unexpected: "
            f"missing={sorted(expected_members - actual_members)} "
            f"unexpected={sorted(actual_members - expected_members)}"
        )
    observed: dict[str, str] = {}
    for relative, expected_hash in sorted(members.items()):
        member = _path_within(
            base,
            str(relative),
            label="B07 review-target member",
        )
        if not member.is_file() or sha256_file(member) != expected_hash:
            raise FinalDecisionPackageError(
                f"B07 review-target member integrity mismatch: {relative}"
            )
        observed[str(relative)] = str(expected_hash)
    digest = canonical_json_sha256(observed)
    if digest != payload.get("review_target_package_sha256"):
        raise FinalDecisionPackageError(
            "B07 review-target package digest is defective"
        )
    if payload.get("status") != "conditional_pending_author_countersign":
        raise FinalDecisionPackageError(
            "B07 review-target remains unready"
        )
    return observed, digest


def _b07_pending_review_rows(
    base: Path,
    name: str,
    *,
    require_nonempty: bool = True,
) -> list[dict[str, str]]:
    rows = read_csv(
        base / name,
        required_fields=("review_status",),
        label=name,
    )
    if require_nonempty and not rows:
        raise FinalDecisionPackageError(f"{name} is empty/unready")
    allowed = {
        "pending_author_review",
        "pending_collective_author_countersign",
    }
    if any(row["review_status"] not in allowed for row in rows):
        raise FinalDecisionPackageError(
            f"{name} contains an unresolved or unexpected review status"
        )
    for row in rows:
        for field in ("author_decision", "author_name", "author_date"):
            if row.get(field, ""):
                raise FinalDecisionPackageError(
                    f"{name} contains an already-mutated author decision"
                )
    return rows


def build_b07(
    base: Path,
    *,
    author: str,
    review_date: str,
    test_mode: bool,
) -> tuple[list[dict[str, str]], dict[str, object]]:
    for name in B07_REQUIRED_FILES:
        if not (base / name).is_file():
            raise FinalDecisionPackageError(f"B07 required file missing: {name}")
    candidate = read_csv(
        base / "B07_PRCH_POLICY_CANDIDATE.csv",
        exact_fields=PRCH_FIELDS,
        label="B07 PRCH policy candidate",
    )
    if not candidate:
        raise FinalDecisionPackageError("B07 candidate is empty/unready")
    unready = [
        row
        for row in candidate
        if not row["review_status"]
        or "request_more_evidence" in row["review_status"].casefold()
        or "unresolved" in row["review_status"].casefold()
        or not row["source_reference"]
        or not row["rationale"]
    ]
    if unready:
        raise FinalDecisionPackageError(
            "B07 candidate contains an unready rule"
        )
    manifest_members = validate_artifact_manifest(
        base,
        "B07_PRCH_POLICY_ARTIFACT_MANIFEST.csv",
        required_members=(
            *B07_REVIEW_TARGET_FILES,
            "B07_PRCH_POLICY_AUTHOR_COUNTERSIGN.csv",
            "B07_PRCH_POLICY_REVIEW_TARGET_DIGEST.json",
            "B07_PRCH_POLICY_SUMMARY.json",
        ),
    )
    review_members, review_target_hash = validate_b07_review_digest(base)
    if any(
        manifest_members.get(name) != review_members[name]
        for name in B07_REVIEW_TARGET_FILES
    ):
        raise FinalDecisionPackageError(
            "B07 artifact manifest and review-target digest disagree"
        )

    component_rows = _b07_pending_review_rows(
        base,
        "B07_COMPONENT_BINDING_REGISTER.csv",
    )
    _b07_pending_review_rows(
        base,
        "B07_COMPONENT_BINDING_SUMMARY.csv",
    )
    component_exceptions = _b07_pending_review_rows(
        base,
        "B07_COMPONENT_METADATA_EXCEPTION_REGISTER.csv",
    )
    finance_rows = _b07_pending_review_rows(
        base,
        "B07_FINANCE_SOURCE_PART_BINDINGS.csv",
    )
    _b07_pending_review_rows(
        base,
        "B07_FINANCE_BINDING_SUMMARY.csv",
    )
    finance_exceptions = _b07_pending_review_rows(
        base,
        "B07_FINANCE_METADATA_EXCEPTION_REGISTER.csv",
    )
    for row in finance_exceptions:
        if (
            not row.get("official_pdf_sha256")
            or not row.get("official_pdf_part_page")
        ):
            raise FinalDecisionPackageError(
                "B07 Finance metadata exception lacks official PDF binding"
            )
    alias_rows = read_csv(
        base / "B07_B04_ALIAS_LINEAGE.csv",
        required_fields=("alias_decision_id", "binding_status"),
        label="B07 B04 alias lineage",
    )
    if not alias_rows or any(
        row["alias_decision_id"] != "B04-ALIAS-001"
        or row["binding_status"] != "exact_countersigned_B04_alias"
        for row in alias_rows
    ):
        raise FinalDecisionPackageError(
            "B07 B04 alias lineage is absent or defective"
        )
    semantic_rows = read_csv(
        base / "B07_SEMANTIC_CONFLICT_DIAGNOSTIC.csv",
        required_fields=("resolution_status", "unresolved_conflict"),
        label="B07 semantic conflict diagnostic",
    )
    if not semantic_rows or any(
        _truth(row["unresolved_conflict"])
        or not row["resolution_status"]
        or row["resolution_status"].casefold().startswith("unresolved")
        for row in semantic_rows
    ):
        raise FinalDecisionPackageError(
            "B07 semantic conflict diagnostic contains an unresolved conflict"
        )
    coverage_rows = read_csv(
        base / "B07_PRCH_POLICY_PREDICATE_COVERAGE.csv",
        required_fields=("coverage_status",),
        label="B07 predicate coverage",
    )
    if not coverage_rows or any(
        row["coverage_status"] != "exact" for row in coverage_rows
    ):
        raise FinalDecisionPackageError("B07 predicate coverage is defective")
    lineage_rows = read_csv(
        base / "B07_PRCH_POLICY_TARGET_LINEAGE.csv",
        required_fields=("binding_status",),
        label="B07 target lineage",
    )
    if not lineage_rows or any(
        row["binding_status"]
        not in {
            "exact",
            "exact_identity_pending_author_binding_and_b05_review",
        }
        for row in lineage_rows
    ):
        raise FinalDecisionPackageError("B07 target lineage is defective")
    canonical_rows = read_csv(
        base / "B07_PRCH_POLICY_CANONICAL_HASH_PROOF.csv",
        required_fields=("pre_sha256", "post_sha256", "unchanged"),
        label="B07 canonical hash proof",
    )
    if not canonical_rows or any(
        not _truth(row["unchanged"])
        or row["pre_sha256"] != row["post_sha256"]
        for row in canonical_rows
    ):
        raise FinalDecisionPackageError(
            "B07 canonical hash proof is defective"
        )
    finance_correction_rows = read_csv(
        base / "B07_2010_FINANCE_CORRECTION_PROOF.csv",
        required_fields=("proof_status",),
        label="B07 2010 Finance correction proof",
    )
    if not finance_correction_rows or any(
        row["proof_status"] != "exact_corrected_inclusion_and_exclusion"
        for row in finance_correction_rows
    ):
        raise FinalDecisionPackageError(
            "B07 2010 Finance correction proof is defective"
        )
    collision_rows = read_csv(
        base / "B07_CROSS_FLAG_TARGET_CELL_COLLISIONS.csv",
        required_fields=("collision_class", "approval_status"),
        label="B07 cross-flag collision proof",
    )
    if any(
        row["collision_class"] != "idempotent_null_null"
        or row["approval_status"] != "pending_author_approval"
        for row in collision_rows
    ):
        raise FinalDecisionPackageError(
            "B07 cross-flag collision proof contains a fatal collision"
        )
    pair_rows = read_csv(
        base / "B07_CROSS_FLAG_PAIR_SUMMARY.csv",
        required_fields=("collision_class", "approval_status"),
        label="B07 cross-flag pair summary",
    )
    if not pair_rows or any(
        row["collision_class"] not in {"none", "idempotent_null_null"}
        or row["approval_status"]
        not in {"no_collision", "pending_author_approval"}
        for row in pair_rows
    ):
        raise FinalDecisionPackageError(
            "B07 cross-flag pair summary contains a fatal collision"
        )
    zero_target_rows = read_csv(
        base / "B07_PRCH_POLICY_ZERO_TARGET_DIAGNOSTICS.csv",
        required_fields=("status",),
        label="B07 zero-target diagnostics",
    )
    if any(
        row["status"]
        not in {
            "conditional_semantic_retain_pending_author_countersign",
            "conditional_zero_target_noop_pending_author_countersign",
        }
        for row in zero_target_rows
    ):
        raise FinalDecisionPackageError(
            "B07 zero-target diagnostic contains an unready status"
        )
    if not test_mode:
        if len(finance_exceptions) != B07_EXPECTED_FINANCE_METADATA_EXCEPTIONS:
            raise FinalDecisionPackageError(
                "B07 Finance metadata exception count changed: "
                f"expected={B07_EXPECTED_FINANCE_METADATA_EXCEPTIONS} "
                f"actual={len(finance_exceptions)}"
            )
        if len(alias_rows) != B07_EXPECTED_B04_ALIAS_ROWS:
            raise FinalDecisionPackageError(
                "B07 B04 alias-lineage count changed: "
                f"expected={B07_EXPECTED_B04_ALIAS_ROWS} "
                f"actual={len(alias_rows)}"
            )
    try:
        summary = json.loads(
            (base / "B07_PRCH_POLICY_SUMMARY.json").read_text(
                encoding="utf-8"
            )
        )
    except (OSError, json.JSONDecodeError) as exc:
        raise FinalDecisionPackageError("B07 summary missing or defective") from exc
    if summary.get("status") != (
        "B07_PRCH_POLICY_CONDITIONAL_REVIEW_CANDIDATE_GENERATED"
    ):
        raise FinalDecisionPackageError("B07 summary status is unready")
    required_zero = (
        "predicate_coverage_failures",
        "predicate_overlap_failures",
        "fatal_cross_flag_collision_count",
        "dimensioned_lane_target_count",
        "unresolved_semantic_conflict_count",
    )
    if any(int(summary.get(field, -1)) != 0 for field in required_zero):
        raise FinalDecisionPackageError(
            "B07 summary contains a fatal or unresolved proof count"
        )
    candidate_hash = sha256_file(base / "B07_PRCH_POLICY_CANDIDATE.csv")
    if (
        summary.get("candidate_sha256") != candidate_hash
        or int(summary.get("candidate_rule_count", -1)) != len(candidate)
        or summary.get("review_target_package_sha256") != review_target_hash
        or int(
            summary.get("pending_finance_metadata_exception_rows", -1)
        )
        != len(finance_exceptions)
        or int(
            summary.get("pending_component_metadata_exception_rows", -1)
        )
        != len(component_exceptions)
        or int(summary.get("b04_alias_lineage_row_count", -1))
        != len(alias_rows)
        or int(summary.get("finance_2010_correction_rule_count", -1))
        != len(finance_correction_rows)
        or int(summary.get("semantic_conflict_diagnostic_row_count", -1))
        != len(semantic_rows)
    ):
        raise FinalDecisionPackageError(
            "B07 summary does not bind the exact candidate/review target"
        )
    countersign = read_csv(
        base / "B07_PRCH_POLICY_AUTHOR_COUNTERSIGN.csv",
        required_fields=(
            "contract_id",
            "candidate_path",
            "candidate_sha256",
            "candidate_rule_count",
            "component_binding_register_path",
            "component_binding_register_sha256",
            "component_binding_row_count",
            "component_metadata_exception_register_sha256",
            "component_metadata_exception_row_count",
            "b04_alias_lineage_sha256",
            "b04_alias_lineage_row_count",
            "finance_source_part_bindings_path",
            "finance_source_part_bindings_sha256",
            "finance_source_part_binding_row_count",
            "finance_metadata_exception_register_sha256",
            "finance_metadata_exception_row_count",
            "finance_2010_correction_proof_sha256",
            "finance_2010_correction_rule_count",
            "semantic_conflict_diagnostic_sha256",
            "semantic_conflict_diagnostic_row_count",
            "target_lineage_sha256",
            "cross_flag_collision_sha256",
            "cross_flag_collision_row_count",
            "review_target_package_sha256",
            "input_manifest_sha256",
            "b05_input_review_state",
            "b07_input_review_state",
            "required_decision",
            "author_decision",
            "author_name",
            "author_date",
        ),
        label="B07 child author-countersign register",
    )
    if len(countersign) != 1:
        raise FinalDecisionPackageError(
            "B07 child author-countersign register must contain one row"
        )
    child = countersign[0]
    if (
        child["contract_id"] != CONTRACT_ID
        or child["candidate_path"] != "B07_PRCH_POLICY_CANDIDATE.csv"
        or child["candidate_sha256"] != candidate_hash
        or child["candidate_rule_count"] != str(len(candidate))
        or child["component_binding_register_path"]
        != "B07_COMPONENT_BINDING_REGISTER.csv"
        or child["component_binding_register_sha256"]
        != sha256_file(base / "B07_COMPONENT_BINDING_REGISTER.csv")
        or child["component_binding_row_count"] != str(len(component_rows))
        or child["component_metadata_exception_register_sha256"]
        != sha256_file(
            base / "B07_COMPONENT_METADATA_EXCEPTION_REGISTER.csv"
        )
        or child["component_metadata_exception_row_count"]
        != str(len(component_exceptions))
        or child["b04_alias_lineage_sha256"]
        != sha256_file(base / "B07_B04_ALIAS_LINEAGE.csv")
        or child["b04_alias_lineage_row_count"] != str(len(alias_rows))
        or child["finance_source_part_bindings_path"]
        != "B07_FINANCE_SOURCE_PART_BINDINGS.csv"
        or child["finance_source_part_bindings_sha256"]
        != sha256_file(base / "B07_FINANCE_SOURCE_PART_BINDINGS.csv")
        or child["finance_source_part_binding_row_count"]
        != str(len(finance_rows))
        or child["finance_metadata_exception_register_sha256"]
        != sha256_file(
            base / "B07_FINANCE_METADATA_EXCEPTION_REGISTER.csv"
        )
        or child["finance_metadata_exception_row_count"]
        != str(len(finance_exceptions))
        or child["finance_2010_correction_proof_sha256"]
        != sha256_file(base / "B07_2010_FINANCE_CORRECTION_PROOF.csv")
        or child["finance_2010_correction_rule_count"]
        != str(len(finance_correction_rows))
        or child["semantic_conflict_diagnostic_sha256"]
        != sha256_file(base / "B07_SEMANTIC_CONFLICT_DIAGNOSTIC.csv")
        or child["semantic_conflict_diagnostic_row_count"]
        != str(len(semantic_rows))
        or child["target_lineage_sha256"]
        != sha256_file(base / "B07_PRCH_POLICY_TARGET_LINEAGE.csv")
        or child["cross_flag_collision_sha256"]
        != sha256_file(base / "B07_CROSS_FLAG_TARGET_CELL_COLLISIONS.csv")
        or child["cross_flag_collision_row_count"]
        != str(len(collision_rows))
        or child["review_target_package_sha256"] != review_target_hash
        or child["input_manifest_sha256"]
        != sha256_file(base / "B07_PRCH_POLICY_INPUT_MANIFEST.csv")
        or child["author_decision"]
        or child["author_name"]
        or child["author_date"]
        or "pending" not in child["b05_input_review_state"].casefold()
        or child["b07_input_review_state"]
        != "unsigned_supported_author_countersign_pending"
    ):
        raise FinalDecisionPackageError(
            "B07 child countersign target is defective or already mutated"
        )
    overlap_rows = read_csv(
        base / "B07_PRCH_POLICY_OVERLAP_PROOF.csv",
        required_fields=("overlap_status",),
        label="B07 overlap proof",
    )
    if any(
        row["overlap_status"].casefold() not in {"", "none", "no_overlap"}
        for row in overlap_rows
    ):
        raise FinalDecisionPackageError("B07 overlap proof is defective")
    _validate_unique(candidate, ("rule_id",), label="B07 policy candidate")
    final_rows = []
    for raw in candidate:
        row = dict(raw)
        row["review_status"] = "approved"
        row["rationale"] = finalize_review_text(
            row["rationale"],
            author=author,
            review_date=review_date,
        )
        final_rows.append(row)
    return final_rows, {
        "manifest_path": base / "B07_PRCH_POLICY_ARTIFACT_MANIFEST.csv",
        "manifest_members": manifest_members,
        "input_path": base / "B07_PRCH_POLICY_INPUT_MANIFEST.csv",
        "register_path": base / "B07_PRCH_POLICY_AUTHOR_COUNTERSIGN.csv",
        "review_digest_path": (
            base / "B07_PRCH_POLICY_REVIEW_TARGET_DIGEST.json"
        ),
        "review_members": review_members,
    }


def validate_stable_b08_receipt(
    repo: Path,
    rows: Sequence[Mapping[str, str]],
) -> dict[str, str]:
    members: dict[str, str] = {}
    for row in rows:
        relative = row["source_evidence_path"]
        safe = _safe_relative_path(
            relative,
            label="B08 source_evidence_path",
        )
        if (
            len(safe.parts) < 4
            or safe.parts[:2] != ("Artifacts", "review_v2")
            or safe.name
            != "B08_OFFICIAL_BENCHMARK_EVIDENCE_RECEIPT.json"
        ):
            raise FinalDecisionPackageError(
                "B08 receipt path is not a stable repo-relative "
                "Artifacts/review_v2 receipt path"
            )
        path = _path_within(
            repo,
            relative,
            label="B08 source_evidence_path",
        )
        if not path.is_file():
            raise FinalDecisionPackageError(
                f"B08 stable evidence receipt missing: {relative}"
            )
        actual = sha256_file(path)
        if actual != row["source_evidence_sha256"]:
            raise FinalDecisionPackageError(
                f"B08 stable evidence receipt hash mismatch: {relative}"
            )
        members[relative] = actual
    return members


def build_b08_b09(
    repo: Path,
    base: Path,
    *,
    author: str,
    review_date: str,
) -> tuple[
    list[dict[str, str]],
    list[dict[str, str]],
    dict[str, object],
]:
    manifest_name = "SCIENTIFIC_REVIEW_PACKAGE_MANIFEST.csv"
    b08_name = "B08_EXTERNAL_BENCHMARK_DECISION_REGISTER.csv"
    b09_candidate_name = "B09_METADATA_BACKFILL_CONDITIONAL_CANDIDATE.csv"
    b09_register_name = "B09_METADATA_BACKFILL_DECISION_REGISTER.csv"
    manifest_members = validate_artifact_manifest(
        base,
        manifest_name,
        required_members=(b08_name, b09_candidate_name, b09_register_name),
    )
    b08 = read_csv(
        base / b08_name,
        required_fields=BENCHMARK_FIELDS
        + ("decision_id", "decision_status", "decision_needed"),
        label="B08 benchmark decision register",
    )
    validate_contract_id(b08, label="B08 benchmark decision register")
    if any(
        row["review_status"] != "pending"
        or row["decision_status"] != "author_review_required"
        or not row["decision_needed"]
        or row["reviewer"]
        or row["review_date"]
        for row in b08
    ):
        raise FinalDecisionPackageError(
            "B08 source contains a pending/unready or already mutated decision"
        )
    receipt_members = validate_stable_b08_receipt(repo, b08)
    _validate_unique(b08, ("benchmark_id",), label="B08 benchmark register")
    final_b08 = []
    for raw in b08:
        row = {field: raw.get(field, "") for field in BENCHMARK_FIELDS}
        row["review_status"] = "approved"
        row["reviewer"] = author
        row["review_date"] = review_date
        row["tolerance_rationale"] = finalize_benchmark_tolerance_rationale(row)
        row["notes"] = finalize_review_text(
            row["notes"],
            author=author,
            review_date=review_date,
        )
        final_b08.append(row)

    b09 = read_csv(
        base / b09_candidate_name,
        exact_fields=BACKFILL_FIELDS,
        label="B09 conditional candidate",
    )
    b09_register = read_csv(
        base / b09_register_name,
        required_fields=(
            "decision_id",
            "target_year",
            "source_file",
            "access_table_name",
            "target_varname",
            "candidate_variable_id",
            "recommended_donor_year",
            "recommendation_status",
            "decision_needed",
            "decision_status",
        ),
        label="B09 child decision register",
    )
    validate_contract_id(b09, label="B09 conditional candidate")
    if any(
        row["approval_status"] != "pending_author_review"
        or row["reviewer"]
        or row["review_date"]
        or row["compatibility_status"]
        != "exact_adjacent_donor_semantics_match"
        for row in b09
    ):
        raise FinalDecisionPackageError(
            "B09 source contains a pending/unready or defective candidate"
        )
    if any(
        row["decision_status"] != "author_review_required"
        or row["recommendation_status"]
        != "nonbinding_author_review_required"
        or not row["decision_needed"]
        for row in b09_register
    ):
        raise FinalDecisionPackageError(
            "B09 child register contains an unready decision"
        )
    by_id = {row["decision_id"]: row for row in b09_register}
    if len(by_id) != len(b09_register) or set(by_id) != {
        row["approval_id"] for row in b09
    }:
        raise FinalDecisionPackageError(
            "B09 child decisions do not exactly cover conditional candidates"
        )
    for row in b09:
        decision = by_id[row["approval_id"]]
        if (
            row["target_year"] != decision["target_year"]
            or row["source_file"] != decision["source_file"]
            or row["access_table_name"] != decision["access_table_name"]
            or row["target_varname"] != decision["target_varname"]
            or row["variable_id"] != decision["candidate_variable_id"]
            or row["donor_year"] != decision["recommended_donor_year"]
        ):
            raise FinalDecisionPackageError(
                f"B09 candidate differs from child decision {row['approval_id']}"
            )
    final_b09 = []
    for raw in b09:
        row = dict(raw)
        row["approval_status"] = "approved"
        row["reviewer"] = author
        row["review_date"] = review_date
        row["justification"] = finalize_review_text(
            row["justification"],
            author=author,
            review_date=review_date,
        )
        final_b09.append(row)
    return final_b08, final_b09, {
        "manifest_path": base / manifest_name,
        "manifest_members": manifest_members,
        "input_path": base / manifest_name,
        "b08_register_path": base / b08_name,
        "b09_register_path": base / b09_register_name,
        "receipt_members": receipt_members,
    }


def _critical_source_members(
    repo: Path,
    groups: Sequence[Mapping[str, object]],
) -> dict[str, str]:
    members: dict[str, str] = {}
    for group in groups:
        for key in ("manifest_path", "input_path", "register_path"):
            path = group.get(key)
            if isinstance(path, Path):
                members[
                    f"repository/{_repo_relative(repo, path, label=key)}"
                ] = sha256_file(path)
        for key in (
            "b03_child_path",
            "b04_child_path",
            "b08_register_path",
            "b09_register_path",
            "review_digest_path",
        ):
            path = group.get(key)
            if isinstance(path, Path):
                members[
                    f"repository/{_repo_relative(repo, path, label=key)}"
                ] = sha256_file(path)
        for mapping_key in (
            "manifest_members",
            "review_members",
            "receipt_members",
        ):
            mapping = group.get(mapping_key)
            if isinstance(mapping, Mapping):
                prefix = str(group.get("member_prefix", mapping_key))
                for relative, digest in sorted(mapping.items()):
                    members[f"{prefix}/{relative}"] = str(digest)
    return members


def write_deterministic_zip(source: Path, target: Path) -> None:
    candidates = [
        path
        for path in sorted(
            source.rglob("*"),
            key=lambda item: item.relative_to(source).as_posix(),
        )
        if path.is_file()
        and path != target
        and path.name != "FINAL_AUTHOR_DECISION_BUNDLE.sha256"
    ]
    with zipfile.ZipFile(
        target,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
    ) as archive:
        for path in candidates:
            relative = path.relative_to(source).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes())


def _write_boundary(path: Path) -> None:
    path.write_text(
        """# Scientific authorization boundary

This package can authorize only exact canonical B03-B09 contract bytes listed
in `CANONICAL_APPLICATION_SCOPE.csv`.

It does not authorize Stage 02 extraction, a full 2004-2023 build, release,
deployment, worktree cleanup, file deletion, package installation, Docker,
Colima, or any other operational action.

FULL_BUILD_NOT_RUN
RELEASE_STILL_BLOCKED
""",
        encoding="utf-8",
        newline="\n",
    )


def _canonical_proof_rows(
    repo: Path,
    snapshot: Mapping[str, str],
) -> list[dict[str, object]]:
    return [
        {
            "path": relative,
            "byte_size": (repo / relative).stat().st_size,
            "sha256": digest,
        }
        for relative, digest in sorted(snapshot.items())
    ]


def _build_into(
    staging: Path,
    *,
    repo: Path,
    snapshot: Mapping[str, str],
    stage04_dir: Path,
    b05_b06_dir: Path,
    b07_dir: Path,
    remaining_dir: Path,
    author_name: str,
    review_date: str,
    generator_path: Path,
    provenance: Mapping[str, str],
    test_mode: bool,
) -> dict[str, object]:
    b03, b04, stage_meta = build_b03_b04(
        stage04_dir,
        author=author_name,
        review_date=review_date,
    )
    b05, b06, b05_meta = build_b05_b06(
        b05_b06_dir,
        author=author_name,
        review_date=review_date,
    )
    b07, b07_meta = build_b07(
        b07_dir,
        author=author_name,
        review_date=review_date,
        test_mode=test_mode,
    )
    b08, b09, remaining_meta = build_b08_b09(
        repo,
        remaining_dir,
        author=author_name,
        review_date=review_date,
    )
    stage_meta["member_prefix"] = "stage04"
    b05_meta["member_prefix"] = "b05_b06"
    b07_meta["member_prefix"] = "b07"
    remaining_meta["member_prefix"] = "b08_b09"
    metadata = (stage_meta, b05_meta, b07_meta, remaining_meta)

    candidate_dir = staging / "canonical_candidates"
    candidate_rows = {
        "table_grain.csv": (TABLE_FIELDS, b03),
        "source_columns.csv": (SOURCE_FIELDS, b04),
        "analysis_schema.csv": (ANALYSIS_FIELDS, b05),
        "discrete_families.csv": (DISCRETE_FIELDS, b06),
        "prch_policy.csv": (PRCH_FIELDS, b07),
        "external_benchmarks.csv": (BENCHMARK_FIELDS, b08),
        "metadata_backfill_approvals.csv": (BACKFILL_FIELDS, b09),
    }
    for name, (fields, rows) in candidate_rows.items():
        write_csv(candidate_dir / name, fields, rows)

    scope_sources = {
        "B03": {
            "child_scope": (
                "all exact Stage04 table identities represented by the "
                "lossless table projection"
            ),
            "child": stage_meta["b03_child_path"],
            "manifest": stage_meta["manifest_path"],
            "input": stage_meta["input_path"],
        },
        "B04": {
            "child_scope": (
                "all exact Stage04 source roles and every explicit all-empty "
                "intentional exclusion"
            ),
            "child": stage_meta["b04_child_path"],
            "manifest": stage_meta["manifest_path"],
            "input": stage_meta["input_path"],
        },
        "B05": {
            "child_scope": (
                "phase=B05; every exact include_direct_identity action"
            ),
            "child": b05_meta["register_path"],
            "manifest": b05_meta["manifest_path"],
            "input": b05_meta["input_path"],
        },
        "B06": {
            "child_scope": (
                "phase=B06; every exact retain_not_collapsible action"
            ),
            "child": b05_meta["register_path"],
            "manifest": b05_meta["manifest_path"],
            "input": b05_meta["input_path"],
        },
        "B07": {
            "child_scope": (
                "the exact B07 conditional review target, component and "
                "Finance bindings, exception register, lineage, and proofs"
            ),
            "child": b07_meta["register_path"],
            "manifest": b07_meta["manifest_path"],
            "input": b07_meta["input_path"],
        },
        "B08": {
            "child_scope": (
                "every official benchmark value, definition, source channel, "
                "and exact tolerance in the B08 decision register"
            ),
            "child": remaining_meta["b08_register_path"],
            "manifest": remaining_meta["manifest_path"],
            "input": remaining_meta["input_path"],
        },
        "B09": {
            "child_scope": (
                "every exact B09 conditional donor selection represented by "
                "the final candidate"
            ),
            "child": remaining_meta["b09_register_path"],
            "manifest": remaining_meta["manifest_path"],
            "input": remaining_meta["input_path"],
        },
    }
    scope_rows = []
    for block, canonical_path, candidate_name in TARGETS:
        candidate_path = candidate_dir / candidate_name
        source = scope_sources[block]
        canonical_pre = snapshot.get(canonical_path)
        if not canonical_pre:
            raise FinalDecisionPackageError(
                f"canonical pre-hash missing for {canonical_path}"
            )
        digest = sha256_file(candidate_path)
        scope_rows.append(
            {
                "scope_id": f"{AUTHORIZATION_ID}-{block}",
                "contract_id": CONTRACT_ID,
                "block_id": block,
                "canonical_path": canonical_path,
                "canonical_pre_sha256": canonical_pre,
                "final_candidate_path": (
                    candidate_path.relative_to(staging).as_posix()
                ),
                "final_candidate_sha256": digest,
                "expected_post_sha256": digest,
                "row_count": len(candidate_rows[candidate_name][1]),
                "application_mode": "replace_exact_bytes",
                "child_decision_scope": source["child_scope"],
                "child_decision_register_path": _repo_relative(
                    repo,
                    source["child"],
                    label=f"{block} child register",
                ),
                "child_decision_register_sha256": sha256_file(source["child"]),
                "evidence_manifest_path": _repo_relative(
                    repo,
                    source["manifest"],
                    label=f"{block} evidence manifest",
                ),
                "evidence_manifest_sha256": sha256_file(source["manifest"]),
                "input_manifest_path": _repo_relative(
                    repo,
                    source["input"],
                    label=f"{block} input manifest",
                ),
                "input_manifest_sha256": sha256_file(source["input"]),
                "readiness_status": "author_ready",
            }
        )
    write_csv(
        staging / "CANONICAL_APPLICATION_SCOPE.csv",
        SCOPE_FIELDS,
        scope_rows,
    )
    write_csv(
        staging / "CANONICAL_PRE_HASH_PROOF.csv",
        ("path", "byte_size", "sha256"),
        _canonical_proof_rows(repo, snapshot),
    )
    _write_boundary(staging / "SCIENTIFIC_AUTHORIZATION_BOUNDARY.md")

    transitive_members = _critical_source_members(repo, metadata)
    for path in sorted(candidate_dir.iterdir(), key=lambda item: item.name):
        transitive_members[
            f"output/canonical_candidates/{path.name}"
        ] = sha256_file(path)
    for name in (
        "CANONICAL_APPLICATION_SCOPE.csv",
        "CANONICAL_PRE_HASH_PROOF.csv",
        "SCIENTIFIC_AUTHORIZATION_BOUNDARY.md",
    ):
        transitive_members[f"output/{name}"] = sha256_file(staging / name)
    transitive_hash = canonical_json_sha256(transitive_members)
    digest_payload = {
        "authorization_id": AUTHORIZATION_ID,
        "contract_id": CONTRACT_ID,
        "author_name": author_name,
        "author_date": review_date,
        "generator_commit": provenance["generator_commit"],
        "generator_sha256": provenance["generator_sha256"],
        "focused_test_sha256": provenance["focused_test_sha256"],
        "members": dict(sorted(transitive_members.items())),
        "member_count": len(transitive_members),
        "transitive_review_target_sha256": transitive_hash,
        "status": "author_ready_pending_countersign",
    }
    digest_path = staging / "TRANSITIVE_REVIEW_TARGET_DIGEST.json"
    digest_path.write_text(
        json.dumps(digest_payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    scope_hash = sha256_file(staging / "CANONICAL_APPLICATION_SCOPE.csv")
    digest_file_hash = sha256_file(digest_path)
    register_row = {
        "authorization_id": AUTHORIZATION_ID,
        "contract_id": CONTRACT_ID,
        "scope_manifest_path": "CANONICAL_APPLICATION_SCOPE.csv",
        "scope_manifest_sha256": scope_hash,
        "scope_row_count": len(scope_rows),
        "transitive_review_target_digest_path": (
            "TRANSITIVE_REVIEW_TARGET_DIGEST.json"
        ),
        "transitive_review_target_digest_sha256": digest_file_hash,
        "transitive_review_target_sha256": transitive_hash,
        "requested_action": "authorize_exact_canonical_application_only",
        "allowed_decisions": (
            "authorize_exact_canonical_application_only|reject|"
            "request_more_evidence"
        ),
        "decision_status": "pending_author_countersign",
        "author_name": author_name,
        "author_date": review_date,
        "release_boundary": "FULL_BUILD_NOT_RUN|RELEASE_STILL_BLOCKED",
    }
    write_csv(
        staging / "AUTHOR_DECISION_REGISTER.csv",
        AUTHOR_REGISTER_FIELDS,
        [register_row],
    )
    register_hash = sha256_file(staging / "AUTHOR_DECISION_REGISTER.csv")
    countersign = f"""# Final B03-B09 author countersign required

No canonical contract has been changed. The author-ready candidate files are
proposals until the exact countersign below is supplied.

Required signature:

> I, {author_name}, dated {review_date}, countersign
> `AUTHOR_DECISION_REGISTER.csv` SHA-256 `{register_hash}`,
> `CANONICAL_APPLICATION_SCOPE.csv` SHA-256 `{scope_hash}`, and transitive
> review-target SHA-256 `{transitive_hash}`. I authorize Codex to replace only
> the seven canonical B03-B09 paths listed in that scope, only when every
> canonical pre-hash, candidate hash, expected post-hash, row count, child
> decision scope, evidence manifest, and input manifest matches exactly. I
> approve every proposed child decision exactly within the listed hash-bound
> scopes, including the explicit all-empty B04 exclusions. Any mismatch voids
> this authorization and requires a stop. This authorizes canonical contract
> application only; it does not authorize Stage 02 extraction, a full build,
> release, deployment, cleanup, deletion, installation, Docker, or Colima.

FULL_BUILD_NOT_RUN
RELEASE_STILL_BLOCKED
"""
    (staging / "AUTHOR_COUNTERSIGN_REQUIRED.md").write_text(
        countersign,
        encoding="utf-8",
        newline="\n",
    )
    summary = {
        "authorization_id": AUTHORIZATION_ID,
        "status": "FINAL_AUTHOR_COUNTERSIGN_REQUIRED",
        "contract_id": CONTRACT_ID,
        "author_name": author_name,
        "author_date": review_date,
        "generator_commit": provenance["generator_commit"],
        "generator_sha256": provenance["generator_sha256"],
        "focused_test_sha256": provenance["focused_test_sha256"],
        "scope_row_count": len(scope_rows),
        "scope_manifest_sha256": scope_hash,
        "author_decision_register_sha256": register_hash,
        "transitive_review_target_digest_sha256": digest_file_hash,
        "transitive_review_target_sha256": transitive_hash,
        "canonical_contract_changed": False,
        "full_build_run": False,
        "release_status": "RELEASE_STILL_BLOCKED",
    }
    (staging / "FINAL_AUTHOR_DECISION_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )

    generator_hash = sha256_file(generator_path)
    artifact_rows = []
    for path in sorted(
        (candidate for candidate in staging.rglob("*") if candidate.is_file()),
        key=lambda candidate: candidate.relative_to(staging).as_posix(),
    ):
        if path.name in {
            "FINAL_AUTHOR_DECISION_ARTIFACT_MANIFEST.csv",
            "FINAL_AUTHOR_DECISION_BUNDLE.zip",
            "FINAL_AUTHOR_DECISION_BUNDLE.sha256",
        }:
            continue
        artifact_rows.append(
            {
                "path": path.relative_to(staging).as_posix(),
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
                "generator_sha256": generator_hash,
                "generator_commit": provenance["generator_commit"],
                "focused_test_sha256": provenance["focused_test_sha256"],
                "canonical_scope_sha256": scope_hash,
                "transitive_review_target_sha256": transitive_hash,
            }
        )
    write_csv(
        staging / "FINAL_AUTHOR_DECISION_ARTIFACT_MANIFEST.csv",
        (
            "path",
            "byte_size",
            "sha256",
            "generator_sha256",
            "generator_commit",
            "focused_test_sha256",
            "canonical_scope_sha256",
            "transitive_review_target_sha256",
        ),
        artifact_rows,
    )
    bundle = staging / "FINAL_AUTHOR_DECISION_BUNDLE.zip"
    write_deterministic_zip(staging, bundle)
    bundle_hash = sha256_file(bundle)
    (staging / "FINAL_AUTHOR_DECISION_BUNDLE.sha256").write_text(
        f"{bundle_hash}  FINAL_AUTHOR_DECISION_BUNDLE.zip\n",
        encoding="utf-8",
        newline="\n",
    )
    return {
        **summary,
        "bundle_sha256": bundle_hash,
        "candidate_hashes": {
            row["block_id"]: row["final_candidate_sha256"]
            for row in scope_rows
        },
    }


def build_package(
    *,
    repo_root: Path,
    stage04_dir: Path,
    b05_b06_dir: Path,
    b07_dir: Path,
    remaining_dir: Path,
    output_dir: Path,
    author_name: str = DEFAULT_AUTHOR,
    review_date: str = DEFAULT_REVIEW_DATE,
    test_mode: bool = False,
) -> dict[str, object]:
    repo = repo_root.resolve()
    output = output_dir.resolve()
    if author_name != DEFAULT_AUTHOR:
        raise FinalDecisionPackageError(
            f"author_name must equal {DEFAULT_AUTHOR!r}"
        )
    if review_date != DEFAULT_REVIEW_DATE:
        raise FinalDecisionPackageError(
            f"review_date must equal {DEFAULT_REVIEW_DATE!r}"
        )
    validate_output_directory(repo, output)
    provenance = code_provenance(repo, test_mode=test_mode)
    sources = {
        "Stage04": stage04_dir.resolve(),
        "B05/B06": b05_b06_dir.resolve(),
        "B07": b07_dir.resolve(),
        "B08/B09": remaining_dir.resolve(),
    }
    for label, path in sources.items():
        if not path.is_dir():
            raise FinalDecisionPackageError(
                f"{label} source directory missing: {path}"
            )
        _repo_relative(repo, path, label=f"{label} source directory")
    snapshot = canonical_snapshot(repo)
    missing_targets = [
        canonical_path
        for _, canonical_path, _ in TARGETS
        if canonical_path not in snapshot
    ]
    if missing_targets:
        raise FinalDecisionPackageError(
            f"canonical target files missing: {missing_targets}"
        )

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix=".final-author-decision.",
        dir=output.parent,
    ) as temporary:
        staging = Path(temporary)
        summary = _build_into(
            staging,
            repo=repo,
            snapshot=snapshot,
            stage04_dir=sources["Stage04"],
            b05_b06_dir=sources["B05/B06"],
            b07_dir=sources["B07"],
            remaining_dir=sources["B08/B09"],
            author_name=author_name,
            review_date=review_date,
            generator_path=Path(__file__).resolve(),
            provenance=provenance,
            test_mode=test_mode,
        )
        assert_canonical_snapshot(repo, snapshot)
        if output.exists():
            output.rmdir()
        shutil.copytree(staging, output)
    assert_canonical_snapshot(repo, snapshot)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--stage04-dir", required=True, type=Path)
    parser.add_argument("--b05-b06-dir", required=True, type=Path)
    parser.add_argument("--b07-dir", required=True, type=Path)
    parser.add_argument("--remaining-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--author-name", default=DEFAULT_AUTHOR)
    parser.add_argument("--review-date", default=DEFAULT_REVIEW_DATE)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        summary = build_package(
            repo_root=args.repo_root,
            stage04_dir=args.stage04_dir,
            b05_b06_dir=args.b05_b06_dir,
            b07_dir=args.b07_dir,
            remaining_dir=args.remaining_dir,
            output_dir=args.output_dir,
            author_name=args.author_name,
            review_date=args.review_date,
        )
    except FinalDecisionPackageError as exc:
        raise SystemExit(f"[fatal] {exc}") from exc
    print("FINAL_AUTHOR_DECISION_PACKAGE_GENERATED")
    print("FINAL_AUTHOR_COUNTERSIGN_REQUIRED")
    print("CANONICAL_CONTRACTS_UNCHANGED")
    print("FULL_BUILD_NOT_RUN")
    print("RELEASE_STILL_BLOCKED")
    print(f"scope_rows={summary['scope_row_count']}")
    print(
        "transitive_review_target_sha256="
        f"{summary['transitive_review_target_sha256']}"
    )
    print(f"output_dir={args.output_dir.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
