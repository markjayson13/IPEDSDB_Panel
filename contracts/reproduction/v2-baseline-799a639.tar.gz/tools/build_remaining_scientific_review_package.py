#!/usr/bin/env python3
"""Build a deterministic, non-approving B01/B07/B08/B09 review package.

The generator is deliberately review-only:

* B01 fills only direct URLs and byte sizes from already reviewed manifests,
  while independently rehashing the exact approved local payloads.
* B07 inventories observed PRCH flag/code evidence without assigning actions.
* B08 creates empty-valued benchmark decision slots; it never derives an
  "external" benchmark from the panel or legacy QA.
* B09 exposes variable-level donor candidates without selecting or approving a
  metadata donor.

Canonical contracts are inputs and are never written.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from decimal import Decimal, InvalidOperation
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
from typing import Iterable, Mapping, Sequence
from urllib.parse import unquote, urlparse
import zipfile


CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
GENERATOR_VERSION = "remaining-scientific-review-v1"
SOURCE_RELEASE_FIELDS = [
    "contract_id",
    "year",
    "academic_year_label",
    "release_type",
    "release_date_text",
    "access_url",
    "access_filename",
    "expected_access_sha256",
    "access_size_bytes",
    "documentation_url",
    "documentation_filename",
    "expected_documentation_sha256",
    "documentation_size_bytes",
    "lock_status",
    "source",
    "approved_at",
    "review_note",
]
CANONICAL_REVIEW_CONTRACTS = (
    "contracts/source_releases.csv",
    "contracts/prch_policy.csv",
    "contracts/external_benchmarks.csv",
    "contracts/metadata_backfill_approvals.csv",
)
B01_PROOF_FIELDS = [
    "year",
    "artifact_kind",
    "filename",
    "canonical_expected_sha256",
    "manifest_url",
    "manifest_size_bytes",
    "manifest_sha256",
    "actual_size_bytes",
    "actual_sha256",
    "url_basename_match",
    "manifest_size_match",
    "manifest_hash_match",
    "canonical_hash_match",
    "archive_container_valid",
    "integrity_status",
]
B07_EVIDENCE_FIELDS = [
    "year",
    "access_table_name",
    "flag",
    "observed_code",
    "observed_row_count",
    "metadata_frequency",
    "metadata_frequency_match",
    "value_label",
    "var_title",
    "source_varnumber",
    "source_csv_sha256",
    "valuesets_csv_sha256",
    "metadata_match_status",
]
B07_DECISION_FIELDS = [
    "decision_id",
    "flag",
    "observed_code",
    "value_label",
    "years_observed",
    "year_signature_count",
    "observed_row_count_total",
    "metadata_evidence_complete",
    "classification",
    "action",
    "target_column_scope",
    "reporting_standard",
    "form",
    "part",
    "decision_needed",
    "external_evidence_needed",
    "source_evidence",
    "decision_status",
]
B08_CONTRACT_FIELDS = [
    "benchmark_id",
    "contract_id",
    "artifact",
    "year",
    "metric",
    "variable",
    "filters",
    "component_family",
    "expected_value",
    "absolute_tolerance",
    "relative_tolerance",
    "tolerance_rationale",
    "official_source",
    "source_date_or_version",
    "source_evidence_path",
    "source_evidence_sha256",
    "review_status",
    "reviewer",
    "review_date",
    "definition",
    "notes",
]
B08_DECISION_FIELDS = B08_CONTRACT_FIELDS + [
    "decision_id",
    "official_variable",
    "official_metric",
    "tolerance_policy_id",
    "tolerance_policy_basis",
    "official_component_zip_sha256",
    "official_member",
    "official_member_sha256",
    "official_csv_parse_status",
    "official_filters",
    "official_row_count",
    "official_flags_zip",
    "official_flags_zip_sha256",
    "official_flags_member",
    "official_flags_member_sha256",
    "official_flags_csv_parse_status",
    "prch_flag",
    "allowed_flag_values",
    "access_diagnostic_table",
    "access_diagnostic_variable",
    "access_diagnostic_filters",
    "access_diagnostic_value",
    "difference_official_minus_access",
    "absolute_relative_difference",
    "within_proposed_tolerance",
    "decision_status",
    "decision_needed",
]
B08_PRCH_JOIN_FIELDS = [
    "benchmark_id",
    "year",
    "component_family",
    "prch_flag",
    "allowed_flag_values",
    "component_zip",
    "component_zip_sha256",
    "component_member",
    "component_member_sha256",
    "flags_zip",
    "flags_zip_sha256",
    "flags_member",
    "flags_member_sha256",
    "component_rows_total",
    "component_rows_after_source_filter",
    "component_distinct_unitid",
    "flags_rows_total",
    "flags_distinct_unitid",
    "matched_component_rows",
    "unmatched_component_unitid_count",
    "retained_component_rows",
    "excluded_component_rows",
    "expected_value",
]
B08_AUDIT_FIELDS = [
    "evidence_kind",
    "relative_path",
    "official_url",
    "member_name",
    "csv_parse_status",
    "byte_size",
    "sha256",
    "member_sha256",
    "row_count",
    "independence_status",
    "release_usable",
    "reason",
]
B09_EVIDENCE_FIELDS = [
    "target_year",
    "source_file",
    "access_table_name",
    "target_csv_sha256",
    "target_row_count",
    "target_varname",
    "target_column_present",
    "target_table_title",
    "target_table_description",
    "target_table_metadata_sha256",
    "same_year_sibling_table",
    "same_year_sibling_varnumber",
    "same_year_sibling_semantics_match",
    "donor_year",
    "donor_access_table_name",
    "donor_table_csv_sha256",
    "donor_table_row_count",
    "donor_table_has_observed_rows",
    "donor_source_varnumber",
    "variable_id",
    "donor_var_title",
    "donor_long_description",
    "donor_data_type",
    "donor_format",
    "donor_field_width",
    "donor_metadata_sha256",
    "cross_donor_semantics_match",
    "compatibility_status",
]
B09_DECISION_FIELDS = [
    "decision_id",
    "target_year",
    "source_file",
    "access_table_name",
    "target_varname",
    "candidate_variable_id",
    "donor_options",
    "cross_donor_semantics_match",
    "same_year_sibling_semantics_match",
    "recommended_donor_year",
    "recommendation_status",
    "recommendation_basis",
    "decision_needed",
    "exact_missing_evidence",
    "source_evidence",
    "decision_status",
]
B09_CONDITIONAL_CANDIDATE_FIELDS = [
    "approval_id",
    "contract_id",
    "target_year",
    "source_file",
    "access_table_name",
    "donor_year",
    "variable_id",
    "target_varname",
    "expected_data_type",
    "expected_title",
    "fields_backfilled",
    "compatibility_status",
    "compatibility_evidence",
    "approval_status",
    "reviewer",
    "review_date",
    "justification",
]


class ReviewEvidenceError(RuntimeError):
    """Source evidence is absent, ambiguous, malformed, or inconsistent."""


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_json(value: object) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    if not path.is_file():
        raise ReviewEvidenceError(f"missing CSV evidence: {path}")
    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle, strict=True)
            fields = list(reader.fieldnames or [])
            if not fields or len(fields) != len(set(fields)):
                raise ReviewEvidenceError(f"CSV has an empty or duplicate header: {path}")
            rows = [
                {str(key): str(value or "").strip() for key, value in row.items()}
                for row in reader
            ]
    except (UnicodeError, csv.Error) as exc:
        raise ReviewEvidenceError(f"cannot parse CSV evidence {path}: {exc}") from exc
    return fields, rows


def write_csv(
    path: Path,
    fields: Sequence[str],
    rows: Iterable[Mapping[str, object]],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=list(fields),
            extrasaction="ignore",
            lineterminator="\n",
        )
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def normalized_row(row: Mapping[str, object]) -> dict[str, str]:
    return {str(key).casefold(): str(value or "").strip() for key, value in row.items()}


def require_single(rows: Sequence[dict[str, str]], *, label: str) -> dict[str, str]:
    if len(rows) != 1:
        raise ReviewEvidenceError(f"expected exactly one {label}, found {len(rows)}")
    return rows[0]


def require_casefold_file(directory: Path, stem: str) -> Path:
    matches = sorted(
        path
        for path in directory.iterdir()
        if path.is_file() and path.stem.casefold() == stem.casefold()
    )
    if len(matches) != 1:
        raise ReviewEvidenceError(
            f"expected exactly one {stem} CSV in {directory}, found {len(matches)}"
        )
    return matches[0]


def validate_zip_container(path: Path) -> bool:
    try:
        with zipfile.ZipFile(path, "r") as archive:
            return bool(archive.infolist()) and archive.testzip() is None
    except (OSError, zipfile.BadZipFile):
        return False


def url_basename(url: str) -> str:
    return Path(unquote(urlparse(url).path)).name


def numeric_code_key(value: str) -> tuple[int, float | str]:
    try:
        return (0, float(value))
    except ValueError:
        return (1, value)


def slug(value: str) -> str:
    text = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-").upper()
    return text or "BLANK"


def compress_years(years: Sequence[int]) -> str:
    ordered = sorted(set(years))
    if not ordered:
        return ""
    spans: list[str] = []
    start = previous = ordered[0]
    for year in ordered[1:]:
        if year == previous + 1:
            previous = year
            continue
        spans.append(str(start) if start == previous else f"{start}:{previous}")
        start = previous = year
    spans.append(str(start) if start == previous else f"{start}:{previous}")
    return "|".join(spans)


def build_b01(
    repo_root: Path,
    legacy_root: Path,
) -> tuple[list[dict[str, str]], list[dict[str, object]], dict[str, object], list[int]]:
    source_path = repo_root / "contracts" / "source_releases.csv"
    fields, canonical_rows = read_csv(source_path)
    if fields != SOURCE_RELEASE_FIELDS:
        raise ReviewEvidenceError("canonical source_releases.csv header is not the reviewed v2 schema")
    if not canonical_rows:
        raise ReviewEvidenceError("canonical source_releases.csv has no reviewed rows")
    years: list[int] = []
    candidates: list[dict[str, str]] = []
    proof: list[dict[str, object]] = []
    changed_fields: set[str] = set()
    seen_years: set[int] = set()

    for canonical in sorted(canonical_rows, key=lambda row: int(row["year"])):
        try:
            year = int(canonical["year"])
        except ValueError as exc:
            raise ReviewEvidenceError(f"invalid source-lock year: {canonical['year']!r}") from exc
        if year in seen_years:
            raise ReviewEvidenceError(f"duplicate source-lock year: {year}")
        seen_years.add(year)
        years.append(year)
        if (
            canonical["contract_id"] != CONTRACT_ID
            or canonical["lock_status"].casefold() != "approved"
            or not canonical["source"]
            or not canonical["approved_at"]
            or not canonical["review_note"]
        ):
            raise ReviewEvidenceError(f"B01 approval provenance is incomplete for year {year}")

        year_dir = legacy_root / "Raw_Access_Databases" / str(year)
        _, manifest_rows = read_csv(year_dir / "manifest.csv")
        manifest = normalized_row(require_single(manifest_rows, label=f"{year} manifest row"))
        identity_pairs = {
            "year": str(year),
            "academic_year_label": canonical["academic_year_label"],
            "release_type": canonical["release_type"],
            "release_date_text": canonical["release_date_text"],
            "access_filename": canonical["access_filename"],
            "doc_filename": canonical["documentation_filename"],
        }
        for manifest_field, expected in identity_pairs.items():
            if manifest.get(manifest_field, "") != expected:
                raise ReviewEvidenceError(
                    f"year {year} manifest {manifest_field} differs from approved B01 identity"
                )

        candidate = dict(canonical)
        artifact_specs = (
            (
                "access",
                "access_filename",
                "expected_access_sha256",
                "access_url",
                "access_size_bytes",
                "access_url",
                "access_zip_filesize_bytes",
                "access_zip_sha256",
            ),
            (
                "documentation",
                "documentation_filename",
                "expected_documentation_sha256",
                "documentation_url",
                "documentation_size_bytes",
                "doc_url",
                "doc_filesize_bytes",
                "doc_sha256",
            ),
        )
        for (
            kind,
            canonical_filename_field,
            canonical_hash_field,
            candidate_url_field,
            candidate_size_field,
            manifest_url_field,
            manifest_size_field,
            manifest_hash_field,
        ) in artifact_specs:
            filename = canonical[canonical_filename_field]
            path = year_dir / "downloads" / filename
            if not path.is_file():
                raise ReviewEvidenceError(f"missing approved {kind} payload for year {year}: {filename}")
            actual_size = path.stat().st_size
            actual_hash = sha256_file(path)
            manifest_url = manifest.get(manifest_url_field, "")
            manifest_size = manifest.get(manifest_size_field, "")
            manifest_hash = manifest.get(manifest_hash_field, "").casefold()
            canonical_hash = canonical[canonical_hash_field].casefold()
            checks = {
                "url_basename_match": url_basename(manifest_url) == filename,
                "manifest_size_match": manifest_size == str(actual_size),
                "manifest_hash_match": manifest_hash == actual_hash,
                "canonical_hash_match": canonical_hash == actual_hash,
                "archive_container_valid": validate_zip_container(path),
            }
            if (
                urlparse(manifest_url).scheme.casefold() != "https"
                or not all(checks.values())
            ):
                failed = ",".join(key for key, value in checks.items() if not value)
                raise ReviewEvidenceError(
                    f"year {year} {kind} URL/size/hash/container evidence failed: {failed or 'url'}"
                )
            existing_size = canonical[candidate_size_field]
            if existing_size and existing_size != str(actual_size):
                raise ReviewEvidenceError(
                    f"year {year} canonical {candidate_size_field} conflicts with approved bytes"
                )
            candidate[candidate_url_field] = manifest_url
            candidate[candidate_size_field] = str(actual_size)
            if canonical[candidate_url_field] != candidate[candidate_url_field]:
                changed_fields.add(candidate_url_field)
            if canonical[candidate_size_field] != candidate[candidate_size_field]:
                changed_fields.add(candidate_size_field)
            proof.append(
                {
                    "year": year,
                    "artifact_kind": kind,
                    "filename": filename,
                    "canonical_expected_sha256": canonical_hash,
                    "manifest_url": manifest_url,
                    "manifest_size_bytes": manifest_size,
                    "manifest_sha256": manifest_hash,
                    "actual_size_bytes": actual_size,
                    "actual_sha256": actual_hash,
                    **{key: str(value).lower() for key, value in checks.items()},
                    "integrity_status": "exact",
                }
            )
        candidates.append(candidate)

    allowed_changes = {
        "access_url",
        "access_size_bytes",
        "documentation_url",
        "documentation_size_bytes",
    }
    if not changed_fields <= allowed_changes:
        raise ReviewEvidenceError(
            "B01 candidate exceeds the mechanical URL/size completion scope"
        )
    classification = (
        "mechanical_completion_under_existing_b01_approval"
        if changed_fields
        else "already_complete_exactly"
    )
    summary = {
        "approved_release_rows": len(candidates),
        "artifact_proof_rows": len(proof),
        "exact_artifact_matches": sum(row["integrity_status"] == "exact" for row in proof),
        "bytes_rehashed": sum(int(row["actual_size_bytes"]) for row in proof),
        "changed_fields": sorted(changed_fields),
        "expected_hashes_changed": False,
        "release_identities_changed": False,
        "mechanical_completion_ready": len(proof) == 2 * len(candidates),
        "classification": classification,
    }
    return candidates, proof, summary, years


def load_valueset_map(path: Path, flags_table: str) -> dict[tuple[str, str], dict[str, str]]:
    _, rows = read_csv(path)
    output: dict[tuple[str, str], dict[str, str]] = {}
    for raw in rows:
        row = normalized_row(raw)
        flag = row.get("varname", "").upper()
        if row.get("tablename", "").casefold() != flags_table.casefold() or not flag.startswith("PRCH"):
            continue
        key = (flag, row.get("codevalue", ""))
        if key in output and output[key] != row:
            raise ReviewEvidenceError(f"conflicting value-set metadata for {flags_table} {key}")
        output[key] = row
    return output


def discover_prch_source_tables(
    tables_dir: Path,
    *,
    year: int,
    valuesets_path: Path,
) -> list[tuple[Path, list[str], list[dict[str, str]], list[str]]]:
    """Return every exact annual data table that carries a PRCH field.

    Older IPEDS releases did not place every parent/child indicator in the
    consolidated FLAGS table.  Approval-grade evidence therefore follows the
    observed CSV schema and exact ValueSets table identity, while requiring a
    single source table for each year/flag identity.
    """

    _, metadata_rows = read_csv(valuesets_path)
    table_flags: dict[str, set[str]] = defaultdict(set)
    table_names: dict[str, str] = {}
    owners: dict[str, str] = {}
    for raw in metadata_rows:
        row = normalized_row(raw)
        flag = row.get("varname", "").upper()
        table_name = row.get("tablename", "").strip()
        if not flag.startswith("PRCH") or not table_name:
            continue
        table_key = table_name.casefold()
        prior = owners.get(flag)
        if prior is not None and prior.casefold() != table_key:
            raise ReviewEvidenceError(
                f"{year}:{flag} occurs in multiple source tables: "
                f"{prior}|{table_name}"
            )
        owners[flag] = table_name
        table_names.setdefault(table_key, table_name)
        table_flags[table_key].add(flag)
    if not table_flags:
        raise ReviewEvidenceError(
            f"no exact PRCH ValueSets identities found in {valuesets_path}"
        )

    discovered: list[
        tuple[Path, list[str], list[dict[str, str]], list[str]]
    ] = []
    for table_key in sorted(table_flags):
        table_name = table_names[table_key]
        path = require_casefold_file(tables_dir, table_name)
        fields, rows = read_csv(path)
        normalized_fields = {field.upper() for field in fields}
        flags = sorted(table_flags[table_key])
        missing = sorted(set(flags) - normalized_fields)
        if missing:
            raise ReviewEvidenceError(
                f"{year}:{table_name} lacks metadata-declared PRCH fields: "
                + "|".join(missing)
            )
        if "UNITID" not in normalized_fields:
            raise ReviewEvidenceError(
                f"{year}:{table_name} carries PRCH fields without UNITID"
            )
        discovered.append((path, fields, rows, flags))
    return discovered


def build_b07(
    legacy_root: Path,
    years: Sequence[int],
) -> tuple[list[dict[str, object]], list[dict[str, object]], dict[str, object]]:
    evidence: list[dict[str, object]] = []
    for year in years:
        tables_dir = legacy_root / "Raw_Access_Databases" / str(year) / "tables_csv"
        valuesets_path = require_casefold_file(tables_dir, f"valueSets{str(year)[-2:]}")
        for source_path, _, rows, flags in discover_prch_source_tables(
            tables_dir,
            year=year,
            valuesets_path=valuesets_path,
        ):
            counts = {flag: Counter() for flag in flags}
            for row in rows:
                normalized = {key.upper(): value for key, value in row.items()}
                for flag in flags:
                    token = normalized.get(flag, "").strip()
                    if token:
                        counts[flag][token] += 1
            metadata = load_valueset_map(valuesets_path, source_path.stem)
            for flag in flags:
                for code, observed_count in sorted(
                    counts[flag].items(), key=lambda item: numeric_code_key(item[0])
                ):
                    meta = metadata.get((flag, code))
                    metadata_frequency = (meta or {}).get("frequency", "")
                    frequency_match = (
                        bool(metadata_frequency)
                        and int(float(metadata_frequency)) == int(observed_count)
                    )
                    evidence.append(
                        {
                            "year": year,
                            "access_table_name": source_path.stem,
                            "flag": flag,
                            "observed_code": code,
                            "observed_row_count": observed_count,
                            "metadata_frequency": metadata_frequency,
                            "metadata_frequency_match": str(frequency_match).lower(),
                            "value_label": (meta or {}).get("valuelabel", ""),
                            "var_title": (meta or {}).get("vartitle", ""),
                            "source_varnumber": (meta or {}).get("varnumber", ""),
                            "source_csv_sha256": sha256_file(source_path),
                            "valuesets_csv_sha256": sha256_file(valuesets_path),
                            "metadata_match_status": "exact" if meta else "missing",
                        }
                    )

    grouped: dict[tuple[str, str, str], list[dict[str, object]]] = defaultdict(list)
    for row in evidence:
        grouped[
            (
                str(row["flag"]),
                str(row["observed_code"]),
                str(row["value_label"]),
            )
        ].append(row)
    decisions: list[dict[str, object]] = []
    for index, (key, rows) in enumerate(
        sorted(
            grouped.items(),
            key=lambda item: (
                item[0][0],
                numeric_code_key(item[0][1]),
                item[0][2],
            ),
        ),
        start=1,
    ):
        flag, code, label = key
        observed_years = [int(row["year"]) for row in rows]
        finance = flag in {"PRCH_F", "PRCHTP_F"}
        external_need = (
            "Annual NCES Finance forms/instructions; accounting standard; exact form/part "
            "and target-column lineage; dimensioned-lane applicability."
            if finance
            else
            "Annual NCES component forms/instructions; exact target-column lineage; "
            "dimensioned-lane applicability."
        )
        decisions.append(
            {
                "decision_id": f"B07-{index:03d}-{slug(flag)}-{slug(code)}",
                "flag": flag,
                "observed_code": code,
                "value_label": label,
                "years_observed": compress_years(observed_years),
                "year_signature_count": len(rows),
                "observed_row_count_total": sum(int(row["observed_row_count"]) for row in rows),
                "metadata_evidence_complete": str(
                    all(row["metadata_match_status"] == "exact" for row in rows)
                ).lower(),
                "classification": "",
                "action": "",
                "target_column_scope": "",
                "reporting_standard": "",
                "form": "",
                "part": "",
                "decision_needed": (
                    "Approve an exact year/code classification and action, plus predicate and "
                    "target-column scope; retain unresolved if the external form evidence is incomplete."
                ),
                "external_evidence_needed": external_need,
                "source_evidence": (
                    "B07_PRCH_OBSERVED_CODE_EVIDENCE.csv; exact archived FLAGS and "
                    "valueSets SHA-256 identities."
                ),
                "decision_status": "request_more_evidence",
            }
        )
    summary = {
        "years": len(years),
        "observed_signature_count": len(evidence),
        "decision_signature_count": len(decisions),
        "distinct_flags": len({row["flag"] for row in evidence}),
        "distinct_flag_codes": len(
            {(row["flag"], row["observed_code"]) for row in evidence}
        ),
        "missing_code_metadata": sum(
            row["metadata_match_status"] != "exact" for row in evidence
        ),
        "frequency_mismatches": sum(
            row["metadata_frequency_match"] != "true" for row in evidence
        ),
        "contract_status": "B07_BLOCKED_AUTHOR_AND_EXTERNAL_REVIEW",
    }
    return evidence, decisions, summary


BENCHMARK_ARTIFACT = "Panels/v2/panel_clean_prch_2004_2023.parquet"
OFFICIAL_BENCHMARK_YEARS = (2015, 2020, 2022)
OFFICIAL_BENCHMARK_DOWNLOAD_DATE = "2026-07-24"
OFFICIAL_BENCHMARK_BASE_URL = "https://nces.ed.gov/ipeds/datacenter/data"
B08_TOLERANCE_POLICY_ID = "B08-NCES-CROSS-RELEASE-CANDIDATE-V1"
BENCHMARK_COMPONENTS = (
    {
        "component_family": "institution_counts",
        "panel_metric": "distinct_unitid",
        "panel_variable": "UNITID",
        "official_table_template": "HD{year}",
        "official_variable": "UNITID",
        "official_metric": "distinct_unitid",
        "official_filter_column": "",
        "official_filter_value": "",
        "prch_flag": "",
        "access_table_template": "HD{year}",
        "access_variable": "UNITID",
        "access_metric": "distinct_unitid",
        "required_evidence": (
            "Official NCES/IPEDS HD Complete Data File and exact distinct-UNITID universe."
        ),
    },
    {
        "component_family": "enrollment",
        "panel_metric": "sum",
        "panel_variable": "ENRTOT",
        "official_table_template": "EF{year}A",
        "official_variable": "EFTOTLT",
        "official_metric": "sum",
        "official_filter_column": "EFALEVEL",
        "official_filter_value": "1",
        "prch_flag": "PRCH_EF",
        "access_table_template": "DRVEF{year}",
        "access_variable": "ENRTOT",
        "access_metric": "sum",
        "required_evidence": (
            "Official NCES/IPEDS EF A Complete Data File; sum EFTOTLT for EFALEVEL=1."
        ),
    },
    {
        "component_family": "completions",
        "panel_metric": "sum",
        "panel_variable": "CSTOTLT",
        "official_table_template": "C{year}_B",
        "official_variable": "CSTOTLT",
        "official_metric": "sum",
        "official_filter_column": "",
        "official_filter_value": "",
        "prch_flag": "PRCH_C",
        "access_table_template": "C{year}_B",
        "access_variable": "CSTOTLT",
        "access_metric": "sum",
        "required_evidence": (
            "Official NCES/IPEDS Completions B Complete Data File; sum CSTOTLT."
        ),
    },
    {
        "component_family": "staffing",
        "panel_metric": "sum",
        "panel_variable": "SANIN01",
        "official_table_template": "SAL{year}_NIS",
        "official_variable": "SANIN01",
        "official_metric": "sum",
        "official_filter_column": "",
        "official_filter_value": "",
        "prch_flag": "PRCH_HR",
        "access_table_template": "SAL{year}_NIS",
        "access_variable": "SANIN01",
        "access_metric": "sum",
        "required_evidence": (
            "Official NCES/IPEDS Salaries NIS Complete Data File; sum SANIN01."
        ),
    },
    {
        "component_family": "tuition_price",
        "panel_metric": "sum",
        "panel_variable": "TUITION2",
        "official_table_template": "IC{year}_AY",
        "official_variable": "TUITION2",
        "official_metric": "sum",
        "official_filter_column": "",
        "official_filter_value": "",
        "prch_flag": "",
        "access_table_template": "IC{year}_AY",
        "access_variable": "TUITION2",
        "access_metric": "sum",
        "required_evidence": (
            "Official NCES/IPEDS Institutional Characteristics AY Complete Data File; sum TUITION2."
        ),
    },
    {
        "component_family": "finance",
        "panel_metric": "sum",
        "panel_variable": "F1A01",
        "official_table_template": "F{finance_years}_F1A",
        "official_variable": "F1A01",
        "official_metric": "sum",
        "official_filter_column": "",
        "official_filter_value": "",
        "prch_flag": "PRCH_F",
        "access_table_template": "F{finance_years}_F1A",
        "access_variable": "F1A01",
        "access_metric": "sum",
        "required_evidence": (
            "Official NCES/IPEDS Finance F1A Complete Data File; sum F1A01 for GASB reporters."
        ),
    },
)


def b08_candidate_tolerance_policy(metric: str) -> dict[str, object]:
    """Return the author-review candidate tolerance without consulting diagnostics."""
    if metric == "distinct_unitid":
        absolute = Decimal("10")
        relative = Decimal("0.0025")
    elif metric == "sum":
        absolute = Decimal("0")
        relative = Decimal("0.01")
    else:
        raise ReviewEvidenceError(
            f"B08 tolerance policy does not define metric {metric!r}"
        )
    basis = {
        "absolute_tolerance": decimal_text(absolute),
        "calibration_source": "author_review_candidate_policy",
        "diagnostics_used_for_calibration": False,
        "metric_class": metric,
        "relative_tolerance": decimal_text(relative),
        "scope": "NCES cross-release revisions",
    }
    return {
        "policy_id": B08_TOLERANCE_POLICY_ID,
        "absolute": absolute,
        "relative": relative,
        "basis": basis,
        "rationale": (
            "This author-review candidate policy for NCES cross-release revisions "
            f"assigns absolute={decimal_text(absolute)} and "
            f"relative={decimal_text(relative)} for metric class {metric}; it was "
            "not estimated from Access diagnostic deltas. Access diagnostics are "
            "post-hoc comparison context only, and author approval is still required."
        ),
    }


def benchmark_target_years(years: Sequence[int]) -> list[int]:
    ordered = sorted(set(years))
    if len(ordered) < 3:
        raise ReviewEvidenceError("B08 requires at least three source years")
    return [ordered[0], ordered[(len(ordered) - 1) // 2], ordered[-1]]


def benchmark_table_name(template: str, year: int) -> str:
    finance_years = f"{str(year - 1)[-2:]}{str(year)[-2:]}"
    return template.format(year=year, finance_years=finance_years)


def decode_csv_payload(payload: bytes, *, label: str) -> str:
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return payload.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise ReviewEvidenceError(f"cannot decode official CSV evidence: {label}")


def parse_csv_text(
    text: str,
    *,
    label: str,
    strict: bool,
) -> tuple[list[str], list[dict[str, str]], list[str]]:
    reader = csv.reader(io.StringIO(text, newline=""), strict=strict)
    try:
        header = next(reader)
    except StopIteration as exc:
        raise ReviewEvidenceError(f"official CSV is empty: {label}") from exc
    raw_fields = [str(value or "").strip() for value in header]
    if not raw_fields or any(not field for field in raw_fields):
        raise ReviewEvidenceError(f"official CSV has an invalid header: {label}")
    seen: Counter[str] = Counter()
    duplicate_names: list[str] = []
    fields: list[str] = []
    for raw_field in raw_fields:
        key = raw_field.casefold()
        seen[key] += 1
        if seen[key] == 1:
            field = raw_field
        else:
            field = f"{raw_field}__DUPLICATE_{seen[key]}"
            if raw_field not in duplicate_names:
                duplicate_names.append(raw_field)
        if field in fields:
            raise ReviewEvidenceError(
                f"official CSV duplicate-header disambiguation collided: {label}:{field}"
            )
        fields.append(field)
    rows: list[dict[str, str]] = []
    for row in reader:
        if len(row) != len(raw_fields):
            raise ReviewEvidenceError(
                f"official CSV row {reader.line_num} column count {len(row)} "
                f"does not match header count {len(raw_fields)}: {label}"
            )
        rows.append(
            {
                field: str(value or "").strip()
                for field, value in zip(fields, row, strict=True)
            }
        )
    return fields, rows, duplicate_names


def read_csv_payload(
    payload: bytes,
    *,
    label: str,
) -> tuple[list[str], list[dict[str, str]], str]:
    text = decode_csv_payload(payload, label=label)
    try:
        fields, rows, duplicate_names = parse_csv_text(text, label=label, strict=True)
        status = "strict"
    except csv.Error as exc:
        try:
            fields, rows, duplicate_names = parse_csv_text(
                text,
                label=label,
                strict=False,
            )
        except csv.Error as fallback_exc:
            raise ReviewEvidenceError(
                f"cannot parse official CSV evidence {label}: "
                f"strict={exc}; permissive={fallback_exc}"
            ) from fallback_exc
        status = "permissive_rectangular_after_strict_quote_error"
    if duplicate_names:
        status += ";duplicate_header_disambiguated=" + "|".join(duplicate_names)
    return fields, rows, status


def read_official_zip_csv(
    path: Path,
    *,
    expected_member: str,
) -> tuple[list[str], list[dict[str, str]], str, str, str]:
    if not path.is_file():
        raise ReviewEvidenceError(f"missing official benchmark source: {path.name}")
    try:
        with zipfile.ZipFile(path, "r") as archive:
            corrupt_member = archive.testzip()
            if corrupt_member is not None:
                raise ReviewEvidenceError(
                    f"official benchmark ZIP has a corrupt member: {path.name}:{corrupt_member}"
                )
            matches = [
                info
                for info in archive.infolist()
                if not info.is_dir()
                and Path(info.filename).name.casefold() == expected_member.casefold()
            ]
            if len(matches) != 1:
                raise ReviewEvidenceError(
                    f"expected exactly one {expected_member} in {path.name}, found {len(matches)}"
                )
            member = matches[0]
            payload = archive.read(member)
    except (OSError, zipfile.BadZipFile) as exc:
        raise ReviewEvidenceError(f"cannot read official benchmark ZIP {path.name}: {exc}") from exc
    fields, rows, parse_status = read_csv_payload(
        payload,
        label=f"{path.name}:{member.filename}",
    )
    return (
        fields,
        rows,
        member.filename,
        hashlib.sha256(payload).hexdigest(),
        parse_status,
    )


def casefold_column(fields: Sequence[str], expected: str, *, label: str) -> str:
    matches = [
        field
        for field in fields
        if re.sub(r"__DUPLICATE_[0-9]+$", "", field).casefold()
        == expected.casefold()
    ]
    if len(matches) != 1:
        raise ReviewEvidenceError(
            f"expected exactly one {expected} column in {label}, found {len(matches)}"
        )
    return matches[0]


def decimal_value(token: object, *, label: str) -> Decimal:
    text = str(token or "").strip().replace(",", "")
    if not text:
        raise ReviewEvidenceError(f"blank numeric value in {label}")
    try:
        value = Decimal(text)
    except InvalidOperation as exc:
        raise ReviewEvidenceError(f"invalid numeric value {text!r} in {label}") from exc
    if not value.is_finite():
        raise ReviewEvidenceError(f"nonfinite numeric value {text!r} in {label}")
    return value


def decimal_text(value: Decimal) -> str:
    if value == value.to_integral_value():
        return str(int(value))
    return format(value.normalize(), "f")


def filter_source_rows(
    rows: Sequence[dict[str, str]],
    fields: Sequence[str],
    *,
    filter_column: str,
    filter_value: str,
    label: str,
) -> list[dict[str, str]]:
    if not filter_column:
        return list(rows)
    actual = casefold_column(fields, filter_column, label=label)
    expected_decimal = decimal_value(filter_value, label=f"{label} filter")
    selected: list[dict[str, str]] = []
    for row in rows:
        token = row.get(actual, "")
        if not token:
            continue
        try:
            matches = decimal_value(token, label=f"{label} {actual}") == expected_decimal
        except ReviewEvidenceError:
            matches = token.casefold() == filter_value.casefold()
        if matches:
            selected.append(row)
    if not selected:
        raise ReviewEvidenceError(f"official benchmark filter selected zero rows: {label}")
    return selected


def aggregate_source_rows(
    rows: Sequence[dict[str, str]],
    fields: Sequence[str],
    *,
    metric: str,
    variable: str,
    label: str,
) -> Decimal:
    actual = casefold_column(fields, variable, label=label)
    if metric == "distinct_unitid":
        values = {row.get(actual, "").strip() for row in rows if row.get(actual, "").strip()}
        if not values:
            raise ReviewEvidenceError(f"official benchmark has no nonblank {variable}: {label}")
        return Decimal(len(values))
    if metric != "sum":
        raise ReviewEvidenceError(f"unsupported review benchmark metric {metric!r}")
    total = Decimal(0)
    nonempty = 0
    for row_number, row in enumerate(rows, start=2):
        token = row.get(actual, "").strip()
        if token in {"", "."}:
            continue
        total += decimal_value(token, label=f"{label} row {row_number} {actual}")
        nonempty += 1
    if nonempty == 0:
        raise ReviewEvidenceError(f"official benchmark has no numeric {variable}: {label}")
    return total


def unique_unitid_index(
    rows: Sequence[dict[str, str]],
    fields: Sequence[str],
    *,
    label: str,
) -> tuple[str, dict[str, dict[str, str]]]:
    unitid_column = casefold_column(fields, "UNITID", label=label)
    index: dict[str, dict[str, str]] = {}
    duplicates: set[str] = set()
    for row_number, row in enumerate(rows, start=2):
        unitid = row.get(unitid_column, "").strip()
        if not unitid:
            raise ReviewEvidenceError(f"blank UNITID in {label} row {row_number}")
        if unitid in index:
            duplicates.add(unitid)
        else:
            index[unitid] = row
    if duplicates:
        sample = "|".join(sorted(duplicates)[:10])
        raise ReviewEvidenceError(
            f"duplicate UNITID values in {label}: count={len(duplicates)} sample={sample}"
        )
    return unitid_column, index


def build_placeholder_b08(
    years: Sequence[int],
) -> tuple[list[dict[str, object]], dict[str, object]]:
    targets = benchmark_target_years(years)
    decisions: list[dict[str, object]] = []
    for family_index, component in enumerate(BENCHMARK_COMPONENTS, start=1):
        for year_index, year in enumerate(targets, start=1):
            decision_id = f"B08-{family_index:02d}-{year_index:02d}"
            decisions.append(
                {
                    "benchmark_id": decision_id,
                    "contract_id": CONTRACT_ID,
                    "artifact": BENCHMARK_ARTIFACT,
                    "year": year,
                    "metric": component["panel_metric"],
                    "variable": component["panel_variable"],
                    "filters": "{}",
                    "component_family": component["component_family"],
                    "expected_value": "",
                    "absolute_tolerance": "",
                    "relative_tolerance": "",
                    "tolerance_rationale": "",
                    "official_source": "",
                    "source_date_or_version": "",
                    "source_evidence_path": "",
                    "source_evidence_sha256": "",
                    "review_status": "pending",
                    "reviewer": "",
                    "review_date": "",
                    "definition": "",
                    "notes": (
                        f"Required: {component['required_evidence']} The legacy panel, candidate "
                        "v2 panel, and pipeline QA totals are prohibited as expected values."
                    ),
                    "decision_id": decision_id,
                    "decision_status": "request_more_evidence",
                    "decision_needed": (
                        "Supply and independently review an official source file, exact derivation, "
                        "expected value, and justified tolerances."
                    ),
                }
            )
    summary = {
        "benchmark_slot_count": len(decisions),
        "target_years": targets,
        "component_families": [
            component["component_family"] for component in BENCHMARK_COMPONENTS
        ],
        "official_values_derived": 0,
        "official_source_files": 0,
        "access_diagnostics_within_proposed_tolerance": 0,
        "independent_reviewed_benchmarks": 0,
        "contract_status": "B08_BLOCKED_EXTERNAL_EVIDENCE",
    }
    return decisions, summary


def validate_b08_source_evidence_path(value: str) -> str:
    normalized = str(value).strip().replace("\\", "/")
    path = PurePosixPath(normalized)
    if (
        not normalized
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
        or path.parts[:2] != ("Artifacts", "review_v2")
        or path.name != "B08_OFFICIAL_BENCHMARK_EVIDENCE_RECEIPT.json"
    ):
        raise ReviewEvidenceError(
            "B08 source_evidence_path must be a stable repo-relative "
            "Artifacts/review_v2 receipt path"
        )
    return path.as_posix()


def stable_b08_receipt_path(repo_root: Path, out_dir: Path) -> str:
    repo = repo_root.expanduser().resolve()
    output = out_dir.expanduser().resolve()
    try:
        relative_output = output.relative_to(repo)
    except ValueError as exc:
        raise ReviewEvidenceError(
            "official B08 output directory must be inside the repository"
        ) from exc
    return validate_b08_source_evidence_path(
        (
            relative_output
            / "B08_OFFICIAL_BENCHMARK_EVIDENCE_RECEIPT.json"
        ).as_posix()
    )


def build_official_b08(
    legacy_root: Path,
    years: Sequence[int],
    official_root: Path,
    *,
    source_evidence_path: str,
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    dict[str, object],
    list[Path],
    list[dict[str, object]],
]:
    source_years = set(int(year) for year in years)
    missing_years = sorted(set(OFFICIAL_BENCHMARK_YEARS) - source_years)
    if missing_years:
        raise ReviewEvidenceError(
            "official B08 benchmark years fall outside the source contract: "
            + ",".join(map(str, missing_years))
        )
    official_root = official_root.expanduser().resolve()
    if not official_root.is_dir():
        raise ReviewEvidenceError(f"official benchmark source directory is missing: {official_root}")

    decisions: list[dict[str, object]] = []
    audit: list[dict[str, object]] = []
    source_files: list[Path] = []
    join_proof: list[dict[str, object]] = []
    flags_by_year: dict[int, dict[str, object]] = {}
    for year in OFFICIAL_BENCHMARK_YEARS:
        flags_zip_name = f"FLAGS{year}.zip"
        flags_zip_path = official_root / flags_zip_name
        (
            flags_fields,
            flags_rows,
            flags_member,
            flags_member_hash,
            flags_parse_status,
        ) = read_official_zip_csv(
            flags_zip_path,
            expected_member=f"flags{year}.csv",
        )
        flags_unitid_column, flags_index = unique_unitid_index(
            flags_rows,
            flags_fields,
            label=f"{flags_zip_name}:{flags_member}",
        )
        flags_zip_hash = sha256_file(flags_zip_path)
        flags_by_year[year] = {
            "fields": flags_fields,
            "rows": flags_rows,
            "member": flags_member,
            "member_hash": flags_member_hash,
            "parse_status": flags_parse_status,
            "unitid_column": flags_unitid_column,
            "index": flags_index,
            "zip_name": flags_zip_name,
            "zip_path": flags_zip_path,
            "zip_hash": flags_zip_hash,
        }
        audit.append(
            {
                "evidence_kind": "official_source_candidate",
                "relative_path": f"official_sources/{flags_zip_name}",
                "official_url": f"{OFFICIAL_BENCHMARK_BASE_URL}/{flags_zip_name}",
                "member_name": flags_member,
                "csv_parse_status": flags_parse_status,
                "byte_size": flags_zip_path.stat().st_size,
                "sha256": flags_zip_hash,
                "member_sha256": flags_member_hash,
                "row_count": len(flags_rows),
                "independence_status": "official_nces_source_pending_review",
                "release_usable": "false",
                "reason": (
                    "Official FLAGS evidence scopes PRCH-cleaned benchmark rows; exact ZIP/member "
                    "hashes and unique UNITID identity are proven, but author review remains required."
                ),
            }
        )
        source_files.append(flags_zip_path)

    for family_index, component in enumerate(BENCHMARK_COMPONENTS, start=1):
        for year_index, year in enumerate(OFFICIAL_BENCHMARK_YEARS, start=1):
            official_table = benchmark_table_name(
                str(component["official_table_template"]),
                year,
            )
            access_table = benchmark_table_name(
                str(component["access_table_template"]),
                year,
            )
            zip_name = f"{official_table}.zip"
            zip_path = official_root / zip_name
            member_expected = f"{official_table.lower()}.csv"
            fields, rows, member_name, member_hash, csv_parse_status = read_official_zip_csv(
                zip_path,
                expected_member=member_expected,
            )
            official_filter_column = str(component["official_filter_column"])
            official_filter_value = str(component["official_filter_value"])
            source_filtered_rows = filter_source_rows(
                rows,
                fields,
                filter_column=official_filter_column,
                filter_value=official_filter_value,
                label=f"{zip_name}:{member_name}",
            )
            prch_flag = str(component["prch_flag"])
            allowed_flag_values = "-2|1" if prch_flag else ""
            panel_filter = (
                json.dumps(
                    {prch_flag: [-2, 1]},
                    sort_keys=True,
                    separators=(",", ":"),
                )
                if prch_flag
                else "{}"
            )
            flags_info = flags_by_year[year]
            retained_rows = list(source_filtered_rows)
            if prch_flag:
                flag_column = casefold_column(
                    list(flags_info["fields"]),
                    prch_flag,
                    label=f"{flags_info['zip_name']}:{flags_info['member']}",
                )
                component_unitid_column = casefold_column(
                    fields,
                    "UNITID",
                    label=f"{zip_name}:{member_name}",
                )
                flags_index = dict(flags_info["index"])
                missing_unitids = sorted(
                    {
                        row.get(component_unitid_column, "").strip()
                        for row in source_filtered_rows
                        if row.get(component_unitid_column, "").strip()
                        not in flags_index
                    }
                )
                blank_component_unitids = sum(
                    not row.get(component_unitid_column, "").strip()
                    for row in source_filtered_rows
                )
                if blank_component_unitids or missing_unitids:
                    raise ReviewEvidenceError(
                        f"official PRCH join incomplete for {zip_name}:{prch_flag}: "
                        f"blank_unitid_rows={blank_component_unitids} "
                        f"unmatched_unitids={len(missing_unitids)} "
                        f"sample={'|'.join(missing_unitids[:10])}"
                    )
                retained_rows = []
                for row in source_filtered_rows:
                    unitid = row[component_unitid_column].strip()
                    flag_token = flags_index[unitid].get(flag_column, "").strip()
                    if flag_token:
                        try:
                            normalized_flag = decimal_text(
                                decimal_value(
                                    flag_token,
                                    label=(
                                        f"{flags_info['zip_name']}:{flags_info['member']} "
                                        f"{unitid} {flag_column}"
                                    ),
                                )
                            )
                        except ReviewEvidenceError:
                            normalized_flag = flag_token
                    else:
                        normalized_flag = ""
                    if normalized_flag in {"-2", "1"}:
                        retained_rows.append(row)

            official_value = aggregate_source_rows(
                retained_rows,
                fields,
                metric=str(component["official_metric"]),
                variable=str(component["official_variable"]),
                label=f"{zip_name}:{member_name}",
            )
            tolerance_policy = b08_candidate_tolerance_policy(
                str(component["panel_metric"])
            )
            absolute_tolerance = tolerance_policy["absolute"]
            relative_tolerance = tolerance_policy["relative"]
            if not isinstance(absolute_tolerance, Decimal) or not isinstance(
                relative_tolerance, Decimal
            ):
                raise ReviewEvidenceError("B08 tolerance policy returned non-decimal limits")

            access_dir = (
                legacy_root
                / "Raw_Access_Databases"
                / str(year)
                / "tables_csv"
            )
            access_path = require_casefold_file(access_dir, access_table)
            access_fields, access_rows = read_csv(access_path)
            access_value = aggregate_source_rows(
                access_rows,
                access_fields,
                metric=str(component["access_metric"]),
                variable=str(component["access_variable"]),
                label=access_path.name,
            )
            difference = official_value - access_value
            relative_difference = (
                abs(difference) / abs(official_value)
                if official_value != 0
                else (Decimal(0) if difference == 0 else Decimal("Infinity"))
            )
            allowed_difference = max(
                absolute_tolerance,
                abs(official_value) * relative_tolerance,
            )
            within_tolerance = abs(difference) <= allowed_difference
            decision_id = (
                f"B08-{family_index:02d}-{year_index:02d}-"
                f"{slug(str(component['component_family']))}-{year}"
            )
            official_filter = (
                json.dumps(
                    {official_filter_column: int(official_filter_value)},
                    sort_keys=True,
                    separators=(",", ":"),
                )
                if official_filter_column
                else "{}"
            )
            source_url = f"{OFFICIAL_BENCHMARK_BASE_URL}/{zip_name}"
            flags_clause = (
                f" Join to {flags_info['member']} on exact UNITID and retain only "
                f"{prch_flag} in [-2,1]."
                if prch_flag
                else ""
            )
            definition = (
                f"For IPEDS year {year}, apply official-source filter {official_filter} "
                f"to {member_name}.{flags_clause} Then compute {component['official_metric']} of "
                f"{component['official_variable']}. Compare to {component['panel_metric']} "
                f"of canonical panel variable {component['panel_variable']} for the same year "
                f"under panel filter {panel_filter}."
            )
            zip_hash = sha256_file(zip_path)
            if prch_flag:
                component_unitid_column = casefold_column(
                    fields,
                    "UNITID",
                    label=f"{zip_name}:{member_name}",
                )
                component_unitids = {
                    row[component_unitid_column].strip()
                    for row in source_filtered_rows
                }
                join_proof.append(
                    {
                        "benchmark_id": decision_id,
                        "year": year,
                        "component_family": component["component_family"],
                        "prch_flag": prch_flag,
                        "allowed_flag_values": allowed_flag_values,
                        "component_zip": zip_name,
                        "component_zip_sha256": zip_hash,
                        "component_member": member_name,
                        "component_member_sha256": member_hash,
                        "flags_zip": flags_info["zip_name"],
                        "flags_zip_sha256": flags_info["zip_hash"],
                        "flags_member": flags_info["member"],
                        "flags_member_sha256": flags_info["member_hash"],
                        "component_rows_total": len(rows),
                        "component_rows_after_source_filter": len(source_filtered_rows),
                        "component_distinct_unitid": len(component_unitids),
                        "flags_rows_total": len(flags_info["rows"]),
                        "flags_distinct_unitid": len(flags_info["index"]),
                        "matched_component_rows": len(source_filtered_rows),
                        "unmatched_component_unitid_count": 0,
                        "retained_component_rows": len(retained_rows),
                        "excluded_component_rows": (
                            len(source_filtered_rows) - len(retained_rows)
                        ),
                        "expected_value": decimal_text(official_value),
                    }
                )
            decisions.append(
                {
                    "benchmark_id": decision_id,
                    "contract_id": CONTRACT_ID,
                    "artifact": BENCHMARK_ARTIFACT,
                    "year": year,
                    "metric": component["panel_metric"],
                    "variable": component["panel_variable"],
                    "filters": panel_filter,
                    "component_family": component["component_family"],
                    "expected_value": decimal_text(official_value),
                    "absolute_tolerance": decimal_text(absolute_tolerance),
                    "relative_tolerance": decimal_text(relative_tolerance),
                    "tolerance_rationale": str(tolerance_policy["rationale"]),
                    "tolerance_policy_id": str(tolerance_policy["policy_id"]),
                    "tolerance_policy_basis": json.dumps(
                        tolerance_policy["basis"],
                        sort_keys=True,
                        separators=(",", ":"),
                    ),
                    "official_source": source_url,
                    "source_date_or_version": (
                        "NCES IPEDS Complete Data File downloaded "
                        f"{OFFICIAL_BENCHMARK_DOWNLOAD_DATE}"
                    ),
                    "source_evidence_path": source_evidence_path,
                    "source_evidence_sha256": "",
                    "review_status": "pending",
                    "reviewer": "",
                    "review_date": "",
                    "definition": definition,
                    "notes": (
                        f"Locked Access diagnostic {access_path.name} "
                        f"{component['access_metric']}({component['access_variable']})="
                        f"{decimal_text(access_value)} is provenance-bound diagnostic context, "
                        "not the benchmark expected value."
                    ),
                    "decision_id": decision_id,
                    "official_variable": component["official_variable"],
                    "official_metric": component["official_metric"],
                    "official_component_zip_sha256": zip_hash,
                    "official_member": member_name,
                    "official_member_sha256": member_hash,
                    "official_csv_parse_status": csv_parse_status,
                    "official_filters": official_filter,
                    "official_row_count": len(rows),
                    "official_flags_zip": flags_info["zip_name"] if prch_flag else "",
                    "official_flags_zip_sha256": (
                        flags_info["zip_hash"] if prch_flag else ""
                    ),
                    "official_flags_member": (
                        flags_info["member"] if prch_flag else ""
                    ),
                    "official_flags_member_sha256": (
                        flags_info["member_hash"] if prch_flag else ""
                    ),
                    "official_flags_csv_parse_status": (
                        flags_info["parse_status"] if prch_flag else ""
                    ),
                    "prch_flag": prch_flag,
                    "allowed_flag_values": allowed_flag_values,
                    "access_diagnostic_table": access_table,
                    "access_diagnostic_variable": component["access_variable"],
                    "access_diagnostic_filters": "{}",
                    "access_diagnostic_value": decimal_text(access_value),
                    "difference_official_minus_access": decimal_text(difference),
                    "absolute_relative_difference": (
                        decimal_text(relative_difference)
                        if relative_difference.is_finite()
                        else "infinite"
                    ),
                    "within_proposed_tolerance": str(within_tolerance).lower(),
                    "decision_status": "author_review_required",
                    "decision_needed": (
                        "Approve or reject the official source channel, derivation, definition, "
                        "and candidate tolerances; then archive the source evidence at the final "
                        "repository-relative contract path."
                    ),
                }
            )
            audit.append(
                {
                    "evidence_kind": "official_source_candidate",
                    "relative_path": f"official_sources/{zip_name}",
                    "official_url": source_url,
                    "member_name": member_name,
                    "csv_parse_status": csv_parse_status,
                    "byte_size": zip_path.stat().st_size,
                    "sha256": sha256_file(zip_path),
                    "member_sha256": member_hash,
                    "row_count": len(rows),
                    "independence_status": "official_nces_source_pending_review",
                    "release_usable": "false",
                    "reason": (
                        "Expected value was derived only from this official ZIP; author review "
                        "and canonical evidence-path promotion remain required."
                    ),
                }
            )
            source_files.append(zip_path)

    summary = {
        "benchmark_slot_count": len(decisions),
        "target_years": list(OFFICIAL_BENCHMARK_YEARS),
        "component_families": [
            component["component_family"] for component in BENCHMARK_COMPONENTS
        ],
        "official_values_derived": len(decisions),
        "official_source_files": len(source_files),
        "official_component_source_files": len(decisions),
        "official_flags_source_files": len(flags_by_year),
        "prch_scoped_benchmarks": len(join_proof),
        "access_diagnostics_within_proposed_tolerance": sum(
            row["within_proposed_tolerance"] == "true" for row in decisions
        ),
        "maximum_absolute_relative_difference": max(
            Decimal(str(row["absolute_relative_difference"]))
            for row in decisions
            if row["absolute_relative_difference"] != "infinite"
        ).to_eng_string(),
        "independent_reviewed_benchmarks": 0,
        "contract_status": "B08_AUTHOR_REVIEW_REQUIRED",
    }
    return decisions, audit, summary, source_files, join_proof


def build_b08(
    repo_root: Path,
    legacy_root: Path,
    years: Sequence[int],
    *,
    official_benchmark_root: Path | None = None,
    source_evidence_path: str | None = None,
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    dict[str, object],
    list[Path],
    list[dict[str, object]],
]:
    _, canonical_rows = read_csv(repo_root / "contracts" / "external_benchmarks.csv")
    if official_benchmark_root is None:
        decisions, summary = build_placeholder_b08(years)
        official_audit: list[dict[str, object]] = []
        source_files: list[Path] = []
        join_proof: list[dict[str, object]] = []
    else:
        if source_evidence_path is None:
            raise ReviewEvidenceError(
                "official B08 generation requires a stable repo-relative "
                "source_evidence_path"
            )
        source_evidence_path = validate_b08_source_evidence_path(
            source_evidence_path
        )
        (
            decisions,
            official_audit,
            summary,
            source_files,
            join_proof,
        ) = build_official_b08(
            legacy_root,
            years,
            official_benchmark_root,
            source_evidence_path=source_evidence_path,
        )
    named_files = sorted(
        path
        for path in legacy_root.rglob("*")
        if path.is_file() and "benchmark" in path.name.casefold()
    )
    audit: list[dict[str, object]] = [
        {
            "evidence_kind": "canonical_contract",
            "relative_path": "contracts/external_benchmarks.csv",
            "official_url": "",
            "member_name": "",
            "csv_parse_status": "",
            "byte_size": (repo_root / "contracts" / "external_benchmarks.csv").stat().st_size,
            "sha256": sha256_file(repo_root / "contracts" / "external_benchmarks.csv"),
            "member_sha256": "",
            "row_count": len(canonical_rows),
            "independence_status": "empty" if not canonical_rows else "requires_independence_review",
            "release_usable": "false",
            "reason": (
                "No reviewed independent benchmarks are configured."
                if not canonical_rows
                else "Rows require source-independence and semantic review."
            ),
        }
    ]
    for path in named_files:
        audit.append(
            {
                "evidence_kind": "legacy_named_candidate",
                "relative_path": path.relative_to(legacy_root).as_posix(),
                "official_url": "",
                "member_name": "",
                "csv_parse_status": "",
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
                "member_sha256": "",
                "row_count": "",
                "independence_status": "unverified",
                "release_usable": "false",
                "reason": "A filename is not proof that a value is independent or definition-compatible.",
            }
        )
    audit.extend(official_audit)
    summary.update(
        {
            "canonical_benchmark_rows": len(canonical_rows),
            "legacy_named_candidate_files": len(named_files),
        }
    )
    return decisions, audit, summary, source_files, join_proof


def build_b08_evidence_receipt(
    decisions: Sequence[Mapping[str, object]],
    audit: Sequence[Mapping[str, object]],
    join_proof: Sequence[Mapping[str, object]],
    *,
    official_source_audit_sha256: str,
    prch_join_proof_sha256: str,
) -> dict[str, object]:
    for label, value in (
        ("official source audit", official_source_audit_sha256),
        ("PRCH join proof", prch_join_proof_sha256),
    ):
        if re.fullmatch(r"[0-9a-f]{64}", value) is None:
            raise ReviewEvidenceError(f"invalid {label} SHA-256")

    source_rows = sorted(
        (
            row
            for row in audit
            if str(row.get("evidence_kind", "")) == "official_source_candidate"
        ),
        key=lambda row: str(row.get("relative_path", "")),
    )
    official_sources = [
        {
            "path": str(row.get("relative_path", "")),
            "official_url": str(row.get("official_url", "")),
            "byte_size": int(row.get("byte_size", 0)),
            "zip_sha256": str(row.get("sha256", "")),
            "selected_member": str(row.get("member_name", "")),
            "member_sha256": str(row.get("member_sha256", "")),
            "csv_parse_status": str(row.get("csv_parse_status", "")),
            "row_count": int(row.get("row_count", 0)),
        }
        for row in source_rows
    ]
    if not official_sources:
        raise ReviewEvidenceError("B08 evidence receipt has no official sources")
    source_by_hash = {
        str(row["zip_sha256"]): row
        for row in official_sources
    }
    if len(source_by_hash) != len(official_sources):
        raise ReviewEvidenceError("B08 official source ZIP hashes are not unique")

    benchmark_rows: list[dict[str, object]] = []
    for decision in sorted(
        decisions,
        key=lambda row: str(row.get("benchmark_id", "")),
    ):
        component_hash = str(decision.get("official_component_zip_sha256", ""))
        component_source = source_by_hash.get(component_hash)
        if component_source is None:
            raise ReviewEvidenceError(
                f"B08 benchmark {decision.get('benchmark_id', '')} lacks a bound component ZIP"
            )
        flags_hash = str(decision.get("official_flags_zip_sha256", ""))
        flags_source = source_by_hash.get(flags_hash) if flags_hash else None
        if flags_hash and flags_source is None:
            raise ReviewEvidenceError(
                f"B08 benchmark {decision.get('benchmark_id', '')} lacks a bound FLAGS ZIP"
            )
        try:
            policy_basis = json.loads(
                str(decision.get("tolerance_policy_basis", ""))
            )
        except json.JSONDecodeError as exc:
            raise ReviewEvidenceError(
                f"B08 benchmark {decision.get('benchmark_id', '')} has invalid "
                "tolerance_policy_basis JSON"
            ) from exc
        if not isinstance(policy_basis, dict):
            raise ReviewEvidenceError(
                f"B08 benchmark {decision.get('benchmark_id', '')} has non-object "
                "tolerance_policy_basis"
            )
        benchmark_rows.append(
            {
                "benchmark_id": str(decision.get("benchmark_id", "")),
                "year": int(decision.get("year", 0)),
                "component_family": str(decision.get("component_family", "")),
                "artifact": str(decision.get("artifact", "")),
                "metric": str(decision.get("metric", "")),
                "variable": str(decision.get("variable", "")),
                "official_metric": str(decision.get("official_metric", "")),
                "official_variable": str(decision.get("official_variable", "")),
                "filters": str(decision.get("filters", "")),
                "expected_value": str(decision.get("expected_value", "")),
                "tolerances": {
                    "absolute": str(decision.get("absolute_tolerance", "")),
                    "relative": str(decision.get("relative_tolerance", "")),
                    "rationale": str(decision.get("tolerance_rationale", "")),
                    "policy_id": str(decision.get("tolerance_policy_id", "")),
                    "policy_basis": policy_basis,
                },
                "definition": str(decision.get("definition", "")),
                "official_source": str(decision.get("official_source", "")),
                "source_date_or_version": str(
                    decision.get("source_date_or_version", "")
                ),
                "official_component_source": dict(component_source),
                "official_component_filters": str(
                    decision.get("official_filters", "")
                ),
                "prch_scope": {
                    "flag": str(decision.get("prch_flag", "")),
                    "allowed_flag_values": str(
                        decision.get("allowed_flag_values", "")
                    ),
                    "official_flags_source": (
                        dict(flags_source) if flags_source is not None else None
                    ),
                },
                "access_diagnostic": {
                    "table": str(decision.get("access_diagnostic_table", "")),
                    "variable": str(
                        decision.get("access_diagnostic_variable", "")
                    ),
                    "filters": str(
                        decision.get("access_diagnostic_filters", "")
                    ),
                    "value": str(decision.get("access_diagnostic_value", "")),
                    "difference_official_minus_access": str(
                        decision.get("difference_official_minus_access", "")
                    ),
                    "absolute_relative_difference": str(
                        decision.get("absolute_relative_difference", "")
                    ),
                    "within_proposed_tolerance": str(
                        decision.get("within_proposed_tolerance", "")
                    ),
                    "rule": (
                        "Diagnostic context only; this value never supplies expected_value."
                    ),
                },
                "review_status": str(decision.get("review_status", "")),
                "decision_status": str(decision.get("decision_status", "")),
            }
        )
    if not benchmark_rows:
        raise ReviewEvidenceError("B08 evidence receipt has no benchmark derivations")

    join_rows = [
        {str(key): value for key, value in row.items()}
        for row in sorted(
            join_proof,
            key=lambda row: str(row.get("benchmark_id", "")),
        )
    ]
    join_summary = {
        "path": "B08_PRCH_JOIN_PROOF.csv",
        "sha256": prch_join_proof_sha256,
        "row_count": len(join_rows),
        "matched_component_rows": sum(
            int(row.get("matched_component_rows", 0)) for row in join_rows
        ),
        "unmatched_component_unitid_count": sum(
            int(row.get("unmatched_component_unitid_count", 0))
            for row in join_rows
        ),
        "retained_component_rows": sum(
            int(row.get("retained_component_rows", 0)) for row in join_rows
        ),
        "excluded_component_rows": sum(
            int(row.get("excluded_component_rows", 0)) for row in join_rows
        ),
        "rows": join_rows,
    }
    return {
        "schema_version": "b08-official-benchmark-evidence-v3",
        "contract_id": CONTRACT_ID,
        "review_status": "pending_author_review",
        "coverage": {
            "benchmark_count": len(benchmark_rows),
            "years": sorted({row["year"] for row in benchmark_rows}),
            "component_families": sorted(
                {row["component_family"] for row in benchmark_rows}
            ),
        },
        "official_source_audit": {
            "path": "B08_EXISTING_BENCHMARK_EVIDENCE_AUDIT.csv",
            "sha256": official_source_audit_sha256,
            "official_source_row_count": len(official_sources),
        },
        "official_sources": official_sources,
        "benchmarks": benchmark_rows,
        "prch_join_proof": join_summary,
        "expected_value_source_rule": (
            "Expected values derive only from the official NCES ZIP/member evidence "
            "listed in this receipt and, when prch_scope.flag is nonblank, exact UNITID "
            "joins to the listed official FLAGS source."
        ),
        "tolerance_policy_rule": (
            "Candidate tolerances use the author-review policy identified in each "
            "benchmark record for NCES cross-release revisions. They were not estimated "
            "from Access diagnostic deltas; Access diagnostics are post-hoc context only."
        ),
        "canonical_boundary": (
            "This receipt is review evidence only. It does not approve or populate "
            "contracts/external_benchmarks.csv."
        ),
    }


def metadata_semantics(row: Mapping[str, str]) -> dict[str, str]:
    normalized = normalized_row(row)
    return {
        "varname": normalized.get("varname", "").upper(),
        "source_varnumber": normalized.get("varnumber", ""),
        "var_title": normalized.get("vartitle", ""),
        "long_description": normalized.get("longdescription", ""),
        "data_type": normalized.get("datatype", ""),
        "format": normalized.get("format", ""),
        "field_width": normalized.get("fieldwidth", ""),
    }


def semantic_fingerprint(row: Mapping[str, str]) -> str:
    return sha256_json(metadata_semantics(row))


def sibling_semantics_match(donor: Mapping[str, str], sibling: Mapping[str, str] | None) -> bool:
    if sibling is None:
        return False
    left = metadata_semantics(donor)
    right = metadata_semantics(sibling)
    return all(
        left[field].casefold() == right[field].casefold()
        for field in ("varname", "var_title", "data_type", "format", "field_width")
    )


def build_b09(
    legacy_root: Path,
    years: Sequence[int],
) -> tuple[
    list[dict[str, object]],
    list[dict[str, object]],
    list[dict[str, object]],
    dict[str, object],
]:
    source_file = "SAL_A_LT"
    annual: dict[int, dict[str, object]] = {}
    for year in years:
        year_dir = legacy_root / "Raw_Access_Databases" / str(year)
        inventory_path = year_dir / "metadata" / "table_inventory.csv"
        if not inventory_path.is_file():
            continue
        _, inventory_rows = read_csv(inventory_path)
        matches = [
            row
            for row in inventory_rows
            if row.get("table_role", "").casefold() == "data"
            and row.get("normalized_table_name", "").upper() == source_file
        ]
        if not matches:
            continue
        if len(matches) != 1:
            raise ReviewEvidenceError(
                f"multiple {source_file} data tables found for year {year}"
            )
        inventory = matches[0]
        table_name = inventory["table_name"]
        csv_rel = inventory["csv_path"]
        data_path = year_dir / csv_rel
        header, data_rows = read_csv(data_path)
        declared_count = int(inventory.get("row_count_csv", "0"))
        if declared_count != len(data_rows):
            raise ReviewEvidenceError(
                f"{year} {table_name} inventory row count differs from strict CSV count"
            )
        tables_dir = year_dir / "tables_csv"
        var_path = require_casefold_file(tables_dir, f"varTable{str(year)[-2:]}")
        _, var_rows = read_csv(var_path)
        exact_rows = [
            row
            for row in var_rows
            if normalized_row(row).get("tablename", "").casefold()
            == table_name.casefold()
        ]
        sibling_name = f"SAL{year}_A"
        sibling_rows = [
            row
            for row in var_rows
            if normalized_row(row).get("tablename", "").casefold()
            == sibling_name.casefold()
        ]
        table_path = require_casefold_file(tables_dir, f"Tables{str(year)[-2:]}")
        _, table_rows = read_csv(table_path)
        table_meta = [
            row
            for row in table_rows
            if normalized_row(row).get("tablename", "").casefold()
            == table_name.casefold()
        ]
        annual[year] = {
            "table_name": table_name,
            "data_path": data_path,
            "header": header,
            "row_count": len(data_rows),
            "var_path": var_path,
            "exact_rows": exact_rows,
            "sibling_name": sibling_name,
            "sibling_rows": sibling_rows,
            "table_path": table_path,
            "table_meta": require_single(table_meta, label=f"{year} {table_name} table metadata"),
        }

    donor_years = sorted(
        year for year, info in annual.items() if list(info["exact_rows"])
    )
    target_years = sorted(
        year
        for year, info in annual.items()
        if int(info["row_count"]) > 0 and not list(info["exact_rows"])
    )
    evidence: list[dict[str, object]] = []
    for target_year in target_years:
        target = annual[target_year]
        if not donor_years:
            continue
        distance = min(abs(year - target_year) for year in donor_years)
        nearest = [
            year for year in donor_years if abs(year - target_year) == distance
        ]
        target_columns = {
            str(column).strip().upper()
            for column in list(target["header"])
            if str(column).strip().upper() != "UNITID"
        }
        donor_rows_by_year: dict[int, dict[str, dict[str, str]]] = {}
        for donor_year in nearest:
            donor_rows_by_year[donor_year] = {
                metadata_semantics(row)["varname"]: row
                for row in list(annual[donor_year]["exact_rows"])
            }
        sibling_by_var = {
            metadata_semantics(row)["varname"]: row
            for row in list(target["sibling_rows"])
        }
        for varname in sorted(target_columns):
            present_donors = {
                year: rows[varname]
                for year, rows in donor_rows_by_year.items()
                if varname in rows
            }
            if not present_donors:
                continue
            cross_match = len(
                {semantic_fingerprint(row) for row in present_donors.values()}
            ) == 1
            for donor_year, donor_row in sorted(present_donors.items()):
                semantics = metadata_semantics(donor_row)
                table_meta = normalized_row(dict(target["table_meta"]))
                sibling = sibling_by_var.get(varname)
                evidence.append(
                    {
                        "target_year": target_year,
                        "source_file": source_file,
                        "access_table_name": target["table_name"],
                        "target_csv_sha256": sha256_file(Path(target["data_path"])),
                        "target_row_count": target["row_count"],
                        "target_varname": varname,
                        "target_column_present": "true",
                        "target_table_title": table_meta.get("tabletitle", ""),
                        "target_table_description": table_meta.get("description", ""),
                        "target_table_metadata_sha256": sha256_file(Path(target["table_path"])),
                        "same_year_sibling_table": target["sibling_name"] if sibling else "",
                        "same_year_sibling_varnumber": (
                            metadata_semantics(sibling)["source_varnumber"] if sibling else ""
                        ),
                        "same_year_sibling_semantics_match": str(
                            sibling_semantics_match(donor_row, sibling)
                        ).lower(),
                        "donor_year": donor_year,
                        "donor_access_table_name": annual[donor_year]["table_name"],
                        "donor_table_csv_sha256": sha256_file(
                            Path(annual[donor_year]["data_path"])
                        ),
                        "donor_table_row_count": annual[donor_year]["row_count"],
                        "donor_table_has_observed_rows": str(
                            int(annual[donor_year]["row_count"]) > 0
                        ).lower(),
                        "donor_source_varnumber": semantics["source_varnumber"],
                        "variable_id": (
                            f"nces:{source_file}:{semantics['source_varnumber']}:{varname}"
                        ),
                        "donor_var_title": semantics["var_title"],
                        "donor_long_description": semantics["long_description"],
                        "donor_data_type": semantics["data_type"],
                        "donor_format": semantics["format"],
                        "donor_field_width": semantics["field_width"],
                        "donor_metadata_sha256": sha256_file(
                            Path(annual[donor_year]["var_path"])
                        ),
                        "cross_donor_semantics_match": str(cross_match).lower(),
                        "compatibility_status": (
                            "candidate-compatible"
                            if cross_match and sibling_semantics_match(donor_row, sibling)
                            else "requires-more-evidence"
                        ),
                    }
                )

    grouped: dict[tuple[str, str, str, str], list[dict[str, object]]] = defaultdict(list)
    for row in evidence:
        grouped[
            (
                str(row["target_year"]),
                str(row["source_file"]),
                str(row["access_table_name"]),
                str(row["target_varname"]),
            )
        ].append(row)
    decisions: list[dict[str, object]] = []
    for key, rows in sorted(grouped.items()):
        target_year, source, table_name, varname = key
        donor_options = [str(row["donor_year"]) for row in rows]
        candidate_ids = sorted({str(row["variable_id"]) for row in rows})
        populated_compatible_donors = sorted(
            {
                str(row["donor_year"])
                for row in rows
                if row["compatibility_status"] == "candidate-compatible"
                and int(row["donor_table_row_count"]) > 0
            }
        )
        zero_row_donors = sorted(
            {
                str(row["donor_year"])
                for row in rows
                if int(row["donor_table_row_count"]) == 0
            }
        )
        if len(populated_compatible_donors) == 1:
            recommended_donor = populated_compatible_donors[0]
            zero_row_clause = (
                "; "
                + ", ".join(
                    f"{year} donor table is zero-row" for year in zero_row_donors
                )
                if zero_row_donors
                else ""
            )
            recommendation_status = "nonbinding_author_review_required"
            recommendation_basis = (
                f"{recommended_donor} is the only semantically compatible adjacent donor "
                f"backed by a nonzero exact source table{zero_row_clause}. This is an "
                "evidence-based recommendation only; author approval is still required."
            )
        else:
            recommended_donor = ""
            recommendation_status = "no_unique_evidence_based_recommendation"
            recommendation_basis = (
                "The source-table row-count and compatibility evidence does not identify "
                "exactly one populated donor."
            )
        decisions.append(
            {
                "decision_id": f"B09-{target_year}-{slug(source)}-{slug(varname)}",
                "target_year": target_year,
                "source_file": source,
                "access_table_name": table_name,
                "target_varname": varname,
                "candidate_variable_id": (
                    candidate_ids[0] if len(candidate_ids) == 1 else "|".join(candidate_ids)
                ),
                "donor_options": "|".join(
                    donor_options + ["do_not_backfill", "request_more_evidence"]
                ),
                "cross_donor_semantics_match": str(
                    all(row["cross_donor_semantics_match"] == "true" for row in rows)
                ).lower(),
                "same_year_sibling_semantics_match": str(
                    all(row["same_year_sibling_semantics_match"] == "true" for row in rows)
                ).lower(),
                "recommended_donor_year": recommended_donor,
                "recommendation_status": recommendation_status,
                "recommendation_basis": recommendation_basis,
                "decision_needed": (
                    "Select exactly one reviewed donor year, reject the backfill, or request "
                    "same-year variable-level documentation."
                ),
                "exact_missing_evidence": (
                    "The target Access table and column exist, but exact same-year target-table "
                    "varlist metadata and source varnumber are absent."
                ),
                "source_evidence": (
                    "B09_METADATA_BACKFILL_CANDIDATE_EVIDENCE.csv; target table/header SHA-256; "
                    "adjacent donor table and varTable SHA-256; donor observed row counts; "
                    "same-year sibling semantics."
                ),
                "decision_status": "author_review_required",
            }
        )
    conditional_candidates: list[dict[str, object]] = []
    for decision in decisions:
        recommended_donor = str(decision["recommended_donor_year"])
        if not recommended_donor:
            continue
        matching = [
            row
            for row in evidence
            if str(row["target_year"]) == str(decision["target_year"])
            and str(row["source_file"]) == str(decision["source_file"])
            and str(row["access_table_name"]) == str(decision["access_table_name"])
            and str(row["target_varname"]) == str(decision["target_varname"])
            and str(row["donor_year"]) == recommended_donor
            and str(row["compatibility_status"]) == "candidate-compatible"
        ]
        if len(matching) != 1:
            raise ReviewEvidenceError(
                f"{decision['decision_id']} does not have exactly one recommended "
                "candidate-compatible donor evidence row"
            )
        donor = matching[0]
        compatibility_evidence = (
            f"target table {donor['access_table_name']} SHA-256 "
            f"{donor['target_csv_sha256']} row count={donor['target_row_count']}; "
            f"{recommended_donor} donor table row count="
            f"{donor['donor_table_row_count']}; donor access table "
            f"{donor['donor_access_table_name']} SHA-256 "
            f"{donor['donor_table_csv_sha256']}; donor metadata SHA-256 "
            f"{donor['donor_metadata_sha256']}; exact cross-donor semantics match="
            f"{donor['cross_donor_semantics_match']}; same-year sibling semantics "
            f"match={donor['same_year_sibling_semantics_match']}."
        )
        conditional_candidates.append(
            {
                "approval_id": decision["decision_id"],
                "contract_id": CONTRACT_ID,
                "target_year": donor["target_year"],
                "source_file": donor["source_file"],
                "access_table_name": donor["access_table_name"],
                "donor_year": recommended_donor,
                "variable_id": donor["variable_id"],
                "target_varname": donor["target_varname"],
                "expected_data_type": donor["donor_data_type"],
                "expected_title": donor["donor_var_title"],
                "fields_backfilled": (
                    "varTitle|longDescription|DataType|format|Fieldwidth"
                ),
                "compatibility_status": (
                    "exact_adjacent_donor_semantics_match"
                ),
                "compatibility_evidence": compatibility_evidence,
                "approval_status": "pending_author_review",
                "reviewer": "",
                "review_date": "",
                "justification": (
                    f"Conditional review-only candidate: use the populated exact "
                    f"{recommended_donor} adjacent donor for missing {donor['target_year']} "
                    f"{donor['access_table_name']}.{donor['target_varname']} metadata only; "
                    "never backfill source values. Requires exact author countersign."
                ),
            }
        )
    conditional_candidates.sort(
        key=lambda row: (
            int(row["target_year"]),
            str(row["source_file"]),
            str(row["access_table_name"]),
            str(row["target_varname"]),
        )
    )
    summary = {
        "runtime_backfill_source": source_file,
        "target_year_count": len(target_years),
        "candidate_row_count": len(evidence),
        "decision_count": len(decisions),
        "candidate_compatible_rows": sum(
            row["compatibility_status"] == "candidate-compatible" for row in evidence
        ),
        "decisions_with_evidence_based_recommendation": sum(
            bool(row["recommended_donor_year"]) for row in decisions
        ),
        "conditional_candidate_row_count": len(conditional_candidates),
        "contract_status": (
            "B09_AUTHOR_REVIEW_REQUIRED" if decisions else "B09_NO_RUNTIME_BACKFILL_NEEDED"
        ),
    }
    return evidence, decisions, conditional_candidates, summary


def external_evidence_markdown(
    b01: Mapping[str, object],
    b07: Mapping[str, object],
    b08: Mapping[str, object],
    b09: Mapping[str, object],
) -> str:
    if b01["classification"] == "already_complete_exactly":
        b01_state = (
            "The canonical B01 URL/size completion is already complete exactly. "
            "The candidate CSV is therefore byte-identical to the canonical contract."
        )
        b01_boundary = "B01: already complete exactly; canonical contract unchanged."
    else:
        b01_state = (
            "Only direct source URLs and observed byte sizes are candidates for completion."
        )
        b01_boundary = (
            "B01 candidate: mechanical completion only; canonical contract unchanged."
        )
    if int(b08.get("official_values_derived", 0)) > 0:
        b08_state = f"""The package derives {b08['official_values_derived']} expected values
from {b08['official_source_files']} exact official NCES Complete Data File
ZIPs across six required component families and the years
{', '.join(map(str, b08['target_years']))}. Every ZIP and selected CSV member
is hashed and supplied in `official_sources/`. Locked Access values are shown
only as diagnostics; they never supply an expected value. All rows remain
pending until the author reviews the official-source channel, derivations,
definitions, and proposed tolerances."""
        b08_boundary = (
            "B08: official evidence derived and supplied; blocked pending author review."
        )
    else:
        b08_state = f"""There are {b08['benchmark_slot_count']} empty-valued decision slots
across six required component families and three years. Needed for every slot:

- an independently published official value;
- exact vintage, universe, variable, filters, and definition;
- nonnegative absolute and relative tolerances plus rationale;
- a preserved source file and SHA-256.

Legacy panel outputs and pipeline QA totals are prohibited as independent
benchmarks."""
        b08_boundary = "B08: blocked pending independent external evidence."
    return f"""# Remaining B01/B07/B08/B09 evidence decisions

This is a review package, not a contract approval or release receipt.

## B01 source-lock completion

The package rehashed {b01['artifact_proof_rows']} exact approved artifacts
({b01['bytes_rehashed']} bytes). {b01_state} Filenames, release identities,
expected hashes, reviewer provenance, and approval status are unchanged. This
is mechanical under the existing B01 approval because the URL and size values
are properties of the already approved exact bytes. An optional live
official-URL check may confirm current availability, but it must not change the
locked byte identity.

## B07 PRCH

There are {b07['observed_signature_count']} year/flag/code signatures across
{b07['distinct_flags']} flags. Archived FLAGS values and official Access
value-set frequencies reconcile mechanically. They do not prove cleaning
actions or target columns. Needed:

- annual NCES component forms and reporting instructions;
- exact flag/code classification and action by applicable year;
- exact analysis-column or source-column targets;
- Finance accounting standard, form, and part for partial cases;
- an explicit decision for dimensioned-lane applicability.

## B08 external benchmarks

{b08_state}

## B09 metadata backfill

The runtime backfill review has {b09['decision_count']} variable-level
decisions and {b09['candidate_row_count']} donor evidence rows. Adjacent donor
agreement and same-year sibling metadata are compatibility evidence, not donor
approval. The package records a nonbinding recommendation and an exact
conditional canonical-shape row only when exactly one compatible adjacent donor
is backed by a nonzero exact source table; the row remains
`pending_author_review` and does not approve that donor. The author must select
exactly one donor per variable, reject the backfill, or request same-year
target-table variable metadata.

## Release boundary

- {b01_boundary}
- B07: blocked pending author and source-semantic review.
- {b08_boundary}
- B09: blocked pending author donor selection where candidates exist.
- Full 2004-2023 build not run.
- Release remains blocked.
"""


def build_package(
    *,
    repo_root: Path,
    legacy_root: Path,
    out_dir: Path,
    official_benchmark_root: Path | None = None,
) -> dict[str, object]:
    repo_root = repo_root.expanduser().resolve()
    legacy_root = legacy_root.expanduser().resolve()
    out_dir = out_dir.expanduser().absolute()
    if out_dir.exists():
        raise ReviewEvidenceError(f"output directory already exists: {out_dir}")
    canonical_before = {
        relative: {
            "byte_size": (repo_root / relative).stat().st_size,
            "sha256": sha256_file(repo_root / relative),
        }
        for relative in CANONICAL_REVIEW_CONTRACTS
    }

    b01_candidate, b01_proof, b01_summary, years = build_b01(repo_root, legacy_root)
    b07_evidence, b07_decisions, b07_summary = build_b07(legacy_root, years)
    b08_source_evidence_path = (
        stable_b08_receipt_path(repo_root, out_dir)
        if official_benchmark_root is not None
        else None
    )
    (
        b08_decisions,
        b08_audit,
        b08_summary,
        b08_source_files,
        b08_join_proof,
    ) = build_b08(
        repo_root,
        legacy_root,
        years,
        official_benchmark_root=official_benchmark_root,
        source_evidence_path=b08_source_evidence_path,
    )
    (
        b09_evidence,
        b09_decisions,
        b09_conditional_candidates,
        b09_summary,
    ) = build_b09(legacy_root, years)

    out_dir.mkdir(parents=True, exist_ok=False)
    generator_source = Path(__file__).resolve()
    generator_copy = out_dir / "generator" / generator_source.name
    generator_copy.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(generator_source, generator_copy)
    generator_source_hash = sha256_file(generator_source)
    if sha256_file(generator_copy) != generator_source_hash:
        raise ReviewEvidenceError("generator source copy verification failed")
    copied_names: set[str] = set()
    for source_path in sorted(b08_source_files, key=lambda path: path.name):
        if source_path.name in copied_names:
            raise ReviewEvidenceError(
                f"duplicate official benchmark source filename: {source_path.name}"
            )
        copied_names.add(source_path.name)
        destination = out_dir / "official_sources" / source_path.name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source_path, destination)
        if sha256_file(destination) != sha256_file(source_path):
            raise ReviewEvidenceError(
                f"official benchmark source copy verification failed: {source_path.name}"
            )
    write_csv(
        out_dir / "B01_SOURCE_RELEASE_COMPLETION_CANDIDATE.csv",
        SOURCE_RELEASE_FIELDS,
        b01_candidate,
    )
    write_csv(
        out_dir / "B01_SOURCE_RELEASE_COMPLETION_PROOF.csv",
        B01_PROOF_FIELDS,
        b01_proof,
    )
    write_csv(
        out_dir / "B07_PRCH_OBSERVED_CODE_EVIDENCE.csv",
        B07_EVIDENCE_FIELDS,
        b07_evidence,
    )
    write_csv(
        out_dir / "B07_PRCH_DECISION_REGISTER.csv",
        B07_DECISION_FIELDS,
        b07_decisions,
    )
    b08_audit_path = out_dir / "B08_EXISTING_BENCHMARK_EVIDENCE_AUDIT.csv"
    write_csv(b08_audit_path, B08_AUDIT_FIELDS, b08_audit)
    b08_join_path = out_dir / "B08_PRCH_JOIN_PROOF.csv"
    write_csv(b08_join_path, B08_PRCH_JOIN_FIELDS, b08_join_proof)
    if int(b08_summary.get("official_values_derived", 0)) > 0:
        receipt_path = out_dir / "B08_OFFICIAL_BENCHMARK_EVIDENCE_RECEIPT.json"
        receipt = build_b08_evidence_receipt(
            b08_decisions,
            b08_audit,
            b08_join_proof,
            official_source_audit_sha256=sha256_file(b08_audit_path),
            prch_join_proof_sha256=sha256_file(b08_join_path),
        )
        receipt_path.write_text(
            json.dumps(receipt, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
            encoding="utf-8",
            newline="\n",
        )
        receipt_hash = sha256_file(receipt_path)
        for decision in b08_decisions:
            decision["source_evidence_sha256"] = receipt_hash
        b08_summary["evidence_receipt_sha256"] = receipt_hash
    write_csv(
        out_dir / "B08_EXTERNAL_BENCHMARK_DECISION_REGISTER.csv",
        B08_DECISION_FIELDS,
        b08_decisions,
    )
    write_csv(
        out_dir / "B09_METADATA_BACKFILL_CANDIDATE_EVIDENCE.csv",
        B09_EVIDENCE_FIELDS,
        b09_evidence,
    )
    write_csv(
        out_dir / "B09_METADATA_BACKFILL_DECISION_REGISTER.csv",
        B09_DECISION_FIELDS,
        b09_decisions,
    )
    write_csv(
        out_dir / "B09_METADATA_BACKFILL_CONDITIONAL_CANDIDATE.csv",
        B09_CONDITIONAL_CANDIDATE_FIELDS,
        b09_conditional_candidates,
    )

    canonical_after = {
        relative: {
            "byte_size": (repo_root / relative).stat().st_size,
            "sha256": sha256_file(repo_root / relative),
        }
        for relative in CANONICAL_REVIEW_CONTRACTS
    }
    if canonical_after != canonical_before:
        raise ReviewEvidenceError("canonical review contracts changed during evidence generation")
    write_csv(
        out_dir / "CANONICAL_CONTRACT_HASH_PROOF.csv",
        ["relative_path", "byte_size", "sha256", "post_sha256", "unchanged"],
        [
            {
                "relative_path": relative,
                "byte_size": canonical_before[relative]["byte_size"],
                "sha256": canonical_before[relative]["sha256"],
                "post_sha256": canonical_after[relative]["sha256"],
                "unchanged": "true",
            }
            for relative in sorted(canonical_before)
        ],
    )
    (out_dir / "REMAINING_EXTERNAL_EVIDENCE.md").write_text(
        external_evidence_markdown(
            b01_summary,
            b07_summary,
            b08_summary,
            b09_summary,
        ),
        encoding="utf-8",
        newline="\n",
    )
    summary: dict[str, object] = {
        "generator_version": GENERATOR_VERSION,
        "generator_source_sha256": generator_source_hash,
        "contract_id": CONTRACT_ID,
        "release_status": "RELEASE_STILL_BLOCKED",
        "canonical_contracts_unchanged": True,
        "full_build_run": False,
        "b01": b01_summary,
        "b07": b07_summary,
        "b08": b08_summary,
        "b09": b09_summary,
    }
    (out_dir / "SCIENTIFIC_REVIEW_PACKAGE_SUMMARY.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    manifest_rows = []
    for path in sorted(
        (path for path in out_dir.rglob("*") if path.is_file()),
        key=lambda path: path.relative_to(out_dir).as_posix(),
    ):
        manifest_rows.append(
            {
                "relative_path": path.relative_to(out_dir).as_posix(),
                "byte_size": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    write_csv(
        out_dir / "SCIENTIFIC_REVIEW_PACKAGE_MANIFEST.csv",
        ["relative_path", "byte_size", "sha256"],
        manifest_rows,
    )
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument("--legacy-root", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument(
        "--official-benchmark-root",
        default=None,
        help=(
            "Directory containing the exact 18 official NCES Complete Data File ZIPs. "
            "When absent, B08 remains an empty-value evidence request."
        ),
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        summary = build_package(
            repo_root=Path(args.repo_root),
            legacy_root=Path(args.legacy_root),
            out_dir=Path(args.out_dir),
            official_benchmark_root=(
                Path(args.official_benchmark_root)
                if args.official_benchmark_root
                else None
            ),
        )
    except ReviewEvidenceError as exc:
        print(f"Review evidence generation failed: {exc}")
        return 1
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
