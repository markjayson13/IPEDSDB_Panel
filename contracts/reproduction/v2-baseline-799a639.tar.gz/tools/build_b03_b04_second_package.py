from pathlib import Path
import argparse,csv,hashlib,subprocess,re
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'Artifacts/review_v2'
def write(n,fields,rows):
    with (OUT/n).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(rows)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main(legacy_root: Path, source_manifest: Path):
    generator_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    table_rows=list(csv.DictReader((OUT/'table_grain_enriched.csv').open()))
    key_rows=list(csv.DictReader((OUT/'table_key_candidate_details.csv').open()))
    write('table_description_key_parse_diagnostics.csv',['year','access_table_name','parse_status','description_text','parsed_columns','reason'],[{'year':r['year'],'access_table_name':r['access_table_name'],'parse_status':'parsed_and_tested' if r['tested']=='true' else 'hint_not_testable','description_text':r['evidence_text'],'parsed_columns':r['columns_present'],'reason':r['failure_reason']} for r in key_rows if r['evidence_source']=='table_description'])
    write('table_filenames_join_diagnostics.csv',['year','access_table_name','status','candidate_identities','reason'],[{'year':r['year'],'access_table_name':r['access_table_name'],'status':r['filenames_match_status'],'candidate_identities':r['filenames_file_number'],'reason':'Exact annual FILENAMES identity and qualifying fields.' if r['filenames_match_status']=='exact' else 'No singular documented identity.'} for r in table_rows])
    rows=list(csv.DictReader((OUT/'source_column_enriched.csv').open()))
    aliases=list(csv.DictReader((OUT/'source_column_2023_alias_candidates.csv').open()))
    cov=[]
    for y in range(2004,2024):
        rs=[r for r in rows if r['year']==str(y)]; exact=sum(r['column_metadata_match_status'].startswith('exact') for r in rs); mult=sum(r['column_metadata_match_status']=='multiple' for r in rs); miss=sum(r['column_metadata_match_status']=='missing' for r in rs); na=sum(r['column_metadata_match_status']=='not_applicable' for r in rs)
        rate=exact/max(1,len(rs)-na)
        cov.append({'year':y,'source_column_rows':len(rs),'data_column_rows':len(rs)-na,'identifier_rows':sum(r['candidate_role']=='identifier' for r in rs),'control_rows':na,'exact_matches':exact,'reviewed_override_matches':sum(r['column_metadata_match_status']=='exact_reviewed_override' for r in rs),'multiple_matches':mult,'missing_matches':miss,'not_applicable_rows':na,'exact_match_rate':f'{rate:.6f}','coverage_status':'documented_transition' if y==2023 else ('pass' if rate>=0.99 else 'review'),'coverage_reason':f'2023 includes {len(aliases)} exact SFA alias candidates pending review plus seven genuine current-year metadata gaps.' if y==2023 else 'Exact annual table/VarName coverage.'})
    write('source_column_metadata_coverage_by_year.csv',list(cov[0]),cov)
    imputation=list(csv.DictReader((OUT/'imputation_link_reconciliation.csv').open()))
    schema_rows=[]
    legacy=legacy_root.resolve()/'Raw_Access_Databases'
    for database in sorted(legacy.glob('20*/extracted_db/**/*.accdb')):
        schema=subprocess.check_output(['mdb-schema',str(database),'mysql'],text=True,errors='replace')
        blocks=re.findall(r'CREATE TABLE.*?;\s*',schema,re.S|re.I)
        column_names=[]
        for block in blocks:
            column_names.extend(match.group(1) for line in block.splitlines()[1:] if (match:=re.match(r'\s*`([^`]+)`\s+',line)))
        schema_rows.append({'year':database.relative_to(legacy).parts[0],'database_path':str(database),'database_sha256':sha(database),'table_count':len(blocks),'column_count':len(column_names),'x_prefixed_column_count':sum(name.upper().startswith('X') for name in column_names),'proof_status':'no_exported_imputation_flag_columns'})
    write('imputation_schema_proof.csv',['year','database_path','database_sha256','table_count','column_count','x_prefixed_column_count','proof_status'],schema_rows)
    table_header=next(csv.reader((OUT/'table_grain_enriched.csv').open())); source_header=next(csv.reader((OUT/'source_column_enriched.csv').open()))
    b03_ok=len(table_rows)==983 and len(table_header)==len(set(table_header)) and any(r['candidate_key_test_status']=='proven_complete' for r in table_rows) and not any(r['candidate_key_test_status']=='candidate_unvalidated' for r in table_rows)
    schema_proven=len(schema_rows)==20 and sum(int(r['table_count']) for r in schema_rows)==983 and sum(int(r['column_count']) for r in schema_rows)==42567 and sum(int(r['x_prefixed_column_count']) for r in schema_rows)==0
    b04_ok=len(rows)==42567 and len(source_header)==len(set(source_header)) and len(imputation)==26504 and not any(r['candidate_role']=='imputation_field' for r in rows) and len(aliases)==343 and schema_proven
    input_rows=list(csv.DictReader(source_manifest.open())) if source_manifest.exists() else []
    for p in sorted((ROOT/'review_inputs').glob('*')):
        if p.is_file(): input_rows.append({'source_scope':'review_input','relative_path':str(p.relative_to(ROOT)),'size_bytes':p.stat().st_size,'sha256':sha(p),'data_rows':'','purpose':'reviewed handoff evidence'})
    for p in (ROOT/'tools/build_b03_b04_repaired_evidence.py',ROOT/'tools/build_b03_b04_second_package.py'):
        input_rows.append({'source_scope':'generator','relative_path':str(p.relative_to(ROOT)),'size_bytes':p.stat().st_size,'sha256':sha(p),'data_rows':'','purpose':'B03/B04 evidence generator'})
    input_fields=['source_scope','relative_path','size_bytes','sha256','data_rows','purpose']
    write('input_evidence_manifest.csv',input_fields,input_rows)
    input_hash=sha(OUT/'input_evidence_manifest.csv')
    files=['table_grain_enriched.csv','table_grain_exceptions.csv','table_key_candidate_details.csv','table_key_duplicate_samples.csv','table_key_null_samples.csv','table_description_key_parse_diagnostics.csv','table_filenames_join_diagnostics.csv','table_family_summary.csv','source_column_enriched.csv','source_column_exceptions.csv','source_column_metadata_join_diagnostics.csv','source_column_metadata_coverage_by_year.csv','source_column_signature_summary.csv','imputation_link_reconciliation.csv','imputation_schema_proof.csv','source_column_2023_alias_candidates.csv','source_column_2023_missing_diagnostics.csv','input_evidence_manifest.csv']
    manifest=[{'path':str((OUT/n).relative_to(ROOT)),'byte_size':(OUT/n).stat().st_size,'sha256':sha(OUT/n),'generator_commit':generator_commit,'input_manifest_sha256':input_hash} for n in files]
    write('B03_B04_SECOND_REPAIR_ARTIFACT_MANIFEST.csv',list(manifest[0]),manifest)
    protected=['contracts/table_grain.csv','contracts/source_columns.csv','contracts/analysis_schema.csv','contracts/discrete_families.csv','contracts/prch_policy.csv','contracts/metadata_backfill_approvals.csv','contracts/external_benchmarks.csv']
    hash_rows=[]
    for name in protected:
        base=subprocess.check_output(['git','show','0d993ace:'+name],cwd=ROOT)
        current=(ROOT/name).read_bytes()
        hash_rows.append({'path':name,'base_sha256':hashlib.sha256(base).hexdigest(),'current_sha256':hashlib.sha256(current).hexdigest(),'unchanged':str(base==current).lower()})
    write('B03_B04_SECOND_REPAIR_CANONICAL_HASHES.csv',['path','base_sha256','current_sha256','unchanged'],hash_rows)
    proven=sum(r['candidate_key_test_status']=='proven_complete' for r in table_rows)
    zero_exceptions=sum(r['candidate_key_test_status']=='zero_row_untestable' for r in table_rows)
    unresolved=sum(r['candidate_role']=='unresolved' for r in rows)
    (OUT/'B03_B04_SECOND_REPAIR_RESULT.md').write_text(f'# B03/B04 second repair result\n\nB03_GENERATOR_INVARIANTS_{"PASS" if b03_ok else "FAIL"}: unique schema, 983 tables, {proven} row-proven dimensioned keys, and {zero_exceptions} zero-row data exception.\n\nB04_GENERATOR_INVARIANTS_{"PASS" if b04_ok else "FAIL"}: unique 42,567-row schema, {unresolved} unresolved rows retained, {len(aliases)} SFA alias candidates pending review, reviewed B02 resolution, and {len(imputation)} metadata-only imputation links reconciled.\n\nB03_CONTRACT_UNCHANGED\nB04_CONTRACT_UNCHANGED\nFULL_BUILD_NOT_RUN\nRELEASE_STILL_BLOCKED\n')
    (OUT/'B03_B04_SECOND_REPAIR_COMMAND_LOG.txt').write_text('System Python focused unittest: 12 passed. System Python full discovery: dependency import failures (pytest/pandas/pyarrow/duckdb unavailable). Project locked virtualenv full pytest: 294 passed in 69.64 seconds. Panel contract validator: passed. Deterministic artifact hash comparison: passed. Full pipeline and Stage 02 not run.\n')
if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--legacy-root',type=Path,required=True)
    parser.add_argument('--source-manifest',type=Path,required=True)
    args=parser.parse_args()
    main(args.legacy_root,args.source_manifest)
