#!/usr/bin/env python3
"""Repair B03/B04 review evidence without touching canonical contracts."""
from pathlib import Path, PurePosixPath
import argparse
import csv, hashlib, json, re
import importlib.util
import sys
from collections import Counter, defaultdict
from tempfile import TemporaryDirectory

BASE_PROFILE_GENERATOR = Path(__file__).with_name("build_grain_column_evidence.py")
BASE_PROFILE_SPEC = importlib.util.spec_from_file_location(
    "build_grain_column_evidence",
    BASE_PROFILE_GENERATOR,
)
if BASE_PROFILE_SPEC is None or BASE_PROFILE_SPEC.loader is None:
    raise RuntimeError(f"Unable to load base profile generator: {BASE_PROFILE_GENERATOR}")
BASE_PROFILE_MODULE = importlib.util.module_from_spec(BASE_PROFILE_SPEC)
BASE_PROFILE_SPEC.loader.exec_module(BASE_PROFILE_MODULE)
build_base_profiles = BASE_PROFILE_MODULE.run

ACCESS_SCHEMA_MODULE_PATH = Path(__file__).with_name("access_schema_evidence.py")
ACCESS_SCHEMA_SPEC = importlib.util.spec_from_file_location(
    "_b03_b04_access_schema_evidence",
    ACCESS_SCHEMA_MODULE_PATH,
)
if ACCESS_SCHEMA_SPEC is None or ACCESS_SCHEMA_SPEC.loader is None:
    raise RuntimeError(f"Unable to load schema evidence helper: {ACCESS_SCHEMA_MODULE_PATH}")
ACCESS_SCHEMA_MODULE = importlib.util.module_from_spec(ACCESS_SCHEMA_SPEC)
sys.modules[ACCESS_SCHEMA_SPEC.name] = ACCESS_SCHEMA_MODULE
ACCESS_SCHEMA_SPEC.loader.exec_module(ACCESS_SCHEMA_MODULE)
SchemaEvidenceError = ACCESS_SCHEMA_MODULE.SchemaEvidenceError
parse_table_schema_evidence = ACCESS_SCHEMA_MODULE.parse_table_schema_evidence
probe_annual_schema = ACCESS_SCHEMA_MODULE.probe_annual_schema

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'Artifacts/review_v2'
CONTRACT_ID='ipedsdb-panel-2004-2023-access-v2'
SIGNED_AUTHORIZATION_ID='AUTH-B03-B09-20260724'
SIGNED_AUTHOR_NAME='Mark Jayson Martinez Farol'
SIGNED_AUTHOR_DATE='2026-07-24'
SIGNED_AUTHOR_RECEIPT_RELATIVE=PurePosixPath(
    'docs/release/B03_B09_AUTHOR_COUNTERSIGN_2026-07-24.csv'
)
SIGNED_AUTHOR_RECEIPT_SHA256=(
    '6b32846e1dabd493ae99508f0c48488078b5ef50aef87e94b81d9fec77c56b7e'
)
FINAL_AUTHOR_PACKAGE_RELATIVE=PurePosixPath(
    'Artifacts/review_v2/final_author_decision_package_2026-07-24'
)
AUTHOR_RECEIPT_FIELDS=(
    'authorization_id','contract_id','author_name','author_date','decision',
    'register_sha256','scope_sha256','transitive_target_sha256',
    'canonicalized_statement_sha256','source_channel','receipt_status',
    'verbatim_statement',
)
SCOPE_FIELDS=(
    'scope_id','contract_id','block_id','canonical_path',
    'canonical_pre_sha256','final_candidate_path','final_candidate_sha256',
    'expected_post_sha256','row_count','application_mode',
    'child_decision_scope','child_decision_register_path',
    'child_decision_register_sha256','evidence_manifest_path',
    'evidence_manifest_sha256','input_manifest_path','input_manifest_sha256',
    'readiness_status',
)
AUTHOR_REGISTER_FIELDS=(
    'authorization_id','contract_id','scope_manifest_path',
    'scope_manifest_sha256','scope_row_count',
    'transitive_review_target_digest_path',
    'transitive_review_target_digest_sha256',
    'transitive_review_target_sha256','requested_action','allowed_decisions',
    'decision_status','author_name','author_date','release_boundary',
)
STAGE04_ARTIFACT_FIELDS=(
    'path','byte_size','sha256','row_count','artifact_role',
    'generator_sha256','input_manifest_sha256',
    'canonical_table_grain_pre_sha256',
    'canonical_source_columns_pre_sha256',
)
STAGE04_INPUT_FIELDS=('input_role','path','byte_size','sha256','row_count')
SHA256_RE=re.compile(r'^[0-9a-f]{64}$')

def read(path):
    with path.open(newline='',encoding='utf-8-sig',errors='replace') as f:return list(csv.DictReader(f))
def write(path, fields, rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows({k:r.get(k,'') for k in fields} for r in rows)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()

def canonical_json_sha256(value):
    payload=json.dumps(
        value,
        sort_keys=True,
        separators=(',',':'),
        ensure_ascii=False,
    ).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()

def canonicalize_statement(value):
    return ' '.join(value.split())

def exact_csv_rows(path,fields,label):
    try:
        with path.open(newline='',encoding='utf-8-sig') as handle:
            reader=csv.DictReader(handle)
            if tuple(reader.fieldnames or ())!=tuple(fields):
                raise ValueError(
                    f'{label} fields differ from the signed schema'
                )
            rows=list(reader)
    except (OSError,UnicodeError,csv.Error) as exc:
        raise ValueError(f'{label} cannot be read: {exc}') from exc
    if any(None in row for row in rows):
        raise ValueError(f'{label} contains non-canonical extra CSV fields')
    return rows

def exact_csv_data_row_count(path,label):
    try:
        with path.open(newline='',encoding='utf-8-sig') as handle:
            reader=csv.reader(handle)
            next(reader,None)
            return sum(1 for _ in reader)
    except (OSError,UnicodeError,csv.Error) as exc:
        raise ValueError(f'{label} row count cannot be read: {exc}') from exc

def require_sha256(value,label):
    normalized=(value or '').strip().lower()
    if not SHA256_RE.fullmatch(normalized):
        raise ValueError(f'{label} is not an exact SHA-256')
    return normalized

def safe_repo_file(repository,relative,label):
    root=Path(repository).absolute()
    if root.is_symlink() or not root.is_dir():
        raise ValueError(f'{label} repository root is missing or a symlink')
    raw=str(relative)
    posix=PurePosixPath(raw)
    if (
        not raw
        or raw!=raw.strip()
        or '\\' in raw
        or posix.is_absolute()
        or posix.as_posix()!=raw
        or any(part in {'','.','..'} for part in posix.parts)
    ):
        raise ValueError(f'{label} path is not a safe repository-relative path')
    current=root
    for part in posix.parts:
        current=current/part
        try:
            if current.is_symlink():
                raise ValueError(f'{label} path contains a symlink')
        except OSError as exc:
            raise ValueError(f'{label} path cannot be inspected: {exc}') from exc
    if not current.exists():
        raise ValueError(f'{label} is missing: {posix.as_posix()}')
    if not current.is_file():
        raise ValueError(f'{label} is not a regular file: {posix.as_posix()}')
    return current

def require_explicit_file(path,label):
    candidate=Path(path).absolute()
    if not candidate.exists():
        raise ValueError(f'{label} is missing: {candidate}')
    if candidate.is_symlink() or not candidate.is_file():
        raise ValueError(f'{label} is not a regular non-symlink file')
    return candidate

def unique_row(rows,label):
    if len(rows)!=1:
        raise ValueError(f'{label} must resolve to exactly one row')
    return rows[0]

def load_json_without_duplicate_keys(path,label):
    def reject_duplicates(pairs):
        result={}
        for key,value in pairs:
            if key in result:
                raise ValueError(f'{label} repeats JSON key {key}')
            result[key]=value
        return result
    try:
        return json.loads(
            path.read_text(encoding='utf-8'),
            object_pairs_hook=reject_duplicates,
        )
    except (OSError,UnicodeError,json.JSONDecodeError) as exc:
        raise ValueError(f'{label} is not valid JSON: {exc}') from exc

def val(row, name):
    target=name.casefold()
    for k,v in row.items():
        if k.casefold()==target:return v
    return ''

def normalized_number(value):
    value=(value or '').strip()
    return str(int(value)) if value.isdigit() else value.casefold()

def diagnostic_table_name(value):
    """Return a lossy name used only to surface possible metadata candidates."""
    return re.sub(r"[_\s]+", "", re.sub(r"20\d{2}", "", (value or ""))).casefold()

def find_casefold_exact_file(directory, expected_name):
    """Find one physical file by its complete case-insensitive basename."""
    if not directory.is_dir():
        return None
    matches=sorted(
        (
            path
            for path in directory.iterdir()
            if path.is_file() and path.name.casefold()==expected_name.casefold()
        ),
        key=lambda path:path.name,
    )
    if len(matches)>1:
        raise ValueError(
            f"multiple case-insensitive file identities for {expected_name}: "
            +'|'.join(path.name for path in matches)
        )
    return matches[0] if matches else None

def resolve_annual_access_database(extracted_root,access_db_file):
    """Resolve one annual Access database by exact basename at any depth."""
    if Path(access_db_file).name!=access_db_file:
        raise SchemaEvidenceError(
            'schema_probe_input_invalid',
            f'Annual Access database identity is not a basename: {access_db_file!r}.',
        )
    if extracted_root.is_symlink():
        raise SchemaEvidenceError(
            'schema_probe_input_invalid',
            f'Annual extracted_db root cannot be a symlink: {extracted_root}.',
        )
    candidates=[
        path
        for path in extracted_root.rglob('*')
        if path.name.casefold()==access_db_file.casefold()
    ] if extracted_root.is_dir() else []
    unsafe=[]
    matches=[]
    resolved_root=extracted_root.resolve()
    for path in candidates:
        current=path
        has_symlink=False
        while current!=extracted_root:
            if current.is_symlink():
                has_symlink=True
                break
            current=current.parent
        try:
            resolved_path=path.resolve(strict=True)
        except (FileNotFoundError,RuntimeError):
            unsafe.append(path)
            continue
        if (
            has_symlink
            or not resolved_path.is_relative_to(resolved_root)
            or not path.is_file()
        ):
            unsafe.append(path)
            continue
        matches.append(path)
    if unsafe:
        raise SchemaEvidenceError(
            'schema_probe_input_invalid',
            f'Unsafe exact Access database path matched {access_db_file!r}: '
            +'|'.join(
                str(path.relative_to(extracted_root))
                for path in sorted(
                    unsafe,
                    key=lambda path:(
                        str(path.relative_to(extracted_root)).casefold(),
                        str(path.relative_to(extracted_root)),
                    ),
                )
            ),
        )
    matches=sorted(
        matches,
        key=lambda path:(
            str(path.relative_to(extracted_root)).casefold(),
            str(path.relative_to(extracted_root)),
        ),
    )
    if not matches:
        raise SchemaEvidenceError(
            'schema_probe_input_missing',
            f'No exact recursive Access database basename matched {access_db_file!r} '
            f'under {extracted_root}.',
        )
    if len(matches)>1:
        raise SchemaEvidenceError(
            'schema_probe_input_ambiguous',
            f'Multiple exact recursive Access database basenames matched '
            f"{access_db_file!r}: "
            +'|'.join(str(path.relative_to(extracted_root)) for path in matches),
        )
    return matches[0]

def exact_description_key_tokens(evidence_text, header):
    """Resolve documented key tokens by exact header identity only."""
    actual={name.casefold():name for name in header}
    requested=[]
    unresolved=[]
    token_matches=re.finditer(
        r'\(([A-Z][A-Z0-9_]*)\)|\b([A-Z][A-Z0-9_]{2,})\b',
        evidence_text or '',
    )
    for token_match in token_matches:
        parenthesized=token_match.group(1)
        bare=token_match.group(2)
        token=parenthesized or bare or ''
        resolved=actual.get(token.casefold())
        if resolved is not None:
            if resolved not in requested:
                requested.append(resolved)
        elif (
            bare is not None
            and token.casefold()=='ipeds'
            and re.match(
                r'\s+ID\b',
                (evidence_text or '')[token_match.end():],
                re.IGNORECASE,
            )
        ):
            continue
        elif token and token not in unresolved:
            unresolved.append(token)
    return requested,unresolved

def approval_grade_description_key_tokens(evidence_text,header):
    """Return a description-backed key only when every named token resolves."""
    resolved,unresolved=exact_description_key_tokens(evidence_text,header)
    candidate=(
        resolved
        if (
            not unresolved
            and len(resolved)>1
            and any(name.casefold()=='unitid' for name in resolved)
        )
        else []
    )
    return candidate,resolved,unresolved

def exact_description_key_substitution(
    key_columns,
    missing_columns,
    evidence_text,
    header,
    metadata_by_column,
):
    """Replace one missing key field only from a complete exact description."""
    candidate,_,_=approval_grade_description_key_tokens(
        evidence_text,
        header,
    )
    if not candidate or len(missing_columns)!=1:
        return None
    existing={name.casefold() for name in key_columns}
    alternatives=[
        name
        for name in candidate
        if (
            name.casefold()!='unitid'
            and name.casefold() not in existing
            and len(metadata_by_column.get(name.casefold(),[]))==1
        )
    ]
    missing_name=missing_columns[0].casefold()
    if (
        len(alternatives)!=1
        or missing_name not in existing
    ):
        return None
    return [
        alternatives[0] if name.casefold()==missing_name else name
        for name in key_columns
    ]

def approval_grade_metadata_status(resolution_kind):
    """Collapse reviewed provenance into the required match-status vocabulary."""
    statuses={
        'singular_exact':'exact',
        'reviewed_override':'exact',
        'reviewed_alias':'exact',
        'multiple':'multiple',
        'missing':'missing',
        'not_applicable':'not_applicable',
    }
    try:
        return statuses[resolution_kind]
    except KeyError as exc:
        raise ValueError(
            f'unsupported metadata resolution kind: {resolution_kind}'
        ) from exc

def match_filenames_metadata(access_table_name, metadata_rows, expected_file_number=""):
    """Resolve annual FILENAMES rows without promoting lossy name matches."""
    exact_name = [
        row
        for row in metadata_rows
        if val(row, "fileName").strip().casefold() == access_table_name.strip().casefold()
    ]
    candidates = exact_name
    if expected_file_number and exact_name:
        candidates = [
            row
            for row in exact_name
            if normalized_number(val(row, "FileNumber"))
            == normalized_number(expected_file_number)
        ]
        if not candidates:
            return "identity_conflict", None, exact_name
    if len(candidates) == 1:
        return "exact", candidates[0], candidates
    if len(candidates) > 1:
        return "multiple", None, candidates

    normalized_name = diagnostic_table_name(access_table_name)
    normalized_candidates = [
        row
        for row in metadata_rows
        if diagnostic_table_name(val(row, "fileName")) == normalized_name
    ]
    if normalized_candidates:
        return "normalized_diagnostic_only", None, normalized_candidates
    return "missing", None, []

def serialized_unique_index_keys(serialized):
    keys=[]
    for item in (serialized or '').split(' || '):
        if not item:
            continue
        if '=' not in item:
            raise ValueError(f'malformed serialized unique index evidence: {item}')
        _,columns=item.split('=',1)
        key=tuple(column for column in columns.split('|') if column)
        if not key:
            raise ValueError(f'empty serialized unique index evidence: {item}')
        keys.append(key)
    return keys

def reviewed_aliases(contract_path=None):
    rows=read(contract_path or ROOT/'contracts/source_metadata_aliases.csv')
    aliases={}
    for row_number,row in enumerate(rows,2):
        required=(
            'contract_id','decision_id','year','source_file',
            'source_access_table_name','source_varname',
            'selected_access_table_name','selected_file_number',
            'selected_source_varnumber','selected_varname',
            'selected_metadata_source','selected_metadata_table_name',
            'evidence','justification','review_status','reviewer','review_date',
        )
        missing=[name for name in required if not row.get(name,'').strip()]
        if missing:
            raise ValueError(
                f"source metadata alias row {row_number} is incomplete: "
                +'|'.join(missing)
            )
        if row['contract_id']!=CONTRACT_ID:
            raise ValueError(
                f"source metadata alias {row['decision_id']} has wrong contract_id: "
                f"{row['contract_id']}"
            )
        if not re.fullmatch(r'\d{4}',row['year']):
            raise ValueError(
                f"source metadata alias {row['decision_id']} has invalid year: "
                f"{row['year']}"
            )
        if row.get('review_status')!='approved' or not row.get('reviewer') or not row.get('review_date'):
            raise ValueError(f"unapproved source metadata alias: {row.get('decision_id','')}")
        if row.get('source_varname','').casefold()!=row.get('selected_varname','').casefold():
            raise ValueError(f"source/selected variable mismatch: {row.get('decision_id','')}")
        key=(row['year'],row['source_access_table_name'].strip().casefold(),row['source_varname'].strip().casefold())
        if key in aliases:
            raise ValueError(f'duplicate source metadata alias: {key}')
        aliases[key]=row
    return aliases

def validate_reviewed_alias_source(alias,source_row):
    """Bind a reviewed metadata alias to its exact source-column scope."""
    label=alias.get('decision_id','<unknown>')
    if alias.get('contract_id')!=CONTRACT_ID:
        raise ValueError(f'source metadata alias {label} has wrong contract_id')
    if source_row.get('contract_id')!=CONTRACT_ID:
        raise ValueError(
            f'source metadata alias {label} source row has wrong contract_id'
        )
    if source_row.get('year','')!=alias.get('year',''):
        raise ValueError(f'source metadata alias {label} source year mismatch')
    if (
        source_row.get('access_table_name','').strip().casefold()
        !=alias.get('source_access_table_name','').strip().casefold()
        or source_row.get('column_name','').strip().casefold()
        !=alias.get('source_varname','').strip().casefold()
    ):
        raise ValueError(
            f'source metadata alias {label} physical table/column identity mismatch'
        )
    if (
        source_row.get('normalized_table_name','').strip().casefold()
        !=alias.get('source_file','').strip().casefold()
    ):
        raise ValueError(
            f'source metadata alias {label} source_file family does not match '
            f"{source_row.get('normalized_table_name','')}"
        )

def reviewed_dictionary_overrides():
    overrides={}
    for row in read(ROOT/'contracts/dictionary_ambiguity_overrides.csv'):
        if row.get('review_status')!='approved':
            continue
        required=(
            'contract_id','year_start','year_end','source_file','access_table_name',
            'varname','selected_source_varnumber','selected_metadata_source',
            'selected_metadata_table_name','evidence','justification','reviewer','review_date',
        )
        missing=[name for name in required if not row.get(name,'').strip()]
        if missing:
            raise ValueError(
                f"approved dictionary override is incomplete ({'|'.join(missing)})"
            )
        if row['contract_id']!=CONTRACT_ID:
            raise ValueError(
                f"approved dictionary override has wrong contract_id: {row['contract_id']}"
            )
        if (
            not re.fullmatch(r'\d{4}',row['year_start'])
            or not re.fullmatch(r'\d{4}',row['year_end'])
            or int(row['year_start'])>int(row['year_end'])
        ):
            raise ValueError(
                f"approved dictionary override has invalid year range: "
                f"{row['year_start']}..{row['year_end']}"
            )
        for year in range(int(row['year_start']),int(row['year_end'])+1):
            key=(
                str(year),
                row['source_file'].strip().casefold(),
                row['access_table_name'].strip().casefold(),
                row['varname'].strip().casefold(),
            )
            if key in overrides:
                raise ValueError(f'duplicate reviewed dictionary override: {key}')
            overrides[key]=row
    return overrides

def exact_override_metadata(override, candidates):
    expected_candidate_count=int(override.get('_expected_candidate_count','2'))
    if len(candidates)!=expected_candidate_count:
        raise ValueError(
            f"reviewed dictionary override "
            f"{override['access_table_name']}.{override['varname']} candidate count "
            f"drifted: expected {expected_candidate_count}, observed {len(candidates)}"
        )
    matches=[
        row
        for row in candidates
        if val(row,'TableName').strip().casefold()
        == override['access_table_name'].strip().casefold()
        and val(row,'VarName').strip().casefold()
        == override['varname'].strip().casefold()
        and normalized_number(val(row,'VarNumber'))
        == normalized_number(override['selected_source_varnumber'])
        and row.get('_metadata_source','').strip().casefold()
        == override['selected_metadata_source'].strip().casefold()
        and row.get('_metadata_table_name','').strip().casefold()
        == override['selected_metadata_table_name'].strip().casefold()
    ]
    if len(matches)!=1:
        raise ValueError(
            f"reviewed dictionary override "
            f"{override['access_table_name']}.{override['varname']} "
            f"resolved to {len(matches)} exact metadata rows"
        )
    return matches[0]

def resolve_stage04_source_candidate_provenance(
    contract_path,
    *,
    provenance_root=None,
    expected_author_receipt_sha256=None,
):
    """Resolve the one signed Stage04 source-candidate hash without guessing."""
    repository=Path(provenance_root or ROOT).absolute()
    expected_receipt=require_sha256(
        expected_author_receipt_sha256 or SIGNED_AUTHOR_RECEIPT_SHA256,
        'expected signed author receipt SHA-256',
    )
    receipt_path=safe_repo_file(
        repository,
        SIGNED_AUTHOR_RECEIPT_RELATIVE.as_posix(),
        'signed author receipt',
    )
    if sha(receipt_path)!=expected_receipt:
        raise ValueError('signed author receipt SHA-256 mismatch')
    receipt=unique_row(
        exact_csv_rows(
            receipt_path,
            AUTHOR_RECEIPT_FIELDS,
            'signed author receipt',
        ),
        'signed author receipt',
    )
    required_receipt_values={
        'authorization_id':SIGNED_AUTHORIZATION_ID,
        'contract_id':CONTRACT_ID,
        'author_name':SIGNED_AUTHOR_NAME,
        'author_date':SIGNED_AUTHOR_DATE,
        'decision':'authorize_exact_canonical_application_only',
        'source_channel':'codex_user_message',
        'receipt_status':'verified_exact_author_countersign',
    }
    for field,expected in required_receipt_values.items():
        if receipt.get(field)!=expected:
            raise ValueError(f'signed author receipt {field} mismatch')
    statement_sha256=hashlib.sha256(
        canonicalize_statement(receipt.get('verbatim_statement','')).encode(
            'utf-8'
        )
    ).hexdigest()
    if statement_sha256!=receipt.get('canonicalized_statement_sha256',''):
        raise ValueError('signed author receipt statement SHA-256 mismatch')
    register_sha256=require_sha256(
        receipt.get('register_sha256',''),
        'signed author receipt register SHA-256',
    )
    scope_sha256=require_sha256(
        receipt.get('scope_sha256',''),
        'signed author receipt scope SHA-256',
    )
    transitive_target_sha256=require_sha256(
        receipt.get('transitive_target_sha256',''),
        'signed author receipt transitive target SHA-256',
    )

    package_prefix=FINAL_AUTHOR_PACKAGE_RELATIVE.as_posix()
    scope_path=safe_repo_file(
        repository,
        f'{package_prefix}/CANONICAL_APPLICATION_SCOPE.csv',
        'signed canonical application scope',
    )
    if sha(scope_path)!=scope_sha256:
        raise ValueError('signed canonical application scope SHA-256 mismatch')
    scope_rows=exact_csv_rows(
        scope_path,
        SCOPE_FIELDS,
        'signed canonical application scope',
    )
    if (
        len(scope_rows)!=7
        or {row.get('block_id') for row in scope_rows}
        != {f'B{number:02d}' for number in range(3,10)}
    ):
        raise ValueError(
            'signed canonical application scope is not the exact B03-B09 set'
        )
    b04=unique_row(
        [row for row in scope_rows if row.get('block_id')=='B04'],
        'signed B04 application scope',
    )
    if (
        b04.get('contract_id')!=CONTRACT_ID
        or b04.get('canonical_path')!='contracts/source_columns.csv'
        or b04.get('application_mode')!='replace_exact_bytes'
        or b04.get('readiness_status')!='author_ready'
    ):
        raise ValueError('signed B04 application scope identity mismatch')
    canonical_contract=safe_repo_file(
        repository,
        b04['canonical_path'],
        'signed B04 canonical contract',
    )
    explicit_contract=require_explicit_file(
        contract_path,
        'reviewed source-role contract',
    )
    if canonical_contract.resolve()!=explicit_contract.resolve():
        raise ValueError(
            'Stage04 reviewed roles must load the signed canonical contract'
        )
    contract_sha256=sha(explicit_contract)
    if (
        require_sha256(
            b04.get('final_candidate_sha256',''),
            'signed B04 final candidate SHA-256',
        )
        !=contract_sha256
        or require_sha256(
            b04.get('expected_post_sha256',''),
            'signed B04 expected post SHA-256',
        )
        !=contract_sha256
    ):
        raise ValueError('signed B04 canonical contract SHA-256 mismatch')
    if (
        not b04.get('row_count','').isdigit()
        or exact_csv_data_row_count(
            explicit_contract,
            'signed B04 canonical contract',
        )
        !=int(b04['row_count'])
    ):
        raise ValueError('signed B04 canonical contract row count mismatch')

    child_register=safe_repo_file(
        repository,
        b04.get('child_decision_register_path',''),
        'signed B04 child decision register',
    )
    if sha(child_register)!=require_sha256(
        b04.get('child_decision_register_sha256',''),
        'signed B04 child decision register SHA-256',
    ):
        raise ValueError('signed B04 child decision register SHA-256 mismatch')
    artifact_manifest=safe_repo_file(
        repository,
        b04.get('evidence_manifest_path',''),
        'signed Stage04 artifact manifest',
    )
    artifact_manifest_sha256=require_sha256(
        b04.get('evidence_manifest_sha256',''),
        'signed Stage04 artifact manifest SHA-256',
    )
    if sha(artifact_manifest)!=artifact_manifest_sha256:
        raise ValueError('signed Stage04 artifact manifest SHA-256 mismatch')
    input_manifest=safe_repo_file(
        repository,
        b04.get('input_manifest_path',''),
        'signed Stage04 input manifest',
    )
    input_manifest_sha256=require_sha256(
        b04.get('input_manifest_sha256',''),
        'signed Stage04 input manifest SHA-256',
    )
    if sha(input_manifest)!=input_manifest_sha256:
        raise ValueError('signed Stage04 input manifest SHA-256 mismatch')

    artifact_rows=exact_csv_rows(
        artifact_manifest,
        STAGE04_ARTIFACT_FIELDS,
        'signed Stage04 artifact manifest',
    )
    input_binding=unique_row(
        [
            row for row in artifact_rows
            if row.get('path')=='STAGE04_PROJECTION_INPUT_MANIFEST.csv'
            and row.get('artifact_role')=='input_hash_binding'
        ],
        'signed Stage04 input-manifest artifact binding',
    )
    projection_binding=unique_row(
        [
            row for row in artifact_rows
            if row.get('path')=='source_columns_contract_projection.csv'
            and row.get('artifact_role')=='compact_source_columns_projection'
        ],
        'signed Stage04 source-column projection binding',
    )
    for binding,label,bound_path in (
        (
            input_binding,
            'signed Stage04 input-manifest artifact binding',
            input_manifest,
        ),
        (
            projection_binding,
            'signed Stage04 source-column projection binding',
            artifact_manifest.parent/'source_columns_contract_projection.csv',
        ),
    ):
        bound_file=require_explicit_file(bound_path,label)
        if (
            require_sha256(binding.get('sha256',''),f'{label} SHA-256')
            !=sha(bound_file)
            or not binding.get('byte_size','').isdigit()
            or int(binding['byte_size'])!=bound_file.stat().st_size
            or not binding.get('row_count','').isdigit()
            or int(binding['row_count'])
            !=exact_csv_data_row_count(bound_file,label)
            or require_sha256(
                binding.get('input_manifest_sha256',''),
                f'{label} input-manifest SHA-256',
            )
            !=input_manifest_sha256
        ):
            raise ValueError(f'{label} content mismatch')

    input_rows=exact_csv_rows(
        input_manifest,
        STAGE04_INPUT_FIELDS,
        'signed Stage04 input manifest',
    )
    source_candidate=unique_row(
        [
            row for row in input_rows
            if row.get('input_role')=='stage04_source_candidate'
        ],
        'signed Stage04 source-candidate input binding',
    )
    if (
        source_candidate.get('path')!='source_columns_stage04_candidate.csv'
        or not source_candidate.get('byte_size','').isdigit()
        or int(source_candidate['byte_size'])<=0
        or not source_candidate.get('row_count','').isdigit()
        or int(source_candidate['row_count'])<=0
    ):
        raise ValueError('signed Stage04 source-candidate identity mismatch')
    source_candidate_sha256=require_sha256(
        source_candidate.get('sha256',''),
        'signed Stage04 source-candidate SHA-256',
    )

    transitive_path=safe_repo_file(
        repository,
        f'{package_prefix}/TRANSITIVE_REVIEW_TARGET_DIGEST.json',
        'signed transitive review-target digest',
    )
    transitive=load_json_without_duplicate_keys(
        transitive_path,
        'signed transitive review-target digest',
    )
    members=transitive.get('members')
    if not isinstance(members,dict) or not members:
        raise ValueError('signed transitive review-target members are missing')
    normalized_members={}
    for member,digest in members.items():
        if not isinstance(member,str) or not isinstance(digest,str):
            raise ValueError(
                'signed transitive review-target member is not textual'
            )
        normalized_members[member]=require_sha256(
            digest,
            f'signed transitive member {member}',
        )
    if (
        transitive.get('authorization_id')!=SIGNED_AUTHORIZATION_ID
        or transitive.get('contract_id')!=CONTRACT_ID
        or transitive.get('author_name')!=SIGNED_AUTHOR_NAME
        or transitive.get('author_date')!=SIGNED_AUTHOR_DATE
        or transitive.get('status')!='author_ready_pending_countersign'
        or transitive.get('member_count')!=len(normalized_members)
        or transitive.get('transitive_review_target_sha256')
        !=transitive_target_sha256
        or canonical_json_sha256(normalized_members)
        !=transitive_target_sha256
    ):
        raise ValueError('signed transitive review-target digest mismatch')
    projection_sha256=sha(
        artifact_manifest.parent/'source_columns_contract_projection.csv'
    )
    required_transitive_members={
        'output/CANONICAL_APPLICATION_SCOPE.csv':(
            scope_sha256,
            'canonical application scope',
        ),
        f"output/{b04['final_candidate_path']}":(
            contract_sha256,
            'canonical candidate',
        ),
        f"repository/{b04['evidence_manifest_path']}":(
            artifact_manifest_sha256,
            'Stage04 artifact manifest',
        ),
        f"repository/{b04['input_manifest_path']}":(
            input_manifest_sha256,
            'Stage04 input manifest',
        ),
        f"repository/{b04['child_decision_register_path']}":(
            sha(child_register),
            'child decision register',
        ),
        'stage04/STAGE04_PROJECTION_INPUT_MANIFEST.csv':(
            input_manifest_sha256,
            'Stage04 input manifest',
        ),
        'stage04/source_columns_contract_projection.csv':(
            projection_sha256,
            'Stage04 source-column projection',
        ),
    }
    for member,(expected,label) in required_transitive_members.items():
        if normalized_members.get(member)!=expected:
            raise ValueError(
                f'signed transitive {label} member mismatch: {member}'
            )

    register_path=safe_repo_file(
        repository,
        f'{package_prefix}/AUTHOR_DECISION_REGISTER.csv',
        'signed author decision register',
    )
    if sha(register_path)!=register_sha256:
        raise ValueError('signed author decision register SHA-256 mismatch')
    register=unique_row(
        exact_csv_rows(
            register_path,
            AUTHOR_REGISTER_FIELDS,
            'signed author decision register',
        ),
        'signed author decision register',
    )
    required_register_values={
        'authorization_id':SIGNED_AUTHORIZATION_ID,
        'contract_id':CONTRACT_ID,
        'scope_manifest_path':'CANONICAL_APPLICATION_SCOPE.csv',
        'scope_manifest_sha256':scope_sha256,
        'scope_row_count':'7',
        'transitive_review_target_digest_path':(
            'TRANSITIVE_REVIEW_TARGET_DIGEST.json'
        ),
        'transitive_review_target_digest_sha256':sha(transitive_path),
        'transitive_review_target_sha256':transitive_target_sha256,
        'requested_action':'authorize_exact_canonical_application_only',
        'allowed_decisions':(
            'authorize_exact_canonical_application_only|reject|'
            'request_more_evidence'
        ),
        'decision_status':'pending_author_countersign',
        'author_name':SIGNED_AUTHOR_NAME,
        'author_date':SIGNED_AUTHOR_DATE,
        'release_boundary':'FULL_BUILD_NOT_RUN|RELEASE_STILL_BLOCKED',
    }
    for field,expected in required_register_values.items():
        if register.get(field)!=expected:
            raise ValueError(f'signed author decision register {field} mismatch')
    return source_candidate_sha256

def reviewed_source_roles(
    contract_path=None,
    *,
    provenance_root=None,
    expected_author_receipt_sha256=None,
):
    role_map={
        'identifier':'identifier',
        'metadata':'administrative_field',
        'excluded':'intentionally_excluded',
        'dimension':'dimension',
        'measure':'measure_candidate',
    }
    roles={}
    path=contract_path or ROOT/'contracts/source_columns.csv'
    contract_rows=read(path)
    parsed_rows=[]
    needs_stage04_provenance=False
    for row_number,row in enumerate(contract_rows,2):
        required=(
            'contract_id','decision_id','year_start','year_end','source_file',
            'access_table_pattern','column_name','role','source_evidence',
            'review_note','reviewed',
        )
        missing=[name for name in required if not row.get(name,'').strip()]
        if missing:
            raise ValueError(
                f"reviewed source role row {row_number} is incomplete: "
                +'|'.join(missing)
            )
        if row['contract_id']!=CONTRACT_ID:
            raise ValueError(
                f"reviewed source role {row['decision_id']} has wrong contract_id: "
                f"{row['contract_id']}"
            )
        if row['reviewed'].strip().casefold()!='true':
            raise ValueError(
                f"source role {row['decision_id']} is not reviewed"
            )
        if row.get('role') not in role_map:
            raise ValueError(f"unsupported reviewed source role: {row.get('role','')}")
        if (
            not re.fullmatch(r'\d{4}',row['year_start'])
            or not re.fullmatch(r'\d{4}',row['year_end'])
            or int(row['year_start'])>int(row['year_end'])
        ):
            raise ValueError(
                f"reviewed source role {row['decision_id']} has invalid year range: "
                f"{row['year_start']}..{row['year_end']}"
            )
        direct_source_hashes=re.findall(
            r'(?i)\bsource CSV SHA-256\s+([0-9a-f]{64})\b',
            row['source_evidence'],
        )
        stage04_source_hashes=re.findall(
            (
                r'(?i)\bExact Stage04 source-column candidate SHA-256\s+'
                r'([0-9a-f]{64})\b'
            ),
            row['source_evidence'],
        )
        if len(direct_source_hashes)==1 and not stage04_source_hashes:
            mode='direct_source_csv'
            evidence_sha256=direct_source_hashes[0].lower()
        elif len(stage04_source_hashes)==1 and not direct_source_hashes:
            mode='stage04_source_candidate'
            evidence_sha256=stage04_source_hashes[0].lower()
            needs_stage04_provenance=True
        else:
            raise ValueError(
                f"reviewed source role {row['decision_id']} must contain "
                "exactly one labeled source CSV SHA-256 or exactly one "
                "labeled provenance SHA-256"
            )
        parsed_rows.append((row,mode,evidence_sha256))

    signed_stage04_sha256=None
    if needs_stage04_provenance:
        signed_stage04_sha256=resolve_stage04_source_candidate_provenance(
            path,
            provenance_root=provenance_root,
            expected_author_receipt_sha256=(
                expected_author_receipt_sha256
            ),
        )
    for row,mode,evidence_sha256 in parsed_rows:
        if (
            mode=='stage04_source_candidate'
            and evidence_sha256!=signed_stage04_sha256
        ):
            raise ValueError(
                f"reviewed source role {row['decision_id']} Stage04 "
                "source-candidate SHA-256 mismatch"
            )
        for year in range(int(row['year_start']),int(row['year_end'])+1):
            pattern=row['access_table_pattern'].strip().casefold()
            if pattern=='*':
                key=(
                    str(year),
                    '*',
                    row['source_file'].strip().casefold(),
                    row['column_name'].strip().casefold(),
                )
            else:
                key=(
                    str(year),
                    pattern,
                    row['column_name'].strip().casefold(),
                )
            if key in roles:
                raise ValueError(f'duplicate reviewed source role: {key}')
            roles[key]={
                **row,
                'candidate_role':role_map[row['role']],
                '_provenance_mode':mode,
                '_source_csv_sha256':(
                    evidence_sha256 if mode=='direct_source_csv' else ''
                ),
                '_stage04_source_candidate_sha256':(
                    evidence_sha256
                    if mode=='stage04_source_candidate'
                    else ''
                ),
            }
    return roles

def validate_reviewed_source_role(decision,source_row,actual_source_sha256):
    """Bind a reviewed role to the exact input identity and physical CSV."""
    label=decision.get('decision_id','<unknown>')
    if decision.get('contract_id')!=CONTRACT_ID:
        raise ValueError(f'reviewed source role {label} has wrong contract_id')
    if source_row.get('contract_id')!=CONTRACT_ID:
        raise ValueError(
            f'reviewed source role {label} source row has wrong contract_id'
        )
    year=source_row.get('year','')
    if (
        not year.isdigit()
        or int(year)<int(decision['year_start'])
        or int(year)>int(decision['year_end'])
    ):
        raise ValueError(
            f'reviewed source role {label} does not cover source year {year}'
        )
    pattern=decision.get('access_table_pattern','').strip().casefold()
    source_table=source_row.get(
        'access_table_name',''
    ).strip().casefold()
    if (
        (pattern!='*' and source_table!=pattern)
        or source_row.get('column_name','').strip().casefold()
        !=decision.get('column_name','').strip().casefold()
    ):
        raise ValueError(
            f'reviewed source role {label} physical table/column identity mismatch'
        )
    if (
        source_row.get('normalized_table_name','').strip().casefold()
        !=decision.get('source_file','').strip().casefold()
    ):
        raise ValueError(
            f'reviewed source role {label} source_file family does not match '
            f"{source_row.get('normalized_table_name','')}"
        )
    observed_hash=(actual_source_sha256 or '').strip().lower()
    if not SHA256_RE.fullmatch(observed_hash):
        raise ValueError(
            f'reviewed source role {label} source CSV SHA-256 mismatch: '
            f'observed {observed_hash or "<missing>"} is not an exact SHA-256'
        )
    mode=decision.get('_provenance_mode','').strip()
    if not mode and decision.get('_source_csv_sha256'):
        mode='direct_source_csv'
    if mode=='direct_source_csv':
        expected_hash=decision.get('_source_csv_sha256','').strip().lower()
        if (
            not SHA256_RE.fullmatch(expected_hash)
            or observed_hash!=expected_hash
        ):
            raise ValueError(
                f'reviewed source role {label} source CSV SHA-256 mismatch: '
                f'expected {expected_hash or "<missing>"}, '
                f'observed {observed_hash}'
            )
    elif mode=='stage04_source_candidate':
        expected_hash=decision.get(
            '_stage04_source_candidate_sha256',''
        ).strip().lower()
        evidence_hashes=re.findall(
            (
                r'(?i)\bExact Stage04 source-column candidate SHA-256\s+'
                r'([0-9a-f]{64})\b'
            ),
            decision.get('source_evidence',''),
        )
        if (
            not SHA256_RE.fullmatch(expected_hash)
            or len(evidence_hashes)!=1
            or evidence_hashes[0].lower()!=expected_hash
        ):
            raise ValueError(
                f'reviewed source role {label} Stage04 provenance mismatch'
            )
    else:
        raise ValueError(
            f'reviewed source role {label} has unsupported provenance mode'
        )

def reviewed_source_role_for_row(roles,source_row):
    """Resolve one exact-table or signed family-wildcard role."""
    year=source_row.get('year','')
    column=source_row.get('column_name','').strip().casefold()
    exact_key=(
        year,
        source_row.get('access_table_name','').strip().casefold(),
        column,
    )
    wildcard_key=(
        year,
        '*',
        source_row.get('normalized_table_name','').strip().casefold(),
        column,
    )
    matches=[
        (key,roles[key])
        for key in (exact_key,wildcard_key)
        if key in roles
    ]
    if len(matches)>1:
        raise ValueError(
            'multiple reviewed source roles bind source identity: '
            f'{year}:{source_row.get("access_table_name","")}.'
            f'{source_row.get("column_name","")}'
        )
    return matches[0] if matches else (None,None)

def record_reviewed_source_role_application(
    role_key,
    source_row,
    applied_role_keys,
    applied_column_identities,
):
    """Record family-role use while rejecting duplicate physical columns."""
    column_identity=(
        source_row.get('year',''),
        source_row.get('access_table_name','').strip().casefold(),
        source_row.get('column_name','').strip().casefold(),
    )
    if column_identity in applied_column_identities:
        raise ValueError(
            f'duplicate source column evidence identity: {column_identity}'
        )
    applied_column_identities.add(column_identity)
    applied_role_keys.add(role_key)

def assert_reviewed_source_roles_consumed(
    roles,
    applied_keys,
    input_table_identities,
):
    """Require every reviewed role for an input table to bind to one column."""
    def input_contains_role(key):
        if len(key)==3:
            return any(
                len(identity)>=2
                and identity[0]==key[0]
                and identity[1]==key[1]
                for identity in input_table_identities
            )
        if len(key)==4 and key[1]=='*':
            return any(
                len(identity)>=3
                and identity[0]==key[0]
                and identity[2]==key[2]
                for identity in input_table_identities
            )
        raise ValueError(f'unsupported reviewed source role key: {key}')
    expected={
        key
        for key in roles
        if input_contains_role(key)
    }
    missing=sorted(expected-set(applied_keys))
    if missing:
        labels=[
            f"{roles[key].get('decision_id','')}:"+':'.join(key)
            for key in missing
        ]
        raise ValueError(
            'reviewed source role scopes were not applied: '+'|'.join(labels)
        )

def exact_alias_metadata(alias, varmeta):
    matches=[
        row for row in varmeta.get(
            (
                alias['year'],
                alias['selected_access_table_name'].strip().casefold(),
                alias['selected_varname'].strip().casefold(),
            ),
            [],
        )
        if normalized_number(val(row,'FileNumber'))==normalized_number(alias['selected_file_number'])
        and normalized_number(val(row,'VarNumber'))==normalized_number(alias['selected_source_varnumber'])
        and val(row,'TableName').strip().casefold()==alias['selected_access_table_name'].strip().casefold()
        and val(row,'VarName').strip().casefold()==alias['selected_varname'].strip().casefold()
        and row.get('_metadata_source','').strip().casefold()
        == alias['selected_metadata_source'].strip().casefold()
        and row.get('_metadata_table_name','').strip().casefold()
        == alias['selected_metadata_table_name'].strip().casefold()
    ]
    if len(matches)!=1:
        raise ValueError(
            f"reviewed alias {alias['source_access_table_name']}.{alias['source_varname']} "
            f"resolved to {len(matches)} exact metadata rows"
        )
    return matches[0]

def table_meta(legacy_root, year, table):
    files=sorted((legacy_root/'Raw_Access_Databases'/str(year)/'tables_csv').glob('Tables*.csv'))
    rows=[]
    for f in files:
        rows += [r for r in read(f) if r.get('TableName','').casefold()==table.casefold()]
    return rows

def validate_key(path, requested_columns):
    """Stream a source CSV and prove a candidate key without loading all rows."""
    seen=set(); duplicate_rows=0; null_rows=0; duplicate_samples=[]; null_samples=[]
    with path.open(newline='',encoding='utf-8-sig',errors='replace') as f:
        reader=csv.DictReader(f)
        actual={name.casefold():name for name in (reader.fieldnames or [])}
        missing=[name for name in requested_columns if name.casefold() not in actual]
        if missing:
            return {'tested':False,'missing':missing,'duplicates':0,'nulls':0,'duplicate_samples':[],'null_samples':[]}
        selected=[actual[name.casefold()] for name in requested_columns]
        for row_number,row in enumerate(reader,2):
            values=tuple((row.get(name) or '').strip() for name in selected)
            if any(value=='' for value in values):
                null_rows+=1
                if len(null_samples)<5:null_samples.append(f'{row_number}:'+repr(values))
                continue
            if values in seen:
                duplicate_rows+=1
                if len(duplicate_samples)<5:duplicate_samples.append(f'{row_number}:'+repr(values))
            else:
                seen.add(values)
    return {'tested':True,'missing':[],'duplicates':duplicate_rows,'nulls':null_rows,'duplicate_samples':duplicate_samples,'null_samples':null_samples}

def run(
    legacy_root: Path,
    out: Path,
    *,
    source_role_contract_path=None,
    provenance_root=None,
    expected_author_receipt_sha256=None,
):
    LEGACY=legacy_root.resolve()
    OUT=out.resolve()
    OUT.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix='ipedsdb-b03-b04-base-') as temporary_base:
        base_out=Path(temporary_base)
        build_base_profiles(LEGACY,base_out,CONTRACT_ID)
        base_tables=read(base_out/'table_grain_enriched.csv')
        base_columns=read(base_out/'source_column_enriched.csv')
    inv=[]
    for y in sorted((LEGACY/'Raw_Access_Databases').glob('20*')): inv += read(y/'metadata/table_inventory.csv')
    varmeta=defaultdict(list)
    for y in sorted((LEGACY/'Raw_Access_Databases').glob('20*')):
        for vp in sorted(list((y/'tables_csv').glob('vartable*.csv')) + list((y/'tables_csv').glob('varTable*.csv'))):
            for mr in read(vp):
                mr=dict(mr)
                mr['_metadata_table_name']=vp.stem
                mr['_metadata_source']='access_varlist'
                varmeta[(y.name,val(mr,'TableName').strip().casefold(),val(mr,'VarName').strip().casefold())].append(mr)
    schema_by_year={}
    inventory_by_year=defaultdict(list)
    for inventory_row in inv:
        inventory_by_year[inventory_row['year']].append(inventory_row)
    for year,year_inventory in sorted(inventory_by_year.items()):
        access_db_files=sorted({
            row.get('access_db_file','').strip()
            for row in year_inventory
            if row.get('access_db_file','').strip()
        })
        if not access_db_files:
            schema_by_year[year]={
                'status':'schema_probe_input_missing',
                'reason':'Annual table inventory has no access_db_file identity.',
            }
            continue
        if len(access_db_files)!=1:
            schema_by_year[year]={
                'status':'schema_probe_input_ambiguous',
                'reason':(
                    'Annual table inventory names multiple Access databases: '
                    +'|'.join(access_db_files)
                ),
            }
            continue
        try:
            database_path=resolve_annual_access_database(
                LEGACY/'Raw_Access_Databases'/year/'extracted_db',
                access_db_files[0],
            )
            probe=probe_annual_schema(database_path)
        except SchemaEvidenceError as exc:
            schema_by_year[year]={'status':exc.status,'reason':exc.reason}
            continue
        try:
            database_reference=str(Path(probe.database_path).relative_to(LEGACY))
        except ValueError:
            database_reference=probe.database_path
        schema_by_year[year]={
            'probe':probe,
            'database_reference':database_reference,
        }
    old_by={(r['year'],r['access_table_name']):r for r in base_tables}
    base_fields=['contract_id','year','access_table_name','normalized_table_name','table_role','row_count','has_unitid','distinct_unitid','duplicate_unitid_rows','unitids_with_multiple_rows','zero_row_table','source_csv_sha256','source_schema_sha256','schema_evidence_scope','source_database_sha256','schema_probe_command','schema_tool_version','declared_primary_key','declared_unique_indexes','declared_nonunique_indexes','schema_key_parse_status','schema_key_parse_reason','file_number','table_catalog_match_status','table_catalog_table_number','table_catalog_file_number','table_title','table_description','legacy_multi_record','filenames_match_status','filenames_file_number','filenames_candidate_identities','multi_record','qualifying_field_1','qualifying_field_2','qualifying_field_3','qualifying_field_1_type','qualifying_field_2_type','qualifying_field_3_type','declared_key_source','declared_key_text','declared_key_columns','candidate_dimension_columns','candidate_minimal_key','duplicate_rows_on_candidate_key','null_rows_on_candidate_key','candidate_key_test_status','candidate_grain','review_status','review_note','metadata_candidate_identities','table_metadata_match_status','matched_table_number','matched_file_number','matched_access_table_name','matched_table_metadata_row_count','metadata_join_reason']
    base_fields.insert(base_fields.index('zero_row_table'),'null_unitid_rows')
    fields=base_fields
    rows=[]; exceptions=[]; diagnostics=[]
    for i in inv:
        key=(i['year'],i['table_name']); r=dict(old_by[key]); m=table_meta(LEGACY,int(i['year']),i['table_name'])
        control = r.get('candidate_grain')=='metadata'
        r['table_role']='control' if control else 'data'
        r['has_unitid']=str(i.get('has_unitid','')).lower()
        for name in ('filenames_match_status','filenames_file_number','filenames_candidate_identities','multi_record','qualifying_field_1','qualifying_field_2','qualifying_field_3','qualifying_field_1_type','qualifying_field_2_type','qualifying_field_3_type','declared_key_source','declared_key_text','declared_key_columns','candidate_dimension_columns','candidate_minimal_key','duplicate_rows_on_candidate_key','null_rows_on_candidate_key','candidate_key_test_status'):
            r[name]=''
        if control: r['candidate_grain']='metadata'; r['table_metadata_match_status']='not_applicable'
        elif int(r.get('row_count','0') or 0)==0: r['candidate_grain']='unknown'
        elif str(i.get('has_unitid','')).casefold()=='true' and int(r.get('duplicate_unitid_rows','0') or 0)==0 and int(r.get('null_unitid_rows','0') or 0)==0: r['candidate_grain']='scalar'
        else: r['candidate_grain']='unknown'
        if int(r.get('row_count','0') or 0)==0 and not control:
            r['candidate_grain']='unknown'; r['candidate_minimal_key']=''; r['proposal_confidence']='mechanical_profile_only_zero_row_exception'
        exact=[x for x in m if x.get('Tablenumber','').strip()==i.get('file_number','').strip()] if i.get('file_number') else m
        if len(exact)==1: status='exact'; reason='year+exact Access table/FileNumber match' if i.get('file_number') else 'singular exact Access table match'; chosen=exact[0]
        elif len(exact)>1: status='multiple'; reason='multiple exact table metadata identities'; chosen={}
        else: status='missing'; reason='no exact annual Tables metadata identity'; chosen={}
        r.update({'table_metadata_match_status':'not_applicable' if control else status,'matched_table_number':chosen.get('Tablenumber',''),'matched_file_number':'','matched_access_table_name':chosen.get('TableName',''),'matched_table_metadata_row_count':len(exact),'metadata_join_reason':'not applicable control table' if control else reason,'metadata_candidate_identities':'|'.join(f"{x.get('TableName','')}:{x.get('Tablenumber','')}" for x in exact),'source_schema_sha256':''})
        if chosen:
            r.update({'file_number':'','table_title':chosen.get('TableTitle',''),'table_description':chosen.get('Description',''),'legacy_multi_record':chosen.get('MultiRecord',chosen.get('multiRecord',''))})
            r['table_catalog_match_status']='exact'
            r['table_catalog_table_number']=chosen.get('Tablenumber','')
            r['table_catalog_file_number']=''
        else:
            r['table_catalog_match_status']='not_applicable' if control else status
        schema_source=schema_by_year[i['year']]
        probe=schema_source.get('probe')
        if probe is None:
            r.update({
                'source_schema_sha256':'',
                'schema_evidence_scope':'unavailable',
                'source_database_sha256':'',
                'schema_probe_command':'',
                'schema_tool_version':'',
                'declared_primary_key':'',
                'declared_unique_indexes':'',
                'declared_nonunique_indexes':'',
                'schema_key_parse_status':schema_source['status'],
                'schema_key_parse_reason':schema_source['reason'],
            })
        else:
            try:
                schema_evidence=parse_table_schema_evidence(
                    probe.schema_bytes,
                    i['table_name'],
                    indexes_requested=True,
                )
            except SchemaEvidenceError as exc:
                schema_evidence={
                    'source_schema_sha256':probe.source_schema_sha256,
                    'declared_primary_key':'',
                    'declared_unique_indexes':'',
                    'declared_nonunique_indexes':'',
                    'schema_key_parse_status':exc.status,
                    'schema_key_parse_reason':exc.reason,
                }
            schema_evidence.update({
                'schema_evidence_scope':'annual_index_enabled',
                'source_database_sha256':probe.database_sha256,
                'schema_probe_command':(
                    'mdb-schema --indexes --not-null '
                    f"{schema_source['database_reference']} postgres"
                ),
                'schema_tool_version':probe.tool_version,
            })
            r.update(schema_evidence)
        if r.get('table_role')=='data':
            primary=tuple(
                column
                for column in r.get('declared_primary_key','').split('|')
                if column
            )
            unique_keys=serialized_unique_index_keys(
                r.get('declared_unique_indexes','')
            )
            distinct_unique=list(dict.fromkeys(unique_keys))
            declared_key=primary
            declared_source='Access primary key'
            if not declared_key and len(distinct_unique)==1:
                declared_key=distinct_unique[0]
                declared_source='Access unique index'
            if (
                declared_key
                and any(column.casefold()=='unitid' for column in declared_key)
            ):
                dimensions=[
                    column
                    for column in declared_key
                    if column.casefold()!='unitid'
                ]
                r['declared_key_source']=declared_source
                r['declared_key_text']='|'.join(declared_key)
                r['declared_key_columns']='|'.join(declared_key)
                r['candidate_dimension_columns']='|'.join(dimensions)
                r['candidate_minimal_key']='|'.join(declared_key)
                r['candidate_key_test_status']='candidate_unvalidated'
                if dimensions:
                    r['candidate_grain']='unknown'
        if int(r.get('row_count','0') or 0)==0: exceptions.append({**r,'exception':'zero_row_no_observed_values'})
        elif r.get('candidate_grain')=='unknown': exceptions.append({**r,'exception':'repeated_UNITID_no_proven_complete_key'})
        rows.append({k:r.get(k,'') for k in fields})
    # Enrich table rows from annual FILENAMES only when the Access table identity is exact.
    for r in rows:
        fp=find_casefold_exact_file(
            LEGACY/'Raw_Access_Databases'/r['year']/'tables_csv',
            'Filenames'+r['year'][-2:]+'.csv',
        )
        if fp is None: continue
        status, selected, candidates = match_filenames_metadata(
            r['access_table_name'],
            read(fp),
        )
        r['filenames_match_status']=status
        r['filenames_candidate_identities']='|'.join(
            f"{val(candidate,'fileName')}:{val(candidate,'FileNumber')}"
            for candidate in candidates
        )
        if selected is not None:
            fr=selected; r.update({'file_number':val(fr,'FileNumber'),'matched_file_number':val(fr,'FileNumber'),'filenames_file_number':val(fr,'FileNumber'),'multi_record':val(fr,'multiRecord'),'qualifying_field_1':val(fr,'qualifyingField1'),'qualifying_field_2':val(fr,'qualifyingField2'),'qualifying_field_3':val(fr,'qualifyingField3'),'qualifying_field_1_type':val(fr,'q1type'),'qualifying_field_2_type':val(fr,'q2type'),'qualifying_field_3_type':val(fr,'q3type')})
            dims=[x for x in [fr.get('qualifyingField1',''),fr.get('qualifyingField2',''),fr.get('qualifyingField3','')] if x]
            if dims and r.get('table_role')=='data' and not r.get('candidate_minimal_key'): r['candidate_dimension_columns']='|'.join(dims); r['candidate_minimal_key']='UNITID|'+'|'.join(dims); r['declared_key_source']='FILENAMES'; r['declared_key_text']='Annual FILENAMES qualifying fields'; r['declared_key_columns']=r['candidate_minimal_key']; r['candidate_key_test_status']='candidate_unvalidated'; r['candidate_grain']='unknown'
    diagnostics=[
        {
            k:r.get(k,'')
            for k in [
                'year','access_table_name','normalized_table_name',
                'table_metadata_match_status','matched_table_number',
                'matched_file_number','matched_access_table_name',
                'matched_table_metadata_row_count','metadata_join_reason',
                'metadata_candidate_identities',
            ]
        }
        for r in rows
    ]
    inv_path={(r['year'],r['table_name']):LEGACY/'Raw_Access_Databases'/r['year']/r['csv_path'] for r in inv}
    description_unresolved_tokens={}
    for r in rows:
        if r.get('candidate_dimension_columns') or r.get('table_role')!='data':
            continue
        description=r.get('table_description','')
        match=re.search(r'(?:(?:each\s+)?records?[^.]{0,180}?uniquely defined|unique(?:ly)? identified)[^.]*',description,re.I)
        if not match:
            continue
        csv_path=inv_path[(r['year'],r['access_table_name'])]
        with csv_path.open(newline='',encoding='utf-8-sig',errors='replace') as f:
            header=next(csv.reader(f),[])
        requested,resolved,unresolved=approval_grade_description_key_tokens(
            match.group(0),
            header,
        )
        if unresolved:
            description_unresolved_tokens[
                (r['year'],r['access_table_name'])
            ]=(match.group(0),resolved,unresolved)
        if requested:
            dimensions=[name for name in requested if name.casefold()!='unitid']
            r['declared_key_source']='table_description'
            r['declared_key_text']=match.group(0)
            r['declared_key_columns']='UNITID|'+'|'.join(dimensions)
            r['candidate_dimension_columns']='|'.join(dimensions)
            r['candidate_minimal_key']=r['declared_key_columns']
            r['candidate_key_test_status']='candidate_unvalidated'
            r['candidate_grain']='unknown'
    for r in rows:
        if r.get('candidate_dimension_columns') or r.get('table_role')!='data':
            continue
        csv_path=inv_path[(r['year'],r['access_table_name'])]
        with csv_path.open(newline='',encoding='utf-8-sig',errors='replace') as f:
            header=next(csv.reader(f),[])
        supported=[]
        evidence=[]
        for name in header:
            if name.casefold()=='unitid':
                continue
            metadata=varmeta.get((r['year'],r['access_table_name'].casefold(),name.casefold()),[])
            if len(metadata)!=1:
                continue
            semantic=' '.join((val(metadata[0],'VarTitle'),val(metadata[0],'LongDescription')))
            if re.search(r'\bunique\s+id\b|IPEDS ID of each comparison institution|identification number of each',semantic,re.I):
                supported.append(name)
                evidence.append(f'{name}:{semantic[:240]}')
        if supported:
            r['declared_key_source']='exact_variable_metadata'
            r['declared_key_text']=' || '.join(evidence)
            r['declared_key_columns']='UNITID|'+'|'.join(supported)
            r['candidate_dimension_columns']='|'.join(supported)
            r['candidate_minimal_key']=r['declared_key_columns']
            r['candidate_key_test_status']='candidate_unvalidated'
            r['candidate_grain']='unknown'
    key_results={}
    for r in rows:
        if int(r.get('row_count','0') or 0)==0 and r.get('candidate_minimal_key'):
            r['candidate_key_test_status']='zero_row_untestable'
            continue
        if not r.get('candidate_minimal_key'):
            continue
        key_columns=[
            column
            for column in r['candidate_minimal_key'].split('|')
            if column
        ]
        csv_path=inv_path[(r['year'],r['access_table_name'])]
        result=validate_key(csv_path,key_columns)
        if not result['tested'] and result['missing']:
            with csv_path.open(newline='',encoding='utf-8-sig') as f:
                header=next(csv.reader(f),[])
            description=r.get('table_description','')
            explicit=re.search(r'(?:uniquely defined|unique(?:ly)? identified)[^.]*',description,re.I)
            replacement=None
            if explicit:
                metadata_by_column={
                    name.casefold():varmeta.get(
                        (
                            r['year'],
                            r['access_table_name'].casefold(),
                            name.casefold(),
                        ),
                        [],
                    )
                    for name in header
                }
                replacement=exact_description_key_substitution(
                    key_columns,
                    result['missing'],
                    explicit.group(0),
                    header,
                    metadata_by_column,
                )
            if replacement is not None:
                key_columns=replacement
                r['candidate_dimension_columns']='|'.join(key_columns[1:])
                r['candidate_minimal_key']='|'.join(key_columns)
                r['declared_key_columns']=r['candidate_minimal_key']
                r['declared_key_source']=r.get('declared_key_source','FILENAMES')+'+description_vartable_resolution'
                result=validate_key(csv_path,key_columns)
        key_results[(r['year'],r['access_table_name'])]=result
        r['duplicate_rows_on_candidate_key']=result['duplicates']
        r['null_rows_on_candidate_key']=result['nulls']
        if not result['tested']:
            r['candidate_key_test_status']='missing_key_columns'
        elif result['duplicates']:
            r['candidate_key_test_status']='rejected_duplicates'
        elif result['nulls']:
            r['candidate_key_test_status']='rejected_nulls'
        else:
            r['candidate_key_test_status']='proven_complete'
            r['candidate_grain']='scalar' if len(key_columns)==1 else 'dimensioned'
    exceptions=[]
    for r in rows:
        if int(r.get('row_count','0') or 0)==0 and r.get('table_role')=='data':
            exceptions.append({**r,'exception':'zero_row_no_observed_values'})
        elif r.get('table_role')=='data' and r.get('candidate_grain')=='unknown':
            status=r.get('candidate_key_test_status') or 'no_evidence_backed_candidate_key'
            exceptions.append({**r,'exception':status})
    key_details=[]; key_dupes=[]; key_nulls=[]
    for r in rows:
        text=r.get('table_description','')
        m=re.search(r'(?:uniquely defined|unique(?:ly)? identified|primary key)[^.:]*?(UNITID[^.;:]*)',text,re.I)
        result=key_results.get((r['year'],r['access_table_name']),{})
        if r.get('candidate_minimal_key') and r.get('declared_key_source'):
            key_details.append({
                'year':r['year'],
                'access_table_name':r['access_table_name'],
                'candidate_key':r['candidate_minimal_key'],
                'evidence_source':r['declared_key_source'],
                'evidence_text':r.get('declared_key_text',''),
                'columns_present':r.get('candidate_dimension_columns',''),
                'duplicate_rows':result.get('duplicates',''),
                'null_key_rows':result.get('nulls',''),
                'tested':str(bool(result.get('tested'))).lower(),
                'accepted_as_candidate':str(r.get('candidate_key_test_status')=='proven_complete').lower(),
                'failure_reason':'' if r.get('candidate_key_test_status')=='proven_complete' else r.get('candidate_key_test_status','not_tested'),
            })
        if m and r.get('declared_key_source')!='table_description':
            cols=[c.strip().upper() for c in re.split(r',|\band\b',m.group(1),flags=re.I) if c.strip()]
            key='|'.join(dict.fromkeys(cols))
            key_details.append({
                'year':r['year'],
                'access_table_name':r['access_table_name'],
                'candidate_key':key,
                'evidence_source':'table_description',
                'evidence_text':m.group(0),
                'columns_present':'',
                'duplicate_rows':'',
                'null_key_rows':'',
                'tested':'false',
                'accepted_as_candidate':'false',
                'failure_reason':(
                    'superseded_by_stronger_declared_key'
                    if r.get('candidate_minimal_key')
                    else 'description_hint_not_resolved_to_complete_key'
                ),
            })
        unresolved_description=description_unresolved_tokens.get(
            (r['year'],r['access_table_name'])
        )
        if unresolved_description:
            evidence_text,resolved_tokens,unresolved_tokens=unresolved_description
            key_details.append({
                'year':r['year'],
                'access_table_name':r['access_table_name'],
                'candidate_key':'|'.join(resolved_tokens),
                'evidence_source':'table_description_exact_token_diagnostic',
                'evidence_text':evidence_text,
                'columns_present':'|'.join(resolved_tokens),
                'duplicate_rows':'',
                'null_key_rows':'',
                'tested':'false',
                'accepted_as_candidate':'false',
                'failure_reason':(
                    'unresolved_exact_description_tokens:'
                    +'|'.join(unresolved_tokens)
                ),
            })
        result=key_results.get((r['year'],r['access_table_name']))
        if result:
            for sample in result['duplicate_samples']:
                key_dupes.append({'year':r['year'],'access_table_name':r['access_table_name'],'candidate_key':r['candidate_minimal_key'],'sample':sample})
            for sample in result['null_samples']:
                key_nulls.append({'year':r['year'],'access_table_name':r['access_table_name'],'candidate_key':r['candidate_minimal_key'],'sample':sample})
    write(OUT/'table_key_candidate_details.csv',['year','access_table_name','candidate_key','evidence_source','evidence_text','columns_present','duplicate_rows','null_key_rows','tested','accepted_as_candidate','failure_reason'],key_details)
    write(OUT/'table_key_duplicate_samples.csv',['year','access_table_name','candidate_key','sample'],key_dupes); write(OUT/'table_key_null_samples.csv',['year','access_table_name','candidate_key','sample'],key_nulls)
    write(OUT/'table_grain_enriched.csv',fields,rows); write(OUT/'table_grain_exceptions.csv',fields+['exception'],exceptions); write(OUT/'table_metadata_join_diagnostics.csv',list(diagnostics[0]),diagnostics)
    fam=defaultdict(list)
    for r in rows:fam[r['normalized_table_name']].append(r)
    ff=['normalized_table_name','years_present','table_count','row_count_total','metadata_exact_count','metadata_multiple_count','metadata_missing_count','stable_declared_key','stable_proven_key','key_changed_across_years','unresolved_year_count','review_priority']
    fr=[]
    for n,rs in sorted(fam.items()):
        declared={x['declared_key_columns'] for x in rs if x['declared_key_columns']}
        proven={x['candidate_minimal_key'] for x in rs if x['candidate_key_test_status']=='proven_complete'}
        unresolved=sum(x['candidate_grain']=='unknown' and x['table_role']=='data' for x in rs)
        fr.append({'normalized_table_name':n,'years_present':'|'.join(sorted({x['year'] for x in rs})),'table_count':len(rs),'row_count_total':sum(int(x.get('row_count','0') or 0) for x in rs),'metadata_exact_count':sum(x['table_metadata_match_status']=='exact' for x in rs),'metadata_multiple_count':sum(x['table_metadata_match_status']=='multiple' for x in rs),'metadata_missing_count':sum(x['table_metadata_match_status']=='missing' for x in rs),'stable_declared_key':next(iter(declared)) if len(declared)==1 else '','stable_proven_key':next(iter(proven)) if len(proven)==1 else '','key_changed_across_years':'true' if len(proven)>1 else ('false' if len(proven)==1 else 'unknown'),'unresolved_year_count':unresolved,'review_priority':'high' if unresolved or len(proven)>1 else 'normal'})
    write(OUT/'table_family_summary.csv',ff,fr)
    write(OUT/'table_key_duplicate_samples.csv',['year','access_table_name','candidate_key','sample'],key_dupes); write(OUT/'table_key_null_samples.csv',['year','access_table_name','candidate_key','sample'],key_nulls)
    inv_sha={(r['year'],r['table_name']):r.get('csv_sha256','') for r in inv}
    source_base=['contract_id','year','access_table_name','normalized_table_name','file_number','table_role','candidate_table_grain','table_catalog_table_number','table_catalog_file_number','filenames_file_number','variable_metadata_file_number','ordinal_position','column_name','column_name_normalized','source_csv_sha256','nonempty_count','null_count','distinct_nonempty_count','example_nonempty_tokens','column_metadata_match_status','matched_file_number','matched_varnumber','matched_varname','matched_metadata_table_name','matched_metadata_source','matched_metadata_row_count','metadata_join_reason','metadata_candidate_identities','metadata_decision_source','metadata_decision_justification','data_type','format','field_width','var_title','long_description','code_label_count','candidate_role','role_evidence','role_decision_id','role_decision_source','role_decision_justification','unresolved_reason','imputation_flag_varname','imputation_flag_column_present','imputation_flag_metadata_present','imputation_link_status']
    cols=base_columns; cf=source_base
    grain_map={(r['year'],r['access_table_name']):r.get('candidate_grain','') for r in rows}
    table_role_map={(r['year'],r['access_table_name']):r.get('table_role','') for r in rows}
    table_file_number_map={
        (r['year'],r['access_table_name']):
        (r.get('filenames_file_number') or r.get('file_number'))
        for r in rows
    }
    table_number_map={
        (r['year'],r['access_table_name']):r.get('matched_table_number','')
        for r in rows
    }
    dimensions_map={(r['year'],r['access_table_name']):{c.casefold() for c in r.get('candidate_dimension_columns','').split('|') if c} for r in rows if r.get('candidate_grain')=='dimensioned'}
    headers_by_table=defaultdict(set)
    for r in cols: headers_by_table[(r['year'],r['access_table_name'])].add(r['column_name'].casefold())
    declared_flag_values=defaultdict(lambda:defaultdict(list))
    for (year,table,varname),matches in varmeta.items():
        if len(matches)==1 and val(matches[0],'ImputationVar').strip():
            declared_flag_values[(year,table)][val(matches[0],'ImputationVar').strip().casefold()].append(varname)
    aliases=reviewed_aliases()
    ambiguity_overrides=reviewed_dictionary_overrides()
    source_roles=reviewed_source_roles(
        source_role_contract_path,
        provenance_root=provenance_root,
        expected_author_receipt_sha256=expected_author_receipt_sha256,
    )
    input_table_identities={
        (
            r['year'],
            r['access_table_name'].strip().casefold(),
            r['normalized_table_name'].strip().casefold(),
        )
        for r in cols
    }
    applied_source_roles=set()
    applied_source_column_identities=set()
    crows=[]; cdiag=[]; cexc=[]; imputation_rows=[]; alias_candidates=[]; missing_2023=[]
    for r in cols:
        table_key=(r['year'],r['access_table_name'])
        column_key=(
            r['year'],
            r['access_table_name'].strip().casefold(),
            r['column_name'].strip().casefold(),
        )
        control = table_role_map.get(table_key)=='control'
        raw_vm=list(varmeta.get(column_key,[]))
        vm=list(raw_vm)
        override=ambiguity_overrides.get(
            (
                r['year'],
                r['normalized_table_name'].strip().casefold(),
                r['access_table_name'].strip().casefold(),
                r['column_name'].strip().casefold(),
            )
        )
        if control or r['column_name'].casefold()=='unitid':
            resolution_kind='not_applicable'
            vm=[]
        elif override is not None:
            vm=[exact_override_metadata(override,raw_vm)]
            resolution_kind='reviewed_override'
        elif len(vm)==1:
            resolution_kind='singular_exact'
        elif len(vm)>1:
            resolution_kind='multiple'
        else:
            resolution_kind='missing'

        alias=aliases.get(column_key) if resolution_kind=='missing' else None
        if alias is not None:
            validate_reviewed_alias_source(alias,r)
            vm=[exact_alias_metadata(alias,varmeta)]
            resolution_kind='reviewed_alias'
            alias_candidates.append({
                'year':r['year'],
                'source_table':r['access_table_name'],
                'source_column':r['column_name'],
                'candidate_metadata_table':alias['selected_access_table_name'],
                'candidate_varnumber':alias['selected_source_varnumber'],
                'candidate_file_number':alias['selected_file_number'],
                'candidate_status':'approved_exact_alias',
                'evidence':alias['evidence'],
            })

        status=approval_grade_metadata_status(resolution_kind)
        diagnostic_candidates=raw_vm
        if resolution_kind=='reviewed_alias':
            diagnostic_candidates=vm
        varnum=str(val(vm[0],'VarNumber')) if len(vm)==1 else ''
        matched_file_number=val(vm[0],'FileNumber') if len(vm)==1 else ''
        matched_metadata_row_count=(
            len(vm) if status in {'exact','multiple'} else 0
        )
        metadata_candidate_identities='|'.join(
            sorted(
                f"{val(candidate,'TableName')}:{val(candidate,'FileNumber')}:"
                f"{val(candidate,'VarNumber')}:{val(candidate,'VarName')}"
                for candidate in diagnostic_candidates
            )
        )
        metadata_join_reason={
            'not_applicable':'identifier or control-table metadata is not panel-measure evidence',
            'singular_exact':(
                'singular exact table/column metadata identity; metadata '
                'FileNumber retained independently of table-level FILENAMES'
            ),
            'multiple':'multiple exact table/column metadata identities',
            'missing':'no exact table/column metadata identity',
            'reviewed_override':(
                f'approved B02 exact metadata identity selected 1 of {len(raw_vm)}'
            ),
            'reviewed_alias':'approved B04 exact cross-table metadata alias',
        }[resolution_kind]
        tg=grain_map.get((r['year'],r['access_table_name']),r.get('candidate_table_grain',''))
        declared_flag=val(vm[0],'ImputationVar').strip() if len(vm)==1 else ''
        flag_present=declared_flag.casefold() in headers_by_table[table_key] if declared_flag else False
        actual_flag=r['column_name'].casefold() in declared_flag_values[table_key]
        if control: role='administrative_field'
        elif r['column_name'].casefold()=='unitid': role='identifier'
        elif actual_flag: role='imputation_field'
        elif status=='exact' and r['column_name'].casefold() in dimensions_map.get(table_key,set()): role='dimension'
        elif status=='exact' and tg in {'scalar','dimensioned'}: role='measure_candidate'
        else: role='unresolved'

        role_key,role_decision=reviewed_source_role_for_row(source_roles,r)
        if role_decision is not None:
            validate_reviewed_source_role(
                role_decision,
                r,
                inv_sha.get(table_key,''),
            )
            record_reviewed_source_role_application(
                role_key,
                r,
                applied_source_roles,
                applied_source_column_identities,
            )
            role=role_decision['candidate_role']

        reason='' if role!='unresolved' else (
            'ambiguous_metadata' if status=='multiple'
            else ('missing_metadata' if status=='missing' else 'table_grain_unresolved')
        )
        evidence={'identifier':'exact UNITID source key','dimension':'proven complete source key','measure_candidate':'exact metadata and proven table grain','imputation_field':'actual source column equals a declared ImputationVar','administrative_field':'control-table evidence'}.get(role,'unresolved exact-evidence gap')
        if role_decision is not None:
            evidence=role_decision['source_evidence']

        metadata_decision_source=''
        metadata_decision_justification=''
        matched_metadata_source='VARTABLE' if varnum else ''
        matched_metadata_table_name=vm[0].get('_metadata_table_name','') if len(vm)==1 else ''
        if resolution_kind=='reviewed_override':
            metadata_decision_source='reviewed B02'
            metadata_decision_justification=override['justification']
            matched_metadata_source=override['selected_metadata_source']
            matched_metadata_table_name=override['selected_metadata_table_name']
        elif resolution_kind=='reviewed_alias' and alias is not None:
            metadata_decision_source='reviewed B04 alias'
            metadata_decision_justification=alias['justification']
            matched_metadata_source=alias['selected_metadata_source']
            matched_metadata_table_name=alias['selected_metadata_table_name']

        x={k:'' for k in cf}
        x.update({
            'contract_id':r['contract_id'],
            'year':r['year'],
            'access_table_name':r['access_table_name'],
            'normalized_table_name':r['normalized_table_name'],
            'file_number':table_file_number_map.get(table_key,''),
            'table_role':'control' if control else 'data',
            'candidate_table_grain':tg,
            'table_catalog_file_number':'',
            'table_catalog_table_number':table_number_map.get(table_key,''),
            'filenames_file_number':table_file_number_map.get(table_key,''),
            'variable_metadata_file_number':matched_file_number,
            'ordinal_position':r['ordinal_position'],
            'column_name':r['column_name'],
            'column_name_normalized':r['column_name'].casefold(),
            'source_csv_sha256':inv_sha.get(table_key,''),
            'nonempty_count':r.get('nonempty_count',''),
            'null_count':r.get('null_or_blank_count',r.get('null_count','')),
            'distinct_nonempty_count':r.get('distinct_nonempty_count',''),
            'example_nonempty_tokens':r.get('example_tokens',r.get('example_nonempty_tokens','')),
            'column_metadata_match_status':status,
            'matched_file_number':matched_file_number,
            'matched_varnumber':varnum,
            'matched_varname':val(vm[0],'VarName') if len(vm)==1 else '',
            'matched_metadata_table_name':matched_metadata_table_name,
            'matched_metadata_source':matched_metadata_source,
            'matched_metadata_row_count':matched_metadata_row_count,
            'metadata_join_reason':metadata_join_reason,
            'metadata_candidate_identities':metadata_candidate_identities,
            'metadata_decision_source':metadata_decision_source,
            'metadata_decision_justification':metadata_decision_justification,
            'data_type':val(vm[0],'DataType') if len(vm)==1 else r.get('data_type',''),
            'format':val(vm[0],'Format') if len(vm)==1 else r.get('format',''),
            'field_width':val(vm[0],'FieldWidth') if len(vm)==1 else r.get('field_width',''),
            'var_title':val(vm[0],'VarTitle') if len(vm)==1 else r.get('var_title',''),
            'long_description':val(vm[0],'LongDescription') if len(vm)==1 else r.get('long_description',''),
            'code_label_count':r.get('code_label_count',''),
            'candidate_role':role,
            'role_evidence':evidence,
            'role_decision_id':role_decision['decision_id'] if role_decision else '',
            'role_decision_source':'reviewed B04 role' if role_decision else '',
            'role_decision_justification':role_decision['review_note'] if role_decision else '',
            'unresolved_reason':reason,
            'imputation_flag_varname':declared_flag,
            'imputation_flag_column_present':str(flag_present).lower(),
            'imputation_flag_metadata_present':str(bool(declared_flag)).lower(),
            'imputation_link_status':(
                ('flag_exported' if flag_present else 'metadata_only_not_exported')
                if declared_flag
                else ('actual_declared_flag' if actual_flag else 'not_applicable')
            ),
        })
        crows.append(x)
        cdiag.append({
            k:x[k]
            for k in [
                'year','access_table_name','column_name',
                'column_metadata_match_status','matched_file_number',
                'matched_varnumber','matched_varname',
                'matched_metadata_table_name','matched_metadata_source',
                'matched_metadata_row_count','metadata_join_reason',
                'metadata_candidate_identities',
                'metadata_decision_source','metadata_decision_justification',
            ]
        })
        if declared_flag:
            imputation_rows.append({'year':r['year'],'access_table_name':r['access_table_name'],'value_column':r['column_name'],'value_varnumber':varnum,'declared_imputation_var':declared_flag,'flag_source_table':r['access_table_name'],'flag_column_present':str(flag_present).lower(),'flag_metadata_present':x['imputation_flag_metadata_present'],'flag_nonempty_count':'','link_status':x['imputation_link_status'],'reason':'exact VARTABLE declaration reconciled to actual exported header'})
        if x['candidate_role']=='unresolved' and int(x.get('nonempty_count','0') or 0)>0: cexc.append({**x,'exception':x['unresolved_reason']})
        if r['year']=='2023' and status=='missing':
            category='derived_copy_metadata_gap' if r['access_table_name']=='CUSTOMCGIDS2023' and r['column_name'] in {'CGCITY','SECTOR','CYACTIVE','MATCH'} else ('undocumented_source_field' if r['access_table_name']=='IC2023' and r['column_name'] in {'TUITVRY1','TUITVRY2','TUITVRY3'} else 'other')
            missing_2023.append({
                'year':r['year'],
                'access_table_name':r['access_table_name'],
                'column_name':r['column_name'],
                'category':category,
                'status':'role_reviewed_metadata_missing' if role_decision else 'unresolved',
                'reason':'No singular current-year exact metadata identity.',
            })
    assert_reviewed_source_roles_consumed(
        source_roles,
        applied_source_roles,
        input_table_identities,
    )
    table_case={(year,table.casefold()):table for year,table in headers_by_table}
    imputation_rows=[]; seen_links=set()
    for (year,table_cf,value_cf),matches in sorted(varmeta.items()):
        for metadata in matches:
            flag=val(metadata,'ImputationVar').strip()
            if not flag:
                continue
            link=(year,table_cf,value_cf,flag.casefold())
            if link in seen_links:
                continue
            seen_links.add(link)
            table_name=table_case.get((year,table_cf),val(metadata,'TableName'))
            headers=headers_by_table.get((year,table_name),set())
            present=flag.casefold() in headers
            flag_meta=bool(varmeta.get((year,table_cf,flag.casefold())))
            value_present=value_cf in headers
            imputation_rows.append({'year':year,'access_table_name':table_name,'value_column':val(metadata,'VarName'),'value_varnumber':val(metadata,'VarNumber'),'declared_imputation_var':flag,'flag_source_table':'','flag_column_present':str(present).lower(),'flag_metadata_present':'true','flag_nonempty_count':'','link_status':'metadata_only_not_exported' if value_present else 'value_and_flag_not_exported','reason':'VARTABLE declares the link, but the archived Access schema and exported headers contain no standalone flag column; prefix alone is not semantic evidence.'})
    write(OUT/'source_column_enriched.csv',cf,crows); write(OUT/'source_column_metadata_join_diagnostics.csv',list(cdiag[0]),cdiag); write(OUT/'source_column_exceptions.csv',cf+['exception'],cexc)
    write(OUT/'source_column_2023_alias_candidates.csv',['year','source_table','source_column','candidate_metadata_table','candidate_varnumber','candidate_file_number','candidate_status','evidence'],alias_candidates)
    write(OUT/'source_column_2023_missing_diagnostics.csv',['year','access_table_name','column_name','category','status','reason'],missing_2023)
    write(OUT/'imputation_link_reconciliation.csv',['year','access_table_name','value_column','value_varnumber','declared_imputation_var','flag_source_table','flag_column_present','flag_metadata_present','flag_nonempty_count','link_status','reason'],imputation_rows)
    sig=defaultdict(list)
    for r in crows:sig[(r['normalized_table_name'],r['column_name_normalized'],r['matched_varnumber'],r['matched_metadata_source'],r['candidate_role'])].append(r)
    sf=['normalized_table_name','column_name_normalized','matched_varnumber','matched_metadata_source','candidate_role','years_present','row_count','nonempty_year_count','metadata_statuses','role_stable_across_years','table_grain_stable_across_years','exception_year_count','review_priority']
    signature_rows=[]
    for k,rs in sorted(sig.items()):
        roles={r['candidate_role'] for r in rs}; grains={r['candidate_table_grain'] for r in rs if r['candidate_table_grain']}; statuses={r['column_metadata_match_status'] for r in rs}
        role_stability='stable' if len(roles)==1 and not any(role=='unresolved' for role in roles) else ('changed' if len(roles)>1 else 'unknown')
        grain_stability='stable' if len(grains)==1 else ('changed' if len(grains)>1 else 'unknown')
        signature_rows.append({'normalized_table_name':k[0],'column_name_normalized':k[1],'matched_varnumber':k[2],'matched_metadata_source':k[3],'candidate_role':k[4],'years_present':'|'.join(sorted({r['year'] for r in rs})),'row_count':len(rs),'nonempty_year_count':sum(int(r.get('nonempty_count','0') or 0)>0 for r in rs),'metadata_statuses':'|'.join(sorted(statuses)),'role_stable_across_years':role_stability,'table_grain_stable_across_years':grain_stability,'exception_year_count':sum(bool(r['unresolved_reason']) for r in rs),'review_priority':'high' if any(r['unresolved_reason'] for r in rs) else 'normal'})
    write(OUT/'source_column_signature_summary.csv',sf,signature_rows)
    (OUT/'table_grain_summary.md').write_text(f'# Table grain evidence\n\nRows: {len(rows)}; metadata statuses: {Counter(r["table_metadata_match_status"] for r in rows)}; unresolved/zero-row exceptions: {len(exceptions)}. This review-artifact generator did not mutate the canonical grain contract.\n')
    (OUT/'source_column_summary.md').write_text(f'# Source-column evidence\n\nRows: {len(crows)}; metadata statuses: {Counter(r["column_metadata_match_status"] for r in crows)}; nonempty unresolved exceptions: {len(cexc)}. This review-artifact generator did not mutate the canonical source-column contract.\n')
def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--legacy-root',type=Path,required=True)
    parser.add_argument('--out-dir',type=Path,default=OUT)
    parser.add_argument('--source-role-contract',type=Path)
    parser.add_argument('--provenance-root',type=Path)
    parser.add_argument('--expected-author-receipt-sha256')
    args=parser.parse_args(argv)
    run(
        args.legacy_root,
        args.out_dir,
        source_role_contract_path=args.source_role_contract,
        provenance_root=args.provenance_root,
        expected_author_receipt_sha256=(
            args.expected_author_receipt_sha256
        ),
    )


if __name__=='__main__': main()
