#!/usr/bin/env python3
"""Build a non-approving review package from a legacy IPEDSDB artifact root.

The package is deliberately separate from ``contracts/``.  It re-verifies
mechanical facts that can be derived from the archived bytes, but it never
marks a source, grain decision, column role, ambiguity, cleaning rule, or
benchmark as reviewed or approved.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import tempfile
import tomllib
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Iterable, Mapping, Sequence


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONTRACT_ID = "ipedsdb-panel-2004-2023-access-v2"
SOURCE_RELEASE_FIELDS = [
    "contract_id",
    "year",
    "academic_year_label",
    "release_type",
    "release_date_text",
    "access_url",
    "access_filename",
    "expected_access_sha256",
    "access_size_bytes",
    "documentation_url",
    "documentation_filename",
    "expected_documentation_sha256",
    "documentation_size_bytes",
    "lock_status",
    "source",
    "approved_at",
    "review_note",
]
SOURCE_VERIFICATION_FIELDS = [
    "year",
    "artifact_kind",
    "relative_path",
    "expected_size_bytes",
    "observed_size_bytes",
    "size_match",
    "expected_sha256",
    "observed_sha256",
    "sha256_match",
    "zip_crc_ok",
    "archive_database_member",
    "archive_database_member_sha256",
    "archive_member_matches_extracted",
    "integrity_verdict",
]
TABLE_REVIEW_FIELDS = [
    "contract_id",
    "year",
    "access_db_file",
    "access_table_name",
    "normalized_table_name",
    "legacy_table_role",
    "csv_relative_path",
    "has_unitid",
    "row_count_csv_inventory",
    "row_count_csv_report",
    "row_count_csv_observed",
    "row_count_access",
    "row_count_match",
    "column_count_inventory",
    "column_count_metadata",
    "column_count_csv_header",
    "column_count_match",
    "column_names_match",
    "observed_csv_size_bytes",
    "expected_csv_sha256",
    "observed_csv_sha256",
    "csv_sha256_match",
    "legacy_export_status",
    "v2_reusable",
    "contract_grain_class",
    "reviewed",
    "review_note",
]
COLUMN_REVIEW_FIELDS = [
    "contract_id",
    "year",
    "access_table_name",
    "normalized_table_name",
    "legacy_table_role",
    "ordinal_position",
    "column_name",
    "column_name_normalized",
    "mechanical_signal",
    "proposed_contract_role",
    "reviewed",
    "review_note",
]
AMBIGUITY_REVIEW_FIELDS = [
    "contract_id",
    "year",
    "source_file",
    "access_table_name",
    "requested_varname",
    "candidate_count",
    "candidate_rank",
    "candidate_varnumber",
    "candidate_varname",
    "candidate_vartitle",
    "candidate_long_description",
    "candidate_data_type",
    "candidate_file_number",
    "selected_by_pending_override",
    "pending_selected_source_varnumber",
    "pending_review_status",
    "reviewed",
    "review_note",
]
DIAGNOSTIC_FIELDS = [
    "category",
    "relative_path",
    "row_count",
    "size_bytes",
    "sha256",
    "interpretation_status",
    "release_usable",
    "review_note",
]
INPUT_EVIDENCE_FIELDS = [
    "source_scope",
    "relative_path",
    "size_bytes",
    "sha256",
    "data_rows",
    "purpose",
]
BLOCKER_FIELDS = [
    "blocker_id",
    "area",
    "status",
    "observed",
    "required_action",
    "machine_approvable",
    "evidence",
]
MANIFEST_FIELDS = ["relative_path", "size_bytes", "sha256", "data_rows"]
REQUIRED_PACKAGE_FILES = {
    "README.md",
    "dictionary_ambiguity_review.csv",
    "input_evidence_manifest.csv",
    "legacy_diagnostic_inventory.csv",
    "package_manifest.csv",
    "review_blockers.csv",
    "review_summary.json",
    "source_column_review.csv",
    "source_release_verification.csv",
    "source_releases_candidate.csv",
    "table_review_inventory.csv",
}

LEGACY_DIAGNOSTICS = [
    ("dictionary", "Checks/dictionary_qc/dictionary_qaqc_summary.csv"),
    ("dictionary", "Checks/dictionary_qc/dictionary_duplicates.csv"),
    ("dictionary", "Checks/dictionary_qc/varnumber_varname_collisions.csv"),
    ("dictionary", "Checks/dictionary_qc/synthetic_rows_summary.csv"),
    ("discrete", "Checks/disc_qc/disc_conflicts_summary_all_years.csv"),
    ("prch", "Checks/prch_qc/prch_flag_policy.csv"),
    ("prch", "Checks/prch_qc/prch_flag_code_counts.csv"),
    ("prch", "Checks/prch_qc/prch_clean_columns.csv"),
    ("prch", "Checks/prch_qc/prch_clean_summary.csv"),
    ("prch", "Checks/prch_qc/prch_lineage_summary.csv"),
    ("wide", "Checks/wide_qc/qc_column_lineage.csv"),
    ("wide", "Checks/wide_qc/qc_target_lineage.csv"),
    ("wide", "Checks/wide_qc/qc_cast_report.csv"),
]


class ReviewPackageError(RuntimeError):
    """Raised when archived evidence is incomplete or internally inconsistent."""


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--legacy-root", required=True, help="Read-only legacy IPEDSDB artifact root")
    parser.add_argument("--out-dir", required=True, help="New directory for the review package")
    parser.add_argument("--repo-root", default=str(REPO_ROOT), help="Repository containing current contracts")
    parser.add_argument("--contract-id", default=DEFAULT_CONTRACT_ID)
    parser.add_argument("--years", default="2004:2023", help="Inclusive range such as 2004:2023")
    return parser.parse_args(argv)


def parse_years(text: str) -> list[int]:
    value = str(text).strip()
    if ":" in value:
        start_text, end_text = value.split(":", 1)
        start, end = int(start_text), int(end_text)
        if start > end:
            raise ReviewPackageError(f"Invalid descending year range: {value}")
        return list(range(start, end + 1))
    years = sorted({int(part.strip()) for part in value.split(",") if part.strip()})
    if not years:
        raise ReviewPackageError("At least one year is required")
    return years


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def sha256_stream(handle) -> str:
    digest = hashlib.sha256()
    for chunk in iter(lambda: handle.read(1024 * 1024), b""):
        digest.update(chunk)
    return digest.hexdigest()


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    if not path.is_file():
        raise ReviewPackageError(f"Required CSV is missing: {path}")
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = list(reader.fieldnames or [])
        if not fields:
            raise ReviewPackageError(f"CSV has no header: {path}")
        rows = [
            {str(key): str(value or "").strip() for key, value in row.items()}
            for row in reader
        ]
    return fields, rows


def require_fields(path: Path, fields: Iterable[str], required: Iterable[str]) -> None:
    missing = sorted(set(required) - set(fields))
    if missing:
        raise ReviewPackageError(f"{path} is missing columns: {', '.join(missing)}")


def bool_text(value: object) -> str:
    return "true" if bool(value) else "false"


def csv_data_row_count(path: Path) -> int:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        try:
            next(reader)
        except StopIteration:
            return 0
        return sum(1 for _ in reader)


def inspect_csv(path: Path) -> tuple[list[str], int, int, str]:
    """Parse a CSV directly and bind its header, logical row count, size, and hash."""
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.reader(handle)
        try:
            header = next(reader)
        except StopIteration as exc:
            raise ReviewPackageError(f"CSV is empty and has no header: {path}") from exc
        data_rows = sum(1 for _ in reader)
    return header, data_rows, path.stat().st_size, sha256_path(path)


def write_csv(path: Path, fields: Sequence[str], rows: Iterable[Mapping[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="raise", lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def safe_child(base: Path, relative: str) -> Path:
    candidate = (base / relative).resolve()
    try:
        candidate.relative_to(base.resolve())
    except ValueError as exc:
        raise ReviewPackageError(f"Path escapes year directory: {relative}") from exc
    return candidate


def is_within(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
    except ValueError:
        return False
    return True


def verify_zip(path: Path, *, capture_database_member: bool) -> tuple[bool, str, str]:
    """Read every member once so the ZIP implementation verifies each CRC."""
    database_members: list[str] = []
    database_hash = ""
    try:
        with zipfile.ZipFile(path) as archive:
            for info in archive.infolist():
                if info.is_dir():
                    continue
                suffix = Path(info.filename).suffix.lower()
                is_database = suffix in {".accdb", ".mdb"}
                if is_database:
                    database_members.append(info.filename)
                with archive.open(info) as member:
                    observed = sha256_stream(member)
                if is_database:
                    database_hash = observed
    except (OSError, zipfile.BadZipFile, RuntimeError) as exc:
        raise ReviewPackageError(f"ZIP integrity check failed for {path}: {exc}") from exc
    if capture_database_member and len(database_members) != 1:
        raise ReviewPackageError(
            f"Expected exactly one Access database in {path}, found {len(database_members)}"
        )
    return True, (database_members[0] if database_members else ""), database_hash


def find_extracted_database(year_dir: Path, filename: str) -> Path:
    matches = sorted(
        path for path in (year_dir / "extracted_db").rglob(filename) if path.is_file()
    )
    if len(matches) != 1:
        raise ReviewPackageError(
            f"Expected exactly one extracted database named {filename} under {year_dir}, found {len(matches)}"
        )
    resolved = matches[0].resolve()
    try:
        resolved.relative_to(year_dir.resolve())
    except ValueError as exc:
        raise ReviewPackageError(f"Extracted database escapes year directory: {resolved}") from exc
    return resolved


def find_download_artifact(year_dir: Path, filename: str) -> Path:
    if Path(filename).name != filename:
        raise ReviewPackageError(f"Manifest download filename is not a safe basename: {filename}")
    candidates = [
        path
        for path in (year_dir / "downloads" / filename, year_dir / filename)
        if path.is_file()
    ]
    if len(candidates) != 1:
        raise ReviewPackageError(
            f"Expected exactly one archived download named {filename} under {year_dir}, found {len(candidates)}"
        )
    resolved = candidates[0].resolve()
    try:
        resolved.relative_to(year_dir.resolve())
    except ValueError as exc:
        raise ReviewPackageError(f"Archived download escapes year directory: {resolved}") from exc
    return resolved


def canonical_contract_counts(repo_root: Path) -> dict[str, int]:
    names = [
        "source_releases",
        "table_grain",
        "source_columns",
        "analysis_schema",
        "discrete_families",
        "prch_policy",
        "external_benchmarks",
        "metadata_backfill_approvals",
    ]
    counts: dict[str, int] = {}
    for name in names:
        path = repo_root / "contracts" / f"{name}.csv"
        _, rows = read_csv(path)
        counts[name] = len(rows)
    return counts


def build_source_evidence(
    legacy_root: Path,
    years: Sequence[int],
    contract_id: str,
) -> tuple[list[dict[str, object]], list[dict[str, object]], dict[str, int]]:
    candidates: list[dict[str, object]] = []
    verification: list[dict[str, object]] = []
    counts = Counter()
    for year in years:
        year_dir = legacy_root / "Raw_Access_Databases" / str(year)
        manifest_path = year_dir / "manifest.csv"
        fields, rows = read_csv(manifest_path)
        require_fields(
            manifest_path,
            fields,
            {
                "year",
                "academic_year_label",
                "release_type",
                "release_date_text",
                "access_url",
                "access_filename",
                "access_zip_filesize_bytes",
                "access_zip_sha256",
                "doc_url",
                "doc_filename",
                "doc_filesize_bytes",
                "doc_sha256",
                "extracted_access_db_file",
                "extracted_access_db_sha256",
            },
        )
        if len(rows) != 1 or int(rows[0]["year"]) != year:
            raise ReviewPackageError(f"Expected one manifest row for {year}: {manifest_path}")
        row = rows[0]
        if row["release_type"].casefold() != "final":
            raise ReviewPackageError(f"Archived year {year} is not labelled Final")
        candidates.append(
            {
                "contract_id": contract_id,
                "year": year,
                "academic_year_label": row["academic_year_label"],
                "release_type": row["release_type"],
                "release_date_text": row["release_date_text"],
                "access_url": row["access_url"],
                "access_filename": row["access_filename"],
                "expected_access_sha256": row["access_zip_sha256"].lower(),
                "access_size_bytes": row["access_zip_filesize_bytes"],
                "documentation_url": row["doc_url"],
                "documentation_filename": row["doc_filename"],
                "expected_documentation_sha256": row["doc_sha256"].lower(),
                "documentation_size_bytes": row["doc_filesize_bytes"],
                "lock_status": "pending",
                "source": "Legacy annual manifest reverified against archived bytes; URLs identify NCES IPEDS",
                "approved_at": "",
                "review_note": (
                    "Machine-derived candidate only; an independent reviewer must confirm release identity "
                    "and explicitly approve this row."
                ),
            }
        )

        access_path = find_download_artifact(year_dir, row["access_filename"])
        doc_path = find_download_artifact(year_dir, row["doc_filename"])
        for kind, path, expected_size, expected_hash, capture_database in (
            (
                "access_archive",
                access_path,
                row["access_zip_filesize_bytes"],
                row["access_zip_sha256"],
                True,
            ),
            (
                "documentation_xlsx",
                doc_path,
                row["doc_filesize_bytes"],
                row["doc_sha256"],
                False,
            ),
        ):
            if not path.is_file():
                raise ReviewPackageError(f"Archived source file is missing: {path}")
            observed_size = path.stat().st_size
            observed_hash = sha256_path(path)
            size_match = observed_size == int(expected_size)
            hash_match = observed_hash == expected_hash.lower()
            crc_ok, database_member, database_member_hash = verify_zip(
                path, capture_database_member=capture_database
            )
            if not (size_match and hash_match and crc_ok):
                raise ReviewPackageError(f"Archived source integrity mismatch: {path}")
            verification.append(
                {
                    "year": year,
                    "artifact_kind": kind,
                    "relative_path": path.relative_to(legacy_root).as_posix(),
                    "expected_size_bytes": expected_size,
                    "observed_size_bytes": observed_size,
                    "size_match": bool_text(size_match),
                    "expected_sha256": expected_hash.lower(),
                    "observed_sha256": observed_hash,
                    "sha256_match": bool_text(hash_match),
                    "zip_crc_ok": bool_text(crc_ok),
                    "archive_database_member": database_member,
                    "archive_database_member_sha256": database_member_hash,
                    "archive_member_matches_extracted": "",
                    "integrity_verdict": "PASS",
                }
            )
            counts["download_artifacts"] += 1
            counts["download_integrity_passes"] += 1

        extracted_filename = row["extracted_access_db_file"]
        extracted_path = find_extracted_database(year_dir, extracted_filename)
        extracted_hash = sha256_path(extracted_path)
        expected_extracted_hash = row["extracted_access_db_sha256"].lower()
        access_verification = verification[-2]
        member_hash = str(access_verification["archive_database_member_sha256"])
        hash_match = extracted_hash == expected_extracted_hash
        member_match = extracted_hash == member_hash
        if not (hash_match and member_match):
            raise ReviewPackageError(f"Extracted database identity mismatch: {extracted_path}")
        access_verification["archive_member_matches_extracted"] = bool_text(member_match)
        verification.append(
            {
                "year": year,
                "artifact_kind": "extracted_access_database",
                "relative_path": extracted_path.relative_to(legacy_root).as_posix(),
                "expected_size_bytes": "",
                "observed_size_bytes": extracted_path.stat().st_size,
                "size_match": "",
                "expected_sha256": expected_extracted_hash,
                "observed_sha256": extracted_hash,
                "sha256_match": bool_text(hash_match),
                "zip_crc_ok": "",
                "archive_database_member": access_verification["archive_database_member"],
                "archive_database_member_sha256": member_hash,
                "archive_member_matches_extracted": bool_text(member_match),
                "integrity_verdict": "PASS",
            }
        )
        counts["annual_manifests"] += 1
        counts["extracted_database_integrity_passes"] += 1
    return candidates, verification, dict(counts)


def normalized_rows(rows: Sequence[Mapping[str, str]], fields: Sequence[str]) -> list[tuple[str, ...]]:
    return [tuple(str(row.get(field, "")) for field in fields) for row in rows]


def build_table_evidence(
    legacy_root: Path,
    years: Sequence[int],
    contract_id: str,
) -> tuple[list[dict[str, object]], list[dict[str, object]], dict[str, object]]:
    table_rows: list[dict[str, object]] = []
    column_rows: list[dict[str, object]] = []
    concatenated_inventories: list[dict[str, str]] = []
    inventory_fields: list[str] | None = None
    zero_row_tables: list[str] = []
    legacy_export_statuses = Counter()

    for year in years:
        year_dir = legacy_root / "Raw_Access_Databases" / str(year)
        inventory_path = year_dir / "metadata" / "table_inventory.csv"
        row_count_path = year_dir / "metadata" / "row_count_report.csv"
        columns_path = year_dir / "metadata" / "table_columns.csv"
        this_inventory_fields, inventory = read_csv(inventory_path)
        row_count_fields, row_counts = read_csv(row_count_path)
        column_fields, columns = read_csv(columns_path)
        require_fields(
            inventory_path,
            this_inventory_fields,
            {
                "year",
                "access_db_file",
                "table_name",
                "normalized_table_name",
                "table_role",
                "csv_path",
                "has_unitid",
                "row_count_csv",
                "column_count",
                "csv_sha256",
                "export_status",
            },
        )
        require_fields(
            row_count_path,
            row_count_fields,
            {"year", "table_name", "row_count_csv", "row_count_access", "row_count_match"},
        )
        require_fields(
            columns_path,
            column_fields,
            {
                "year",
                "table_name",
                "normalized_table_name",
                "ordinal_position",
                "column_name",
                "column_name_normalized",
            },
        )
        if inventory_fields is None:
            inventory_fields = this_inventory_fields
        elif inventory_fields != this_inventory_fields:
            raise ReviewPackageError(f"Inventory schema drift in {inventory_path}")
        for label, records in (
            ("inventory", inventory),
            ("row-count report", row_counts),
            ("column inventory", columns),
        ):
            if any(int(record["year"]) != year for record in records):
                raise ReviewPackageError(f"{label} contains a mismatched year in {year_dir}")
        concatenated_inventories.extend(inventory)

        row_count_by_table = {row["table_name"].casefold(): row for row in row_counts}
        if len(row_count_by_table) != len(row_counts):
            raise ReviewPackageError(f"Duplicate table in {row_count_path}")
        columns_by_table: dict[str, list[dict[str, str]]] = defaultdict(list)
        for column in columns:
            columns_by_table[column["table_name"].casefold()].append(column)
        inventory_by_table = {row["table_name"].casefold(): row for row in inventory}
        if len(inventory_by_table) != len(inventory):
            raise ReviewPackageError(f"Duplicate table in {inventory_path}")
        if set(inventory_by_table) != set(row_count_by_table) or set(inventory_by_table) != set(columns_by_table):
            raise ReviewPackageError(f"Table inventory/count/column coverage differs for year {year}")

        for record in sorted(inventory, key=lambda item: item["table_name"].casefold()):
            key = record["table_name"].casefold()
            counts = row_count_by_table[key]
            table_columns = sorted(columns_by_table[key], key=lambda item: int(item["ordinal_position"]))
            ordinals = [int(column["ordinal_position"]) for column in table_columns]
            if ordinals != list(range(1, len(table_columns) + 1)):
                raise ReviewPackageError(
                    f"Column ordinals are not contiguous for {year} {record['table_name']}"
                )
            if any(
                column["normalized_table_name"] != record["normalized_table_name"]
                for column in table_columns
            ):
                raise ReviewPackageError(
                    f"Normalized table identity differs in column metadata: {year} {record['table_name']}"
                )
            csv_path = safe_child(year_dir, record["csv_path"])
            if not csv_path.is_file():
                raise ReviewPackageError(f"Exported table CSV is missing: {csv_path}")
            observed_header, observed_row_count, observed_size, observed_hash = inspect_csv(csv_path)
            expected_hash = record["csv_sha256"].lower()
            csv_hash_match = observed_hash == expected_hash
            row_match = (
                int(record["row_count_csv"]) == observed_row_count
                and int(counts["row_count_csv"]) == observed_row_count
                and int(counts["row_count_access"]) == observed_row_count
                and counts["row_count_match"].casefold() == "true"
            )
            expected_header = [column["column_name"] for column in table_columns]
            column_match = (
                int(record["column_count"]) == len(table_columns) == len(observed_header)
            )
            column_names_match = observed_header == expected_header
            if not (csv_hash_match and row_match and column_match and column_names_match):
                raise ReviewPackageError(f"Legacy table evidence mismatch: {year} {record['table_name']}")
            if observed_row_count == 0:
                zero_row_tables.append(f"{year}:{record['table_name']}")
            legacy_export_statuses[record["export_status"]] += 1
            table_rows.append(
                {
                    "contract_id": contract_id,
                    "year": year,
                    "access_db_file": record["access_db_file"],
                    "access_table_name": record["table_name"],
                    "normalized_table_name": record["normalized_table_name"],
                    "legacy_table_role": record["table_role"],
                    "csv_relative_path": csv_path.relative_to(legacy_root).as_posix(),
                    "has_unitid": record["has_unitid"].lower(),
                    "row_count_csv_inventory": record["row_count_csv"],
                    "row_count_csv_report": counts["row_count_csv"],
                    "row_count_csv_observed": observed_row_count,
                    "row_count_access": counts["row_count_access"],
                    "row_count_match": bool_text(row_match),
                    "column_count_inventory": record["column_count"],
                    "column_count_metadata": len(table_columns),
                    "column_count_csv_header": len(observed_header),
                    "column_count_match": bool_text(column_match),
                    "column_names_match": bool_text(column_names_match),
                    "observed_csv_size_bytes": observed_size,
                    "expected_csv_sha256": expected_hash,
                    "observed_csv_sha256": observed_hash,
                    "csv_sha256_match": bool_text(csv_hash_match),
                    "legacy_export_status": record["export_status"],
                    "v2_reusable": "false",
                    "contract_grain_class": "unknown",
                    "reviewed": "false",
                    "review_note": (
                        "Mechanical inventory evidence only; classify source grain and column disposition "
                        "under the v2 contract before release."
                    ),
                }
            )
            for column in table_columns:
                normalized = column["column_name_normalized"].strip().upper()
                is_unitid = normalized == "UNITID"
                column_rows.append(
                    {
                        "contract_id": contract_id,
                        "year": year,
                        "access_table_name": record["table_name"],
                        "normalized_table_name": record["normalized_table_name"],
                        "legacy_table_role": record["table_role"],
                        "ordinal_position": column["ordinal_position"],
                        "column_name": column["column_name"],
                        "column_name_normalized": column["column_name_normalized"],
                        "mechanical_signal": "exact_UNITID_name" if is_unitid else "none",
                        "proposed_contract_role": "identifier" if is_unitid else "unknown",
                        "reviewed": "false",
                        "review_note": (
                            "UNITID role is a name-based candidate only."
                            if is_unitid
                            else "No semantic role inferred; independent source-column review required."
                        ),
                    }
                )

    global_inventory_path = legacy_root / "Checks" / "extract_qc" / "table_inventory_all_years.csv"
    global_fields, global_rows = read_csv(global_inventory_path)
    if inventory_fields != global_fields:
        raise ReviewPackageError("Global and annual inventory schemas differ")
    requested_years = set(years)
    filtered_global_rows = [
        row for row in global_rows if int(row["year"]) in requested_years
    ]
    global_matches = normalized_rows(filtered_global_rows, global_fields) == normalized_rows(
        concatenated_inventories, global_fields
    )
    if not global_matches:
        raise ReviewPackageError("Global table inventory does not equal concatenated annual inventories")

    metrics: dict[str, object] = {
        "table_inventory_rows": len(table_rows),
        "table_csv_hash_matches": sum(row["csv_sha256_match"] == "true" for row in table_rows),
        "row_count_matches": sum(row["row_count_match"] == "true" for row in table_rows),
        "column_count_matches": sum(row["column_count_match"] == "true" for row in table_rows),
        "column_name_matches": sum(row["column_names_match"] == "true" for row in table_rows),
        "source_column_records": len(column_rows),
        "zero_row_tables": zero_row_tables,
        "legacy_export_statuses": dict(sorted(legacy_export_statuses.items())),
        "global_inventory_matches_annual": global_matches,
    }
    return table_rows, column_rows, metrics


def build_ambiguity_evidence(
    legacy_root: Path,
    repo_root: Path,
    contract_id: str,
) -> list[dict[str, object]]:
    override_path = repo_root / "contracts" / "dictionary_ambiguity_overrides.csv"
    _, overrides = read_csv(override_path)
    evidence: list[dict[str, object]] = []
    for override in sorted(
        overrides,
        key=lambda row: (int(row["year_start"]), row["access_table_name"], row["varname"]),
    ):
        if override.get("contract_id") != contract_id:
            continue
        year = int(override["year_start"])
        metadata_table = override["selected_metadata_table_name"]
        candidates = sorted(
            path
            for path in (legacy_root / "Raw_Access_Databases" / str(year) / "tables_csv").glob("*.csv")
            if path.stem.casefold() == metadata_table.casefold()
        )
        if len(candidates) != 1:
            raise ReviewPackageError(
                f"Expected one metadata CSV for ambiguity {year} {metadata_table}, found {len(candidates)}"
            )
        fields, metadata_rows = read_csv(candidates[0])
        lower_to_field = {field.casefold(): field for field in fields}
        required = {"tablename", "varnumber", "varname", "vartitle", "datatype", "longdescription"}
        if not required.issubset(lower_to_field):
            raise ReviewPackageError(f"Ambiguity metadata schema is incomplete: {candidates[0]}")
        requested_name = override["varname"]
        requested_table = override["access_table_name"]
        matches = [
            row
            for row in metadata_rows
            if row[lower_to_field["varname"]].casefold() == requested_name.casefold()
            and row[lower_to_field["tablename"]].casefold() == requested_table.casefold()
        ]
        matches.sort(key=lambda row: row[lower_to_field["varnumber"]].zfill(20))
        if len(matches) < 2:
            raise ReviewPackageError(
                f"Pending ambiguity no longer has multiple candidates: {year} {requested_table} {requested_name}"
            )
        if override["review_status"].casefold() != "pending":
            raise ReviewPackageError(
                f"Ambiguity review status must remain pending: {year} {requested_table} {requested_name}"
            )
        if override.get("reviewer", "") or override.get("review_date", ""):
            raise ReviewPackageError(
                f"Pending ambiguity must not contain reviewer approval fields: {year} {requested_table} {requested_name}"
            )
        selected = override["selected_source_varnumber"].lstrip("0") or "0"
        selected_matches = [
            row
            for row in matches
            if (row[lower_to_field["varnumber"]].lstrip("0") or "0") == selected
        ]
        if len(selected_matches) != 1:
            raise ReviewPackageError(
                f"Pending ambiguity must identify exactly one candidate: {year} {requested_table} "
                f"{requested_name}; matches={len(selected_matches)}"
            )
        for rank, row in enumerate(matches, 1):
            candidate_number = row[lower_to_field["varnumber"]]
            is_selected = (candidate_number.lstrip("0") or "0") == selected
            evidence.append(
                {
                    "contract_id": contract_id,
                    "year": year,
                    "source_file": override["source_file"],
                    "access_table_name": requested_table,
                    "requested_varname": requested_name,
                    "candidate_count": len(matches),
                    "candidate_rank": rank,
                    "candidate_varnumber": candidate_number,
                    "candidate_varname": row[lower_to_field["varname"]],
                    "candidate_vartitle": row[lower_to_field["vartitle"]],
                    "candidate_long_description": row[lower_to_field["longdescription"]],
                    "candidate_data_type": row[lower_to_field["datatype"]],
                    "candidate_file_number": row.get(lower_to_field.get("filenumber", ""), ""),
                    "selected_by_pending_override": bool_text(is_selected),
                    "pending_selected_source_varnumber": override["selected_source_varnumber"],
                    "pending_review_status": override["review_status"],
                    "reviewed": "false",
                    "review_note": (
                        "Side-by-side source evidence only; candidate identity requires an independent reviewer."
                    ),
                }
            )
    return evidence


def build_diagnostic_inventory(legacy_root: Path) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for category, relative in LEGACY_DIAGNOSTICS:
        path = safe_child(legacy_root, relative)
        if not path.is_file():
            continue
        rows.append(
            {
                "category": category,
                "relative_path": relative,
                "row_count": csv_data_row_count(path),
                "size_bytes": path.stat().st_size,
                "sha256": sha256_path(path),
                "interpretation_status": "legacy_diagnostic_only",
                "release_usable": "false",
                "review_note": (
                    "Preserved for reviewer context; this v1-derived artifact is not a v2 contract, approval, "
                    "external benchmark, or sealed release result."
                ),
            }
        )
    return rows


def input_evidence_row(
    *,
    source_scope: str,
    root: Path,
    path: Path,
    purpose: str,
) -> dict[str, object]:
    resolved_root = root.resolve()
    resolved_path = path.resolve()
    try:
        relative = resolved_path.relative_to(resolved_root).as_posix()
    except ValueError as exc:
        raise ReviewPackageError(f"Input evidence escapes {source_scope}: {resolved_path}") from exc
    if not resolved_path.is_file():
        raise ReviewPackageError(f"Input evidence is missing: {resolved_path}")
    return {
        "source_scope": source_scope,
        "relative_path": relative,
        "size_bytes": resolved_path.stat().st_size,
        "sha256": sha256_path(resolved_path),
        "data_rows": csv_data_row_count(resolved_path) if resolved_path.suffix.lower() == ".csv" else "",
        "purpose": purpose,
    }


def build_input_evidence_inventory(
    legacy_root: Path,
    repo_root: Path,
    years: Sequence[int],
    contract_id: str,
    source_verification: Sequence[Mapping[str, object]],
    table_rows: Sequence[Mapping[str, object]],
) -> list[dict[str, object]]:
    """Bind the metadata and contracts used to derive the review package."""
    inputs: dict[tuple[str, str], dict[str, object]] = {}

    def retain(row: dict[str, object], purpose: str) -> None:
        scope = str(row["source_scope"])
        key = (scope, str(row["relative_path"]))
        previous = inputs.get(key)
        if previous:
            for field in ("size_bytes", "sha256", "data_rows"):
                if str(previous[field]) != str(row[field]):
                    raise ReviewPackageError(
                        f"Conflicting input evidence for {scope}:{row['relative_path']} field {field}"
                    )
            if previous["purpose"] != purpose:
                previous["purpose"] = f"{previous['purpose']}; {purpose}"
        else:
            inputs[key] = row

    def add(scope: str, root: Path, path: Path, purpose: str) -> None:
        retain(
            input_evidence_row(
                source_scope=scope,
                root=root,
                path=path,
                purpose=purpose,
            ),
            purpose,
        )

    def add_observed(
        *,
        scope: str,
        root: Path,
        relative_path: str,
        size_bytes: object,
        sha256: object,
        data_rows: object,
        purpose: str,
    ) -> None:
        path = safe_child(root, relative_path)
        if not path.is_file() or path.stat().st_size != int(size_bytes):
            raise ReviewPackageError(f"Observed input evidence changed: {scope}:{relative_path}")
        retain(
            {
                "source_scope": scope,
                "relative_path": path.relative_to(root.resolve()).as_posix(),
                "size_bytes": size_bytes,
                "sha256": sha256,
                "data_rows": data_rows,
                "purpose": purpose,
            },
            purpose,
        )

    for year in years:
        year_dir = legacy_root / "Raw_Access_Databases" / str(year)
        add("legacy_root", legacy_root, year_dir / "manifest.csv", "annual source identity manifest")
        for name, purpose in (
            ("table_inventory.csv", "annual exported-table inventory"),
            ("row_count_report.csv", "annual Access-to-CSV row reconciliation"),
            ("table_columns.csv", "annual source-column inventory"),
        ):
            add("legacy_root", legacy_root, year_dir / "metadata" / name, purpose)
    add(
        "legacy_root",
        legacy_root,
        legacy_root / "Checks" / "extract_qc" / "table_inventory_all_years.csv",
        "global exported-table inventory",
    )

    _, overrides = read_csv(repo_root / "contracts" / "dictionary_ambiguity_overrides.csv")
    ambiguity_sources: set[tuple[int, str]] = set()
    for override in overrides:
        if override.get("contract_id") == contract_id:
            ambiguity_sources.add(
                (int(override["year_start"]), override["selected_metadata_table_name"])
            )
    for year, table_name in sorted(ambiguity_sources):
        candidates = sorted(
            path
            for path in (legacy_root / "Raw_Access_Databases" / str(year) / "tables_csv").glob("*.csv")
            if path.stem.casefold() == table_name.casefold()
        )
        if len(candidates) != 1:
            raise ReviewPackageError(
                f"Expected one ambiguity metadata source for {year} {table_name}, found {len(candidates)}"
            )
        add("legacy_root", legacy_root, candidates[0], "dictionary ambiguity source metadata")

    for _category, relative in LEGACY_DIAGNOSTICS:
        path = safe_child(legacy_root, relative)
        if path.is_file():
            add("legacy_root", legacy_root, path, "legacy diagnostic context")

    for record in source_verification:
        add_observed(
            scope="legacy_root",
            root=legacy_root,
            relative_path=str(record["relative_path"]),
            size_bytes=record["observed_size_bytes"],
            sha256=record["observed_sha256"],
            data_rows="",
            purpose=f"verified source payload ({record['artifact_kind']})",
        )
    for record in table_rows:
        add_observed(
            scope="legacy_root",
            root=legacy_root,
            relative_path=str(record["csv_relative_path"]),
            size_bytes=record["observed_csv_size_bytes"],
            sha256=record["observed_csv_sha256"],
            data_rows=record["row_count_csv_observed"],
            purpose="directly parsed and hashed exported table CSV",
        )

    contract_dir = repo_root / "contracts"
    contract_paths = [contract_dir / "panel_spec.toml", *sorted(contract_dir.glob("*.csv"))]
    for path in contract_paths:
        add("current_repo", repo_root, path, "current release contract input")
    add(
        "current_repo",
        repo_root,
        repo_root / "Artifacts" / "release_validation_plan.md",
        "review blocker and execution-plan evidence",
    )

    generator_path = Path(__file__).resolve()
    add("generator", generator_path.parent, generator_path, "review-package generator implementation")
    return [inputs[key] for key in sorted(inputs)]


def count_v2_stage02_evidence(legacy_root: Path, years: Sequence[int]) -> dict[str, int]:
    counts = Counter()
    for year in years:
        year_dir = legacy_root / "Raw_Access_Databases" / str(year)
        if (year_dir / "metadata" / "extraction_receipt.csv").is_file():
            counts["extraction_receipts"] += 1
        if (year_dir / "qc" / "extraction_cache_manifest.json").is_file():
            counts["cache_manifests"] += 1
        if (year_dir / "extracted_db" / "CURRENT").is_file():
            counts["current_pointers"] += 1
        counts["table_export_manifests"] += sum(
            1 for _ in (year_dir / "tables_csv").glob("*.csv.export-manifest.json")
        )
    return {
        "extraction_receipts": counts["extraction_receipts"],
        "cache_manifests": counts["cache_manifests"],
        "current_pointers": counts["current_pointers"],
        "table_export_manifests": counts["table_export_manifests"],
    }


def build_blockers(
    contract_counts: Mapping[str, int],
    source_candidate_count: int,
    ambiguity_rows: Sequence[Mapping[str, object]],
    stage02: Mapping[str, int],
    table_metrics: Mapping[str, object],
    legacy_root: Path,
) -> list[dict[str, object]]:
    ambiguity_keys = {
        (row["year"], row["access_table_name"], row["requested_varname"])
        for row in ambiguity_rows
    }
    benchmark_candidates = sorted(
        path.relative_to(legacy_root).as_posix()
        for path in legacy_root.rglob("*")
        if path.is_file() and "benchmark" in path.name.casefold()
    )
    blockers = [
        (
            "B01",
            "source_lock",
            f"canonical_rows={contract_counts['source_releases']}; verified_candidates={source_candidate_count}",
            "Independently confirm each final NCES release identity, then add reviewer, approval timestamp, and notes.",
            "false",
            "source_releases_candidate.csv; source_release_verification.csv",
        ),
        (
            "B02",
            "dictionary_ambiguity",
            f"pending_identity_decisions={len(ambiguity_keys)}",
            "Select exactly one metadata identity for every ambiguity and record reviewer evidence.",
            "false",
            "dictionary_ambiguity_review.csv",
        ),
        (
            "B03",
            "table_grain",
            f"canonical_rows={contract_counts['table_grain']}; inventory_rows={table_metrics['table_inventory_rows']}",
            "Review every inventoried table, including zero-row data tables, and populate scalar, dimensioned, metadata, or excluded grain decisions.",
            "false",
            "table_review_inventory.csv",
        ),
        (
            "B04",
            "source_columns",
            f"canonical_rows={contract_counts['source_columns']}; inventory_rows={table_metrics['source_column_records']}",
            "Review every source column role, dimension identity, and exclusion reason.",
            "false",
            "source_column_review.csv",
        ),
        (
            "B05",
            "analysis_schema",
            f"canonical_rows={contract_counts['analysis_schema']}",
            "Approve the materialized analysis variables, transformations, types, nullability, and active years.",
            "false",
            "contracts/analysis_schema.csv",
        ),
        (
            "B06",
            "discrete_semantics",
            f"canonical_rows={contract_counts['discrete_families']}",
            "Review component families, tokens, outputs, and multi-active behavior from source documentation.",
            "false",
            "legacy_diagnostic_inventory.csv; contracts/discrete_families.csv",
        ),
        (
            "B07",
            "prch_policy",
            f"canonical_rows={contract_counts['prch_policy']}",
            "Approve exact year, flag, code, predicate, target-column, accounting/form/part actions.",
            "false",
            "legacy_diagnostic_inventory.csv; contracts/prch_policy.csv",
        ),
        (
            "B08",
            "external_benchmarks",
            f"canonical_rows={contract_counts['external_benchmarks']}; legacy_named_candidates={len(benchmark_candidates)}",
            "Collect and review at least 15 independent, source-backed benchmarks spanning the required coverage.",
            "false",
            "contracts/external_benchmarks.csv",
        ),
        (
            "B09",
            "metadata_backfill",
            f"canonical_approval_rows={contract_counts['metadata_backfill_approvals']}",
            "Review any required donor/backfill at the variable level; do not inherit v1 synthetic decisions.",
            "false",
            "legacy_diagnostic_inventory.csv; contracts/metadata_backfill_approvals.csv",
        ),
        (
            "B10",
            "stage02_provenance",
            (
                f"receipts={stage02['extraction_receipts']}; cache_manifests={stage02['cache_manifests']}; "
                f"current_pointers={stage02['current_pointers']}; "
                f"table_export_manifests={stage02['table_export_manifests']}"
            ),
            "Regenerate/reseal extraction with v2 tool bindings, receipts, cache manifests, and per-table export manifests.",
            "true",
            "source_release_verification.csv; table_review_inventory.csv",
        ),
        (
            "B11",
            "sealed_real_run",
            "not_run",
            "After reviews, execute one clean locked 2004-2023 run and retain its durable gate verdict and bundle evidence.",
            "true",
            "Artifacts/release_validation_plan.md",
        ),
    ]
    return [
        {
            "blocker_id": blocker_id,
            "area": area,
            "status": "BLOCKED",
            "observed": observed,
            "required_action": required_action,
            "machine_approvable": machine_approvable,
            "evidence": evidence,
        }
        for blocker_id, area, observed, required_action, machine_approvable, evidence in blockers
    ]


def panel_release_ready(repo_root: Path) -> bool:
    path = repo_root / "contracts" / "panel_spec.toml"
    with path.open("rb") as handle:
        value = tomllib.load(handle).get("release_ready", False)
    return value is True


def panel_contract_id(repo_root: Path) -> str:
    path = repo_root / "contracts" / "panel_spec.toml"
    with path.open("rb") as handle:
        return str(tomllib.load(handle).get("contract_id", "")).strip()


def git_context(repo_root: Path) -> dict[str, object]:
    def run(*args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            ["git", "-C", str(repo_root), *args],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=10,
        )

    try:
        revision = run("rev-parse", "HEAD")
        status = run("status", "--porcelain", "--untracked-files=all")
    except (OSError, subprocess.SubprocessError):
        return {"available": False, "commit": "", "dirty": None, "status_entry_count": None}
    if revision.returncode != 0 or status.returncode != 0:
        return {"available": False, "commit": "", "dirty": None, "status_entry_count": None}
    entries = [line for line in status.stdout.splitlines() if line]
    return {
        "available": True,
        "commit": revision.stdout.strip(),
        "dirty": bool(entries),
        "status_entry_count": len(entries),
    }


def build_readme(summary: Mapping[str, object]) -> str:
    source = summary["source_integrity"]
    tables = summary["legacy_extraction"]
    contracts = summary["canonical_contract_rows"]
    lines = [
        "# IPEDSDB v2 contract review package",
        "",
        "Verdict: **BLOCKED_REVIEW_REQUIRED**.",
        "",
        "This package verifies machine-derivable facts from a legacy artifact root. It does not approve or",
        "modify any canonical contract, and it is not evidence that a real v2 release has passed.",
        "",
        "## Verified mechanical evidence",
        "",
        f"- Years: {summary['years'][0]}-{summary['years'][-1]} ({len(summary['years'])})",
        f"- Annual manifests: {source['annual_manifests']}",
        f"- Download artifacts matching archived size, SHA-256, and ZIP CRC: {source['download_integrity_passes']}/{source['download_artifacts']}",
        f"- Extracted Access databases matching both manifest and archive member: {source['extracted_database_integrity_passes']}/{len(summary['years'])}",
        f"- Exported table CSV hashes directly verified: {tables['table_csv_hash_matches']}/{tables['table_inventory_rows']}",
        f"- Direct CSV record counts matching bound legacy Access row-count reports: {tables['row_count_matches']}/{tables['table_inventory_rows']}",
        f"- Direct CSV headers matching bound column inventories: {tables['column_name_matches']}/{tables['table_inventory_rows']}",
        f"- Source-column inventory rows: {tables['source_column_records']}",
        f"- Zero-row legacy tables: {len(tables['zero_row_tables'])}",
        f"- Repository commit: {summary['repo_git']['commit'] or 'unavailable'}",
        f"- Repository dirty at package time: {summary['repo_git']['dirty']}",
        "",
        "## Non-approval boundary",
        "",
        "- `source_releases_candidate.csv` is pending by construction; all approval fields remain empty.",
        "- Table grain remains `unknown` and every table/column review row remains `reviewed=false`.",
        "- Dictionary candidates are shown side-by-side without resolving identity choices.",
        "- Legacy PRCH, discrete, dictionary, and wide files are indexed only as diagnostics.",
        "- No benchmark is inferred from the panel or legacy QA output.",
        "",
        "## Canonical contract rows at package time",
        "",
    ]
    lines.extend(f"- `{name}.csv`: {count}" for name, count in sorted(contracts.items()))
    lines.extend(
        [
            "",
            "See `review_blockers.csv` for the ordered review and regeneration work. `input_evidence_manifest.csv`",
            "binds every source payload, exported table, metadata report, contract, diagnostic, and the generator;",
            "`package_manifest.csv` binds every generated evidence file to its byte size and SHA-256.",
            "The Access row counts are archived report evidence, not a fresh mdb-tools query; Stage 02 must still",
            "regenerate and reseal extraction under the v2 toolchain.",
            "",
            "Code and synthetic regression checks may pass while the 2004-2023 real-data release remains",
            "unverified. Do not call the panel final until all reviews and one clean sealed real run pass.",
            "",
        ]
    )
    return "\n".join(lines)


def write_package_manifest(directory: Path) -> None:
    rows: list[dict[str, object]] = []
    for path in sorted(directory.iterdir(), key=lambda item: item.name):
        if not path.is_file() or path.name == "package_manifest.csv":
            continue
        rows.append(
            {
                "relative_path": path.name,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_path(path),
                "data_rows": csv_data_row_count(path) if path.suffix.lower() == ".csv" else "",
            }
        )
    write_csv(directory / "package_manifest.csv", MANIFEST_FIELDS, rows)


def verify_package(directory: Path, *, verify_external_inputs: bool = True) -> None:
    """Verify package bytes and the invariants that prevent accidental approval."""
    manifest_path = directory / "package_manifest.csv"
    fields, manifest_rows = read_csv(manifest_path)
    require_fields(manifest_path, fields, MANIFEST_FIELDS)
    actual_files = {
        path.name
        for path in directory.iterdir()
        if path.is_file()
    }
    if actual_files != REQUIRED_PACKAGE_FILES:
        raise ReviewPackageError("Review package file inventory is not the required exact set")
    expected_files = actual_files - {manifest_path.name}
    manifested_files = {row["relative_path"] for row in manifest_rows}
    if expected_files != manifested_files or len(manifested_files) != len(manifest_rows):
        raise ReviewPackageError("Package manifest file inventory is not exact")
    for row in manifest_rows:
        path = directory / row["relative_path"]
        if path.stat().st_size != int(row["size_bytes"]):
            raise ReviewPackageError(f"Package size verification failed: {path.name}")
        if sha256_path(path) != row["sha256"]:
            raise ReviewPackageError(f"Package SHA-256 verification failed: {path.name}")
        if path.suffix.lower() == ".csv" and csv_data_row_count(path) != int(row["data_rows"]):
            raise ReviewPackageError(f"Package row-count verification failed: {path.name}")

    summary = json.loads((directory / "review_summary.json").read_text(encoding="utf-8"))
    _, input_rows = read_csv(directory / "input_evidence_manifest.csv")
    if not input_rows or len(input_rows) != int(summary.get("input_evidence_files", -1)):
        raise ReviewPackageError("Input evidence manifest is empty or disagrees with the summary")
    if verify_external_inputs:
        roots = {
            "legacy_root": Path(str(summary["legacy_root"])),
            "current_repo": Path(str(summary["repo_root"])),
        }
        generator_path = Path(str(summary["generator_path"])).resolve()
        for row in input_rows:
            scope = row["source_scope"]
            if scope == "generator":
                path = generator_path
                if row["relative_path"] != generator_path.name:
                    raise ReviewPackageError("Generator evidence path disagrees with the summary")
            elif scope in roots:
                path = safe_child(roots[scope], row["relative_path"])
            else:
                raise ReviewPackageError(f"Unknown input evidence scope: {scope}")
            if not path.is_file() or path.stat().st_size != int(row["size_bytes"]):
                raise ReviewPackageError(f"Input evidence size verification failed: {scope}:{row['relative_path']}")
            if sha256_path(path) != row["sha256"]:
                raise ReviewPackageError(f"Input evidence SHA-256 verification failed: {scope}:{row['relative_path']}")
            if path.suffix.lower() == ".csv" and csv_data_row_count(path) != int(row["data_rows"]):
                raise ReviewPackageError(f"Input evidence row-count verification failed: {scope}:{row['relative_path']}")

    input_keys = {
        (row["source_scope"], row["relative_path"])
        for row in input_rows
    }
    _, source_verification_rows = read_csv(directory / "source_release_verification.csv")
    if not source_verification_rows or any(
        row["integrity_verdict"] != "PASS"
        or row["sha256_match"].casefold() != "true"
        for row in source_verification_rows
    ):
        raise ReviewPackageError("Source payload verification is incomplete or failing")
    missing_source_bindings = {
        ("legacy_root", row["relative_path"])
        for row in source_verification_rows
    } - input_keys
    if missing_source_bindings:
        raise ReviewPackageError("Source payloads are missing from the input evidence manifest")

    _, source_rows = read_csv(directory / "source_releases_candidate.csv")
    if not source_rows or any(
        row["lock_status"].casefold() != "pending" or row["approved_at"]
        for row in source_rows
    ):
        raise ReviewPackageError("Source candidates crossed the non-approval boundary")
    _, table_rows = read_csv(directory / "table_review_inventory.csv")
    if not table_rows or any(
        row["contract_grain_class"].casefold() != "unknown"
        or row["reviewed"].casefold() != "false"
        or row["v2_reusable"].casefold() != "false"
        or row["row_count_match"].casefold() != "true"
        or row["column_count_match"].casefold() != "true"
        or row["column_names_match"].casefold() != "true"
        or row["csv_sha256_match"].casefold() != "true"
        for row in table_rows
    ):
        raise ReviewPackageError("Table review inventory crossed the non-approval boundary")
    missing_table_bindings = {
        ("legacy_root", row["csv_relative_path"])
        for row in table_rows
    } - input_keys
    if missing_table_bindings:
        raise ReviewPackageError("Exported table payloads are missing from the input evidence manifest")
    _, column_rows = read_csv(directory / "source_column_review.csv")
    if not column_rows or any(row["reviewed"].casefold() != "false" for row in column_rows):
        raise ReviewPackageError("Source-column review crossed the non-approval boundary")
    _, ambiguity_rows = read_csv(directory / "dictionary_ambiguity_review.csv")
    if any(
        row["reviewed"].casefold() != "false"
        or row["pending_review_status"].casefold() != "pending"
        for row in ambiguity_rows
    ):
        raise ReviewPackageError("Dictionary ambiguity review crossed the non-approval boundary")
    ambiguity_groups: dict[tuple[str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in ambiguity_rows:
        ambiguity_groups[(row["year"], row["access_table_name"], row["requested_varname"])].append(row)
    if any(
        len(group) != int(group[0]["candidate_count"])
        or sum(row["selected_by_pending_override"].casefold() == "true" for row in group) != 1
        for group in ambiguity_groups.values()
    ):
        raise ReviewPackageError("Dictionary ambiguity selection cardinality is not exact")
    _, diagnostic_rows = read_csv(directory / "legacy_diagnostic_inventory.csv")
    if any(row["release_usable"].casefold() != "false" for row in diagnostic_rows):
        raise ReviewPackageError("Legacy diagnostics were incorrectly marked release-usable")
    _, blocker_rows = read_csv(directory / "review_blockers.csv")
    if not blocker_rows or any(row["status"] != "BLOCKED" for row in blocker_rows):
        raise ReviewPackageError("Review blocker inventory is not fail-closed")
    if summary.get("release_verdict") != "BLOCKED_REVIEW_REQUIRED":
        raise ReviewPackageError("Review summary does not retain the blocked verdict")


def build_package(
    *,
    legacy_root: Path,
    out_dir: Path,
    repo_root: Path,
    contract_id: str,
    years: Sequence[int],
) -> dict[str, object]:
    legacy_root = legacy_root.expanduser().resolve()
    repo_root = repo_root.expanduser().resolve()
    out_dir = out_dir.expanduser().resolve()
    if not (legacy_root / "Raw_Access_Databases").is_dir():
        raise ReviewPackageError(f"Not an IPEDSDB artifact root: {legacy_root}")
    if not (repo_root / "contracts" / "panel_spec.toml").is_file():
        raise ReviewPackageError(f"Not an IPEDSDB repository root: {repo_root}")
    declared_contract_id = panel_contract_id(repo_root)
    if contract_id != declared_contract_id:
        raise ReviewPackageError(
            f"Contract ID mismatch: requested {contract_id!r}, panel_spec.toml declares {declared_contract_id!r}"
        )
    if is_within(out_dir, legacy_root):
        raise ReviewPackageError(
            f"Output directory must be outside the read-only legacy root: {out_dir}"
        )
    if is_within(out_dir, repo_root):
        raise ReviewPackageError(
            f"Output directory must be outside the repository and its contracts: {out_dir}"
        )
    if out_dir.exists():
        raise ReviewPackageError(f"Output directory already exists; refusing to overwrite: {out_dir}")
    out_dir.parent.mkdir(parents=True, exist_ok=True)

    source_candidates, source_verification, source_metrics = build_source_evidence(
        legacy_root, years, contract_id
    )
    table_rows, column_rows, table_metrics = build_table_evidence(
        legacy_root, years, contract_id
    )
    ambiguity_rows = build_ambiguity_evidence(legacy_root, repo_root, contract_id)
    diagnostics = build_diagnostic_inventory(legacy_root)
    input_evidence = build_input_evidence_inventory(
        legacy_root,
        repo_root,
        years,
        contract_id,
        source_verification,
        table_rows,
    )
    contract_counts = canonical_contract_counts(repo_root)
    stage02 = count_v2_stage02_evidence(legacy_root, years)
    blockers = build_blockers(
        contract_counts,
        len(source_candidates),
        ambiguity_rows,
        stage02,
        table_metrics,
        legacy_root,
    )
    summary: dict[str, object] = {
        "schema_version": "1.0",
        "package_kind": "non_approving_contract_review",
        "contract_id": contract_id,
        "legacy_root": str(legacy_root),
        "repo_root": str(repo_root),
        "repo_git": git_context(repo_root),
        "generator_path": str(Path(__file__).resolve()),
        "years": list(years),
        "release_verdict": "BLOCKED_REVIEW_REQUIRED",
        "release_ready_in_panel_spec": panel_release_ready(repo_root),
        "source_integrity": source_metrics,
        "legacy_extraction": table_metrics,
        "canonical_contract_rows": contract_counts,
        "pending_dictionary_ambiguities": len(
            {
                (row["year"], row["access_table_name"], row["requested_varname"])
                for row in ambiguity_rows
            }
        ),
        "stage02_v2_evidence": stage02,
        "blocker_count": len(blockers),
        "input_evidence_files": len(input_evidence),
        "non_approval_guarantees": [
            "source lock rows remain pending and have no approval timestamp",
            "table grain remains unknown",
            "all table and column review rows remain reviewed=false",
            "dictionary ambiguities remain unresolved",
            "legacy diagnostics are not treated as contracts or benchmarks",
            "canonical contract files are not modified",
        ],
    }

    with tempfile.TemporaryDirectory(prefix=f".{out_dir.name}.", dir=out_dir.parent) as temp_name:
        staging = Path(temp_name) / "package"
        staging.mkdir()
        write_csv(staging / "source_releases_candidate.csv", SOURCE_RELEASE_FIELDS, source_candidates)
        write_csv(staging / "source_release_verification.csv", SOURCE_VERIFICATION_FIELDS, source_verification)
        write_csv(staging / "table_review_inventory.csv", TABLE_REVIEW_FIELDS, table_rows)
        write_csv(staging / "source_column_review.csv", COLUMN_REVIEW_FIELDS, column_rows)
        write_csv(staging / "dictionary_ambiguity_review.csv", AMBIGUITY_REVIEW_FIELDS, ambiguity_rows)
        write_csv(staging / "legacy_diagnostic_inventory.csv", DIAGNOSTIC_FIELDS, diagnostics)
        write_csv(staging / "input_evidence_manifest.csv", INPUT_EVIDENCE_FIELDS, input_evidence)
        write_csv(staging / "review_blockers.csv", BLOCKER_FIELDS, blockers)
        (staging / "review_summary.json").write_text(
            json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
        )
        (staging / "README.md").write_text(build_readme(summary), encoding="utf-8")
        write_package_manifest(staging)
        verify_package(staging)
        os.replace(staging, out_dir)
    return summary


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        summary = build_package(
            legacy_root=Path(args.legacy_root),
            out_dir=Path(args.out_dir),
            repo_root=Path(args.repo_root),
            contract_id=str(args.contract_id).strip(),
            years=parse_years(args.years),
        )
    except (OSError, ValueError, ReviewPackageError) as exc:
        print(f"ERROR: {exc}")
        return 1
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
