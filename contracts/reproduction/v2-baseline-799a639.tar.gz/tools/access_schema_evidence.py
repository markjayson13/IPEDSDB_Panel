#!/usr/bin/env python3
"""Read-only helpers for exact Access schema and index evidence."""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Final


_IDENTIFIER_PATTERN: Final[str] = (
    r'(?:"(?:[^"]|"")*"|\[(?:[^\]]|\]\])*\]|[A-Za-z_][A-Za-z0-9_$#@]*)'
)
_CREATE_TABLE_HEADER = re.compile(
    rf"^\s*CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?\s+"
    rf"(?P<table>{_IDENTIFIER_PATTERN})(?P<tail>.*)$",
    re.IGNORECASE | re.DOTALL,
)
_CREATE_INDEX_HEADER = re.compile(
    rf"^\s*CREATE\s+(?P<unique>UNIQUE\s+)?INDEX"
    rf"(?:\s+IF\s+NOT\s+EXISTS)?\s+"
    rf"(?P<index>{_IDENTIFIER_PATTERN})\s+ON\s+"
    rf"(?P<table>{_IDENTIFIER_PATTERN})(?P<tail>.*)$",
    re.IGNORECASE | re.DOTALL,
)
_ALTER_TABLE_HEADER = re.compile(
    rf"^\s*ALTER\s+TABLE(?:\s+ONLY)?\s+"
    rf"(?P<table>{_IDENTIFIER_PATTERN})(?P<tail>.*)$",
    re.IGNORECASE | re.DOTALL,
)
_INDEX_COLUMNS = re.compile(
    rf"^\s*(?:USING\s+{_IDENTIFIER_PATTERN}\s*)?"
    r"\((?P<columns>.*)\)\s*$",
    re.IGNORECASE | re.DOTALL,
)
_PRIMARY_KEY = re.compile(
    rf"^\s*ADD\s+(?:CONSTRAINT\s+{_IDENTIFIER_PATTERN}\s+)?"
    r"PRIMARY\s+KEY\s*\((?P<columns>.*)\)\s*$",
    re.IGNORECASE | re.DOTALL,
)
_INLINE_PRIMARY_KEY = re.compile(
    rf"(?:\bCONSTRAINT\s+{_IDENTIFIER_PATTERN}\s+)?"
    r"\bPRIMARY\s+KEY\s*\((?P<columns>[^()]*)\)",
    re.IGNORECASE | re.DOTALL,
)
_PRIMARY_KEY_TOKEN = re.compile(
    r"\bPRIMARY\s+KEY\b",
    re.IGNORECASE,
)


class SchemaEvidenceError(ValueError):
    """Schema evidence is ambiguous or cannot be parsed safely."""

    def __init__(self, status: str, reason: str):
        super().__init__(reason)
        self.status = status
        self.reason = reason


@dataclass(frozen=True)
class AnnualSchemaProbe:
    """Exact bytes and provenance returned by a read-only annual schema probe."""

    schema_bytes: bytes
    source_schema_sha256: str
    command: tuple[str, ...]
    tool_path: str
    tool_version: str
    database_path: str
    database_sha256: str


def _parse_error(reason: str) -> SchemaEvidenceError:
    return SchemaEvidenceError("parse_error", reason)


def _split_sql_statements(sql: str) -> list[str]:
    """Split SQL on unquoted semicolons while removing comments."""

    statements: list[str] = []
    current: list[str] = []
    state = "normal"
    index = 0

    while index < len(sql):
        char = sql[index]
        following = sql[index + 1] if index + 1 < len(sql) else ""

        if state == "normal":
            if char == "-" and following == "-":
                current.extend((" ", " "))
                index += 2
                state = "line_comment"
                continue
            if char == "/" and following == "*":
                current.extend((" ", " "))
                index += 2
                state = "block_comment"
                continue
            if char == "'":
                state = "single_quote"
            elif char == '"':
                state = "double_quote"
            elif char == "[":
                state = "bracket"
            elif char == ";":
                statement = "".join(current).strip()
                if statement:
                    statements.append(statement)
                current = []
                index += 1
                continue
            current.append(char)
            index += 1
            continue

        if state == "line_comment":
            if char in "\r\n":
                current.append(char)
                state = "normal"
            else:
                current.append(" ")
            index += 1
            continue

        if state == "block_comment":
            if char == "*" and following == "/":
                current.extend((" ", " "))
                index += 2
                state = "normal"
            else:
                current.append(char if char in "\r\n" else " ")
                index += 1
            continue

        current.append(char)
        if state == "single_quote" and char == "'":
            if following == "'":
                current.append(following)
                index += 2
                continue
            state = "normal"
        elif state == "double_quote" and char == '"':
            if following == '"':
                current.append(following)
                index += 2
                continue
            state = "normal"
        elif state == "bracket" and char == "]":
            if following == "]":
                current.append(following)
                index += 2
                continue
            state = "normal"
        index += 1

    if state in {"single_quote", "double_quote", "bracket", "block_comment"}:
        raise _parse_error(f"Unterminated SQL token while in {state}.")

    statement = "".join(current).strip()
    if statement:
        statements.append(statement)
    return statements


def _is_unquoted_sql_position(sql: str, position: int) -> bool:
    """Return whether ``position`` is outside SQL string/identifier quotes."""

    state = "normal"
    index = 0
    while index < position:
        char = sql[index]
        following = sql[index + 1] if index + 1 < len(sql) else ""

        if state == "normal":
            if char == "'":
                state = "single_quote"
            elif char == '"':
                state = "double_quote"
            elif char == "[":
                state = "bracket"
            index += 1
            continue

        if state == "single_quote" and char == "'":
            if following == "'":
                index += 2
                continue
            state = "normal"
        elif state == "double_quote" and char == '"':
            if following == '"':
                index += 2
                continue
            state = "normal"
        elif state == "bracket" and char == "]":
            if following == "]":
                index += 2
                continue
            state = "normal"
        index += 1

    return state == "normal"


def _unquote_identifier(token: str) -> str:
    if token.startswith('"'):
        return token[1:-1].replace('""', '"')
    if token.startswith("["):
        return token[1:-1].replace("]]", "]")
    return token


def _consume_identifier(text: str, position: int) -> tuple[str, int] | None:
    while position < len(text) and text[position].isspace():
        position += 1
    if position >= len(text):
        return None

    first = text[position]
    if first == '"':
        cursor = position + 1
        value: list[str] = []
        while cursor < len(text):
            if text[cursor] == '"':
                if cursor + 1 < len(text) and text[cursor + 1] == '"':
                    value.append('"')
                    cursor += 2
                    continue
                return "".join(value), cursor + 1
            value.append(text[cursor])
            cursor += 1
        return None

    if first == "[":
        cursor = position + 1
        value = []
        while cursor < len(text):
            if text[cursor] == "]":
                if cursor + 1 < len(text) and text[cursor + 1] == "]":
                    value.append("]")
                    cursor += 2
                    continue
                return "".join(value), cursor + 1
            value.append(text[cursor])
            cursor += 1
        return None

    match = re.match(r"[A-Za-z_][A-Za-z0-9_$#@]*", text[position:])
    if match is None:
        return None
    return match.group(0), position + match.end()


def _parse_column_list(raw_columns: str, *, context: str) -> tuple[str, ...]:
    columns: list[str] = []
    position = 0

    while True:
        while position < len(raw_columns) and raw_columns[position].isspace():
            position += 1
        if position >= len(raw_columns):
            break

        parsed = _consume_identifier(raw_columns, position)
        if parsed is None:
            raise _parse_error(
                f"{context} contains an expression or malformed column at "
                f"offset {position}."
            )
        column, position = parsed
        if "|" in column:
            raise _parse_error(
                f"{context} contains identifier {column!r} with the "
                "serialization delimiter '|'."
            )

        while position < len(raw_columns) and raw_columns[position].isspace():
            position += 1
        direction = re.match(r"(?:ASC|DESC)\b", raw_columns[position:], re.IGNORECASE)
        if direction is not None:
            position += direction.end()
            while position < len(raw_columns) and raw_columns[position].isspace():
                position += 1

        if position < len(raw_columns) and raw_columns[position] != ",":
            raise _parse_error(
                f"{context} contains an expression or unsupported index modifier "
                f"at offset {position}."
            )

        normalized = column.upper()
        if normalized in columns:
            raise _parse_error(
                f"{context} repeats column {normalized}; it is not a usable key."
            )
        columns.append(normalized)

        if position >= len(raw_columns):
            break
        position += 1
        if not raw_columns[position:].strip():
            raise _parse_error(f"{context} ends with an empty column.")

    if not columns:
        raise _parse_error(f"{context} has no columns.")
    return tuple(columns)


def _serialize_indexes(
    indexes: list[tuple[str, tuple[str, ...]]],
) -> str:
    ordered = sorted(
        indexes,
        key=lambda item: (item[0].casefold(), tuple(part.casefold() for part in item[1])),
    )
    return " || ".join(
        f"{index_name.upper()}={'|'.join(columns)}"
        for index_name, columns in ordered
    )


def parse_table_schema_evidence(
    schema_bytes: bytes,
    access_table_name: str,
    *,
    indexes_requested: bool,
) -> dict[str, str]:
    """Parse declared keys for one exact Access table identity.

    Table matching is case-insensitive because Access identifiers are
    case-insensitive. No punctuation removal, year stripping, or other lossy
    normalization is used.
    """

    source_schema_sha256 = hashlib.sha256(schema_bytes).hexdigest()
    if not access_table_name or not access_table_name.strip():
        raise _parse_error("The exact Access table name must be nonempty.")
    try:
        sql = schema_bytes.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise _parse_error(f"Schema bytes are not valid UTF-8: {exc}.") from exc

    statements = _split_sql_statements(sql)
    target = access_table_name.casefold()
    table_statements: list[tuple[str, str]] = []

    for statement in statements:
        if not re.match(r"^\s*CREATE\s+TABLE\b", statement, re.IGNORECASE):
            continue
        match = _CREATE_TABLE_HEADER.match(statement)
        if match is None:
            continue
        table_name = _unquote_identifier(match.group("table"))
        if table_name.casefold() != target:
            continue
        if not match.group("tail").lstrip().startswith("("):
            raise _parse_error(
                f"Malformed CREATE TABLE statement for exact target "
                f"{access_table_name!r}."
            )
        table_statements.append((table_name, match.group("tail")))

    if len(table_statements) > 1:
        identities = ", ".join(sorted(name for name, _ in table_statements))
        raise SchemaEvidenceError(
            "multiple_table_definitions",
            f"Multiple CREATE TABLE definitions match exact identity "
            f"{access_table_name!r}: {identities}.",
        )

    empty_result = {
        "declared_primary_key": "",
        "declared_unique_indexes": "",
        "declared_nonunique_indexes": "",
        "schema_key_parse_status": "table_missing",
        "schema_key_parse_reason": (
            f"No exact case-insensitive CREATE TABLE identity matched "
            f"{access_table_name!r}; lossy normalization was not used."
        ),
        "source_schema_sha256": source_schema_sha256,
    }
    if not table_statements:
        return empty_result

    primary_keys: list[tuple[str, ...]] = []
    unique_indexes: list[tuple[str, tuple[str, ...]]] = []
    nonunique_indexes: list[tuple[str, tuple[str, ...]]] = []
    seen_index_names: set[str] = set()

    create_tail = table_statements[0][1]
    supported_inline_primary_key_spans: list[tuple[int, int]] = []
    for inline_match in _INLINE_PRIMARY_KEY.finditer(create_tail):
        if not _is_unquoted_sql_position(create_tail, inline_match.start()):
            continue
        supported_inline_primary_key_spans.append(inline_match.span())
        primary_keys.append(
            _parse_column_list(
                inline_match.group("columns"),
                context=f"inline primary key for {access_table_name}",
            )
        )
    for primary_key_token in _PRIMARY_KEY_TOKEN.finditer(create_tail):
        if not _is_unquoted_sql_position(create_tail, primary_key_token.start()):
            continue
        if any(
            start <= primary_key_token.start() < end
            for start, end in supported_inline_primary_key_spans
        ):
            continue
        raise _parse_error(
            f"Unsupported or malformed primary-key definition in CREATE TABLE "
            f"for exact target {access_table_name!r}."
        )

    for statement in statements:
        if re.match(
            r"^\s*CREATE\s+(?:UNIQUE\s+)?INDEX\b",
            statement,
            re.IGNORECASE,
        ):
            header = _CREATE_INDEX_HEADER.match(statement)
            if header is None:
                raise _parse_error("Malformed CREATE INDEX statement in schema evidence.")
            table_name = _unquote_identifier(header.group("table"))
            if table_name.casefold() != target:
                continue

            index_name = _unquote_identifier(header.group("index"))
            if "|" in index_name:
                raise _parse_error(
                    f"Index identifier {index_name!r} contains the "
                    "serialization delimiter '|'."
                )
            index_identity = index_name.casefold()
            if index_identity in seen_index_names:
                raise _parse_error(
                    f"Duplicate index identity {index_name!r} for "
                    f"{access_table_name!r}."
                )
            seen_index_names.add(index_identity)

            columns_match = _INDEX_COLUMNS.match(header.group("tail"))
            if columns_match is None:
                raise _parse_error(
                    f"Index {index_name!r} for {access_table_name!r} has an "
                    "unsupported or malformed definition."
                )
            columns = _parse_column_list(
                columns_match.group("columns"),
                context=f"index {index_name}",
            )
            destination = (
                unique_indexes if header.group("unique") else nonunique_indexes
            )
            destination.append((index_name, columns))
            continue

        if not re.match(r"^\s*ALTER\s+TABLE\b", statement, re.IGNORECASE):
            continue
        header = _ALTER_TABLE_HEADER.match(statement)
        if header is None:
            if re.search(r"\bPRIMARY\s+KEY\b", statement, re.IGNORECASE):
                raise _parse_error("Malformed ALTER TABLE primary-key statement.")
            continue
        table_name = _unquote_identifier(header.group("table"))
        if table_name.casefold() != target:
            continue
        tail = header.group("tail")
        if not re.search(r"\bPRIMARY\s+KEY\b", tail, re.IGNORECASE):
            continue
        primary_match = _PRIMARY_KEY.match(tail)
        if primary_match is None:
            raise _parse_error(
                f"Primary-key definition for {access_table_name!r} is malformed."
            )
        primary_keys.append(
            _parse_column_list(
                primary_match.group("columns"),
                context=f"primary key for {access_table_name}",
            )
        )

    if len(primary_keys) > 1:
        raise SchemaEvidenceError(
            "multiple_primary_keys",
            f"Multiple primary-key definitions were found for "
            f"{access_table_name!r}.",
        )

    primary_key = "|".join(primary_keys[0]) if primary_keys else ""
    serialized_unique = _serialize_indexes(unique_indexes)
    serialized_nonunique = _serialize_indexes(nonunique_indexes)
    evidence_count = len(primary_keys) + len(unique_indexes) + len(nonunique_indexes)

    if not indexes_requested and evidence_count == 0:
        status = "indexes_not_exported"
        reason = (
            f"Exact table definition {table_statements[0][0]!r} was found, but "
            "indexes were not exported; declared key absence cannot be inferred."
        )
    else:
        status = "exact_indexes_parsed"
        if evidence_count:
            reason = (
                f"Parsed exact table identity {table_statements[0][0]!r}: "
                f"{len(primary_keys)} primary key(s), "
                f"{len(unique_indexes)} unique index(es), and "
                f"{len(nonunique_indexes)} nonunique index(es)."
            )
        else:
            reason = (
                f"Parsed exact table identity {table_statements[0][0]!r} from "
                "index-enabled schema; no declared primary or secondary indexes "
                "were present."
            )

    return {
        "declared_primary_key": primary_key,
        "declared_unique_indexes": serialized_unique,
        "declared_nonunique_indexes": serialized_nonunique,
        "schema_key_parse_status": status,
        "schema_key_parse_reason": reason,
        "source_schema_sha256": source_schema_sha256,
    }


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolve_executable(executable: str | Path) -> Path:
    requested = Path(executable).expanduser()
    if requested.is_absolute():
        resolved = requested.resolve()
        if not resolved.is_file() or not os.access(resolved, os.X_OK):
            raise SchemaEvidenceError(
                "schema_probe_unavailable",
                f"mdb-schema executable is unavailable at {resolved}.",
            )
        return resolved

    discovered = shutil.which(str(executable))
    if discovered is None:
        raise SchemaEvidenceError(
            "schema_probe_unavailable",
            f"mdb-schema executable {str(executable)!r} was not found on PATH.",
        )
    return Path(discovered).resolve()


def _decode_process_message(payload: bytes) -> str:
    return payload.decode("utf-8", errors="replace").strip()


def probe_annual_schema(
    database_path: str | Path,
    *,
    mdb_schema_path: str | Path = "mdb-schema",
) -> AnnualSchemaProbe:
    """Run one read-only, index-enabled annual ``mdb-schema`` probe."""

    database = Path(database_path).expanduser().resolve()
    if not database.is_file():
        raise SchemaEvidenceError(
            "schema_probe_input_missing",
            f"Access database is unavailable at {database}.",
        )
    tool = _resolve_executable(mdb_schema_path)
    environment = os.environ.copy()
    environment.update({"LC_ALL": "C", "LANG": "C"})

    version_command = (str(tool), "--version")
    version_result = subprocess.run(
        version_command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        env=environment,
    )
    if version_result.returncode != 0:
        message = _decode_process_message(
            version_result.stderr or version_result.stdout
        )
        raise SchemaEvidenceError(
            "schema_probe_failed",
            f"mdb-schema version probe exited {version_result.returncode}: "
            f"{message or 'no diagnostic output'}.",
        )
    tool_version = _decode_process_message(
        version_result.stdout or version_result.stderr
    )

    command = (
        str(tool),
        "--indexes",
        "--not-null",
        str(database),
        "postgres",
    )
    result = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        env=environment,
    )
    if result.returncode != 0:
        message = _decode_process_message(result.stderr or result.stdout)
        raise SchemaEvidenceError(
            "schema_probe_failed",
            f"mdb-schema annual probe exited {result.returncode}: "
            f"{message or 'no diagnostic output'}.",
        )

    return AnnualSchemaProbe(
        schema_bytes=result.stdout,
        source_schema_sha256=hashlib.sha256(result.stdout).hexdigest(),
        command=command,
        tool_path=str(tool),
        tool_version=tool_version,
        database_path=str(database),
        database_sha256=_sha256_file(database),
    )
