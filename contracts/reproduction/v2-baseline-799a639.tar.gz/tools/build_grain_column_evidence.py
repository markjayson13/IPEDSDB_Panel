#!/usr/bin/env python3
"""Profile legacy exports for review; never writes canonical contracts."""
from __future__ import annotations

import argparse
import csv
import hashlib
import math
import re
from collections import Counter, defaultdict
from pathlib import Path


SHA256_PATTERN = re.compile(r"[0-9a-fA-F]{64}")


def is_control_table(record: dict[str, str], headers: list[str]) -> bool:
    """Identify archived metadata/control tables from inventory and schema evidence."""
    if record.get("table_role", "").casefold().startswith("metadata"):
        return True
    normalized_headers = {name.strip().casefold() for name in headers}
    filenames_signature = {
        "filename",
        "filenumber",
        "multirecord",
        "qualifyingfield1",
    }
    section_signature = {
        "filename",
        "filenumber",
        "tablename",
        "sectionnumber",
    }
    return (
        filenames_signature.issubset(normalized_headers)
        or section_signature.issubset(normalized_headers)
    )


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        return list(reader.fieldnames or []), [{str(k): str(v or "") for k, v in row.items()} for row in reader]


def write_csv(path: Path, fields: list[str], rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows({field: row.get(field, "") for field in fields} for row in rows)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_inventory_csv_sha256(
    record: dict[str, str],
    csv_path: Path,
) -> str:
    identity = f"{record.get('year', '')}:{record.get('table_name', '')}"
    expected = record.get("csv_sha256", "").strip()
    if not expected:
        raise ValueError(f"{identity}: missing csv_sha256 in table inventory")
    if SHA256_PATTERN.fullmatch(expected) is None:
        raise ValueError(f"{identity}: invalid csv_sha256 in table inventory")
    actual = sha256_file(csv_path)
    if expected.casefold() != actual:
        raise ValueError(
            f"{identity}: csv_sha256 mismatch: inventory={expected.casefold()} "
            f"actual={actual}"
        )
    return actual


def vartable_paths(year_dir: Path) -> list[Path]:
    candidates = (
        list((year_dir / "tables_csv").glob("vartable*.csv"))
        + list((year_dir / "tables_csv").glob("varTable*.csv"))
    )
    unique = {path.resolve() for path in candidates}
    return sorted(
        unique,
        key=lambda path: (path.name.casefold(), path.name, path.as_posix()),
    )


def percentile(values: list[int], p: float) -> int:
    if not values:
        return 0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, math.ceil(p * len(ordered)) - 1))
    return ordered[index]


def metadata_index(root: Path) -> dict[tuple[int, str, str], list[dict[str, str]]]:
    index: dict[tuple[int, str, str], list[dict[str, str]]] = defaultdict(list)
    for year_dir in sorted((root / "Raw_Access_Databases").glob("20*")):
        year = int(year_dir.name)
        for path in vartable_paths(year_dir):
            fields, rows = read_csv(path)
            lower = {field.casefold(): field for field in fields}
            required = {"tablename", "varname"}
            if not required.issubset(lower):
                continue
            for row in rows:
                key = (year, row[lower["tablename"]].casefold(), row[lower["varname"]].casefold())
                index[key].append(row | {"_fields": lower})
    return index


def profile_table(path: Path, headers: list[str]) -> tuple[dict[str, object], dict[str, dict[str, object]]]:
    unitid = next((i for i, name in enumerate(headers) if name.casefold() == "unitid"), None)
    counts: Counter[str] = Counter()
    column_stats: dict[str, dict[str, object]] = {
        name: {"nonempty": 0, "blank": 0, "distinct": set(), "distinct_capped": False, "examples": []}
        for name in headers
    }
    row_count = 0
    with path.open(newline="", encoding="utf-8-sig", errors="replace") as fh:
        reader = csv.reader(fh)
        next(reader, None)
        for values in reader:
            row_count += 1
            for index, name in enumerate(headers):
                value = values[index] if index < len(values) else ""
                stat = column_stats[name]
                if value.strip() == "":
                    stat["blank"] += 1
                else:
                    stat["nonempty"] += 1
                    if len(stat["examples"]) < 5 and value not in stat["examples"]:
                        stat["examples"].append(value)
                    if not stat["distinct_capped"]:
                        stat["distinct"].add(value)
                        if len(stat["distinct"]) >= 10000:
                            stat["distinct_capped"] = True
                            stat["distinct"].clear()
            if unitid is not None:
                value = values[unitid].strip() if unitid < len(values) else ""
                if value:
                    counts[value] += 1
    per_unit = list(counts.values())
    duplicate_rows = sum(max(0, count - 1) for count in per_unit)
    profile = {
        "row_count": row_count,
        "distinct_unitid": len(counts),
        "duplicate_unitid_rows": duplicate_rows,
        "unitids_with_multiple_rows": sum(count > 1 for count in per_unit),
        "min_rows_per_unitid": min(per_unit) if per_unit else 0,
        "median_rows_per_unitid": percentile(per_unit, 0.5),
        "max_rows_per_unitid": max(per_unit) if per_unit else 0,
        "p95_rows_per_unitid": percentile(per_unit, 0.95),
        "null_unitid_rows": row_count - sum(per_unit),
    }
    return profile, column_stats


def run(root: Path, out: Path, contract_id: str) -> None:
    metadata = metadata_index(root)
    inventory_rows: list[dict[str, str]] = []
    for year_dir in sorted((root / "Raw_Access_Databases").glob("20*")):
        _, rows = read_csv(year_dir / "metadata" / "table_inventory.csv")
        inventory_rows.extend(rows)
    grain_fields = [
        "contract_id", "year", "access_table_name", "normalized_table_name", "legacy_table_role",
        "row_count", "distinct_unitid", "duplicate_unitid_rows", "unitids_with_multiple_rows",
        "null_unitid_rows",
        "min_rows_per_unitid", "median_rows_per_unitid", "max_rows_per_unitid", "p95_rows_per_unitid",
        "legacy_multi_record", "file_number", "table_title", "table_description",
        "candidate_dimension_columns", "candidate_minimal_key", "duplicate_rows_on_candidate_key",
        "null_rows_on_candidate_key", "zero_row_table", "source_csv_sha256", "candidate_grain",
        "proposal_confidence", "review_status", "review_note",
    ]
    column_fields = [
        "contract_id", "year", "access_table_name", "normalized_table_name", "file_number",
        "table_grain", "ordinal_position", "column_name", "source_varnumber", "var_title",
        "long_description", "data_type", "format", "field_width", "imputation_var", "code_label_count",
        "nonempty_count", "null_or_blank_count", "distinct_nonempty_count", "example_tokens",
        "candidate_role", "role_evidence", "proposal_confidence", "output_name_collision_count",
        "active_years", "review_status",
    ]
    grain_rows: list[dict[str, object]] = []
    column_rows: list[dict[str, object]] = []
    grain_exceptions: list[dict[str, object]] = []
    column_exceptions: list[dict[str, object]] = []
    grain_counts = Counter()
    role_counts = Counter()
    for record in sorted(inventory_rows, key=lambda row: (int(row["year"]), row["table_name"].casefold())):
        year = int(record["year"])
        year_dir = root / "Raw_Access_Databases" / str(year)
        csv_path = year_dir / record["csv_path"]
        source_csv_sha256 = validate_inventory_csv_sha256(record, csv_path)
        with csv_path.open(newline="", encoding="utf-8-sig", errors="replace") as fh:
            headers = next(csv.reader(fh), [])
        profile, stats = profile_table(csv_path, headers)
        table_meta = metadata.get((year, record["table_name"].casefold(), ""), [])
        table_role = record["table_role"]
        is_control = is_control_table(record, headers)
        if is_control:
            grain = "metadata"
        elif record["has_unitid"].casefold() != "true":
            grain = "unknown"
        elif profile["max_rows_per_unitid"] <= 1 and profile["null_unitid_rows"] == 0:
            grain = "scalar"
        else:
            grain = "unknown"
        grain_counts[grain] += 1
        title = ""
        description = ""
        file_number = ""
        candidates = [row for (y, table, _), rows in metadata.items() if y == year and table == record["table_name"].casefold() for row in rows]
        if len(candidates) == 1:
            fields = candidates[0]["_fields"]
            title = candidates[0].get(fields.get("tabletitle", ""), "")
            description = candidates[0].get(fields.get("longdescription", ""), "")
            file_number = candidates[0].get(fields.get("filenumber", ""), "")
        grain_row = {
            "contract_id": contract_id, "year": year, "access_table_name": record["table_name"],
            "normalized_table_name": record["normalized_table_name"], "legacy_table_role": table_role,
            **profile, "legacy_multi_record": "", "file_number": file_number,
            "table_title": title, "table_description": description, "candidate_dimension_columns": "",
            "candidate_minimal_key": "UNITID" if grain == "scalar" else "",
            "duplicate_rows_on_candidate_key": profile["duplicate_unitid_rows"],
            "null_rows_on_candidate_key": profile["null_unitid_rows"], "zero_row_table": str(profile["row_count"] == 0).lower(),
            "source_csv_sha256": source_csv_sha256, "candidate_grain": grain,
            "proposal_confidence": "mechanical_profile_only", "review_status": "unreviewed",
            "review_note": "Candidate only; complete source grain and key review is required; legacy multi-record flag not inferred.",
        }
        grain_rows.append(grain_row)
        if grain == "unknown" or (grain == "dimensioned" and not grain_row["candidate_dimension_columns"]):
            grain_exceptions.append({**grain_row, "exception": "repeated UNITID without proven complete dimension key"})
        for ordinal, name in enumerate(headers, 1):
            matches = metadata.get((year, record["table_name"].casefold(), name.casefold()), [])
            match = matches[0] if len(matches) == 1 else {}
            fields = match.get("_fields", {})
            stat = stats[name]
            if name.casefold() == "unitid":
                role, evidence = "identifier", "exact UNITID name"
            elif is_control:
                role, evidence = "administrative_field", "metadata table role"
            elif len(matches) == 1 and match.get(fields.get("imputationvar", ""), "").strip():
                role, evidence = "imputation_field", "VARTABLE ImputationVar"
            else:
                role, evidence = "unresolved", "no role inferred from names alone"
            role_counts[role] += 1
            distinct = ">=10000" if stat["distinct_capped"] else len(stat["distinct"])
            row = {
                "contract_id": contract_id, "year": year, "access_table_name": record["table_name"],
                "normalized_table_name": record["normalized_table_name"], "file_number": match.get(fields.get("filenumber", ""), ""),
                "table_grain": grain, "ordinal_position": ordinal, "column_name": name,
                "source_varnumber": match.get(fields.get("varnumber", ""), "") if len(matches) == 1 else "",
                "var_title": match.get(fields.get("vartitle", ""), "") if len(matches) == 1 else "",
                "long_description": match.get(fields.get("longdescription", ""), "") if len(matches) == 1 else "",
                "data_type": match.get(fields.get("datatype", ""), "") if len(matches) == 1 else "",
                "format": match.get(fields.get("format", ""), "") if len(matches) == 1 else "",
                "field_width": match.get(fields.get("fieldwidth", ""), "") if len(matches) == 1 else "",
                "imputation_var": match.get(fields.get("imputationvar", ""), "") if len(matches) == 1 else "",
                "code_label_count": "", "nonempty_count": stat["nonempty"], "null_or_blank_count": stat["blank"],
                "distinct_nonempty_count": distinct, "example_tokens": "|".join(stat["examples"]),
                "candidate_role": role, "role_evidence": evidence, "proposal_confidence": "mechanical_only",
                "output_name_collision_count": len(matches), "active_years": str(year), "review_status": "unreviewed",
            }
            column_rows.append(row)
            if role == "unresolved" and stat["nonempty"]:
                column_exceptions.append({**row, "exception": "nonempty unresolved source column"})
    write_csv(out / "table_grain_enriched.csv", grain_fields, grain_rows)
    write_csv(out / "table_grain_exceptions.csv", grain_fields + ["exception"], grain_exceptions)
    write_csv(out / "source_column_enriched.csv", column_fields, column_rows)
    write_csv(out / "source_column_exceptions.csv", column_fields + ["exception"], column_exceptions)
    (out / "table_grain_summary.md").write_text(
        "# Table grain evidence\n\n"
        f"Rows profiled: {len(grain_rows)}. Counts: {dict(sorted(grain_counts.items()))}.\n\n"
        f"Exceptions: {len(grain_exceptions)}. Scalar candidates are valid only where max rows per UNITID <= 1; "
        "no dimensioned key was inferred. All rows remain unreviewed.\n", encoding="utf-8"
    )
    (out / "source_column_summary.md").write_text(
        "# Source-column evidence\n\n"
        f"Columns profiled: {len(column_rows)}. Candidate roles: {dict(sorted(role_counts.items()))}.\n\n"
        f"Nonempty unresolved exceptions: {len(column_exceptions)}. All rows remain unreviewed; proposal confidence is not evidence.\n",
        encoding="utf-8"
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--legacy-root", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--contract-id", default="ipedsdb-panel-2004-2023-access-v2")
    args = parser.parse_args()
    run(args.legacy_root.resolve(), args.out_dir.resolve(), args.contract_id)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
