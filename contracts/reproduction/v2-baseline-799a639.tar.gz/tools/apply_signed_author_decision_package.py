#!/usr/bin/env python3
"""Verify or atomically apply the exact signed B03-B09 decision package.

The default mode is a non-mutating dry run.  Production application requires
``--apply`` and an exact external author receipt.  The tool never creates or
infers author authorization.
"""
from __future__ import annotations

import argparse
import csv
import ctypes
from dataclasses import asdict, dataclass
import errno
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import secrets
import shutil
import stat
import subprocess
import sys
import tempfile
from typing import Callable, Iterable, Mapping, Sequence
import zipfile


AUTHOR_RECEIPT_REPO_PATH = (
    "docs/release/B03_B09_AUTHOR_COUNTERSIGN_2026-07-24.csv"
)
AUTHOR_RECEIPT_FIELDS = (
    "authorization_id",
    "contract_id",
    "author_name",
    "author_date",
    "decision",
    "register_sha256",
    "scope_sha256",
    "transitive_target_sha256",
    "canonicalized_statement_sha256",
    "source_channel",
    "receipt_status",
    "verbatim_statement",
)
SCOPE_FIELDS = (
    "scope_id",
    "contract_id",
    "block_id",
    "canonical_path",
    "canonical_pre_sha256",
    "final_candidate_path",
    "final_candidate_sha256",
    "expected_post_sha256",
    "row_count",
    "application_mode",
    "child_decision_scope",
    "child_decision_register_path",
    "child_decision_register_sha256",
    "evidence_manifest_path",
    "evidence_manifest_sha256",
    "input_manifest_path",
    "input_manifest_sha256",
    "readiness_status",
)
AUTHOR_REGISTER_FIELDS = (
    "authorization_id",
    "contract_id",
    "scope_manifest_path",
    "scope_manifest_sha256",
    "scope_row_count",
    "transitive_review_target_digest_path",
    "transitive_review_target_digest_sha256",
    "transitive_review_target_sha256",
    "requested_action",
    "allowed_decisions",
    "decision_status",
    "author_name",
    "author_date",
    "release_boundary",
)
ARTIFACT_MANIFEST_FIELDS = (
    "path",
    "byte_size",
    "sha256",
    "generator_sha256",
    "generator_commit",
    "focused_test_sha256",
    "canonical_scope_sha256",
    "transitive_review_target_sha256",
)
PRE_HASH_FIELDS = ("path", "byte_size", "sha256")
PACKAGE_MANIFEST = "FINAL_AUTHOR_DECISION_ARTIFACT_MANIFEST.csv"
PACKAGE_BUNDLE = "FINAL_AUTHOR_DECISION_BUNDLE.zip"
PACKAGE_BUNDLE_DIGEST = "FINAL_AUTHOR_DECISION_BUNDLE.sha256"
PACKAGE_FIXED_FILES = {
    PACKAGE_MANIFEST,
    PACKAGE_BUNDLE,
    PACKAGE_BUNDLE_DIGEST,
}
SHA256_HEX = frozenset("0123456789abcdef")


class SignedApplicationError(RuntimeError):
    """Raised when signed application cannot be proven safe and exact."""


@dataclass(frozen=True)
class ScopeBinding:
    scope_id: str
    contract_id: str
    block_id: str
    canonical_path: str
    canonical_pre_sha256: str
    final_candidate_path: str
    final_candidate_sha256: str
    expected_post_sha256: str
    row_count: str
    application_mode: str
    child_decision_scope: str
    child_decision_register_path: str
    child_decision_register_sha256: str
    evidence_manifest_path: str
    evidence_manifest_sha256: str
    input_manifest_path: str
    input_manifest_sha256: str
    readiness_status: str


@dataclass(frozen=True)
class TrustPolicy:
    authorization_id: str
    contract_id: str
    author_name: str
    author_date: str
    author_decision_register_sha256: str
    canonical_application_scope_sha256: str
    transitive_review_target_sha256: str
    bundle_sha256: str
    required_statement: str
    scope_bindings: tuple[ScopeBinding, ...]


@dataclass(frozen=True)
class VerifiedPackage:
    package_dir: Path
    scope_rows: tuple[dict[str, str], ...]
    candidate_bytes: Mapping[str, bytes]
    canonical_pre_snapshot: Mapping[str, str]
    author_receipt_bytes: bytes
    author_receipt_sha256: str
    package_snapshot: Mapping[str, str]
    artifact_manifest_sha256: str
    transitive_digest_file_sha256: str
    bundle_sha256: str


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_sha256(value: object) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return sha256_bytes(payload)


def canonicalize_statement(value: str) -> str:
    """Collapse all Unicode whitespace to a single ASCII space."""
    return " ".join(value.split())


def _is_sha256(value: str) -> bool:
    return len(value) == 64 and set(value) <= SHA256_HEX


def _safe_relative(value: str, *, label: str) -> PurePosixPath:
    raw = str(value)
    if raw != raw.strip() or "\\" in raw or "\x00" in raw:
        raise SignedApplicationError(f"{label} is not canonical: {value!r}")
    path = PurePosixPath(raw)
    if (
        not raw
        or path.is_absolute()
        or any(part in {"", ".", ".."} for part in path.parts)
        or path.as_posix() != raw
    ):
        raise SignedApplicationError(
            f"{label} is not a safe relative path: {value!r}"
        )
    return path


def _assert_no_symlink_components(
    base: Path,
    relative: PurePosixPath,
    *,
    label: str,
) -> Path:
    current = base
    try:
        if stat.S_ISLNK(current.lstat().st_mode):
            raise SignedApplicationError(f"{label} root is a symlink: {base}")
    except FileNotFoundError as exc:
        raise SignedApplicationError(f"{label} root is missing: {base}") from exc
    for part in relative.parts:
        current = current / part
        try:
            mode = current.lstat().st_mode
        except FileNotFoundError as exc:
            raise SignedApplicationError(
                f"{label} path is missing: {relative.as_posix()}"
            ) from exc
        if stat.S_ISLNK(mode):
            raise SignedApplicationError(
                f"{label} contains a symlink: {relative.as_posix()}"
            )
    return current


def _safe_existing_file(base: Path, value: str, *, label: str) -> Path:
    relative = _safe_relative(value, label=label)
    path = _assert_no_symlink_components(base, relative, label=label)
    if not path.is_file():
        raise SignedApplicationError(f"{label} is not a regular file: {value}")
    return path


def _assert_regular_file(path: Path, *, label: str) -> None:
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError as exc:
        raise SignedApplicationError(f"{label} is missing: {path}") from exc
    if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
        raise SignedApplicationError(
            f"{label} must be a regular non-symlink file: {path}"
        )


def _assert_safe_author_receipt_parents(
    repo: Path,
    *,
    create: bool,
) -> None:
    relative = _safe_relative(
        AUTHOR_RECEIPT_REPO_PATH,
        label="author receipt repository path",
    )
    current = repo
    for part in relative.parts[:-1]:
        current = current / part
        try:
            mode = current.lstat().st_mode
        except FileNotFoundError:
            if not create:
                return
            try:
                current.mkdir(mode=0o755)
            except FileExistsError:
                pass
            mode = current.lstat().st_mode
        if stat.S_ISLNK(mode) or not stat.S_ISDIR(mode):
            raise SignedApplicationError(
                "author receipt parent path contains a symlink or "
                f"non-directory: {current}"
            )


def _assert_author_receipt_target_absent(repo: Path) -> None:
    _assert_safe_author_receipt_parents(repo, create=False)
    target = repo / AUTHOR_RECEIPT_REPO_PATH
    try:
        target.lstat()
    except FileNotFoundError:
        return
    raise SignedApplicationError(
        "target author receipt already exists; refusing ambiguous re-application"
    )


def _open_safe_repository_lock(
    path: Path,
) -> tuple[object, tuple[int, int]]:
    flags = os.O_RDWR | os.O_CREAT
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags, 0o600)
    except OSError as exc:
        if exc.errno in {errno.ELOOP, errno.EMLINK}:
            raise SignedApplicationError(
                "repository lock is a symlink; refusing unsafe repository lock"
            ) from exc
        raise
    try:
        opened = os.fstat(descriptor)
        listed = path.lstat()
        if (
            not stat.S_ISREG(opened.st_mode)
            or stat.S_ISLNK(listed.st_mode)
            or opened.st_dev != listed.st_dev
            or opened.st_ino != listed.st_ino
        ):
            raise SignedApplicationError(
                "repository lock is not a safe regular file"
            )
        return os.fdopen(descriptor, "a+b"), (opened.st_dev, opened.st_ino)
    except BaseException:
        os.close(descriptor)
        raise


def _unlink_owned_lock(path: Path, identity: tuple[int, int]) -> None:
    try:
        listed = path.lstat()
    except FileNotFoundError:
        return
    if (
        stat.S_ISREG(listed.st_mode)
        and (listed.st_dev, listed.st_ino) == identity
    ):
        path.unlink()
        _fsync_directory(path.parent)


def _read_csv(
    path: Path,
    *,
    exact_fields: Sequence[str],
    label: str,
    allow_surrounding_whitespace_fields: Sequence[str] = (),
) -> list[dict[str, str]]:
    _assert_regular_file(path, label=label)
    try:
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            fields = list(reader.fieldnames or [])
            if fields != list(exact_fields) or len(fields) != len(set(fields)):
                raise SignedApplicationError(
                    f"{label} has an unexpected CSV schema: {fields}"
                )
            rows: list[dict[str, str]] = []
            for raw in reader:
                if None in raw:
                    raise SignedApplicationError(
                        f"{label} contains an over-wide CSV row"
                    )
                row = {field: str(raw.get(field) or "") for field in fields}
                allowed_whitespace = set(allow_surrounding_whitespace_fields)
                if any(
                    value != value.strip() and field not in allowed_whitespace
                    for field, value in row.items()
                ):
                    raise SignedApplicationError(
                        f"{label} contains non-canonical surrounding whitespace"
                    )
                if any(row.values()):
                    rows.append(row)
            return rows
    except UnicodeError as exc:
        raise SignedApplicationError(f"{label} is not valid UTF-8") from exc


def _csv_data_row_count(payload: bytes, *, label: str) -> int:
    try:
        text = payload.decode("utf-8-sig")
    except UnicodeError as exc:
        raise SignedApplicationError(f"{label} is not valid UTF-8") from exc
    reader = csv.reader(text.splitlines())
    try:
        header = next(reader)
    except StopIteration as exc:
        raise SignedApplicationError(f"{label} is empty") from exc
    if not header or len(header) != len(set(header)):
        raise SignedApplicationError(f"{label} has a defective header")
    count = 0
    for row in reader:
        if len(row) != len(header):
            raise SignedApplicationError(f"{label} contains a malformed row")
        if any(cell.strip() for cell in row):
            count += 1
    return count


def _tree_snapshot(
    root: Path,
    *,
    label: str,
) -> dict[str, str]:
    if not root.is_dir() or root.is_symlink():
        raise SignedApplicationError(
            f"{label} must be a non-symlink directory: {root}"
        )
    snapshot: dict[str, str] = {}
    for path in sorted(root.rglob("*"), key=lambda item: item.relative_to(root).as_posix()):
        relative = path.relative_to(root).as_posix()
        mode = path.lstat().st_mode
        if stat.S_ISLNK(mode):
            raise SignedApplicationError(f"{label} contains symlink: {relative}")
        if stat.S_ISDIR(mode):
            continue
        if not stat.S_ISREG(mode):
            raise SignedApplicationError(
                f"{label} contains non-regular entry: {relative}"
            )
        snapshot[relative] = sha256_file(path)
    return snapshot


def _validate_provenance(
    repo: Path,
    paths: Sequence[Path],
) -> dict[str, object]:
    if len(paths) < 3:
        raise SignedApplicationError(
            "production provenance must bind applicator, test, and validator"
        )
    head = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        check=False,
        capture_output=True,
        text=True,
    )
    if head.returncode != 0:
        raise SignedApplicationError("repository has no verifiable Git HEAD")
    commit = head.stdout.strip()
    members: dict[str, str] = {}
    for raw_path in paths:
        path = raw_path.absolute()
        _assert_regular_file(path, label="production provenance member")
        try:
            relative = path.relative_to(repo.absolute()).as_posix()
        except ValueError as exc:
            raise SignedApplicationError(
                f"production provenance member is outside repository: {path}"
            ) from exc
        tracked = subprocess.run(
            ["git", "ls-files", "--error-unmatch", "--", relative],
            cwd=repo,
            check=False,
            capture_output=True,
            text=True,
        )
        if tracked.returncode != 0:
            raise SignedApplicationError(
                f"production provenance member is untracked: {relative}"
            )
        dirty = subprocess.run(
            [
                "git",
                "status",
                "--porcelain",
                "--untracked-files=all",
                "--",
                relative,
            ],
            cwd=repo,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
        if dirty:
            raise SignedApplicationError(
                f"production provenance member has dirty or uncommitted bytes: "
                f"{relative}"
            )
        committed = subprocess.run(
            ["git", "show", f"{commit}:{relative}"],
            cwd=repo,
            check=True,
            capture_output=True,
        ).stdout
        observed = sha256_file(path)
        if sha256_bytes(committed) != observed:
            raise SignedApplicationError(
                f"HEAD does not bind production provenance member: {relative}"
            )
        members[relative] = observed
    return {"git_commit": commit, "members": dict(sorted(members.items()))}


def _validate_author_receipt(
    path: Path,
    *,
    trust_policy: TrustPolicy,
) -> tuple[bytes, str]:
    _assert_regular_file(path, label="external author receipt")
    rows = _read_csv(
        path,
        exact_fields=AUTHOR_RECEIPT_FIELDS,
        label="external author receipt",
        allow_surrounding_whitespace_fields=("verbatim_statement",),
    )
    if len(rows) != 1:
        raise SignedApplicationError(
            "external author receipt must contain exactly one decision row"
        )
    row = rows[0]
    canonical_statement = canonicalize_statement(row["verbatim_statement"])
    required_canonical_statement = canonicalize_statement(
        trust_policy.required_statement
    )
    required_statement_hash = sha256_bytes(
        required_canonical_statement.encode("utf-8")
    )
    expected = {
        "authorization_id": trust_policy.authorization_id,
        "contract_id": trust_policy.contract_id,
        "author_name": trust_policy.author_name,
        "author_date": trust_policy.author_date,
        "decision": "authorize_exact_canonical_application_only",
        "register_sha256": trust_policy.author_decision_register_sha256,
        "scope_sha256": trust_policy.canonical_application_scope_sha256,
        "transitive_target_sha256": (
            trust_policy.transitive_review_target_sha256
        ),
        "canonicalized_statement_sha256": required_statement_hash,
        "source_channel": "codex_user_message",
        "receipt_status": "verified_exact_author_countersign",
        "verbatim_statement": row["verbatim_statement"],
    }
    if row != expected or canonical_statement != required_canonical_statement:
        differing = sorted(
            field for field in AUTHOR_RECEIPT_FIELDS if row.get(field) != expected[field]
        )
        raise SignedApplicationError(
            f"external author receipt is missing or altered: fields={differing}"
        )
    payload = path.read_bytes()
    return payload, sha256_bytes(payload)


def _validate_scope(
    package: Path,
    repo: Path,
    *,
    trust_policy: TrustPolicy,
) -> tuple[tuple[dict[str, str], ...], dict[str, bytes]]:
    scope_path = _safe_existing_file(
        package,
        "CANONICAL_APPLICATION_SCOPE.csv",
        label="canonical application scope",
    )
    if sha256_file(scope_path) != trust_policy.canonical_application_scope_sha256:
        raise SignedApplicationError("canonical application scope hash mismatch")
    rows = _read_csv(
        scope_path,
        exact_fields=SCOPE_FIELDS,
        label="canonical application scope",
    )
    expected = [asdict(binding) for binding in trust_policy.scope_bindings]
    if rows != expected or len(rows) != 7:
        raise SignedApplicationError(
            "canonical application scope is not the exact authorized seven rows"
        )
    if len({row["canonical_path"] for row in rows}) != 7:
        raise SignedApplicationError(
            "canonical application scope repeats a canonical path"
        )
    if len({row["block_id"] for row in rows}) != 7:
        raise SignedApplicationError(
            "canonical application scope repeats a scientific block"
        )
    candidates: dict[str, bytes] = {}
    for row in rows:
        if (
            row["contract_id"] != trust_policy.contract_id
            or row["application_mode"] != "replace_exact_bytes"
            or row["readiness_status"] != "author_ready"
            or row["final_candidate_sha256"] != row["expected_post_sha256"]
            or not row["child_decision_scope"]
        ):
            raise SignedApplicationError(
                f"{row['block_id']} is not author-ready for exact replacement"
            )
        canonical_rel = _safe_relative(
            row["canonical_path"],
            label=f"{row['block_id']} canonical path",
        )
        if canonical_rel.parts[0] != "contracts" or len(canonical_rel.parts) != 2:
            raise SignedApplicationError(
                f"{row['block_id']} targets a non-canonical or nested path"
            )
        candidate = _safe_existing_file(
            package,
            row["final_candidate_path"],
            label=f"{row['block_id']} candidate",
        )
        payload = candidate.read_bytes()
        if sha256_bytes(payload) != row["final_candidate_sha256"]:
            raise SignedApplicationError(
                f"{row['block_id']} candidate hash mismatch"
            )
        if _csv_data_row_count(payload, label=f"{row['block_id']} candidate") != int(
            row["row_count"]
        ):
            raise SignedApplicationError(
                f"{row['block_id']} candidate row count mismatch"
            )
        for path_field, hash_field in (
            ("child_decision_register_path", "child_decision_register_sha256"),
            ("evidence_manifest_path", "evidence_manifest_sha256"),
            ("input_manifest_path", "input_manifest_sha256"),
        ):
            evidence_path = _safe_existing_file(
                repo,
                row[path_field],
                label=f"{row['block_id']} {path_field}",
            )
            if sha256_file(evidence_path) != row[hash_field]:
                raise SignedApplicationError(
                    f"{row['block_id']} {path_field} hash mismatch"
                )
        candidates[row["canonical_path"]] = payload
    return tuple(rows), candidates


def _validate_canonical_pre_snapshot(
    package: Path,
    repo: Path,
    scope_rows: Sequence[Mapping[str, str]],
) -> dict[str, str]:
    rows = _read_csv(
        _safe_existing_file(
            package,
            "CANONICAL_PRE_HASH_PROOF.csv",
            label="canonical pre-hash proof",
        ),
        exact_fields=PRE_HASH_FIELDS,
        label="canonical pre-hash proof",
    )
    expected: dict[str, str] = {}
    for row in rows:
        path = _safe_existing_file(repo, row["path"], label="canonical pre-hash member")
        if str(path.stat().st_size) != row["byte_size"]:
            raise SignedApplicationError(
                f"canonical pre-hash size mismatch: {row['path']}"
            )
        if row["path"] in expected:
            raise SignedApplicationError(
                f"canonical pre-hash proof repeats {row['path']}"
            )
        expected[row["path"]] = row["sha256"]
    actual_contracts = {
        f"contracts/{relative}": digest
        for relative, digest in _tree_snapshot(
            repo / "contracts",
            label="canonical contracts",
        ).items()
    }
    if expected != actual_contracts:
        raise SignedApplicationError(
            "canonical contract set or hashes differ from the signed pre-snapshot"
        )
    for row in scope_rows:
        if expected.get(row["canonical_path"]) != row["canonical_pre_sha256"]:
            raise SignedApplicationError(
                f"{row['block_id']} canonical pre-hash is stale"
            )
    return expected


def _validate_transitive_digest(
    package: Path,
    repo: Path,
    scope_rows: Sequence[Mapping[str, str]],
    *,
    trust_policy: TrustPolicy,
) -> str:
    path = _safe_existing_file(
        package,
        "TRANSITIVE_REVIEW_TARGET_DIGEST.json",
        label="transitive review-target digest",
    )
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise SignedApplicationError(
            "transitive review-target digest is invalid JSON"
        ) from exc
    members = payload.get("members")
    if not isinstance(members, dict) or not members:
        raise SignedApplicationError(
            "transitive review-target digest has no complete member map"
        )
    if (
        payload.get("authorization_id") != trust_policy.authorization_id
        or payload.get("contract_id") != trust_policy.contract_id
        or payload.get("author_name") != trust_policy.author_name
        or payload.get("author_date") != trust_policy.author_date
        or payload.get("status") != "author_ready_pending_countersign"
        or payload.get("member_count") != len(members)
    ):
        raise SignedApplicationError(
            "transitive review-target digest metadata is inconsistent"
        )
    normalized = {str(key): str(value) for key, value in members.items()}
    if (
        canonical_json_sha256(normalized)
        != trust_policy.transitive_review_target_sha256
        or payload.get("transitive_review_target_sha256")
        != trust_policy.transitive_review_target_sha256
    ):
        raise SignedApplicationError(
            "transitive review-target digest does not match authorization"
        )
    source_bases = {
        "stage04": Path(scope_rows[0]["evidence_manifest_path"]).parent,
        "b05_b06": Path(scope_rows[2]["evidence_manifest_path"]).parent,
        "b07": Path(scope_rows[4]["evidence_manifest_path"]).parent,
        "b08_b09": Path(scope_rows[5]["evidence_manifest_path"]).parent,
    }
    for member, expected_hash in sorted(normalized.items()):
        if not _is_sha256(expected_hash):
            raise SignedApplicationError(
                f"transitive member has invalid hash: {member}"
            )
        relative = _safe_relative(member, label="transitive member")
        prefix = relative.parts[0]
        remainder = PurePosixPath(*relative.parts[1:])
        if prefix == "output":
            base = package
        elif prefix == "repository":
            base = repo
        elif prefix in source_bases:
            if remainder.parts and remainder.parts[0] in {
                "Artifacts",
                "contracts",
            }:
                base = repo
            else:
                base = repo / source_bases[prefix]
        else:
            raise SignedApplicationError(
                f"transitive member has unknown source prefix: {member}"
            )
        target = _safe_existing_file(
            base,
            remainder.as_posix(),
            label=f"transitive member {member}",
        )
        if sha256_file(target) != expected_hash:
            raise SignedApplicationError(
                f"transitive review-target member hash mismatch: {member}"
            )
    return sha256_file(path)


def _validate_author_register(
    package: Path,
    *,
    trust_policy: TrustPolicy,
    transitive_digest_file_sha256: str,
) -> None:
    path = _safe_existing_file(
        package,
        "AUTHOR_DECISION_REGISTER.csv",
        label="author decision register",
    )
    if sha256_file(path) != trust_policy.author_decision_register_sha256:
        raise SignedApplicationError("author decision register hash mismatch")
    rows = _read_csv(
        path,
        exact_fields=AUTHOR_REGISTER_FIELDS,
        label="author decision register",
    )
    if len(rows) != 1:
        raise SignedApplicationError(
            "author decision register must contain exactly one row"
        )
    row = rows[0]
    expected = {
        "authorization_id": trust_policy.authorization_id,
        "contract_id": trust_policy.contract_id,
        "scope_manifest_path": "CANONICAL_APPLICATION_SCOPE.csv",
        "scope_manifest_sha256": (
            trust_policy.canonical_application_scope_sha256
        ),
        "scope_row_count": "7",
        "transitive_review_target_digest_path": (
            "TRANSITIVE_REVIEW_TARGET_DIGEST.json"
        ),
        "transitive_review_target_digest_sha256": (
            transitive_digest_file_sha256
        ),
        "transitive_review_target_sha256": (
            trust_policy.transitive_review_target_sha256
        ),
        "requested_action": "authorize_exact_canonical_application_only",
        "allowed_decisions": (
            "authorize_exact_canonical_application_only|reject|"
            "request_more_evidence"
        ),
        "decision_status": "pending_author_countersign",
        "author_name": trust_policy.author_name,
        "author_date": trust_policy.author_date,
        "release_boundary": "FULL_BUILD_NOT_RUN|RELEASE_STILL_BLOCKED",
    }
    if row != expected:
        raise SignedApplicationError(
            "author decision register fields differ from the signed authorization"
        )


def _validate_artifact_manifest_and_bundle(
    package: Path,
    *,
    trust_policy: TrustPolicy,
) -> tuple[dict[str, str], str]:
    manifest_path = _safe_existing_file(
        package,
        PACKAGE_MANIFEST,
        label="final package artifact manifest",
    )
    rows = _read_csv(
        manifest_path,
        exact_fields=ARTIFACT_MANIFEST_FIELDS,
        label="final package artifact manifest",
    )
    members: dict[str, str] = {}
    provenance_values: set[tuple[str, str, str, str, str]] = set()
    for row in rows:
        relative = row["path"]
        if relative in members:
            raise SignedApplicationError(
                f"final package artifact manifest repeats {relative}"
            )
        path = _safe_existing_file(
            package,
            relative,
            label="final package artifact member",
        )
        if (
            str(path.stat().st_size) != row["byte_size"]
            or sha256_file(path) != row["sha256"]
        ):
            raise SignedApplicationError(
                f"final package artifact member mismatch: {relative}"
            )
        provenance_values.add(
            (
                row["generator_sha256"],
                row["generator_commit"],
                row["focused_test_sha256"],
                row["canonical_scope_sha256"],
                row["transitive_review_target_sha256"],
            )
        )
        members[relative] = row["sha256"]
    if len(provenance_values) != 1:
        raise SignedApplicationError(
            "final package artifact manifest has inconsistent provenance"
        )
    provenance = next(iter(provenance_values))
    if (
        provenance[3] != trust_policy.canonical_application_scope_sha256
        or provenance[4] != trust_policy.transitive_review_target_sha256
    ):
        raise SignedApplicationError(
            "final package artifact manifest is bound to another authorization"
        )
    actual = _tree_snapshot(package, label="final package directory")
    if set(actual) != set(members) | PACKAGE_FIXED_FILES:
        raise SignedApplicationError(
            "final package directory has missing or unexpected members"
        )
    bundle_path = package / PACKAGE_BUNDLE
    sidecar = package / PACKAGE_BUNDLE_DIGEST
    bundle_hash = sha256_file(bundle_path)
    if (
        bundle_hash != trust_policy.bundle_sha256
        or sidecar.read_text(encoding="utf-8")
        != f"{bundle_hash}  {PACKAGE_BUNDLE}\n"
    ):
        raise SignedApplicationError(
            "final package bundle or digest sidecar is altered"
        )
    expected_zip = set(members) | {PACKAGE_MANIFEST}
    with zipfile.ZipFile(bundle_path) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)) or set(names) != expected_zip:
            raise SignedApplicationError(
                "final package bundle member set is incomplete or unexpected"
            )
        for info in infos:
            relative = _safe_relative(info.filename, label="bundle member")
            mode = (info.external_attr >> 16) & 0o170000
            if (
                info.is_dir()
                or info.flag_bits & 0x1
                or mode not in {0, stat.S_IFREG}
                or info.date_time != (1980, 1, 1, 0, 0, 0)
            ):
                raise SignedApplicationError(
                    f"bundle member is unsafe or nondeterministic: {info.filename}"
                )
            disk_path = _safe_existing_file(
                package,
                relative.as_posix(),
                label="bundle counterpart",
            )
            if archive.read(info) != disk_path.read_bytes():
                raise SignedApplicationError(
                    f"bundle member differs from package file: {info.filename}"
                )
    return actual, sha256_file(manifest_path)


def verify_package(
    *,
    repo_root: Path,
    package_dir: Path,
    author_receipt: Path,
    trust_policy: TrustPolicy,
) -> VerifiedPackage:
    repo = repo_root.absolute()
    package = package_dir.absolute()
    if repo.is_symlink() or not repo.is_dir():
        raise SignedApplicationError("repository root is missing or a symlink")
    package_snapshot, artifact_manifest_hash = (
        _validate_artifact_manifest_and_bundle(
            package,
            trust_policy=trust_policy,
        )
    )
    scope_rows, candidate_bytes = _validate_scope(
        package,
        repo,
        trust_policy=trust_policy,
    )
    pre_snapshot = _validate_canonical_pre_snapshot(package, repo, scope_rows)
    transitive_file_hash = _validate_transitive_digest(
        package,
        repo,
        scope_rows,
        trust_policy=trust_policy,
    )
    _validate_author_register(
        package,
        trust_policy=trust_policy,
        transitive_digest_file_sha256=transitive_file_hash,
    )
    receipt_bytes, receipt_hash = _validate_author_receipt(
        author_receipt.absolute(),
        trust_policy=trust_policy,
    )
    return VerifiedPackage(
        package_dir=package,
        scope_rows=scope_rows,
        candidate_bytes=candidate_bytes,
        canonical_pre_snapshot=pre_snapshot,
        author_receipt_bytes=receipt_bytes,
        author_receipt_sha256=receipt_hash,
        package_snapshot=package_snapshot,
        artifact_manifest_sha256=artifact_manifest_hash,
        transitive_digest_file_sha256=transitive_file_hash,
        bundle_sha256=trust_policy.bundle_sha256,
    )


def _copy_regular_tree(source: Path, target: Path, *, label: str) -> None:
    snapshot = _tree_snapshot(source, label=label)
    for relative in snapshot:
        source_path = _safe_existing_file(source, relative, label=label)
        target_path = target / relative
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_bytes(source_path.read_bytes())


def _stage_validation_repo(
    repo: Path,
    verified: VerifiedPackage,
    staging_repo: Path,
) -> None:
    _copy_regular_tree(
        repo / "contracts",
        staging_repo / "contracts",
        label="canonical contracts",
    )
    for canonical_path, payload in verified.candidate_bytes.items():
        target = staging_repo / canonical_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payload)
    receipt_target = staging_repo / AUTHOR_RECEIPT_REPO_PATH
    receipt_target.parent.mkdir(parents=True, exist_ok=True)
    receipt_target.write_bytes(verified.author_receipt_bytes)

    # Signed benchmark validation follows stable repo-relative receipt paths.
    benchmark = verified.candidate_bytes.get(
        "contracts/external_benchmarks.csv",
        b"",
    )
    try:
        rows = list(csv.DictReader(benchmark.decode("utf-8-sig").splitlines()))
    except (UnicodeError, csv.Error) as exc:
        raise SignedApplicationError(
            "external benchmark candidate cannot be staged"
        ) from exc
    for row in rows:
        relative = str(row.get("source_evidence_path") or "").strip()
        if not relative:
            continue
        source = _safe_existing_file(
            repo,
            relative,
            label="benchmark source evidence",
        )
        target = staging_repo / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())


def _run_validator(
    *,
    validator_path: Path,
    repo_root: Path,
    phase: str,
    expected_sha256: str,
) -> dict[str, object]:
    _assert_regular_file(validator_path, label="contract validator")
    validator_bytes = validator_path.read_bytes()
    if sha256_bytes(validator_bytes) != expected_sha256:
        raise SignedApplicationError(
            "contract validator bytes differ from committed provenance"
        )
    env = dict(os.environ)
    env["SIGNED_APPLICATION_VALIDATION_PHASE"] = phase
    with tempfile.TemporaryDirectory(
        prefix=".signed-validator.",
        dir=repo_root,
    ) as temporary:
        exact_validator = Path(temporary) / validator_path.name
        exact_validator.write_bytes(validator_bytes)
        completed = subprocess.run(
            [
                sys.executable,
                str(exact_validator),
                "--repo-root",
                str(repo_root),
            ],
            capture_output=True,
            text=True,
            check=False,
            env=env,
        )
    if sha256_file(validator_path) != expected_sha256:
        raise SignedApplicationError(
            "contract validator changed during exact-byte validation"
        )
    result = {
        "phase": phase,
        "exit_code": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "validator_sha256": expected_sha256,
    }
    if completed.returncode != 0:
        raise SignedApplicationError(
            f"{phase} contract validation failed with exit "
            f"{completed.returncode}: {completed.stdout}{completed.stderr}"
        )
    return result


def _validate_output_path(repo: Path, package: Path, output: Path) -> None:
    contracts = (repo / "contracts").absolute()
    candidate = output.absolute()
    if candidate.name in {"", ".", ".."}:
        raise SignedApplicationError(
            f"application output path has no safe final name: {output}"
        )
    if candidate == contracts or contracts in candidate.parents:
        raise SignedApplicationError(
            "application receipt output must remain outside contracts"
        )
    verified_package = package.absolute()
    if candidate == verified_package or verified_package in candidate.parents:
        raise SignedApplicationError(
            "application receipt output must remain outside the verified package"
        )


def _write_result_bundle(
    *,
    output: Path,
    output_parent_fd: int,
    verified: VerifiedPackage,
    trust_policy: TrustPolicy,
    provenance: Mapping[str, object],
    validation: Sequence[Mapping[str, object]],
    status: str,
    applied: bool,
    backup_root: Path | None = None,
    failure_injector: Callable[[str, str, int], None] | None = None,
) -> tuple[int, int]:
    receipt_payload = {
        "schema_version": "1",
        "authorization_id": trust_policy.authorization_id,
        "contract_id": trust_policy.contract_id,
        "status": status,
        "applied": applied,
        "scope_row_count": len(verified.scope_rows),
        "author_receipt_repo_path": AUTHOR_RECEIPT_REPO_PATH,
        "author_receipt_sha256": verified.author_receipt_sha256,
        "author_decision_register_sha256": (
            trust_policy.author_decision_register_sha256
        ),
        "canonical_application_scope_sha256": (
            trust_policy.canonical_application_scope_sha256
        ),
        "transitive_review_target_sha256": (
            trust_policy.transitive_review_target_sha256
        ),
        "transitive_digest_file_sha256": (
            verified.transitive_digest_file_sha256
        ),
        "package_artifact_manifest_sha256": (
            verified.artifact_manifest_sha256
        ),
        "package_bundle_sha256": verified.bundle_sha256,
        "application_provenance": provenance,
        "validator_runs": list(validation),
        "targets": [
            {
                "block_id": row["block_id"],
                "canonical_path": row["canonical_path"],
                "pre_sha256": row["canonical_pre_sha256"],
                "post_sha256": row["expected_post_sha256"],
                "row_count": int(row["row_count"]),
            }
            for row in verified.scope_rows
        ],
        "release_boundary": [
            "FULL_BUILD_NOT_RUN",
            "RELEASE_STILL_BLOCKED",
        ],
    }
    members: dict[str, bytes] = {
        "SIGNED_APPLICATION_RECEIPT.json": (
            json.dumps(receipt_payload, indent=2, sort_keys=True) + "\n"
        ).encode("utf-8")
    }
    if backup_root is not None:
        expected_backups = {
            row["canonical_path"]: row["canonical_pre_sha256"]
            for row in verified.scope_rows
        }
        actual_backups = _tree_snapshot(
            backup_root,
            label="application backups",
        )
        if actual_backups != expected_backups:
            raise SignedApplicationError(
                "application backup tree differs from the signed pre-state"
            )
        for relative in sorted(expected_backups):
            source = _safe_existing_file(
                backup_root,
                relative,
                label="application backups",
            )
            payload = source.read_bytes()
            if hashlib.sha256(payload).hexdigest() != expected_backups[relative]:
                raise SignedApplicationError(
                    f"application backup changed while staging: {relative}"
                )
            members[f"backups/{relative}"] = payload

    manifest_buffer = io.StringIO(newline="")
    manifest_writer = csv.DictWriter(
        manifest_buffer,
        fieldnames=["path", "byte_size", "sha256"],
        lineterminator="\n",
    )
    manifest_writer.writeheader()
    for relative, payload in sorted(members.items()):
        manifest_writer.writerow(
            {
                "path": relative,
                "byte_size": len(payload),
                "sha256": hashlib.sha256(payload).hexdigest(),
            }
        )
    members["SIGNED_APPLICATION_ARTIFACT_MANIFEST.csv"] = (
        manifest_buffer.getvalue().encode("utf-8")
    )
    expected_snapshot: dict[str, tuple[str, int, str]] = {}
    for relative, payload in members.items():
        path = PurePosixPath(relative)
        for index in range(1, len(path.parts)):
            expected_snapshot["/".join(path.parts[:index])] = (
                "directory",
                0,
                "",
            )
        expected_snapshot[relative] = (
            "file",
            len(payload),
            hashlib.sha256(payload).hexdigest(),
        )

    staging_parent_name, staging_parent_fd, staging_parent_identity = (
        _create_private_directory_at(
            output_parent_fd,
            prefix=".signed-output-staging",
            label="application output staging parent",
        )
    )
    result_fd: int | None = None
    result_identity: tuple[int, int] | None = None
    published = False
    completed = False
    try:
        os.mkdir("result", mode=0o700, dir_fd=staging_parent_fd)
        os.fsync(staging_parent_fd)
        result_fd = _open_directory_entry(
            staging_parent_fd,
            "result",
            label="application output staging source",
        )
        result_identity = _directory_identity(result_fd)
        for relative, payload in sorted(members.items()):
            parts = PurePosixPath(relative).parts
            target_parent_fd, _ = _open_directory_chain(
                result_fd,
                parts[:-1],
                create=True,
                label="application output staging tree",
            )
            if target_parent_fd is None:  # pragma: no cover - create guarantees fd
                raise SignedApplicationError(
                    "application output staging parent was not created"
                )
            try:
                _write_bytes_at(
                    target_parent_fd,
                    parts[-1],
                    payload,
                    label=f"application output member {relative}",
                )
            finally:
                os.close(target_parent_fd)
        os.fsync(result_fd)

        staging_parent_path = output.parent / staging_parent_name
        _inject(
            failure_injector,
            "before_output_staging_parent_publish",
            str(staging_parent_path),
            9,
        )
        _assert_output_parent_identity(output.parent, output_parent_fd)
        _assert_directory_entry_identity(
            output_parent_fd,
            staging_parent_name,
            staging_parent_identity,
            label="application output staging parent",
        )
        _inject(
            failure_injector,
            "before_output_source_snapshot",
            str(staging_parent_path / "result"),
            9,
        )
        if _snapshot_tree_at(result_fd) != expected_snapshot:
            raise SignedApplicationError(
                "application output staging contents changed or became unsafe"
            )
        _inject(
            failure_injector,
            "after_output_source_snapshot",
            str(staging_parent_path / "result"),
            9,
        )
        _inject(
            failure_injector,
            "before_output_source_publish",
            str(staging_parent_path / "result"),
            9,
        )
        _assert_directory_entry_identity(
            staging_parent_fd,
            "result",
            result_identity,
            label="application output staging source",
        )
        _inject(
            failure_injector,
            "after_output_source_identity",
            str(staging_parent_path / "result"),
            9,
        )
        _assert_directory_entry_identity(
            staging_parent_fd,
            "result",
            result_identity,
            label="application output staging source",
        )
        _directory_entry_absent(
            output_parent_fd,
            output.name,
            label="application output path",
        )
        _inject(
            failure_injector,
            "before_output_atomic_publish",
            str(output),
            9,
        )
        _atomic_rename_noreplace_at(
            staging_parent_fd,
            "result",
            output_parent_fd,
            output.name,
        )
        published = True
        os.fsync(staging_parent_fd)
        os.fsync(output_parent_fd)

        published_fd = _open_directory_entry(
            output_parent_fd,
            output.name,
            label="published application output",
        )
        try:
            if _directory_identity(published_fd) != result_identity:
                raise SignedApplicationError(
                    "published application output is not the verified staging "
                    "directory"
                )
            if _snapshot_tree_at(published_fd) != expected_snapshot:
                raise SignedApplicationError(
                    "published application output contents changed or became "
                    "unsafe"
                )
            os.fsync(published_fd)
        finally:
            os.close(published_fd)
        _assert_output_parent_identity(output.parent, output_parent_fd)
        _assert_directory_entry_identity(
            output_parent_fd,
            output.name,
            result_identity,
            label="published application output",
        )
        completed = True
        return result_identity
    finally:
        try:
            if not completed:
                if published:
                    if result_identity is not None:
                        _remove_owned_directory_by_identity(
                            output_parent_fd,
                            result_identity,
                        )
                else:
                    if result_identity is not None:
                        _remove_owned_directory_by_identity(
                            staging_parent_fd,
                            result_identity,
                        )
            if result_fd is not None:
                os.close(result_fd)
                result_fd = None
            _remove_owned_directory_by_identity(
                output_parent_fd,
                staging_parent_identity,
                recursive=False,
            )
        finally:
            if result_fd is not None:
                os.close(result_fd)
            os.close(staging_parent_fd)


def _assert_current_pre_snapshot(
    repo: Path,
    expected: Mapping[str, str],
) -> None:
    actual = {
        f"contracts/{relative}": digest
        for relative, digest in _tree_snapshot(
            repo / "contracts",
            label="canonical contracts",
        ).items()
    }
    if actual != dict(expected):
        raise SignedApplicationError(
            "canonical contracts changed after package verification"
        )


def _assert_package_unchanged(verified: VerifiedPackage) -> None:
    actual = _tree_snapshot(
        verified.package_dir,
        label="final package directory",
    )
    if actual != dict(verified.package_snapshot):
        raise SignedApplicationError(
            "final package changed after verification"
        )


def _reverify_exact_inputs(
    *,
    repo: Path,
    verified: VerifiedPackage,
    author_receipt: Path,
    trust_policy: TrustPolicy,
) -> None:
    observed = verify_package(
        repo_root=repo,
        package_dir=verified.package_dir,
        author_receipt=author_receipt,
        trust_policy=trust_policy,
    )
    if observed != verified:
        raise SignedApplicationError(
            "signed package, receipt, canonical prestate, or transitive "
            "source evidence changed after initial verification"
        )


def _inject(
    callback: Callable[[str, str, int], None] | None,
    event: str,
    path: str,
    index: int,
) -> None:
    if callback is not None:
        callback(event, path, index)


def _assert_same_provenance(
    repo: Path,
    paths: Sequence[Path],
    expected: Mapping[str, object],
) -> None:
    observed = _validate_provenance(repo, paths)
    if observed != dict(expected):
        raise SignedApplicationError(
            "production provenance changed after the initial verification"
        )


def _provenance_member_hash(
    repo: Path,
    path: Path,
    provenance: Mapping[str, object],
) -> str:
    try:
        relative = path.absolute().relative_to(repo.absolute()).as_posix()
    except ValueError as exc:
        raise SignedApplicationError(
            "validator path is outside the repository"
        ) from exc
    members = provenance.get("members")
    if not isinstance(members, Mapping):
        raise SignedApplicationError("application provenance has no member map")
    value = members.get(relative)
    if not isinstance(value, str) or not _is_sha256(value):
        raise SignedApplicationError(
            "application provenance does not bind the validator"
        )
    return value


def _fsync_file(path: Path) -> None:
    with path.open("rb") as handle:
        os.fsync(handle.fileno())


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _open_safe_directory(path: Path, *, label: str) -> int:
    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise SignedApplicationError(
            f"{label} cannot be opened without following symlinks: {path}"
        ) from exc
    try:
        opened = os.fstat(descriptor)
        listed = path.lstat()
        if (
            not stat.S_ISDIR(opened.st_mode)
            or stat.S_ISLNK(listed.st_mode)
            or opened.st_dev != listed.st_dev
            or opened.st_ino != listed.st_ino
        ):
            raise SignedApplicationError(
                f"{label} changed or is not a safe directory: {path}"
            )
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _assert_directory_path_identity(
    path: Path,
    directory_fd: int,
    *,
    label: str,
) -> None:
    try:
        listed = path.lstat()
    except FileNotFoundError as exc:
        raise SignedApplicationError(f"{label} path disappeared: {path}") from exc
    opened = os.fstat(directory_fd)
    if (
        not stat.S_ISDIR(opened.st_mode)
        or stat.S_ISLNK(listed.st_mode)
        or not stat.S_ISDIR(listed.st_mode)
        or opened.st_dev != listed.st_dev
        or opened.st_ino != listed.st_ino
    ):
        raise SignedApplicationError(
            f"{label} path changed after it was opened"
        )


def _directory_entry_absent(
    directory_fd: int,
    name: str,
    *,
    label: str,
) -> None:
    try:
        os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
    except FileNotFoundError:
        return
    raise SignedApplicationError(f"{label} already exists")


def _open_directory_chain(
    base_directory_fd: int,
    parts: Sequence[str],
    *,
    create: bool,
    label: str,
) -> tuple[int | None, tuple[str, ...]]:
    current = os.dup(base_directory_fd)
    created: list[str] = []
    walked: list[str] = []
    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        for part in parts:
            walked.append(part)
            try:
                following = os.open(part, flags, dir_fd=current)
            except FileNotFoundError:
                if not create:
                    os.close(current)
                    return None, tuple(created)
                try:
                    os.mkdir(part, mode=0o755, dir_fd=current)
                    created.append("/".join(walked))
                    os.fsync(current)
                except FileExistsError:
                    pass
                try:
                    following = os.open(part, flags, dir_fd=current)
                except OSError as exc:
                    raise SignedApplicationError(
                        f"{label} component is unsafe after creation: {part}"
                    ) from exc
            except OSError as exc:
                raise SignedApplicationError(
                    f"{label} component is a symlink or unsafe: {part}"
                ) from exc
            os.close(current)
            current = following
        return current, tuple(created)
    except BaseException:
        try:
            os.close(current)
        except OSError:
            pass
        raise


def _open_output_parent(output: Path) -> int:
    parent = output.parent.absolute()
    root_fd = _open_safe_directory(
        Path(parent.anchor),
        label="application output filesystem root",
    )
    try:
        parent_fd, _ = _open_directory_chain(
            root_fd,
            parent.parts[1:],
            create=True,
            label="application output parent",
        )
    finally:
        os.close(root_fd)
    if parent_fd is None:  # pragma: no cover - create guarantees a descriptor
        raise SignedApplicationError(
            "application output parent could not be created"
        )
    try:
        _directory_entry_absent(
            parent_fd,
            output.name,
            label="application output path",
        )
        _assert_output_parent_identity(parent, parent_fd)
        return parent_fd
    except BaseException:
        os.close(parent_fd)
        raise


def _assert_output_parent_identity(parent: Path, expected_parent_fd: int) -> None:
    root_fd: int | None = None
    observed_fd: int | None = None
    try:
        root_fd = _open_safe_directory(
            Path(parent.anchor),
            label="application output filesystem root",
        )
        observed_fd, _ = _open_directory_chain(
            root_fd,
            parent.parts[1:],
            create=False,
            label="application output parent",
        )
        if observed_fd is None:
            raise SignedApplicationError(
                "application output parent path disappeared"
            )
        expected = os.fstat(expected_parent_fd)
        observed = os.fstat(observed_fd)
        if (
            expected.st_dev != observed.st_dev
            or expected.st_ino != observed.st_ino
        ):
            raise SignedApplicationError(
                "application output parent path changed after it was opened"
            )
    except SignedApplicationError as exc:
        if "application output parent path changed" in str(exc):
            raise
        raise SignedApplicationError(
            "application output parent changed or became unsafe"
        ) from exc
    finally:
        if observed_fd is not None:
            os.close(observed_fd)
        if root_fd is not None:
            os.close(root_fd)


def _directory_identity(directory_fd: int) -> tuple[int, int]:
    opened = os.fstat(directory_fd)
    if not stat.S_ISDIR(opened.st_mode):
        raise SignedApplicationError(
            "application output staging descriptor is not a directory"
        )
    return opened.st_dev, opened.st_ino


def _atomic_rename_noreplace_at(
    source_parent_fd: int,
    source_name: str,
    destination_parent_fd: int,
    destination_name: str,
) -> None:
    library = ctypes.CDLL(None, use_errno=True)
    if sys.platform == "darwin":
        try:
            rename = library.renameatx_np
        except AttributeError as exc:  # pragma: no cover - unsupported old macOS
            raise SignedApplicationError(
                "atomic no-replace publication is unavailable"
            ) from exc
        rename.argtypes = (
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_uint,
        )
        rename.restype = ctypes.c_int
        flags = 0x00000004  # RENAME_EXCL
    elif sys.platform.startswith("linux"):
        try:
            rename = library.renameat2
        except AttributeError as exc:  # pragma: no cover - libc dependent
            raise SignedApplicationError(
                "atomic no-replace publication is unavailable"
            ) from exc
        rename.argtypes = (
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_int,
            ctypes.c_char_p,
            ctypes.c_uint,
        )
        rename.restype = ctypes.c_int
        flags = 1  # RENAME_NOREPLACE
    else:  # pragma: no cover - fail closed on unsupported platforms
        raise SignedApplicationError(
            "atomic no-replace publication is unavailable"
        )
    ctypes.set_errno(0)
    result = rename(
        source_parent_fd,
        os.fsencode(source_name),
        destination_parent_fd,
        os.fsencode(destination_name),
        flags,
    )
    if result == 0:
        return
    error = ctypes.get_errno()
    if error in {errno.EEXIST, errno.ENOTEMPTY}:
        raise SignedApplicationError(
            "application output path appeared before atomic publication"
        )
    raise SignedApplicationError(
        "atomic no-replace publication failed: "
        f"{os.strerror(error) if error else 'unknown operating-system error'}"
    )


def _open_directory_entry(
    parent_fd: int,
    name: str,
    *,
    label: str,
) -> int:
    flags = os.O_RDONLY
    if hasattr(os, "O_DIRECTORY"):
        flags |= os.O_DIRECTORY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(name, flags, dir_fd=parent_fd)
    except OSError as exc:
        raise SignedApplicationError(
            f"{label} is missing, changed, or unsafe"
        ) from exc
    try:
        if not stat.S_ISDIR(os.fstat(descriptor).st_mode):
            raise SignedApplicationError(f"{label} is not a directory")
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _assert_directory_entry_identity(
    parent_fd: int,
    name: str,
    expected: tuple[int, int],
    *,
    label: str,
) -> None:
    try:
        observed = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
    except OSError as exc:
        raise SignedApplicationError(
            f"{label} changed or became unsafe"
        ) from exc
    if (
        not stat.S_ISDIR(observed.st_mode)
        or (observed.st_dev, observed.st_ino) != expected
    ):
        raise SignedApplicationError(f"{label} changed or became unsafe")


def _create_private_directory_at(
    parent_fd: int,
    *,
    prefix: str,
    label: str,
) -> tuple[str, int, tuple[int, int]]:
    for _ in range(128):
        name = f"{prefix}.{secrets.token_hex(16)}"
        try:
            os.mkdir(name, mode=0o700, dir_fd=parent_fd)
        except FileExistsError:
            continue
        os.fsync(parent_fd)
        try:
            descriptor = _open_directory_entry(
                parent_fd,
                name,
                label=label,
            )
        except BaseException:
            raise
        return name, descriptor, _directory_identity(descriptor)
    raise SignedApplicationError(
        f"{label} could not reserve a unique directory"
    )


def _write_bytes_at(
    directory_fd: int,
    name: str,
    payload: bytes,
    *,
    label: str,
) -> None:
    if name in {"", ".", ".."} or PurePosixPath(name).name != name:
        raise SignedApplicationError(f"{label} has an unsafe name")
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(
            name,
            flags,
            0o600,
            dir_fd=directory_fd,
        )
    except OSError as exc:
        raise SignedApplicationError(
            f"{label} could not be created safely"
        ) from exc
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise SignedApplicationError(f"{label} is not a regular file")
        view = memoryview(payload)
        while view:
            written = os.write(descriptor, view)
            if written <= 0:  # pragma: no cover - defensive OS invariant
                raise SignedApplicationError(f"{label} write did not progress")
            view = view[written:]
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    os.fsync(directory_fd)


def _snapshot_tree_at(
    directory_fd: int,
    *,
    prefix: tuple[str, ...] = (),
) -> dict[str, tuple[str, int, str]]:
    snapshot: dict[str, tuple[str, int, str]] = {}
    with os.scandir(directory_fd) as entries:
        names = sorted(entry.name for entry in entries)
    for name in names:
        relative_parts = (*prefix, name)
        relative = "/".join(relative_parts)
        try:
            listed = os.stat(
                name,
                dir_fd=directory_fd,
                follow_symlinks=False,
            )
        except OSError as exc:
            raise SignedApplicationError(
                "application output staging contents changed or became unsafe"
            ) from exc
        if stat.S_ISDIR(listed.st_mode):
            child_fd = _open_directory_entry(
                directory_fd,
                name,
                label=f"application output directory {relative}",
            )
            try:
                opened = os.fstat(child_fd)
                if (
                    opened.st_dev != listed.st_dev
                    or opened.st_ino != listed.st_ino
                ):
                    raise SignedApplicationError(
                        "application output staging contents changed or became "
                        "unsafe"
                    )
                snapshot[relative] = ("directory", 0, "")
                snapshot.update(
                    _snapshot_tree_at(
                        child_fd,
                        prefix=relative_parts,
                    )
                )
            finally:
                os.close(child_fd)
            continue
        if not stat.S_ISREG(listed.st_mode):
            raise SignedApplicationError(
                "application output staging contents changed or became unsafe"
            )
        flags = os.O_RDONLY
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        try:
            member_fd = os.open(
                name,
                flags,
                dir_fd=directory_fd,
            )
        except OSError as exc:
            raise SignedApplicationError(
                "application output staging contents changed or became unsafe"
            ) from exc
        try:
            opened = os.fstat(member_fd)
            if (
                not stat.S_ISREG(opened.st_mode)
                or opened.st_dev != listed.st_dev
                or opened.st_ino != listed.st_ino
            ):
                raise SignedApplicationError(
                    "application output staging contents changed or became "
                    "unsafe"
                )
            digest = hashlib.sha256()
            while True:
                chunk = os.read(member_fd, 1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
            snapshot[relative] = (
                "file",
                opened.st_size,
                digest.hexdigest(),
            )
        finally:
            os.close(member_fd)
    return snapshot


def _empty_owned_directory_fd(directory_fd: int) -> None:
    with os.scandir(directory_fd) as entries:
        names = sorted(entry.name for entry in entries)
    for name in names:
        try:
            listed = os.stat(
                name,
                dir_fd=directory_fd,
                follow_symlinks=False,
            )
        except FileNotFoundError:
            continue
        if stat.S_ISDIR(listed.st_mode):
            child_fd = _open_directory_entry(
                directory_fd,
                name,
                label="owned application output cleanup directory",
            )
            try:
                child_identity = _directory_identity(child_fd)
                _empty_owned_directory_fd(child_fd)
                _assert_directory_entry_identity(
                    directory_fd,
                    name,
                    child_identity,
                    label="owned application output cleanup directory",
                )
                os.rmdir(name, dir_fd=directory_fd)
            finally:
                os.close(child_fd)
        else:
            os.unlink(name, dir_fd=directory_fd)
    os.fsync(directory_fd)


def _remove_owned_directory_by_identity(
    parent_fd: int,
    expected: tuple[int, int],
    *,
    recursive: bool = True,
) -> None:
    with os.scandir(parent_fd) as entries:
        names = sorted(entry.name for entry in entries)
    for name in names:
        try:
            listed = os.stat(
                name,
                dir_fd=parent_fd,
                follow_symlinks=False,
            )
        except FileNotFoundError:
            continue
        if (
            stat.S_ISDIR(listed.st_mode)
            and (listed.st_dev, listed.st_ino) == expected
        ):
            owned_fd = _open_directory_entry(
                parent_fd,
                name,
                label="owned application output cleanup root",
            )
            try:
                if _directory_identity(owned_fd) != expected:
                    continue
                if recursive:
                    _empty_owned_directory_fd(owned_fd)
                else:
                    with os.scandir(owned_fd) as children:
                        if next(children, None) is not None:
                            return
                _assert_directory_entry_identity(
                    parent_fd,
                    name,
                    expected,
                    label="owned application output cleanup root",
                )
                os.rmdir(name, dir_fd=parent_fd)
                os.fsync(parent_fd)
            finally:
                os.close(owned_fd)
            return


def _remove_output_at(
    output_parent_fd: int,
    output_name: str,
    output_identity: tuple[int, int],
) -> None:
    _remove_owned_directory_by_identity(
        output_parent_fd,
        output_identity,
    )


def _assert_author_receipt_absent_at(
    repo_directory_fd: int,
) -> None:
    parent_fd, _ = _open_directory_chain(
        repo_directory_fd,
        ("docs", "release"),
        create=False,
        label="author receipt parent",
    )
    if parent_fd is None:
        return
    try:
        _directory_entry_absent(
            parent_fd,
            Path(AUTHOR_RECEIPT_REPO_PATH).name,
            label="target author receipt",
        )
    finally:
        os.close(parent_fd)


def _assert_receipt_parent_identity(
    repo_directory_fd: int,
    expected_parent_fd: int,
) -> None:
    observed_fd, _ = _open_directory_chain(
        repo_directory_fd,
        ("docs", "release"),
        create=False,
        label="author receipt parent",
    )
    if observed_fd is None:
        raise SignedApplicationError("author receipt parent disappeared")
    try:
        expected = os.fstat(expected_parent_fd)
        observed = os.fstat(observed_fd)
        if (
            expected.st_dev != observed.st_dev
            or expected.st_ino != observed.st_ino
        ):
            raise SignedApplicationError(
                "author receipt parent changed after it was opened"
            )
    finally:
        os.close(observed_fd)


def _sha256_directory_entry(directory_fd: int, name: str) -> str:
    flags = os.O_RDONLY
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    descriptor = os.open(name, flags, dir_fd=directory_fd)
    try:
        opened = os.fstat(descriptor)
        if not stat.S_ISREG(opened.st_mode):
            raise SignedApplicationError(
                "installed author receipt is not a regular file"
            )
        digest = hashlib.sha256()
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
        return digest.hexdigest()
    finally:
        os.close(descriptor)


def _write_durable_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    _fsync_directory(path.parent)


def _write_journal(path: Path, payload: Mapping[str, object]) -> None:
    temporary = path.with_name(f".{path.name}.pending")
    if path.exists() or path.is_symlink() or temporary.exists():
        raise SignedApplicationError(
            "a prior signed-application journal or pending journal exists"
        )
    _write_durable_bytes(
        temporary,
        (
            json.dumps(payload, indent=2, sort_keys=True) + "\n"
        ).encode("utf-8"),
    )
    os.replace(temporary, path)
    _fsync_directory(path.parent)


def _remove_if_exists(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        return
    _fsync_directory(path.parent)


def _prune_empty_receipt_parents(repo: Path, receipt_target: Path) -> None:
    parent = receipt_target.parent
    while parent != repo and repo in parent.parents:
        try:
            parent.rmdir()
        except OSError:
            break
        parent = parent.parent


def _rollback_transaction(
    *,
    repo: Path,
    verified: VerifiedPackage,
    backup_root: Path,
    rollback_root: Path,
    repo_directory_fd: int,
    contracts_directory_fd: int,
    receipt_target: Path,
    receipt_directory_fd: int | None,
    receipt_installed: bool,
    receipt_created_parts: Sequence[str],
    output_parent_fd: int,
    output_name: str,
    output_published: bool,
    output_identity: tuple[int, int] | None,
) -> None:
    errors: list[str] = []
    for row in verified.scope_rows:
        relative = row["canonical_path"]
        backup = backup_root / relative
        target = repo / relative
        try:
            payload = backup.read_bytes()
            pending = rollback_root / relative
            pending.parent.mkdir(parents=True, exist_ok=True)
            pending.write_bytes(payload)
            _fsync_file(pending)
            os.replace(
                pending,
                target.name,
                dst_dir_fd=contracts_directory_fd,
            )
            os.fsync(contracts_directory_fd)
        except Exception as exc:  # pragma: no cover - catastrophic filesystem path
            errors.append(f"{relative}: {exc}")
    if receipt_installed and receipt_directory_fd is not None:
        try:
            os.unlink(
                receipt_target.name,
                dir_fd=receipt_directory_fd,
            )
            os.fsync(receipt_directory_fd)
        except FileNotFoundError:
            pass
        except Exception as exc:  # pragma: no cover - catastrophic filesystem path
            errors.append(f"{AUTHOR_RECEIPT_REPO_PATH}: {exc}")
    if "docs/release" in receipt_created_parts:
        try:
            docs_fd, _ = _open_directory_chain(
                repo_directory_fd,
                ("docs",),
                create=False,
                label="author receipt rollback parent",
            )
            if docs_fd is not None:
                try:
                    os.rmdir("release", dir_fd=docs_fd)
                    os.fsync(docs_fd)
                finally:
                    os.close(docs_fd)
        except OSError:
            pass
        except SignedApplicationError:
            pass
    if "docs" in receipt_created_parts:
        try:
            os.rmdir("docs", dir_fd=repo_directory_fd)
            os.fsync(repo_directory_fd)
        except OSError:
            pass
    if output_published and output_identity is not None:
        try:
            _remove_output_at(
                output_parent_fd,
                output_name,
                output_identity,
            )
        except Exception as exc:  # pragma: no cover - catastrophic filesystem path
            errors.append(f"application output: {exc}")
    for row in verified.scope_rows:
        try:
            if (
                _sha256_directory_entry(
                    contracts_directory_fd,
                    Path(row["canonical_path"]).name,
                )
                != row["canonical_pre_sha256"]
            ):
                errors.append(
                    f"post-rollback verification: {row['canonical_path']}"
                )
        except Exception as exc:  # pragma: no cover - catastrophic filesystem path
            errors.append(
                f"post-rollback verification: {row['canonical_path']}: {exc}"
            )
    try:
        _assert_directory_path_identity(
            repo / "contracts",
            contracts_directory_fd,
            label="canonical contracts directory",
        )
        _assert_current_pre_snapshot(repo, verified.canonical_pre_snapshot)
    except Exception as exc:  # pragma: no cover - external concurrent mutation
        errors.append(f"canonical contracts path changed externally: {exc}")
    if errors:
        raise SignedApplicationError(
            "transaction failed and rollback was incomplete; recovery journal "
            f"retained; errors={errors}"
        )


def _apply_transaction(
    *,
    repo: Path,
    output: Path,
    output_parent_fd: int,
    author_receipt_source: Path,
    repo_directory_fd: int,
    verified: VerifiedPackage,
    trust_policy: TrustPolicy,
    provenance: Mapping[str, object],
    validator: Path,
    validator_sha256: str,
    provenance_paths: Sequence[Path],
    validation_runs: list[dict[str, object]],
    failure_injector: Callable[[str, str, int], None] | None,
) -> dict[str, object]:
    journal_path = repo / ".signed-author-application.journal.json"
    if journal_path.exists() or journal_path.is_symlink():
        raise SignedApplicationError(
            "a prior signed-application recovery journal exists"
        )
    receipt_target = repo / AUTHOR_RECEIPT_REPO_PATH
    transaction_root = Path(
        tempfile.mkdtemp(prefix=".signed-author-transaction.", dir=repo)
    )
    backup_root = transaction_root / "backups"
    pending_root = transaction_root / "pending"
    rollback_root = transaction_root / "rollback"
    mutation_started = False
    rollback_complete = False
    preserve_recovery = False
    contracts_directory_fd: int | None = None
    receipt_directory_fd: int | None = None
    receipt_installed = False
    receipt_created_parts: tuple[str, ...] = ()
    output_published = False
    output_identity: tuple[int, int] | None = None
    try:
        if transaction_root.stat().st_dev != (repo / "contracts").stat().st_dev:
            raise SignedApplicationError(
                "candidate staging is not on the canonical filesystem"
            )
        contracts_directory_fd = _open_safe_directory(
            repo / "contracts",
            label="canonical contracts directory",
        )
        for row in verified.scope_rows:
            relative = row["canonical_path"]
            canonical = _safe_existing_file(
                repo,
                relative,
                label=f"{row['block_id']} canonical target",
            )
            backup = backup_root / relative
            pending = pending_root / relative
            _write_durable_bytes(backup, canonical.read_bytes())
            _write_durable_bytes(
                pending,
                verified.candidate_bytes[relative],
            )
            if (
                sha256_file(backup) != row["canonical_pre_sha256"]
                or sha256_file(pending) != row["expected_post_sha256"]
            ):
                raise SignedApplicationError(
                    f"{row['block_id']} staged or backup bytes do not match scope"
                )
        pending_receipt = pending_root / AUTHOR_RECEIPT_REPO_PATH
        _write_durable_bytes(
            pending_receipt,
            verified.author_receipt_bytes,
        )
        if (
            sha256_file(pending_receipt)
            != verified.author_receipt_sha256
        ):
            raise SignedApplicationError("staged author receipt hash mismatch")
        _assert_current_pre_snapshot(repo, verified.canonical_pre_snapshot)
        _assert_directory_path_identity(
            repo / "contracts",
            contracts_directory_fd,
            label="canonical contracts directory",
        )
        _assert_package_unchanged(verified)
        _assert_same_provenance(repo, provenance_paths, provenance)
        _reverify_exact_inputs(
            repo=repo,
            verified=verified,
            author_receipt=author_receipt_source,
            trust_policy=trust_policy,
        )
        _assert_regular_file(
            author_receipt_source,
            label="external author receipt",
        )
        if sha256_file(author_receipt_source) != verified.author_receipt_sha256:
            raise SignedApplicationError(
                "external author receipt changed after verification"
            )
        journal_payload = {
            "schema_version": "1",
            "authorization_id": trust_policy.authorization_id,
            "status": "prepared",
            "transaction_root": str(transaction_root),
            "author_receipt_repo_path": AUTHOR_RECEIPT_REPO_PATH,
            "author_receipt_preexisting": False,
            "targets": [
                {
                    "canonical_path": row["canonical_path"],
                    "pre_sha256": row["canonical_pre_sha256"],
                    "post_sha256": row["expected_post_sha256"],
                    "backup_path": str(backup_root / row["canonical_path"]),
                    "pending_path": str(pending_root / row["canonical_path"]),
                }
                for row in verified.scope_rows
            ],
        }
        _write_journal(journal_path, journal_payload)
        mutation_started = True

        for index, row in enumerate(verified.scope_rows):
            relative = row["canonical_path"]
            target = repo / relative
            pending = pending_root / relative
            if (
                _sha256_directory_entry(
                    contracts_directory_fd,
                    target.name,
                )
                != row["canonical_pre_sha256"]
            ):
                raise SignedApplicationError(
                    f"{row['block_id']} canonical target changed before replacement"
                )
            _inject(failure_injector, "before_replace", relative, index)
            os.replace(
                pending,
                target.name,
                dst_dir_fd=contracts_directory_fd,
            )
            os.fsync(contracts_directory_fd)
            _inject(failure_injector, "after_replace", relative, index)
        _inject(
            failure_injector,
            "before_receipt_parent_open",
            "docs/release",
            7,
        )
        receipt_directory_fd, receipt_created_parts = _open_directory_chain(
            repo_directory_fd,
            ("docs", "release"),
            create=True,
            label="author receipt parent",
        )
        if receipt_directory_fd is None:  # pragma: no cover - create guarantees fd
            raise SignedApplicationError("author receipt parent was not created")
        _directory_entry_absent(
            receipt_directory_fd,
            receipt_target.name,
            label="target author receipt",
        )
        _inject(
            failure_injector,
            "before_receipt",
            AUTHOR_RECEIPT_REPO_PATH,
            7,
        )
        os.replace(
            pending_receipt,
            receipt_target.name,
            dst_dir_fd=receipt_directory_fd,
        )
        receipt_installed = True
        os.fsync(receipt_directory_fd)
        _inject(
            failure_injector,
            "after_receipt",
            AUTHOR_RECEIPT_REPO_PATH,
            7,
        )

        for row in verified.scope_rows:
            target = repo / row["canonical_path"]
            if (
                _sha256_directory_entry(
                    contracts_directory_fd,
                    target.name,
                )
                != row["expected_post_sha256"]
            ):
                raise SignedApplicationError(
                    f"{row['block_id']} post-application hash mismatch"
                )
        _assert_directory_path_identity(
            repo / "contracts",
            contracts_directory_fd,
            label="canonical contracts directory",
        )
        _assert_receipt_parent_identity(
            repo_directory_fd,
            receipt_directory_fd,
        )
        if (
            _sha256_directory_entry(
                receipt_directory_fd,
                receipt_target.name,
            )
            != verified.author_receipt_sha256
        ):
            raise SignedApplicationError(
                "installed author receipt hash mismatch"
            )
        _inject(failure_injector, "before_post_validator", "repository", 8)
        _assert_same_provenance(repo, provenance_paths, provenance)
        validation_runs.append(
            _run_validator(
                validator_path=validator,
                repo_root=repo,
                phase="post-application-live",
                expected_sha256=validator_sha256,
            )
        )
        _inject(failure_injector, "before_output_publish", str(output), 8)
        output_identity = _write_result_bundle(
            output=output,
            output_parent_fd=output_parent_fd,
            verified=verified,
            trust_policy=trust_policy,
            provenance=provenance,
            validation=validation_runs,
            status="APPLIED",
            applied=True,
            backup_root=backup_root,
            failure_injector=failure_injector,
        )
        output_published = True
        _remove_if_exists(journal_path)
        rollback_complete = True
        return {
            "status": "APPLIED",
            "applied": True,
            "output_dir": str(output),
        }
    except BaseException as original:
        if mutation_started:
            try:
                _rollback_transaction(
                    repo=repo,
                    verified=verified,
                    backup_root=backup_root,
                    rollback_root=rollback_root,
                    repo_directory_fd=repo_directory_fd,
                    contracts_directory_fd=contracts_directory_fd,
                    receipt_target=receipt_target,
                    receipt_directory_fd=receipt_directory_fd,
                    receipt_installed=receipt_installed,
                    receipt_created_parts=receipt_created_parts,
                    output_parent_fd=output_parent_fd,
                    output_name=output.name,
                    output_published=output_published,
                    output_identity=output_identity,
                )
                _remove_if_exists(journal_path)
                rollback_complete = True
            except Exception as rollback_error:
                preserve_recovery = True
                raise rollback_error from original
        raise
    finally:
        if contracts_directory_fd is not None:
            os.close(contracts_directory_fd)
        if receipt_directory_fd is not None:
            os.close(receipt_directory_fd)
        if not preserve_recovery and (not mutation_started or rollback_complete):
            shutil.rmtree(transaction_root, ignore_errors=True)


def execute_application(
    *,
    repo_root: Path,
    package_dir: Path,
    author_receipt: Path,
    output_dir: Path,
    apply: bool = False,
    trust_policy: TrustPolicy,
    validator_path: Path | None = None,
    _provenance_paths: Sequence[Path] | None = None,
    _failure_injector: Callable[[str, str, int], None] | None = None,
) -> dict[str, object]:
    """Verify or apply one exact package; private arguments are test seams."""
    repo = repo_root.absolute()
    output = output_dir.absolute()
    validator = validator_path or (
        repo / "Scripts/QA_QC/11_validate_panel_contract.py"
    )
    production_paths = tuple(
        _provenance_paths
        or (
            Path(__file__).absolute(),
            repo / "tests/test_apply_signed_author_decision_package.py",
            validator,
        )
    )
    _validate_output_path(repo, package_dir.absolute(), output)
    journal_path = repo / ".signed-author-application.journal.json"
    try:
        journal_path.lstat()
    except FileNotFoundError:
        pass
    else:
        raise SignedApplicationError(
            "a prior signed-application recovery journal exists"
        )
    provenance = _validate_provenance(repo, production_paths)
    verified = verify_package(
        repo_root=repo,
        package_dir=package_dir,
        author_receipt=author_receipt,
        trust_policy=trust_policy,
    )
    try:
        repo_directory_fd = _open_safe_directory(
            repo,
            label="repository root",
        )
        _assert_author_receipt_absent_at(repo_directory_fd)
        output_parent_fd = _open_output_parent(output)
    except BaseException:
        if "output_parent_fd" in locals():
            os.close(output_parent_fd)
        if "repo_directory_fd" in locals():
            os.close(repo_directory_fd)
        raise

    lock_path = repo / ".signed-author-application.lock"
    try:
        lock_handle, lock_identity = _open_safe_repository_lock(lock_path)
    except BaseException:
        os.close(output_parent_fd)
        os.close(repo_directory_fd)
        raise
    try:
        fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        lock_handle.close()
        os.close(output_parent_fd)
        os.close(repo_directory_fd)
        raise SignedApplicationError(
            "another signed application process holds the repository lock"
        ) from exc

    validation_runs: list[dict[str, object]] = []
    try:
        _assert_author_receipt_absent_at(repo_directory_fd)
        _assert_same_provenance(repo, production_paths, provenance)
        _assert_author_receipt_absent_at(repo_directory_fd)
        validator_sha256 = _provenance_member_hash(
            repo,
            validator,
            provenance,
        )
        with tempfile.TemporaryDirectory(
            prefix=".signed-author-validation.",
            dir=repo,
        ) as temporary:
            staging_repo = Path(temporary) / "repo"
            staging_repo.mkdir()
            _stage_validation_repo(repo, verified, staging_repo)
            validation_runs.append(
                _run_validator(
                    validator_path=validator,
                    repo_root=staging_repo,
                    phase="pre-application-staged",
                    expected_sha256=validator_sha256,
                )
            )
        _inject(
            _failure_injector,
            "after_pre_validator",
            "staged-repository",
            -1,
        )
        _assert_output_parent_identity(output.parent, output_parent_fd)
        _assert_same_provenance(repo, production_paths, provenance)
        _reverify_exact_inputs(
            repo=repo,
            verified=verified,
            author_receipt=author_receipt.absolute(),
            trust_policy=trust_policy,
        )
        _assert_current_pre_snapshot(repo, verified.canonical_pre_snapshot)
        _assert_package_unchanged(verified)
        if not apply:
            _write_result_bundle(
                output=output,
                output_parent_fd=output_parent_fd,
                verified=verified,
                trust_policy=trust_policy,
                provenance=provenance,
                validation=validation_runs,
                status="DRY_RUN_VERIFIED",
                applied=False,
                failure_injector=_failure_injector,
            )
            return {
                "status": "DRY_RUN_VERIFIED",
                "applied": False,
                "output_dir": str(output),
            }
        return _apply_transaction(
            repo=repo,
            output=output,
            output_parent_fd=output_parent_fd,
            author_receipt_source=author_receipt.absolute(),
            repo_directory_fd=repo_directory_fd,
            verified=verified,
            trust_policy=trust_policy,
            provenance=provenance,
            validator=validator,
            validator_sha256=validator_sha256,
            provenance_paths=production_paths,
            validation_runs=validation_runs,
            failure_injector=_failure_injector,
        )
    finally:
        try:
            _unlink_owned_lock(lock_path, lock_identity)
        finally:
            try:
                lock_handle.close()
            finally:
                try:
                    os.close(output_parent_fd)
                finally:
                    os.close(repo_directory_fd)


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", required=True, type=Path)
    parser.add_argument("--package-dir", required=True, type=Path)
    parser.add_argument("--author-receipt", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument(
        "--apply",
        action="store_true",
        help="perform the exact transaction; default is dry-run verification",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        result = execute_application(
            repo_root=args.repo_root,
            package_dir=args.package_dir,
            author_receipt=args.author_receipt,
            output_dir=args.output_dir,
            apply=args.apply,
            trust_policy=DEFAULT_TRUST_POLICY,
        )
    except SignedApplicationError as exc:
        raise SystemExit(f"[fatal] {exc}") from exc
    print(result["status"])
    print(f"output_dir={result['output_dir']}")
    return 0


# The production trust policy is populated below as immutable source literals.
DEFAULT_TRUST_POLICY = TrustPolicy(
    authorization_id="AUTH-B03-B09-20260724",
    contract_id="ipedsdb-panel-2004-2023-access-v2",
    author_name="Mark Jayson Martinez Farol",
    author_date="2026-07-24",
    author_decision_register_sha256=(
        "72c12fd2b61f0470bb4cec1aee51c8d342bef12e8c572bea1e3feb538c2ff4a0"
    ),
    canonical_application_scope_sha256=(
        "bf7cd2c9c58baf9419fd5fbb6ebda6615cc9e8a18aa82670da092dc406b2c882"
    ),
    transitive_review_target_sha256=(
        "cd4a57a982098747cb2b794b2c5f1a4f4b431fe55cde6ddefa50a3df709b2c3b"
    ),
    bundle_sha256=(
        "ab4a4e6400c8dc6d53ad9e0fdab0fef61d0c19c1cd5430cd5777e61147d212e3"
    ),
    required_statement=(
        "I, Mark Jayson Martinez Farol, dated 2026-07-24, countersign "
        "`AUTHOR_DECISION_REGISTER.csv` SHA-256 "
        "`72c12fd2b61f0470bb4cec1aee51c8d342bef12e8c572bea1e3feb538c2ff4a0`, "
        "`CANONICAL_APPLICATION_SCOPE.csv` SHA-256 "
        "`bf7cd2c9c58baf9419fd5fbb6ebda6615cc9e8a18aa82670da092dc406b2c882`, "
        "and transitive review-target SHA-256 "
        "`cd4a57a982098747cb2b794b2c5f1a4f4b431fe55cde6ddefa50a3df709b2c3b`. "
        "I authorize Codex to replace only the seven canonical B03-B09 paths "
        "listed in that scope, only when every canonical pre-hash, candidate "
        "hash, expected post-hash, row count, child decision scope, evidence "
        "manifest, and input manifest matches exactly. I approve every "
        "proposed child decision exactly within the listed hash-bound scopes, "
        "including the explicit all-empty B04 exclusions. Any mismatch voids "
        "this authorization and requires a stop. This authorizes canonical "
        "contract application only; it does not authorize Stage 02 extraction, "
        "a full build, release, deployment, cleanup, deletion, installation, "
        "Docker, or Colima."
    ),
    scope_bindings=(
        ScopeBinding(
            scope_id="AUTH-B03-B09-20260724-B03",
            contract_id="ipedsdb-panel-2004-2023-access-v2",
            block_id="B03",
            canonical_path="contracts/table_grain.csv",
            canonical_pre_sha256="f802dbc670f443e81ea3047469f65ff0143baa56b3f7dc307861a267ba5aee48",
            final_candidate_path="canonical_candidates/table_grain.csv",
            final_candidate_sha256="fd5cf7273b8aeaea9f6a7bd2d66a3799972e59e17e6f58087fa1bc1767717d70",
            expected_post_sha256="fd5cf7273b8aeaea9f6a7bd2d66a3799972e59e17e6f58087fa1bc1767717d70",
            row_count="114",
            application_mode="replace_exact_bytes",
            child_decision_scope=(
                "all exact Stage04 table identities represented by the "
                "lossless table projection"
            ),
            child_decision_register_path=(
                "Artifacts/review_v2/stage04_contract_projection_2026-07-24/"
                "table_grain_contract_projection.csv"
            ),
            child_decision_register_sha256="4b6de0af9ed7a29940bdc8f24cff2fc15c7293f79ba92f36a06c4b5463d771dc",
            evidence_manifest_path=(
                "Artifacts/review_v2/stage04_contract_projection_2026-07-24/"
                "STAGE04_PROJECTION_ARTIFACT_MANIFEST.csv"
            ),
            evidence_manifest_sha256="8fa3d895bb96d6d0ee35aec47f1ec2b161120e2acac4526917c69dde9e850d36",
            input_manifest_path=(
                "Artifacts/review_v2/stage04_contract_projection_2026-07-24/"
                "STAGE04_PROJECTION_INPUT_MANIFEST.csv"
            ),
            input_manifest_sha256="be6abac0635ef48ad85ca0ae0d238758a885dd0b10fa2cfb32953cad8f55cb40",
            readiness_status="author_ready",
        ),
        ScopeBinding(
            scope_id="AUTH-B03-B09-20260724-B04",
            contract_id="ipedsdb-panel-2004-2023-access-v2",
            block_id="B04",
            canonical_path="contracts/source_columns.csv",
            canonical_pre_sha256="7929a50b8436ebbad57a30f2f739bb506706c5c849675feabee5ae49d9e28fcd",
            final_candidate_path="canonical_candidates/source_columns.csv",
            final_candidate_sha256="22d72c86a94c03fc9490f7eb2947604a04f14b62de5ef6e8cab6fcddd93b5bc2",
            expected_post_sha256="22d72c86a94c03fc9490f7eb2947604a04f14b62de5ef6e8cab6fcddd93b5bc2",
            row_count="4681",
            application_mode="replace_exact_bytes",
            child_decision_scope=(
                "all exact Stage04 source roles and every explicit all-empty "
                "intentional exclusion"
            ),
            child_decision_register_path=(
                "Artifacts/review_v2/stage04_contract_projection_2026-07-24/"
                "stage04_proposed_empty_exclusions.csv"
            ),
            child_decision_register_sha256="e07491265a0cc918454eec273ee0d2fe464cad4f200e1b43ae9aa98721213220",
            evidence_manifest_path=(
                "Artifacts/review_v2/stage04_contract_projection_2026-07-24/"
                "STAGE04_PROJECTION_ARTIFACT_MANIFEST.csv"
            ),
            evidence_manifest_sha256="8fa3d895bb96d6d0ee35aec47f1ec2b161120e2acac4526917c69dde9e850d36",
            input_manifest_path=(
                "Artifacts/review_v2/stage04_contract_projection_2026-07-24/"
                "STAGE04_PROJECTION_INPUT_MANIFEST.csv"
            ),
            input_manifest_sha256="be6abac0635ef48ad85ca0ae0d238758a885dd0b10fa2cfb32953cad8f55cb40",
            readiness_status="author_ready",
        ),
        ScopeBinding(
            scope_id="AUTH-B03-B09-20260724-B05",
            contract_id="ipedsdb-panel-2004-2023-access-v2",
            block_id="B05",
            canonical_path="contracts/analysis_schema.csv",
            canonical_pre_sha256="2e5ec59201020a74309bcdc8e64f232c06d8a22b2085934e508f4f44f1292286",
            final_candidate_path="canonical_candidates/analysis_schema.csv",
            final_candidate_sha256="c284398e1a5189f639a939a722eb100b3853748a06a74c197b4b6bdab17d21c4",
            expected_post_sha256="c284398e1a5189f639a939a722eb100b3853748a06a74c197b4b6bdab17d21c4",
            row_count="2720",
            application_mode="replace_exact_bytes",
            child_decision_scope=(
                "phase=B05; every exact include_direct_identity action"
            ),
            child_decision_register_path=(
                "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24/"
                "B05_B06_CONSERVATIVE_DECISION_REGISTER.csv"
            ),
            child_decision_register_sha256="9c6dfd1cd04d427ea9de71c8fa50e71549b06e8ba64fb28eff2e2a12bddc3d53",
            evidence_manifest_path=(
                "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24/"
                "B05_B06_ARTIFACT_MANIFEST.csv"
            ),
            evidence_manifest_sha256="022c1f0147ddfc26d72499d39e3de8f5f72efb1668c99c494e3603e418cdede8",
            input_manifest_path=(
                "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24/"
                "B05_B06_INPUT_MANIFEST.csv"
            ),
            input_manifest_sha256="b671c6cde292cc66aaf07f5176b68c30c9bf31926ad7b6274abdbec2fc93df66",
            readiness_status="author_ready",
        ),
        ScopeBinding(
            scope_id="AUTH-B03-B09-20260724-B06",
            contract_id="ipedsdb-panel-2004-2023-access-v2",
            block_id="B06",
            canonical_path="contracts/discrete_families.csv",
            canonical_pre_sha256="712bc309b0f8ceb28067617af8fe7d46072418896385322becc65f492775040d",
            final_candidate_path="canonical_candidates/discrete_families.csv",
            final_candidate_sha256="67c022b560691fb82413758513b0be5b810ec0bec15f396d1aee065a09bb3f65",
            expected_post_sha256="67c022b560691fb82413758513b0be5b810ec0bec15f396d1aee065a09bb3f65",
            row_count="411",
            application_mode="replace_exact_bytes",
            child_decision_scope=(
                "phase=B06; every exact retain_not_collapsible action"
            ),
            child_decision_register_path=(
                "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24/"
                "B05_B06_CONSERVATIVE_DECISION_REGISTER.csv"
            ),
            child_decision_register_sha256="9c6dfd1cd04d427ea9de71c8fa50e71549b06e8ba64fb28eff2e2a12bddc3d53",
            evidence_manifest_path=(
                "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24/"
                "B05_B06_ARTIFACT_MANIFEST.csv"
            ),
            evidence_manifest_sha256="022c1f0147ddfc26d72499d39e3de8f5f72efb1668c99c494e3603e418cdede8",
            input_manifest_path=(
                "Artifacts/review_v2/b05_b06_conservative_candidates_2026-07-24/"
                "B05_B06_INPUT_MANIFEST.csv"
            ),
            input_manifest_sha256="b671c6cde292cc66aaf07f5176b68c30c9bf31926ad7b6274abdbec2fc93df66",
            readiness_status="author_ready",
        ),
        ScopeBinding(
            scope_id="AUTH-B03-B09-20260724-B07",
            contract_id="ipedsdb-panel-2004-2023-access-v2",
            block_id="B07",
            canonical_path="contracts/prch_policy.csv",
            canonical_pre_sha256="92424ec99fc24b60e1acf286a2e9dd7e0f7bc3a6402c35567c8d36ec3e4e17ea",
            final_candidate_path="canonical_candidates/prch_policy.csv",
            final_candidate_sha256="c3320783366c7d9bc6bb808bcc7432398bf2a0cb4347fa44e070dd48b5fa4258",
            expected_post_sha256="c3320783366c7d9bc6bb808bcc7432398bf2a0cb4347fa44e070dd48b5fa4258",
            row_count="1620",
            application_mode="replace_exact_bytes",
            child_decision_scope=(
                "the exact B07 conditional review target, component and "
                "Finance bindings, exception register, lineage, and proofs"
            ),
            child_decision_register_path=(
                "Artifacts/review_v2/b07_prch_policy_candidate_2026-07-24/"
                "B07_PRCH_POLICY_AUTHOR_COUNTERSIGN.csv"
            ),
            child_decision_register_sha256="7bbc10ed0fd5eef8d4799c540e31de211fda69fa4e37f34d21737a4d28e50173",
            evidence_manifest_path=(
                "Artifacts/review_v2/b07_prch_policy_candidate_2026-07-24/"
                "B07_PRCH_POLICY_ARTIFACT_MANIFEST.csv"
            ),
            evidence_manifest_sha256="5dce240ca358c0129ea5ccd84854fdd9f3e9eec66da140b72c766db8db56785b",
            input_manifest_path=(
                "Artifacts/review_v2/b07_prch_policy_candidate_2026-07-24/"
                "B07_PRCH_POLICY_INPUT_MANIFEST.csv"
            ),
            input_manifest_sha256="ba20da8939c15e85178843348af3977d4eca5b94f0633f149af6194fe30a202d",
            readiness_status="author_ready",
        ),
        ScopeBinding(
            scope_id="AUTH-B03-B09-20260724-B08",
            contract_id="ipedsdb-panel-2004-2023-access-v2",
            block_id="B08",
            canonical_path="contracts/external_benchmarks.csv",
            canonical_pre_sha256="d11ca73db7f174d0f12243d0444cff0eb08492412aeb8a10b8da605d49438e1a",
            final_candidate_path="canonical_candidates/external_benchmarks.csv",
            final_candidate_sha256="0159f7dedca341519eca5727f2d49d1bb0d1d46de7fc673c3334fe2d07c24eb1",
            expected_post_sha256="0159f7dedca341519eca5727f2d49d1bb0d1d46de7fc673c3334fe2d07c24eb1",
            row_count="18",
            application_mode="replace_exact_bytes",
            child_decision_scope=(
                "every official benchmark value, definition, source channel, "
                "and exact tolerance in the B08 decision register"
            ),
            child_decision_register_path=(
                "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
                "B08_EXTERNAL_BENCHMARK_DECISION_REGISTER.csv"
            ),
            child_decision_register_sha256="4594c49ac4cca60da9e8b3a24ad976ab938998d8a86539d7e5b3a39233ec9535",
            evidence_manifest_path=(
                "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
                "SCIENTIFIC_REVIEW_PACKAGE_MANIFEST.csv"
            ),
            evidence_manifest_sha256="c9aae983518547b77b2f0598f87c00d718442ce1bebbbd36c0b408ad7cacc1c9",
            input_manifest_path=(
                "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
                "SCIENTIFIC_REVIEW_PACKAGE_MANIFEST.csv"
            ),
            input_manifest_sha256="c9aae983518547b77b2f0598f87c00d718442ce1bebbbd36c0b408ad7cacc1c9",
            readiness_status="author_ready",
        ),
        ScopeBinding(
            scope_id="AUTH-B03-B09-20260724-B09",
            contract_id="ipedsdb-panel-2004-2023-access-v2",
            block_id="B09",
            canonical_path="contracts/metadata_backfill_approvals.csv",
            canonical_pre_sha256="38b64161d868db79bbdea62238423f26984d965809a1be2d70dbf029965464ce",
            final_candidate_path=(
                "canonical_candidates/metadata_backfill_approvals.csv"
            ),
            final_candidate_sha256="c5efc85b8b567d0729864702ac528fabe5632862753b6790142f5f8debe53b4a",
            expected_post_sha256="c5efc85b8b567d0729864702ac528fabe5632862753b6790142f5f8debe53b4a",
            row_count="4",
            application_mode="replace_exact_bytes",
            child_decision_scope=(
                "every exact B09 conditional donor selection represented by "
                "the final candidate"
            ),
            child_decision_register_path=(
                "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
                "B09_METADATA_BACKFILL_DECISION_REGISTER.csv"
            ),
            child_decision_register_sha256="81170ee27526dfd703f243386c10a33b828af99de03ec01ce51ece53538c5d70",
            evidence_manifest_path=(
                "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
                "SCIENTIFIC_REVIEW_PACKAGE_MANIFEST.csv"
            ),
            evidence_manifest_sha256="c9aae983518547b77b2f0598f87c00d718442ce1bebbbd36c0b408ad7cacc1c9",
            input_manifest_path=(
                "Artifacts/review_v2/remaining_scientific_review_2026-07-24/"
                "SCIENTIFIC_REVIEW_PACKAGE_MANIFEST.csv"
            ),
            input_manifest_sha256="c9aae983518547b77b2f0598f87c00d718442ce1bebbbd36c0b408ad7cacc1c9",
            readiness_status="author_ready",
        ),
    ),
)


if __name__ == "__main__":
    raise SystemExit(main())
