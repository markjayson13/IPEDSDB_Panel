#!/usr/bin/env python3
"""Build a source-bound, non-release B03/B04 evidence-package report."""
from __future__ import annotations

import argparse
import csv
import hashlib
import re
import shutil
import subprocess
import tomllib
from collections import Counter, defaultdict
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[1]

CANONICAL_B03_B04_CONTRACTS = (
    "contracts/b03_b04_decisions.csv",
    "contracts/table_grain.csv",
    "contracts/source_columns.csv",
    "contracts/source_metadata_aliases.csv",
)
PRIOR_REVIEWED_B01_B02_CONTRACTS = {
    "contracts/source_releases.csv",
    "contracts/dictionary_ambiguity_overrides.csv",
}
AUTHORIZED_B03_B04_RUNTIME_SUPPORT_CONTRACTS = {
    "contracts/panel_spec.toml",
}
GENERATOR_INPUTS = (
    "tools/build_b03_b04_repaired_evidence.py",
    "tools/build_grain_column_evidence.py",
    "tools/access_schema_evidence.py",
    "tools/build_b03_b04_package_report.py",
)
EVIDENCE_GENERATOR_INPUTS = GENERATOR_INPUTS[:3]
REQUIRED_EVIDENCE_ARTIFACTS = (
    "table_grain_enriched.csv",
    "table_grain_exceptions.csv",
    "table_grain_summary.md",
    "table_metadata_join_diagnostics.csv",
    "table_family_summary.csv",
    "table_key_candidate_details.csv",
    "table_key_duplicate_samples.csv",
    "table_key_null_samples.csv",
    "source_column_enriched.csv",
    "source_column_exceptions.csv",
    "source_column_summary.md",
    "source_column_metadata_join_diagnostics.csv",
    "source_column_signature_summary.csv",
    "imputation_link_reconciliation.csv",
    "source_column_2023_alias_candidates.csv",
    "source_column_2023_missing_diagnostics.csv",
)
REQUIRED_PACKAGE_ARTIFACTS = ("B03_B04_command_log.txt",)
ALLOWED_METADATA_STATUSES = {
    "exact",
    "multiple",
    "missing",
    "not_applicable",
}
ALLOWED_CANDIDATE_ROLES = {
    "identifier",
    "dimension",
    "measure_candidate",
    "imputation_field",
    "administrative_field",
    "metadata_field",
    "intentionally_excluded",
    "unresolved",
}
CANONICAL_TO_CANDIDATE_ROLE = {
    "identifier": "identifier",
    "dimension": "dimension",
    "measure": "measure_candidate",
    "imputation": "imputation_field",
    "administrative": "administrative_field",
    "metadata": "administrative_field",
    "excluded": "intentionally_excluded",
}
INVENTORY_TO_EVIDENCE_TABLE_ROLE = {
    "data": "data",
    "unknown": "control",
    "metadata_other": "control",
    "metadata_varlist": "control",
    "metadata_codes": "control",
}
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
COMMIT_RE = re.compile(r"^[0-9a-f]{40}$")
BLOCKED_EXACT_SCOPE_RE = re.compile(
    r"^(?P<year>\d{4}):(?P<table>[^.]+)\.(?P<column>.+)$"
)
BLOCKED_FAMILY_SCOPE_RE = re.compile(
    r"^(?P<family>[^.]+)\.(?P<column>\S+)\s+\((?P<year>\d{4})\)$"
)


@dataclass(frozen=True)
class PackageTrustPolicy:
    """Out-of-band trust anchors for one bounded evidence package."""

    base_commit: str
    authorized_contract_commit: str
    evidence_generator_commit: str
    receipt_date: str
    receipt_worktree: str
    receipt_branch: str
    command_log_normalized_sha256: str
    decision_register_sha256: str
    evidence_artifact_sha256: tuple[tuple[str, str], ...]
    source_input_manifest_sha256: str


PRODUCTION_TRUST_POLICY = PackageTrustPolicy(
    base_commit="0d993ace78de24db4a4f4271380690654e157348",
    authorized_contract_commit="3751fc6f12ac0456f194388b43665272f14e14c5",
    evidence_generator_commit="3751fc6f12ac0456f194388b43665272f14e14c5",
    receipt_date="2026-07-24",
    receipt_worktree="/private/tmp/IPEDSDB_Panel-pipeline-v2",
    receipt_branch="codex/pipeline-integrity-v2",
    command_log_normalized_sha256=(
        "bc0990f090db54e6eddcc946fb287e5186f46c213221bfba0ae70531f792a603"
    ),
    decision_register_sha256=(
        "801f232fda4cac15fac75522f57ceff571fe611093f12f7aeb5921c106bd92cf"
    ),
    source_input_manifest_sha256=(
        "8c1bed1ee4fb60a80b9c41645c099c985c31dae70cb999aac319ea5ca3ab83ef"
    ),
    evidence_artifact_sha256=(
        (
            "table_grain_enriched.csv",
            "043149d32302329b600f258882a396214aca9adbee052348d4bb55297bcb1a03",
        ),
        (
            "table_grain_exceptions.csv",
            "ef9167273156040bfe856d9aff0c93d4c657037a5592e0b5d757fdde95a5350e",
        ),
        (
            "table_grain_summary.md",
            "8f41cc1ecf63b420ccf6b33ac0fd35531250a81300713095343bba88225e8ad9",
        ),
        (
            "table_metadata_join_diagnostics.csv",
            "58aae6446fda6dd7768a470ac2108d44a2da31d0a279823a9eab7cea1d36fdbe",
        ),
        (
            "table_family_summary.csv",
            "2082c19e675d60c2291e0d4b25053051a768681961e97b6410b6148eba8eca1c",
        ),
        (
            "table_key_candidate_details.csv",
            "c4a99cd2978aa4be32cf5170b07d579385f67535ffacf2e12fb37c72b66885ad",
        ),
        (
            "table_key_duplicate_samples.csv",
            "388d11f28a0208eb47c94214da1be4c3f5a2e45e3769bde76acdc9bf5d9ac4e9",
        ),
        (
            "table_key_null_samples.csv",
            "388d11f28a0208eb47c94214da1be4c3f5a2e45e3769bde76acdc9bf5d9ac4e9",
        ),
        (
            "source_column_enriched.csv",
            "9848d03cc52526c59424912f62ba0e6930e02ca255f7e7e2b49fc35342840e1b",
        ),
        (
            "source_column_exceptions.csv",
            "591c76adbfbea2f9a2d5170807776d1c961d8ffb93649e7af6dbfdbd8bd6c6db",
        ),
        (
            "source_column_summary.md",
            "56761ab7a43b41b49121a84eb1e15b4ff7d016e7e801cf209e6e4218a15c2a45",
        ),
        (
            "source_column_metadata_join_diagnostics.csv",
            "a75c815fe672c7e58c906e354c370cc5000e9f7050b0f4013382cb1cd67afedb",
        ),
        (
            "source_column_signature_summary.csv",
            "8d24d0de059e09291dc73a9310786a550bd28a99043a7e1c94210e912083f301",
        ),
        (
            "imputation_link_reconciliation.csv",
            "14954b5294caf8bf3f178d39053f0e3bfa674b46ad779c5d0309e4e5791e3f91",
        ),
        (
            "source_column_2023_alias_candidates.csv",
            "a58744dc78091942c97d375438a82c240a65b3e6375280b393f591475673b834",
        ),
        (
            "source_column_2023_missing_diagnostics.csv",
            "4ea6888f9a995aaa6a10569d34e6a1e878e6b73f89ed59c1d95481e277090ee3",
        ),
    ),
)


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            hasher.update(block)
    return hasher.hexdigest()


def normalized_command_log_digest(text: str) -> str:
    """Hash a receipt while excluding bound commit IDs and elapsed tokens."""

    if not text.isascii():
        raise ValueError("command log must be ASCII text")
    if any(
        (ord(character) < 0x20 and character != "\n")
        or ord(character) == 0x7F
        for character in text
    ):
        raise ValueError(
            "command log contains an unsupported control character"
        )

    normalized_lines: list[str] = []
    commit_header = re.compile(
        r"^(Final package head|Evidence-generator implementation head|"
        r"Authorized canonical snapshot): [0-9a-f]{40}$"
    )
    elapsed_test_result = re.compile(
        r"^(\s*\d+ passed) in \d+(?:\.\d+)?s(.*)$"
    )
    for line in text.splitlines():
        commit_match = commit_header.fullmatch(line)
        if commit_match is not None:
            normalized_lines.append(f"{commit_match.group(1)}: <commit>")
            continue
        elapsed_match = elapsed_test_result.fullmatch(line)
        if elapsed_match is not None:
            normalized_lines.append(
                f"{elapsed_match.group(1)} in <elapsed>"
                f"{elapsed_match.group(2)}"
            )
            continue
        normalized_lines.append(line)
    normalized = "\n".join(normalized_lines)
    if text.endswith(("\n", "\r")):
        normalized += "\n"
    return hashlib.sha256(normalized.encode("utf-8", errors="strict")).hexdigest()


def _hash_fields(rows: Iterable[Iterable[str]]) -> str:
    hasher = hashlib.sha256()
    for row in rows:
        values = tuple(row)
        hasher.update(len(values).to_bytes(8, "big"))
        for value in values:
            encoded = value.encode("utf-8", errors="strict")
            hasher.update(len(encoded).to_bytes(8, "big"))
            hasher.update(encoded)
    return hasher.hexdigest()


def trusted_input_fingerprint(
    rows: Iterable[dict[str, object]],
) -> str:
    """Hash source/evidence inputs while excluding mutable package code."""

    fields = (
        "source_scope",
        "year",
        "logical_identity",
        "path",
        "byte_size",
        "sha256",
        "expected_sha256",
        "verification_status",
        "purpose",
    )
    selected = sorted(
        (
            tuple(str(row.get(field, "")) for field in fields)
            for row in rows
            if str(row.get("source_scope", "")) != "generator"
        ),
        key=lambda row: tuple((value.casefold(), value) for value in row),
    )
    return _hash_fields(selected)


def validate_trust_policy(
    trust_policy: PackageTrustPolicy,
) -> dict[str, str]:
    if not isinstance(trust_policy, PackageTrustPolicy):
        raise ValueError("package trust policy has an invalid type")
    for label, value, pattern in (
        ("base commit", trust_policy.base_commit, COMMIT_RE),
        (
            "authorized contract commit",
            trust_policy.authorized_contract_commit,
            COMMIT_RE,
        ),
        (
            "evidence generator commit",
            trust_policy.evidence_generator_commit,
            COMMIT_RE,
        ),
        (
            "decision register SHA-256",
            trust_policy.decision_register_sha256,
            SHA256_RE,
        ),
        (
            "source-input manifest SHA-256",
            trust_policy.source_input_manifest_sha256,
            SHA256_RE,
        ),
        (
            "normalized command-log SHA-256",
            trust_policy.command_log_normalized_sha256,
            SHA256_RE,
        ),
    ):
        if not pattern.fullmatch(value):
            raise ValueError(f"package trust policy has invalid {label}")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", trust_policy.receipt_date):
        raise ValueError("package trust policy has invalid receipt date")
    if (
        not trust_policy.receipt_worktree.startswith("/")
        or re.search(r"\s", trust_policy.receipt_worktree)
    ):
        raise ValueError("package trust policy has invalid receipt worktree")
    if (
        not trust_policy.receipt_branch
        or re.search(r"\s", trust_policy.receipt_branch)
    ):
        raise ValueError("package trust policy has invalid receipt branch")

    evidence: dict[str, str] = {}
    for name, value in trust_policy.evidence_artifact_sha256:
        if (
            name != Path(name).name
            or name in evidence
            or not SHA256_RE.fullmatch(value)
        ):
            raise ValueError(
                "package trust policy has an invalid or duplicate evidence "
                f"artifact entry: {name!r}"
            )
        evidence[name] = value
    expected = set(REQUIRED_EVIDENCE_ARTIFACTS)
    if set(evidence) != expected:
        raise ValueError(
            "package trust policy evidence coverage differs from required "
            "artifacts; missing="
            + "|".join(sorted(expected - set(evidence)))
            + "; unexpected="
            + "|".join(sorted(set(evidence) - expected))
        )
    return evidence


def trust_policy_fingerprint(trust_policy: PackageTrustPolicy) -> str:
    evidence = validate_trust_policy(trust_policy)
    rows = [
        ("base_commit", trust_policy.base_commit),
        (
            "authorized_contract_commit",
            trust_policy.authorized_contract_commit,
        ),
        (
            "evidence_generator_commit",
            trust_policy.evidence_generator_commit,
        ),
        ("receipt_date", trust_policy.receipt_date),
        ("receipt_worktree", trust_policy.receipt_worktree),
        ("receipt_branch", trust_policy.receipt_branch),
        (
            "command_log_normalized_sha256",
            trust_policy.command_log_normalized_sha256,
        ),
        (
            "decision_register_sha256",
            trust_policy.decision_register_sha256,
        ),
        (
            "source_input_manifest_sha256",
            trust_policy.source_input_manifest_sha256,
        ),
        *(
            (f"evidence_artifact:{name}", evidence[name])
            for name in sorted(evidence, key=lambda value: (value.casefold(), value))
        ),
    ]
    return _hash_fields(rows)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig", errors="strict") as handle:
        return list(csv.DictReader(handle))


def write_csv(
    path: Path,
    fields: Iterable[str],
    rows: Iterable[dict[str, object]],
) -> None:
    selected = list(fields)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=selected,
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(
            {field: row.get(field, "") for field in selected}
            for row in rows
        )


def git_bytes(repo_root: Path, *args: str) -> bytes:
    result = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.returncode:
        message = result.stderr.decode("utf-8", errors="replace").strip()
        raise ValueError(f"git {' '.join(args)} failed: {message}")
    return result.stdout


def resolve_commit(repo_root: Path, ref: str) -> str:
    return git_bytes(repo_root, "rev-parse", "--verify", f"{ref}^{{commit}}").decode(
        "ascii"
    ).strip()


def git_is_ancestor(
    repo_root: Path,
    ancestor: str,
    descendant: str,
) -> bool:
    result = subprocess.run(
        ["git", "merge-base", "--is-ancestor", ancestor, descendant],
        cwd=repo_root,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )
    if result.returncode == 0:
        return True
    if result.returncode == 1:
        return False
    raise ValueError(
        "git merge-base --is-ancestor failed: "
        + result.stderr.decode("utf-8", errors="replace").strip()
    )


def git_blob(
    repo_root: Path,
    commit: str,
    relative_path: str,
) -> bytes | None:
    result = subprocess.run(
        ["git", "show", f"{commit}:{relative_path}"],
        cwd=repo_root,
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.returncode == 0:
        return result.stdout
    missing = subprocess.run(
        ["git", "cat-file", "-e", f"{commit}:{relative_path}"],
        cwd=repo_root,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if missing.returncode:
        return None
    raise ValueError(
        f"unable to read Git blob {commit}:{relative_path}: "
        + result.stderr.decode("utf-8", errors="replace").strip()
    )


def git_contract_paths(repo_root: Path, commit: str) -> set[str]:
    output = git_bytes(
        repo_root,
        "ls-tree",
        "-r",
        "--name-only",
        commit,
        "--",
        "contracts",
    ).decode("utf-8", errors="strict")
    return {
        path
        for path in output.splitlines()
        if Path(path).suffix.casefold() in {".csv", ".toml"}
    }


def sha256_bytes(value: bytes | None) -> str:
    return hashlib.sha256(value).hexdigest() if value is not None else ""


def package_trust_issues(
    *,
    repo_root: Path,
    out_dir: Path,
    requested_base_commit: str,
    requested_authorized_commit: str,
    head_commit: str,
    trust_policy: PackageTrustPolicy,
    input_rows: list[dict[str, object]],
) -> list[str]:
    evidence_hashes = validate_trust_policy(trust_policy)
    issues: list[str] = []
    if requested_base_commit != trust_policy.base_commit:
        issues.append(
            "trusted base commit mismatch: requested "
            f"{requested_base_commit}, pinned {trust_policy.base_commit}"
        )
    if requested_authorized_commit != trust_policy.authorized_contract_commit:
        issues.append(
            "trusted authorized contract commit mismatch: requested "
            f"{requested_authorized_commit}, pinned "
            f"{trust_policy.authorized_contract_commit}"
        )

    trusted_base = resolve_commit(repo_root, trust_policy.base_commit)
    trusted_authorized = resolve_commit(
        repo_root,
        trust_policy.authorized_contract_commit,
    )
    trusted_evidence_generator = resolve_commit(
        repo_root,
        trust_policy.evidence_generator_commit,
    )
    if trusted_base != trust_policy.base_commit:
        issues.append(
            "trusted base commit did not resolve to its pinned full identity"
        )
    if trusted_authorized != trust_policy.authorized_contract_commit:
        issues.append(
            "trusted authorized contract commit did not resolve to its pinned "
            "full identity"
        )
    if trusted_evidence_generator != trust_policy.evidence_generator_commit:
        issues.append(
            "trusted evidence generator commit did not resolve to its pinned "
            "full identity"
        )
    if not git_is_ancestor(repo_root, trusted_base, trusted_authorized):
        issues.append(
            "trusted base commit is not an ancestor of the trusted authorized "
            "contract commit"
        )
    if not git_is_ancestor(repo_root, trusted_authorized, head_commit):
        issues.append(
            "trusted authorized contract commit is not an ancestor of HEAD"
        )
    if not git_is_ancestor(
        repo_root,
        trusted_authorized,
        trusted_evidence_generator,
    ):
        issues.append(
            "trusted authorized contract commit is not an ancestor of the "
            "trusted evidence generator commit"
        )
    if not git_is_ancestor(
        repo_root,
        trusted_evidence_generator,
        head_commit,
    ):
        issues.append(
            "trusted evidence generator commit is not an ancestor of HEAD"
        )
    for relative in EVIDENCE_GENERATOR_INPUTS:
        trusted_bytes = git_blob(
            repo_root,
            trusted_evidence_generator,
            relative,
        )
        current_path = repo_root / relative
        if (
            trusted_bytes is None
            or not current_path.is_file()
            or current_path.read_bytes() != trusted_bytes
        ):
            issues.append(
                "trusted evidence generator input mismatch: "
                f"{relative} differs from {trusted_evidence_generator}"
            )

    decision_path = repo_root / "contracts" / "b03_b04_decisions.csv"
    observed_decision_hash = digest(decision_path)
    if observed_decision_hash != trust_policy.decision_register_sha256:
        issues.append(
            "trusted decision register hash mismatch: worktree "
            f"{observed_decision_hash}, pinned "
            f"{trust_policy.decision_register_sha256}"
        )
    authorized_decisions = git_blob(
        repo_root,
        trusted_authorized,
        "contracts/b03_b04_decisions.csv",
    )
    authorized_decision_hash = sha256_bytes(authorized_decisions)
    if authorized_decision_hash != trust_policy.decision_register_sha256:
        issues.append(
            "trusted decision register hash mismatch: authorized snapshot "
            f"{authorized_decision_hash or '<missing>'}, pinned "
            f"{trust_policy.decision_register_sha256}"
        )

    for name in REQUIRED_EVIDENCE_ARTIFACTS:
        observed = digest(out_dir / name)
        expected = evidence_hashes[name]
        if observed != expected:
            issues.append(
                "trusted evidence artifact hash mismatch: "
                f"{name} observed {observed}, pinned {expected}"
            )

    observed_input_fingerprint = trusted_input_fingerprint(input_rows)
    if observed_input_fingerprint != trust_policy.source_input_manifest_sha256:
        issues.append(
            "trusted source-input manifest hash mismatch: observed "
            f"{observed_input_fingerprint}, pinned "
            f"{trust_policy.source_input_manifest_sha256}"
        )
    return issues


def authorized_panel_spec_change(
    base: bytes | None,
    current: bytes | None,
) -> bool:
    if base is None or current is None:
        return False
    try:
        base_spec = tomllib.loads(base.decode("utf-8", errors="strict"))
        current_spec = tomllib.loads(current.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, tomllib.TOMLDecodeError):
        return False
    expected = deepcopy(base_spec)
    inputs = expected.get("inputs")
    dictionary = expected.get("artifacts", {}).get("dictionary")
    if not isinstance(inputs, dict) or not isinstance(dictionary, dict):
        return False
    if (
        "source_metadata_aliases" in inputs
        or "reviewed_b03_b04_decisions" in inputs
    ):
        return False
    required = dictionary.get("required_columns")
    if (
        not isinstance(required, list)
        or "source_metadata_year" not in required
        or "metadata_file_number" in required
    ):
        return False
    inputs["source_metadata_aliases"] = "contracts/source_metadata_aliases.csv"
    inputs["reviewed_b03_b04_decisions"] = "contracts/b03_b04_decisions.csv"
    insert_at = required.index("source_metadata_year") + 1
    required.insert(insert_at, "metadata_file_number")
    return current_spec == expected


def relative_path(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise ValueError(f"{path} is outside declared source root {root}") from exc


def file_input_row(
    *,
    source_scope: str,
    year: str,
    logical_identity: str,
    source_root: Path | str,
    path: Path,
    relative_to_root: Path | None,
    expected_sha256: str = "",
    verification_status: str = "hashed",
    purpose: str,
) -> dict[str, object]:
    if not path.is_file():
        raise ValueError(f"missing {source_scope} input: {path}")
    actual = digest(path)
    expected = expected_sha256.strip().casefold()
    if expected:
        if not SHA256_RE.fullmatch(expected):
            raise ValueError(
                f"{logical_identity}: invalid expected SHA-256 {expected_sha256!r}"
            )
        if actual != expected:
            raise ValueError(
                f"{logical_identity}: source CSV SHA-256 mismatch: "
                f"expected {expected}, observed {actual}"
            )
    return {
        "source_scope": source_scope,
        "year": year,
        "logical_identity": logical_identity,
        "source_root": str(source_root),
        "path": (
            relative_path(path, relative_to_root)
            if relative_to_root is not None
            else str(path.resolve())
        ),
        "byte_size": path.stat().st_size,
        "sha256": actual,
        "expected_sha256": expected,
        "verification_status": verification_status,
        "purpose": purpose,
    }


def exact_database_path(year_dir: Path, database_identity: str) -> Path:
    identity_text = database_identity.strip()
    if (
        not identity_text
        or identity_text in {".", ".."}
        or "/" in identity_text
        or "\\" in identity_text
        or "\x00" in identity_text
        or Path(identity_text).name != identity_text
    ):
        raise ValueError(
            f"{year_dir.name}: Access database identity must be a basename: "
            f"{database_identity!r}"
        )
    extracted_root = year_dir / "extracted_db"
    if year_dir.is_symlink() or extracted_root.is_symlink():
        raise ValueError(
            f"{year_dir.name}: Access database root cannot be a symlink"
        )
    if not extracted_root.is_dir():
        raise ValueError(
            f"{year_dir.name}: Access database root is unavailable: {extracted_root}"
        )
    resolved_root = extracted_root.resolve(strict=True)
    matches: list[Path] = []
    entries = sorted(
        extracted_root.rglob("*"),
        key=lambda path: (path.as_posix().casefold(), path.as_posix()),
    )
    for candidate in entries:
        if candidate.is_symlink():
            raise ValueError(
                f"{year_dir.name}: Access database tree contains a symlink: "
                f"{candidate}"
            )
        resolved_candidate = candidate.resolve(strict=True)
        try:
            resolved_candidate.relative_to(resolved_root)
        except ValueError as exc:
            raise ValueError(
                f"{year_dir.name}: Access database path escapes extracted_db: "
                f"{candidate}"
            ) from exc
        if (
            candidate.is_file()
            and candidate.name.casefold() == identity_text.casefold()
        ):
            matches.append(candidate)
    if not matches:
        raise ValueError(
            f"{year_dir.name}: Access database {database_identity!r} is unavailable"
        )
    if len(matches) > 1:
        joined = "|".join(str(path) for path in matches)
        raise ValueError(
            f"{year_dir.name}: Access database identity is ambiguous: {joined}"
        )
    return matches[0]


def assert_generator_inputs_match_head(
    repo_root: Path,
    head_commit: str,
) -> None:
    for relative in GENERATOR_INPUTS:
        path = repo_root / relative
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"generator input is missing or a symlink: {relative}")
        head_bytes = git_blob(repo_root, head_commit, relative)
        if head_bytes is None or path.read_bytes() != head_bytes:
            raise ValueError(
                f"generator input differs from HEAD {head_commit}: {relative}"
            )


def metadata_scope(path: Path) -> str | None:
    name = path.name.casefold()
    if re.fullmatch(r"vartable.*\.csv", name):
        return "vartable_metadata"
    if re.fullmatch(r"tables.*\.csv", name):
        return "tables_metadata"
    if re.fullmatch(r"filenames\d{2}\.csv", name):
        return "filenames_metadata"
    return None


def build_input_manifest_rows(
    *,
    repo_root: Path,
    legacy_root: Path,
    schema_tool_path: Path | None,
    table_evidence: list[dict[str, str]],
) -> tuple[
    list[dict[str, object]],
    list[dict[str, str]],
    dict[tuple[str, str], tuple[str, ...]],
]:
    raw_root = legacy_root / "Raw_Access_Databases"
    if not raw_root.is_dir():
        raise ValueError(f"missing raw Access root: {raw_root}")

    database_hashes_by_year: dict[str, set[str]] = defaultdict(set)
    for row in table_evidence:
        value = row.get("source_database_sha256", "").strip().casefold()
        if value:
            if not SHA256_RE.fullmatch(value):
                raise ValueError(
                    f"{row.get('year')}:{row.get('access_table_name')}: "
                    "invalid source_database_sha256"
                )
            database_hashes_by_year[row.get("year", "")].add(value)

    manifest_rows: list[dict[str, object]] = []
    inventory_rows: list[dict[str, str]] = []
    source_headers: dict[tuple[str, str], tuple[str, ...]] = {}
    seen_table_identities: set[tuple[str, str]] = set()
    year_dirs = sorted(
        (
            path
            for path in raw_root.iterdir()
            if path.is_dir() and re.fullmatch(r"20\d{2}", path.name)
        ),
        key=lambda path: path.name,
    )
    if not year_dirs:
        raise ValueError(f"no annual raw-input directories found under {raw_root}")

    for year_dir in year_dirs:
        year = year_dir.name
        inventory_path = year_dir / "metadata" / "table_inventory.csv"
        annual_inventory = read_csv(inventory_path)
        manifest_rows.append(
            file_input_row(
                source_scope="annual_inventory",
                year=year,
                logical_identity=f"{year}:table_inventory",
                source_root=legacy_root,
                path=inventory_path,
                relative_to_root=legacy_root,
                verification_status="hashed",
                purpose="Annual exported-table inventory used by the evidence generator.",
            )
        )
        database_identities: set[str] = set()
        for row in annual_inventory:
            row_year = row.get("year", "").strip()
            table = row.get("table_name", "").strip()
            if row_year != year or not table:
                raise ValueError(
                    f"{inventory_path}: invalid inventory identity {row_year}:{table}"
                )
            identity = (year, table.casefold())
            if identity in seen_table_identities:
                raise ValueError(f"duplicate annual table identity: {year}:{table}")
            seen_table_identities.add(identity)
            source_relative = row.get("csv_path", "").strip()
            if not source_relative:
                raise ValueError(f"{year}:{table}: inventory csv_path is blank")
            source_path = (year_dir / source_relative).resolve()
            relative_path(source_path, year_dir)
            expected = row.get("csv_sha256", "").strip().casefold()
            with source_path.open(
                newline="",
                encoding="utf-8-sig",
                errors="strict",
            ) as handle:
                header = next(csv.reader(handle), [])
            expected_column_count = as_int(
                row.get("column_count", ""),
                f"{year}:{table}",
            )
            if len(header) != expected_column_count:
                raise ValueError(
                    f"{year}:{table}: source header count {len(header)} != "
                    f"inventory column_count {expected_column_count}"
                )
            if (
                any(not column.strip() for column in header)
                or len({column.casefold() for column in header}) != len(header)
            ):
                raise ValueError(
                    f"{year}:{table}: source header is blank or case-colliding"
                )
            source_headers[identity] = tuple(header)
            manifest_rows.append(
                file_input_row(
                    source_scope="source_table_csv",
                    year=year,
                    logical_identity=f"{year}:{table}",
                    source_root=legacy_root,
                    path=source_path,
                    relative_to_root=legacy_root,
                    expected_sha256=expected,
                    verification_status="verified_expected_sha256",
                    purpose="Exact exported Access table profiled for B03/B04 evidence.",
                )
            )
            database_identity = row.get("access_db_file", "").strip()
            if database_identity:
                database_identities.add(database_identity)
            inventory_rows.append(dict(row))

        if len(database_identities) != 1:
            raise ValueError(
                f"{year}: expected one annual access_db_file identity, observed "
                + "|".join(sorted(database_identities))
            )
        database_identity = next(iter(database_identities))
        database_path = exact_database_path(year_dir, database_identity)
        evidence_hashes = database_hashes_by_year.get(year, set())
        if len(evidence_hashes) > 1:
            raise ValueError(
                f"{year}: generated table evidence names multiple database hashes"
            )
        expected_database_hash = (
            next(iter(evidence_hashes)) if evidence_hashes else ""
        )
        database_row = file_input_row(
            source_scope="access_schema_input_database",
            year=year,
            logical_identity=f"{year}:{database_identity}",
            source_root=legacy_root,
            path=database_path,
            relative_to_root=legacy_root,
            expected_sha256="",
            verification_status=(
                "verified_against_generated_evidence"
                if expected_database_hash
                else "hashed_without_generated_schema_binding"
            ),
            purpose="Annual Access database supplied to the read-only schema probe.",
        )
        if (
            expected_database_hash
            and database_row["sha256"] != expected_database_hash
        ):
            raise ValueError(
                f"{year}: Access database SHA-256 differs from generated evidence: "
                f"expected {expected_database_hash}, observed {database_row['sha256']}"
            )
        database_row["expected_sha256"] = expected_database_hash
        manifest_rows.append(database_row)

        tables_dir = year_dir / "tables_csv"
        for metadata_path in sorted(
            (path for path in tables_dir.iterdir() if path.is_file()),
            key=lambda path: (path.name.casefold(), path.name),
        ):
            scope = metadata_scope(metadata_path)
            if scope is None:
                continue
            manifest_rows.append(
                file_input_row(
                    source_scope=scope,
                    year=year,
                    logical_identity=f"{year}:{metadata_path.stem}",
                    source_root=legacy_root,
                    path=metadata_path,
                    relative_to_root=legacy_root,
                    verification_status="hashed",
                    purpose={
                        "vartable_metadata": "Exact annual source-column metadata.",
                        "tables_metadata": "Exact annual Access table catalog metadata.",
                        "filenames_metadata": "Exact annual file/grain metadata.",
                    }[scope],
                )
            )

    for relative in GENERATOR_INPUTS:
        manifest_rows.append(
            file_input_row(
                source_scope="generator",
                year="",
                logical_identity=relative,
                source_root=repo_root,
                path=repo_root / relative,
                relative_to_root=repo_root,
                verification_status="hashed",
                purpose="B03/B04 evidence or package generator implementation.",
            )
        )
    for relative in CANONICAL_B03_B04_CONTRACTS:
        manifest_rows.append(
            file_input_row(
                source_scope="canonical_contract",
                year="",
                logical_identity=relative,
                source_root=repo_root,
                path=repo_root / relative,
                relative_to_root=repo_root,
                verification_status="hashed",
                purpose="Canonical reviewed B03/B04 decision input.",
            )
        )
    prerequisite = repo_root / "contracts" / "dictionary_ambiguity_overrides.csv"
    if prerequisite.is_file():
        manifest_rows.append(
            file_input_row(
                source_scope="reviewed_prerequisite_contract",
                year="",
                logical_identity="contracts/dictionary_ambiguity_overrides.csv",
                source_root=repo_root,
                path=prerequisite,
                relative_to_root=repo_root,
                verification_status="hashed",
                purpose="Previously reviewed B02 identities consumed by B04 enrichment.",
            )
        )

    tool = schema_tool_path
    if tool is None:
        discovered = shutil.which("mdb-schema")
        tool = Path(discovered) if discovered else None
    if tool is not None:
        manifest_rows.append(
            file_input_row(
                source_scope="schema_tool",
                year="",
                logical_identity="mdb-schema",
                source_root="system",
                path=tool,
                relative_to_root=None,
                verification_status="hashed",
                purpose="Read-only Access schema/index extraction executable.",
            )
        )

    manifest_rows.sort(
        key=lambda row: (
            str(row["source_scope"]),
            str(row["year"]),
            str(row["path"]).casefold(),
            str(row["logical_identity"]).casefold(),
        )
    )
    return manifest_rows, inventory_rows, source_headers


def build_canonical_comparison(
    *,
    repo_root: Path,
    base_commit: str,
    authorized_commit: str,
    head_commit: str,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    contracts_root = repo_root / "contracts"
    if contracts_root.is_symlink() or not contracts_root.is_dir():
        raise ValueError("contracts root is missing or a symlink")
    worktree_paths: set[str] = set()
    for path in contracts_root.rglob("*"):
        if path.suffix.casefold() not in {".csv", ".toml"}:
            continue
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"canonical contract is not a regular file: {path}")
        worktree_paths.add(path.relative_to(repo_root).as_posix())
    canonical_paths = sorted(
        worktree_paths
        | git_contract_paths(repo_root, base_commit)
        | git_contract_paths(repo_root, authorized_commit)
        | git_contract_paths(repo_root, head_commit),
        key=lambda path: (path.casefold(), path),
    )
    for relative in canonical_paths:
        current_path = repo_root / relative
        base = git_blob(repo_root, base_commit, relative)
        authorized = git_blob(repo_root, authorized_commit, relative)
        head = git_blob(repo_root, head_commit, relative)
        worktree = current_path.read_bytes() if current_path.is_file() else None
        changed_from_base = base is None or worktree != base
        matches_authorized = worktree == authorized
        if not matches_authorized:
            classification = "unexpected_change"
        elif not changed_from_base:
            classification = "unchanged"
        elif relative in PRIOR_REVIEWED_B01_B02_CONTRACTS:
            classification = "prior_reviewed_B01_B02"
        elif relative in CANONICAL_B03_B04_CONTRACTS:
            classification = "authorized_B03_B04"
        elif (
            relative in AUTHORIZED_B03_B04_RUNTIME_SUPPORT_CONTRACTS
            and authorized_panel_spec_change(base, worktree)
        ):
            classification = "authorized_B03_B04_runtime_support"
        else:
            classification = "unexpected_change"
        rows.append(
            {
                "path": relative,
                "base_commit": base_commit,
                "base_exists": str(base is not None).lower(),
                "base_sha256": sha256_bytes(base),
                "authorized_commit": authorized_commit,
                "authorized_exists": str(authorized is not None).lower(),
                "authorized_sha256": sha256_bytes(authorized),
                "head_commit": head_commit,
                "head_exists": str(head is not None).lower(),
                "head_sha256": sha256_bytes(head),
                "worktree_exists": str(worktree is not None).lower(),
                "worktree_sha256": sha256_bytes(worktree),
                "unchanged_from_base": str(
                    base is not None and worktree == base
                ).lower(),
                "matches_authorized": str(matches_authorized).lower(),
                "matches_head": str(worktree == head).lower(),
                "change_classification": classification,
            }
        )
    return rows


def as_int(value: str, identity: str) -> int:
    try:
        return int(value or "0")
    except ValueError as exc:
        raise ValueError(f"{identity}: invalid integer {value!r}") from exc


def normalized_boolean(value: str) -> bool | None:
    normalized = value.strip().casefold()
    if normalized == "true":
        return True
    if normalized == "false":
        return False
    return None


def zero_row_observational_boundaries(
    table_rows: list[dict[str, str]],
) -> list[dict[str, str]]:
    return sorted(
        (
            row
            for row in table_rows
            if row.get("table_role", "").casefold() == "data"
            and (
                row.get("zero_row_table", "").casefold() == "true"
                or as_int(
                    row.get("row_count", ""),
                    f"{row.get('year')}:{row.get('access_table_name')}",
                )
                == 0
            )
        ),
        key=lambda row: (row.get("year", ""), row.get("access_table_name", "")),
    )


def decision_contract_issues(
    *,
    decisions: list[dict[str, str]],
    table_grain_rows: list[dict[str, str]],
    source_column_rows: list[dict[str, str]],
    source_alias_rows: list[dict[str, str]],
) -> tuple[list[str], list[str], set[str]]:
    b03_issues: list[str] = []
    b04_issues: list[str] = []
    decision_by_id: dict[str, dict[str, str]] = {}
    for row in decisions:
        decision_id = row.get("decision_id", "").strip()
        if not decision_id or decision_id in decision_by_id:
            target = b03_issues if decision_id.startswith("B03-") else b04_issues
            target.append(
                f"decision register has blank or duplicate ID {decision_id!r}"
            )
            continue
        decision_by_id[decision_id] = row

    supported_targets: dict[str, str] = {}
    expected_counts: dict[str, int] = {}
    for decision_id, row in decision_by_id.items():
        if row.get("decision", "").strip() == "request_more_evidence":
            continue
        if decision_id.startswith("B03-"):
            target = "table_grain"
        elif decision_id.startswith("B04-"):
            target = (
                "source_metadata_aliases"
                if row.get("decision", "").strip()
                == "approve_controlled_crosswalk"
                else "source_columns"
            )
        else:
            b04_issues.append(
                f"supported decision has unknown subsystem: {decision_id}"
            )
            continue
        supported_targets[decision_id] = target
        try:
            expected_counts[decision_id] = int(
                row.get("affected_year_table_column_rows", "")
            )
        except ValueError:
            target_issues = b03_issues if target == "table_grain" else b04_issues
            target_issues.append(
                f"{decision_id} has invalid affected row count"
            )

    contracts = {
        "table_grain": table_grain_rows,
        "source_columns": source_column_rows,
        "source_metadata_aliases": source_alias_rows,
    }
    applied_ids: set[str] = set()
    observed: dict[str, Counter[str]] = {}
    for contract_name, rows in contracts.items():
        counts = Counter(row.get("decision_id", "").strip() for row in rows)
        observed[contract_name] = counts
        for decision_id, count in counts.items():
            if not decision_id:
                target_issues = (
                    b03_issues
                    if contract_name == "table_grain"
                    else b04_issues
                )
                target_issues.append(
                    f"{contract_name} contains {count} blank decision IDs"
                )
                continue
            applied_ids.add(decision_id)
            expected_target = supported_targets.get(decision_id)
            target_issues = (
                b03_issues
                if decision_id.startswith("B03-")
                or contract_name == "table_grain"
                else b04_issues
            )
            if expected_target != contract_name:
                target_issues.append(
                    f"{decision_id} is in wrong destination contract "
                    f"{contract_name}; expected {expected_target or '<none>'}"
                )
                continue
            expected_count = expected_counts.get(decision_id)
            if expected_count is None or count != expected_count:
                target_issues.append(
                    f"{decision_id} row count {count} != reviewed count "
                    f"{expected_count if expected_count is not None else '<invalid>'}"
                )

    for decision_id, contract_name in supported_targets.items():
        if observed[contract_name].get(decision_id, 0) == 0:
            target_issues = (
                b03_issues if contract_name == "table_grain" else b04_issues
            )
            target_issues.append(
                f"{decision_id} is absent from reviewed destination "
                f"{contract_name}"
            )
    return b03_issues, b04_issues, applied_ids


def reviewed_source_role_index(
    rows: list[dict[str, str]],
) -> tuple[
    dict[tuple[str, str, str], dict[str, str]],
    list[str],
]:
    index: dict[tuple[str, str, str], dict[str, str]] = {}
    issues: list[str] = []
    for row in rows:
        decision_id = row.get("decision_id", "").strip()
        table = row.get("access_table_pattern", "").strip()
        column = row.get("column_name", "").strip()
        canonical_role = row.get("role", "").strip().casefold()
        candidate_role = CANONICAL_TO_CANDIDATE_ROLE.get(canonical_role)
        if candidate_role is None:
            issues.append(
                f"{decision_id or '<blank>'} has unsupported canonical source role "
                f"{canonical_role!r}"
            )
            continue
        if not decision_id or not table or not column:
            issues.append("source role contract has a blank exact identity")
            continue
        if any(token in table for token in "*?[]"):
            issues.append(
                f"{decision_id} does not use an exact Access table identity"
            )
            continue
        if "reviewed" in row and row.get("reviewed", "").casefold() != "true":
            issues.append(f"{decision_id} source role is not marked reviewed")
            continue
        try:
            year_start = int(row.get("year_start", ""))
            year_end = int(row.get("year_end", ""))
        except ValueError:
            issues.append(f"{decision_id} has invalid reviewed role year bounds")
            continue
        if year_start > year_end or year_end - year_start > 100:
            issues.append(f"{decision_id} has invalid reviewed role year range")
            continue
        for year in range(year_start, year_end + 1):
            key = (str(year), table.casefold(), column.casefold())
            if key in index:
                issues.append(
                    f"reviewed source role identity is ambiguous: "
                    f"{year}:{table}.{column}"
                )
                continue
            indexed = dict(row)
            indexed["_candidate_role"] = candidate_role
            index[key] = indexed
    return index, issues


def validate_command_log(
    path: Path,
    head_commit: str,
    supported_decision_count: int,
    request_more_evidence_count: int,
    trust_policy: PackageTrustPolicy,
) -> dict[str, str]:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"command log is missing or a symlink: {path}")
    try:
        text = path.read_bytes().decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise ValueError("command log is not valid UTF-8") from exc
    if not text.strip() or not text.isascii():
        raise ValueError("command log must be nonempty ASCII text")
    observed_receipt_hash = normalized_command_log_digest(text)
    if observed_receipt_hash != trust_policy.command_log_normalized_sha256:
        raise ValueError(
            "command log normalized SHA-256 does not match the trusted "
            "receipt; observed "
            f"{observed_receipt_hash}, pinned "
            f"{trust_policy.command_log_normalized_sha256}"
        )

    lines = text.splitlines()
    title = "B03/B04 AUTHOR-DECISION APPLICATION AND EVIDENCE COMMAND LOG"
    if not lines or lines[0] != title:
        raise ValueError("command log has an invalid title")
    expected_headers = {
        "date": f"Date: {trust_policy.receipt_date}",
        "worktree": f"Worktree: {trust_policy.receipt_worktree}",
        "branch": f"Branch: {trust_policy.receipt_branch}",
        "final package head": f"Final package head: {head_commit}",
        "evidence generator implementation head": (
            "Evidence-generator implementation head: "
            f"{trust_policy.evidence_generator_commit}"
        ),
        "authorized canonical snapshot": (
            "Authorized canonical snapshot: "
            f"{trust_policy.authorized_contract_commit}"
        ),
    }
    observed_headers: dict[str, list[str]] = defaultdict(list)
    for line in lines:
        match = re.match(r"^\s*([^:]+?)\s*:", line)
        if match is None:
            continue
        label = re.sub(
            r"[\s_-]+",
            " ",
            match.group(1).casefold(),
        ).strip()
        if label in expected_headers:
            observed_headers[label].append(line)
    for label, expected in expected_headers.items():
        observed = observed_headers.get(label, [])
        if observed != [expected]:
            raise ValueError(
                f"command log must contain exactly one exact {label}"
            )

    sections = (
        "BOUNDARY",
        "DECISION APPLICATION PROOF",
        "BOUNDED EVIDENCE GENERATION, PASS A",
        "BOUNDED EVIDENCE GENERATION, PASS B",
        "DETERMINISM COMPARISON",
        "FOCUSED B03/B04 SUITE",
        "FULL TEST SUITE",
        "CANONICAL VALIDATOR",
        "WHITESPACE CHECK",
        "INDEPENDENT CODE AND INVARIANT REVIEWS",
        "FINAL EVIDENCE COUNTS",
        "FINAL STATUS",
    )
    section_positions: list[int] = []
    for section in sections:
        positions = [index for index, line in enumerate(lines) if line == section]
        if len(positions) != 1:
            raise ValueError(
                f"command log section {section!r} occurs {len(positions)} times"
            )
        section_positions.append(positions[0])
    if section_positions != sorted(section_positions):
        raise ValueError("command log sections are out of order")
    section_bodies = {
        section: lines[
            section_positions[index] + 1 : (
                section_positions[index + 1]
                if index + 1 < len(sections)
                else len(lines)
            )
        ]
        for index, section in enumerate(sections)
    }

    boundary = (
        "Stage 02 extraction was not run.",
        "The full 2004-2023 pipeline was not run.",
        "No panel-ready or release-ready status was asserted.",
        "Countersigned supported decisions applied: "
        f"{supported_decision_count}.",
        "Request_more_evidence decisions remaining unresolved: "
        f"{request_more_evidence_count}.",
    )
    observed_boundary = tuple(
        line for line in section_bodies["BOUNDARY"] if line.strip()
    )
    if observed_boundary != boundary:
        raise ValueError("command log boundary section is not exact")

    command_sections = {
        "DECISION APPLICATION PROOF",
        "BOUNDED EVIDENCE GENERATION, PASS A",
        "BOUNDED EVIDENCE GENERATION, PASS B",
        "DETERMINISM COMPARISON",
        "FOCUSED B03/B04 SUITE",
        "FULL TEST SUITE",
        "CANONICAL VALIDATOR",
        "WHITESPACE CHECK",
    }
    command_marker = re.compile(r"^\s*command\s*:\s*$", re.IGNORECASE)
    exit_marker = re.compile(
        r"^\s*exit[\s_-]+code\b.*$",
        re.IGNORECASE,
    )
    successful_exit = re.compile(
        r"^\s*exit[\s_-]+code\s*:\s*0\s*$",
        re.IGNORECASE,
    )
    for section, body in section_bodies.items():
        command_positions = [
            index
            for index, line in enumerate(body)
            if command_marker.fullmatch(line)
        ]
        exit_lines = [
            (index, line)
            for index, line in enumerate(body)
            if exit_marker.fullmatch(line)
        ]
        if section in command_sections:
            if (
                len(command_positions) != 1
                or len(exit_lines) != 1
                or not successful_exit.fullmatch(exit_lines[0][1])
            ):
                raise ValueError(
                    f"command log section {section!r} must contain one "
                    "successful command receipt"
                )
            command_index = command_positions[0]
            exit_index = exit_lines[0][0]
            command_lines = body[command_index + 1 : exit_index]
            if (
                exit_index <= command_index + 1
                or not any(
                    line.startswith((" ", "\t")) and line.strip()
                    for line in command_lines
                )
            ):
                raise ValueError(
                    f"command log section {section!r} has no command text"
                )
        elif command_positions or exit_lines:
            raise ValueError(
                f"command log non-command section {section!r} contains a "
                "command receipt"
            )

    final_status = (
        "B03_EVIDENCE_REPAIRED",
        "B04_EVIDENCE_REPAIRED",
        "B03_CONTRACT_UPDATED_BY_AUTHORIZED_DECISION",
        "B04_CONTRACT_UPDATED_BY_AUTHORIZED_DECISIONS",
        "B03_B04_RUNTIME_SUPPORT_UPDATED_BY_AUTHORIZED_DECISIONS",
        "B04_REQUEST_MORE_EVIDENCE_"
        f"{request_more_evidence_count}_UNRESOLVED",
        "FULL_BUILD_NOT_RUN",
        "RELEASE_STILL_BLOCKED",
    )
    observed_final_status = tuple(
        line for line in section_bodies["FINAL STATUS"] if line.strip()
    )
    if observed_final_status != final_status:
        raise ValueError("command log final status section is not exact")

    allowed_claim_lines = {
        title,
        *boundary,
        *final_status,
        *expected_headers.values(),
    }
    for raw_line in lines:
        stripped = raw_line.strip()
        if not stripped or stripped in allowed_claim_lines:
            continue
        raw_normalized = re.sub(
            r"[\s_-]+",
            " ",
            stripped.casefold(),
        ).strip()
        if re.search(r"\bstage\s*0*2\b", raw_normalized):
            raise ValueError(
                "command log contains an additional Stage 02 claim"
            )
        claim_text = re.sub(
            r"(?<!\S)/(?:[^/\s]+/)+\S+",
            "<path>",
            stripped,
        )
        normalized = re.sub(
            r"[\s_-]+",
            " ",
            claim_text.casefold(),
        ).strip()
        words = re.findall(r"[a-z0-9]+", normalized)
        word_set = set(words)
        if "pipeline" in word_set or (
            "full" in word_set and "build" in word_set
        ):
            raise ValueError(
                "command log contains an additional full-build/pipeline claim"
            )
        readiness_positions = [
            index
            for index, word in enumerate(words)
            if word.startswith(("read", "approv", "clear", "confirm"))
        ]
        release_positions = [
            index
            for index, word in enumerate(words)
            if word in {"release", "panel"}
        ]
        if any(
            abs(ready_index - release_index) <= 5
            for ready_index in readiness_positions
            for release_index in release_positions
        ):
            raise ValueError(
                "command log contains an additional release/panel-ready claim"
            )
    return {
        "b03_status": observed_final_status[0],
        "b04_status": observed_final_status[1],
    }


def evidence_status(
    *,
    table_rows: list[dict[str, str]],
    table_exceptions: list[dict[str, str]],
    source_rows: list[dict[str, str]],
    inventory_rows: list[dict[str, str]],
    source_headers: dict[tuple[str, str], tuple[str, ...]],
    decisions: list[dict[str, str]],
    source_role_contract_rows: list[dict[str, str]],
    applied_decision_ids: set[str],
    canonical_matches_head: bool,
    trust_issues: list[str] | None = None,
    unexpected_canonical_changes: list[str] | None = None,
    b03_contract_issues: list[str] | None = None,
    b04_contract_issues: list[str] | None = None,
) -> dict[str, object]:
    b03_issues = [*(b03_contract_issues or ()), *(trust_issues or ())]
    b04_issues = [*(b04_contract_issues or ()), *(trust_issues or ())]
    source_role_index, source_role_contract_issues = (
        reviewed_source_role_index(source_role_contract_rows)
    )
    b04_issues.extend(source_role_contract_issues)
    inventory_by_identity: dict[tuple[str, str], dict[str, str]] = {}
    for row in inventory_rows:
        identity = (
            row.get("year", ""),
            row.get("table_name", "").casefold(),
        )
        if identity in inventory_by_identity:
            b03_issues.append(
                "annual inventories contain duplicate table identity "
                + ":".join(identity)
            )
            b04_issues.append(
                "annual inventories contain duplicate table identity "
                + ":".join(identity)
            )
        inventory_by_identity[identity] = row
    inventory_identities = set(inventory_by_identity)
    table_by_identity: dict[tuple[str, str], dict[str, str]] = {}
    for row in table_rows:
        identity = (
            row.get("year", ""),
            row.get("access_table_name", "").casefold(),
        )
        if identity in table_by_identity:
            b03_issues.append(
                "table evidence contains duplicate identity "
                + ":".join(identity)
            )
        table_by_identity[identity] = row
    table_identities = set(table_by_identity)
    if table_identities != inventory_identities:
        b03_issues.append(
            "table evidence identities do not equal the annual inventories"
        )
    expected_columns = sum(
        as_int(
            row.get("column_count", ""),
            f"{row.get('year')}:{row.get('table_name')}",
        )
        for row in inventory_rows
    )
    if len(source_rows) != expected_columns:
        b04_issues.append(
            f"source-column row count {len(source_rows)} != inventory total "
            f"{expected_columns}"
        )

    required_table_fields = {
        "year",
        "access_table_name",
        "normalized_table_name",
        "table_role",
        "row_count",
        "has_unitid",
        "zero_row_table",
        "source_csv_sha256",
        "source_schema_sha256",
        "source_database_sha256",
    }
    table_fields = set(table_rows[0]) if table_rows else set()
    missing_table_fields = sorted(required_table_fields - table_fields)
    if missing_table_fields:
        b03_issues.append(
            "table evidence missing required fields: "
            + "|".join(missing_table_fields)
        )
    required_source_fields = {
        "year",
        "access_table_name",
        "normalized_table_name",
        "table_role",
        "candidate_table_grain",
        "ordinal_position",
        "column_name",
        "source_csv_sha256",
        "candidate_role",
        "role_decision_id",
    }
    source_fields = set(source_rows[0]) if source_rows else set()
    missing_source_fields = sorted(required_source_fields - source_fields)
    if missing_source_fields:
        b04_issues.append(
            "source-column evidence missing required fields: "
            + "|".join(missing_source_fields)
        )

    table_exception_ids = {
        (row.get("year", ""), row.get("access_table_name", "").casefold())
        for row in table_exceptions
    }
    for row in table_rows:
        identity = f"{row.get('year')}:{row.get('access_table_name')}"
        identity_tuple = (
            row.get("year", ""),
            row.get("access_table_name", "").casefold(),
        )
        inventory_row = inventory_by_identity.get(identity_tuple)
        expected_source_hash = (
            inventory_row.get("csv_sha256", "").strip().casefold()
            if inventory_row is not None
            else ""
        )
        if inventory_row is not None:
            if (
                row.get(
                    "normalized_table_name",
                    "",
                ).strip().casefold()
                != inventory_row.get(
                    "normalized_table_name",
                    "",
                ).strip().casefold()
            ):
                b03_issues.append(
                    f"{identity} normalized_table_name does not match annual "
                    "inventory"
                )
            expected_table_role = INVENTORY_TO_EVIDENCE_TABLE_ROLE.get(
                inventory_row.get("table_role", "").strip().casefold()
            )
            if (
                expected_table_role is None
                or row.get("table_role", "").strip().casefold()
                != expected_table_role
            ):
                b03_issues.append(
                    f"{identity} table_role does not match annual inventory "
                    "taxonomy"
                )
            observed_row_count = as_int(row.get("row_count", ""), identity)
            expected_row_count = as_int(
                inventory_row.get("row_count_csv", ""),
                identity,
            )
            if observed_row_count != expected_row_count:
                b03_issues.append(
                    f"{identity} row_count does not match annual inventory"
                )
            observed_has_unitid = normalized_boolean(
                row.get("has_unitid", "")
            )
            expected_has_unitid = normalized_boolean(
                inventory_row.get("has_unitid", "")
            )
            if (
                observed_has_unitid is None
                or expected_has_unitid is None
                or observed_has_unitid != expected_has_unitid
            ):
                b03_issues.append(
                    f"{identity} has_unitid does not match annual inventory"
                )
            observed_zero = normalized_boolean(
                row.get("zero_row_table", "")
            )
            if (
                observed_zero is None
                or observed_zero != (observed_row_count == 0)
            ):
                b03_issues.append(
                    f"{identity} zero_row_table is inconsistent with row_count"
                )
        observed_source_hash = row.get("source_csv_sha256", "").strip().casefold()
        if (
            not SHA256_RE.fullmatch(observed_source_hash)
            or observed_source_hash != expected_source_hash
        ):
            b03_issues.append(
                f"{identity} source_csv_sha256 does not match annual inventory"
            )
        for field in ("source_schema_sha256", "source_database_sha256"):
            if not SHA256_RE.fullmatch(row.get(field, "").strip().casefold()):
                b03_issues.append(f"{identity} has invalid {field}")
        status = row.get("table_metadata_match_status", "")
        if status not in ALLOWED_METADATA_STATUSES:
            b03_issues.append(f"{identity} has invalid table metadata status")
        is_data = row.get("table_role", "").casefold() == "data"
        is_zero = (
            row.get("zero_row_table", "").casefold() == "true"
            or as_int(row.get("row_count", ""), identity) == 0
        )
        if is_data and is_zero and row.get("candidate_grain") == "scalar":
            b03_issues.append(f"{identity} mechanically treats a zero-row table as scalar")
        if (
            is_data
            and not is_zero
            and row.get("candidate_grain") == "unknown"
            and (row.get("year", ""), row.get("access_table_name", "").casefold())
            not in table_exception_ids
        ):
            b03_issues.append(f"{identity} is unresolved but absent from exceptions")

    source_by_identity: dict[tuple[str, str, str], dict[str, str]] = {}
    source_by_family_identity: dict[
        tuple[str, str, str],
        list[dict[str, str]],
    ] = defaultdict(list)
    source_counts_by_table: Counter[tuple[str, str]] = Counter()
    source_ordinals_by_table: dict[
        tuple[str, str],
        set[int],
    ] = defaultdict(set)
    for row in source_rows:
        table_identity = (
            row.get("year", ""),
            row.get("access_table_name", "").casefold(),
        )
        source_counts_by_table[table_identity] += 1
        identity_tuple = (
            *table_identity,
            row.get("column_name", "").casefold(),
        )
        if identity_tuple in source_by_identity:
            b04_issues.append(
                "duplicate source-column identity "
                + ":".join(identity_tuple)
            )
        source_by_identity[identity_tuple] = row
        source_by_family_identity[
            (
                row.get("year", ""),
                row.get("normalized_table_name", "").casefold(),
                row.get("column_name", "").casefold(),
            )
        ].append(row)
        identity = (
            f"{row.get('year')}:{row.get('access_table_name')}."
            f"{row.get('column_name')}"
        )
        inventory_row = inventory_by_identity.get(table_identity)
        if inventory_row is None:
            b04_issues.append(f"{identity} table is absent from annual inventory")
        else:
            if (
                row.get("normalized_table_name", "").strip().casefold()
                != inventory_row.get(
                    "normalized_table_name",
                    "",
                ).strip().casefold()
            ):
                b04_issues.append(
                    f"{identity} normalized_table_name does not match annual "
                    "inventory"
                )
            expected_table_role = INVENTORY_TO_EVIDENCE_TABLE_ROLE.get(
                inventory_row.get("table_role", "").strip().casefold()
            )
            if (
                expected_table_role is None
                or row.get("table_role", "").strip().casefold()
                != expected_table_role
            ):
                b04_issues.append(
                    f"{identity} table_role does not match annual inventory "
                    "taxonomy"
                )
            table_evidence = table_by_identity.get(table_identity)
            if table_evidence is None:
                b04_issues.append(
                    f"{identity} has no matching table-grain evidence"
                )
            elif (
                row.get("candidate_table_grain", "").strip().casefold()
                != table_evidence.get("candidate_grain", "").strip().casefold()
            ):
                b04_issues.append(
                    f"{identity} candidate_table_grain does not match table "
                    "evidence"
                )
            elif (
                row.get("table_role", "").strip().casefold()
                != table_evidence.get("table_role", "").strip().casefold()
            ):
                b04_issues.append(
                    f"{identity} table_role does not match table evidence"
                )
            expected_source_hash = (
                inventory_row.get("csv_sha256", "").strip().casefold()
            )
            observed_source_hash = (
                row.get("source_csv_sha256", "").strip().casefold()
            )
            if (
                not SHA256_RE.fullmatch(observed_source_hash)
                or observed_source_hash != expected_source_hash
            ):
                b04_issues.append(
                    f"{identity} source_csv_sha256 does not match annual inventory"
                )
            try:
                ordinal = int(row.get("ordinal_position", ""))
            except ValueError:
                ordinal = 0
            header = source_headers.get(table_identity, ())
            if (
                ordinal < 1
                or ordinal > len(header)
                or header[ordinal - 1] != row.get("column_name", "")
                or ordinal in source_ordinals_by_table[table_identity]
            ):
                b04_issues.append(
                    f"{identity} source header/ordinal identity is invalid"
                )
            else:
                source_ordinals_by_table[table_identity].add(ordinal)
        candidate_role = row.get("candidate_role", "").strip()
        if candidate_role not in ALLOWED_CANDIDATE_ROLES:
            b04_issues.append(f"{identity} has invalid candidate role")
        exact_role_contract = source_role_index.get(identity_tuple)
        role_decision_id = row.get("role_decision_id", "").strip()
        exact_role_match = False
        if role_decision_id:
            if exact_role_contract is None:
                b04_issues.append(
                    f"{identity} role decision has no exact reviewed contract "
                    "identity"
                )
            else:
                exact_role_match = (
                    role_decision_id
                    == exact_role_contract.get("decision_id", "").strip()
                    and candidate_role
                    == exact_role_contract.get("_candidate_role", "")
                    and row.get(
                        "normalized_table_name",
                        "",
                    ).strip().casefold()
                    == exact_role_contract.get("source_file", "").strip().casefold()
                )
                if not exact_role_match:
                    b04_issues.append(
                        f"{identity} role decision does not match the exact "
                        "reviewed role contract"
                    )
        elif exact_role_contract is not None:
            b04_issues.append(
                f"{identity} omits its exact reviewed role decision"
            )
        if candidate_role == "intentionally_excluded" and not exact_role_match:
            b04_issues.append(
                f"{identity} intentionally_excluded requires an exact reviewed "
                "role decision"
            )
        status = row.get("column_metadata_match_status", "")
        if status not in ALLOWED_METADATA_STATUSES:
            b04_issues.append(f"{identity} has invalid column metadata status")
        if not row.get("metadata_join_reason", "").strip():
            b04_issues.append(f"{identity} has no metadata join reason")
        if status == "exact":
            required = (
                "matched_file_number",
                "matched_varnumber",
                "matched_varname",
                "matched_metadata_table_name",
                "matched_metadata_source",
            )
            missing = [
                field for field in required if not row.get(field, "").strip()
            ]
            if missing or row.get("matched_metadata_row_count", "") != "1":
                b04_issues.append(
                    f"{identity} exact metadata identity is incomplete"
                )
        if (
            status in {"missing", "multiple"}
            and as_int(row.get("nonempty_count", ""), identity) > 0
            and row.get("candidate_role", "") != "unresolved"
            and not row.get("role_decision_id", "").strip()
        ):
            b04_issues.append(
                f"{identity} unmatched nonempty value lacks an exact reviewed role"
            )

    missing_reviewed_role_identities = set(source_role_index) - set(source_by_identity)
    if missing_reviewed_role_identities:
        b04_issues.append(
            "reviewed source-role identities are absent from source evidence: "
            + "|".join(
                ":".join(identity)
                for identity in sorted(missing_reviewed_role_identities)
            )
        )

    for table_identity, inventory_row in inventory_by_identity.items():
        expected_count = as_int(
            inventory_row.get("column_count", ""),
            ":".join(table_identity),
        )
        observed_count = source_counts_by_table.get(table_identity, 0)
        if observed_count != expected_count:
            b04_issues.append(
                f"{inventory_row.get('year')}:{inventory_row.get('table_name')} "
                f"source-column count {observed_count} != inventory "
                f"column_count {expected_count}"
            )
        expected_ordinals = set(range(1, expected_count + 1))
        if source_ordinals_by_table.get(table_identity, set()) != expected_ordinals:
            b04_issues.append(
                f"{inventory_row.get('year')}:{inventory_row.get('table_name')} "
                "source header/ordinal identity coverage is incomplete"
            )

    supported_by_subsystem: dict[str, set[str]] = {
        "B03": set(),
        "B04": set(),
    }
    blocked_rows: list[dict[str, str]] = []
    for row in decisions:
        decision_id = row.get("decision_id", "").strip()
        subsystem = "B03" if decision_id.startswith("B03-") else (
            "B04" if decision_id.startswith("B04-") else ""
        )
        if not subsystem or not decision_id:
            continue
        if row.get("decision", "").strip() == "request_more_evidence":
            blocked_rows.append(row)
        else:
            supported_by_subsystem[subsystem].add(decision_id)

    missing_b03 = supported_by_subsystem["B03"] - applied_decision_ids
    missing_b04 = supported_by_subsystem["B04"] - applied_decision_ids
    if missing_b03:
        b03_issues.append(
            "supported decisions absent from canonical contracts: "
            + "|".join(sorted(missing_b03))
        )
    if missing_b04:
        b04_issues.append(
            "supported decisions absent from canonical contracts: "
            + "|".join(sorted(missing_b04))
        )
    blocked_ids = {
        row.get("decision_id", "").strip()
        for row in blocked_rows
    }
    blocked_details: list[dict[str, str]] = []
    applied_blocked = blocked_ids & applied_decision_ids
    if applied_blocked:
        b04_issues.append(
            "request_more_evidence decisions were applied: "
            + "|".join(sorted(applied_blocked))
        )
    for row in blocked_rows:
        scope = row.get("scope", "").strip()
        exact_match = BLOCKED_EXACT_SCOPE_RE.fullmatch(scope)
        family_match = BLOCKED_FAMILY_SCOPE_RE.fullmatch(scope)
        candidates: list[dict[str, str]]
        if exact_match is not None:
            identity = (
                exact_match.group("year"),
                exact_match.group("table").casefold(),
                exact_match.group("column").casefold(),
            )
            exact_source = source_by_identity.get(identity)
            candidates = [exact_source] if exact_source is not None else []
        elif family_match is not None:
            identity = (
                family_match.group("year"),
                family_match.group("family").casefold(),
                family_match.group("column").casefold(),
            )
            candidates = source_by_family_identity.get(identity, [])
        else:
            b04_issues.append(
                f"{row.get('decision_id')} has an unparseable blocked scope"
            )
            blocked_details.append(
                {
                    "decision_id": row.get("decision_id", "").strip(),
                    "scope": scope,
                    "resolved_identity": "<unparseable>",
                    "nonempty_count": "",
                    "metadata_status": "",
                    "unresolved_reason": "",
                    "blocker_type": "generator",
                    "missing_evidence": row.get("justification", "").strip(),
                }
            )
            continue
        resolved_identity = "|".join(
            sorted(
                f"{candidate.get('year')}:{candidate.get('access_table_name')}."
                f"{candidate.get('column_name')}"
                for candidate in candidates
            )
        )
        unresolved_reasons = {
            candidate.get("unresolved_reason", "") for candidate in candidates
        }
        if "generator_join_failure" in unresolved_reasons:
            blocker_type = "generator"
        elif "missing_metadata" in unresolved_reasons:
            blocker_type = "source_evidence"
        else:
            blocker_type = "scientific_review"
        blocked_details.append(
            {
                "decision_id": row.get("decision_id", "").strip(),
                "scope": scope,
                "resolved_identity": resolved_identity or "<absent>",
                "nonempty_count": "|".join(
                    candidate.get("nonempty_count", "") for candidate in candidates
                ),
                "metadata_status": "|".join(
                    candidate.get("column_metadata_match_status", "")
                    for candidate in candidates
                ),
                "unresolved_reason": "|".join(
                    candidate.get("unresolved_reason", "")
                    for candidate in candidates
                ),
                "blocker_type": blocker_type,
                "missing_evidence": row.get("justification", "").strip(),
            }
        )
        if not candidates:
            b04_issues.append(
                f"{row.get('decision_id')} blocked source identity is absent"
            )
        elif len(candidates) > 1:
            b04_issues.append(
                f"{row.get('decision_id')} blocked scope resolves to multiple "
                "source identities"
            )
        elif candidates[0].get("candidate_role", "") != "unresolved":
            b04_issues.append(
                f"{row.get('decision_id')} blocked source identity is not unresolved"
            )
    if not canonical_matches_head:
        b03_issues.append("canonical B03/B04 worktree files do not all match HEAD")
        b04_issues.append("canonical B03/B04 worktree files do not all match HEAD")
    if unexpected_canonical_changes:
        detail = "|".join(unexpected_canonical_changes)
        b03_issues.append(f"unexpected canonical changes: {detail}")
        b04_issues.append(f"unexpected canonical changes: {detail}")

    return {
        "b03_status": (
            "B03_EVIDENCE_REPAIRED" if not b03_issues else "B03_BLOCKED"
        ),
        "b04_status": (
            "B04_EVIDENCE_REPAIRED" if not b04_issues else "B04_BLOCKED"
        ),
        "b03_issues": b03_issues,
        "b04_issues": b04_issues,
        "supported_b03_count": len(supported_by_subsystem["B03"]),
        "supported_b04_count": len(supported_by_subsystem["B04"]),
        "applied_supported_b03_count": len(
            supported_by_subsystem["B03"] & applied_decision_ids
        ),
        "applied_supported_b04_count": len(
            supported_by_subsystem["B04"] & applied_decision_ids
        ),
        "request_more_evidence_count": len(blocked_ids),
        "preserved_request_more_evidence_count": len(blocked_ids - applied_decision_ids),
        "blocked_details": sorted(
            blocked_details,
            key=lambda row: (row["decision_id"], row["scope"]),
        ),
        "expected_source_column_count": expected_columns,
    }


def artifact_path(path: Path, repo_root: Path) -> str:
    try:
        return path.resolve().relative_to(repo_root.resolve()).as_posix()
    except ValueError:
        return str(path.resolve())


def build_package(
    *,
    repo_root: Path,
    legacy_root: Path,
    out_dir: Path,
    base_ref: str,
    authorized_contract_ref: str,
    trust_policy: PackageTrustPolicy,
    schema_tool_path: Path | None = None,
) -> dict[str, object]:
    repo_root = repo_root.resolve()
    legacy_root = legacy_root.resolve()
    out_dir = out_dir.resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    for name in REQUIRED_EVIDENCE_ARTIFACTS:
        path = out_dir / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"missing required B03/B04 evidence artifact: {name}")
    for name in REQUIRED_PACKAGE_ARTIFACTS:
        path = out_dir / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"missing required B03/B04 package artifact: {name}")
    validate_trust_policy(trust_policy)
    requested_base_commit = resolve_commit(repo_root, base_ref)
    requested_authorized_commit = resolve_commit(
        repo_root,
        authorized_contract_ref,
    )
    base_commit = resolve_commit(repo_root, trust_policy.base_commit)
    authorized_commit = resolve_commit(
        repo_root,
        trust_policy.authorized_contract_commit,
    )
    head_commit = resolve_commit(repo_root, "HEAD")
    assert_generator_inputs_match_head(repo_root, head_commit)
    decisions = read_csv(repo_root / "contracts" / "b03_b04_decisions.csv")
    command_log_statuses = validate_command_log(
        out_dir / "B03_B04_command_log.txt",
        head_commit,
        sum(
            row.get("decision", "").strip() != "request_more_evidence"
            for row in decisions
        ),
        sum(
            row.get("decision", "").strip() == "request_more_evidence"
            for row in decisions
        ),
        trust_policy,
    )

    table_rows = read_csv(out_dir / "table_grain_enriched.csv")
    table_exceptions = read_csv(out_dir / "table_grain_exceptions.csv")
    source_rows = read_csv(out_dir / "source_column_enriched.csv")
    source_exceptions = read_csv(out_dir / "source_column_exceptions.csv")
    input_rows, inventory_rows, source_headers = build_input_manifest_rows(
        repo_root=repo_root,
        legacy_root=legacy_root,
        schema_tool_path=(
            schema_tool_path.resolve() if schema_tool_path is not None else None
        ),
        table_evidence=table_rows,
    )
    input_fields = (
        "source_scope",
        "year",
        "logical_identity",
        "source_root",
        "path",
        "byte_size",
        "sha256",
        "expected_sha256",
        "verification_status",
        "purpose",
    )
    input_manifest = out_dir / "input_evidence_manifest.csv"
    write_csv(input_manifest, input_fields, input_rows)
    input_manifest_sha256 = digest(input_manifest)
    source_input_manifest_sha256 = trusted_input_fingerprint(input_rows)
    policy_fingerprint = trust_policy_fingerprint(trust_policy)
    trust_issues = package_trust_issues(
        repo_root=repo_root,
        out_dir=out_dir,
        requested_base_commit=requested_base_commit,
        requested_authorized_commit=requested_authorized_commit,
        head_commit=head_commit,
        trust_policy=trust_policy,
        input_rows=input_rows,
    )

    comparison_rows = build_canonical_comparison(
        repo_root=repo_root,
        base_commit=base_commit,
        authorized_commit=authorized_commit,
        head_commit=head_commit,
    )
    comparison_fields = (
        "path",
        "base_commit",
        "base_exists",
        "base_sha256",
        "authorized_commit",
        "authorized_exists",
        "authorized_sha256",
        "head_commit",
        "head_exists",
        "head_sha256",
        "worktree_exists",
        "worktree_sha256",
        "unchanged_from_base",
        "matches_authorized",
        "matches_head",
        "change_classification",
    )
    comparison_path = out_dir / "B03_B04_canonical_hash_comparison.csv"
    write_csv(comparison_path, comparison_fields, comparison_rows)

    table_grain_contract = read_csv(repo_root / "contracts" / "table_grain.csv")
    source_column_contract = read_csv(
        repo_root / "contracts" / "source_columns.csv"
    )
    source_alias_contract = read_csv(
        repo_root / "contracts" / "source_metadata_aliases.csv"
    )
    (
        b03_contract_issues,
        b04_contract_issues,
        applied_decision_ids,
    ) = decision_contract_issues(
        decisions=decisions,
        table_grain_rows=table_grain_contract,
        source_column_rows=source_column_contract,
        source_alias_rows=source_alias_contract,
    )
    summary = evidence_status(
        table_rows=table_rows,
        table_exceptions=table_exceptions,
        source_rows=source_rows,
        inventory_rows=inventory_rows,
        source_headers=source_headers,
        decisions=decisions,
        source_role_contract_rows=source_column_contract,
        applied_decision_ids=applied_decision_ids,
        canonical_matches_head=all(
            row["matches_head"] == "true" for row in comparison_rows
        ),
        trust_issues=trust_issues,
        unexpected_canonical_changes=[
            str(row["path"])
            for row in comparison_rows
            if row["change_classification"] == "unexpected_change"
        ],
        b03_contract_issues=b03_contract_issues,
        b04_contract_issues=b04_contract_issues,
    )
    for subsystem in ("b03", "b04"):
        status_key = f"{subsystem}_status"
        issues_key = f"{subsystem}_issues"
        logged_status = command_log_statuses[status_key]
        computed_status = str(summary[status_key])
        if logged_status != computed_status:
            summary[issues_key].append(
                f"command log {subsystem.upper()} status does not match computed "
                f"status: logged {logged_status}, computed {computed_status}"
            )
            summary[status_key] = f"{subsystem.upper()}_BLOCKED"
    table_statuses: dict[str, int] = defaultdict(int)
    for row in table_rows:
        table_statuses[row.get("table_metadata_match_status", "")] += 1
    source_statuses: dict[str, int] = defaultdict(int)
    source_roles: dict[str, int] = defaultdict(int)
    source_unresolved_reasons: dict[str, int] = defaultdict(int)
    for row in source_rows:
        source_statuses[row.get("column_metadata_match_status", "")] += 1
        source_roles[row.get("candidate_role", "")] += 1
        if row.get("candidate_role", "") == "unresolved":
            source_unresolved_reasons[row.get("unresolved_reason", "")] += 1
    table_grains: dict[str, int] = defaultdict(int)
    table_key_statuses: dict[str, int] = defaultdict(int)
    for row in table_rows:
        table_grains[row.get("candidate_grain", "")] += 1
        table_key_statuses[row.get("candidate_key_test_status", "")] += 1
    table_exception_reasons: dict[str, int] = defaultdict(int)
    for row in table_exceptions:
        table_exception_reasons[row.get("exception", "")] += 1
    source_exception_reasons: dict[str, int] = defaultdict(int)
    for row in source_exceptions:
        source_exception_reasons[
            row.get("unresolved_reason", "") or row.get("exception", "")
        ] += 1
    zero_row_tables = zero_row_observational_boundaries(table_rows)
    input_scope_counts: dict[str, int] = defaultdict(int)
    for row in input_rows:
        input_scope_counts[str(row["source_scope"])] += 1

    b03_contract_status = (
        "B03_CONTRACT_UPDATED_BY_AUTHORIZED_DECISION"
        if summary["supported_b03_count"]
        and summary["applied_supported_b03_count"]
        == summary["supported_b03_count"]
        else "B03_CONTRACT_APPLICATION_INCOMPLETE"
    )
    b04_contract_status = (
        "B04_CONTRACT_UPDATED_BY_AUTHORIZED_DECISIONS"
        if summary["supported_b04_count"]
        and summary["applied_supported_b04_count"]
        == summary["supported_b04_count"]
        else "B04_CONTRACT_APPLICATION_INCOMPLETE"
    )
    runtime_support_status = (
        "B03_B04_RUNTIME_SUPPORT_UPDATED_BY_AUTHORIZED_DECISIONS"
        if any(
            row["change_classification"]
            == "authorized_B03_B04_runtime_support"
            for row in comparison_rows
        )
        else "B03_B04_RUNTIME_SUPPORT_UNCHANGED"
    )
    lines = [
        "# B03/B04 result",
        "",
        str(summary["b03_status"]),
        str(summary["b04_status"]),
        b03_contract_status,
        b04_contract_status,
        runtime_support_status,
        "B04_REQUEST_MORE_EVIDENCE_"
        f"{summary['preserved_request_more_evidence_count']}_UNRESOLVED",
        "",
        "## Evidence inventory",
        "",
        f"- Table evidence rows: {len(table_rows)}; annual inventory rows: {len(inventory_rows)}.",
        "- Table metadata statuses: "
        + ", ".join(
            f"{key or '<blank>'}={value}"
            for key, value in sorted(table_statuses.items())
        )
        + ".",
        "- Candidate table grains: "
        + ", ".join(
            f"{key or '<blank>'}={value}"
            for key, value in sorted(table_grains.items())
        )
        + ".",
        "- Candidate key statuses: "
        + ", ".join(
            f"{key or '<blank>'}={value}"
            for key, value in sorted(table_key_statuses.items())
        )
        + ".",
        f"- Table-grain exceptions: {len(table_exceptions)}"
        + (
            " ("
            + ", ".join(
                f"{key or '<blank>'}={value}"
                for key, value in sorted(table_exception_reasons.items())
            )
            + ")"
            if table_exception_reasons
            else ""
        )
        + ".",
        f"- Source-column evidence rows: {len(source_rows)}; inventory column total: "
        f"{summary['expected_source_column_count']}.",
        "- Source-column metadata statuses: "
        + ", ".join(
            f"{key or '<blank>'}={value}"
            for key, value in sorted(source_statuses.items())
        )
        + ".",
        "- Candidate source-column roles: "
        + ", ".join(
            f"{key or '<blank>'}={value}"
            for key, value in sorted(source_roles.items())
        )
        + ".",
        "- Unresolved source-column reasons: "
        + (
            ", ".join(
                f"{key or '<blank>'}={value}"
                for key, value in sorted(source_unresolved_reasons.items())
            )
            if source_unresolved_reasons
            else "none"
        )
        + ".",
        f"- Source-column exceptions: {len(source_exceptions)}"
        + (
            " ("
            + ", ".join(
                f"{key or '<blank>'}={value}"
                for key, value in sorted(source_exception_reasons.items())
            )
            + ")"
            if source_exception_reasons
            else ""
        )
        + ".",
        f"- Input manifest SHA-256: {input_manifest_sha256}.",
        "- Input scopes: "
        + ", ".join(
            f"{key}={value}" for key, value in sorted(input_scope_counts.items())
        )
        + ".",
        "",
        "## Reviewed decisions",
        "",
        f"- B03 supported decisions applied: {summary['applied_supported_b03_count']}/"
        f"{summary['supported_b03_count']}.",
        f"- B04 supported decisions applied: {summary['applied_supported_b04_count']}/"
        f"{summary['supported_b04_count']}.",
        f"- REQUEST_MORE_EVIDENCE_PRESERVED: "
        f"{summary['preserved_request_more_evidence_count']}/"
        f"{summary['request_more_evidence_count']}.",
        f"- Canonical comparison base commit: {base_commit}.",
        f"- Authorized canonical snapshot commit: {authorized_commit}.",
        f"- Requested base ref resolved to: {requested_base_commit}.",
        "- Requested authorized-contract ref resolved to: "
        f"{requested_authorized_commit}.",
        "- Trusted evidence-generator implementation commit: "
        f"{trust_policy.evidence_generator_commit}.",
        "- Trusted normalized command-receipt SHA-256: "
        f"{trust_policy.command_log_normalized_sha256}.",
        "- Trusted decision-register SHA-256: "
        f"{trust_policy.decision_register_sha256}.",
        "- Trusted evidence-artifact hashes: "
        f"{len(trust_policy.evidence_artifact_sha256)}.",
        "- Trusted source-input manifest SHA-256: "
        f"{trust_policy.source_input_manifest_sha256}; observed "
        f"{source_input_manifest_sha256}.",
        f"- Package trust-policy fingerprint: {policy_fingerprint}.",
        f"- Package generator commit: {head_commit}. Exact generator/helper file "
        "hashes are bound in the input manifest.",
    ]
    if zero_row_tables:
        lines.extend(
            [
                "",
                "## Zero-row observational boundary",
                "",
            ]
        )
        lines.extend(
            "- `"
            f"{row.get('year')}:{row.get('access_table_name')}`: "
            f"declared key `{row.get('declared_key_columns') or '<none>'}`; "
            f"key status `{row.get('candidate_key_test_status') or '<blank>'}`; "
            f"observed candidate grain `{row.get('candidate_grain') or '<blank>'}`. "
            "A zero-row export cannot empirically prove uniqueness or grain."
            for row in zero_row_tables
        )
    blocked_details = summary["blocked_details"]
    if blocked_details:
        lines.extend(
            [
                "",
                "## Preserved request-more-evidence decisions",
                "",
            ]
        )
        for detail in blocked_details:
            lines.append(
                f"- {detail['decision_id']}: `{detail['resolved_identity']}` "
                f"(review scope `{detail['scope']}`); nonempty count "
                f"{detail['nonempty_count'] or '<unknown>'}; metadata status "
                f"`{detail['metadata_status'] or '<blank>'}`; unresolved reason "
                f"`{detail['unresolved_reason'] or '<blank>'}`; blocker type "
                f"`{detail['blocker_type']}`. Smallest next "
                f"evidence/decision input: {detail['missing_evidence'] or 'not recorded'}"
            )
    if summary["b03_issues"]:
        lines.extend(
            [
                "",
                "## B03 blockers",
                "",
                *[f"- {issue}" for issue in summary["b03_issues"]],
            ]
        )
    if summary["b04_issues"]:
        lines.extend(
            [
                "",
                "## B04 blockers",
                "",
                *[f"- {issue}" for issue in summary["b04_issues"]],
            ]
        )
    lines.extend(
        [
            "",
            "The evidence and reviewed-decision application do not constitute a full "
            "pipeline build or release approval.",
            "",
            "FULL_BUILD_NOT_RUN",
            "RELEASE_STILL_BLOCKED",
            "",
        ]
    )
    result_path = out_dir / "B03_B04_RESULT.md"
    result_path.write_text("\n".join(lines), encoding="utf-8")

    artifact_names = [
        *REQUIRED_EVIDENCE_ARTIFACTS,
        input_manifest.name,
        comparison_path.name,
        result_path.name,
        *REQUIRED_PACKAGE_ARTIFACTS,
    ]
    comparison_sha256 = digest(comparison_path)
    artifact_rows = [
        {
            "path": artifact_path(out_dir / name, repo_root),
            "byte_size": (out_dir / name).stat().st_size,
            "sha256": digest(out_dir / name),
            "generator_commit": head_commit,
            "input_manifest_sha256": input_manifest_sha256,
            "canonical_hash_comparison_sha256": comparison_sha256,
        }
        for name in artifact_names
    ]
    artifact_fields = (
        "path",
        "byte_size",
        "sha256",
        "generator_commit",
        "input_manifest_sha256",
        "canonical_hash_comparison_sha256",
    )
    write_csv(
        out_dir / "B03_B04_artifact_manifest.csv",
        artifact_fields,
        artifact_rows,
    )
    return {
        **summary,
        "generator_commit": head_commit,
        "base_commit": base_commit,
        "authorized_contract_commit": authorized_commit,
        "evidence_generator_commit": trust_policy.evidence_generator_commit,
        "requested_base_commit": requested_base_commit,
        "requested_authorized_contract_commit": requested_authorized_commit,
        "trust_policy_fingerprint": policy_fingerprint,
        "source_input_manifest_sha256": source_input_manifest_sha256,
        "input_manifest_sha256": input_manifest_sha256,
        "input_row_count": len(input_rows),
        "artifact_row_count": len(artifact_rows),
    }


def package_process_exit_code(result: dict[str, object]) -> int:
    return (
        0
        if result.get("b03_status") == "B03_EVIDENCE_REPAIRED"
        and result.get("b04_status") == "B04_EVIDENCE_REPAIRED"
        else 1
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=ROOT)
    parser.add_argument("--legacy-root", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument("--base-ref", required=True)
    parser.add_argument("--authorized-contract-ref", required=True)
    parser.add_argument("--schema-tool", type=Path)
    args = parser.parse_args()
    repo_root = args.repo_root.resolve()
    out_dir = (
        args.out_dir.resolve()
        if args.out_dir is not None
        else repo_root / "Artifacts" / "review_v2"
    )
    result = build_package(
        repo_root=repo_root,
        legacy_root=args.legacy_root,
        out_dir=out_dir,
        base_ref=args.base_ref,
        authorized_contract_ref=args.authorized_contract_ref,
        trust_policy=PRODUCTION_TRUST_POLICY,
        schema_tool_path=args.schema_tool,
    )
    print(result["b03_status"])
    print(result["b04_status"])
    print(f"generator_commit={result['generator_commit']}")
    print(f"input_manifest_sha256={result['input_manifest_sha256']}")
    print("FULL_BUILD_NOT_RUN")
    print("RELEASE_STILL_BLOCKED")
    if package_process_exit_code(result):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
